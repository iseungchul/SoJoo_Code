#if !defined(AFX_PANEMOTORSETUPSUB_H__E5761B27_E6E3_4C1C_A0CA_04FCD6EC3CC8__INCLUDED_)
#define AFX_PANEMOTORSETUPSUB_H__E5761B27_E6E3_4C1C_A0CA_04FCD6EC3CC8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneMotorSetupSub.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneMotorSetupSub form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"

class CPaneMotorSetupSub : public CFormView
{
protected:
	CPaneMotorSetupSub();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneMotorSetupSub)

// Form Data
public:
	//{{AFX_DATA(CPaneMotorSetupSub)
	enum { IDD = IDD_DLG_MOTOR_SETUP_SUB };
	UEasyButtonEx	m_btnBack;
	//}}AFX_DATA

// Attributes
public:
	CFont		m_fntBtn;

// Operations
public:
	void		InitBtnControl();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneMotorSetupSub)
	public:
	virtual BOOL DestroyWindow();
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneMotorSetupSub();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneMotorSetupSub)
	afx_msg void OnButtonBack();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMOTORSETUPSUB_H__E5761B27_E6E3_4C1C_A0CA_04FCD6EC3CC8__INCLUDED_)

// PaneRecipeGenSub.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneRecipeGenSub.h"
#include "..\EasyDrillerDlg.h"
#include "..\model\DProcessINI.h"
#include "..\model\DEasyDrillerINI.h"

#include "..\model\dproject.h"
#include "..\device\HVision.h"
#include "..\device\HDeviceFactory.h"
#include "PaneManualControl.h"
#include "PaneManualControlVision.h"
#include "PaneRecipeGen.h"
#include "PaneRecipeGenData.h"
#include "PaneRecipeGenFiducialNew.h"
#include "PaneRecipeGenParameterNew.h"
#include "..\alarmmsg.h"
#include "paneautorun.h"
#include "PaneAutoRunViewFiducial.h"
#include "PaneAutoRunViewPrework.h"
#include "PaneAutoRunViewPreworkPower.h"
#include "..\model\DSystemINI.h"
#include "CDlgBarcodeManager.h"
#include "DlgBarcodeInfo.h"
#include "..\device\HEocard.h"
#include "ProgressWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenSub

IMPLEMENT_DYNCREATE(CPaneRecipeGenSub, CFormView)

CPaneRecipeGenSub::CPaneRecipeGenSub()
	: CFormView(CPaneRecipeGenSub::IDD)
{
	//{{AFX_DATA_INIT(CPaneRecipeGenSub)
	//}}AFX_DATA_INIT
	m_nBackPaneNo		= 0;
}

CPaneRecipeGenSub::~CPaneRecipeGenSub()
{
}

void CPaneRecipeGenSub::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneRecipeGenSub)
	DDX_Control(pDX, IDC_BUTTON_PRJ_OPEN, m_btnPrjOpen);
	DDX_Control(pDX, IDC_BTN_GO_VISION, m_btnGoVision);
	DDX_Control(pDX, IDC_BTN_GO_FIDUCIAL, m_btnGoFiducial);
	DDX_Control(pDX, IDC_BUTTON_PRJ_SAVE, m_btnPrjSave);
	DDX_Control(pDX, IDC_BUTTON_PRJ_APPLY, m_btnPrjApply);
	DDX_Control(pDX, IDC_BUTTON_BACK, m_btnBack);
	DDX_Control(pDX, IDC_BUTTON_PRJ_INIT, m_btnPrjInit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneRecipeGenSub, CFormView)
	//{{AFX_MSG_MAP(CPaneRecipeGenSub)
	ON_BN_CLICKED(IDC_BUTTON_BACK, OnButtonBack)
	ON_BN_CLICKED(IDC_BUTTON_PRJ_SAVE, OnButtonPrjSave)
	ON_BN_CLICKED(IDC_BTN_GO_VISION, OnBtnGoVision)
	ON_BN_CLICKED(IDC_BTN_GO_FIDUCIAL, OnBtnGoFiducial)
	ON_BN_CLICKED(IDC_BUTTON_PRJ_OPEN, OnButtonPrjOpen)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_PRJ_APPLY, OnButtonPrjApply)
	ON_BN_CLICKED(IDC_BUTTON_DIVIDE, OnButtonDivide)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_PRJ_INIT, &CPaneRecipeGenSub::OnBnClickedButtonPrjInit)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenSub diagnostics

#ifdef _DEBUG
void CPaneRecipeGenSub::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneRecipeGenSub::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenSub message handlers

void CPaneRecipeGenSub::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
}

void CPaneRecipeGenSub::OnButtonBack() 
{
	// 110621
/*	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsIdleStatus() && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bLaser && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bInit)
	{
//		if(IDYES == ErrMessage(IDS_IDLE_CHANGE_ON, MB_YESNO))
		{		
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bIdleStatus = TRUE;	
			::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, IDLE_MODE);
		}
	}
*/	

	BOOL bCurrentShow = ((CEasyDrillerDlg*)::AfxGetMainWnd())->IsShowEasyTestDlg();

	if(bCurrentShow)
	{			
		if(IDNO == ErrMessage(_T("Do you want exit EasyMode?"), MB_YESNO | MB_ICONQUESTION))
	    return;
	}

	WPARAM wParam = m_nBackPaneNo;

	int nBackPaneNo = ::AfxGetMainWnd()->SendMessage( GET_BACK_PANE_NO, wParam, 0 );

	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, nBackPaneNo );
}

void CPaneRecipeGenSub::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnPrjApply.SetFont( &m_fntBtn );
	m_btnPrjApply.SetFlat( FALSE );
	m_btnPrjApply.SetImageOrg( 10, 3 );
	m_btnPrjApply.SetIcon( IDI_APPLY );
	m_btnPrjApply.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPrjApply.EnableBallonToolTip();
	m_btnPrjApply.SetToolTipText( _T("Recipe Data Apply") );
	m_btnPrjApply.SetBtnCursor( IDC_HAND_1 );

	m_btnPrjSave.SetFont( &m_fntBtn );
	m_btnPrjSave.SetFlat( FALSE );
	m_btnPrjSave.SetImageOrg( 10, 3 );
	m_btnPrjSave.SetIcon( IDI_SAVE );
	m_btnPrjSave.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPrjSave.EnableBallonToolTip();
	m_btnPrjSave.SetToolTipText( _T("Recipe Data Save") );
	m_btnPrjSave.SetBtnCursor( IDC_HAND_1 );
	m_btnPrjInit.SetFont( &m_fntBtn );
	m_btnPrjInit.SetFlat( FALSE );
	m_btnPrjInit.SetImageOrg( 10, 3 );
	m_btnPrjInit.SetIcon( IDI_CLEAN );
	m_btnPrjInit.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPrjInit.EnableBallonToolTip();
	m_btnPrjInit.SetToolTipText( _T("Recipe Data Save") );
	m_btnPrjInit.SetBtnCursor( IDC_HAND_1 );

	m_btnPrjOpen.SetFont( &m_fntBtn );
	m_btnPrjOpen.SetFlat( FALSE );
	m_btnPrjOpen.SetImageOrg( 10, 3 );
	m_btnPrjOpen.SetIcon( IDI_OPEN );
	m_btnPrjOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPrjOpen.EnableBallonToolTip();
	m_btnPrjOpen.SetToolTipText( _T("Recipe Data Open") );
	m_btnPrjOpen.SetBtnCursor( IDC_HAND_1 );

	// Go Vision
	m_btnGoVision.SetFont( &m_fntBtn );
	m_btnGoVision.SetFlat( FALSE );
	m_btnGoVision.SetImageOrg( 10, 3 );
	m_btnGoVision.SetIcon( IDI_VISION, 48, 48 );
	m_btnGoVision.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGoVision.EnableBallonToolTip();
	m_btnGoVision.SetToolTipText( _T("Move Manual - Vision") );
	m_btnGoVision.SetBtnCursor( IDC_HAND_1 );
	m_btnGoVision.ShowWindow(SW_HIDE);

	// Go Fiducial
	m_btnGoFiducial.SetFont( &m_fntBtn );
	m_btnGoFiducial.SetFlat( FALSE );
	m_btnGoFiducial.SetImageOrg( 10, 3 );
	m_btnGoFiducial.SetIcon( IDI_PROCESSSETUP, 48, 48 );
	m_btnGoFiducial.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGoFiducial.EnableBallonToolTip();
	m_btnGoFiducial.SetToolTipText( _T("Move ProcessSetup - Fiducial") );
	m_btnGoFiducial.SetBtnCursor( IDC_HAND_1 );
	m_btnGoFiducial.ShowWindow(SW_HIDE);

	m_btnBack.SetFont( &m_fntBtn );
	m_btnBack.SetFlat( FALSE );
	m_btnBack.SetImageOrg( 10, 3 );
	m_btnBack.SetIcon( IDI_BACK );
	m_btnBack.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBack.EnableBallonToolTip();
	m_btnBack.SetToolTipText( _T("Back") );
	m_btnBack.SetBtnCursor( IDC_HAND_1 );
}

void CPaneRecipeGenSub::OnButtonPrjSave() 
{
	TCHAR BASED_CODE szFilter[] = _T("Project Files (*.prj)|*.prj|All Files (*.*)|*.*||");

	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

	CString strFull, strAddr, strFile;
	strFull = ((CEasyDrillerDlg*)GetParent())->GetPrjName();

	if(strFull == _T("Untitle.prj"))
	{
		strAddr = gEasyDrillerINI.m_clsDirPath.GetProjectDir();
		strFile = "";
	}
	else
	{
		int nToken = strFull.ReverseFind(_T('\\'));
		if(nToken == -1)
		{
			strAddr = gEasyDrillerINI.m_clsDirPath.GetProjectDir();
			strFile = strFull;
		}
		else
		{
			strAddr = strFull.Mid(0,nToken);
			strFile = strFull.Mid(nToken+1);
		}
	}

	CFileDialog dlg(FALSE, "*.prj", strFile, dwFlags, szFilter);
	dlg.m_ofn.lpstrInitialDir = strAddr;
	if(IDOK != dlg.DoModal())
	{
		return;
	}

	BOOL bExist = CheckSameName(dlg.GetPathName());
	if(FALSE == ((CEasyDrillerDlg*)GetParent())->SaveProject(dlg.GetPathName()))
		return; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
	
#ifndef __KUNSAN_LAVIA__
	CDlgBarcodeInfo dlgLotId;
	dlgLotId.m_strLotInfo.Format(_T("%s"), gDProject.m_szLotId);
	while(TRUE)
	{
		if(IDOK == dlgLotId.DoModal())
			break;
	}
	((CEasyDrillerDlg*)GetParent())->m_pRecipeGen->m_pParamNew->ChangeLotID(dlgLotId.m_strLotInfo);
#else
	((CEasyDrillerDlg*)GetParent())->m_pRecipeGen->m_pParamNew->ChangeLotID(gDProject.m_szLotId);
#endif
//	strcpy_s(gDProject.m_szLotId, dlgLotId.m_strLotInfo);
	
	((CEasyDrillerDlg*)GetParent())->SetPrjName( dlg.GetPathName() );
	((CEasyDrillerDlg*)GetParent())->m_pAutoRun->SetPreworkInfo();
	((CEasyDrillerDlg*)GetParent())->m_pAutoRun->m_pFiducial->ChangeDisplay();
	if(((CEasyDrillerDlg*)GetParent())->m_pAutoRun->m_pPrework)
		((CEasyDrillerDlg*)GetParent())->m_pAutoRun->m_pPrework->m_pPower->ChangeDisplay();

	((CEasyDrillerDlg*)GetParent())->m_pAutoRun->CalculateAvgScale();
	strcpy_s(gDProject.m_szProjectName, dlg.GetPathName());
	::AfxGetApp()->WriteProfileString(_T("Files"), _T("Recent File"), dlg.GetPathName());

/*	if(!bExist)
	{
		//create new prj
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_RECIPE, RMS_CREATE);
	}
	else
	{
		//change prj
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_RECIPE, RMS_CHANGE);
	}
	*/
	::AfxGetMainWnd()->SendMessage(UM_CHANGE_DATAFILE, TRUE);
	((CEasyDrillerDlg*)GetParent())->m_pAutoRun->DoFidImageWork();
}

void CPaneRecipeGenSub::OnBtnGoVision() 
{
	WPARAM wParam = MANUAL_CONTROL;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, RECIPE_GEN );

	::AfxGetMainWnd()->PostMessage( CHANGE_SUB_PANE, wParam, 4 ); // Vision Tab
}

void CPaneRecipeGenSub::OnBtnGoFiducial() 
{
	WPARAM wParam = PROCESS_SETUP;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, 4 ); // Fiducial Tab
}

void CPaneRecipeGenSub::ShowBtnControl(int nCmdShow)
{ 
	 m_btnPrjSave.ShowWindow( nCmdShow );
    // m_btnPrjSave2.ShowWindow( nCmdShow );
	 m_btnPrjInit.ShowWindow( nCmdShow );
}

void CPaneRecipeGenSub::OnButtonPrjOpen() 
{
#ifdef __KUNSAN_LAVIA__  // ��� ��� �߰�
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->GetUserLevel() < 1 )
	{
		ErrMessage(_T("Operator can't open a project."));
		return;
	}
#endif

	CString strMessage,str,strTemp;
	//if(gSystemINI.m_sHardWare.nUseBarcodeReader == 1)  20190702
	if(gProcessINI.m_sProcessSystem.bUseBracodeReader)
	{
		CDlgBarcodeManager dlg;
		dlg.SetOpenType(TRUE);
		if(IDOK != dlg.DoModal())
		{
			return;
		}

		((CEasyDrillerDlg*)GetParent())->SetFileOpen(FALSE);

//		CString strName;
//		TCHAR cTemp[125] ={0,}; //20130528 125 ���� ū ��ΰ� ������ ������ �Ⱦ��°� ���� �ּ�
		
//		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_stcPrjName.GetWindowText(strName);
//		_stprintf_s(cTemp, (LPSTR)(LPCTSTR)strName);
		
//		if(strcmp(cTemp, (LPSTR)(LPCTSTR)dlg.GetFilePath()) != 0)
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER + DO_SCANNER));
			CString strFile, strLog;
			strFile.Format(_T("PreWork"));
			strLog.Format(_T("AnyDo (OnButtonPrjOpen) : P + S"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		}

		if(FALSE == ((CEasyDrillerDlg*)GetParent())->OpenProject(dlg.GetFilePath()))
		{
			ErrMsgDlg(STDGNALM113, dlg.GetFilePath());
			return; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
		}

		((CEasyDrillerDlg*)GetParent())->SetPrjName( dlg.GetFilePath() );
		
		::AfxGetMainWnd()->SendMessage(UM_CHANGE_DATAFILE, TRUE);
		
		strcpy_s(gDProject.m_szProjectName, dlg.GetFilePath());
		strcpy_s(gDProject.m_szTempFileName, gDProject.m_szFileName);
		
		strMessage.Format(_T("Project ( %s ) is opend"), dlg.GetFilePath());
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), NULL);
		
		::AfxGetApp()->WriteProfileString(_T("Files"), _T("Recent File"), dlg.GetFilePath());
		
		((CEasyDrillerDlg*)GetParent())->SetFileOpen(TRUE);
	}
	else
 	{
		CDlgBarcodeInfo dlgLotId;
		if(IDOK != dlgLotId.DoModal())
		{
			return;
		}
		strcpy_s(gDProject.m_szLotId, dlgLotId.m_strLotInfo);

		TCHAR BASED_CODE szFilter[] = _T("Project Files (*.prj)|*.prj|All Files (*.*)|*.*||");

		DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

		CFileDialog dlg(TRUE, _T("*.prj"), NULL, dwFlags, szFilter);

		dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetProjectDir();

		if(IDOK != dlg.DoModal())
		{
			return;
		}

		((CEasyDrillerDlg*)GetParent())->SetFileOpen(FALSE);

		//������ ������Ʈ ���½� �н� 
//		CString strName;
//		TCHAR cTemp[125] ={0,};
		
//		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_stcPrjName.GetWindowText(strName);
//		_stprintf_s(cTemp, (LPSTR)(LPCTSTR)strName);
		
//		if(strcmp(cTemp, dlg.GetPathName()) != 0)
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER + DO_SCANNER));
			CString strFile, strLog;
			strFile.Format(_T("PreWork"));
			strLog.Format(_T("AnyDo (OnButtonPrjOpen 2) : P + S"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		}

		if(FALSE == ((CEasyDrillerDlg*)GetParent())->OpenProject(dlg.GetPathName()))
		{
			ErrMsgDlg(STDGNALM113, dlg.GetPathName());
			return; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
		}

		((CEasyDrillerDlg*)GetParent())->SetPrjName( dlg.GetPathName() );
		strcpy_s(gDProject.m_szLotId, dlgLotId.m_strLotInfo);
		
		::AfxGetMainWnd()->SendMessage(UM_CHANGE_DATAFILE, TRUE);

		strcpy_s(gDProject.m_szProjectName, dlg.GetPathName());
		strcpy_s(gDProject.m_szTempFileName, gDProject.m_szFileName);

		strMessage.Format(_T("Project ( %s ) is opend"), dlg.GetPathName());
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), NULL);
		
		::AfxGetApp()->WriteProfileString(_T("Files"), _T("Recent File"), dlg.GetPathName());
		
		((CEasyDrillerDlg*)GetParent())->SetFileOpen(TRUE);

	}


	HVision* pVision =gDeviceFactory.GetVision();
	str.Format(_T("%s"),gDProject.m_szVisionProjectName);
	int nlen, n = str.Find("D:");
	nlen = strlen(str);
	if(n != -1) //char finding ���ϸ� return = -1
	{
		strTemp = str.Mid(n, nlen-n);
 		memset(gDProject.m_szVisionProjectName, 0 , sizeof(gDProject.m_szVisionProjectName));
		strcpy_s(gDProject.m_szVisionProjectName, strTemp);

		nlen = strlen(gDProject.m_szVisionProjectName);
		if(nlen > 0)
		{
			if(pVision->LoadProject(strTemp))
			{
				((CEasyDrillerDlg*)GetParent())->m_pManualControl->m_pVision->m_edtProjectPath.SetWindowText((LPCTSTR)strTemp);
				((CEasyDrillerDlg*)GetParent())->m_pRecipeGen->m_pFiducialNew->m_edtPath.SetWindowText((LPCTSTR)strTemp);
			}
		}
	}
	else
	{
		memset(&gDProject.m_szVisionProjectName, 0 , sizeof(gDProject.m_szVisionProjectName));
		((CEasyDrillerDlg*)GetParent())->m_pManualControl->m_pVision->m_edtProjectPath.SetWindowText("");
		((CEasyDrillerDlg*)GetParent())->m_pRecipeGen->m_pFiducialNew->m_edtPath.SetWindowText("");
	}

	((CEasyDrillerDlg*)GetParent())->m_pAutoRun->CalculateAvgScale();

	((CEasyDrillerDlg*)GetParent())->m_pAutoRun->SetPreworkInfo();

#ifdef __KUNSAN_LAVIA__
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nRealFiredHoleCount = 0;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nTotalHoleCount = 0;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nTotalLineCount = 0;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nLotHoleCount = 0;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nLotLineCount = 0;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nCurrentLotCount = 0;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->	GetLotCntAndMarkIndex(TRUE, TRUE);
#endif

	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->ChangeProjectInfo(TRUE);
	((CEasyDrillerDlg*)GetParent())->m_pRecipeGen->m_pFiducialNew->DrawData();
	((CEasyDrillerDlg*)GetParent())->m_pAutoRun->DoFidImageWork();
}

void CPaneRecipeGenSub::OnDestroy() 
{
	m_fntBtn.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneRecipeGenSub::OnButtonPrjApply() 
{
	// TODO: Add your control notification handler code here
	
	((CEasyDrillerDlg*)GetParent())->SetFileOpen(FALSE);

	if(FALSE == ((CEasyDrillerDlg*)GetParent())->ApplyProject())
		return; // error �α� ��� ����� �����Ѵ� -> ���� �߰�

	((CEasyDrillerDlg*)GetParent())->SetFileOpen(TRUE);
	
	if(!((CEasyDrillerDlg*)GetParent())->IsShowEasyTestDlg())
	{
	   WPARAM wParam = m_nBackPaneNo;
	   int nBackPaneNo = ::AfxGetMainWnd()->SendMessage( GET_BACK_PANE_NO, wParam, 0 );
	   ::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, nBackPaneNo );
	}

	strcpy_s(gDProject.m_szFileName, gDProject.m_szTempFileName);
	::AfxGetMainWnd()->SendMessage(UM_CHANGE_DATAFILE, TRUE);
	((CEasyDrillerDlg*)GetParent())->m_pAutoRun->SetPreworkInfo();
	((CEasyDrillerDlg*)GetParent())->m_pAutoRun->m_pFiducial->ChangeDisplay();
	if(((CEasyDrillerDlg*)GetParent())->m_pAutoRun->m_pPrework)
		((CEasyDrillerDlg*)GetParent())->m_pAutoRun->m_pPrework->m_pPower->ChangeDisplay();
	((CEasyDrillerDlg*)GetParent())->m_pAutoRun->CalculateAvgScale();

	if(!gDeviceFactory.GetEocard()->StandbyParamSet())
	{
#ifndef __TEST__
		CString strFile, strLog;
		strFile.Format(_T("ReadHole"));
		strLog.Format(_T("Standby Parameter Set Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		ErrMessage(_T("Error : Standby shot parameter download Failure"));
#endif
	}
	BOOL bCurrentShow = ::AfxGetMainWnd()->SendMessage(UM_IS_SHOW_EASY_TEST_WINDOW);

	if(bCurrentShow)
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->ChangeProjectInfo(TRUE);

}

void CPaneRecipeGenSub::OnButtonDivide() 
{
	// TODO: Add your control notification handler code here
	
}


BOOL CPaneRecipeGenSub::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Recipe_Sub) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}
BOOL CPaneRecipeGenSub::CheckSameName(CString strPath)
{
	BOOL bExist;
	CFileFind find;
	bExist = find.FindFile(strPath);
	if(bExist)
	{
		return TRUE;
	}
	return FALSE;
}
void CPaneRecipeGenSub::EnableButton(BOOL bEnable)
{
	m_btnPrjApply.EnableWindow(bEnable);
	m_btnPrjSave.EnableWindow(bEnable);
	m_btnPrjOpen.EnableWindow(bEnable);
	m_btnGoVision.EnableWindow(bEnable);
	m_btnGoFiducial.EnableWindow(bEnable);
	m_btnBack.EnableWindow(bEnable);

	m_btnPrjInit.EnableWindow(bEnable);
}

void CPaneRecipeGenSub::OnButtonPrjSave2() 
{
	CString strFull, strAddr, strFile;
	strFull = ((CEasyDrillerDlg*)GetParent())->GetDataName();//gDProject.m_szFileName; //((CEasyDrillerDlg*)GetParent())->GetPrjName();

	if(strFull == _T("Untitle.txt"))
	{
		ErrMessage(_T("Excellon data file name is Untitle.txt\n Please open another excellon data"));
		return;
	}
	else
	{
		int nToken = strFull.ReverseFind(_T('\\'));
		if(nToken == -1)
		{
			strFile = strFull;
		}
		else
		{
			strFile = strFull.Mid(nToken+1);
		}
		
		int nIndex = strFile.ReverseFind(_T('.'));
		if(nIndex == -1)
		{
			strFile = strFile;
		}
		else
		{
			strFile = strFile.Left(nIndex);
		}
	}
	strAddr = gEasyDrillerINI.m_clsDirPath.GetProjectDir();
	strFull.Format(_T("%s%s.prj"), strAddr, strFile);

 	BOOL bExist = CheckSameName(strFull);

	CProgressWnd wndProgress(NULL, _T("Save Data"), TRUE);
	wndProgress.GoModal();
	wndProgress.SetRange(0,0);
	wndProgress.SetText(_T("Save Data"));

 	if(FALSE == ((CEasyDrillerDlg*)GetParent())->SaveProject(strFull))
 		return; // error �α� ��� ����� �����Ѵ� -> ���� �߰�

	wndProgress.ShowWindow(SW_HIDE);
/*	CDlgBarcodeInfo dlgLotId;
	dlgLotId.m_strLotInfo.Format(_T("%s"), gDProject.m_szLotId);
	while(TRUE)
	{
		if(IDOK == dlgLotId.DoModal())
			break;
	}
	strcpy_s(gDProject.m_szLotId, dlgLotId.m_strLotInfo);
	*/
	((CEasyDrillerDlg*)GetParent())->SetPrjName( strFull );
	((CEasyDrillerDlg*)GetParent())->m_pAutoRun->SetPreworkInfo();
	((CEasyDrillerDlg*)GetParent())->m_pAutoRun->m_pFiducial->ChangeDisplay();
	if(((CEasyDrillerDlg*)GetParent())->m_pAutoRun->m_pPrework)
		((CEasyDrillerDlg*)GetParent())->m_pAutoRun->m_pPrework->m_pPower->ChangeDisplay();
	((CEasyDrillerDlg*)GetParent())->m_pRecipeGen->m_pParamNew->ChangeLotID(gDProject.m_szLotId);
	((CEasyDrillerDlg*)GetParent())->m_pAutoRun->CalculateAvgScale();
	strcpy_s(gDProject.m_szProjectName, strFull);
	::AfxGetApp()->WriteProfileString(_T("Files"), _T("Recent File"), strFull);

/*	if(!bExist)
	{
		//create new prj
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_RECIPE, RMS_CREATE);
	}
	else
	{
		//change prj
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_RECIPE, RMS_CHANGE);
	}
	*/
	::AfxGetMainWnd()->SendMessage(UM_CHANGE_DATAFILE, TRUE);
	((CEasyDrillerDlg*)GetParent())->m_pAutoRun->DoFidImageWork();
}


void CPaneRecipeGenSub::OnBnClickedButtonPrjInit()
{
	gDProject.RemoveProject();
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_DProject.RemoveProject();
	//((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pDlgRecipeGen->m_DProject.RemoveProject();

	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pDataLoad->DrawData();
	//Invalidate();
}

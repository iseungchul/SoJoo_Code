#if !defined(AFX_PANEMANUALCONTROLDEVICE_H__11221492_D53E_45B8_ADA1_FC693D41C24E__INCLUDED_)
#define AFX_PANEMANUALCONTROLDEVICE_H__11221492_D53E_45B8_ADA1_FC693D41C24E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlDevice.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlDevice form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "ColorStatic.h"
#include "UEasyButton.h"
#include "UEasyButtonEx.h"

class CPaneManualControlDevice : public CFormView
{
protected:
	CPaneManualControlDevice();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlDevice)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlDevice)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_DEVICE };
	CColorStatic	m_stc2ndThickness;
	CColorStatic	m_stc1stThickness;
	UEasyButtonEx	m_btnMeasuring;
	UEasyButton	m_btnPowermeterOpen;
	UEasyButton	m_btnPowermeterClose;
	UEasyButton m_btnPowermeterOpen2nd;
	UEasyButton m_btnPowermeterClose2nd;
	UEasyButton	m_btnHSensorDown;
	UEasyButton	m_btnHSensorUp;
	UEasyButton m_btnHSensorDown2nd;
	UEasyButton m_btnHSensorUp2nd;
	UEasyButton	m_btn2ndShtOpen;
	UEasyButton	m_btn2ndShtClose;
	UEasyButton	m_btn1stShtOpen;
	UEasyButton	m_btn1stShtClose;
	UEasyButtonEx	m_btnMoveMaskPos;
	UEasyButtonEx	m_btnMoveMask;
	UEasyButtonEx	m_btnUnloaderHoming;
	UEasyButtonEx	m_btnLoaderHoming;
	UEasyButtonEx	m_btnMotorHoming;
	CColorEdit	m_edtMaskPos;
	CComboBox	m_cmbMask;
	//}}AFX_DATA

// Attributes
public:

// Attributes
protected:
	CFont			m_fntStatic;
	CFont			m_fntBtn;
	CFont			m_fntEdit;
	CFont			m_fntCombo;

	BOOL			m_b1stSht;
	BOOL			m_b2ndSht;
	BOOL			m_bPowermeter;
	BOOL			m_bHeightSensor;
	BOOL			m_bPowermeter2nd;
	BOOL			m_bHeightSensor2nd;

// Operations
public:
	void			InitBtnControl();
	void			InitStaticControl();
	void			InitEditControl();
	void			InitComboControl();

	void			SetDeviceStatus();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlDevice)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlDevice();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlDevice)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnButtonMeasuring();
	afx_msg void OnButton1stShtOpen();
	afx_msg void OnButton1stShtClose();
	afx_msg void OnButton2ndShtOpen();
	afx_msg void OnButton2ndShtClose();
	afx_msg void OnButtonPowermeterOpen();
	afx_msg void OnButtonPowermeterClose();
	afx_msg void OnButtonPowermeterOpen2nd();
	afx_msg void OnButtonPowermeterClose2nd();
	afx_msg void OnButtonHeightSensorUp();
	afx_msg void OnButtonHeightSesnorDown();
	afx_msg void OnButtonHeightSensorUp2nd();
	afx_msg void OnButtonHeightSensorDown2nd();
	afx_msg void OnButtonMotorHoming();
	afx_msg void OnButtonLoaderHoming();
	afx_msg void OnButtonUnloaderHoming();
	afx_msg void OnButtonMaskMoveNum();
	afx_msg void OnButtonMaskMovePos();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLDEVICE_H__11221492_D53E_45B8_ADA1_FC693D41C24E__INCLUDED_)

// PaneManualControlVision.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlVision.h"
#include "..\EasyDrillerDlg.h"
#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "DlgMatroxVisionView.h"
#include "..\device\hdevicefactory.h"
#include "..\device\hvision.h"
#include "..\device\hvisionomi.h"
#include "..\model\deasydrillerini.h"
#include "..\model\DSystemINI.h"
#include "..\model\dproject.h"
#include "..\device\devicemotor.h"
#include "..\Resource.h"
#include "..\model\dprocessini.h"
#include "..\device\HMotor.h"
#include "..\alarmmsg.h"
#include "PaneManualControl.h"
#include "PaneManualControlOneHole.h"
#include "PaneManualControlScannerCalibration.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const UINT UM_CHANGE_VISION_PARAM4	= WM_APP + 21;

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlVision

IMPLEMENT_DYNCREATE(CPaneManualControlVision, CFormView)

CPaneManualControlVision::CPaneManualControlVision()
	: CFormView(CPaneManualControlVision::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlVision)
	m_nPolarity = 2;
	m_nRemote = 0;
	//}}AFX_DATA_INIT
	m_bIsLive		= FALSE;
	m_nModelType	= 1;
	m_bMore			= FALSE;
	//memset( &m_sFidInfo, 0, sizeof(m_sFidInfo) );
	memset( &m_sVisionInfo, 0, sizeof(m_sVisionInfo) );

	for(int i=0; i<4; i++)
	{
		CString strCoaxial, strRing, strIR;
		gDeviceFactory.GetVision()->GetLampValue(i, strCoaxial, strRing, strIR); 
		int nCoaxial, nRing, nIR;
		nCoaxial = atoi(strCoaxial);
		nRing = atoi(strRing);
		nIR = atoi(strIR);
		m_nCoaxial[i] = nCoaxial;
		m_nRing[i] = nRing;
		m_nIR[i] = nIR;
		m_dContrast[i] = 0.2;
		m_dBrightness[i] = 0.2;
//		m_nBlob[i] = 128;
	}

	m_strPath = _T("");
	m_nFidKind = 0;
	m_bSetTrainRegion = FALSE;
	m_nPolarity = 2; 
	m_nTimerID = 0;
	m_nOldMotorMode = -1;
}

CPaneManualControlVision::~CPaneManualControlVision()
{
}

void CPaneManualControlVision::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlVision)
	DDX_Control(pDX, IDC_LIST_RESULT, m_lboxResult);
	DDX_Control(pDX, IDC_STATIC_PIC, m_stcPic);
	DDX_Control(pDX, IDC_EDIT_CONTRAST, m_edtContrast);
	DDX_Control(pDX, IDC_EDIT_BRIGHTNESS, m_edtBrightness);
	DDX_Control(pDX, IDC_EDIT_RING, m_edtRing);
	DDX_Control(pDX, IDC_EDIT_IR, m_edtIR);
	DDX_Control(pDX, IDC_EDIT_COAXIAL, m_edtCoaxial);
	DDX_Control(pDX, IDC_EDIT_ASPECTRATIO, m_edtAspectRatio);
	DDX_Control(pDX, IDC_EDIT_ANGLE, m_edtAngle);
	DDX_Control(pDX, IDC_EDIT_VISION_SIZE, m_edtSize);
	DDX_Control(pDX, IDC_EDIT_ORIENTATION, m_edtOrientation);
	DDX_Control(pDX, IDC_EDIT_SIZE_C, m_edtSizeC);
	DDX_Control(pDX, IDC_EDIT_SIZE_B, m_edtSizeB);
	DDX_Control(pDX, IDC_EDIT_SIZE_A, m_edtSizeA);
	DDX_Control(pDX, IDC_EDIT_JOB_FILE, m_edtPath);
	DDX_Control(pDX, IDC_EDIT_2DBARCODE, m_edt2DBarcodeResult);
	DDX_Control(pDX, IDC_STATIC_INSP_RESULT, m_stcInspResult);
	DDX_Control(pDX, IDC_CHECK_INSP_AREA, m_chkInspArea);
	DDX_Control(pDX, IDC_COMBO_TYPE, m_cmbType);
	DDX_Control(pDX, IDC_COMBO_CAM_NO, m_cmbCamNo);
	DDX_Control(pDX, IDC_BUTTON_TRAIN, m_btnTrain);
	DDX_Control(pDX, IDC_BUTTON_TEST, m_btnTest);
	DDX_Control(pDX, IDC_BUTTON_MORE, m_btnMore);
	DDX_Control(pDX, IDC_BUTTON_LIVE, m_btnLive);
	DDX_Control(pDX, IDC_BUTTON_IMG_SAVE, m_btnImgSave);
	DDX_Radio(pDX, IDC_RADIO_DARK, m_nPolarity);
	DDX_Radio(pDX, IDC_RADIO_REMOTE, m_nRemote);
	DDX_Control(pDX, IDC_BUTTON_SET_RECIPE, m_btnApply);
	DDX_Control(pDX, IDC_BUTTON_JOB_FILE_OPEN2, m_btnJobFile);
	DDX_Control(pDX, IDC_BUTTON_VISION_TRIGGER, m_btnTrigger);
	DDX_Control(pDX, IDC_BUTTON_VISION_TRIGGER_AGC, m_btnTriggerAgc);
	DDX_Control(pDX, IDC_BUTTON_SHOW_DIALOG, m_btnShowDialog);
	DDX_Control(pDX, IDC_BUTTON_OPEN, m_btnOpenProject);
	DDX_Control(pDX, IDC_BUTTON_SAVE, m_btnSaveProject);
	DDX_Control(pDX, IDC_EDIT_VISION_PROJECT_PATH, m_edtProjectPath);
	DDX_Control(pDX, IDC_BUTTON_TRAIN_REGION, m_btnTrainRegion);
	DDX_Control(pDX, IDC_EDIT_THRESHOLD, m_edtThreshold);
	DDX_Control(pDX, IDC_BUTTON_INIT_2DPIXEL, m_btnInit2D);
	DDX_Control(pDX, IDC_BUTTON_GET_2DPIXEL, m_btnGet2D);
	DDX_Control(pDX, IDC_BUTTON_PROOF_2DPIXCEL, m_btnVerify2D);
	DDX_Control(pDX, IDC_BTN_TABLE_LIMIT_MAX, m_btnTableLimitMinSetting);
	DDX_Control(pDX, IDC_BTN_TABLE_LIMIT_MIN, m_btnTableLimitMaxSetting);
	DDX_Control(pDX, IDC_BUTTON_2DBARCODE, m_btn2DBarcode);
	DDX_Control(pDX, IDC_BUTTON_2DBARCODE_UNLOAD, m_btn2DBarcodeUnload);
	DDX_Control(pDX, IDC_BUTTON_IMAGE_TEST, m_btnImageTest);
	DDX_Control(pDX, IDC_BUTTON_IMAGE_LOAD, m_btnImageLoad);
	DDX_Control(pDX, IDC_SLIDER_COAXIAL, m_SliderCoaxial);
	DDX_Control(pDX, IDC_SLIDER_RING, m_SliderRing);
	DDX_Control(pDX, IDC_SLIDER_IR, m_SliderIR);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlVision, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlVision)
	ON_BN_CLICKED(IDC_BUTTON_SET_RECIPE, OnButtonApply)
	ON_BN_CLICKED(IDC_CHECK_INSP_AREA, OnInspectionArea)
	ON_BN_CLICKED(IDC_BUTTON_LIVE, OnButtonLive)
	ON_BN_CLICKED(IDC_BUTTON_IMG_SAVE, OnButtonImgSave)
	ON_CBN_SELCHANGE(IDC_COMBO_TYPE, OnSelchangeComboType)
	ON_BN_CLICKED(IDC_BUTTON_MORE, OnButtonMore)
	ON_WM_DESTROY()
	ON_WM_CTLCOLOR()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_TEST, OnButtonTest)
	ON_BN_CLICKED(IDC_BUTTON_TRAIN, OnButtonTrain)
	ON_CBN_SELCHANGE(IDC_COMBO_CAM_NO, OnSelchangeComboCamNo)
	ON_EN_CHANGE(IDC_EDIT_COAXIAL, OnChangeEditCoaxial)
	ON_EN_CHANGE(IDC_EDIT_CONTRAST, OnChangeEditContrast)
	ON_EN_CHANGE(IDC_EDIT_RING, OnChangeEditRing)
	ON_EN_CHANGE(IDC_EDIT_IR, OnChangeEditIR)
	ON_EN_CHANGE(IDC_EDIT_BRIGHTNESS, OnChangeEditBrightness)
	ON_EN_KILLFOCUS(IDC_EDIT_COAXIAL, OnKillfocusEdit)
	ON_BN_CLICKED(IDC_BUTTON_JOB_FILE_OPEN2, OnButtonJobFileOpen)
	ON_BN_CLICKED(IDC_BUTTON_VISION_TRIGGER, OnButtonTrigger)
	ON_BN_CLICKED(IDC_BUTTON_VISION_TRIGGER_AGC, OnButtonTriggerAgc)
	ON_BN_CLICKED(IDC_BUTTON_SHOW_DIALOG, OnButtonShowDialog)
	ON_MESSAGE(UM_CHANGE_VISION_PARAM4, ChangeVisionParameter)
	ON_BN_CLICKED(IDC_BUTTON_OPEN, OnButtonOpen)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, OnButtonSave)
	ON_BN_CLICKED(IDC_BUTTON_TRAIN_REGION, OnButtonTrainRegion)
	ON_EN_CHANGE(IDC_EDIT_THRESHOLD, OnButtonThreshold)
	ON_BN_CLICKED(IDC_BUTTON_GET_2DPIXEL, OnButtonGet2dpixel)
	ON_BN_CLICKED(IDC_BUTTON_INIT_2DPIXEL, OnButtonInit2dpixel)
	ON_EN_KILLFOCUS(IDC_EDIT_RING, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDIT_IR, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDIT_CONTRAST, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDIT_BRIGHTNESS, OnKillfocusEdit)
	ON_BN_CLICKED(IDC_BUTTON_PROOF_2DPIXCEL, OnButtonProof2dpixcel)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BTN_TABLE_LIMIT_MIN, &CPaneManualControlVision::OnBnClickedBtnTableLimitMin)
	ON_BN_CLICKED(IDC_BTN_TABLE_LIMIT_MAX, &CPaneManualControlVision::OnBnClickedBtnTableLimitMax)
//	ON_EN_KILLFOCUS(IDC_EDIT_BLOB, &CPaneManualControlVision::OnEnKillfocusEditBlob)
	ON_BN_CLICKED(IDC_BUTTON_2DBARCODE, &CPaneManualControlVision::OnBnClickedButton2dbarcode)
	ON_BN_CLICKED(IDC_BUTTON_2DBARCODE_UNLOAD, &CPaneManualControlVision::OnBnClickedButton2dbarcodeUnload)
	ON_BN_CLICKED(IDC_BUTTON_IMAGE_TEST, OnButtonImageTest)
	ON_BN_CLICKED(IDC_BUTTON_IMAGE_LOAD, OnButtonImgaeLoad)
	ON_BN_CLICKED(IDC_RADIO_REMOTE,OnRadioRemote)
	ON_BN_CLICKED(IDC_RADIO_MANUAL,OnRadioManual)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_COAXIAL, &CPaneManualControlVision::OnNMReleasedcaptureSliderCoaxial)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_RING, &CPaneManualControlVision::OnNMReleasedcaptureSliderRing)
	ON_WM_HSCROLL()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlVision diagnostics

#ifdef _DEBUG
void CPaneManualControlVision::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlVision::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlVision message handlers

void CPaneManualControlVision::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBitmap();

	InitStaticControl();
	InitBtnControl();
	InitEditControl();
	InitListBoxControl();
	InitComboControl();
	InitSlideControl();

	if(!gSystemINI.m_sHardWare.nUseLampRS232)
	{
		GetDlgItem(IDC_STATIC_LIGHT)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_COAXIAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_COAXIAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_RING)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_IR)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_RING)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_IR)->EnableWindow(FALSE);
	}
	else
	{
		gDeviceFactory.GetVision()->UseRemoteControl(!m_nRemote);
	}

	GetDlgItem(IDC_BUTTON_SET_RECIPE)->ShowWindow(FALSE);

	m_nTimerID = SetTimer( 394, 250, NULL );

	if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		m_chkInspArea.SetCheck(0);
		ChangeControl(FALSE);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
	{
		ChangeControl(FALSE);
	}
	else
		ChangeControl(TRUE);

#ifdef USE_VISION_PRO
	//gDeviceFactory.GetVision()->ConnectPatternUI(DISPLAYB, GetDlgItem(IDC_VISION_PATTERN));
#endif
	
}

BOOL CPaneManualControlVision::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneManualControlVision::InitBitmap()
{
	m_imgAnnulus.LoadBitmap(IDB_ANNULUS);
	m_imgCircle.LoadBitmap(IDB_CIRCLE);
	m_imgCross.LoadBitmap(IDB_CROSS);
	m_imgDiamond.LoadBitmap(IDB_DIAMOND);
	m_imgDouble.LoadBitmap(IDB_DOUBLERECT);
	m_imgRect.LoadBitmap(IDB_RECT);
	m_imgTriangle.LoadBitmap(IDB_TRIANGLE);
	m_imgUserImage.LoadBitmap(IDB_USER_IMAGE);
}

void CPaneManualControlVision::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	m_fntBtn2.CreatePointFont(120, "Arial Bold");
	m_fntBtn3.CreatePointFont(140, "Arial Bold");

	// Inspection Area
	m_chkInspArea.SetFont( &m_fntBtn );
	m_chkInspArea.SetImageOrg( 10, 3 );
	m_chkInspArea.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkInspArea.EnableBallonToolTip();
	m_chkInspArea.SetToolTipText( _T("Inspection Area") );
	m_chkInspArea.SetBtnCursor(IDC_HAND_1);
	m_chkInspArea.SetCheck(0);
//	m_chkInspArea.ShowWindow(SW_HIDE);

	// More
	m_btnMore.SetFont( &m_fntBtn );
	m_btnMore.SetFlat( FALSE );
	m_btnMore.EnableBallonToolTip();
	m_btnMore.SetToolTipText( _T("More ��") );
	m_btnMore.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMore.SetBtnCursor(IDC_HAND_1);
	m_btnMore.SetWindowText( _T("More ��") );

	// Polarity
	GetDlgItem(IDC_RADIO_DARK)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_LIGHT)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_NONE)->SetFont( &m_fntBtn );
	m_nPolarity = 2;
	GetDlgItem(IDC_RADIO_REMOTE)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_MANUAL)->SetFont( &m_fntBtn );
	m_nRemote = 0;
	// Live
	m_btnLive.SetFont( &m_fntBtn );
	m_btnLive.SetRectAlign( 1 );
	m_btnLive.SetToolTipText( _T("Omi Vision Live Start/Stop") );
	m_btnLive.SetBtnCursor( IDC_HAND_1 );

	// Test
	m_btnTest.SetFont( &m_fntBtn );
	m_btnTest.SetFlat( FALSE );
	m_btnTest.EnableBallonToolTip();
	m_btnTest.SetToolTipText( _T("Test") );
	m_btnTest.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTest.SetBtnCursor(IDC_HAND_1);

	// Train Region
	m_btnTrainRegion.SetFont( &m_fntBtn );
	m_btnTrainRegion.SetFlat( FALSE );
	m_btnTrainRegion.EnableBallonToolTip();
	m_btnTrainRegion.SetToolTipText( _T("Test") );
	m_btnTrainRegion.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTrainRegion.SetBtnCursor(IDC_HAND_1);
	m_btnTrainRegion.ShowWindow(SW_HIDE);

	// Train
	m_btnTrain.SetFont( &m_fntBtn3 );
	m_btnTrain.SetFlat( FALSE );
	m_btnTrain.EnableBallonToolTip();
	m_btnTrain.SetToolTipText( _T("Train") );
	m_btnTrain.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTrain.SetBtnCursor(IDC_HAND_1);
	m_btnTrain.SetColorType(1); // Blue & Bold Line

	// Image Test
	m_btnImageTest.SetFont( &m_fntBtn3 );
	m_btnImageTest.SetFlat( FALSE );
	m_btnImageTest.EnableBallonToolTip();
	m_btnImageTest.SetToolTipText( _T("Train") );
	m_btnImageTest.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnImageTest.SetBtnCursor(IDC_HAND_1);
	m_btnImageTest.SetColorType(1); // Blue & Bold Line

	// Image Load
	m_btnImageLoad.SetFont( &m_fntBtn3 );
	m_btnImageLoad.SetFlat( FALSE );
	m_btnImageLoad.EnableBallonToolTip();
	m_btnImageLoad.SetToolTipText( _T("Train") );
	m_btnImageLoad.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnImageLoad.SetBtnCursor(IDC_HAND_1);
	m_btnImageLoad.SetColorType(1); // Blue & Bold Line
	

	// Image Save
	m_btnImgSave.SetFont( &m_fntBtn );
	m_btnImgSave.SetFlat( FALSE );
	m_btnImgSave.EnableBallonToolTip();
	m_btnImgSave.SetToolTipText( _T("Image Save") );
	m_btnImgSave.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnImgSave.SetBtnCursor(IDC_HAND_1);

	// Apply
	m_btnApply.SetFont( &m_fntBtn );
	m_btnApply.SetFlat( FALSE );
	m_btnApply.EnableBallonToolTip();
	m_btnApply.SetToolTipText( _T("Apply") );
	m_btnApply.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApply.SetBtnCursor(IDC_HAND_1);

	// Trigger
	m_btnTrigger.SetFont( &m_fntBtn );
	m_btnTrigger.SetFlat( FALSE );
	m_btnTrigger.EnableBallonToolTip();
	m_btnTrigger.SetToolTipText( _T("Trigger") );
	m_btnTrigger.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTrigger.SetBtnCursor(IDC_HAND_1);
	
	// Trigger Agc
	m_btnTriggerAgc.SetFont( &m_fntBtn );
	m_btnTriggerAgc.SetFlat( FALSE );
	m_btnTriggerAgc.EnableBallonToolTip();
	m_btnTriggerAgc.SetToolTipText( _T("Trigger Agc") );
	m_btnTriggerAgc.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTriggerAgc.SetBtnCursor(IDC_HAND_1);

	// Show Dialog
	m_btnShowDialog.SetFont( &m_fntBtn );
	m_btnShowDialog.SetFlat( FALSE );
	m_btnShowDialog.EnableBallonToolTip();
	m_btnShowDialog.SetToolTipText( _T("Show Vision Dialog") );
	m_btnShowDialog.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShowDialog.SetBtnCursor(IDC_HAND_1);

	// Open Project
	m_btnOpenProject.SetFont( &m_fntBtn );
	m_btnOpenProject.SetFlat( FALSE );
	m_btnOpenProject.EnableBallonToolTip();
	m_btnOpenProject.SetToolTipText( _T("Open Vision Project") );
	m_btnOpenProject.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOpenProject.SetBtnCursor(IDC_HAND_1);

	// Save Project
	m_btnSaveProject.SetFont( &m_fntBtn );
	m_btnSaveProject.SetFlat( FALSE );
	m_btnSaveProject.EnableBallonToolTip();
	m_btnSaveProject.SetToolTipText( _T("Save Vision Project") );
	m_btnSaveProject.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSaveProject.SetBtnCursor(IDC_HAND_1);
	
	m_btnJobFile.SetFont( &m_fntBtn2 );
	m_btnJobFile.SetFlat( FALSE );
	m_btnJobFile.EnableBallonToolTip();
	m_btnJobFile.SetToolTipText( _T("Job FilePath Selection") );
	m_btnJobFile.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnJobFile.SetBtnCursor(IDC_HAND_1);

	m_btnInit2D.SetFont( &m_fntBtn );
	m_btnInit2D.SetFlat( FALSE );
	m_btnInit2D.EnableBallonToolTip();
	m_btnInit2D.SetToolTipText( _T("Init. 2D-Pixel") );
	m_btnInit2D.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInit2D.SetBtnCursor(IDC_HAND_1);

	m_btnGet2D.SetFont( &m_fntBtn );
	m_btnGet2D.SetFlat( FALSE );
	m_btnGet2D.EnableBallonToolTip();
	m_btnGet2D.SetToolTipText( _T("Get 2D-Pixel") );
	m_btnGet2D.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGet2D.SetBtnCursor(IDC_HAND_1);

	m_btnVerify2D.SetFont( &m_fntBtn );
	m_btnVerify2D.SetFlat( FALSE );
	m_btnVerify2D.EnableBallonToolTip();
	m_btnVerify2D.SetToolTipText( _T("Verify 2D-Pixel") );
	m_btnVerify2D.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVerify2D.SetBtnCursor(IDC_HAND_1);

	m_btnTableLimitMinSetting.SetFont( &m_fntBtn );
	m_btnTableLimitMinSetting.SetFlat( FALSE );
	m_btnTableLimitMinSetting.EnableBallonToolTip();
	m_btnTableLimitMinSetting.SetToolTipText( _T("Table Minimum Position Setting(Laser Fire)") );
	m_btnTableLimitMinSetting.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableLimitMinSetting.SetBtnCursor(IDC_HAND_1);

	m_btnTableLimitMaxSetting.SetFont( &m_fntBtn );
	m_btnTableLimitMaxSetting.SetFlat( FALSE );
	m_btnTableLimitMaxSetting.EnableBallonToolTip();
	m_btnTableLimitMaxSetting.SetToolTipText( _T("Table Maximum Position Setting(Laser Fire)") );
	m_btnTableLimitMaxSetting.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableLimitMaxSetting.SetBtnCursor(IDC_HAND_1);
	
	m_btn2DBarcode.SetFont( &m_fntBtn );
	m_btn2DBarcode.SetFlat( FALSE );
	m_btn2DBarcode.EnableBallonToolTip();
	m_btn2DBarcode.SetToolTipText( _T("2D Barcode Read Data ") );
	m_btn2DBarcode.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btn2DBarcode.SetBtnCursor(IDC_HAND_1);

	m_btn2DBarcodeUnload.SetFont( &m_fntBtn );
	m_btn2DBarcodeUnload.SetFlat( FALSE );
	m_btn2DBarcodeUnload.EnableBallonToolTip();
	m_btn2DBarcodeUnload.SetToolTipText( _T("2D Barcode Read Data ") );
	m_btn2DBarcodeUnload.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btn2DBarcodeUnload.SetBtnCursor(IDC_HAND_1);
}

void CPaneManualControlVision::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// Camera No
	GetDlgItem(IDC_STATIC_CAMERA)->SetFont( &m_fntStatic );

	// Model
	GetDlgItem(IDC_STATIC_MODEL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TYPE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE_A)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE_B)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE_C)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ORIENTATION)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POLARITY)->SetFont( &m_fntStatic );

	// Accept Score
	GetDlgItem(IDC_STATIC_VISION_ACCEPT_SCORE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VISION_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ANGLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ASPECT_RATIO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_THRESHOLD)->SetFont( &m_fntStatic );
	// Light
	GetDlgItem(IDC_STATIC_LIGHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_COAXIAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_RING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_IR)->SetFont( &m_fntStatic );
	// Contrast / Brightness
	GetDlgItem(IDC_STATIC_CONTRASTBRIGHTNESS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CONTRAST)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_BRIGHTNESS)->SetFont( &m_fntStatic );
//	GetDlgItem(IDC_STATIC_BLOB)->SetFont( &m_fntStatic );

	// Inpsection Result
	m_stcInspResult.SetFont( &m_fntStatic );
	m_stcInspResult.SetForeColor( VALUE_FORE_COLOR );
	m_stcInspResult.SetBackColor( VALUE_BACK_COLOR );

	//2d barcode
	GetDlgItem(IDC_STATIC_2DBARCODE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2DBARCODE_RESULT)->SetFont( &m_fntStatic );

#ifndef __KUNSAN_SAMSUNG_LARGE__
	GetDlgItem(IDC_STATIC_2DBARCODE)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_2DBARCODE_RESULT)->ShowWindow(SW_HIDE);
#endif
}

void CPaneManualControlVision::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	// Model
	m_edtSizeA.SetFont( &m_fntEdit );
	m_edtSizeA.SetReceivedFlag( 3 );
	m_edtSizeA.SetWindowText( _T("0.1") );

	m_edtSizeB.SetFont( &m_fntEdit );
	m_edtSizeB.SetReceivedFlag( 3 );
	m_edtSizeB.SetWindowText( _T("0.0") );

	m_edtSizeC.SetFont( &m_fntEdit );
	m_edtSizeC.SetReceivedFlag( 3 );
	m_edtSizeC.SetWindowText( _T("0.0") );

	m_edtOrientation.SetFont( &m_fntEdit );
	m_edtOrientation.SetReceivedFlag( 1 );
	m_edtOrientation.SetWindowText( _T("0") );

	// Accept Score
	m_edtSize.SetFont( &m_fntEdit );
	m_edtSize.SetReceivedFlag( 1 );
	m_edtSize.SetWindowText( _T("20") );

	m_edtAngle.SetFont( &m_fntEdit );
	m_edtAngle.SetReceivedFlag( 1 );
	m_edtAngle.SetWindowText( _T("20") );

	m_edtAspectRatio.SetFont( &m_fntEdit );
	m_edtAspectRatio.SetReceivedFlag( 1 );
	m_edtAspectRatio.SetWindowText( _T("20") );

	// Light
	m_edtCoaxial.SetFont( &m_fntEdit );
	m_edtCoaxial.SetReceivedFlag( 1 );
	m_edtCoaxial.SetWindowText( _T("150") );

	m_edtRing.SetFont( &m_fntEdit );
	m_edtRing.SetReceivedFlag( 1 );
	m_edtRing.SetWindowText( _T("150") );

	m_edtIR.SetFont( &m_fntEdit );
	m_edtIR.SetReceivedFlag( 1 );
	m_edtIR.SetWindowText( _T("150") );
	
	// Contrast / Brightness
	m_edtContrast.SetFont( &m_fntEdit );
	m_edtContrast.SetReceivedFlag( 3 );
	m_edtContrast.SetWindowText( _T("0.5") );

	m_edtBrightness.SetFont( &m_fntEdit );
	m_edtBrightness.SetReceivedFlag( 3 );
	m_edtBrightness.SetWindowText( _T("0.5") );

	m_fntEdit2.CreatePointFont(120, "Arial Bold");

	// Job File Path
	m_edtPath.SetFont( &m_fntEdit2 );
	m_edtPath.SetForeColor( BLACK_COLOR );
	m_edtPath.SetBackColor( WHITE_COLOR );
	m_edtPath.SetWindowText( (LPCTSTR)m_strPath );

	m_edtProjectPath.SetFont( &m_fntEdit2 );
	m_edtProjectPath.SetForeColor( BLACK_COLOR );
	m_edtProjectPath.SetBackColor( WHITE_COLOR );
	m_edtProjectPath.SetWindowText( (LPCTSTR)m_strPath );

	m_edtThreshold.SetFont( &m_fntEdit );
	m_edtThreshold.SetReceivedFlag( 3 );
	m_edtThreshold.SetWindowText( _T("0.5") );

	//2d Barcode
	m_edt2DBarcodeResult.SetFont( &m_fntEdit2 );
	m_edt2DBarcodeResult.SetForeColor( BLACK_COLOR );
	m_edt2DBarcodeResult.SetBackColor( WHITE_COLOR );
	m_edt2DBarcodeResult.SetWindowText( _T(""));
#ifndef __KUNSAN_SAMSUNG_LARGE__
	m_edt2DBarcodeResult.ShowWindow(SW_HIDE);
#endif
}

void CPaneManualControlVision::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(130, "Arial Bold");

	m_cmbCamNo.SetFont( &m_fntCombo );
	
	switch( gEasyDrillerINI.m_clsHwOption.GetCameraNum() )
	{
	case 1 :
		m_cmbCamNo.ResetContent();
		m_cmbCamNo.AddString("Vision");
		m_cmbCamNo.EnableWindow(FALSE);
		break;
	case 2 :
		m_cmbCamNo.ResetContent();
		m_cmbCamNo.AddString("High Vision");
		m_cmbCamNo.AddString("Low Vision");
		break;
	}

	m_cmbCamNo.SetCurSel( 1 );
#ifdef __USE_ONLY_LOW_CAM__
	m_cmbCamNo.ResetContent();
	m_cmbCamNo.AddString("1'st Vision");
	m_cmbCamNo.AddString("2'nd Vision");
	m_cmbCamNo.SetCurSel( 0 );
#endif
	SetValue( 0 );

	m_cmbType.SetFont( &m_fntCombo );
	m_cmbType.SetCurSel( m_nModelType );
	SelectPic( m_nModelType );
}

void CPaneManualControlVision::InitListBoxControl()
{
	// Set ListBox Font
	m_fntListBox.CreatePointFont(130, "Arial Bold");

	m_lboxResult.SetFont( &m_fntListBox );
}

void CPaneManualControlVision::OnButtonLive() 
{
	m_bIsLive = !m_bIsLive;

	m_btnLive.SetClick( m_bIsLive );
	
	if( m_bIsLive )
	{
		m_btnLive.SetWindowText( _T("Stop\nLive") );
		m_btnTest.EnableWindow(FALSE);
		m_btnTrain.EnableWindow(FALSE);
		m_btnTrigger.EnableWindow(FALSE);
		m_btnTriggerAgc.EnableWindow(FALSE);
		m_btnImgSave.EnableWindow(FALSE);
		m_cmbCamNo.EnableWindow(FALSE);
		m_btnShowDialog.EnableWindow(FALSE);
	}
	else
	{
		m_btnLive.SetWindowText( _T("Start\nLive") );
		m_btnTest.EnableWindow(TRUE);
		m_btnTrain.EnableWindow(TRUE);
		m_btnTrigger.EnableWindow(TRUE);
		m_btnTriggerAgc.EnableWindow(TRUE);
		m_btnImgSave.EnableWindow(TRUE);
		m_cmbCamNo.EnableWindow(TRUE);
		m_btnShowDialog.EnableWindow(TRUE);
	}

	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnLive(nCamNo, m_bIsLive);
}

void CPaneManualControlVision::OnButtonImgSave() 
{
	TCHAR szFilter[] = _T("Image File(*.bmp)|*.bmp||");
	CFileDialog filedlg(FALSE, _T("bmp"), _T(""), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);
		
	filedlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetImageDir();
		
	if (IDOK != filedlg.DoModal())
		return;

	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->SaveImg( nCamNo, filedlg.GetPathName() );
}

void CPaneManualControlVision::OnButtonApply()
{
	UpdateData(TRUE);

	if(gDProject.m_bSkivingMode)
	{
		if(IDNO == ErrMessage(_T("This is just for the reference mechanical fiducial.\r\nDo you want to continue?"), MB_ICONQUESTION|MB_YESNO))
			return;
	}
	CString str;
	double dTempVal;
	int	nTempVal;
	
	// �Է°� ��������
	
	m_edtSizeA.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeA.IsWindowEnabled()) 
	{
		m_edtSizeA.SetFocus();
		ErrMessage(_T("0 < SizeA <= 5(mm)"));
		return;
	}
	
	m_edtSizeB.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeB.IsWindowEnabled()) 
	{
		m_edtSizeB.SetFocus();
		ErrMessage(_T("0 < SizeB <= 5(mm)"));
		return;
	}
	
	m_edtSizeC.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeC.IsWindowEnabled()) 
	{
		m_edtSizeC.SetFocus();
		ErrMessage(_T("0 < SizeC <= 5(mm)"));
		return;
	}
	
	m_edtSize.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_PERCENT || nTempVal < 0) 
	{
		m_edtSize.SetFocus();
		ErrMessage(_T("0 <= Size <= 100(%)"));
		return;
	}
	
	m_edtAngle.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_ANGLE || nTempVal < 0) 
	{
		m_edtAngle.SetFocus();
		ErrMessage(_T("0 <= Angle <= 360"));
		return;
	}
	

	m_edtAspectRatio.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_PERCENT || nTempVal < 0) 
	{
		m_edtAspectRatio.SetFocus();
		ErrMessage(_T("0 <= Aspect Ratio <= 100(%)"));
		return;
	}
	
	m_edtThreshold.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal < 0 || nTempVal > 255) 
	{
		m_edtAspectRatio.SetFocus();
		ErrMessage(_T("0 <= Threshold <= 255"));
		return;
	}
	int nCount = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);

	for(int p = 0; p <nCount; p++)
	{
		LPFIDDATA pFidData = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, p);

		if(pFidData == NULL)
		{
			ErrMessage(_T("There is no fiducial data"));
			return;
		}


		// �Է°� �����Ϸ�

		m_edtPath.GetWindowText(str);
		lstrcpy(gDProject.m_szJobFilePath, (LPCSTR)str);
		
		int nCam = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
		if(nCam == HIGH_1ST_CAM)
			nCam = LOW_1ST_CAM;
		else
			nCam = LOW_2ND_CAM;
#endif
		if(nCam == HIGH_1ST_CAM || nCam == HIGH_2ND_CAM)
			nCam = HIGH_CAM;
		else
			nCam = LOW_CAM;

		pFidData->nCam = nCam;
			
		pFidData->sVisInfo.nModelType = (long)m_nModelType;
		
		m_edtSizeA.GetWindowText(str);
		dTempVal = atof(str);
		pFidData->sVisInfo.dSizeA = (float)dTempVal;
		
		m_edtSizeB.GetWindowText(str);
		dTempVal = atof(str);
		pFidData->sVisInfo.dSizeB = (float)dTempVal;
		
		m_edtSizeC.GetWindowText(str);
		dTempVal = atof(str);
		pFidData->sVisInfo.dSizeC = (float)dTempVal;
		
		pFidData->sVisInfo.nPolarity = (long)m_nPolarity;
		
		m_edtSize.GetWindowText(str);
		nTempVal = atoi(str);
		pFidData->sVisInfo.dScoreSize = nTempVal;
		
		m_edtAngle.GetWindowText(str);
		nTempVal = atoi(str);
		pFidData->sVisInfo.dScoreAngle = nTempVal;
		
		m_edtAspectRatio.GetWindowText(str);
		nTempVal = atoi(str);
		pFidData->sVisInfo.dAspectRatio = nTempVal;
		
		m_edtThreshold.GetWindowText(str);
		nTempVal = atoi(str);
		pFidData->sVisInfo.nThreshold = nTempVal;

		for(int i=0; i<4; i++)
		{
			pFidData->sVisInfo.nCoaxial[i] = m_nCoaxial[i];
			pFidData->sVisInfo.nRing[i] = m_nRing[i];
			pFidData->sVisInfo.nIR[i] = m_nIR[i];
			pFidData->sVisInfo.dBrightness[i] = m_dBrightness[i];
			pFidData->sVisInfo.dContrast[i] = m_dContrast[i];
//			pFidData->sVisInfo.nBlob[i] = m_nBlob[i];
		}
	}

}

void CPaneManualControlVision::SelectPic(int nType)
{
	if(nType >= MODEL_PATTERN)
	{
		m_stcPic.ShowWindow(SW_HIDE);
#ifdef USE_VISION_PRO
	//	BOOL bRes = GetDlgItem(IDC_VISION_PATTERN)->ShowWindow(TRUE);
#endif
	}
	else
	{
#ifdef USE_VISION_PRO
		//GetDlgItem(IDC_VISION_PATTERN)->ShowWindow(SW_HIDE);
#endif
		m_stcPic.ShowWindow(TRUE);

	}

	switch( nType )
	{
	case 0 : // Annulus
		m_stcPic.SetBitmap( m_imgAnnulus );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( FALSE );
		break;
	case 1 : // Circle
		m_stcPic.SetBitmap( m_imgCircle );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( FALSE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( FALSE );
		break;
	case 2 : // Cross
		m_stcPic.SetBitmap( m_imgCross );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( TRUE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	case 3 : // Diamond
		m_stcPic.SetBitmap( m_imgDiamond );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	case 4 : // Double Rectangle
		m_stcPic.SetBitmap( m_imgDouble );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	case 5 : // Rectangle
		m_stcPic.SetBitmap( m_imgRect );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	case 6 : // Triangle
		m_stcPic.SetBitmap( m_imgTriangle );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	default : // User Image
		m_edtSizeA.EnableWindow( FALSE );
		m_edtSizeB.EnableWindow( FALSE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	}
}

void CPaneManualControlVision::OnSelchangeComboType() 
{
	m_nModelType = m_cmbType.GetCurSel();

	SelectPic( m_nModelType );

	//�߰� ���� 
	//1. ������ Index ���� 
	//2. ���� ������ ��� Train���θ� ������  
	//2-1. Train�Ǿ� ���� ��� Train Image�� Diplay
	//2-2. Not Train�� ��� ���� ������ �����ϵ��� Rectangle Diplay
	
	HVision *pVision = gDeviceFactory.GetVision();
	pVision->SetSelIndex(m_nModelType);
	int nCam = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCam == HIGH_1ST_CAM)
		nCam = LOW_1ST_CAM;
	else
		nCam = LOW_2ND_CAM;
#endif
	pVision->ClearInteractiveGraphics(nCam);	
//	ChangeDisplay(m_nModelType, nCam);
	
	m_btnTrainRegion.ShowWindow(SW_HIDE);
	


}

void CPaneManualControlVision::OnButtonMore() 
{
	CRect rect;
	
	m_lboxResult.GetWindowRect( rect );
	
	if( FALSE == m_bMore )
	{
		m_lboxResult.SetWindowPos( NULL, 0, 0, rect.Width(), rect.Height() + EXTEND_DISPLAY, 
			SWP_NOMOVE|SWP_NOZORDER );
		m_btnMore.SetWindowText( _T("Less ��") );
		
		GetDlgItem(IDC_STATIC_MODEL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_TYPE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SIZE_A)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SIZE_B)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SIZE_C)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_ORIENTATION)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_PIC)->ShowWindow(SW_HIDE);
		
		m_cmbType.ShowWindow(SW_HIDE);
		m_edtSizeA.ShowWindow(SW_HIDE);
		m_edtSizeB.ShowWindow(SW_HIDE);
		m_edtSizeC.ShowWindow(SW_HIDE);
		m_edtOrientation.ShowWindow(SW_HIDE);
		
		GetDlgItem(IDC_STATIC_POLARITY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_RADIO_DARK)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_RADIO_LIGHT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_RADIO_NONE)->ShowWindow(SW_HIDE);
	}
	else
	{
		m_lboxResult.SetWindowPos( NULL, 0, 0, rect.Width(), rect.Height() - EXTEND_DISPLAY, 
								   SWP_NOMOVE|SWP_NOZORDER );
		m_btnMore.SetWindowText( _T("More ��") );

		GetDlgItem(IDC_STATIC_MODEL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_TYPE)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_SIZE_A)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_SIZE_B)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_SIZE_C)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_STATIC_ORIENTATION)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_PIC)->ShowWindow(SW_SHOW);

		m_cmbType.ShowWindow(SW_SHOW);
		m_edtSizeA.ShowWindow(SW_SHOW);
		m_edtSizeB.ShowWindow(SW_SHOW);
		m_edtSizeC.ShowWindow(SW_SHOW);
//		m_edtOrientation.ShowWindow(SW_SHOW);

		GetDlgItem(IDC_STATIC_POLARITY)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_RADIO_DARK)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_RADIO_LIGHT)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_RADIO_NONE)->ShowWindow(SW_SHOW);
	}

	m_bMore = !m_bMore;
}

void CPaneManualControlVision::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntBtn2.DeleteObject();
	m_fntBtn3.DeleteObject();
	m_fntStatic.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntEdit2.DeleteObject();
	m_fntCombo.DeleteObject();
	m_fntListBox.DeleteObject();

	CFormView::OnDestroy();
}

HBRUSH CPaneManualControlVision::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( CTLCOLOR_STATIC == nCtlColor )
	{
		if( GetDlgItem(IDC_STATIC_MODEL)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_POLARITY)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_VISION_ACCEPT_SCORE)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_LIGHT)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_CONTRASTBRIGHTNESS)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_2DBARCODE)->GetSafeHwnd() == pWnd->m_hWnd)
			pDC->SetTextColor( RGB(0, 0, 255) );
	}
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneManualControlVision::ConnectView()
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
//		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->SetPanelNo(TEACHING_VISION_VIEW);

		CRect rtPos;
		GetDlgItem(IDC_STATIC_TEACHING_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_SHOW );
//		GetDlgItem(IDC_STATIC_TEACHING_VIEW)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetPanelNo(TEACHING_VISION_VIEW);

		CRect rtPos;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow( SW_SHOW );
		GetDlgItem(IDC_STATIC_TEACHING_VIEW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_SHOW);
		
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->SetPanelNo(TEACHING_VISION_VIEW);

		CRect rtPos;
		GetDlgItem(IDC_STATIC_TEACHING_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_SHOW );
//		GetDlgItem(IDC_STATIC_TEACHING_VIEW)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}
//	GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
//	GetDlgItem(IDC_STATIC_TEACHING_VIEW)->ShowWindow(SW_SHOW);
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	OnCamChange( nCamNo );
}

void CPaneManualControlVision::OnCamChange(int nCamNo)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnCamChange( nCamNo );
}

void CPaneManualControlVision::OnMoveVisionView()
{
	CRect rtPos;

	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		GetDlgItem(IDC_STATIC_TEACHING_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		GetDlgItem(IDC_STATIC_TEACHING_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
	}
}

void CPaneManualControlVision::OnTimer(UINT nIDEvent) 
{

#ifdef __PUSAN_LDD__
	if( 1 == m_bIsLive )
	{
		int nCamNo = m_cmbCamNo.GetCurSel();
		HVision* pVision = gDeviceFactory.GetVision();
		pVision->OnCamChange( nCamNo );
		pVision->OnAcquire(nCamNo);
	}
#endif

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(m_nOldMotorMode != pMotor->GetCurrentMode())
	{
		if(pMotor->GetCurrentMode() == MODE_MPG)
		{
			if(!m_bIsLive)
			{
				OnButtonLive();
			}
		}
		else
		{
			if(m_bIsLive)
			{
				OnButtonLive();
			}
		}
		m_nOldMotorMode = pMotor->GetCurrentMode();
	}

	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlVision::OnButtonTrigger()
{
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	CString strMsg;
	
	HVision* pVision = gDeviceFactory.GetVision();
	if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
		pVision->OnFindFiducial( nCamNo, 4, strMsg );
	else
		pVision->OnFindFiducial( nCamNo, 6, strMsg );

	m_stcInspResult.SetWindowText( strMsg );
	
	CString strPos;
	double dPosX, dPosY;
	CString strData;
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, TRUE);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, TRUE);
	strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
	strData.Format(_T("%s %s"), strPos, strMsg);
	
	m_lboxResult.InsertString( 0, (LPCTSTR)strData );
	m_lboxResult.SetCurSel( 0 );
}

void CPaneManualControlVision::OnButtonTriggerAgc()
{
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	CString strMsg;
	
	HVision* pVision = gDeviceFactory.GetVision();
	if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
		pVision->OnFindHole( nCamNo, 4, strMsg );
	else
		pVision->OnFindHole( nCamNo, 6, strMsg );

	m_stcInspResult.SetWindowText( strMsg );
	
	CString strPos;
	double dPosX, dPosY;
	CString strData;
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, TRUE);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, TRUE);
	strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
	strData.Format(_T("%s %s"), strPos, strMsg);
	
	m_lboxResult.InsertString( 0, (LPCTSTR)strData );
	m_lboxResult.SetCurSel( 0 );	
}

void CPaneManualControlVision::OnButtonShowDialog()
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->ShowVisionDialog();
}

void CPaneManualControlVision::OnButtonTest() 
{
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	int nPatternNo = m_cmbType.GetCurSel();
	CString strMsg;

	HVision* pVision = gDeviceFactory.GetVision();
	if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
		pVision->OnFindFiducial( nCamNo, 4, strMsg );
	else
		//	pVision->OnFindFiducial( nCamNo, 6, strMsg ); 
		pVision->OnFindFiducial( nCamNo, nPatternNo, strMsg);
	
	m_stcInspResult.SetWindowText( strMsg );
	
	CString strPos;
	double dPosX, dPosY;
	BOOL b1st = TRUE;
	
	CString strData;
	
	switch( nCamNo )
	{
	case HIGH_1ST_CAM :
	case LOW_1ST_CAM :
		b1st = TRUE;
		gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
		gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);
		strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
		strData.Format(_T("1st %s %s"), strPos, strMsg);
		break;
	case HIGH_2ND_CAM :
	case LOW_2ND_CAM :
		if(gSystemINI.m_sSystemDevice.nCalGridMode)
			b1st = TRUE;
		else
			b1st = FALSE;
		gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
		gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);
		strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
		strData.Format(_T("2nd %s %s"), strPos, strMsg);
		break;
	}
	
	m_lboxResult.InsertString( 0, (LPCTSTR)strData );
	m_lboxResult.SetCurSel( 0 );
}

void CPaneManualControlVision::OnButtonTrain() 
{
	UpdateData(TRUE);
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	CString strData;

	// Model Type
	m_sVisionInfo.nModelType = m_cmbType.GetCurSel();

	// Size A, B, C, Orientation
	if(m_sVisionInfo.nModelType < MODEL_PATTERN)
	{
		m_edtSizeA.GetWindowText( strData );
		m_sVisionInfo.dSizeA	= atof( (LPSTR)(LPCTSTR)strData );

		m_edtSizeB.GetWindowText( strData );
		m_sVisionInfo.dSizeB	= atof( (LPSTR)(LPCTSTR)strData );

		m_edtSizeC.GetWindowText( strData );
		m_sVisionInfo.dSizeC	= atof( (LPSTR)(LPCTSTR)strData );
	}
	else
	{
		m_sVisionInfo.dSizeA = 0;
		m_sVisionInfo.dSizeB = 0;
		m_sVisionInfo.dSizeC = 0;
	}
	//	m_edtOrientation.GetWindowText( strData );
	//	m_sVisionInfo.dOrientation	= atof( (LPSTR)(LPCTSTR)strData );

	// Polarity
	if( 2 == m_nPolarity )
		m_sVisionInfo.nPolarity = 3;
	else
		m_sVisionInfo.nPolarity = m_nPolarity;

	if(!ValidateValue())
		return;

	// Contast & Brightness
	m_edtContrast.GetWindowText( strData );
	m_dContrast[nCamNo] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtBrightness.GetWindowText( strData );
	m_dBrightness[nCamNo]	= atof( (LPSTR)(LPCTSTR)strData );

	// Accept Score
	m_edtSize.GetWindowText( strData );
	m_sVisionInfo.dScoreSize	= atof( (LPSTR)(LPCTSTR)strData );

	m_edtAngle.GetWindowText( strData );
	m_sVisionInfo.dScoreAngle	= atof( (LPSTR)(LPCTSTR)strData );

	m_edtAspectRatio.GetWindowText( strData );
	m_sVisionInfo.dAspectRatio	= atof( (LPSTR)(LPCTSTR)strData );

	m_edtThreshold.GetWindowText( strData );
	m_sVisionInfo.nThreshold = atoi ((LPSTR)(LPCTSTR)strData);

	// Light
	m_edtCoaxial.GetWindowText( strData );
	m_nCoaxial[nCamNo]		= atoi( (LPSTR)(LPCTSTR)strData );

	m_edtRing.GetWindowText( strData );
	m_nRing[nCamNo]			= atoi( (LPSTR)(LPCTSTR)strData );

	m_edtIR.GetWindowText( strData );
	m_nIR[nCamNo]			= atoi( (LPSTR)(LPCTSTR)strData );
	

	for(int i=0; i<4; i++)
	{
		m_sVisionInfo.nCoaxial[i] = m_nCoaxial[i];
		m_sVisionInfo.nRing[i] = m_nRing[i];
		m_sVisionInfo.nIR[i] = m_nIR[i];
		m_sVisionInfo.dContrast[i] = m_dContrast[i];
		m_sVisionInfo.dBrightness[i] = m_dBrightness[i];
	}

	int nPatternNo = m_sVisionInfo.nModelType; 

	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnLightAll(nCamNo, m_nCoaxial[nCamNo], m_nRing[nCamNo], m_nIR[nCamNo]);
	pVision->OnApplyVisionParam(nPatternNo ,nCamNo, m_sVisionInfo );


	OnButtonTest();
	
}

void CPaneManualControlVision::OnButtonImageTest() 
{
	UpdateData(TRUE);
	int nCamNo = m_cmbCamNo.GetCurSel();
	CString strData;

	// Model Type
	m_sVisionInfo.nModelType = m_cmbType.GetCurSel();

	// Size A, B, C, Orientation
	if(m_sVisionInfo.nModelType < MODEL_PATTERN)
	{
		m_edtSizeA.GetWindowText( strData );
		m_sVisionInfo.dSizeA	= atof( (LPSTR)(LPCTSTR)strData );

		m_edtSizeB.GetWindowText( strData );
		m_sVisionInfo.dSizeB	= atof( (LPSTR)(LPCTSTR)strData );

		m_edtSizeC.GetWindowText( strData );
		m_sVisionInfo.dSizeC	= atof( (LPSTR)(LPCTSTR)strData );
	}
	else
	{
		m_sVisionInfo.dSizeA = 0;
		m_sVisionInfo.dSizeB = 0;
		m_sVisionInfo.dSizeC = 0;
	}
	//	m_edtOrientation.GetWindowText( strData );
	//	m_sVisionInfo.dOrientation	= atof( (LPSTR)(LPCTSTR)strData );

	// Polarity
	if( 2 == m_nPolarity )
		m_sVisionInfo.nPolarity = 3;
	else
		m_sVisionInfo.nPolarity = m_nPolarity;

	if(!ValidateValue())
		return;

	// Contast & Brightness
	m_edtContrast.GetWindowText( strData );
	m_dContrast[nCamNo] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtBrightness.GetWindowText( strData );
	m_dBrightness[nCamNo]	= atof( (LPSTR)(LPCTSTR)strData );

	// Accept Score
	m_edtSize.GetWindowText( strData );
	m_sVisionInfo.dScoreSize	= atof( (LPSTR)(LPCTSTR)strData );

	m_edtAngle.GetWindowText( strData );
	m_sVisionInfo.dScoreAngle	= atof( (LPSTR)(LPCTSTR)strData );

	m_edtAspectRatio.GetWindowText( strData );
	m_sVisionInfo.dAspectRatio	= atof( (LPSTR)(LPCTSTR)strData );

	m_edtThreshold.GetWindowText( strData );
	m_sVisionInfo.nThreshold = atoi ((LPSTR)(LPCTSTR)strData);

	// Light
	m_edtCoaxial.GetWindowText( strData );
	m_nCoaxial[nCamNo]		= atoi( (LPSTR)(LPCTSTR)strData );

	m_edtRing.GetWindowText( strData );
	m_nRing[nCamNo]			= atoi( (LPSTR)(LPCTSTR)strData );

	m_edtIR.GetWindowText( strData );
	m_nIR[nCamNo]			= atoi( (LPSTR)(LPCTSTR)strData );

	for(int i=0; i<4; i++)
	{
		m_sVisionInfo.nCoaxial[i] = m_nCoaxial[i];
		m_sVisionInfo.nRing[i] = m_nRing[i];
		m_sVisionInfo.nIR[i] = m_nIR[i];

		m_sVisionInfo.dContrast[i] = m_dContrast[i];
		m_sVisionInfo.dBrightness[i] = m_dBrightness[i];
	}

	int nPatternNo = m_sVisionInfo.nModelType; 

	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnLightAll(nCamNo, m_nCoaxial[nCamNo], m_nRing[nCamNo], m_nIR[nCamNo]);
//	pVision->OnApplyVisionParam(nPatternNo ,nCamNo, m_sVisionInfo );

	CString strMsg;
	CString strBarcodeResult;
	//pVision->On2DRead( nCamNo, MODEL_CIRCLE, strMsg, strBarcodeResult );
	m_stcInspResult.SetWindowText(strMsg);
	CString strPos;
	double dPosX, dPosY;
	BOOL b1st = TRUE;

	switch( nCamNo )
	{
	case HIGH_1ST_CAM :
	case LOW_1ST_CAM :
		b1st = TRUE;
		gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
		gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);
		strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
		strData.Format(_T("1st %s %s"), strPos, strMsg);
		break;
	case HIGH_2ND_CAM :
	case LOW_2ND_CAM :
		b1st = FALSE;
		gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
		gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);
		strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
		strData.Format(_T("2nd %s %s"), strPos, strMsg);
		break;
	}

	if(m_lboxResult.GetCount() > 400) 
		m_lboxResult.DeleteString(0);

	m_lboxResult.AddString((LPCTSTR)strData);
	m_lboxResult.SetCurSel(m_lboxResult.GetCount() - 1);

	
}

void CPaneManualControlVision::OnButtonImgaeLoad() 
{
	char szFilter[] = "Image File (*.*)|*.*||";
	CFileDialog pFileOpen(TRUE, "All Files", NULL, OFN_FILEMUSTEXIST | OFN_HIDEREADONLY | OFN_PATHMUSTEXIST, szFilter, NULL);
	if (pFileOpen.DoModal() == IDOK)
	{
		// Get file name
		CString sName(pFileOpen.GetPathName());
		gVPro.LoadImage(sName, true, m_cmbCamNo.GetCurSel());
	}
}

void CPaneManualControlVision::OnSelchangeComboCamNo() 
{
	int nCamNo = m_cmbCamNo.GetCurSel();
	HVision* pVision = gDeviceFactory.GetVision();
	
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif

	pVision->OnCamChange( nCamNo );

	SetValue( nCamNo );
}

void CPaneManualControlVision::SetValue(int nNumber)
{
	CString strData;

	strData.Format(_T("%d"), m_nCoaxial[nNumber]);
	m_edtCoaxial.SetWindowText(strData);
	m_SliderCoaxial.SetPos(m_nCoaxial[nNumber]);

	strData.Format(_T("%d"), m_nRing[nNumber]);
	m_edtRing.SetWindowText(strData);
	m_SliderRing.SetPos(m_nRing[nNumber]);

	strData.Format(_T("%d"), m_nIR[nNumber]);
	m_edtIR.SetWindowText(strData);
	m_SliderIR.SetPos(m_nIR[nNumber]);

	strData.Format(_T("%.1f"), m_dContrast[nNumber]);
	m_edtContrast.SetWindowText(strData);

	strData.Format(_T("%.1f"), m_dBrightness[nNumber]);
	m_edtBrightness.SetWindowText(strData);	
	
	UpdateData(FALSE);
}

void CPaneManualControlVision::OnChangeEditCoaxial() 
{
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	HVision* pVision = gDeviceFactory.GetVision();

	CString str;
	
	m_edtRing.GetWindowText(str);
	int nRing = atoi(str);
	m_edtCoaxial.GetWindowText(str);
	int nCoaxial = atoi(str);
	m_SliderCoaxial.SetPos(nCoaxial);
	m_edtIR.GetWindowText(str);
	int nIR = atoi(str);
//	m_SliderIR.SetPos(nIR);
	pVision->OnLightAll(nCamNo, nCoaxial, nRing, nIR);
}

void CPaneManualControlVision::OnChangeEditContrast() 
{
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	HVision* pVision = gDeviceFactory.GetVision();

	CString strData;

	m_edtContrast.GetWindowText( strData );
	double dContrast = atof( (LPSTR)(LPCTSTR)strData );
	pVision->OnContrast( nCamNo, dContrast );
	pVision->OnAcquire(nCamNo);
}

void CPaneManualControlVision::OnChangeEditIR() 
{
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	HVision* pVision = gDeviceFactory.GetVision();

	CString str;

	m_edtRing.GetWindowText(str);
	int nRing = atoi(str);
	m_edtCoaxial.GetWindowText(str);
	int nCoaxial = atoi(str);
	m_edtIR.GetWindowText(str);
	int nIR = atoi(str);
	m_SliderIR.SetPos(nIR);
	pVision->OnLightAll(nCamNo, nCoaxial, nRing, nIR);
}

void CPaneManualControlVision::OnChangeEditRing() 
{
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	HVision* pVision = gDeviceFactory.GetVision();

	CString str;
	
	m_edtRing.GetWindowText(str);
	int nRing = atoi(str);
	m_edtCoaxial.GetWindowText(str);
	int nCoaxial = atoi(str);
	m_edtIR.GetWindowText(str);
	int nIR = atoi(str);
	m_SliderRing.SetPos(nRing);
	
	pVision->OnLightAll(nCamNo, nCoaxial, nRing, nIR);
}

void CPaneManualControlVision::OnChangeEditBrightness() 
{
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	HVision* pVision = gDeviceFactory.GetVision();

	CString strData;

	m_edtBrightness.GetWindowText( strData );
	double dBrightness = atof( (LPSTR)(LPCTSTR)strData );
	pVision->OnBrightness( nCamNo, dBrightness );
	pVision->OnAcquire(nCamNo);
}

void CPaneManualControlVision::ResetLive()
{
	if( FALSE == m_bIsLive )
		return;

	m_bIsLive = !m_bIsLive;
	m_btnLive.SetClick(m_bIsLive);
	m_btnLive.SetWindowText( _T("Start\nLive") );
	m_btnTest.EnableWindow(TRUE);
	m_btnTrain.EnableWindow(TRUE);
	m_btnImgSave.EnableWindow(TRUE);
	m_cmbCamNo.EnableWindow(TRUE);

	m_btnTrigger.EnableWindow(TRUE);
	m_btnTriggerAgc.EnableWindow(TRUE);
	m_btnShowDialog.EnableWindow(TRUE);

	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnLive(nCamNo, m_bIsLive);
}

BOOL CPaneManualControlVision::ValidateValue()
{
	CString strData;
	double dValue;
	int nValue;

	// Contast & Brightness
	m_edtContrast.GetWindowText( strData );
	dValue = atof( (LPSTR)(LPCTSTR)strData );
	if(dValue < 0.0 || dValue > 1.0)
	{
		ErrMessage(_T("0 <= Contrast <= 1.0"));
		m_edtContrast.SetFocus();
		return FALSE;
	}
	
	m_edtBrightness.GetWindowText( strData );
	dValue = atof( (LPSTR)(LPCTSTR)strData );
	if(dValue < 0.0 || dValue > 1.0)
	{
		ErrMessage(_T("0 <= Brightness <= 1.0"));
		m_edtBrightness.SetFocus();
		return FALSE;
	}
	
	// Accept Score
	m_edtSize.GetWindowText( strData );
	dValue = atof( (LPSTR)(LPCTSTR)strData );
	if(dValue < 0.0 || dValue > 100.0)
	{
		ErrMessage(_T("0 <= Size <= 100.0"));
		m_edtSize.SetFocus();
		return FALSE;
	}
	
	m_edtAngle.GetWindowText( strData );
	dValue = atof( (LPSTR)(LPCTSTR)strData );
	if(dValue < 0.0 || dValue > 360.0)
	{
		ErrMessage(_T("0 <= Angle <= 360.0"));
		m_edtAngle.SetFocus();
		return FALSE;
	}
	
	m_edtAspectRatio.GetWindowText( strData );
	dValue = atof( (LPSTR)(LPCTSTR)strData );
	if(dValue < 0.0 || dValue > 100.0)
	{
		ErrMessage(_T("0 <= Aspect Ratio <= 100.0"));
		m_edtAspectRatio.SetFocus();
		return FALSE;
	}
	
	// Light
	m_edtCoaxial.GetWindowText( strData );
	nValue = atoi( (LPSTR)(LPCTSTR)strData );
	if(nValue < 0 || nValue > 255)
	{
		ErrMessage(_T("0 <= Coaxial <= 255"));
		m_edtCoaxial.SetFocus();
		return FALSE;
	}
	
	m_edtRing.GetWindowText( strData );
	nValue = atoi( (LPSTR)(LPCTSTR)strData );
	if(nValue < 0 || nValue > 255)
	{
		ErrMessage(_T("0 <= Ring <= 255"));
		m_edtRing.SetFocus();
		return FALSE;
	}

	m_edtIR.GetWindowText( strData );
	nValue = atoi( (LPSTR)(LPCTSTR)strData );
	if(nValue < 0 || nValue > 255)
	{
		ErrMessage(_T("0 <= IR <= 255"));
		m_edtIR.SetFocus();
		return FALSE;
	}

	return TRUE;
}

void CPaneManualControlVision::OnKillfocusEdit()
{
	UpdateData(TRUE);
	
	CString str;
	int nTempVal;
	double dTempVal;
	int nCam = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCam == HIGH_1ST_CAM)
		nCam = LOW_1ST_CAM;
	else
		nCam = LOW_2ND_CAM;
#endif
	m_edtCoaxial.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > 255 || nTempVal < 0) 
		return;
	else
		m_nCoaxial[nCam] = nTempVal;
	
	m_edtRing.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > 255 || nTempVal < 0) 
		return;
	else
		m_nRing[nCam] = nTempVal;

	m_edtIR.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > 255 || nTempVal < 0) 
		return;
	else
		m_nIR[nCam] = nTempVal;
	
	m_edtBrightness.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > 1.0 || dTempVal < 0.0) 
		return;
	else
		m_dBrightness[nCam] = dTempVal;
	
	m_edtContrast.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > 1.0 || dTempVal < 0.0) 
		return;
	else
		m_dContrast[nCam] = dTempVal;
}

void CPaneManualControlVision::SetVisionInfo()
{
	OnButtonTrain();
}

void CPaneManualControlVision::OnInspectionArea()
{
	UpdateData(TRUE);

	BOOL bCheck = m_chkInspArea.GetCheck();
	int nPattern = m_cmbType.GetCurSel();
	int nCam = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCam == HIGH_1ST_CAM)
		nCam = LOW_1ST_CAM;
	else
		nCam = LOW_2ND_CAM;
#endif
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		if(bCheck)
		{
			gDeviceFactory.GetVision()->ShowArea(2, nPattern, nCam);
			GetDlgItem(IDC_CHECK_INSP_AREA)->SetWindowText(_T("Apply ROI"));
			GetDlgItem(IDC_BUTTON_TEST)->EnableWindow(FALSE);
			GetDlgItem(IDC_BUTTON_TRAIN)->EnableWindow(FALSE);
			GetDlgItem(IDC_BUTTON_INIT_2DPIXEL)->EnableWindow(FALSE);
			GetDlgItem(IDC_BUTTON_GET_2DPIXEL)->EnableWindow(FALSE);
			GetDlgItem(IDC_BUTTON_PROOF_2DPIXCEL)->EnableWindow(FALSE);
			GetDlgItem(IDC_BUTTON_IMG_SAVE)->EnableWindow(FALSE);
			GetDlgItem(IDC_BUTTON_OPEN)->EnableWindow(FALSE);
			GetDlgItem(IDC_BUTTON_SAVE)->EnableWindow(FALSE);
			GetDlgItem(IDC_BUTTON_SET_RECIPE)->EnableWindow(FALSE);
			GetDlgItem(IDC_BUTTON_LIVE)->EnableWindow(FALSE);
		}
		else
		{
			gDeviceFactory.GetVision()->ShowArea(0, nPattern, nCam);
			GetDlgItem(IDC_CHECK_INSP_AREA)->SetWindowText(_T("Show ROI"));
			GetDlgItem(IDC_BUTTON_TEST)->EnableWindow(TRUE);
			GetDlgItem(IDC_BUTTON_TRAIN)->EnableWindow(TRUE);
			GetDlgItem(IDC_BUTTON_INIT_2DPIXEL)->EnableWindow(TRUE);
			GetDlgItem(IDC_BUTTON_GET_2DPIXEL)->EnableWindow(TRUE);
			GetDlgItem(IDC_BUTTON_PROOF_2DPIXCEL)->EnableWindow(TRUE);
			GetDlgItem(IDC_BUTTON_IMG_SAVE)->EnableWindow(TRUE);
			GetDlgItem(IDC_BUTTON_OPEN)->EnableWindow(TRUE);
			GetDlgItem(IDC_BUTTON_SAVE)->EnableWindow(TRUE);
			GetDlgItem(IDC_BUTTON_SET_RECIPE)->EnableWindow(TRUE);
			GetDlgItem(IDC_BUTTON_LIVE)->EnableWindow(TRUE);
		}
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		if(bCheck)
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetInspectArea(TRUE);
		else
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetInspectArea(FALSE);

			DPOINT dpStart, dpEnd;
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->GetInspectArea(dpStart, dpEnd);
			gDeviceFactory.GetVision()->SetInspectArea(dpStart, dpEnd);
		}
	}
}

int CPaneManualControlVision::GetCameraNo()
{
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	return nCamNo;
}

void CPaneManualControlVision::DPHoleInfo(CString strMsg)
{
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	m_stcInspResult.SetWindowText( strMsg );
	
	CString strPos;
	double dPosX, dPosY;
	BOOL b1st = TRUE;
	
	CString strData;
	
	switch( nCamNo )
	{
	case HIGH_1ST_CAM :
	case LOW_1ST_CAM :
		b1st = TRUE;
		gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
		gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);
		strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
		strData.Format(_T("1st %s %s"), strPos, strMsg);
		break;
	case HIGH_2ND_CAM :
	case LOW_2ND_CAM :
		b1st = FALSE;
		gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
		gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);
		strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
		strData.Format(_T("2nd %s %s"), strPos, strMsg);
		break;
	}
	
	m_lboxResult.InsertString( 0, (LPCTSTR)strData );
	m_lboxResult.SetCurSel( 0 );
}

void CPaneManualControlVision::EnableButton(BOOL bEnable)
{
	GetDlgItem(IDC_BUTTON_LIVE)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_TRAIN)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_TEST)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_IMG_SAVE)->EnableWindow(bEnable);
	GetDlgItem(IDC_CHECK_INSP_AREA)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_SET_RECIPE)->EnableWindow(bEnable);

	GetDlgItem(IDC_BUTTON_VISION_TRIGGER)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_VISION_TRIGGER_AGC)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_SHOW_DIALOG)->EnableWindow(bEnable);
}

void CPaneManualControlVision::SetFiducial(BOOL bSetFid)
{
//	GetDlgItem(IDC_BUTTON_SET_RECIPE)->ShowWindow(bSetFid);
}

int CPaneManualControlVision::VisionParameterSetting(int nFidKind, int nIndex) 
{
	UpdateData();
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	CString strData;

	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return -1;
	
	LPFIDDATA pFidData = gDProject.m_Glyphs.GetFiducialData(nFidKind, nIndex);
	
	if(pFidData == NULL)
	{
		ErrMessage(_T("There is no fiducial data"));
		return -1;
	}

	VISION_INFO sVisionInfo;
	
	// Model Type
	sVisionInfo.nModelType = pFidData->sVisInfo.nModelType;

	// Polarity
	sVisionInfo.nPolarity = pFidData->sVisInfo.nPolarity;
	
	// Size A, B, C, Orientation
	sVisionInfo.dSizeA	= pFidData->sVisInfo.dSizeA;
	
	sVisionInfo.dSizeB	= pFidData->sVisInfo.dSizeB;
	
	sVisionInfo.dSizeC	= pFidData->sVisInfo.dSizeC;
		
	// Accept Score
	sVisionInfo.dScoreSize	= pFidData->sVisInfo.dScoreSize;
	
	sVisionInfo.dScoreAngle	= pFidData->sVisInfo.dScoreAngle;
	
	sVisionInfo.dAspectRatio	= pFidData->sVisInfo.dAspectRatio;

	sVisionInfo.nThreshold = pFidData->sVisInfo.nThreshold;
	
	for(int i=0; i<4; i++)
	{
		sVisionInfo.nCoaxial[i] = pFidData->sVisInfo.nCoaxial[i];
		sVisionInfo.nRing[i] = pFidData->sVisInfo.nRing[i];
		sVisionInfo.nIR[i] = pFidData->sVisInfo.nIR[i];

		sVisionInfo.dContrast[i] = pFidData->sVisInfo.dContrast[i];
		sVisionInfo.dBrightness[i] = pFidData->sVisInfo.dBrightness[i];
	}
	
	HVision* pVision = gDeviceFactory.GetVision();
	if(nCamNo == LOW_1ST_CAM || nCamNo == HIGH_1ST_CAM)
	{
		if(pFidData->nCam == HIGH_CAM)
		{
			nCamNo = HIGH_1ST_CAM;
		}
		else
		{
			nCamNo = LOW_1ST_CAM;
		}
	}
	else if(nCamNo == LOW_2ND_CAM || nCamNo == HIGH_2ND_CAM)
	{
		if(pFidData->nCam == HIGH_CAM)
		{
			nCamNo = HIGH_2ND_CAM;
		}
		else
		{
			nCamNo = LOW_2ND_CAM;
		}
	}
	pVision->OnApplyVisionParameter( sVisionInfo.nModelType, nCamNo, sVisionInfo );

/*	m_cmbType.SetCurSel(sVisionInfo.nModelType);
	
	// Size A, B, C, Orientation
	strData.Format(_T("%.2f"), sVisionInfo.dSizeA);
	m_edtSizeA.SetWindowText( strData );
	
	strData.Format(_T("%.2f"), sVisionInfo.dSizeB);
	m_edtSizeB.SetWindowText( strData );
	
	strData.Format(_T("%.2f"), sVisionInfo.dSizeC);
	m_edtSizeC.SetWindowText( strData );
	
	// Polarity
	m_nPolarity = sVisionInfo.nPolarity;
	
	// Contast & Brightness
	strData.Format(_T("%.1f"), sVisionInfo.dContrast[nCamNo]);
	m_edtContrast.SetWindowText( strData );
	
	strData.Format(_T("%.1f"), sVisionInfo.dBrightness[nCamNo]);
	m_edtBrightness.SetWindowText( strData );
	
	// Accept Score
	strData.Format(_T("%.1f"), sVisionInfo.dScoreSize);
	m_edtSize.SetWindowText( strData );
	
	strData.Format(_T("%.1f"), sVisionInfo.dScoreAngle);
	m_edtAngle.SetWindowText( strData );
	
	strData.Format(_T("%.1f"), sVisionInfo.dAspectRatio);
	m_edtAspectRatio.SetWindowText( strData );
	
	strData.Format(_T("%d"), sVisionInfo.nThreshold);
	m_edtThreshold.SetWindowText( strData );

	// Light
	strData.Format(_T("%d"), sVisionInfo.nCoaxial[nCamNo]);
	m_edtCoaxial.SetWindowText( strData );
	
	strData.Format(_T("%d"), sVisionInfo.nRing[nCamNo]);
	m_edtRing.SetWindowText( strData );
	
	for(int i = 0; i<4; i++)
	{
		m_nCoaxial[i] = sVisionInfo.nCoaxial[i];
		m_nRing[i] = sVisionInfo.nRing[i];
		m_dContrast[i] = sVisionInfo.dContrast[i];
		m_dBrightness[i] = sVisionInfo.dBrightness[i];
	}
	
	strData.Format(_T("%.1f"), m_dContrast[nCamNo]);
	m_edtContrast.SetWindowText( strData );
	
	strData.Format(_T("%.1f"), m_dBrightness[nCamNo]);
	m_edtBrightness.SetWindowText( strData );
	
	UpdateData(FALSE);
*/
	return nCamNo;
}

void CPaneManualControlVision::VisionSetting(int nFidKind) 
{
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	CString strData;

	if(nFidKind < 0 || nFidKind >= MAX_FID_KIND_NO)
		return ;
	
	LPFIDDATA pFidData = gDProject.m_Glyphs.GetFiducialData(nFidKind, 0);
	
	if(pFidData == NULL)
	{
		ErrMessage(_T("There is no fiducial data"));
		return ;
	}

	VISION_INFO sVisionInfo;
	
	// Model Type
	sVisionInfo.nModelType = pFidData->sVisInfo.nModelType;

	// Polarity
	sVisionInfo.nPolarity = pFidData->sVisInfo.nPolarity;
	
	// Size A, B, C, Orientation
	sVisionInfo.dSizeA	= pFidData->sVisInfo.dSizeA;
	
	sVisionInfo.dSizeB	= pFidData->sVisInfo.dSizeB;
	
	sVisionInfo.dSizeC	= pFidData->sVisInfo.dSizeC;
		
	// Accept Score
	sVisionInfo.dScoreSize	= pFidData->sVisInfo.dScoreSize;
	
	sVisionInfo.dScoreAngle	= pFidData->sVisInfo.dScoreAngle;
	
	sVisionInfo.dAspectRatio	= pFidData->sVisInfo.dAspectRatio;

	sVisionInfo.nThreshold = pFidData->sVisInfo.nThreshold;
	
	for(int i=0; i<4; i++)
	{
		sVisionInfo.nCoaxial[i] = pFidData->sVisInfo.nCoaxial[i];
		sVisionInfo.nRing[i] = pFidData->sVisInfo.nRing[i];
		sVisionInfo.nIR[i] = pFidData->sVisInfo.nIR[i];

		sVisionInfo.dContrast[i] = pFidData->sVisInfo.dContrast[i];
		sVisionInfo.dBrightness[i] = pFidData->sVisInfo.dBrightness[i];
	}
	
	m_cmbType.SetCurSel(sVisionInfo.nModelType);
	
	// Size A, B, C, Orientation
	strData.Format(_T("%.2f"), sVisionInfo.dSizeA);
	m_edtSizeA.SetWindowText( strData );
	
	strData.Format(_T("%.2f"), sVisionInfo.dSizeB);
	m_edtSizeB.SetWindowText( strData );
	
	strData.Format(_T("%.2f"), sVisionInfo.dSizeC);
	m_edtSizeC.SetWindowText( strData );
	
	// Polarity
	m_nPolarity = sVisionInfo.nPolarity;
	
	// Contast & Brightness
	strData.Format(_T("%.1f"), sVisionInfo.dContrast[nCamNo]);
	m_edtContrast.SetWindowText( strData );
	
	strData.Format(_T("%.1f"), sVisionInfo.dBrightness[nCamNo]);
	m_edtBrightness.SetWindowText( strData );
	
	// Accept Score
	strData.Format(_T("%.1f"), sVisionInfo.dScoreSize);
	m_edtSize.SetWindowText( strData );
	
	strData.Format(_T("%.1f"), sVisionInfo.dScoreAngle);
	m_edtAngle.SetWindowText( strData );
	
	strData.Format(_T("%.1f"), sVisionInfo.dAspectRatio);
	m_edtAspectRatio.SetWindowText( strData );
	
	strData.Format(_T("%d"), sVisionInfo.nThreshold);
	m_edtThreshold.SetWindowText( strData );

	// Light
	strData.Format(_T("%d"), sVisionInfo.nCoaxial[nCamNo]);
	m_edtCoaxial.SetWindowText( strData );
	m_SliderCoaxial.SetPos(sVisionInfo.nCoaxial[nCamNo]);
	
	strData.Format(_T("%d"), sVisionInfo.nRing[nCamNo]);
	m_edtRing.SetWindowText( strData );
	m_SliderRing.SetPos(sVisionInfo.nRing[nCamNo]);

	strData.Format(_T("%d"), sVisionInfo.nIR[nCamNo]);
	m_edtIR.SetWindowText( strData );
	m_SliderIR.SetPos(sVisionInfo.nIR[nCamNo]);
	
	for(int i=0; i<4; i++)
	{
		m_nCoaxial[i] = sVisionInfo.nCoaxial[i];
		m_nRing[i] = sVisionInfo.nRing[i];
		m_nIR[i] = sVisionInfo.nIR[i];
		m_dContrast[i] = sVisionInfo.dContrast[i];
		m_dBrightness[i] = sVisionInfo.dBrightness[i];
	}
	
	strData.Format(_T("%.1f"), m_dContrast[nCamNo]);
	m_edtContrast.SetWindowText( strData );
	
	strData.Format(_T("%.1f"), m_dBrightness[nCamNo]);
	m_edtBrightness.SetWindowText( strData );
	
	UpdateData(FALSE);

	return;

/*	SVISIONINFO sVisionInfo;
	UpdateData();
	int nCamNo = m_cmbCamNo.GetCurSel();
	CString strData;

	// Model Type
	sVisionInfo.nModelType = gDProject.m_FidInfo[nFidKind].nModelType;
	
	// Size A, B, C, Orientation
	sVisionInfo.dSizeA	= gDProject.m_FidInfo[nFidKind].dSizeA;
	
	sVisionInfo.dSizeB	= gDProject.m_FidInfo[nFidKind].dSizeB;
	
	sVisionInfo.dSizeC	= gDProject.m_FidInfo[nFidKind].dSizeC;
	
	// Polarity
	sVisionInfo.nPolarity = gDProject.m_FidInfo[nFidKind].nPolarity;
	
	// Accept Score
	sVisionInfo.dScoreSize	= gDProject.m_FidInfo[nFidKind].dScoreSize;
	
	sVisionInfo.dScoreAngle	= gDProject.m_FidInfo[nFidKind].dScoreAngle;
	
	sVisionInfo.dAspectRatio	= gDProject.m_FidInfo[nFidKind].dAspectRatio;

	sVisionInfo.nThreshold = gDProject.m_FidInfo[nFidKind].nThreshold;	

	for(int i=0; i<4; i++)
	{
		sVisionInfo.nCoaxial[i] = gDProject.m_FidInfo[nFidKind].nCoaxial[i];
		sVisionInfo.nRing[i] = gDProject.m_FidInfo[nFidKind].nRing[i];
		sVisionInfo.dContrast[i] = gDProject.m_FidInfo[nFidKind].dContrast[i];
		sVisionInfo.dBrightness[i] = gDProject.m_FidInfo[nFidKind].dBrightness[i];
	}
	
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->SetInspectionArea(-1, nCamNo);
	pVision->OnApplyVisionParam( sVisionInfo.nModelType, nCamNo, sVisionInfo );

	m_cmbType.SetCurSel(sVisionInfo.nModelType);
	
	// Size A, B, C, Orientation
	strData.Format(_T("%.2f"), sVisionInfo.dSizeA);
	m_edtSizeA.SetWindowText( strData );
	
	strData.Format(_T("%.2f"), sVisionInfo.dSizeB);
	m_edtSizeB.SetWindowText( strData );

	strData.Format(_T("%.2f"), sVisionInfo.dSizeC);
	m_edtSizeC.SetWindowText( strData );
	
	// Polarity
	m_nPolarity = sVisionInfo.nPolarity;
	
	// Contast & Brightness
	strData.Format(_T("%.1f"), sVisionInfo.dContrast[nCamNo]);
	m_edtContrast.SetWindowText( strData );
	
	strData.Format(_T("%.1f"), sVisionInfo.dBrightness[nCamNo]);
	m_edtBrightness.SetWindowText( strData );
	
	// Accept Score
	strData.Format(_T("%.1f"), sVisionInfo.dScoreSize);
	m_edtSize.SetWindowText( strData );

	strData.Format(_T("%.1f"), sVisionInfo.dScoreAngle);
	m_edtAngle.SetWindowText( strData );
	
	strData.Format(_T("%.1f"), sVisionInfo.dAspectRatio);
	m_edtAspectRatio.SetWindowText( strData );
	
	strData.Format(_T("%d"), sVisionInfo.nThreshold );
	m_edtThreshold.SetWindowText( strData );
	// Light
	strData.Format(_T("%d"), sVisionInfo.nCoaxial[nCamNo]);
	m_edtCoaxial.SetWindowText( strData );

	strData.Format(_T("%d"), sVisionInfo.nRing[nCamNo]);
	m_edtRing.SetWindowText( strData );
	
	for(int i = 0; i<4; i++)
	{
		m_nCoaxial[i] = sVisionInfo.nCoaxial[i];
		m_nRing[i] = sVisionInfo.nRing[i];
		m_dContrast[i] = sVisionInfo.dContrast[i];
		m_dBrightness[i] = sVisionInfo.dBrightness[i];
	}

	strData.Format(_T("%.1f"), m_dContrast[nCamNo]);
	m_edtContrast.SetWindowText( strData );

	strData.Format(_T("%.1f"), m_dBrightness[nCamNo]);
	m_edtBrightness.SetWindowText( strData );

	UpdateData(FALSE);
	*/
}

void CPaneManualControlVision::ChangeControl(BOOL bUse)
{
	GetDlgItem(IDC_STATIC_MODEL)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_POLARITY)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_VISION_ACCEPT_SCORE)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_CONTRASTBRIGHTNESS)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_TYPE)->ShowWindow(bUse);
	GetDlgItem(IDC_COMBO_TYPE)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_A)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_B)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_C)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_SIZE_A)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_SIZE_B)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_SIZE_C)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_A_MM)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_B_MM)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_C_MM)->ShowWindow(bUse);
	GetDlgItem(IDC_RADIO_DARK)->ShowWindow(bUse);
	GetDlgItem(IDC_RADIO_LIGHT)->ShowWindow(bUse);
	GetDlgItem(IDC_RADIO_NONE)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_PIC)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_VISION_SIZE)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_VISION_SIZE)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_VISION_SIZE_PER)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_ANGLE)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_ANGLE)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_ANGLE_DEG)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_ASPECT_RATIO)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_ASPECTRATIO)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_ASPECT_RATIO_PER)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_CONTRAST)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_CONTRAST)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_BRIGHTNESS)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_BRIGHTNESS)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_CAMERA)->ShowWindow(bUse);
//	GetDlgItem(IDC_COMBO_CAM_NO)->ShowWindow(bUse);
	GetDlgItem(IDC_BUTTON_TRAIN)->ShowWindow(bUse);
	GetDlgItem(IDC_BUTTON_TEST)->ShowWindow(bUse);	
//	GetDlgItem(IDC_BUTTON_IMG_SAVE)->ShowWindow(bUse);	

	GetDlgItem(IDC_BUTTON_VISION_TRIGGER)->ShowWindow(!bUse);	
	GetDlgItem(IDC_BUTTON_VISION_TRIGGER_AGC)->ShowWindow(!bUse);
	GetDlgItem(IDC_BUTTON_SHOW_DIALOG)->ShowWindow(!bUse);
	
	GetDlgItem(IDC_EDIT_JOB_FILE)->ShowWindow(!bUse);
	GetDlgItem(IDC_BUTTON_JOB_FILE_OPEN2)->ShowWindow(!bUse);
}

void CPaneManualControlVision::OnButtonJobFileOpen()
{
	TCHAR BASED_CODE szFilter[] = _T("Job Files (*.Job)|*.job|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.Job"), NULL, dwFlags, szFilter);
	
	CString strPath;
	strPath.Format(_T("%s\\JobFile\\"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	dlg.m_ofn.lpstrInitialDir = strPath;
	
	if(IDOK != dlg.DoModal())
		return;
	
	m_strPath = dlg.GetPathName();
	
	m_edtPath.SetWindowText(m_strPath);

	HVision* pVision = gDeviceFactory.GetVision();
	pVision->LoadProject(m_strPath);
}

LRESULT CPaneManualControlVision::ChangeVisionParameter(WPARAM wParam, LPARAM lParam)
{
	VisionParameterSetting(wParam, lParam);
	return 1L;
}

void CPaneManualControlVision::OnButtonOpen() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg( TRUE, "vpp", NULL, OFN_OVERWRITEPROMPT, "VisionPro Files (*.vpp)|*.vpp||" );
	dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetVisionProjectPath();
	if( dlg.DoModal() != IDOK )	return;

	CString str;
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->LoadProject(dlg.GetPathName());
	str.Format(_T("%s"), dlg.GetPathName());
	memset(gDProject.m_szVisionProjectName, 0, sizeof(gDProject.m_szVisionProjectName));
	strcpy_s(gDProject.m_szVisionProjectName, str);
	m_edtProjectPath.SetWindowText((LPCTSTR)str);
	int nCam = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCam == HIGH_1ST_CAM)
		nCam = LOW_1ST_CAM;
	else
		nCam = LOW_2ND_CAM;
#endif
	int nSel = m_cmbType.GetCurSel();
	ChangeDisplay(nSel, nCam);

}

void CPaneManualControlVision::OnButtonSave() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg( FALSE, "vpp", NULL, OFN_OVERWRITEPROMPT, "VisionPro Files (*.vpp)|*.vpp||" );
	dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetVisionProjectPath();	
	if( dlg.DoModal() != IDOK ) return;

	CString str;
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->SaveProject(dlg.GetPathName());
	
	str.Format(_T("%s"), dlg.GetPathName());
	memset(gDProject.m_szVisionProjectName, 0, sizeof(gDProject.m_szVisionProjectName));
	strcpy_s(gDProject.m_szVisionProjectName, str);
	m_edtProjectPath.SetWindowText((LPCTSTR)str);

	
}


void CPaneManualControlVision::ChangeDisplay(int nSel, int nCamNo)
{
	//Size A,B,C
	//Size %, Angle %, Aspect Ratio %
	//Contrast Brightness 1.0 ~ 0.0

	SVISIONINFO pVisionInfo;
	GetDispParam(&pVisionInfo, nSel, nCamNo);

	if(pVisionInfo.nThreshold < 0)
		pVisionInfo.nThreshold = 0;

	if(nSel >= MODEL_PATTERN)
	{
		pVisionInfo.dSizeA = 0;
		pVisionInfo.dSizeB = 0;
		pVisionInfo.dSizeC = 0;
	}

	CString str;
	str.Format(_T("%.2f"),pVisionInfo.dSizeA);
	m_edtSizeA.SetWindowText(str);
	
	str.Format(_T("%.2f"),pVisionInfo.dSizeB);
	m_edtSizeB.SetWindowText(str);
	
	str.Format(_T("%2f"),pVisionInfo.dSizeC);
	m_edtSizeC.SetWindowText(str);

	str.Format(_T("%.1f"),pVisionInfo.dContrast[nCamNo]);
	m_edtContrast.SetWindowText(str);

	str.Format(_T("%.1f"),pVisionInfo.dBrightness[nCamNo]);
	m_edtBrightness.SetWindowText(str);

	str.Format(_T("%.1f"),pVisionInfo.dScoreSize);
	m_edtSize.SetWindowText(str);

	str.Format(_T("%.1f"), pVisionInfo.dScoreAngle);
	m_edtAngle.SetWindowText(str);

	str.Format(_T("%.1f"), pVisionInfo.dAspectRatio);
	m_edtAspectRatio.SetWindowText(str);

	str.Format(_T("%d"), pVisionInfo.nThreshold );
	m_edtThreshold.SetWindowText(str);

	str.Format(_T("%s"), gDProject.m_szVisionProjectName);
	m_edtProjectPath.SetWindowText(str);
	
// 	str.Format(_T("%d"), pVisionInfo.nBlob[nCamNo]);
// 	m_edtBlob.SetWindowText(str);

	m_nPolarity = pVisionInfo.nPolarity;
	UpdateData(FALSE);

}

void CPaneManualControlVision::GetDispParam(SVISIONINFO *pVisionInfo, int nSel, int nCamNo)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->GetDispParam(pVisionInfo, nSel, nCamNo);
}
void CPaneManualControlVision::OnButtonTrainRegion()
{

}

void CPaneManualControlVision::GetSelIndex(int& nIndex, int& nCam)
{
	nIndex = m_nModelType;
	nCam = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCam == HIGH_1ST_CAM)
		nCam = LOW_1ST_CAM;
	else
		nCam = LOW_2ND_CAM;
#endif
}
void CPaneManualControlVision::OnButtonThreshold()
{
	UpdateData(TRUE);

	int nTemp, nCam, nPatternNo;
	CString str;
	m_edtThreshold.GetWindowText(str);
	nTemp = atoi(str);

	if(nTemp < 0 || nTemp > 255)
	{
		ErrMessage(_T("0 <= Threshold <= 255"));
		return;
	}
	nCam = m_cmbCamNo.GetCurSel();	
#ifdef __USE_ONLY_LOW_CAM__
	if(nCam == HIGH_1ST_CAM)
		nCam = LOW_1ST_CAM;
	else
		nCam = LOW_2ND_CAM;
#endif
	nPatternNo = m_cmbType.GetCurSel();
//	gDeviceFactory.GetVision()->SetThreshold(nCam, nPatternNo, nTemp);
}

void CPaneManualControlVision::OnButtonGet2dpixel() 
{
	// TODO: Add your control notification handler code here
	int nCam = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCam == HIGH_1ST_CAM)
		nCam = LOW_1ST_CAM;
	else
		nCam = LOW_2ND_CAM;
#endif
	DPOINT visionResult;
	double dPosX, dPosY;

	gDeviceFactory.GetVision()->InitVisionPixelData(nCam);
	gDeviceFactory.GetVision()->InitDistancePerPixel();

	BOOL b1st = TRUE;
	if(nCam >= HIGH_2ND_CAM)
		b1st = FALSE;

	CString strData;
	m_edtSizeA.GetWindowText( strData );
	double dHoleSize = atof( (LPSTR)(LPCTSTR)strData );
	double dXDis = gSystemINI.m_sSystemDevice.dHighFOVX/2 -dHoleSize, dYDis = gSystemINI.m_sSystemDevice.dHighFOVY/2 -dHoleSize;
	
	if(nCam % 2)
	{
		//dXDis = 3; dYDis = 2.5;
		dXDis = gSystemINI.m_sSystemDevice.dLowFOVX/2 -dHoleSize; 
		dYDis = gSystemINI.m_sSystemDevice.dLowFOVY/2 -dHoleSize;
	}

	gDeviceFactory.GetVision()->OnLive(nCam, FALSE);
	gDeviceFactory.GetVision()->SetInspectionArea(-1, nCam);

	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);

	double dPixelDist1 = 0, dPixelDist2 = 0;
	double dMotorDist1 = 0, dMotorDist2 = 0;
	double dPixelPerMSY = 0, dPixelPerMSX = 0;
	double dCalMoveX = 0, dCalMoveY = 0;

	double dXPlus = FALSE, dYPlus = FALSE;
	for(int i = 0; i < 2; i++)
	{
		if(i % 2)
			dXPlus = 1;
		else
			dXPlus = -1;

		if(!gDeviceFactory.GetMotor()->MotorMoveXY(dPosX + dXPlus * (dXDis/2), dPosY, b1st))
		{
			ErrMessage(_T("Can't move table."));
			return;
		}
		
		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
		{
			ErrMessage(_T("Inposition error."));
			return;
		}
		::Sleep(200);
		OnButtonTest();
		if(!gDeviceFactory.GetVision()->GetRealPos(&visionResult, nCam, m_cmbType.GetCurSel(), TRUE))
		{
			gDeviceFactory.GetMotor()->MotorMoveXY(dPosX , dPosY, b1st );
//			OnButtonTest();
	//		ErrMessage(_T("There is no model"));
		//	return;
		}
		if(i == 0)
		{
			dPixelDist1 = visionResult.x;
			dMotorDist1 = dPosX + dXPlus * (dXDis/2);
		}
		else
		{
			dPixelDist2 = fabs(dPixelDist1 - visionResult.x);
			dMotorDist2 = ((dPosX + dXPlus * (dXDis/2)) - dMotorDist1);
			dPixelPerMSX = ((dMotorDist2 * 1000) / dPixelDist2) / 1000;
		}
	}
	for(int i = 0; i < 2; i++)
	{
		if(i % 2)
			dYPlus = 1;
		else
			dYPlus = -1;

		if(!gDeviceFactory.GetMotor()->MotorMoveXY(dPosX, dPosY + dYPlus * (dYDis/2), b1st))
		{
			ErrMessage(_T("Can't move table."));
			return;
		}
		
		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
		{
			ErrMessage(_T("Inposition error."));
			return;
		}
		::Sleep(200);
		OnButtonTest();
		if(!gDeviceFactory.GetVision()->GetRealPos(&visionResult, nCam, m_cmbType.GetCurSel(), TRUE))
		{
			gDeviceFactory.GetMotor()->MotorMoveXY(dPosX , dPosY, b1st );
//			OnButtonTest();
	//		ErrMessage(_T("There is no model"));
		//	return;
		}
		if(i == 0)
		{
			dPixelDist1 = visionResult.y;
			dMotorDist1 = dPosY + dYPlus * (dYDis/2);
		}
		else
		{
			dPixelDist2 = fabs(dPixelDist1 - visionResult.y);
			dMotorDist2 = ((dPosY + dYPlus * (dYDis/2)) - dMotorDist1);
			dPixelPerMSY = ((dMotorDist2 * 1000) / dPixelDist2) / 1000;
		}
	}

	if(!gDeviceFactory.GetVision()->GetRealPos(&visionResult, nCam, m_cmbType.GetCurSel(), TRUE))
	{
//			OnButtonTest();
//		ErrMessage(_T("There is no model"));
		return;
	}

	if(nCam == HIGH_2ND_CAM || nCam == HIGH_1ST_CAM)
	{
		double dCameraPixelX = gSystemINI.m_sSystemDevice.nCameraPixelX;
		double dCameraPixelY = gSystemINI.m_sSystemDevice.nCameraPixelY;
		double dCenterDistX = (dCameraPixelX/2 - visionResult.x) * dPixelPerMSX;
		double dCenterDistY = (dCameraPixelY/2 - visionResult.y) * dPixelPerMSY;

		gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
		gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);

		if(!gDeviceFactory.GetMotor()->MotorMoveXY(dPosX + dCenterDistX, dPosY - dCenterDistY, b1st))
		{
			ErrMessage(_T("Can't move table."));
			return;
		}
		
		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
		{
			ErrMessage(_T("Inposition error."));
			return;
		}
		::Sleep(200);
		OnButtonTest();
		if(!gDeviceFactory.GetVision()->GetRealPos(&visionResult, nCam, m_cmbType.GetCurSel(), TRUE))
		{
			gDeviceFactory.GetMotor()->MotorMoveXY(dPosX , dPosY, b1st );
//			OnButtonTest();
	//		ErrMessage(_T("There is no model"));
		//	return;
		}
		CString strMessage = _T("");
		strMessage.Format(_T("Is hole placed in center position?\n(x:%.1f, y:%.1f)"), 
			dCameraPixelX/2, 
			dCameraPixelY/2);
		if(ErrMessage(strMessage, MB_YESNO) != IDYES)
			return;
		dCalMoveX = dPosX + dCenterDistX;
		dCalMoveY = dPosY - dCenterDistY;
	}
	else
	{
		double dCameraPixelX = gSystemINI.m_sSystemDevice.nCameraPixelX;
		double dCameraPixelY = gSystemINI.m_sSystemDevice.nCameraPixelY;
		double dCenterDistX = (dCameraPixelX/2 - visionResult.x) * dPixelPerMSX;
		double dCenterDistY = (dCameraPixelY/2 - visionResult.y) * dPixelPerMSY;

		gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
		gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);

		if(!gDeviceFactory.GetMotor()->MotorMoveXY(dPosX + dCenterDistX, dPosY - dCenterDistY, b1st))
		{
			ErrMessage(_T("Can't move table."));
			return;
		}
		
		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
		{
			ErrMessage(_T("Inposition error."));
			return;
		}
		::Sleep(200);
		OnButtonTest();
		if(!gDeviceFactory.GetVision()->GetRealPos(&visionResult, nCam, m_cmbType.GetCurSel(), TRUE))
		{
			gDeviceFactory.GetMotor()->MotorMoveXY(dPosX , dPosY, b1st );
//			OnButtonTest();
	//		ErrMessage(_T("There is no model"));
		//	return;
		}
		CString strMessage = _T("");
		strMessage.Format(_T("Is hole placed in center position?\n(x:%.1f, y:%.1f)"), 
			dCameraPixelX/2, 
			dCameraPixelY/2);
		if(ErrMessage(strMessage, MB_YESNO) != IDYES)
			return;
		dCalMoveX = dPosX + dCenterDistX;
		dCalMoveY = dPosY - dCenterDistY;
	}

	if(gDeviceFactory.GetMotor()->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
	{
		BOOL bSuction = gDeviceFactory.GetMotor()->GetCurrentSuction();
		if(b1st)	
		{
			if(!(bSuction & 0x01))
			{
				ErrMessage(_T("Check Table Vacuume"));
				return;
			}
		}
		else
		{
			if(!(bSuction & 0x02))
			{
				ErrMessage(_T("Check Table Vacuume"));
				return;
			}
		}
	}
	
	
//	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
//	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);

	gDeviceFactory.GetVision()->OnLive(nCam, FALSE);
	gDeviceFactory.GetVision()->SetInspectionArea(-1, nCam);

	for(int i = 0; i < 4; i++)
	{
		if(i < 2)
			dXPlus = 1;
		else
			dXPlus = -1;
		if(i % 2)
			dYPlus = 1;
		else
			dYPlus = -1;

		if(!gDeviceFactory.GetMotor()->MotorMoveXY(dCalMoveX + dXPlus * dXDis, dCalMoveY + dYPlus * dYDis, b1st))
		{
			ErrMessage(_T("Can't move table."));
			return;
		}
		
		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
		{
			ErrMessage(_T("Inposition error."));
			return;
		}
		::Sleep(200);
		OnButtonTest();
		if(!gDeviceFactory.GetVision()->GetRealPos(&visionResult, nCam, m_cmbType.GetCurSel(), TRUE))
		{
			gDeviceFactory.GetMotor()->MotorMoveXY(dPosX , dPosY, b1st );
//			OnButtonTest();
	//		ErrMessage(_T("There is no model"));
		//	return;
		}

		gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][i].x = visionResult.x; gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][i].y = visionResult.y;
		gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][i].x = dXPlus * dXDis; gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][i].y = dYPlus * dYDis;
	}

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, SYSTEM_INI))
	{
		gDeviceFactory.GetMotor()->MotorMoveXY(dPosX , dPosY, b1st);
		OnButtonTest();
		ErrMsgDlg(STDGNALM110);
		return;
	}
	::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, SYSTEM_DEVICE);
	gDeviceFactory.GetVision()->TransformPixel();
	
	
	if(!gDeviceFactory.GetMotor()->MotorMoveXY(dCalMoveX , dCalMoveY, b1st ))
	{
		ErrMessage(_T("Can't move table."));
		return;
	}
	
	if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
	{
		ErrMessage(_T("Inposition error."));
		return;
	}
	OnButtonTest();
}

void CPaneManualControlVision::OnButtonInit2dpixel() 
{
	// TODO: Add your control notification handler code here
	if(IDYES != ErrMessage(_T("Danger : Do you really want to reset vision pixel data?"), MB_YESNO))
		return;

	int nCam = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCam == HIGH_1ST_CAM)
		nCam = LOW_1ST_CAM;
	else
		nCam = LOW_2ND_CAM;
#endif
	if(nCam < 0 || nCam > LOW_2ND_CAM)
		return;

	gDeviceFactory.GetVision()->InitVisionPixelData(nCam);
	gDeviceFactory.GetVision()->InitDistancePerPixel();

}

void CPaneManualControlVision::OnButtonProof2dpixcel() 
{
	// TODO: Add your control notification handler code here
	if(gDeviceFactory.GetMotor()->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	int nCam = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCam == HIGH_1ST_CAM)
		nCam = LOW_1ST_CAM;
	else
		nCam = LOW_2ND_CAM;
#endif
	CString strData;
	m_edtSizeA.GetWindowText( strData );
	double dHoleSize = atof( (LPSTR)(LPCTSTR)strData );

	double dXDis = gSystemINI.m_sSystemDevice.dHighFOVX/2 -dHoleSize, dYDis = gSystemINI.m_sSystemDevice.dHighFOVY/2 -dHoleSize;
	if(nCam % 2)
	{
		//dXDis = 3; dYDis = 2.5;
		dXDis = gSystemINI.m_sSystemDevice.dLowFOVX/2 -dHoleSize; 
		dYDis = gSystemINI.m_sSystemDevice.dLowFOVY/2 -dHoleSize;
	}
	BOOL b1st = TRUE;
	if(nCam > HIGH_2ND_CAM)
		b1st = FALSE;
	
	if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
	{
		BOOL bSuction = gDeviceFactory.GetMotor()->GetCurrentSuction();
		if(b1st)	
		{
			if(!(bSuction & 0x01))
			{
				ErrMessage(_T("Check Table Vacuume"));
				return;
		
			}
			else
			{
				if(!(bSuction & 0x02))
				{
					ErrMessage(_T("Check Table Vacuume"));
					return;
				}
			}
		}
	}
	
	double dPosX, dPosY;
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);
	
	gDeviceFactory.GetVision()->OnLive(nCam, FALSE);
	gDeviceFactory.GetVision()->SetInspectionArea(-1, nCam);
	
	double dXPlus = FALSE, dYPlus = FALSE;
	for(int i = 0; i < 4; i++)
	{
		if(i < 2)
			dXPlus = 1;
		else
			dXPlus = -1;
		if(i % 2)
			dYPlus = 1;
		else
			dYPlus = -1;
		
		if(!gDeviceFactory.GetMotor()->MotorMoveXY(dPosX + dXPlus * dXDis, dPosY + dYPlus * dYDis, b1st))
		{
			ErrMessage(_T("Can't move table."));
			return;
		}
		
		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
		{
			ErrMessage(_T("Inposition error."));
			return;
		}
		::Sleep(200);
		OnButtonTest();
	}

	if(!gDeviceFactory.GetMotor()->MotorMoveXY(dPosX , dPosY, b1st))
	{
		ErrMessage(_T("Can't move table."));
		return;
	}
	
	if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
	{
		ErrMessage(_T("Inposition error."));
		return;
	}
	OnButtonTest();
}

void CPaneManualControlVision::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

void CPaneManualControlVision::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_nTimerID = SetTimer(423, 500, NULL);
	}
}

void CPaneManualControlVision::SetAuthorityByLevel(int nLevel)
{
	switch(nLevel)
	{
	case 0:
	case 1:
		GetDlgItem(IDC_BUTTON_INIT_2DPIXEL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_GET_2DPIXEL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_PROOF_2DPIXCEL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BTN_TABLE_LIMIT_MAX)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BTN_TABLE_LIMIT_MIN)->ShowWindow(SW_HIDE);
		break;
	case 2:
	case 3:
		GetDlgItem(IDC_BUTTON_INIT_2DPIXEL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BUTTON_GET_2DPIXEL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BUTTON_PROOF_2DPIXCEL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BTN_TABLE_LIMIT_MAX)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BTN_TABLE_LIMIT_MIN)->ShowWindow(SW_SHOW);
		break;
	}
}


void CPaneManualControlVision::OnBnClickedBtnTableLimitMin()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	double dPosX, dPosY;
	double dVisionOffsetX,dVisionOffsetY;
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, TRUE);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, TRUE);

	if(nCamNo == 0)
	{
		dVisionOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
		dVisionOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
	}
	else if(nCamNo == 1)
	{
		dVisionOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dVisionOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
	}
	else if(nCamNo == 2)
	{
		dVisionOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
		dVisionOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
	}
	else if(nCamNo == 3)
	{
		dVisionOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		dVisionOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
	}

	CString strMsg = _T("");
	strMsg.Format(_T("Table Limit (Laser base) Position change\nMin X= %.3f, Min Y= %.3f"), 
		dPosX - dVisionOffsetX + gSystemINI.m_sSystemDevice.dFieldSize.x/2,
		dPosY - dVisionOffsetY + gSystemINI.m_sSystemDevice.dFieldSize.y/2);
	if(ErrMessage(strMsg, MB_YESNO)== IDYES)
	{
		gSystemINI.m_sSystemDevice.dTableLimitMinX = dPosX - dVisionOffsetX + gSystemINI.m_sSystemDevice.dFieldSize.x/2;
		gSystemINI.m_sSystemDevice.dTableLimitMinY = dPosY - dVisionOffsetY + gSystemINI.m_sSystemDevice.dFieldSize.y/2;

		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, SYSTEM_INI))
			ErrMsgDlg(STDGNALM110);
	}
}


void CPaneManualControlVision::OnBnClickedBtnTableLimitMax()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	double dPosX, dPosY;
	double dVisionOffsetX,dVisionOffsetY;
	int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
	if(nCamNo == HIGH_1ST_CAM)
		nCamNo = LOW_1ST_CAM;
	else
		nCamNo = LOW_2ND_CAM;
#endif
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, TRUE);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, TRUE);
	if(nCamNo == 0)
	{
		dVisionOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
		dVisionOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
	}
	else if(nCamNo == 1)
	{
		dVisionOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dVisionOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
	}
	else if(nCamNo == 2)
	{
		dVisionOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
		dVisionOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
	}
	else if(nCamNo == 3)
	{
		dVisionOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		dVisionOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
	}

	CString strMsg = _T("");
	strMsg.Format(_T("Table Limit (Laser base) Position change\nMax X= %.3f, Max Y= %.3f"), 
		dPosX - dVisionOffsetX - gSystemINI.m_sSystemDevice.dFieldSize.x/2,
		dPosY - dVisionOffsetY - gSystemINI.m_sSystemDevice.dFieldSize.y/2);
	if(ErrMessage(strMsg, MB_YESNO)== IDYES)
	{
		gSystemINI.m_sSystemDevice.dTableLimitMaxX = dPosX - dVisionOffsetX - gSystemINI.m_sSystemDevice.dFieldSize.x/2;
		gSystemINI.m_sSystemDevice.dTableLimitMaxY = dPosY - dVisionOffsetY - gSystemINI.m_sSystemDevice.dFieldSize.y/2;
	
		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, SYSTEM_INI))
			ErrMsgDlg(STDGNALM110);
	}
}


// void CPaneManualControlVision::OnEnKillfocusEditBlob()
// {
// 	// TODO: Add your control notification handler code here
// 	int nCamNo = m_cmbCamNo.GetCurSel();
// 	HVision* pVision = gDeviceFactory.GetVision();
// 
// 	CString strData;
// 
// 	m_edtBlob.GetWindowText( strData );
// 	
// 	m_nBlob[nCamNo] =  atoi( (LPSTR)(LPCTSTR)strData );
// 
// 	pVision->SetBlobValue(m_nBlob[nCamNo]);
// }


BOOL CPaneManualControlVision::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_Vision) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneManualControlVision::OnBnClickedButton2dbarcode()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
//	gDeviceFactory.GetMotor()->Set2DBarcodeTrigger();
//	Sleep(500);
	
	CString str;
	char szResult[256];
	memset(szResult, 0, sizeof(szResult));
	gDeviceFactory.GetVision()->Get2DBarcode(szResult, TRUE);

	str.Format(_T("%s"), szResult);
	
	m_edt2DBarcodeResult.SetWindowText(str);
}

void CPaneManualControlVision::OnBnClickedButton2dbarcodeUnload()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
//	gDeviceFactory.GetMotor()->Set2DBarcodeTrigger();
//	Sleep(500);
	
	CString str;
	char szResult[256];
	memset(szResult, 0, sizeof(szResult));
	gDeviceFactory.GetVision()->Get2DBarcode(szResult, FALSE);

	str.Format(_T("%s"), szResult);
	
	m_edt2DBarcodeResult.SetWindowText(str);
}


void CPaneManualControlVision::OnRadioRemote()
{
	m_nRemote = 0;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pScannerCalibration->m_nRemote = 0;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pOneHole->m_nRemote = 0;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pOneHole->UpdateData(FALSE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pScannerCalibration->UpdateData(FALSE);
	gDeviceFactory.GetVision()->UseRemoteControl(!m_nRemote);
	CString strCoaxial, strRing, strIR;
	gDeviceFactory.GetVision()->GetLampValue(m_cmbCamNo.GetCurSel(), strCoaxial, strRing,strIR); 
	
	m_edtCoaxial.SetWindowText(strCoaxial);
	m_edtRing.SetWindowText(strRing);
	m_edtIR.SetWindowText(strIR);

	int nCoaxial, nRing, nIR;
	nCoaxial = atoi(strCoaxial);
	nRing = atoi(strRing);
	nIR = atoi(strIR);

	m_SliderCoaxial.SetPos(nCoaxial);
	m_SliderRing.SetPos(nRing);
	m_SliderIR.SetPos(nIR);

	gDeviceFactory.GetVision()->OnLightAll(m_cmbCamNo.GetCurSel(), nCoaxial, nRing, nIR);

	UpdateData(FALSE);
}
void CPaneManualControlVision::OnRadioManual()
{
	m_nRemote = 1;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pScannerCalibration->m_nRemote = 1;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pOneHole->m_nRemote = 1;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pOneHole->UpdateData(FALSE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pScannerCalibration->UpdateData(FALSE);
	gDeviceFactory.GetVision()->UseRemoteControl(!m_nRemote);

	UpdateData(FALSE);
}

void CPaneManualControlVision::SetvisionParam(VISION_INFO sVisionParam) 
{
	for(int i=0; i<4; i++)
	{
		m_nCoaxial[i] = sVisionParam.nCoaxial[i];
		m_nRing[i] = sVisionParam.nRing[i];
		m_nIR[i] = sVisionParam.nIR[i];
	}
	OnSelchangeComboCamNo();
}

void CPaneManualControlVision::InitSlideControl()
{
	m_SliderCoaxial.SetRange(0, 255);
	m_SliderRing.SetRange(0, 255);
	m_SliderIR.SetRange(0, 255);

	// ��ġ ����.
	m_SliderCoaxial.SetPos(50);
	m_SliderRing.SetPos(50);
	m_SliderIR.SetPos(50);

	// ���� ������ �����Ѵ�.
	// �Ӽ��� Tick Marks�� Auto Ticks�� True�� �Ǿ� �־�� �Ѵ�.
	m_SliderCoaxial.SetTicFreq(10);
	m_SliderRing.SetTicFreq(10);
	m_SliderIR.SetTicFreq(10);

	// Ű���� Ŀ��Ű�� �����̴��� �����϶��� ���� ũ�⸦ ����
	m_SliderCoaxial.SetLineSize(1);
	m_SliderRing.SetLineSize(1);
	m_SliderIR.SetLineSize(1);

	// Ű������ PgUp, PgDnŰ�� �����ų� ���콺�� �����̴��� ������ Ŭ���� ������ ũ�� 
	m_SliderCoaxial.SetPageSize(10);
	m_SliderRing.SetPageSize(10);
	m_SliderIR.SetPageSize(10);
}

void CPaneManualControlVision::OnNMReleasedcaptureSliderCoaxial(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
/*	int nCoaxial = 0;
	CString strData;
	nCoaxial= m_SliderCoaxial.GetPos();
	strData.Format(_T("%d"), nCoaxial);
	m_edtCoaxial.SetWindowText( strData );
*/
	*pResult = 0;
}


void CPaneManualControlVision::OnNMReleasedcaptureSliderRing(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
/*	int nRing = 0;
	CString strData;
	nRing = m_SliderRing.GetPos();
	strData.Format(_T("%d"), nRing);
	m_edtRing.SetWindowText( strData );
*/
	*pResult = 0;
}
void CPaneManualControlVision::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: Add your message handler code here and/or call default
	if(gSystemINI.m_sHardWare.nUseLampRS232)
	{

		if(pScrollBar == (CScrollBar*)&m_SliderCoaxial ||
			pScrollBar == (CScrollBar*)&m_SliderRing ||
			pScrollBar == (CScrollBar*)&m_SliderIR)
		{
			HVision* pVision = gDeviceFactory.GetVision();
			int nCamNo = m_cmbCamNo.GetCurSel();
#ifdef __USE_ONLY_LOW_CAM__
			if(nCamNo == HIGH_1ST_CAM)
				nCamNo = LOW_1ST_CAM;
			else
				nCamNo = LOW_2ND_CAM;
#endif
			int nPosCoax = m_SliderCoaxial.GetPos();
			int nPosRing = m_SliderRing.GetPos();
			int nPosIR = m_SliderIR.GetPos();
			pVision->OnLightAll(nCamNo, nPosCoax, nPosRing, nPosIR);
			CString strCoax = _T("");
			CString strRing = _T("");
			CString strIR = _T("");
			strCoax.Format("%d", nPosCoax);
			m_edtCoaxial.SetWindowText(strCoax);
			strRing.Format("%d", nPosRing);
			m_edtRing.SetWindowText(strRing);
			strIR.Format("%d", nPosIR);
			m_edtIR.SetWindowText(strIR);
			Sleep(1);
		}
	}
	CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
}
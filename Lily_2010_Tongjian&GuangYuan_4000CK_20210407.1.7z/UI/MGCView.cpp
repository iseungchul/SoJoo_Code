// CMGCView.cpp : implementation file
//http://pc.danawa.com/price.html?defSite=PC&pc=pc&cate1=860&cate2=867

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetupMGC.h"
#include "MGCView.h"
#include "..\model\dsystemini.h"

#include "DlgInformationBox.h"
#include "DlgQuestionbox.h"

#include "NAxis.h"
#include "NGrid.h"
#include "NMode.h"

#include <cmath>

#pragma warning (disable:4100)
#pragma warning (disable:4189)

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMGCView

IMPLEMENT_DYNCREATE(CMGCView, CScrollView)

CMGCView::CMGCView() : c_nOffset(20)
{
//	m_dFieldSizeX = SCANNER_FIELD_SIZE;
//	m_dFieldSizeY = SCANNER_FIELD_SIZE;
	m_nXMin=0;
	m_nXMax=0;
	m_nYMin=0;
	m_nYMax=0;
}

CMGCView::~CMGCView()
{
}


BEGIN_MESSAGE_MAP(CMGCView, CScrollView)
	//{{AFX_MSG_MAP(CMGCView)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_RBUTTONDOWN()
	ON_WM_CONTEXTMENU()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMGCView drawing

void CMGCView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	m_dFieldSizeX = gSystemINI.m_sSystemDevice.dFieldSize.x;
	m_dFieldSizeY = gSystemINI.m_sSystemDevice.dFieldSize.y;

	CSize sizeTotal;
	// TODO: calculate the total size of this view

	m_clrNodeColor = RGB(0, 0, 0);
	m_clrBoxColorNormal = RGB(0, 0, 255);
	m_clrBoxColorSelected = RGB(255, 0, 0);
	m_clrBoxColorChanged = RGB(0, 255, 0);
	m_clrDeltaColor = RGB(128, 0, 128);

	m_dZoomFactor = 1.0;
	CRect rectClient;
	GetClientRect(rectClient);
	sizeTotal.cx = int(rectClient.Width() * m_dZoomFactor);
	sizeTotal.cy = int(rectClient.Height() * m_dZoomFactor);

	SetScrollSizes(MM_TEXT, sizeTotal);

	m_rectSelectedInField.left = -1;
	m_rectSelectedInField.top = -1;
	m_rectSelectedInField.right = -1;
	m_rectSelectedInField.bottom = -1;

	m_rectSelectedInAxis.left = -1;
	m_rectSelectedInAxis.top = -1;
	m_rectSelectedInAxis.right = -1;
	m_rectSelectedInAxis.bottom = -1;

	m_nAxis = NAxis::axis_270;
	m_nGrid = NGrid::grid65x65;
	m_bSelectionMode = FALSE;
	m_bPointSelectionMode = FALSE;
	m_bZoomMode = FALSE;
	m_bDrawDelta = FALSE;

	// Selected Node Index �ʱ�ȭ - ����
	ClearNodeSelected();
	// Selected Node Index �ʱ�ȭ - ��

	// Changed Node Index �ʱ�ȭ - ����
	ClearNodeChanged();
	// Changed Node Index �ʱ�ȭ - ��

	// Delta �� �ʱ�ȭ - ����
	ClearDeltaValue();
	// Delta �� �ʱ�ȭ - ��

	// Asc File Data �ʱ�ȭ - ����
	ClearAscFileData();
	// Asc File Data �ʱ�ȭ - ��

	// Data ���� ���� Flag �ʱ�ȭ - ����
	m_bIsModified = FALSE;
	// Data ���� ���� Flag �ʱ�ȭ - ��
}

void CMGCView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
	CRect rectMGCView;
	GetWindowRect(rectMGCView);

	CWnd *pWnd = GetParent();
	pWnd->ScreenToClient(rectMGCView);
	rectMGCView.left -= ::GetSystemMetrics(SM_CXEDGE) / 2;;
	rectMGCView.top -= ::GetSystemMetrics(SM_CYEDGE) / 2;

	CDC *pParentDC = pWnd->GetDC();
	pParentDC->Draw3dRect(
		rectMGCView,
		::GetSysColor(COLOR_3DSHADOW),
		::GetSysColor(COLOR_3DLIGHT));
	pWnd->ReleaseDC(pParentDC);

	DrawNode(pDC);

	if(m_bDrawDelta == TRUE)
	{
		DrawDelta(pDC);
	}

}

/////////////////////////////////////////////////////////////////////////////
// CMGCView diagnostics

#ifdef _DEBUG
void CMGCView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CMGCView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMGCView message handlers

LRESULT CALLBACK CMGCView::WindowProcedure(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	CMGCView *pView = (CMGCView *) CWnd::FromHandlePermanent(hWnd);
	if(pView == NULL)
	{
		pView = new CMGCView;
		pView->Attach(hWnd);
	}

	VERIFY(pView);

	LRESULT lResult = AfxCallWndProc(pView, hWnd, nMsg, wParam, lParam);

	return lResult;
}

BOOL CMGCView::RegisterMGCViewClass(HINSTANCE hInstance)
{
	WNDCLASS wc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hbrBackground = (HBRUSH) ::GetStockObject(WHITE_BRUSH);
	wc.hCursor = (HCURSOR) ::LoadCursor(NULL, IDC_ARROW);
	wc.hIcon = NULL;
	wc.hInstance = hInstance;
	wc.lpfnWndProc = (WNDPROC) CMGCView::WindowProcedure;
	wc.lpszClassName = _T("MGCViewClass");
	wc.lpszMenuName = NULL;
	wc.style = CS_GLOBALCLASS;

	BOOL bResult = (::RegisterClass(&wc) != 0);

	return bResult;
}


void CMGCView::SetAxis(int nAxis)
{
	m_nAxis = nAxis;

#ifdef _DEBUG
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		TRACE(_T("CMGCView : Axis Change to axis_0\n"));
		break;
	case NAxis::axis_90:
		TRACE(_T("CMGCView : Axis Change to axis_90\n"));
		break;
	case NAxis::axis_180:
		TRACE(_T("CMGCView : Axis Change to axis_180\n"));
		break;
	case NAxis::axis_270:
		TRACE(_T("CMGCView : Axis Change to axis_270\n"));
		break;
	case NAxis::axis_left_0:
		TRACE(_T("CMGCView : Axis Change to axis_left_0\n"));
		break;
	case NAxis::axis_left_90:
		TRACE(_T("CMGCView : Axis Change to axis_left_90\n"));
		break;
	case NAxis::axis_left_180:
		TRACE(_T("CMGCView : Axis Change to axis_left_180\n"));
		break;
	case NAxis::axis_left_270:
		TRACE(_T("CMGCView : Axis Change to axis_left_270\n"));
		break;
	}
#endif

}

void CMGCView::ChangeSelectedNode(RECT rectSelectedInField, RECT rectSelectedInAxis)
{
	ClearNodeSelected();
	ClearNodeChanged();
	ClearDeltaValue();

	m_rectSelectedInField = rectSelectedInField;
	m_rectSelectedInAxis = rectSelectedInAxis;

	Invalidate();

}

void CMGCView::DrawNode(CDC *pDC)
{
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		DrawNode_0(pDC);
		break;
	case NAxis::axis_90:
		DrawNode_90(pDC);
		break;
	case NAxis::axis_180:
		DrawNode_180(pDC);
		break;
	case NAxis::axis_270:
		DrawNode_270(pDC);
		break;
	case NAxis::axis_left_0:
		DrawNode_Left_0(pDC);
		break;
	case NAxis::axis_left_90:
		DrawNode_Left_90(pDC);
		break;
	case NAxis::axis_left_180:
		DrawNode_Left_180(pDC);
		break;
	case NAxis::axis_left_270:
		DrawNode_Left_270(pDC);
		break;
	}

}

void CMGCView::DrawNode_0(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : ���� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_0(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	/* ����� ���Ͽ� �ݵ�� ���� - ����
	CBrush br;
	br.CreateSolidBrush(RGB(255, 255, 160));
	CBrush *pBr = pDC->SelectObject(&br);
	pDC->Rectangle(rectField);
	pDC->SelectObject(pBr);
	    ����� ���Ͽ� �ݵ�� ���� - ���� */

	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				rectField.Height() - int(nIterY * double(rectField.Height()) / double(nDivide));
			
			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				pDC->SetPixel(nX, nY, RGB(255, 0, 0));
			}
			else
			{
				pDC->SetPixel(nX, nY, m_clrNodeColor);
			}
			
			/* ����� ���Ͽ� �ݵ�� ���� - ����
			CString strTemp;
			strTemp.Format(_T("(%d,%d)"), nIterX + nXStart, nIterY + nYStart );
			pDC->TextOut(nX, nY, strTemp);
			   ����� ���Ͽ� �ݵ�� ���� - ���� */
		}
	}

	DrawBox_0(pDC);

}

void CMGCView::DrawNode_90(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : ���������� ����
	
	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_90(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	/* ����� ���Ͽ� �ݵ�� ���� - ����
	CBrush br;
	br.CreateSolidBrush(RGB(255, 255, 160));
	CBrush *pBr = pDC->SelectObject(&br);
	pDC->Rectangle(rectField);
	pDC->SelectObject(pBr);
	   ����� ���Ͽ� �ݵ�� ���� - �� */

	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Width()) / double(nDivide));

			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				pDC->SetPixel(nY, nX, RGB(255, 0, 0));
			}
			else
			{
				pDC->SetPixel(nY, nX, m_clrNodeColor);
			}

			/* ����� ���Ͽ� �ݵ�� ���� - ����
			CString strTemp;
			strTemp.Format(_T("(%d,%d)"), nIterX + nXStart, nIterY + nYStart );
			pDC->TextOut(nY, nX, strTemp);
			   ����� ���Ͽ� �ݵ�� ���� - �� */
		}
	}

	DrawBox_90(pDC);

}

void CMGCView::DrawNode_180(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : �Ʒ��� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_180(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	/* ����� ���Ͽ� �ݵ�� ���� - ����
	CBrush br;
	br.CreateSolidBrush(RGB(255, 255, 160));
	CBrush *pBr = pDC->SelectObject(&br);
	pDC->Rectangle(rectField);
	pDC->SelectObject(pBr);
	   ����� ���Ͽ� �ݵ�� ���� - �� */

	// nIterX, nIterY : Axis�� ���� Node Index.
	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Width() - int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Height()) / double(nDivide));

			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				pDC->SetPixel(nX, nY, RGB(255, 0, 0));
			}
			else
			{
				pDC->SetPixel(nX, nY, m_clrNodeColor);
			}

			/* ����� ���Ͽ� �ݵ�� ���� - ����
			CString strTemp;
			strTemp.Format(_T("(%d,%d)"), nIterX + nXStart, nIterY + nYStart);
			pDC->TextOut(nX, nY, strTemp);
			   ����� ���Ͽ� �ݵ�� ���� - �� */
		}
	}

	DrawBox_180(pDC);

}

void CMGCView::DrawNode_270(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���� ����
	// Y �� : ���� :�������� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_270(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	/* ����� ���Ͽ� �ݵ�� ���� - ����
	CBrush br;
	br.CreateSolidBrush(RGB(255, 255, 160));
	CBrush *pBr = pDC->SelectObject(&br);
	pDC->Rectangle(rectField);
	pDC->SelectObject(pBr);
	   ����� ���Ͽ� �ݵ�� ���� - �� */

	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Height() - int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				rectField.Width() - int(nIterY * double(rectField.Width()) / double(nDivide));

			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				pDC->SetPixel(nY, nX, RGB(255, 0, 0));
			}
			else
			{
				pDC->SetPixel(nY, nX, m_clrNodeColor);
			}

			/* ����� ���Ͽ� �ݵ�� ���� - ����
			CString strTemp;
			strTemp.Format(_T("(%d,%d)"), nIterX + nXStart, nIterY + nYStart);
			pDC->TextOut(nY, nX, strTemp);
			   ����� ���Ͽ� �ݵ�� ���� - �� */
		}
	}

	DrawBox_270(pDC);

}

void CMGCView::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CScrollView::OnPrepareDC(pDC, pInfo);
}

void CMGCView::SetGrid(int nGrid)
{
	ClearNodeSelected();

	m_nGrid = nGrid;

#ifdef _DEBUG
	switch(m_nGrid)
	{
	case NGrid::grid3x3:
		TRACE(_T("CMGCView: Grid Change to grid3x3\n"));
		break;
	case NGrid::grid5x5:
		TRACE(_T("CMGCView: Grid Change to grid5x5\n"));
		break;
	case NGrid::grid9x9:
		TRACE(_T("CMGCView: Grid Change to grid9x9\n"));
		break;
	case NGrid::grid17x17:
		TRACE(_T("CMGCView: Grid Change to grid17x17\n"));
		break;
	case NGrid::grid33x33:
		TRACE(_T("CMGCView: Grid Change to grid33x33\n"));
		break;
	case NGrid::grid65x65:
		TRACE(_T("CMGCView: Grid Change to grid65x65\n"));
		break;
	}
#endif

	Invalidate();
}

void CMGCView::DrawBox_0(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : ���� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_0(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	pDC->SelectStockObject(NULL_BRUSH);
	CPen penBoxNormal;
	penBoxNormal.CreatePen(PS_SOLID, 0, m_clrBoxColorNormal);
	CPen *pPenOld = pDC->SelectObject(&penBoxNormal);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = nYEnd - nYStart ; nIterY >= 0 ; nIterY -= nGridIterY )
	{
		nBoxNumberX = 0;
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX += nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				rectField.Height() - int(nIterY * double(rectField.Height()) / double(nDivide));

			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == FALSE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);

				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				CBrush brBoxChanged;
				brBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&brBoxChanged);

				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);

				pDC->SelectObject(pBrushOld);
				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == FALSE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CBrush brBoxChanged;
				brBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&brBoxChanged);

				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);

				pDC->SelectObject(pBrushOld);
			}
			else
			{
				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	pDC->SelectObject(pPenOld);

}

void CMGCView::DrawBox_90(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : ���������� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_90(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	pDC->SelectStockObject(NULL_BRUSH);
	CPen penBoxNormal;
	penBoxNormal.CreatePen(PS_SOLID, 0, m_clrBoxColorNormal);
	CPen *pPenOld = pDC->SelectObject(&penBoxNormal);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX += nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Width()) / double(nDivide));

			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == FALSE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);

				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				CBrush penBoxChanged;
				penBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&penBoxChanged);

				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);

				pDC->SelectObject(pBrushOld);
				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == FALSE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CBrush brBoxChanged;
				brBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&brBoxChanged);

				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);

				pDC->SelectObject(pBrushOld);
			}
			else
			{
				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;

		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	pDC->SelectObject(pPenOld);

}

void CMGCView::DrawBox_180(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : �Ʒ��� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_180(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	pDC->SelectStockObject(NULL_BRUSH);
	CPen penBoxNormal;
	penBoxNormal.CreatePen(PS_SOLID, 0, m_clrBoxColorNormal);
	CPen *pPenOld = pDC->SelectObject(&penBoxNormal);

	// nIterX, nIterY : Axis�� ���� Node Index.
	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd - nXStart ; nIterX >= 0  ; nIterX -= nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Width() - int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Height()) / double(nDivide));

			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == FALSE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);

				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				CBrush penBoxChanged;
				penBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&penBoxChanged);

				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);

				pDC->SelectObject(pBrushOld);
				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == FALSE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CBrush brBoxChanged;
				brBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&brBoxChanged);

				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);

				pDC->SelectObject(pBrushOld);
			}
			else
			{
				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
				break;
	}

	pDC->SelectObject(pPenOld);

}

void CMGCView::DrawBox_270(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���� ����
	// Y �� : ���� :�������� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_270(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	pDC->SelectStockObject(NULL_BRUSH);
	CPen penBoxNormal;
	penBoxNormal.CreatePen(PS_SOLID, 0, m_clrBoxColorNormal);
	CPen *pPenOld = pDC->SelectObject(&penBoxNormal);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = nYEnd - nYStart ; nIterY >= 0 ; nIterY -= nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd - nXStart ; nIterX >= 0 ; nIterX -= nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Height() - int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				rectField.Width() - int(nIterY * double(rectField.Width()) / double(nDivide));

			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == FALSE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);

				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				CBrush penBoxChanged;
				penBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&penBoxChanged);

				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);

				pDC->SelectObject(pBrushOld);
				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == FALSE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CBrush brBoxChanged;
				brBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&brBoxChanged);

				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);

				pDC->SelectObject(pBrushOld);
			}
			else
			{
				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
				break;

	}

	pDC->SelectObject(pPenOld);

}

void CMGCView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	SetCapture();
	//m_bSelectionMode = TRUE;
	m_bPointSelectionMode = TRUE;
	
	m_ptDragStart = point;
	m_ptDragEnd = point;
	DrawSelectionRect(m_ptDragStart, m_ptDragEnd);
	
	CScrollView::OnLButtonDown(nFlags, point);
}

void CMGCView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_bPointSelectionMode == TRUE)
	{
		::ReleaseCapture();
		m_bPointSelectionMode = FALSE;

		DrawSelectionRect(m_ptDragStart, m_ptDragEnd);
		SelectPointNode();
	}
	else if(m_bSelectionMode == TRUE)
	{
		::ReleaseCapture();
		m_bSelectionMode = FALSE;
		
		DrawSelectionRect(m_ptDragStart, m_ptDragEnd);
		SelectNode();		
	}
	
	CScrollView::OnLButtonUp(nFlags, point);
}

void CMGCView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_bPointSelectionMode == TRUE)
	{
		m_bPointSelectionMode = FALSE;
		m_bSelectionMode = TRUE;
	}
	else if(m_bSelectionMode == TRUE)
	{
		DrawSelectionRect(m_ptDragStart, m_ptDragEnd);

		m_ptDragEnd = point;

		DrawSelectionRect(m_ptDragStart, m_ptDragEnd);
	}
	
	CScrollView::OnMouseMove(nFlags, point);
}

void CMGCView::DrawSelectionRect(POINT ptLeftTop, POINT ptRightBottom)
{
	CClientDC dc(this);

	dc.SetROP2(R2_NOT);
	dc.SelectStockObject(NULL_BRUSH);

	dc.Rectangle(
		ptLeftTop.x,
		ptLeftTop.y,
		ptRightBottom.x,
		ptRightBottom.y
		);

}

void CMGCView::SelectNode()
{
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		SelectNode_0();
		break;
	case NAxis::axis_90:
		SelectNode_90();
		break;
	case NAxis::axis_180:
		SelectNode_180();
		break;
	case NAxis::axis_270:
		SelectNode_270();
		break;
	case NAxis::axis_left_0:
		SelectNode_Left_0();
		break;
	case NAxis::axis_left_90:
		SelectNode_Left_90();
		break;
	case NAxis::axis_left_180:
		SelectNode_Left_180();
		break;
	case NAxis::axis_left_270:
		SelectNode_Left_270();
		break;
	}
}

void CMGCView::SelectNode_0()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : ���� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_0(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptDragStart;
	POINT ptDragEnd;
	if(m_ptDragStart.x < m_ptDragEnd.x)
	{
		ptDragStart.x = m_ptDragStart.x;
		ptDragEnd.x = m_ptDragEnd.x;
	}
	else
	{
		ptDragStart.x = m_ptDragEnd.x;
		ptDragEnd.x = m_ptDragStart.x;
	}

	if(m_ptDragStart.y < m_ptDragEnd.y)
	{
		ptDragStart.y = m_ptDragStart.y;
		ptDragEnd.y = m_ptDragEnd.y;
	}
	else
	{
		ptDragStart.y = m_ptDragEnd.y;
		ptDragEnd.y = m_ptDragStart.y;
	}

	dc.DPtoLP(&ptDragStart);
	dc.DPtoLP(&ptDragEnd);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = nYEnd - nYStart ; nIterY >= 0 ; nIterY -= nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX += nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				rectField.Height() - int(nIterY * double(rectField.Height()) / double(nDivide));

			if(nX >= ptDragStart.x && nX <= ptDragEnd.x &&
				nY >= ptDragStart.y && nY <= ptDragEnd.y)
			{

				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] =
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	ptDragStart.x -= int(double(rectField.Width()) / double(nDivide));
	ptDragStart.y -= int(double(rectField.Height()) / double(nDivide));
	ptDragEnd.x += int(double(rectField.Width()) / double(nDivide));
	ptDragEnd.y += int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(&ptDragStart);
	dc.LPtoDP(&ptDragEnd);

	RECT rectRedraw;

	rectRedraw.left = ptDragStart.x;
	rectRedraw.top = ptDragStart.y;
	rectRedraw.right = ptDragEnd.x;
	rectRedraw.bottom = ptDragEnd.y;

	InvalidateRect(&rectRedraw);

}

void CMGCView::ClearNodeSelected()
{
	// Axis ��ǥ�踦 �������� �Ѵ�.
	// ���� X Index, ���� Y Index �� �Ѵ�.

	for(int nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			m_bNodeSelected[nIterX][nIterY] = FALSE;
		}
	}

	TRACE(_T("Clear Node Selected\n"));

}

void CMGCView::SelectNode_90()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : ���������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_90(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptDragStart;
	POINT ptDragEnd;
	if(m_ptDragStart.x < m_ptDragEnd.x)
	{
		ptDragStart.x = m_ptDragStart.x;
		ptDragEnd.x = m_ptDragEnd.x;
	}
	else
	{
		ptDragStart.x = m_ptDragEnd.x;
		ptDragEnd.x = m_ptDragStart.x;
	}

	if(m_ptDragStart.y < m_ptDragEnd.y)
	{
		ptDragStart.y = m_ptDragStart.y;
		ptDragEnd.y = m_ptDragEnd.y;
	}
	else
	{
		ptDragStart.y = m_ptDragEnd.y;
		ptDragEnd.y = m_ptDragStart.y;
	}

	dc.DPtoLP(&ptDragStart);
	dc.DPtoLP(&ptDragEnd);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX += nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Width()) / double(nDivide));

			if(nY >= ptDragStart.x && nY <= ptDragEnd.x &&
				nX >= ptDragStart.y && nX <= ptDragEnd.y)
			{
				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] = 
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
				break;
	}

	ptDragStart.x -= int(double(rectField.Width()) / double(nDivide));
	ptDragStart.y -= int(double(rectField.Height()) / double(nDivide));
	ptDragEnd.x += int(double(rectField.Width()) / double(nDivide));
	ptDragEnd.y += int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(&ptDragStart);
	dc.LPtoDP(&ptDragEnd);

	RECT rectRedraw;

	rectRedraw.left = ptDragStart.x;
	rectRedraw.top = ptDragStart.y;
	rectRedraw.right = ptDragEnd.x;
	rectRedraw.bottom = ptDragEnd.y;

	InvalidateRect(&rectRedraw);

}

void CMGCView::SelectNode_180()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : �Ʒ��� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_180(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptDragStart;
	POINT ptDragEnd;
	if(m_ptDragStart.x < m_ptDragEnd.x)
	{
		ptDragStart.x = m_ptDragStart.x;
		ptDragEnd.x = m_ptDragEnd.x;
	}
	else
	{
		ptDragStart.x = m_ptDragEnd.x;
		ptDragEnd.x = m_ptDragStart.x;
	}

	if(m_ptDragStart.y < m_ptDragEnd.y)
	{
		ptDragStart.y = m_ptDragStart.y;
		ptDragEnd.y = m_ptDragEnd.y;
	}
	else
	{
		ptDragStart.y = m_ptDragEnd.y;
		ptDragEnd.y = m_ptDragStart.y;
	}

	dc.DPtoLP(&ptDragStart);
	dc.DPtoLP(&ptDragEnd);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd - nXStart ; nIterX >= 0  ; nIterX -= nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Width() - int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Height()) / double(nDivide));

			if(nX >= ptDragStart.x && nX <= ptDragEnd.x &&
				nY >= ptDragStart.y && nY <= ptDragEnd.y)
			{
				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] = 
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	ptDragStart.x -= int(double(rectField.Width()) / double(nDivide));
	ptDragStart.y -= int(double(rectField.Height()) / double(nDivide));
	ptDragEnd.x += int(double(rectField.Width()) / double(nDivide));
	ptDragEnd.y += int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(&ptDragStart);
	dc.LPtoDP(&ptDragEnd);

	RECT rectRedraw;

	rectRedraw.left = ptDragStart.x;
	rectRedraw.top = ptDragStart.y;
	rectRedraw.right = ptDragEnd.x;
	rectRedraw.bottom = ptDragEnd.y;

	InvalidateRect(&rectRedraw);

}

void CMGCView::SelectNode_270()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���� ����
	// Y �� : ���� : �������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_270(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptDragStart;
	POINT ptDragEnd;
	if(m_ptDragStart.x < m_ptDragEnd.x)
	{
		ptDragStart.x = m_ptDragStart.x;
		ptDragEnd.x = m_ptDragEnd.x;
	}
	else
	{
		ptDragStart.x = m_ptDragEnd.x;
		ptDragEnd.x = m_ptDragStart.x;
	}

	if(m_ptDragStart.y < m_ptDragEnd.y)
	{
		ptDragStart.y = m_ptDragStart.y;
		ptDragEnd.y = m_ptDragEnd.y;
	}
	else
	{
		ptDragStart.y = m_ptDragEnd.y;
		ptDragEnd.y = m_ptDragStart.y;
	}

	dc.DPtoLP(&ptDragStart);
	dc.DPtoLP(&ptDragEnd);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = nYEnd - nYStart ; nIterY >= 0 ; nIterY -= nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd - nXStart ; nIterX >= 0 ; nIterX -= nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Height() - int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				rectField.Width() - int(nIterY * double(rectField.Width()) / double(nDivide));

			if(nY >= ptDragStart.x && nY <= ptDragEnd.x &&
				nX >= ptDragStart.y && nX <= ptDragEnd.y)
			{
				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] = 
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	ptDragStart.x -= int(double(rectField.Width()) / double(nDivide));
	ptDragStart.y -= int(double(rectField.Height()) / double(nDivide));
	ptDragEnd.x += int(double(rectField.Width()) / double(nDivide));
	ptDragEnd.y += int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(&ptDragStart);
	dc.LPtoDP(&ptDragEnd);

	RECT rectRedraw;

	rectRedraw.left = ptDragStart.x;
	rectRedraw.top = ptDragStart.y;
	rectRedraw.right = ptDragEnd.x;
	rectRedraw.bottom = ptDragEnd.y;

	InvalidateRect(&rectRedraw);

}

void CMGCView::SelectAll()
{
	int nIndexStartX;
	int nIndexEndX;
	int nIndexStartY;
	int nIndexEndY;

	if(m_rectSelectedInAxis.left < m_rectSelectedInAxis.right)
	{
		nIndexStartX = m_rectSelectedInAxis.left;
		nIndexEndX = m_rectSelectedInAxis.right;
	}
	else
	{
		nIndexStartX = m_rectSelectedInAxis.right;
		nIndexEndX = m_rectSelectedInAxis.left;
	}

	if(m_rectSelectedInAxis.top < m_rectSelectedInAxis.bottom)
	{
		nIndexStartY = m_rectSelectedInAxis.top;
		nIndexEndY = m_rectSelectedInAxis.bottom;
	}
	else
	{
		nIndexStartY = m_rectSelectedInAxis.bottom;
		nIndexEndY = m_rectSelectedInAxis.top;
	}

	int nGrid = 8;
	int nGridIterX = (nIndexEndX - nIndexStartX) / 8;
	int nGridIterY = (nIndexEndY - nIndexStartY) / 8;

	switch(m_nGrid)
	{
	case NGrid::grid3x3:
		nGrid = 2;
		nGridIterX = (nIndexEndX - nIndexStartX) / 2;
		nGridIterY = (nIndexEndY - nIndexStartY) / 2;
		break;
	case NGrid::grid5x5:
		nGrid = 4;
		nGridIterX = (nIndexEndX - nIndexStartX) / 4;
		nGridIterY = (nIndexEndY - nIndexStartY) / 4;
		break;
	case NGrid::grid9x9:
		nGrid = 8;
		nGridIterX = (nIndexEndX - nIndexStartX) / 8;
		nGridIterY = (nIndexEndY - nIndexStartY) / 8;
		break;
	case NGrid::grid17x17:
		nGrid = 16;
		nGridIterX = (nIndexEndX - nIndexStartX) / 16;
		nGridIterY = (nIndexEndY - nIndexStartY) / 16;
		break;
	case NGrid::grid33x33:
		nGrid = 32;
		nGridIterX = (nIndexEndX - nIndexStartX) / 32;
		nGridIterY = (nIndexEndY - nIndexStartY) / 32;
		break;
	case NGrid::grid65x65:
		nGrid = 64;
		nGridIterX = (nIndexEndX - nIndexStartX) / 64;
		nGridIterY = (nIndexEndY - nIndexStartY) / 64;
		break;
	}

	if(nGridIterX == 0)
		nGridIterX = 1;
	if(nGridIterY == 0)
		nGridIterY = 1;

	if(!((nIndexStartX >= 0 && nIndexStartX <= 64) &&
		(nIndexStartY >= 0 && nIndexStartY <= 64) &&
		(nIndexEndX >= 0 && nIndexEndX <= 64) &&
		(nIndexEndY >= 0 && nIndexEndY <= 64)))
	{
		TRACE(_T("Invalid Index in select all\n"));
		return;
	}

	int nIterX;
	int nIterY;
	int nBoxNumberX;
	int nBoxNumberY = 0;
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		for(nIterY = nIndexEndY ; nIterY >= nIndexStartY ; nIterY -= nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexStartX ; nIterX <= nIndexEndX ; nIterX += nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = TRUE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
				break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_90:
		for(nIterY = nIndexStartY ; nIterY <= nIndexEndY ; nIterY += nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexStartX ; nIterX <= nIndexEndX ; nIterX += nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = TRUE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_180:
		for(nIterY = nIndexStartY ; nIterY <= nIndexEndY ; nIterY += nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexEndX ; nIterX >= nIndexStartX ; nIterX -= nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = TRUE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_270:
		for(nIterY = nIndexEndY ; nIterY >= nIndexStartY ; nIterY -= nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexEndX ; nIterX >= nIndexStartX ; nIterX -= nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = TRUE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_left_0:
		for(nIterY = nIndexStartY ; nIterY <= nIndexEndY ; nIterY += nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexEndX ; nIterX >= nIndexStartX ; nIterX -= nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = TRUE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_left_90:
		for(nIterY = nIndexStartY ; nIterY <= nIndexEndY ; nIterY += nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexStartX ; nIterX <= nIndexEndX ; nIterX += nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = TRUE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_left_180:
		for(nIterY = nIndexEndY ; nIterY >= nIndexStartY ; nIterY -= nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexStartX ; nIterX <= nIndexEndX ; nIterX += nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = TRUE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_left_270:
		for(nIterY = nIndexEndY ; nIterY >= nIndexStartY ; nIterY -= nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexEndX ; nIterX >= nIndexStartX ; nIterX -= nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = TRUE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
				break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	}
	
	Invalidate();
	
}

void CMGCView::UnselectAll()
{
	int nIndexStartX;
	int nIndexEndX;
	int nIndexStartY;
	int nIndexEndY;

	if(m_rectSelectedInAxis.left < m_rectSelectedInAxis.right)
	{
		nIndexStartX = m_rectSelectedInAxis.left;
		nIndexEndX = m_rectSelectedInAxis.right;
	}
	else
	{
		nIndexStartX = m_rectSelectedInAxis.right;
		nIndexEndX = m_rectSelectedInAxis.left;
	}

	if(m_rectSelectedInAxis.top < m_rectSelectedInAxis.bottom)
	{
		nIndexStartY = m_rectSelectedInAxis.top;
		nIndexEndY = m_rectSelectedInAxis.bottom;
	}
	else
	{
		nIndexStartY = m_rectSelectedInAxis.bottom;
		nIndexEndY = m_rectSelectedInAxis.top;
	}

	int nGrid = 8;
	int nGridIterX = (nIndexEndX - nIndexStartX) / 8;
	int nGridIterY = (nIndexEndY - nIndexStartY) / 8;

	switch(m_nGrid)
	{
	case NGrid::grid3x3:
		nGrid = 2;
		nGridIterX = (nIndexEndX - nIndexStartX) / 2;
		nGridIterY = (nIndexEndY - nIndexStartY) / 2;
		break;
	case NGrid::grid5x5:
		nGrid = 4;
		nGridIterX = (nIndexEndX - nIndexStartX) / 4;
		nGridIterY = (nIndexEndY - nIndexStartY) / 4;
		break;
	case NGrid::grid9x9:
		nGrid = 8;
		nGridIterX = (nIndexEndX - nIndexStartX) / 8;
		nGridIterY = (nIndexEndY - nIndexStartY) / 8;
		break;
	case NGrid::grid17x17:
		nGrid = 16;
		nGridIterX = (nIndexEndX - nIndexStartX) / 16;
		nGridIterY = (nIndexEndY - nIndexStartY) / 16;
		break;
	case NGrid::grid33x33:
		nGrid = 32;
		nGridIterX = (nIndexEndX - nIndexStartX) / 32;
		nGridIterY = (nIndexEndY - nIndexStartY) / 32;
		break;
	case NGrid::grid65x65:
		nGrid = 64;
		nGridIterX = (nIndexEndX - nIndexStartX) / 64;
		nGridIterY = (nIndexEndY - nIndexStartY) / 64;
		break;
	}

	if(nGridIterX == 0)
		nGridIterX = 1;
	if(nGridIterY == 0)
		nGridIterY = 1;

	if(!((nIndexStartX >= 0 && nIndexStartX <= 64) &&
		(nIndexStartY >= 0 && nIndexStartY <= 64) &&
		(nIndexEndX >= 0 && nIndexEndX <= 64) &&
		(nIndexEndY >= 0 && nIndexEndY <= 64)))
	{
		TRACE(_T("Invalid Index in select all\n"));
		return;
	}

	int nIterX;
	int nIterY;
	int nBoxNumberX;
	int nBoxNumberY = 0;
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		for(nIterY = nIndexEndY ; nIterY >= nIndexStartY ; nIterY -= nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexStartX ; nIterX <= nIndexEndX ; nIterX += nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = FALSE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_90:
		for(nIterY = nIndexStartY ; nIterY <= nIndexEndY ; nIterY += nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexStartX ; nIterX <= nIndexEndX ; nIterX += nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = FALSE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_180:
		for(nIterY = nIndexStartY ; nIterY <= nIndexEndY ; nIterY += nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexEndX ; nIterX >= nIndexStartX ; nIterX -= nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = FALSE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_270:
		for(nIterY = nIndexEndY ; nIterY >= nIndexStartY ; nIterY -= nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexEndX ; nIterX >= nIndexStartX ; nIterX -= nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = FALSE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_left_0:
		for(nIterY = nIndexStartY ; nIterY <= nIndexEndY ; nIterY += nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexEndX ; nIterX >= nIndexStartX ; nIterX -= nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = FALSE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_left_90:
		for(nIterY = nIndexStartY ; nIterY <= nIndexEndY ; nIterY += nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexStartX ; nIterX <= nIndexEndX ; nIterX += nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = FALSE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_left_180:
		for(nIterY = nIndexEndY ; nIterY >= nIndexStartY ; nIterY -= nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexStartX ; nIterX <= nIndexEndX ; nIterX += nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = FALSE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_left_270:
		for(nIterY = nIndexEndY ; nIterY >= nIndexStartY ; nIterY -= nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexEndX ; nIterX >= nIndexStartX ; nIterX -= nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = FALSE;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
				break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	}
	
	Invalidate();

}

void CMGCView::Invert()
{
	int nIndexStartX;
	int nIndexEndX;
	int nIndexStartY;
	int nIndexEndY;

	if(m_rectSelectedInAxis.left < m_rectSelectedInAxis.right)
	{
		nIndexStartX = m_rectSelectedInAxis.left;
		nIndexEndX = m_rectSelectedInAxis.right;
	}
	else
	{
		nIndexStartX = m_rectSelectedInAxis.right;
		nIndexEndX = m_rectSelectedInAxis.left;
	}

	if(m_rectSelectedInAxis.top < m_rectSelectedInAxis.bottom)
	{
		nIndexStartY = m_rectSelectedInAxis.top;
		nIndexEndY = m_rectSelectedInAxis.bottom;
	}
	else
	{
		nIndexStartY = m_rectSelectedInAxis.bottom;
		nIndexEndY = m_rectSelectedInAxis.top;
	}

	int nGrid = 8;
	int nGridIterX = (nIndexEndX - nIndexStartX) / 8;
	int nGridIterY = (nIndexEndY - nIndexStartY) / 8;

	switch(m_nGrid)
	{
	case NGrid::grid3x3:
		nGrid = 2;
		nGridIterX = (nIndexEndX - nIndexStartX) / 2;
		nGridIterY = (nIndexEndY - nIndexStartY) / 2;
		break;
	case NGrid::grid5x5:
		nGrid = 4;
		nGridIterX = (nIndexEndX - nIndexStartX) / 4;
		nGridIterY = (nIndexEndY - nIndexStartY) / 4;
		break;
	case NGrid::grid9x9:
		nGrid = 8;
		nGridIterX = (nIndexEndX - nIndexStartX) / 8;
		nGridIterY = (nIndexEndY - nIndexStartY) / 8;
		break;
	case NGrid::grid17x17:
		nGrid = 16;
		nGridIterX = (nIndexEndX - nIndexStartX) / 16;
		nGridIterY = (nIndexEndY - nIndexStartY) / 16;
		break;
	case NGrid::grid33x33:
		nGrid = 32;
		nGridIterX = (nIndexEndX - nIndexStartX) / 32;
		nGridIterY = (nIndexEndY - nIndexStartY) / 32;
		break;
	case NGrid::grid65x65:
		nGrid = 64;
		nGridIterX = (nIndexEndX - nIndexStartX) / 64;
		nGridIterY = (nIndexEndY - nIndexStartY) / 64;
		break;
	}

	if(nGridIterX == 0)
		nGridIterX = 1;
	if(nGridIterY == 0)
		nGridIterY = 1;

	if(!((nIndexStartX >= 0 && nIndexStartX <= 64) &&
		(nIndexStartY >= 0 && nIndexStartY <= 64) &&
		(nIndexEndX >= 0 && nIndexEndX <= 64) &&
		(nIndexEndY >= 0 && nIndexEndY <= 64)))
	{
		TRACE(_T("Invalid Index in select all\n"));
		return;
	}

	int nIterX;
	int nIterY;
	int nBoxNumberX;
	int nBoxNumberY = 0;
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		for(nIterY = nIndexEndY ; nIterY >= nIndexStartY ; nIterY -= nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexStartX ; nIterX <= nIndexEndX ; nIterX += nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = !(m_bNodeSelected[nIterX][nIterY]);
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_90:
		for(nIterY = nIndexStartY ; nIterY <= nIndexEndY ; nIterY += nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexStartX ; nIterX <= nIndexEndX ; nIterX += nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = !(m_bNodeSelected[nIterX][nIterY]);
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_180:
		for(nIterY = nIndexStartY ; nIterY <= nIndexEndY ; nIterY += nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexEndX ; nIterX >= nIndexStartX ; nIterX -= nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = !(m_bNodeSelected[nIterX][nIterY]);
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_270:
		for(nIterY = nIndexEndY ; nIterY >= nIndexStartY ; nIterY -= nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexEndX ; nIterX >= nIndexStartX ; nIterX -= nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = !(m_bNodeSelected[nIterX][nIterY]);
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_left_0:
		for(nIterY = nIndexStartY ; nIterY <= nIndexEndY ; nIterY += nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexEndX ; nIterX >= nIndexStartX ; nIterX -= nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = !(m_bNodeSelected[nIterX][nIterY]);
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_left_90:
		for(nIterY = nIndexStartY ; nIterY <= nIndexEndY ; nIterY += nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexStartX ; nIterX <= nIndexEndX ; nIterX += nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = !(m_bNodeSelected[nIterX][nIterY]);
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_left_180:
		for(nIterY = nIndexEndY ; nIterY >= nIndexStartY ; nIterY -= nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexStartX ; nIterX <= nIndexEndX ; nIterX += nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = !(m_bNodeSelected[nIterX][nIterY]);
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
					break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	case NAxis::axis_left_270:
		for(nIterY = nIndexEndY ; nIterY >= nIndexStartY ; nIterY -= nGridIterY)
		{
			nBoxNumberX = 0;
			for(nIterX = nIndexEndX ; nIterX >= nIndexStartX ; nIterX -= nGridIterX)
			{
				m_bNodeSelected[nIterX][nIterY] = !(m_bNodeSelected[nIterX][nIterY]);;
				
				nBoxNumberX++;
				if(nBoxNumberX > nGrid)
				break;
			}

			nBoxNumberY++;
			if(nBoxNumberY > nGrid)
				break;
		}
		break;
	}
	
	Invalidate();

}

void CMGCView::SetField(double dFieldSizeX, double dFieldSizeY)
{
	m_dFieldSizeX = dFieldSizeX;
	m_dFieldSizeY = dFieldSizeY;
	TRACE(_T("CMGCView: Field Change to %fx%f\n"), m_dFieldSizeX, m_dFieldSizeY);
}

void CMGCView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CScrollView::OnRButtonDown(nFlags, point);
}

void CMGCView::PointZoomIn()
{
	CPaneSysSetupMGC *pParent = (CPaneSysSetupMGC *) GetParent();
	pParent->EnableZoomOut(TRUE);
	pParent->EnableZoomAll(TRUE);

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectClient;
	GetClientRect(rectClient);

	POINT ptCenter;
	ptCenter.x = (rectClient.right - rectClient.left) / 2;
	ptCenter.y = (rectClient.bottom - rectClient.top) / 2;
	dc.DPtoLP(&ptCenter);
	dc.DPtoLP(rectClient);

	// Zoom Factor ���� - ����
	double m_dZoomFactorPrev = m_dZoomFactor;

	// ����� �ڵ� - ����
	m_dZoomFactor += 1.0;
	if(m_dZoomFactor > 10.0)
	{
		m_dZoomFactor = 10.0;
	}
	if(fabs(m_dZoomFactor - 10.0) < 0.5)
	{
		pParent->EnableZoomIn(FALSE);
	}
	// ����� �ڵ� - ��
	
	CSize sizeTotal = GetTotalSize();

	sizeTotal.cx =
		int(sizeTotal.cx * m_dZoomFactor / m_dZoomFactorPrev);
	sizeTotal.cy =
		int(sizeTotal.cy * m_dZoomFactor / m_dZoomFactorPrev);

	SetScrollSizes(MM_TEXT, sizeTotal);
	// Zoom Factor ���� - ��

	ptCenter.x = int(ptCenter.x * m_dZoomFactor / m_dZoomFactorPrev) - rectClient.Width() / 2;
	ptCenter.y = int(ptCenter.y * m_dZoomFactor / m_dZoomFactorPrev) - rectClient.Height() / 2;
	ScrollToPosition(ptCenter);

	Invalidate();
}

void CMGCView::PointZoomOut()
{
	CPaneSysSetupMGC *pParent = (CPaneSysSetupMGC *) GetParent();
	pParent->EnableZoomIn(TRUE);
	pParent->EnableZoomAll(TRUE);

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectClient;
	GetClientRect(rectClient);

	POINT ptCenter;
	ptCenter.x = (rectClient.right - rectClient.left) / 2;
	ptCenter.y = (rectClient.bottom - rectClient.top) / 2;
	dc.DPtoLP(&ptCenter);
	dc.DPtoLP(rectClient);

	// Zoom Factor ���� - ����
	double m_dZoomFactorPrev = m_dZoomFactor;
	
	// ����� �ڵ� - ����
	m_dZoomFactor -= 1.0;
	if(m_dZoomFactor < 1.0)
	{
		m_dZoomFactor = 1.0;
	}
	// ����� �ڵ� - ��

	CSize sizeTotal = GetTotalSize();
	
	sizeTotal.cx =
		int(sizeTotal.cx * m_dZoomFactor / m_dZoomFactorPrev);
	sizeTotal.cy =
		int(sizeTotal.cy * m_dZoomFactor / m_dZoomFactorPrev);
	
	SetScrollSizes(MM_TEXT, sizeTotal);
	// Zoom Factor ���� - ��

	ptCenter.x = int(ptCenter.x * m_dZoomFactor / m_dZoomFactorPrev) - rectClient.Width() / 2;
	ptCenter.y = int(ptCenter.y * m_dZoomFactor / m_dZoomFactorPrev) - rectClient.Height() / 2;

	// ����� �ڵ� - ����
	if(fabs(m_dZoomFactor - 1.0) < 0.5)
	{
		ptCenter.x = 0;
		ptCenter.y = 0;

		pParent->EnableZoomOut(FALSE);
		pParent->EnableZoomAll(FALSE);
	}
	// ����� �ڵ� - ��

	ScrollToPosition(ptCenter);
	
	Invalidate();
	
}

void CMGCView::FindField_0(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : ���� ����

	CSize sizeTotal = GetTotalSize();

	nXStart = m_rectSelectedInAxis.left;
	nXEnd = m_rectSelectedInAxis.right;
	nYStart = m_rectSelectedInAxis.bottom;
	nYEnd = m_rectSelectedInAxis.top;

	if(nXStart == nXEnd && nYStart == nYEnd)
		return;

	int nOffsetX = 0;
	int nOffsetY = 0;
	int nFieldX = 0;
	int nFieldY = 0;

	if(nXEnd - nXStart > nYEnd - nYStart)
	{
		nDivide = nXEnd - nXStart;

		nOffsetX = c_nOffset;
		nFieldX = sizeTotal.cx - nOffsetX * 2;
		nFieldY =
			int(nFieldX * double(nYEnd - nYStart) / double(nXEnd - nXStart));

		nOffsetY = 
			int((nFieldX - nFieldY) / 2.0 - (sizeTotal.cy - nFieldX) / 2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldX;
		rectField.bottom = nFieldX;

		pDC->SetWindowOrg(
		-nOffsetX,
		nOffsetY);

	}
	else
	{
		nDivide = nYEnd - nYStart;

		nOffsetY = c_nOffset;
		nFieldY = sizeTotal.cy - nOffsetY * 2;
		nFieldX = 
			int(nFieldY * double(nXEnd - nXStart) / double(nYEnd - nYStart));

		nOffsetX = 
			int((nFieldY - nFieldX) / 2.0 + (sizeTotal.cx - nFieldY) / 2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldY;
		rectField.bottom = nFieldY;

		pDC->SetWindowOrg(
		-nOffsetX,
		-nOffsetY);

	}

	switch(m_nGrid)
	{
	case NGrid::grid3x3:
		nGrid = 2;
		nGridIterX = (nXEnd - nXStart) / 2;
		nGridIterY = (nYEnd - nYStart) / 2;
		break;
	case NGrid::grid5x5:
		nGrid = 4;
		nGridIterX = (nXEnd - nXStart) / 4;
		nGridIterY = (nYEnd - nYStart) / 4;
		break;
	case NGrid::grid9x9:
		nGrid = 8;
		nGridIterX = (nXEnd - nXStart) / 8;
		nGridIterY = (nYEnd - nYStart) / 8;
		break;
	case NGrid::grid17x17:
		nGrid = 16;
		nGridIterX = (nXEnd - nXStart) / 16;
		nGridIterY = (nYEnd - nYStart) / 16;
		break;
	case NGrid::grid33x33:
		nGrid = 32;
		nGridIterX = (nXEnd - nXStart) / 32;
		nGridIterY = (nYEnd - nYStart) / 32;
		break;
	case NGrid::grid65x65:
		nGrid = 64;
		nGridIterX = (nXEnd - nXStart) / 64;
		nGridIterY = (nYEnd - nYStart) / 64;
		break;
	}

	if(nGridIterX == 0)
		nGridIterX = 1;
	if(nGridIterY == 0)
		nGridIterY = 1;

}

void CMGCView::FindField_90(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : ���������� ����

	CSize sizeTotal = GetTotalSize();

	nXStart = m_rectSelectedInAxis.left;
	nXEnd = m_rectSelectedInAxis.right;
	nYStart = m_rectSelectedInAxis.top;
	nYEnd = m_rectSelectedInAxis.bottom;

	if(nXStart == nXEnd && nYStart == nYEnd)
		return;

	int nOffsetX = 0;
	int nOffsetY = 0;
	int nFieldX = 0;
	int nFieldY = 0;

	if(nXEnd - nXStart >= nYEnd - nYStart)
	{
		nDivide = nXEnd - nXStart;

		nOffsetY = c_nOffset;
		nFieldY = sizeTotal.cy - nOffsetY * 2;
		nFieldX =
			int(nFieldY * double(nYEnd - nYStart) / double(nXEnd - nXStart));

		nOffsetX = 
			int((nFieldY - nFieldX) / 2.0 + (sizeTotal.cx - nFieldY) / 2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldY;
		rectField.bottom = nFieldY;

		pDC->SetWindowOrg(
		-nOffsetX,
		-nOffsetY);
	}
	else
	{
		nDivide = nYEnd - nYStart;

		nOffsetX = c_nOffset;
		nFieldX = sizeTotal.cx - nOffsetX * 2;
		nFieldY = 
			int(nFieldX * double(nXEnd - nXStart) / double(nYEnd - nYStart));

		nOffsetY = 
			int((nFieldX - nFieldY) / 2.0 + (sizeTotal.cy - nFieldX) / 2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldX;
		rectField.bottom = nFieldX;

		pDC->SetWindowOrg(
		-nOffsetX,
		-nOffsetY);
	}

	switch(m_nGrid)
	{
	case NGrid::grid3x3:
		nGrid = 2;
		nGridIterX = (nXEnd - nXStart) / 2;
		nGridIterY = (nYEnd - nYStart) / 2;
		break;
	case NGrid::grid5x5:
		nGrid = 4;
		nGridIterX = (nXEnd - nXStart) / 4;
		nGridIterY = (nYEnd - nYStart) / 4;
		break;
	case NGrid::grid9x9:
		nGrid = 8;
		nGridIterX = (nXEnd - nXStart) / 8;
		nGridIterY = (nYEnd - nYStart) / 8;
		break;
	case NGrid::grid17x17:
		nGrid = 16;
		nGridIterX = (nXEnd - nXStart) / 16;
		nGridIterY = (nYEnd - nYStart) / 16;
		break;
	case NGrid::grid33x33:
		nGrid = 32;
		nGridIterX = (nXEnd - nXStart) / 32;
		nGridIterY = (nYEnd - nYStart) / 32;
		break;
	case NGrid::grid65x65:
		nGrid = 64;
		nGridIterX = (nXEnd - nXStart) / 64;
		nGridIterY = (nYEnd - nYStart) / 64;
		break;
	}

	if(nGridIterX == 0)
		nGridIterX = 1;
	if(nGridIterY == 0)
		nGridIterY = 1;

}

void CMGCView::FindField_180(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : �Ʒ��� ����

	CSize sizeTotal = GetTotalSize();

	nXStart = m_rectSelectedInAxis.right;
	nXEnd = m_rectSelectedInAxis.left;
	nYStart = m_rectSelectedInAxis.top;
	nYEnd = m_rectSelectedInAxis.bottom;

	if(nXStart == nXEnd && nYStart == nYEnd)
		return;

	int nOffsetX = 0;
	int nOffsetY = 0;
	int nFieldX = 0;
	int nFieldY = 0;

	if(nXEnd - nXStart > nYEnd - nYStart)
	{
		nDivide = nXEnd - nXStart;

		nOffsetX = c_nOffset;
		nFieldX = sizeTotal.cx - nOffsetX * 2;
		nFieldY =
			int(nFieldX * double(nYEnd - nYStart) / double(nXEnd - nXStart));

		nOffsetY = 
			int((nFieldX - nFieldY) / 2.0 + (sizeTotal.cy - nFieldX) / 2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldX;
		rectField.bottom = nFieldX;

		pDC->SetWindowOrg(
		-nOffsetX,
		-nOffsetY);
	}
	else
	{
		nDivide = nYEnd - nYStart;

		nOffsetY = c_nOffset;
		nFieldY = sizeTotal.cy - nOffsetY * 2;
		nFieldX = 
			int(nFieldY * double(nXEnd - nXStart) / double(nYEnd - nYStart));
		//nOffsetX = int(double(sizeTotal.cx - nFieldX) / 2.0);

		nOffsetX = int((nFieldY - nFieldX)/2.0 - (sizeTotal.cx - nFieldY)/2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldY;
		rectField.bottom = nFieldY;

		pDC->SetWindowOrg(
		nOffsetX,
		-nOffsetY);
	}

	switch(m_nGrid)
	{
	case NGrid::grid3x3:
		nGrid = 2;
		nGridIterX = (nXEnd - nXStart) / 2;
		nGridIterY = (nYEnd - nYStart) / 2;
		break;
	case NGrid::grid5x5:
		nGrid = 4;
		nGridIterX = (nXEnd - nXStart) / 4;
		nGridIterY = (nYEnd - nYStart) / 4;
		break;
	case NGrid::grid9x9:
		nGrid = 8;
		nGridIterX = (nXEnd - nXStart) / 8;
		nGridIterY = (nYEnd - nYStart) / 8;
		break;
	case NGrid::grid17x17:
		nGrid = 16;
		nGridIterX = (nXEnd - nXStart) / 16;
		nGridIterY = (nYEnd - nYStart) / 16;
		break;
	case NGrid::grid33x33:
		nGrid = 32;
		nGridIterX = (nXEnd - nXStart) / 32;
		nGridIterY = (nYEnd - nYStart) / 32;
		break;
	case NGrid::grid65x65:
		nGrid = 64;
		nGridIterX = (nXEnd - nXStart) / 64;
		nGridIterY = (nYEnd - nYStart) / 64;
		break;
	}

	if(nGridIterX == 0)
		nGridIterX = 1;
	if(nGridIterY == 0)
		nGridIterY = 1;

}

void CMGCView::FindField_270(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���� ����
	// Y �� : ���� :�������� ����

	CSize sizeTotal = GetTotalSize();

	nXStart = m_rectSelectedInAxis.right;
	nXEnd = m_rectSelectedInAxis.left;
	nYStart = m_rectSelectedInAxis.bottom;
	nYEnd = m_rectSelectedInAxis.top;

	if(nXStart == nXEnd && nYStart == nYEnd)
		return;

	int nOffsetX = 0;
	int nOffsetY = 0;
	int nFieldX = 0;
	int nFieldY = 0;

	if(nXEnd - nXStart >= nYEnd - nYStart)
	{
		nDivide = nXEnd - nXStart;

		nOffsetY = c_nOffset;
		nFieldY = sizeTotal.cy - nOffsetY * 2;
		nFieldX =
			int(nFieldY * double(nYEnd - nYStart) / double(nXEnd -nXStart));

		nOffsetX =
			int((nFieldY - nFieldX) / 2.0 - (sizeTotal.cx - nFieldY) / 2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldY;
		rectField.bottom = nFieldY;

		pDC->SetWindowOrg(
		nOffsetX,
		-nOffsetY);
	}
	else
	{
		nDivide = nYEnd - nYStart;

		nOffsetX = c_nOffset;
		nFieldX = sizeTotal.cx - nOffsetX * 2;
		nFieldY =
			int(nFieldX * double(nXEnd - nXStart) / double(nYEnd - nYStart));

		nOffsetY =
			int((nFieldX - nFieldY) / 2.0 - (sizeTotal.cy - nFieldX) / 2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldX;
		rectField.bottom = nFieldX;

		pDC->SetWindowOrg(
		-nOffsetX,
		nOffsetY);
	}

	nGrid;
	nGridIterX;
	nGridIterY;
	switch(m_nGrid)
	{
	case NGrid::grid3x3:
		nGrid = 2;
		nGridIterX = (nXEnd - nXStart) / 2;
		nGridIterY = (nYEnd - nYStart) / 2;
		break;
	case NGrid::grid5x5:
		nGrid = 4;
		nGridIterX = (nXEnd - nXStart) / 4;
		nGridIterY = (nYEnd - nYStart) / 4;
		break;
	case NGrid::grid9x9:
		nGrid = 8;
		nGridIterX = (nXEnd - nXStart) / 8;
		nGridIterY = (nYEnd - nYStart) / 8;
		break;
	case NGrid::grid17x17:
		nGrid = 16;
		nGridIterX = (nXEnd - nXStart) / 16;
		nGridIterY = (nYEnd - nYStart) / 16;
		break;
	case NGrid::grid33x33:
		nGrid = 32;
		nGridIterX = (nXEnd - nXStart) / 32;
		nGridIterY = (nYEnd - nYStart) / 32;
		break;
	case NGrid::grid65x65:
		nGrid = 64;
		nGridIterX = (nXEnd - nXStart) / 64;
		nGridIterY = (nYEnd - nYStart) / 64;
		break;
	}

	if(nGridIterX == 0)
		nGridIterX = 1;
	if(nGridIterY == 0)
		nGridIterY = 1;

	// Choi - Debug2
	/*
	if(nGridIterX > nGridIterY)
		nGridIterY = nGridIterX;
	else if(nGridIterX < nGridIterY)
		nGridIterX = nGridIterY;
		*/
	// Choi - Debug2

}

void CMGCView::SetDrawDelta(BOOL bDrawDelta)
{
	m_bDrawDelta = bDrawDelta;

	TRACE(_T("Draw Delta Flag is set to %d\n"), m_bDrawDelta);

	Invalidate();

}

void CMGCView::DrawDelta(CDC *pDC)
{
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		DrawDelta_0(pDC);
		break;
	case NAxis::axis_90:
		DrawDelta_90(pDC);
		break;
	case NAxis::axis_180:
		DrawDelta_180(pDC);
		break;
	case NAxis::axis_270:
		DrawDelta_270(pDC);
		break;
	case NAxis::axis_left_0:
		DrawDelta_Left_0(pDC);
		break;
	case NAxis::axis_left_90:
		DrawDelta_Left_90(pDC);
		break;
	case NAxis::axis_left_180:
		DrawDelta_Left_180(pDC);
		break;
	case NAxis::axis_left_270:
		DrawDelta_Left_270(pDC);
		break;
	}
}

void CMGCView::CalculateDelta(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY)
{
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		CalculateDelta_0(nMaxDeltaInLsbX, nMaxDeltaInLsbY);
		break;
	case NAxis::axis_90:
		CalculateDelta_90(nMaxDeltaInLsbX, nMaxDeltaInLsbY);
		break;
	case NAxis::axis_180:
		CalculateDelta_180(nMaxDeltaInLsbX, nMaxDeltaInLsbY);
		break;
	case NAxis::axis_270:
		CalculateDelta_270(nMaxDeltaInLsbX, nMaxDeltaInLsbY);
		break;
	case NAxis::axis_left_0:
		CalculateDelta_Left_0(nMaxDeltaInLsbX, nMaxDeltaInLsbY);
		break;
	case NAxis::axis_left_90:
		CalculateDelta_Left_90(nMaxDeltaInLsbX, nMaxDeltaInLsbY);
		break;
	case NAxis::axis_left_180:
		CalculateDelta_Left_180(nMaxDeltaInLsbX, nMaxDeltaInLsbY);
		break;
	case NAxis::axis_left_270:
		CalculateDelta_Left_270(nMaxDeltaInLsbX, nMaxDeltaInLsbY);
		break;
	}

}

void CMGCView::ClearDeltaValue()
{
	// Axis ��ǥ�踦 �������� �Ѵ�.
	// ���� X Index, ���� Y Index �� �Ѵ�.

	for(int nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			m_sizeDelta[nIterX][nIterY].cx = 0;
			m_sizeDelta[nIterX][nIterY].cy = 0;
		}
	}
	
	TRACE(_T("Clear Delta Value\n"));

}

void CMGCView::DrawDelta_0(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : ���� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_0(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nLsbX = int(65535 / 64);
	int nLsbY = int(65535 / 64);

	int nVectorX;
	int nVectorY;

	CPen penDelta;
	penDelta.CreatePen(PS_SOLID, 0, m_clrDeltaColor);
	CPen *pPenOld = pDC->SelectObject(&penDelta);

	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				rectField.Height() - int(nIterY * double(rectField.Height()) / double(nDivide));

			nVectorX = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cx) / double(nLsbX)) *
				double(rectField.Width()) / double(nDivide));
			nVectorY = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cy) / double(nLsbX)) *
				double(rectField.Height()) / double(nDivide));

			pDC->MoveTo(nX, nY);
			pDC->LineTo(nX + nVectorX, nY - nVectorY);
		}
	}

	pDC->SelectObject(pPenOld);

}

void CMGCView::DrawDelta_90(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : ���������� ����
	
	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_90(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nLsbX = int(65535 / 64);
	int nLsbY = int(65535 / 64);

	int nVectorX;
	int nVectorY;

	CPen penDelta;
	penDelta.CreatePen(PS_SOLID, 0, m_clrDeltaColor);
	CPen *pPenOld = pDC->SelectObject(&penDelta);

	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Width()) / double(nDivide));

			nVectorX = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cx) / double(nLsbX)) *
				double(rectField.Height()) / double(nDivide));
			nVectorY = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cy) / double(nLsbX)) *
				double(rectField.Width()) / double(nDivide));

			pDC->MoveTo(nY, nX);
			pDC->LineTo(nY + nVectorY, nX + nVectorX);
		}
	}

	pDC->SelectObject(pPenOld);

}

void CMGCView::DrawDelta_180(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : �Ʒ��� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_180(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nLsbX = int(65535 / 64);
	int nLsbY = int(65535 / 64);

	int nVectorX;
	int nVectorY;

	CPen penDelta;
	penDelta.CreatePen(PS_SOLID, 0, m_clrDeltaColor);
	CPen *pPenOld = pDC->SelectObject(&penDelta);

	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Width() - int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Height()) / double(nDivide));

			nVectorX = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cx) / double(nLsbX)) *
				double(rectField.Width()) / double(nDivide));
			nVectorY = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cy) / double(nLsbX)) *
				double(rectField.Height()) / double(nDivide));

			pDC->MoveTo(nX, nY);
			pDC->LineTo(nX - nVectorX, nY + nVectorY);
		}
	}

	pDC->SelectObject(pPenOld);

}

void CMGCView::DrawDelta_270(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���� ����
	// Y �� : ���� :�������� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_270(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nLsbX = int(65535 / 64);
	int nLsbY = int(65535 / 64);

	int nVectorX;
	int nVectorY;

	CPen penDelta;
	penDelta.CreatePen(PS_SOLID, 0, m_clrDeltaColor);
	CPen *pPenOld = pDC->SelectObject(&penDelta);

	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Height() - int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				rectField.Width() - int(nIterY * double(rectField.Width()) / double(nDivide));

			nVectorX = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cx) / double(nLsbX)) *
				double(rectField.Height()) / double(nDivide));
			nVectorY = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cy) / double(nLsbX)) *
				double(rectField.Width()) / double(nDivide));

			pDC->MoveTo(nY, nX);
			pDC->LineTo(nY - nVectorY, nX - nVectorX);
		}
	}

	pDC->SelectObject(pPenOld);

}

void CMGCView::CalculateDelta_0(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : ���� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_0(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nBoxNumberX;
	int nBoxNumberY = 0;

	for(int nIterY = nYEnd ; nIterY >= nYStart ; nIterY -= nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXStart ; nIterX <= nXEnd ; nIterX += nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				m_bNodeChanged[nIterX][nIterY] = TRUE;

				int nXInterpolationIndexStart = nIterX - nGridIterX;
				int nXInterpolationIndexEnd = nIterX + nGridIterX;
				int nYInterpolationIndexStart = nIterY - nGridIterY;
				int nYInterpolationIndexEnd = nIterY + nGridIterY;

				if(nIterX == nXStart)
					nXInterpolationIndexStart = nIterX;
				
				if(nXEnd - nXStart + 1 > nGrid + 1)
				{
					// nXEnd - nXStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.
					
					if(nIterX == nXStart + nGridIterX * nGrid)
						nXInterpolationIndexEnd = nIterX;
				}
				else
				{
					if(nIterX == nXStart + nGridIterX * (nXEnd - nXStart))
						nXInterpolationIndexEnd = nIterX;
				}
				
				if(nIterY == nYEnd)
					nYInterpolationIndexEnd = nIterY;

				if(nYEnd - nYStart + 1 > nGrid + 1)
				{
					// nYEnd - nYStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.

					if(nIterY == nYEnd - nGridIterY * nGrid)
						nYInterpolationIndexStart = nIterY;
				}
				else
				{
					if(nIterY == nYEnd - nGridIterY * (nYEnd - nYStart))
						nYInterpolationIndexStart = nIterY;
				}

				TRACE(
					_T("\nInterpolation Center Index: (%d, %d)\n"),
					nIterX,
					nIterY
					);
				TRACE(
					_T("Interpolation Start Index: (%d, %d)\n"),
					nXInterpolationIndexStart,
					nYInterpolationIndexStart
					);
				TRACE(
					_T("Interpolation End Index: (%d, %d)\n"),
					nXInterpolationIndexEnd,
					nYInterpolationIndexEnd
					);

				// Interpolation
				m_sizeDelta[nIterX][nIterY].cx += nMaxDeltaInLsbX;
				m_sizeDelta[nIterX][nIterY].cy += nMaxDeltaInLsbY;

				if(nXInterpolationIndexStart != nIterX &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nIterY,
						nYInterpolationIndexEnd
						);
				}
				
				if(nXInterpolationIndexStart != nIterX &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nIterY,
						nYInterpolationIndexEnd
						);
				}

			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}
}

void CMGCView::CalculateDelta_90(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : ���������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_90(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nBoxNumberX;
	int nBoxNumberY = 0;

	for(int nIterY = nYStart ; nIterY <= nYEnd ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXStart ; nIterX <= nXEnd ; nIterX += nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				m_bNodeChanged[nIterX][nIterY] = TRUE;

				int nXInterpolationIndexStart = nIterX - nGridIterX;
				int nXInterpolationIndexEnd = nIterX + nGridIterX;
				int nYInterpolationIndexStart = nIterY - nGridIterY;
				int nYInterpolationIndexEnd = nIterY + nGridIterY;

				if(nIterX == nXStart)
					nXInterpolationIndexStart = nIterX;

				if(nXEnd - nXStart + 1 > nGrid + 1)
				{
					// nXEnd - nXStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.

					if(nIterX == nXStart + nGridIterX * nGrid)
						nXInterpolationIndexEnd = nIterX;
				}
				else
				{
					if(nIterX == nXStart + nGridIterX * (nXEnd - nXStart))
						nXInterpolationIndexEnd = nIterX;
				}

				if(nIterY == nYStart)
					nYInterpolationIndexStart = nIterY;

				if(nYEnd - nYStart + 1 > nGrid + 1)
				{
					// nYEnd - nYStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.

					if(nIterY == nYStart + nGridIterY * nGrid)
						nYInterpolationIndexEnd = nIterY;
				}
				else
				{
					if(nIterY == nYStart + nGridIterY * (nYEnd - nYStart))
						nYInterpolationIndexEnd  = nIterY;
				}

				TRACE(
					_T("\nInterpolation Center Index: (%d, %d)\n"),
					nIterX,
					nIterY
					);
				TRACE(
					_T("Interpolation Start Index: (%d, %d)\n"),
					nXInterpolationIndexStart,
					nYInterpolationIndexStart
					);
				TRACE(
					_T("Interpolation End Index: (%d, %d)\n"),
					nXInterpolationIndexEnd,
					nYInterpolationIndexEnd
					);

				// Interpolation
				m_sizeDelta[nIterX][nIterY].cx += nMaxDeltaInLsbX;
				m_sizeDelta[nIterX][nIterY].cy += nMaxDeltaInLsbY;

				if(nXInterpolationIndexStart != nIterX &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nIterY,
						nYInterpolationIndexEnd
						);
				}
				
				if(nXInterpolationIndexStart != nIterX &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nIterY,
						nYInterpolationIndexEnd
						);
				}
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}
		
		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}
}

void CMGCView::CalculateDelta_180(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : �Ʒ��� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_180(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nBoxNumberX;
	int nBoxNumberY = 0;

	for(int nIterY = nYStart ; nIterY <= nYEnd ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd ; nIterX >= nXStart  ; nIterX -= nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				m_bNodeChanged[nIterX][nIterY] = TRUE;

				int nXInterpolationIndexStart = nIterX - nGridIterX;
				int nXInterpolationIndexEnd = nIterX + nGridIterX;
				int nYInterpolationIndexStart = nIterY - nGridIterY;
				int nYInterpolationIndexEnd = nIterY + nGridIterY;

				if(nIterX == nXEnd)
					nXInterpolationIndexEnd = nIterX;

				if(nXEnd - nXStart + 1 > nGrid + 1)
				{
					// nXEnd - nXStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.

					if(nIterX == nXEnd - nGridIterX * nGrid)
						nXInterpolationIndexStart = nIterX;
				}
				else
				{
					if(nIterX == nXEnd - nGridIterX * (nXEnd - nXStart))
						nXInterpolationIndexStart = nIterX;
				}

				if(nIterY == nYStart)
					nYInterpolationIndexStart = nIterY;

				if(nYEnd - nYStart + 1 > nGrid + 1)
				{
					// nYEnd - nYStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.

					if(nIterY == nYStart + nGridIterY * nGrid)
						nYInterpolationIndexEnd = nIterY;
				}
				else
				{
					if(nIterY == nYStart + nGridIterY * (nYEnd - nYStart))
						nYInterpolationIndexEnd = nIterY;
				}

				TRACE(
					_T("\nInterpolation Center Index: (%d, %d)\n"),
					nIterX,
					nIterY
					);
				TRACE(
					_T("Interpolation Start Index: (%d, %d)\n"),
					nXInterpolationIndexStart,
					nYInterpolationIndexStart
					);
				TRACE(
					_T("Interpolation End Index: (%d, %d)\n"),
					nXInterpolationIndexEnd,
					nYInterpolationIndexEnd
					);

				// Interpolation
				m_sizeDelta[nIterX][nIterY].cx += nMaxDeltaInLsbX;
				m_sizeDelta[nIterX][nIterY].cy += nMaxDeltaInLsbY;

				if(nXInterpolationIndexStart != nIterX &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nIterY,
						nYInterpolationIndexEnd
						);
				}
				
				if(nXInterpolationIndexStart != nIterX &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nIterY,
						nYInterpolationIndexEnd
						);
				}
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}
}

void CMGCView::CalculateDelta_270(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���� ����
	// Y �� : ���� :�������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_270(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nBoxNumberX;
	int nBoxNumberY = 0;

	for(int nIterY = nYEnd ; nIterY >= nYStart ; nIterY -= nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd ; nIterX >= nXStart ; nIterX -= nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				m_bNodeChanged[nIterX][nIterY] = TRUE;

				int nXInterpolationIndexStart = nIterX - nGridIterX;
				int nXInterpolationIndexEnd = nIterX + nGridIterX;
				int nYInterpolationIndexStart = nIterY - nGridIterY;
				int nYInterpolationIndexEnd = nIterY + nGridIterY;

				if(nIterX == nXEnd)
					nXInterpolationIndexEnd = nIterX;

				/*
				if(nIterX - (nGrid - nBoxNumberX) * nGridIterX < nXStart)
				{
					if(nXInterpolationIndexStart < nXStart)
						nXInterpolationIndexStart = nIterX;
				}
				else
				{
				*/
					if(nXEnd - nXStart + 1 > nGrid + 1)
					{
						// nXEnd - nXStart + 1 : Node�� ����
						// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
						// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.
						
						if(nIterX == nXEnd - nGridIterX * nGrid)
							nXInterpolationIndexStart = nIterX;
					}
					else
					{
						if(nIterX == nXEnd - nGridIterX * (nXEnd - nXStart))
							nXInterpolationIndexStart = nIterX;
					}
					/*
				}
				*/

				if(nIterY == nYEnd)
					nYInterpolationIndexEnd = nIterY;

				if(nYEnd - nYStart + 1 > nGrid + 1)
				{
					// nYEnd - nYStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.

					if(nIterY == nYEnd - nGridIterY * nGrid)
						nYInterpolationIndexStart = nIterY;
				}
				else
				{
					if(nIterY == nYEnd - nGridIterY * (nYEnd - nYStart))
						nYInterpolationIndexStart = nIterY;
				}

				TRACE(
					_T("\nInterpolation Center Index: (%d, %d)\n"),
					nIterX,
					nIterY
					);
				TRACE(
					_T("Interpolation Start Index: (%d, %d)\n"),
					nXInterpolationIndexStart,
					nYInterpolationIndexStart
					);
				TRACE(
					_T("Interpolation End Index: (%d, %d)\n"),
					nXInterpolationIndexEnd,
					nYInterpolationIndexEnd
					);

				// Interpolation
				m_sizeDelta[nIterX][nIterY].cx += nMaxDeltaInLsbX;
				m_sizeDelta[nIterX][nIterY].cy += nMaxDeltaInLsbY;

				if(nXInterpolationIndexStart != nIterX &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nIterY,
						nYInterpolationIndexEnd
						);
				}
				
				if(nXInterpolationIndexStart != nIterX &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nIterY,
						nYInterpolationIndexEnd
						);
				}

			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}
}

void CMGCView::FindDivideAndRemainder(int &nDivideX, int &nRemainderX, int &nDivideY, int &nRemainderY, int nXStart, int nXEnd, int nYStart, int nYEnd)
{
	switch(m_nGrid)
	{
	case NGrid::grid3x3:
		nDivideX = (nXEnd - nXStart) / 2;
		nRemainderX = (nXEnd - nXStart) % 2;
		nDivideY = (nYEnd - nYStart) / 2;
		nRemainderY = (nYEnd - nYStart) % 2;
		break;
	case NGrid::grid5x5:
		nDivideX = (nXEnd - nXStart) / 4;
		nRemainderX = (nXEnd - nXStart) % 4;
		nDivideY = (nYEnd - nYStart) / 4;
		nRemainderY = (nYEnd - nYStart) % 4;
		break;
	case NGrid::grid9x9:
		nDivideX = (nXEnd - nXStart) / 8;
		nRemainderX = (nXEnd - nXStart) % 8;
		nDivideY = (nYEnd - nYStart) / 8;
		nRemainderY = (nYEnd - nYStart) % 8;
		break;
	case NGrid::grid17x17:
		nDivideX = (nXEnd - nXStart) / 16;
		nRemainderX = (nXEnd - nXStart) % 16;
		nDivideY = (nYEnd - nYStart) / 16;
		nRemainderY = (nYEnd - nYStart) % 16;
		break;
	case NGrid::grid33x33:
		nDivideX = (nXEnd - nXStart) / 32;
		nRemainderX = (nXEnd - nXStart) % 32;
		nDivideY = (nYEnd - nYStart) / 32;
		nRemainderY = (nYEnd - nYStart) % 32;
		break;
	case NGrid::grid65x65:
		nDivideX = (nXEnd - nXStart) / 64;
		nRemainderX = (nXEnd - nXStart) % 64;
		nDivideY = (nYEnd - nYStart) / 64;
		nRemainderY = (nYEnd - nYStart) % 64;
		break;
	}

}

void CMGCView::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	// TODO: Add your message handler code here
	CMenu menu;
	menu.LoadMenu(IDR_MENU_CONTEXT);

	CMenu *pMenuContext = menu.GetSubMenu(0);
	pMenuContext->TrackPopupMenu(
		TPM_LEFTALIGN | TPM_RIGHTBUTTON,
		point.x, point.y,
		this
		);
}

BOOL CMGCView::ReadAscFile(const CString &strAscFilePath)
{
	int nXAscFileData[65][65];
	int nYAscFileData[65][65];

	CStdioFile fileAsc;
	if(fileAsc.Open(strAscFilePath, CFile::modeRead) == FALSE)
	{
		CDlgInformationBox dlgInformationBox;
		dlgInformationBox.SetTitleContent("ERROR", "Cannot open file.");

		dlgInformationBox.DoModal();

		return FALSE;
	}

	CString strRead;
	fileAsc.Seek(0, CFile::begin);

	// LT Ȯ�� - ����
	fileAsc.ReadString(strRead);
	if(strRead != _T("LT"))
	{
		CDlgInformationBox dlgInformationBox;
		dlgInformationBox.SetTitleContent("ERROR", "This is not asc file.");

		dlgInformationBox.DoModal();

		return FALSE;
	}
	// LT Ȯ�� - ��

	// Index�� Axis��ǥ�踦 �������� �Ѵ�. �տ� ���� X��, �ڿ� ���� Y��
	int nIterX;
	int nIterY;

	// Y�� ���� �б� - ����
	for(nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			if(fileAsc.ReadString(strRead) == FALSE)
			{
				CDlgInformationBox dlgInformationBox;
				dlgInformationBox.SetTitleContent("ERROR", "This is not asc file.");
				
				dlgInformationBox.DoModal();
				
				return FALSE;
			}

			nYAscFileData[nIterX][nIterY] = atoi(strRead);
		}
	}
	// Y�� ���� �б� - ��

	// X�� ���� �б� - ����
	for(nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			if(fileAsc.ReadString(strRead) == FALSE)
			{
				CDlgInformationBox dlgInformationBox;
				dlgInformationBox.SetTitleContent("ERROR", "This is not asc file.");
				
				dlgInformationBox.DoModal();
				
				return FALSE;
			}

			nXAscFileData[nIterX][nIterY] = atoi(strRead);

		}
	}
	// X�� ���� �б� - ��

	// QT Ȯ�� - ����
	fileAsc.ReadString(strRead);
	if(strRead != _T("QT"))
	{
		CDlgInformationBox dlgInformationBox;
		dlgInformationBox.SetTitleContent("ERROR", "This is not asc file.");

		dlgInformationBox.DoModal();

		return FALSE;
	}
	// QT Ȯ�� - ��

	// Asc file Data ä��� - ����
	m_nDistanceMax = 0;
	m_nXMax = 0;
	m_nYMax = 0;
	m_nXMin = 0;
	m_nYMin = 0;
	for(nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			m_nXAscFileData[nIterX][nIterY] =
				nXAscFileData[nIterX][nIterY];
			m_nYAscFileData[nIterX][nIterY] =
				nYAscFileData[nIterX][nIterY];

			double xpow = pow((double)nXAscFileData[nIterX][nIterY],2);
			double ypow = pow((double)nYAscFileData[nIterX][nIterY],2);
			m_nDistanceMax = (int)(max(sqrt(xpow+ypow),m_nDistanceMax));
			m_nXMax = (int)(max(nXAscFileData[nIterX][nIterY],m_nXMax));
			m_nYMax = (int)(max(nYAscFileData[nIterX][nIterY],m_nYMax));
			m_nXMin = (int)(min(nXAscFileData[nIterX][nIterY],m_nXMin));
			m_nYMin = (int)(min(nYAscFileData[nIterX][nIterY],m_nYMin));

			// ������ ����� - ����
			m_sizeDelta[nIterX][nIterY].cx = 0;
			m_sizeDelta[nIterX][nIterY].cy = 0;
			// ������ ����� - ��
		}
	}
	// Asc file Data ä��� - ��

	fileAsc.Close();
	CPaneSysSetupMGC *pParent = (CPaneSysSetupMGC *)GetParent();
	pParent->EnableCalView(TRUE);
	return TRUE;
}

BOOL CMGCView::CheckDeltaLimit(int dXDeltaInLsb, int dYDeltaInLsb)
{
	BOOL bResult = TRUE;

	switch(m_nAxis)
	{
	case NAxis::axis_0:
		bResult = CheckDeltaLimit_0(dXDeltaInLsb, dYDeltaInLsb);
		break;
	case NAxis::axis_90:
		bResult = CheckDeltaLimit_90(dXDeltaInLsb, dYDeltaInLsb);
		break;
	case NAxis::axis_180:
		bResult = CheckDeltaLimit_180(dXDeltaInLsb, dYDeltaInLsb);
		break;
	case NAxis::axis_270:
		bResult = CheckDeltaLimit_270(dXDeltaInLsb, dYDeltaInLsb);
		break;
	case NAxis::axis_left_0:
		bResult = CheckDeltaLimit_Left_0(dXDeltaInLsb, dYDeltaInLsb);
		break;
	case NAxis::axis_left_90:
		bResult = CheckDeltaLimit_Left_90(dXDeltaInLsb, dYDeltaInLsb);
		break;
	case NAxis::axis_left_180:
		bResult = CheckDeltaLimit_Left_180(dXDeltaInLsb, dYDeltaInLsb);
		break;
	case NAxis::axis_left_270:
		bResult = CheckDeltaLimit_Left_270(dXDeltaInLsb, dYDeltaInLsb);
		break;
	}

	return bResult;
}

BOOL CMGCView::SaveAscFile(const CString &strAscFilePath)
{
	// Asc File Data�� �����Ѵ�.
	// Asc File Data�� �������� ���� Data�� �����Ϸ���
	// CMGCView::CombineAscFileDataAndDeltaValue()��
	// ���� ȣ���Ͽ��� �Ѵ�.

	CStdioFile fileAsc;
	if(fileAsc.Open(strAscFilePath, CFile::modeWrite | CFile::modeCreate) == FALSE)
	{
		CDlgInformationBox dlgInformationBox;
		dlgInformationBox.SetTitleContent("ERROR", "Cannot open file.");

		dlgInformationBox.DoModal();

		return FALSE;
	}

	CString strWrite;
	fileAsc.Seek(0, CFile::begin);

	// LT ���� - ����
	fileAsc.WriteString(_T("LT\n"));
	// LT ���� - ��

	// Index�� Axis��ǥ�踦 �������� �Ѵ�. �տ� ���� X��, �ڿ� ���� Y��
	int nIterX;
	int nIterY;

	// Y�� ���� ���� - ����
	for(nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			strWrite.Format(_T("%d\n"), m_nYAscFileData[nIterX][nIterY]);
			fileAsc.WriteString(strWrite);
		}
	}
	// Y�� ���� ���� - ��

	// X�� ���� ���� - ����
	for(nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			strWrite.Format(_T("%d\n"), m_nXAscFileData[nIterX][nIterY]);
			fileAsc.WriteString(strWrite);
		}
	}
	// X�� ���� ���� - ��

	// QT ���� - ����
	fileAsc.WriteString(_T("QT\n"));
	// QT ���� - ��

	return TRUE;
}


BOOL CMGCView::CheckDeltaLimit_0(int dXDeltaInLsb, int dYDeltaInLsb)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : ���� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_0(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	for(int nIterY = nYEnd ; nIterY >= nYStart ; nIterY -= nGridIterY )
	{
		for(int nIterX = nXStart ; nIterX <= nXEnd ; nIterX += nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				if(CheckDeltaLimitX(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterX) == FALSE)
					return FALSE;

				if(CheckDeltaLimitY(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterY) == FALSE)
					return FALSE;
			}

		}

	}

	return TRUE;
}

BOOL CMGCView::CheckDeltaLimit_90(int dXDeltaInLsb, int dYDeltaInLsb)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : ���������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_90(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	for(int nIterY = nYStart ; nIterY <= nYEnd ; nIterY += nGridIterY)
	{
		for(int nIterX = nXStart ; nIterX <= nXEnd ; nIterX += nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				if(CheckDeltaLimitX(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterX) == FALSE)
					return FALSE;

				if(CheckDeltaLimitY(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterY) == FALSE)
					return FALSE;
			}
		}
	}

	return TRUE;
}

BOOL CMGCView::CheckDeltaLimit_180(int dXDeltaInLsb, int dYDeltaInLsb)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : �Ʒ��� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_180(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	for(int nIterY = nYStart ; nIterY <= nYEnd ; nIterY += nGridIterY)
	{
		for(int nIterX = nXEnd ; nIterX >= nXStart  ; nIterX -= nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				if(CheckDeltaLimitX(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterX) == FALSE)
					return FALSE;

				if(CheckDeltaLimitY(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterY) == FALSE)
					return FALSE;
			}
		}
	}

	return TRUE;
}

BOOL CMGCView::CheckDeltaLimit_270(int dXDeltaInLsb, int dYDeltaInLsb)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���� ����
	// Y �� : ���� : �������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_270(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	for(int nIterY = nYEnd ; nIterY >= nYStart ; nIterY -= nGridIterY)
	{
		for(int nIterX = nXEnd ; nIterX >= nXStart ; nIterX -= nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				if(CheckDeltaLimitX(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterX) == FALSE)
					return FALSE;
				
				if(CheckDeltaLimitY(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterY) == FALSE)
					return FALSE;
			}
		}
	}

	return TRUE;
}

BOOL CMGCView::CheckDeltaLimitX(int nIndexX, int nIndexY, int dXDeltaInLsb, int dYDeltaInLsb, int nGridIterX)
{
	if(dXDeltaInLsb >= 0)
	{
//		if(nIndexX == 64)
//		{
//			if(65535 + m_nXAscFileData[nIndexX][nIndexY] + m_sizeDelta[nIndexX][nIndexY].cx + dXDeltaInLsb > 65535)
//				return FALSE;
//		}
//		else
		{
			int nNextIndexX = nIndexX + nGridIterX;
			if(nNextIndexX >= 65)
				nNextIndexX = 64;
			
			if(m_bNodeSelected[nNextIndexX][nIndexY] == TRUE)
				return TRUE;
			
			if((nIndexX * 65535 / 64 + m_nXAscFileData[nIndexX][nIndexY] + m_sizeDelta[nIndexX][nIndexY].cx + dXDeltaInLsb) >
				(nNextIndexX * 65535 / 64 + m_nXAscFileData[nNextIndexX][nIndexY] + m_sizeDelta[nNextIndexX][nIndexY].cx))
			{
				return FALSE;
			}
		}
		
	}
	else if(dXDeltaInLsb < 0)
	{
//		if(nIndexX == 0)
//		{
//			if(0 + m_nXAscFileData[nIndexX][nIndexY] + m_sizeDelta[nIndexX][nIndexY].cx + dXDeltaInLsb < 0)
//				return FALSE;
//		}
//		else
		{
			int nPrevIndexX = nIndexX - nGridIterX;
			if(nPrevIndexX < 0)
				nPrevIndexX = 0;
			
			if(m_bNodeSelected[nPrevIndexX][nIndexY] == TRUE)
				return TRUE;
			
			if((nIndexX * 65535 / 64 + m_nXAscFileData[nIndexX][nIndexY] + m_sizeDelta[nIndexX][nIndexY].cx + dXDeltaInLsb) <
				(nPrevIndexX * 65535 / 64 + m_nXAscFileData[nPrevIndexX][nIndexY] + m_sizeDelta[nPrevIndexX][nIndexY].cx))
			{
				return FALSE;
			}
		}
	}
				
	return TRUE;
}

BOOL CMGCView::CheckDeltaLimitY(int nIndexX, int nIndexY, int dXDeltaInLsb, int dYDeltaInLsb, int nGridIterY)
{
	if(dYDeltaInLsb >= 0)
	{
//		if(nIndexY == 64)
//		{
//			if(65535 + m_nYAscFileData[nIndexX][nIndexY] + m_sizeDelta[nIndexX][nIndexY].cy + dYDeltaInLsb > 65535)
//				return FALSE;
//		}
//		else
		{
			int nNextIndexY = nIndexY + nGridIterY;
			if(nNextIndexY >= 65)
				nNextIndexY = 64;
			
			if(m_bNodeSelected[nIndexX][nNextIndexY] == TRUE)
				return TRUE;
			
			if((nIndexY * 65535 / 64 + m_nYAscFileData[nIndexX][nIndexY] + m_sizeDelta[nIndexX][nIndexY].cy + dYDeltaInLsb) >
				(nNextIndexY * 65535 / 64 + m_nYAscFileData[nIndexX][nNextIndexY] + m_sizeDelta[nIndexX][nNextIndexY].cy))
			{
				return FALSE;
			}
		}
	}
	else if(dYDeltaInLsb < 0)
	{
//		if(nIndexY == 0)
//		{
//			if(0 + m_nYAscFileData[nIndexX][nIndexY] + m_sizeDelta[nIndexX][nIndexY].cy + dYDeltaInLsb < 0)
//				return FALSE;
//		}
//		else
		{
			int nPrevIndexY = nIndexY - nGridIterY;
			if(nPrevIndexY < 0)
				nPrevIndexY = 0;
			
			if(m_bNodeSelected[nIndexX][nPrevIndexY] == TRUE)
				return TRUE;
			
			if((nIndexY * 65535 / 64 + m_nYAscFileData[nIndexX][nIndexY] + m_sizeDelta[nIndexX][nIndexY].cy + dYDeltaInLsb) <
				(nPrevIndexY * 65535 / 64 + m_nYAscFileData[nIndexX][nPrevIndexY] + m_sizeDelta[nIndexX][nPrevIndexY].cy))
			{
				return FALSE;
			}
		}
	}
				
	return TRUE;
}

void CMGCView::setModified(BOOL bIsModified)
{
	m_bIsModified = bIsModified;
}

BOOL CMGCView::getModified()
{
	return (m_bIsModified);
}

void CMGCView::ClearAscFileData()
{
	// Axis ��ǥ�踦 �������� �Ѵ�.
	// ���� X Index, ���� Y Index �� �Ѵ�.

	for(int nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			m_nXAscFileData[nIterX][nIterY] = 0;
			m_nYAscFileData[nIterX][nIterY] = 0;
		}
	}

}

void CMGCView::ClearNodeChanged()
{
	// Axis ��ǥ�踦 �������� �Ѵ�.
	// ���� X Index, ���� Y Index �� �Ѵ�.

	for(int nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			m_bNodeChanged[nIterX][nIterY] = FALSE;
		}
	}

	TRACE(_T("Clear Node Changed\n"));

}

int CMGCView::getNumberOfSelectedNode()
{
	int nNumberOfSelectedNode = 0;

	for(int nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
				nNumberOfSelectedNode++;
		}
	}

	TRACE(_T("\nNumber of Selected Node: %d\n"), nNumberOfSelectedNode);

	return (nNumberOfSelectedNode);
}

void CMGCView::PointZoomAll()
{
	CPaneSysSetupMGC *pParent = (CPaneSysSetupMGC *) GetParent();
	pParent->EnableZoomIn(TRUE);
	pParent->EnableZoomOut(FALSE);
	pParent->EnableZoomAll(FALSE);

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectClient;
	GetClientRect(rectClient);

	POINT ptCenter;
	ptCenter.x = (rectClient.right - rectClient.left) / 2;
	ptCenter.y = (rectClient.bottom - rectClient.top) / 2;
	dc.DPtoLP(&ptCenter);
	dc.DPtoLP(rectClient);

	// Zoom Factor ���� - ����
	double m_dZoomFactorPrev = m_dZoomFactor;
	
	m_dZoomFactor = 1.0;

	CSize sizeTotal = GetTotalSize();
	
	sizeTotal.cx =
		int(sizeTotal.cx * m_dZoomFactor / m_dZoomFactorPrev);
	sizeTotal.cy =
		int(sizeTotal.cy * m_dZoomFactor / m_dZoomFactorPrev);
	
	SetScrollSizes(MM_TEXT, sizeTotal);
	// Zoom Factor ���� - ��

	ptCenter.x = int(ptCenter.x * m_dZoomFactor / m_dZoomFactorPrev) - rectClient.Width() / 2;
	ptCenter.y = int(ptCenter.y * m_dZoomFactor / m_dZoomFactorPrev) - rectClient.Height() / 2;

	// ����� �ڵ� - ����
	if(fabs(m_dZoomFactor - 1.0) < 0.5)
	{
		ptCenter.x = 0;
		ptCenter.y = 0;
	}
	// ����� �ڵ� - ��

	ScrollToPosition(ptCenter);
	
	Invalidate();

}

void CMGCView::SaveTempFile(const CString &strTempFilePath)
{
	CStdioFile file;
	file.Open(strTempFilePath, CFile::modeWrite | CFile::modeCreate);

	int nIterX;
	int nIterY;
	CString strWrite;

	// Selected Node �� Changed Node ���� - ����
	for(nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				strWrite.Format(_T("SNode:%d,%d\n"), nIterX, nIterY);
				file.WriteString(strWrite);
			}
			
			if(m_bNodeChanged[nIterX][nIterY] == TRUE)
			{
				strWrite.Format(_T("CNode:%d,%d\n"), nIterX, nIterY);
				file.WriteString(strWrite);
			}
			
		}
	}
	// Selected Node �� Changed Node ���� - ��

	// Delta Value ���� - ����
	for(nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			strWrite.Format(
				_T("%d,%d\n"),
				m_sizeDelta[nIterX][nIterY].cx,
				m_sizeDelta[nIterX][nIterY].cy
				);

			file.WriteString(strWrite);
		}
	}
	// Delta Value ���� - ��

	file.Close();
}

void CMGCView::CombineAscFileDataAndDeltaValue()
{
	// Asc File Data �� �������� ���Ѵ�.
	// �������� ���� 0���� �ʱ�ȭ �Ϸ��� �ؾ��Ѵ�.

	for(int nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			m_nXAscFileData[nIterX][nIterY] += m_sizeDelta[nIterX][nIterY].cx;
			m_nYAscFileData[nIterX][nIterY] += m_sizeDelta[nIterX][nIterY].cy;
		}
	}
}

void CMGCView::SelectPointNode()
{
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		SelectPointNode_0();
		break;
	case NAxis::axis_90:
		SelectPointNode_90();
		break;
	case NAxis::axis_180:
		SelectPointNode_180();
		break;
	case NAxis::axis_270:
		SelectPointNode_270();
		break;
	case NAxis::axis_left_0:
		SelectPointNode_Left_0();
		break;
	case NAxis::axis_left_90:
		SelectPointNode_Left_90();
		break;
	case NAxis::axis_left_180:
		SelectPointNode_Left_180();
		break;
	case NAxis::axis_left_270:
		SelectPointNode_Left_270();
		break;
	}

}

void CMGCView::SelectPointNode_0()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : ���� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_0(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptPoint;
	ptPoint.x = m_ptDragEnd.x;
	ptPoint.y = m_ptDragEnd.y;

	dc.DPtoLP(&ptPoint);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = nYEnd - nYStart ; nIterY >= 0 ; nIterY -= nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX += nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				rectField.Height() - int(nIterY * double(rectField.Height()) / double(nDivide));

			if(ptPoint.x > nX - 3 && ptPoint.x < nX + 4 &&
				ptPoint.y > nY - 3 && ptPoint.y < nY + 4)
			{
				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] =
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	CRect rectRedraw;
	rectRedraw.left = ptPoint.x - int(double(rectField.Width()) / double(nDivide));
	rectRedraw.top = ptPoint.y - int(double(rectField.Height()) / double(nDivide));
	rectRedraw.right = ptPoint.x + int(double(rectField.Width()) / double(nDivide));
	rectRedraw.bottom = ptPoint.y + int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(rectRedraw);

	InvalidateRect(rectRedraw, TRUE);
}

void CMGCView::SelectPointNode_90()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : ���������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_90(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptPoint;
	ptPoint.x = m_ptDragEnd.x;
	ptPoint.y = m_ptDragEnd.y;

	dc.DPtoLP(&ptPoint);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX += nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Width()) / double(nDivide));

			if(ptPoint.x > nY - 3 && ptPoint.x < nY + 4 &&
				ptPoint.y > nX - 3 && ptPoint.y < nX + 4)
			{
				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] =
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
				break;
	}

	CRect rectRedraw;
	rectRedraw.left = ptPoint.x - int(double(rectField.Width()) / double(nDivide));
	rectRedraw.top = ptPoint.y - int(double(rectField.Height()) / double(nDivide));
	rectRedraw.right = ptPoint.x + int(double(rectField.Width()) / double(nDivide));
	rectRedraw.bottom = ptPoint.y + int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(rectRedraw);

	InvalidateRect(rectRedraw, TRUE);
}

void CMGCView::SelectPointNode_180()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : �Ʒ��� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_180(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptPoint;
	ptPoint.x = m_ptDragEnd.x;
	ptPoint.y = m_ptDragEnd.y;

	dc.DPtoLP(&ptPoint);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd - nXStart ; nIterX >= 0  ; nIterX -= nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Width() - int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Height()) / double(nDivide));

			if(ptPoint.x > nX - 3 && ptPoint.x < nX + 4 &&
				ptPoint.y > nY - 3 && ptPoint.y < nY + 4)
			{
				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] =
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	CRect rectRedraw;
	rectRedraw.left = ptPoint.x - int(double(rectField.Width()) / double(nDivide));
	rectRedraw.top = ptPoint.y - int(double(rectField.Height()) / double(nDivide));
	rectRedraw.right = ptPoint.x + int(double(rectField.Width()) / double(nDivide));
	rectRedraw.bottom = ptPoint.y + int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(rectRedraw);

	InvalidateRect(rectRedraw, TRUE);
}

void CMGCView::SelectPointNode_270()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���� ����
	// Y �� : ���� : �������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_270(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptPoint;
	ptPoint.x = m_ptDragEnd.x;
	ptPoint.y = m_ptDragEnd.y;

	dc.DPtoLP(&ptPoint);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = nYEnd - nYStart ; nIterY >= 0 ; nIterY -= nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd - nXStart ; nIterX >= 0 ; nIterX -= nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Height() - int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				rectField.Width() - int(nIterY * double(rectField.Width()) / double(nDivide));

			if(ptPoint.x > nY - 3 && ptPoint.x < nY + 4 &&
				ptPoint.y > nX - 3 && ptPoint.y < nX + 4)
			{
				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] =
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	CRect rectRedraw;
	rectRedraw.left = ptPoint.x - int(double(rectField.Width()) / double(nDivide));
	rectRedraw.top = ptPoint.y - int(double(rectField.Height()) / double(nDivide));
	rectRedraw.right = ptPoint.x + int(double(rectField.Width()) / double(nDivide));
	rectRedraw.bottom = ptPoint.y + int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(rectRedraw);

	InvalidateRect(rectRedraw, TRUE);
}

void CMGCView::ReadTempFile(const CString &strTempFilePath)
{
	ClearNodeSelected();
	ClearNodeChanged();

	CStdioFile file;
	if(file.Open(strTempFilePath, CFile::modeRead) == FALSE)
		return;

	CString strRead;
	int nIndexX = 0;
	int nIndexY = 0;
	while(file.ReadString(strRead))
	{
		int nIndex;
		if(strRead.Find(_T("SNode:")) == 0)
		{
			nIndex = strRead.Find(_T(','), 0);
			CString strIndexX = strRead.Mid(6, nIndex - 1 - 5);
			CString strIndexY = strRead.Right(strRead.GetLength() - nIndex - 1);

			int nIndexX = ::atoi(strIndexX);
			int nIndexY = ::atoi(strIndexY);

			m_bNodeSelected[nIndexX][nIndexY] = TRUE;
		}
		else if(strRead.Find(_T("CNode:")) == 0)
		{
			nIndex = strRead.Find(_T(','), 0);
			CString strIndexX = strRead.Mid(6, nIndex - 1 - 5);
			CString strIndexY = strRead.Right(strRead.GetLength() - nIndex - 1);

			int nIndexX = ::atoi(strIndexX);
			int nIndexY = ::atoi(strIndexY);

			m_bNodeChanged[nIndexX][nIndexY] = TRUE;
		}
		else
		{
			nIndex = strRead.Find(_T(","));
			CString strDeltaX = strRead.Left(nIndex);
			CString strDeltaY = strRead.Right(strRead.GetLength() - nIndex - 1);

			m_sizeDelta[nIndexX][nIndexY].cx = ::atoi(strDeltaX);
			m_sizeDelta[nIndexX][nIndexY].cy = ::atoi(strDeltaY);

			nIndexX++;
			if(nIndexX > 64)
			{
				nIndexY++;
				nIndexX = 0;
			}

		}

	}
	
	SetDrawDelta(TRUE);

	Invalidate();
}

void CMGCView::BilinearInterpolation(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY, int nXIndexStart, int nXIndexEnd, int nYIndexStart, int nYIndexEnd)
{
	for(int nIterY = nYIndexStart ; nIterY <= nYIndexEnd ; nIterY++)
	{
		for(int nIterX = nXIndexStart ; nIterX <= nXIndexEnd ; nIterX++)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
				continue;

			double t = double(nIterX - nXIndexStart) / double(nXIndexEnd - nXIndexStart);
			double w = double(nIterY - nYIndexStart) / double(nYIndexEnd - nYIndexStart);

			int DeltaX = int(((1 - w) * (1 - t) * m_sizeDelta[nXIndexStart][nYIndexStart].cx) +
				((1 - w) * t * m_sizeDelta[nXIndexEnd][nYIndexStart].cx) +
				(w * t * m_sizeDelta[nXIndexEnd][nYIndexEnd].cx) +
				(w * (1 - t) * m_sizeDelta[nXIndexStart][nYIndexEnd].cx));

			int DeltaY = int(((1 - w) * (1 - t) * m_sizeDelta[nXIndexStart][nYIndexStart].cy) +
				((1 - w) * t * m_sizeDelta[nXIndexEnd][nYIndexStart].cy) +
				(w * t * m_sizeDelta[nXIndexEnd][nYIndexEnd].cy) +
				(w * (1 - t) * m_sizeDelta[nXIndexStart][nYIndexEnd].cy));

			m_sizeDelta[nIterX][nIterY].cx = DeltaX;
				
			m_sizeDelta[nIterX][nIterY].cy = DeltaY;
				

		}
	}

}

void CMGCView::DrawNode_Left_0(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ������ ����
	// Y �� : ���� : �����ʷ� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_0(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = nXEnd - nXStart ; nIterX >= 0 ; nIterX--)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Height() - int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Width()) / double(nDivide));

			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				pDC->SetPixel(nY, nX, RGB(255, 0, 0));
			}
			else
			{
				pDC->SetPixel(nY, nX, m_clrNodeColor);
			}

		}
	}

	DrawBox_Left_0(pDC);

}

void CMGCView::DrawNode_Left_90(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : �Ʒ��� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_90(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	// nIterX, nIterY : Axis�� ���� Node Index.
	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Height()) / double(nDivide));

			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				pDC->SetPixel(nX, nY, RGB(255, 0, 0));
			}
			else
			{
				pDC->SetPixel(nX, nY, m_clrNodeColor);
			}
		}
	}

	DrawBox_Left_90(pDC);

}

void CMGCView::DrawNode_Left_180(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : �������� ����
	
	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_180(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	for(int nIterY = nYEnd - nYStart ; nIterY >= 0 ; nIterY--)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				rectField.Width() - int(nIterY * double(rectField.Width()) / double(nDivide));

			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				pDC->SetPixel(nY, nX, RGB(255, 0, 0));
			}
			else
			{
				pDC->SetPixel(nY, nX, m_clrNodeColor);
			}
		}
	}

	DrawBox_Left_180(pDC);
}

void CMGCView::DrawNode_Left_270(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : ���� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_270(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Width() - int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				rectField.Height() - int(nIterY * double(rectField.Height()) / double(nDivide));
			
			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				pDC->SetPixel(nX, nY, RGB(255, 0, 0));
			}
			else
			{
				pDC->SetPixel(nX, nY, m_clrNodeColor);
			}
		}
	}

	DrawBox_Left_270(pDC);

}

void CMGCView::FindField_Left_0(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ������ ����
	// Y �� : ���� : ���������� ����

	CSize sizeTotal = GetTotalSize();

	nXStart = m_rectSelectedInAxis.right;
	nXEnd = m_rectSelectedInAxis.left;
	nYStart = m_rectSelectedInAxis.top;
	nYEnd = m_rectSelectedInAxis.bottom;

	if(nXStart == nXEnd && nYStart == nYEnd)
		return;

	int nOffsetX = 0;
	int nOffsetY = 0;
	int nFieldX = 0;
	int nFieldY = 0;

	if(nXEnd - nXStart >= nYEnd - nYStart)
	{
		nDivide = nXEnd - nXStart;

		nOffsetY = c_nOffset;
		nFieldY = sizeTotal.cy - nOffsetY * 2;
		nFieldX =
			int(nFieldY * double(nYEnd - nYStart) / double(nXEnd - nXStart));

		nOffsetX = 
			int((nFieldY - nFieldX) / 2.0 + (sizeTotal.cx - nFieldY) / 2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldY;
		rectField.bottom = nFieldY;

		pDC->SetWindowOrg(
		-nOffsetX,
		-nOffsetY);
	}
	else
	{
		nDivide = nYEnd - nYStart;

		nOffsetX = c_nOffset;
		nFieldX = sizeTotal.cx - nOffsetX * 2;
		nFieldY = 
			int(nFieldX * double(nXEnd - nXStart) / double(nYEnd - nYStart));

		nOffsetY = 
			int((nFieldX - nFieldY) / 2.0 + (sizeTotal.cy - nFieldX) / 2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldX;
		rectField.bottom = nFieldX;

		pDC->SetWindowOrg(
		-nOffsetX,
		nOffsetY);
	}

	nGrid;
	nGridIterX;
	nGridIterY;
	switch(m_nGrid)
	{
	case NGrid::grid3x3:
		nGrid = 2;
		nGridIterX = (nXEnd - nXStart) / 2;
		nGridIterY = (nYEnd - nYStart) / 2;
		break;
	case NGrid::grid5x5:
		nGrid = 4;
		nGridIterX = (nXEnd - nXStart) / 4;
		nGridIterY = (nYEnd - nYStart) / 4;
		break;
	case NGrid::grid9x9:
		nGrid = 8;
		nGridIterX = (nXEnd - nXStart) / 8;
		nGridIterY = (nYEnd - nYStart) / 8;
		break;
	case NGrid::grid17x17:
		nGrid = 16;
		nGridIterX = (nXEnd - nXStart) / 16;
		nGridIterY = (nYEnd - nYStart) / 16;
		break;
	case NGrid::grid33x33:
		nGrid = 32;
		nGridIterX = (nXEnd - nXStart) / 32;
		nGridIterY = (nYEnd - nYStart) / 32;
		break;
	case NGrid::grid65x65:
		nGrid = 64;
		nGridIterX = (nXEnd - nXStart) / 64;
		nGridIterY = (nYEnd - nYStart) / 64;
		break;
	}

	if(nGridIterX == 0)
		nGridIterX = 1;
	if(nGridIterY == 0)
		nGridIterY = 1;
}

void CMGCView::DrawBox_Left_0(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ������ ����
	// Y �� : ���� : �����ʷ� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_0(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	pDC->SelectStockObject(NULL_BRUSH);
	CPen penBoxNormal;
	penBoxNormal.CreatePen(PS_SOLID, 0, m_clrBoxColorNormal);
	CPen *pPenOld = pDC->SelectObject(&penBoxNormal);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY +=nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd - nXStart ; nIterX >= 0 ; nIterX -= nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Height() - int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Width()) / double(nDivide));

			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == FALSE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);

				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				CBrush penBoxChanged;
				penBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&penBoxChanged);

				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);

				pDC->SelectObject(pBrushOld);
				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == FALSE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CBrush brBoxChanged;
				brBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&brBoxChanged);

				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);

				pDC->SelectObject(pBrushOld);
			}
			else
			{
				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	pDC->SelectObject(pPenOld);
}

void CMGCView::FindField_Left_90(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : �Ʒ��� ����

	CSize sizeTotal = GetTotalSize();

	nXStart = m_rectSelectedInAxis.left;
	nXEnd = m_rectSelectedInAxis.right;
	nYStart = m_rectSelectedInAxis.top;
	nYEnd = m_rectSelectedInAxis.bottom;

	if(nXStart == nXEnd && nYStart == nYEnd)
		return;

	int nOffsetX = 0;
	int nOffsetY = 0;
	int nFieldX = 0;
	int nFieldY = 0;

	if(nXEnd - nXStart > nYEnd - nYStart)
	{
		nDivide = nXEnd - nXStart;

		nOffsetX = c_nOffset;
		nFieldX = sizeTotal.cx - nOffsetX * 2;
		nFieldY =
			int(nFieldX * double(nYEnd - nYStart) / double(nXEnd - nXStart));

		nOffsetY = 
			int((nFieldX - nFieldY) / 2.0 - (sizeTotal.cy - nFieldX) / 2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldX;
		rectField.bottom = nFieldX;

		pDC->SetWindowOrg(
		-nOffsetX,
		-nOffsetY);
	}
	else
	{
		nDivide = nYEnd - nYStart;

		nOffsetY = c_nOffset;
		nFieldY = sizeTotal.cy - nOffsetY * 2;
		nFieldX = 
			int(nFieldY * double(nXEnd - nXStart) / double(nYEnd - nYStart));
		//nOffsetX = int(double(sizeTotal.cx - nFieldX) / 2.0);

		nOffsetX = int((nFieldY - nFieldX)/2.0 + (sizeTotal.cx - nFieldY)/2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldY;
		rectField.bottom = nFieldY;

		pDC->SetWindowOrg(
		-nOffsetX,
		-nOffsetY);
	}

	switch(m_nGrid)
	{
	case NGrid::grid3x3:
		nGrid = 2;
		nGridIterX = (nXEnd - nXStart) / 2;
		nGridIterY = (nYEnd - nYStart) / 2;
		break;
	case NGrid::grid5x5:
		nGrid = 4;
		nGridIterX = (nXEnd - nXStart) / 4;
		nGridIterY = (nYEnd - nYStart) / 4;
		break;
	case NGrid::grid9x9:
		nGrid = 8;
		nGridIterX = (nXEnd - nXStart) / 8;
		nGridIterY = (nYEnd - nYStart) / 8;
		break;
	case NGrid::grid17x17:
		nGrid = 16;
		nGridIterX = (nXEnd - nXStart) / 16;
		nGridIterY = (nYEnd - nYStart) / 16;
		break;
	case NGrid::grid33x33:
		nGrid = 32;
		nGridIterX = (nXEnd - nXStart) / 32;
		nGridIterY = (nYEnd - nYStart) / 32;
		break;
	case NGrid::grid65x65:
		nGrid = 64;
		nGridIterX = (nXEnd - nXStart) / 64;
		nGridIterY = (nYEnd - nYStart) / 64;
		break;
	}

	if(nGridIterX == 0)
		nGridIterX = 1;
	if(nGridIterY == 0)
		nGridIterY = 1;

}

void CMGCView::FindField_Left_180(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : �������� ����

	CSize sizeTotal = GetTotalSize();

	nXStart = m_rectSelectedInAxis.left;
	nXEnd = m_rectSelectedInAxis.right;
	nYStart = m_rectSelectedInAxis.bottom;
	nYEnd = m_rectSelectedInAxis.top;

	if(nXStart == nXEnd && nYStart == nYEnd)
		return;

	int nOffsetX = 0;
	int nOffsetY = 0;
	int nFieldX = 0;
	int nFieldY = 0;

	if(nXEnd - nXStart >= nYEnd - nYStart)
	{
		nDivide = nXEnd - nXStart;

		nOffsetY = c_nOffset;
		nFieldY = sizeTotal.cy - nOffsetY * 2;
		nFieldX =
			int(nFieldY * double(nYEnd - nYStart) / double(nXEnd - nXStart));

		nOffsetX = 
			int((nFieldY - nFieldX) / 2.0 - (sizeTotal.cx - nFieldY) / 2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldY;
		rectField.bottom = nFieldY;

		pDC->SetWindowOrg(
		nOffsetX,
		-nOffsetY);
	}
	else
	{
		nDivide = nYEnd - nYStart;

		nOffsetX = c_nOffset;
		nFieldX = sizeTotal.cx - nOffsetX * 2;
		nFieldY = 
			int(nFieldX * double(nXEnd - nXStart) / double(nYEnd - nYStart));

		nOffsetY = 
			int((nFieldX - nFieldY) / 2.0 + (sizeTotal.cy - nFieldX) / 2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldX;
		rectField.bottom = nFieldX;

		pDC->SetWindowOrg(
		-nOffsetX,
		-nOffsetY);
	}

	switch(m_nGrid)
	{
	case NGrid::grid3x3:
		nGrid = 2;
		nGridIterX = (nXEnd - nXStart) / 2;
		nGridIterY = (nYEnd - nYStart) / 2;
		break;
	case NGrid::grid5x5:
		nGrid = 4;
		nGridIterX = (nXEnd - nXStart) / 4;
		nGridIterY = (nYEnd - nYStart) / 4;
		break;
	case NGrid::grid9x9:
		nGrid = 8;
		nGridIterX = (nXEnd - nXStart) / 8;
		nGridIterY = (nYEnd - nYStart) / 8;
		break;
	case NGrid::grid17x17:
		nGrid = 16;
		nGridIterX = (nXEnd - nXStart) / 16;
		nGridIterY = (nYEnd - nYStart) / 16;
		break;
	case NGrid::grid33x33:
		nGrid = 32;
		nGridIterX = (nXEnd - nXStart) / 32;
		nGridIterY = (nYEnd - nYStart) / 32;
		break;
	case NGrid::grid65x65:
		nGrid = 64;
		nGridIterX = (nXEnd - nXStart) / 64;
		nGridIterY = (nYEnd - nYStart) / 64;
		break;
	}

	if(nGridIterX == 0)
		nGridIterX = 1;
	if(nGridIterY == 0)
		nGridIterY = 1;

}

void CMGCView::FindField_Left_270(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : ���� ����

	CSize sizeTotal = GetTotalSize();

	nXStart = m_rectSelectedInAxis.right;
	nXEnd = m_rectSelectedInAxis.left;
	nYStart = m_rectSelectedInAxis.bottom;
	nYEnd = m_rectSelectedInAxis.top;

	if(nXStart == nXEnd && nYStart == nYEnd)
		return;

	int nOffsetX = 0;
	int nOffsetY = 0;
	int nFieldX = 0;
	int nFieldY = 0;

	if(nXEnd - nXStart > nYEnd - nYStart)
	{
		nDivide = nXEnd - nXStart;

		nOffsetX = c_nOffset;
		nFieldX = sizeTotal.cx - nOffsetX * 2;
		nFieldY =
			int(nFieldX * double(nYEnd - nYStart) / double(nXEnd - nXStart));

		nOffsetY = 
			int((nFieldX - nFieldY) / 2.0 - (sizeTotal.cy - nFieldX) / 2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldX;
		rectField.bottom = nFieldX;

		pDC->SetWindowOrg(
		-nOffsetX,
		nOffsetY);
	}
	else
	{
		nDivide = nYEnd - nYStart;

		nOffsetY = c_nOffset;
		nFieldY = sizeTotal.cy - nOffsetY * 2;
		nFieldX = 
			int(nFieldY * double(nXEnd - nXStart) / double(nYEnd - nYStart));

		nOffsetX = 
			int((nFieldY - nFieldX) / 2.0 - (sizeTotal.cx - nFieldY) / 2.0);

		rectField.left = 0;
		rectField.top = 0;
		rectField.right = nFieldY;
		rectField.bottom = nFieldY;

		pDC->SetWindowOrg(
		nOffsetX,
		-nOffsetY);
	}

	switch(m_nGrid)
	{
	case NGrid::grid3x3:
		nGrid = 2;
		nGridIterX = (nXEnd - nXStart) / 2;
		nGridIterY = (nYEnd - nYStart) / 2;
		break;
	case NGrid::grid5x5:
		nGrid = 4;
		nGridIterX = (nXEnd - nXStart) / 4;
		nGridIterY = (nYEnd - nYStart) / 4;
		break;
	case NGrid::grid9x9:
		nGrid = 8;
		nGridIterX = (nXEnd - nXStart) / 8;
		nGridIterY = (nYEnd - nYStart) / 8;
		break;
	case NGrid::grid17x17:
		nGrid = 16;
		nGridIterX = (nXEnd - nXStart) / 16;
		nGridIterY = (nYEnd - nYStart) / 16;
		break;
	case NGrid::grid33x33:
		nGrid = 32;
		nGridIterX = (nXEnd - nXStart) / 32;
		nGridIterY = (nYEnd - nYStart) / 32;
		break;
	case NGrid::grid65x65:
		nGrid = 64;
		nGridIterX = (nXEnd - nXStart) / 64;
		nGridIterY = (nYEnd - nYStart) / 64;
		break;
	}

	if(nGridIterX == 0)
		nGridIterX = 1;
	if(nGridIterY == 0)
		nGridIterY = 1;
}

void CMGCView::DrawBox_Left_90(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : �Ʒ��� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_90(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	pDC->SelectStockObject(NULL_BRUSH);
	CPen penBoxNormal;
	penBoxNormal.CreatePen(PS_SOLID, 0, m_clrBoxColorNormal);
	CPen *pPenOld = pDC->SelectObject(&penBoxNormal);

	// nIterX, nIterY : Axis�� ���� Node Index.
	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart  ; nIterX += nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Height()) / double(nDivide));

			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == FALSE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);

				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				CBrush penBoxChanged;
				penBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&penBoxChanged);

				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);

				pDC->SelectObject(pBrushOld);
				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == FALSE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CBrush brBoxChanged;
				brBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&brBoxChanged);

				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);

				pDC->SelectObject(pBrushOld);
			}
			else
			{
				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
				break;
	}

	pDC->SelectObject(pPenOld);
}

void CMGCView::DrawBox_Left_180(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : �������� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_180(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	pDC->SelectStockObject(NULL_BRUSH);
	CPen penBoxNormal;
	penBoxNormal.CreatePen(PS_SOLID, 0, m_clrBoxColorNormal);
	CPen *pPenOld = pDC->SelectObject(&penBoxNormal);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = nYEnd - nYStart ; nIterY >= 0 ; nIterY -= nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX += nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				rectField.Width() - int(nIterY * double(rectField.Width()) / double(nDivide));

			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == FALSE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);

				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				CBrush penBoxChanged;
				penBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&penBoxChanged);

				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);

				pDC->SelectObject(pBrushOld);
				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == FALSE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CBrush brBoxChanged;
				brBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&brBoxChanged);

				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);

				pDC->SelectObject(pBrushOld);
			}
			else
			{
				pDC->Rectangle(nY - 3, nX - 3, nY + 4, nX + 4);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	pDC->SelectObject(pPenOld);

}

void CMGCView::DrawBox_Left_270(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : ���� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_270(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	pDC->SelectStockObject(NULL_BRUSH);
	CPen penBoxNormal;
	penBoxNormal.CreatePen(PS_SOLID, 0, m_clrBoxColorNormal);
	CPen *pPenOld = pDC->SelectObject(&penBoxNormal);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = nYEnd - nYStart ; nIterY >= 0 ; nIterY -= nGridIterY )
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd - nXStart ; nIterX >= 0 ; nIterX -= nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Width() - int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				rectField.Height() - int(nIterY * double(rectField.Height()) / double(nDivide));

			if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == FALSE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);

				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == TRUE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CPen penBoxSelected;
				penBoxSelected.CreatePen(PS_SOLID, 2, m_clrBoxColorSelected);
				CPen *pPenOld = pDC->SelectObject(&penBoxSelected);

				CBrush brBoxChanged;
				brBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&brBoxChanged);

				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);

				pDC->SelectObject(pBrushOld);
				pDC->SelectObject(pPenOld);
			}
			else if(m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] == FALSE &&
				m_bNodeChanged[nIterX + nXStart][nIterY + nYStart] == TRUE)
			{
				CBrush brBoxChanged;
				brBoxChanged.CreateSolidBrush(m_clrBoxColorChanged);
				CBrush *pBrushOld = pDC->SelectObject(&brBoxChanged);

				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);

				pDC->SelectObject(pBrushOld);
			}
			else
			{
				pDC->Rectangle(nX - 3, nY - 3, nX + 4, nY + 4);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	pDC->SelectObject(pPenOld);
}

void CMGCView::SelectNode_Left_0()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���� ����
	// Y �� : ���� : ���������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_0(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptDragStart;
	POINT ptDragEnd;
	if(m_ptDragStart.x < m_ptDragEnd.x)
	{
		ptDragStart.x = m_ptDragStart.x;
		ptDragEnd.x = m_ptDragEnd.x;
	}
	else
	{
		ptDragStart.x = m_ptDragEnd.x;
		ptDragEnd.x = m_ptDragStart.x;
	}

	if(m_ptDragStart.y < m_ptDragEnd.y)
	{
		ptDragStart.y = m_ptDragStart.y;
		ptDragEnd.y = m_ptDragEnd.y;
	}
	else
	{
		ptDragStart.y = m_ptDragEnd.y;
		ptDragEnd.y = m_ptDragStart.y;
	}

	dc.DPtoLP(&ptDragStart);
	dc.DPtoLP(&ptDragEnd);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd - nXStart ; nIterX >= 0 ; nIterX -= nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Height() - int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Width()) / double(nDivide));

			if(nY >= ptDragStart.x && nY <= ptDragEnd.x &&
				nX >= ptDragStart.y && nX <= ptDragEnd.y)
			{
				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] = 
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	ptDragStart.x -= int(double(rectField.Width()) / double(nDivide));
	ptDragStart.y -= int(double(rectField.Height()) / double(nDivide));
	ptDragEnd.x += int(double(rectField.Width()) / double(nDivide));
	ptDragEnd.y += int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(&ptDragStart);
	dc.LPtoDP(&ptDragEnd);

	RECT rectRedraw;

	rectRedraw.left = ptDragStart.x;
	rectRedraw.top = ptDragStart.y;
	rectRedraw.right = ptDragEnd.x;
	rectRedraw.bottom = ptDragEnd.y;

	InvalidateRect(&rectRedraw);
}

void CMGCView::SelectNode_Left_90()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : �Ʒ��� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_90(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptDragStart;
	POINT ptDragEnd;
	if(m_ptDragStart.x < m_ptDragEnd.x)
	{
		ptDragStart.x = m_ptDragStart.x;
		ptDragEnd.x = m_ptDragEnd.x;
	}
	else
	{
		ptDragStart.x = m_ptDragEnd.x;
		ptDragEnd.x = m_ptDragStart.x;
	}

	if(m_ptDragStart.y < m_ptDragEnd.y)
	{
		ptDragStart.y = m_ptDragStart.y;
		ptDragEnd.y = m_ptDragEnd.y;
	}
	else
	{
		ptDragStart.y = m_ptDragEnd.y;
		ptDragEnd.y = m_ptDragStart.y;
	}

	dc.DPtoLP(&ptDragStart);
	dc.DPtoLP(&ptDragEnd);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX += nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Height()) / double(nDivide));

			if(nX >= ptDragStart.x && nX <= ptDragEnd.x &&
				nY >= ptDragStart.y && nY <= ptDragEnd.y)
			{
				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] = 
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	ptDragStart.x -= int(double(rectField.Width()) / double(nDivide));
	ptDragStart.y -= int(double(rectField.Height()) / double(nDivide));
	ptDragEnd.x += int(double(rectField.Width()) / double(nDivide));
	ptDragEnd.y += int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(&ptDragStart);
	dc.LPtoDP(&ptDragEnd);

	RECT rectRedraw;

	rectRedraw.left = ptDragStart.x;
	rectRedraw.top = ptDragStart.y;
	rectRedraw.right = ptDragEnd.x;
	rectRedraw.bottom = ptDragEnd.y;

	InvalidateRect(&rectRedraw);

}

void CMGCView::SelectNode_Left_180()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : ���������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_180(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptDragStart;
	POINT ptDragEnd;
	if(m_ptDragStart.x < m_ptDragEnd.x)
	{
		ptDragStart.x = m_ptDragStart.x;
		ptDragEnd.x = m_ptDragEnd.x;
	}
	else
	{
		ptDragStart.x = m_ptDragEnd.x;
		ptDragEnd.x = m_ptDragStart.x;
	}

	if(m_ptDragStart.y < m_ptDragEnd.y)
	{
		ptDragStart.y = m_ptDragStart.y;
		ptDragEnd.y = m_ptDragEnd.y;
	}
	else
	{
		ptDragStart.y = m_ptDragEnd.y;
		ptDragEnd.y = m_ptDragStart.y;
	}

	dc.DPtoLP(&ptDragStart);
	dc.DPtoLP(&ptDragEnd);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = nYEnd - nYStart ; nIterY >= 0 ; nIterY -= nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX += nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				rectField.Width() - int(nIterY * double(rectField.Width()) / double(nDivide));

			if(nY >= ptDragStart.x && nY <= ptDragEnd.x &&
				nX >= ptDragStart.y && nX <= ptDragEnd.y)
			{
				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] = 
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
				break;
	}

	ptDragStart.x -= int(double(rectField.Width()) / double(nDivide));
	ptDragStart.y -= int(double(rectField.Height()) / double(nDivide));
	ptDragEnd.x += int(double(rectField.Width()) / double(nDivide));
	ptDragEnd.y += int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(&ptDragStart);
	dc.LPtoDP(&ptDragEnd);

	RECT rectRedraw;

	rectRedraw.left = ptDragStart.x;
	rectRedraw.top = ptDragStart.y;
	rectRedraw.right = ptDragEnd.x;
	rectRedraw.bottom = ptDragEnd.y;

	InvalidateRect(&rectRedraw);
}

void CMGCView::SelectNode_Left_270()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : ���� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_270(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptDragStart;
	POINT ptDragEnd;
	if(m_ptDragStart.x < m_ptDragEnd.x)
	{
		ptDragStart.x = m_ptDragStart.x;
		ptDragEnd.x = m_ptDragEnd.x;
	}
	else
	{
		ptDragStart.x = m_ptDragEnd.x;
		ptDragEnd.x = m_ptDragStart.x;
	}

	if(m_ptDragStart.y < m_ptDragEnd.y)
	{
		ptDragStart.y = m_ptDragStart.y;
		ptDragEnd.y = m_ptDragEnd.y;
	}
	else
	{
		ptDragStart.y = m_ptDragEnd.y;
		ptDragEnd.y = m_ptDragStart.y;
	}

	dc.DPtoLP(&ptDragStart);
	dc.DPtoLP(&ptDragEnd);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = nYEnd - nYStart ; nIterY >= 0 ; nIterY -= nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd - nXStart ; nIterX >= 0 ; nIterX -= nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Width() - int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				rectField.Height() - int(nIterY * double(rectField.Height()) / double(nDivide));

			if(nX >= ptDragStart.x && nX <= ptDragEnd.x &&
				nY >= ptDragStart.y && nY <= ptDragEnd.y)
			{

				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] =
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	ptDragStart.x -= int(double(rectField.Width()) / double(nDivide));
	ptDragStart.y -= int(double(rectField.Height()) / double(nDivide));
	ptDragEnd.x += int(double(rectField.Width()) / double(nDivide));
	ptDragEnd.y += int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(&ptDragStart);
	dc.LPtoDP(&ptDragEnd);

	RECT rectRedraw;

	rectRedraw.left = ptDragStart.x;
	rectRedraw.top = ptDragStart.y;
	rectRedraw.right = ptDragEnd.x;
	rectRedraw.bottom = ptDragEnd.y;

	InvalidateRect(&rectRedraw);

}

void CMGCView::SelectPointNode_Left_0()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���� ����
	// Y �� : ���� : ���������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_0(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptPoint;
	ptPoint.x = m_ptDragEnd.x;
	ptPoint.y = m_ptDragEnd.y;

	dc.DPtoLP(&ptPoint);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd - nXStart ; nIterX >= 0 ; nIterX -= nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Height() - int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Width()) / double(nDivide));

			if(ptPoint.x > nY - 3 && ptPoint.x < nY + 4 &&
				ptPoint.y > nX - 3 && ptPoint.y < nX + 4)
			{
				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] =
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	CRect rectRedraw;
	rectRedraw.left = ptPoint.x - int(double(rectField.Width()) / double(nDivide));
	rectRedraw.top = ptPoint.y - int(double(rectField.Height()) / double(nDivide));
	rectRedraw.right = ptPoint.x + int(double(rectField.Width()) / double(nDivide));
	rectRedraw.bottom = ptPoint.y + int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(rectRedraw);

	InvalidateRect(rectRedraw, TRUE);
}

void CMGCView::SelectPointNode_Left_90()
{
    // Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : �Ʒ��� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_90(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptPoint;
	ptPoint.x = m_ptDragEnd.x;
	ptPoint.y = m_ptDragEnd.y;

	dc.DPtoLP(&ptPoint);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart  ; nIterX += nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Height()) / double(nDivide));

			if(ptPoint.x > nX - 3 && ptPoint.x < nX + 4 &&
				ptPoint.y > nY - 3 && ptPoint.y < nY + 4)
			{
				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] =
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	CRect rectRedraw;
	rectRedraw.left = ptPoint.x - int(double(rectField.Width()) / double(nDivide));
	rectRedraw.top = ptPoint.y - int(double(rectField.Height()) / double(nDivide));
	rectRedraw.right = ptPoint.x + int(double(rectField.Width()) / double(nDivide));
	rectRedraw.bottom = ptPoint.y + int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(rectRedraw);

	InvalidateRect(rectRedraw, TRUE);
}

void CMGCView::SelectPointNode_Left_180()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : �������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_180(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptPoint;
	ptPoint.x = m_ptDragEnd.x;
	ptPoint.y = m_ptDragEnd.y;

	dc.DPtoLP(&ptPoint);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = nYEnd - nYStart ; nIterY >= 0 ; nIterY -= nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX += nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				rectField.Width() - int(nIterY * double(rectField.Width()) / double(nDivide));

			if(ptPoint.x > nY - 3 && ptPoint.x < nY + 4 &&
				ptPoint.y > nX - 3 && ptPoint.y < nX + 4)
			{
				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] =
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
				break;
	}

	CRect rectRedraw;
	rectRedraw.left = ptPoint.x - int(double(rectField.Width()) / double(nDivide));
	rectRedraw.top = ptPoint.y - int(double(rectField.Height()) / double(nDivide));
	rectRedraw.right = ptPoint.x + int(double(rectField.Width()) / double(nDivide));
	rectRedraw.bottom = ptPoint.y + int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(rectRedraw);

	InvalidateRect(rectRedraw, TRUE);
}

void CMGCView::SelectPointNode_Left_270()
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : ���� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_270(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	POINT ptPoint;
	ptPoint.x = m_ptDragEnd.x;
	ptPoint.y = m_ptDragEnd.y;

	dc.DPtoLP(&ptPoint);

	int nBoxNumberX;
	int nBoxNumberY = 0;
	for(int nIterY = nYEnd - nYStart ; nIterY >= 0 ; nIterY -= nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd - nXStart ; nIterX >= 0 ; nIterX -= nGridIterX)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Width() - int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				rectField.Height() - int(nIterY * double(rectField.Height()) / double(nDivide));

			if(ptPoint.x > nX - 3 && ptPoint.x < nX + 4 &&
				ptPoint.y > nY - 3 && ptPoint.y < nY + 4)
			{
				m_bNodeSelected[nIterX + nXStart][nIterY + nYStart] =
					(! m_bNodeSelected[nIterX + nXStart][nIterY + nYStart]);
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

	CRect rectRedraw;
	rectRedraw.left = ptPoint.x - int(double(rectField.Width()) / double(nDivide));
	rectRedraw.top = ptPoint.y - int(double(rectField.Height()) / double(nDivide));
	rectRedraw.right = ptPoint.x + int(double(rectField.Width()) / double(nDivide));
	rectRedraw.bottom = ptPoint.y + int(double(rectField.Height()) / double(nDivide));

	dc.LPtoDP(rectRedraw);

	InvalidateRect(rectRedraw, TRUE);
}

BOOL CMGCView::CheckDeltaLimit_Left_0(int dXDeltaInLsb, int dYDeltaInLsb)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���� ����
	// Y �� : ���� : ���������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_0(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	for(int nIterY = nYStart ; nIterY <= nYEnd ; nIterY += nGridIterY)
	{
		for(int nIterX = nXEnd ; nIterX >= nXStart ; nIterX -= nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				if(CheckDeltaLimitX(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterX) == FALSE)
					return FALSE;
				
				if(CheckDeltaLimitY(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterY) == FALSE)
					return FALSE;
			}
		}
	}

	return TRUE;
}

BOOL CMGCView::CheckDeltaLimit_Left_90(int dXDeltaInLsb, int dYDeltaInLsb)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : �Ʒ��� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_90(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	for(int nIterY = nYStart ; nIterY <= nYEnd ; nIterY += nGridIterY)
	{
		for(int nIterX = nXStart ; nIterX <= nXEnd ; nIterX += nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				if(CheckDeltaLimitX(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterX) == FALSE)
					return FALSE;

				if(CheckDeltaLimitY(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterY) == FALSE)
					return FALSE;
			}
		}
	}

	return TRUE;
}

BOOL CMGCView::CheckDeltaLimit_Left_180(int dXDeltaInLsb, int dYDeltaInLsb)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : �������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_180(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	for(int nIterY = nYEnd ; nIterY >= nYStart ; nIterY -= nGridIterY)
	{
		for(int nIterX = nXStart ; nIterX <= nXEnd ; nIterX += nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				if(CheckDeltaLimitX(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterX) == FALSE)
					return FALSE;

				if(CheckDeltaLimitY(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterY) == FALSE)
					return FALSE;
			}
		}
	}

	return TRUE;
}

BOOL CMGCView::CheckDeltaLimit_Left_270(int dXDeltaInLsb, int dYDeltaInLsb)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : ���� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_270(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	for(int nIterY = nYEnd ; nIterY >= nYStart ; nIterY -= nGridIterY )
	{
		for(int nIterX = nXEnd ; nIterX >= nXStart ; nIterX -= nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				if(CheckDeltaLimitX(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterX) == FALSE)
					return FALSE;

				if(CheckDeltaLimitY(nIterX, nIterY, dXDeltaInLsb, dYDeltaInLsb, nGridIterY) == FALSE)
					return FALSE;
			}

		}

	}

	return TRUE;
}

void CMGCView::CalculateDelta_Left_0(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���� ����
	// Y �� : ���� :���������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_0(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nBoxNumberX;
	int nBoxNumberY = 0;

	for(int nIterY = nYStart ; nIterY <= nYEnd ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd ; nIterX >= nXStart ; nIterX -= nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				m_bNodeChanged[nIterX][nIterY] = TRUE;

				int nXInterpolationIndexStart = nIterX - nGridIterX;
				int nXInterpolationIndexEnd = nIterX + nGridIterX;
				int nYInterpolationIndexStart = nIterY - nGridIterY;
				int nYInterpolationIndexEnd = nIterY + nGridIterY;

				if(nIterX == nXEnd)
					nXInterpolationIndexEnd = nIterX;

				if(nXEnd - nXStart + 1 > nGrid + 1)
				{
					// nXEnd - nXStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.

					if(nIterX == nXEnd - nGridIterX * nGrid)
						nXInterpolationIndexStart = nIterX;
				}
				else
				{
					if(nIterX == nXEnd - nGridIterX * (nXEnd - nXStart))
						nXInterpolationIndexStart = nIterX;
				}

				if(nIterY == nYStart)
					nYInterpolationIndexStart = nIterY;

				if(nYEnd - nYStart + 1 > nGrid + 1)
				{
					// nYEnd - nYStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.

					if(nIterY == nYStart + nGridIterY * nGrid)
						nYInterpolationIndexEnd = nIterY;
				}
				else
				{
					if(nIterY == nYStart + nGridIterY * (nYEnd - nYStart))
						nYInterpolationIndexEnd = nIterY;
				}

				TRACE(
					_T("\nInterpolation Center Index: (%d, %d)\n"),
					nIterX,
					nIterY
					);
				TRACE(
					_T("Interpolation Start Index: (%d, %d)\n"),
					nXInterpolationIndexStart,
					nYInterpolationIndexStart
					);
				TRACE(
					_T("Interpolation End Index: (%d, %d)\n"),
					nXInterpolationIndexEnd,
					nYInterpolationIndexEnd
					);

				// Interpolation
				m_sizeDelta[nIterX][nIterY].cx += nMaxDeltaInLsbX;
				m_sizeDelta[nIterX][nIterY].cy += nMaxDeltaInLsbY;

				if(nXInterpolationIndexStart != nIterX &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nIterY,
						nYInterpolationIndexEnd
						);
				}
				
				if(nXInterpolationIndexStart != nIterX &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nIterY,
						nYInterpolationIndexEnd
						);
				}

			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

}

void CMGCView::CalculateDelta_Left_90(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : �Ʒ��� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_90(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nBoxNumberX;
	int nBoxNumberY = 0;

	for(int nIterY = nYStart ; nIterY <= nYEnd ; nIterY += nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXStart ; nIterX <= nXEnd ; nIterX += nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				m_bNodeChanged[nIterX][nIterY] = TRUE;

				int nXInterpolationIndexStart = nIterX - nGridIterX;
				int nXInterpolationIndexEnd = nIterX + nGridIterX;
				int nYInterpolationIndexStart = nIterY - nGridIterY;
				int nYInterpolationIndexEnd = nIterY + nGridIterY;

				if(nIterX == nXStart)
					nXInterpolationIndexStart = nIterX;

				if(nXEnd - nXStart + 1 > nGrid + 1)
				{
					// nXEnd - nXStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.

					if(nIterX == nXStart + nGridIterX * nGrid)
						nXInterpolationIndexEnd = nIterX;
				}
				else
				{
					if(nIterX == nXStart + nGridIterX * (nXEnd - nXStart))
						nXInterpolationIndexEnd = nIterX;
				}

				if(nIterY == nYStart)
					nYInterpolationIndexStart = nIterY;

				if(nYEnd - nYStart + 1 > nGrid + 1)
				{
					// nYEnd - nYStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.

					if(nIterY == nYStart + nGridIterY * nGrid)
						nYInterpolationIndexEnd = nIterY;
				}
				else
				{
					if(nIterY == nYStart + nGridIterY * (nYEnd - nYStart))
						nYInterpolationIndexEnd = nIterY;
				}

				TRACE(
					_T("\nInterpolation Center Index: (%d, %d)\n"),
					nIterX,
					nIterY
					);
				TRACE(
					_T("Interpolation Start Index: (%d, %d)\n"),
					nXInterpolationIndexStart,
					nYInterpolationIndexStart
					);
				TRACE(
					_T("Interpolation End Index: (%d, %d)\n"),
					nXInterpolationIndexEnd,
					nYInterpolationIndexEnd
					);

				// Interpolation
				m_sizeDelta[nIterX][nIterY].cx += nMaxDeltaInLsbX;
				m_sizeDelta[nIterX][nIterY].cy += nMaxDeltaInLsbY;

				if(nXInterpolationIndexStart != nIterX &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nIterY,
						nYInterpolationIndexEnd
						);
				}
				
				if(nXInterpolationIndexStart != nIterX &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nIterY,
						nYInterpolationIndexEnd
						);
				}
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

}

void CMGCView::CalculateDelta_Left_180(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : �������� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_180(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nBoxNumberX;
	int nBoxNumberY = 0;

	for(int nIterY = nYEnd ; nIterY >= nYStart ; nIterY -= nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXStart ; nIterX <= nXEnd ; nIterX += nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				m_bNodeChanged[nIterX][nIterY] = TRUE;

				int nXInterpolationIndexStart = nIterX - nGridIterX;
				int nXInterpolationIndexEnd = nIterX + nGridIterX;
				int nYInterpolationIndexStart = nIterY - nGridIterY;
				int nYInterpolationIndexEnd = nIterY + nGridIterY;

				if(nIterX == nXStart)
					nXInterpolationIndexStart = nIterX;

				if(nXEnd - nXStart + 1 > nGrid + 1)
				{
					// nXEnd - nXStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.

					if(nIterX == nXStart + nGridIterX * nGrid)
						nXInterpolationIndexEnd = nIterX;
				}
				else
				{
					if(nIterX == nXStart + nGridIterX * (nXEnd - nXStart))
						nXInterpolationIndexEnd = nIterX;
				}

				if(nIterY == nYEnd)
					nYInterpolationIndexEnd = nIterY;

				if(nYEnd - nYStart + 1 > nGrid + 1)
				{
					// nYEnd - nYStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.

					if(nIterY == nYEnd - nGridIterY * nGrid)
						nYInterpolationIndexStart = nIterY;
				}
				else
				{
					if(nIterY == nYEnd - nGridIterY * (nYEnd - nYStart))
						nYInterpolationIndexStart = nIterY;
				}

				TRACE(
					_T("\nInterpolation Center Index: (%d, %d)\n"),
					nIterX,
					nIterY
					);
				TRACE(
					_T("Interpolation Start Index: (%d, %d)\n"),
					nXInterpolationIndexStart,
					nYInterpolationIndexStart
					);
				TRACE(
					_T("Interpolation End Index: (%d, %d)\n"),
					nXInterpolationIndexEnd,
					nYInterpolationIndexEnd
					);

				// Interpolation
				m_sizeDelta[nIterX][nIterY].cx += nMaxDeltaInLsbX;
				m_sizeDelta[nIterX][nIterY].cy += nMaxDeltaInLsbY;

				if(nXInterpolationIndexStart != nIterX &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nIterY,
						nYInterpolationIndexEnd
						);
				}
				
				if(nXInterpolationIndexStart != nIterX &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nIterY,
						nYInterpolationIndexEnd
						);
				}
			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}
		
		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

}

void CMGCView::CalculateDelta_Left_270(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : ���� ����

	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_270(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nBoxNumberX;
	int nBoxNumberY = 0;

	for(int nIterY = nYEnd ; nIterY >= nYStart ; nIterY -= nGridIterY)
	{
		nBoxNumberX = 0;
		for(int nIterX = nXEnd ; nIterX >= nXStart ; nIterX -= nGridIterX)
		{
			if(m_bNodeSelected[nIterX][nIterY] == TRUE)
			{
				m_bNodeChanged[nIterX][nIterY] = TRUE;

				int nXInterpolationIndexStart = nIterX - nGridIterX;
				int nXInterpolationIndexEnd = nIterX + nGridIterX;
				int nYInterpolationIndexStart = nIterY - nGridIterY;
				int nYInterpolationIndexEnd = nIterY + nGridIterY;

				if(nIterX == nXEnd)
					nXInterpolationIndexEnd = nIterX;
				
				if(nXEnd - nXStart + 1 > nGrid + 1)
				{
					// nXEnd - nXStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.
					
					if(nIterX == nXEnd - nGridIterX * nGrid)
						nXInterpolationIndexStart = nIterX;
				}
				else
				{
					if(nIterX == nXEnd - nGridIterX * (nXEnd - nXStart))
						nXInterpolationIndexStart = nIterX;
				}
				
				if(nIterY == nYEnd)
					nYInterpolationIndexEnd = nIterY;

				if(nYEnd - nYStart + 1 > nGrid + 1)
				{
					// nYEnd - nYStart + 1 : Node�� ����
					// nGrid + 1 : ���õ� Grid�� ������ ���� Box�� ����
					// nGrid + 1 : �� �׷��� �� Box �������� ���� �� �ִ�.

					if(nIterY == nYEnd - nGridIterY * nGrid)
						nYInterpolationIndexStart = nIterY;
				}
				else
				{
					if(nIterY == nYEnd - nGridIterY * (nYEnd - nYStart))
						nYInterpolationIndexStart = nIterY;
				}

				TRACE(
					_T("\nInterpolation Center Index: (%d, %d)\n"),
					nIterX,
					nIterY
					);
				TRACE(
					_T("Interpolation Start Index: (%d, %d)\n"),
					nXInterpolationIndexStart,
					nYInterpolationIndexStart
					);
				TRACE(
					_T("Interpolation End Index: (%d, %d)\n"),
					nXInterpolationIndexEnd,
					nYInterpolationIndexEnd
					);

				// Interpolation
				m_sizeDelta[nIterX][nIterY].cx += nMaxDeltaInLsbX;
				m_sizeDelta[nIterX][nIterY].cy += nMaxDeltaInLsbY;

				if(nXInterpolationIndexStart != nIterX &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nYInterpolationIndexStart != nIterY)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nYInterpolationIndexStart,
						nIterY
						);
				}
				
				if(nIterX != nXInterpolationIndexEnd &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nIterX,
						nXInterpolationIndexEnd,
						nIterY,
						nYInterpolationIndexEnd
						);
				}
				
				if(nXInterpolationIndexStart != nIterX &&
					nIterY != nYInterpolationIndexEnd)
				{
					BilinearInterpolation(
						nMaxDeltaInLsbX,
						nMaxDeltaInLsbY,
						nXInterpolationIndexStart,
						nIterX,
						nIterY,
						nYInterpolationIndexEnd
						);
				}

			}

			nBoxNumberX++;
			if(nBoxNumberX > nGrid)
				break;
		}

		nBoxNumberY++;
		if(nBoxNumberY > nGrid)
			break;
	}

}

void CMGCView::DrawDelta_Left_0(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���� ����
	// Y �� : ���� :���������� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_0(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nLsbX = int(65535 / 64);
	int nLsbY = int(65535 / 64);

	int nVectorX;
	int nVectorY;

	CPen penDelta;
	penDelta.CreatePen(PS_SOLID, 0, m_clrDeltaColor);
	CPen *pPenOld = pDC->SelectObject(&penDelta);

	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Height() - int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Width()) / double(nDivide));

			nVectorX = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cx) / double(nLsbX)) *
				double(rectField.Height()) / double(nDivide));
			nVectorY = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cy) / double(nLsbX)) *
				double(rectField.Width()) / double(nDivide));

			pDC->MoveTo(nY, nX);
			pDC->LineTo(nY + nVectorY, nX - nVectorX);
		}
	}

	pDC->SelectObject(pPenOld);
}

void CMGCView::DrawDelta_Left_90(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : ���������� ����
	// Y �� : ���� : �Ʒ��� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_90(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nLsbX = int(65535 / 64);
	int nLsbY = int(65535 / 64);

	int nVectorX;
	int nVectorY;

	CPen penDelta;
	penDelta.CreatePen(PS_SOLID, 0, m_clrDeltaColor);
	CPen *pPenOld = pDC->SelectObject(&penDelta);

	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				int(nIterY * double(rectField.Height()) / double(nDivide));

			nVectorX = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cx) / double(nLsbX)) *
				double(rectField.Width()) / double(nDivide));
			nVectorY = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cy) / double(nLsbX)) *
				double(rectField.Height()) / double(nDivide));

			pDC->MoveTo(nX, nY);
			pDC->LineTo(nX + nVectorX, nY + nVectorY);
		}
	}

	pDC->SelectObject(pPenOld);

}

void CMGCView::DrawDelta_Left_180(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �Ʒ��� ����
	// Y �� : ���� : �������� ����
	
	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_180(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nLsbX = int(65535 / 64);
	int nLsbY = int(65535 / 64);

	int nVectorX;
	int nVectorY;

	CPen penDelta;
	penDelta.CreatePen(PS_SOLID, 0, m_clrDeltaColor);
	CPen *pPenOld = pDC->SelectObject(&penDelta);

	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				int(nIterX * double(rectField.Height()) / double(nDivide));
			int nY = 
				rectField.Width() - int(nIterY * double(rectField.Width()) / double(nDivide));

			nVectorX = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cx) / double(nLsbX)) *
				double(rectField.Height()) / double(nDivide));
			nVectorY = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cy) / double(nLsbX)) *
				double(rectField.Width()) / double(nDivide));

			pDC->MoveTo(nY, nX);
			pDC->LineTo(nY - nVectorY, nX + nVectorX);
		}
	}

	pDC->SelectObject(pPenOld);

}

void CMGCView::DrawDelta_Left_270(CDC *pDC)
{
	// Field ��ǥ��(MM_TEXT)�� �׸���.
	// X �� : ���� : �������� ����
	// Y �� : ���� : ���� ����

	CRect rectField;
	int nXStart = 0;
	int nYStart = 0;
	int nXEnd = 0;
	int nYEnd = 0;
	int nGrid = 0;
	int nGridIterX = 0;
	int nGridIterY = 0;
	int nDivide = 0;

	FindField_Left_270(pDC, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);

	int nLsbX = int(65535 / 64);
	int nLsbY = int(65535 / 64);

	int nVectorX;
	int nVectorY;

	CPen penDelta;
	penDelta.CreatePen(PS_SOLID, 0, m_clrDeltaColor);
	CPen *pPenOld = pDC->SelectObject(&penDelta);

	for(int nIterY = 0 ; nIterY <= nYEnd - nYStart ; nIterY++)
	{
		for(int nIterX = 0 ; nIterX <= nXEnd - nXStart ; nIterX++)
		{
			// nX, nY�� MM_TEXT ��ǥ
			int nX = 
				rectField.Width() - int(nIterX * double(rectField.Width()) / double(nDivide));
			int nY = 
				rectField.Height() - int(nIterY * double(rectField.Height()) / double(nDivide));

			nVectorX = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cx) / double(nLsbX)) *
				double(rectField.Width()) / double(nDivide));
			nVectorY = int((double(m_sizeDelta[nIterX + nXStart][nIterY + nYStart].cy) / double(nLsbX)) *
				double(rectField.Height()) / double(nDivide));

			pDC->MoveTo(nX, nY);
			pDC->LineTo(nX - nVectorX, nY - nVectorY);
		}
	}

	pDC->SelectObject(pPenOld);

}


int CMGCView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	CRect rectMGCView;
	GetWindowRect(rectMGCView);

	CWnd *pWnd = GetParent();
	pWnd->ScreenToClient(rectMGCView);

	rectMGCView.left += ::GetSystemMetrics(SM_CXEDGE) / 2;
	rectMGCView.top += ::GetSystemMetrics(SM_CYEDGE) / 2;

	MoveWindow(rectMGCView);
	
	
	return 0;
}

void CMGCView::getSelectedNodeInAxis(int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide)
{
	CClientDC dc(this);
	OnPrepareDC(&dc);

	CRect rectField;

	switch(m_nAxis)
	{
	case NAxis::axis_0:
		FindField_0(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);
		break;
	case NAxis::axis_90:
		FindField_90(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);
		break;
	case NAxis::axis_180:
		FindField_180(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);
		break;
	case NAxis::axis_270:
		FindField_270(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);
		break;
	case NAxis::axis_left_0:
		FindField_Left_0(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);
		break;
	case NAxis::axis_left_90:
		FindField_Left_90(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);
		break;
	case NAxis::axis_left_180:
		FindField_Left_180(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);
		break;
	case NAxis::axis_left_270:
		FindField_Left_270(&dc, rectField, nXStart, nYStart, nXEnd, nYEnd, nGrid, nGridIterX, nGridIterY, nDivide);
		break;
	}

}

BOOL CMGCView::SaveTestFile(const CString &strTestFilePath)
{
	// Test�� ���� �ӽ� ������ ���� �Ѵ�.
	// Asc File Data�� �������� ���Ͽ� ������ �ӽ� ���Ͽ� �����Ѵ�.

	CStdioFile fileAsc;
	if(fileAsc.Open(strTestFilePath, CFile::modeWrite | CFile::modeCreate) == FALSE)
	{
		CDlgInformationBox dlgInformationBox;
		dlgInformationBox.SetTitleContent("ERROR", "Failed to save temporary file for test.");

		dlgInformationBox.DoModal();

		return FALSE;
	}
	
	CString strWrite;
	fileAsc.Seek(0, CFile::begin);

	// LT ���� - ����
	fileAsc.WriteString(_T("LT\n"));
	// LT ���� - ��

	// Index�� Axis��ǥ�踦 �������� �Ѵ�. �տ� ���� X��, �ڿ� ���� Y��
	int nIterX;
	int nIterY;

	// Y�� ���� ���� - ����
	for(nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			strWrite.Format(_T("%d\n"), m_nYAscFileData[nIterX][nIterY] + m_sizeDelta[nIterX][nIterY].cy);
			fileAsc.WriteString(strWrite);
		}
	}
	// Y�� ���� ���� - ��

	// X�� ���� ���� - ����
	for(nIterY = 0 ; nIterY <= 64 ; nIterY++)
	{
		for(nIterX = 0 ; nIterX <= 64 ; nIterX++)
		{
			strWrite.Format(_T("%d\n"), m_nXAscFileData[nIterX][nIterY] + m_sizeDelta[nIterX][nIterY].cx);
			fileAsc.WriteString(strWrite);
		}
	}
	// X�� ���� ���� - ��

	// QT ���� - ����
	fileAsc.WriteString(_T("QT\n"));
	// QT ���� - ��

	return TRUE;
}

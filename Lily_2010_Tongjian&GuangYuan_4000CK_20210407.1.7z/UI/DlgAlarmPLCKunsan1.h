#if !defined(AFX_DLGALARMPLCKUNSAN1_H__11EF7FFD_8084_4E45_83E6_41222FA736F5__INCLUDED_)
#define AFX_DLGALARMPLCKUNSAN1_H__11EF7FFD_8084_4E45_83E6_41222FA736F5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgAlarmPLCKunsan1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgAlarmPLCKunsan1 dialog

class CDlgAlarmPLCKunsan1 : public CDialog
{
// Construction
public:
	CDlgAlarmPLCKunsan1(CWnd* pParent = NULL);   // standard constructor

	void GetIoErrorMsg();
	void GetLoadErrorMsg();
	void GetLoad2ErrorMsg();
	void GetLoad3ErrorMsg();
	void GetUnloadErrorMsg();
	void GetUnload2ErrorMsg();
	void GetUnload3ErrorMsg();
	void GetTableLimitErrorMsg();
	void GetOtherLimitErrorMsg();
	void GetLaserErrorMsg();
	void GetOthersErrorMsg();
	void GetOthers2ErrorMsg();
	void GetOthers3ErrorMsg();
	void GetOthers4ErrorMsg();
	void GetTableErrorMsg();
	LONG m_lErrorIoNew;
	LONG m_lErrorLoadNew;
	LONG m_lErrorLoad2New;
	LONG m_lErrorLoad3New;
	LONG m_lErrorUnloadNew;
	LONG m_lErrorUnload2New;
	LONG m_lErrorUnload3New;
	LONG m_lErrorTableLimitNew;
	LONG m_lErrorOtherLimitNew;
	LONG m_lErrorLaserNew;
	LONG m_lErrorOthersNew;
	LONG m_lErrorOthers2New;
	LONG m_lErrorOthers3New;
	LONG m_lErrorOthers4New;
	LONG m_lErrorTableNew;
	LONG m_lErrorNew;
	LONG m_lErrorOld;
	int m_nMsg;
	TCHAR m_szText[255];
	CString m_strMsg[20];
	BOOL m_bOnTimer;
	void UpdateMsg();
	void InitListCtrl();
	void AddItems();
	CListCtrl m_ctrlListMsg;
	
	int m_nTimerID;
	
	// Dialog Data
	//{{AFX_DATA(CDlgAlarmPLCKunsan1)
	enum { IDD = IDD_DLG_PLC_ALARM };
	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
	
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgAlarmPLCKunsan1)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CDlgAlarmPLCKunsan1)
	afx_msg void OnTimer(UINT nIDEvent);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGALARMPLCKUNSAN1_H__11EF7FFD_8084_4E45_83E6_41222FA736F5__INCLUDED_)

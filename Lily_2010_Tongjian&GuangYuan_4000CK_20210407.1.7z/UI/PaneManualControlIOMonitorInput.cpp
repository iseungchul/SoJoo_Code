// PaneManualControlIOMonitorInput.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlIOMonitorInput.h"
#include "PaneManualControlIOMonitorInputSub1.h"
#include "PaneManualControlIOMonitorInputSub2.h"
#include "..\model\deasydrillerini.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInput

IMPLEMENT_DYNCREATE(CPaneManualControlIOMonitorInput, CFormView)

CPaneManualControlIOMonitorInput::CPaneManualControlIOMonitorInput()
	: CFormView(CPaneManualControlIOMonitorInput::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlIOMonitorInput)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pSub1 = NULL;
	m_pSub2 = NULL;
	m_pSub3 = NULL;
	m_pSub4 = NULL;
	m_nPaneNo = -1;
}

CPaneManualControlIOMonitorInput::~CPaneManualControlIOMonitorInput()
{
}

void CPaneManualControlIOMonitorInput::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlIOMonitorInput)
	DDX_Control(pDX, IDC_TAB_MANUAL_CONTROL, m_tabManualControl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlIOMonitorInput, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlIOMonitorInput)
	ON_NOTIFY(NM_CLICK, IDC_TAB_MANUAL_CONTROL, OnClickTabManualControl)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInput diagnostics

#ifdef _DEBUG
void CPaneManualControlIOMonitorInput::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlIOMonitorInput::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInput message handlers
void CPaneManualControlIOMonitorInput::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitTabControl();
}

void CPaneManualControlIOMonitorInput::InitTabControl()
{
	// Set Button Font
	m_fntTab.CreatePointFont(150, "Arial Bold");
	
	BOOL bRet = 0;
	
	m_tabManualControl.SetFont( &m_fntTab );
	
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_PMAC)
	{
		// Input
		bRet = m_tabManualControl.AddPane( _T(" Input1 - Main "), RUNTIME_CLASS(CPaneManualControlIOMonitorInputSub1) );
		if( FALSE != bRet )
		{
			m_pSub1 = static_cast<CPaneManualControlIOMonitorInputSub1*>(m_tabManualControl.GetPane(0));
			m_pSub1->OnInitialUpdate();
		}

		bRet = m_tabManualControl.AddPane( _T(" Input2 - Handler "), RUNTIME_CLASS(CPaneManualControlIOMonitorInputSub2) );
		if( FALSE != bRet )
		{
			m_pSub2 = static_cast<CPaneManualControlIOMonitorInputSub2*>(m_tabManualControl.GetPane(1));
			m_pSub2->OnInitialUpdate();
		}

	/*	bRet = m_tabManualControl.AddPane( _T(" Input3 - Loader "), RUNTIME_CLASS(CPaneManualControlIOMonitorInputSub3) );
		if( FALSE != bRet )
		{
			m_pSub3 = static_cast<CPaneManualControlIOMonitorInputSub3*>(m_tabManualControl.GetPane(2));
			m_pSub3->OnInitialUpdate();
		}

		bRet = m_tabManualControl.AddPane( _T(" Input4 - Unloader "), RUNTIME_CLASS(CPaneManualControlIOMonitorInputSub4) );
		if( FALSE != bRet )
		{
			m_pSub4 = static_cast<CPaneManualControlIOMonitorInputSub4*>(m_tabManualControl.GetPane(3));
			m_pSub4->OnInitialUpdate();
		}
*/
		m_tabManualControl.ShowPane(0);
	}
}

void CPaneManualControlIOMonitorInput::ShowTabPane(int nPaneNo)
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;

	if( nPaneNo >= 0 && nPaneNo < 4 )
	{
		m_tabManualControl.ShowPane( nPaneNo );
		
		m_nPaneNo = nPaneNo;
	}
}

void CPaneManualControlIOMonitorInput::ChangeSubPane()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;

	if(m_nPaneNo == -1)
		m_nPaneNo = 0;
	m_tabManualControl.ShowPane(m_nPaneNo);
	
	switch(m_nPaneNo)
	{
	case 0:
		m_pSub1->InitTimer();
		break;
	case 1:
		m_pSub2->InitTimer();
		break;
/*	case 2:
		m_pSub3->InitTimer();
		break;
	case 3:
		m_pSub4->InitTimer();
		break;
		*/
	}
}

void CPaneManualControlIOMonitorInput::KillSubTimer()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;

	if(m_nPaneNo == -1)
		return;
	else
	{
		switch(m_nPaneNo)
		{
		case 0:
			m_pSub1->DestroyTimer();
			break;
		case 1:
			m_pSub2->DestroyTimer();
			break;
/*		case 2:
			m_pSub3->DestroyTimer();
			break;
		case 3:
			m_pSub4->DestroyTimer();
			break;
			*/
		}
	}
}

void CPaneManualControlIOMonitorInput::OnClickTabManualControl(NMHDR* pNMHDR, LRESULT* pResult) 
{
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->ActiveStaticForKeyboardError();

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;
	
	int nSel = m_tabManualControl.GetCurSel();
	
	if( nSel == m_nPaneNo )
		return;

	switch(m_nPaneNo)
	{
	case 0:
		m_pSub1->DestroyTimer();
		break;
	case 1:
		m_pSub2->DestroyTimer();
		break;
/*	case 2:
		m_pSub3->DestroyTimer();
		break;
	case 3:
		m_pSub4->DestroyTimer();
		break;
		*/
	}
		
	switch( nSel )
	{
	case 0:
		m_pSub1->InitTimer();
		break;
	case 1:
		m_pSub2->InitTimer();
		break;
/*	case 2:
		m_pSub3->InitTimer();
		break;
	case 3:
		m_pSub4->InitTimer();
		break;
*/	}
	
	m_nPaneNo = nSel;
	
	*pResult = 0;
}

void CPaneManualControlIOMonitorInput::OnDestroy() 
{
	m_fntTab.DeleteObject();
	
	CFormView::OnDestroy();
}

BOOL CPaneManualControlIOMonitorInput::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}
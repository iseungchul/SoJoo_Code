// panelv1.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "panelv1.h"
#include "..\model\DSystemINI.h"
#include "..\EasyDrillerDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneLV1

IMPLEMENT_DYNCREATE(CPaneLV1, CFormView)

CPaneLV1::CPaneLV1()
	: CFormView(CPaneLV1::IDD)
{
	//{{AFX_DATA_INIT(CPaneLV1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneLV1::~CPaneLV1()
{
}

void CPaneLV1::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneLV1)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneLV1, CFormView)
	//{{AFX_MSG_MAP(CPaneLV1)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneLV1 diagnostics

#ifdef _DEBUG
void CPaneLV1::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneLV1::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneLV1 message handlers

void CPaneLV1::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
#ifdef USE_VISION_PRO
	gVPro.SetDisplayWindow( 1, GetDlgItem(IDC_VISIONPRO_1L) );
#endif
}

BEGIN_EVENTSINK_MAP(CPaneLV1, CFormView)
    //{{AFX_EVENTSINK_MAP(CPaneLV1)
	ON_EVENT(CPaneLV1, IDC_VISIONPRO_1L, 5208 /* DblClick */, OnDblClickVisionpro1l, VTS_NONE)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CPaneLV1::OnDblClickVisionpro1l() 
{
	// TODO: Add your control notification handler code here
/*	if(gSystemINI.m_sHardWare.bUseWideMonitor)
	{
		BOOL bIsSize = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetSideStatus();
		if(bIsSize)
			::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);
		else
			::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, TRUE);
		
		
	}
*/
}

#if !defined(AFX_PANEPROCESSSETUPLASERSCANNER_H__141921F4_E1F5_4516_9665_2015AB66B03C__INCLUDED_)
#define AFX_PANEPROCESSSETUPLASERSCANNER_H__141921F4_E1F5_4516_9665_2015AB66B03C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneProcessSetupLaserScanner.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupLaserScanner form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "ColorStatic.h"
#include "ColorEdit.h"
#include "LedButton.h"

class CPaneProcessSetupLaserScanner : public CFormView
{
protected:
	CPaneProcessSetupLaserScanner();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneProcessSetupLaserScanner)

// Form Data
public:
	//{{AFX_DATA(CPaneProcessSetupLaserScanner)
	enum { IDD = IDD_DLG_PROCESS_SETUP_LASERSCANNER };
//	CColorEdit	m_edtStepPeriod;
//	CColorEdit	m_edtLaserOnDelay;
//	CColorEdit	m_edtJumpStep;
//	CColorEdit	m_edtJumpDelay;
//	CColorEdit	m_edtCycleTime;
//	CColorEdit	m_edtScannerJDelay;
//	CColorEdit	m_edtPulseFrequency;
	CColorEdit	m_edtPreheatModulationTime;
	CColorEdit	m_edtPreheatTime;
//	CColorStatic	m_stcPenPath;
	UEasyButtonEx	m_btnResetTotalShots;
//	UEasyButtonEx	m_btnPenSave;
//	UEasyButtonEx	m_btnPenOpen;
	//}}AFX_DATA

// Attributes
public:

// Attributes
protected :
	CFont			m_fntBtn;
	CFont			m_fntStatic;
	CFont			m_fntEdit;

	SPROCESSLASERSCANNER	m_sProcessLaserScanner;
	CString			m_strTotalShot;

// Operations
public:
	CString GetChangeValueStr();
	void			InitBtnControl();
	void			InitStaticControl();
	void			InitEditControl();

	void			SetProcessLaserScannerData(SPROCESSLASERSCANNER sData);
	void			GetProcessLaserScannerData(SPROCESSLASERSCANNER* pData);
	void			DispProcessLaserScannerData();
	void			OnApply();

	void			SetPenData();
	void			GetPenData();

	void			InitTotalShot();
	CString			GetTotalShot();
	void			MakeReadableNumber(CString& strVal);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneProcessSetupLaserScanner)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneProcessSetupLaserScanner();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneProcessSetupLaserScanner)
//	afx_msg void OnButtonParamOpen();
//	afx_msg void OnButtonParamSave();
	afx_msg void OnButtonResetTotalShots();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEPROCESSSETUPLASERSCANNER_H__141921F4_E1F5_4516_9665_2015AB66B03C__INCLUDED_)

#if !defined(AFX_CDLGBARCODEMANAGER_H__955102BF_1A08_43F3_8080_C0D4BD017B5C__INCLUDED_)
#define AFX_CDLGBARCODEMANAGER_H__955102BF_1A08_43F3_8080_C0D4BD017B5C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CDlgBarcodeManager.h : header file
//
#include "UEasyButtonEx.h"
#include "ColorEdit.h"
/////////////////////////////////////////////////////////////////////////////
// CDlgBarcodeManager dialog

class CDlgBarcodeManager : public CDialog
{
// Construction
public:
	void SetOpenType(BOOL bPrj);
	CString GetFileName();
	CString GetFilePath();
	void InitEditControl();
	void DecodeManageNum();
	void InitStaticControl();
	void InitBtnControl();
	CDlgBarcodeManager(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgBarcodeManager)
	enum { IDD = IDD_DLG_BARCODE_MANAGE };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	UEasyButtonEx m_btnApply;
	UEasyButtonEx m_btnInput;
	UEasyButtonEx m_btnOpen;
	
	CColorEdit	m_edtProjectPath;
	CColorEdit	m_edtLotNo;
	CColorEdit	m_edtManageNo;

	CString	m_strLotNo;
	CString m_strManageNo;
	CString	m_strManage; //decode
	CString m_strCurrent;
	CString m_OpenProjectFile;
	CString m_OpenProjectFileName;
	CFont m_fntStatic;
	CFont m_fntBtn;
	CFont m_fntEdit;
	BOOL m_bOpenPrj;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgBarcodeManager)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgBarcodeManager)
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonInput();
	afx_msg void OnButtonOpenProject();
	afx_msg void OnButtonApply();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CDLGBARCODEMANAGER_H__955102BF_1A08_43F3_8080_C0D4BD017B5C__INCLUDED_)

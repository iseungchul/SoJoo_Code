#if !defined(AFX_PANEMANUALDRILLSUB_H__B7FB0DB3_C750_48D0_8FBE_C4ECD6181189__INCLUDED_)
#define AFX_PANEMANUALDRILLSUB_H__B7FB0DB3_C750_48D0_8FBE_C4ECD6181189__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualDrillSub.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualDrillSub form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "PaneManualControlVision.h"

class CPaneManualDrillSub : public CFormView
{
protected:
	CPaneManualDrillSub();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualDrillSub)

// Form Data
public:
	//{{AFX_DATA(CPaneManualDrillSub)
	enum { IDD = IDD_DLG_MANUAL_DRILL_SUB };
	UEasyButtonEx	m_btnSetRef;
	UEasyButtonEx	m_btnMoveRef;
	UEasyButtonEx	m_btnInspectionStop;
	UEasyButtonEx	m_btnInspectionStart;
	UEasyButtonEx	m_btnFindFiducial;
	UEasyButtonEx	m_btnBack;
	UEasyButtonEx	m_btnApplyRef;
	UEasyButtonEx	m_btnGoFiducial;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

	TCHAR myResultChar[255];
	DPOINT visionResult;

	double m_dZPos;
	BOOL IsVisionWorking();
	void ShowHoleFind(BOOL bShow);
	BOOL ButtonEnable(BOOL bEnable);
	BOOL CheckFoundFidValid(int nFidKind);
	CPoint GetNextStepIndex(int nStepNo);
	int		m_nFidKind;
	BOOL	m_bStop;
	int m_nCameraNo;
	CWinThread* m_pFindFidThread;
	CWinThread* m_pHoleFindThread;
	BOOL FindFiducial();
	CPaneManualControlVision* m_pVisionTab;
	void SetVisionTab(CPaneManualControlVision* pVision);
	void		InitBtnControl();

	void		SetBackPaneNo(int nPaneNo)	{ m_nBackPaneNo = nPaneNo; }
	int			GetBackPaneNo()		{ return m_nBackPaneNo; }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualDrillSub)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualDrillSub();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntBtn;
	CFont		m_fntBtn2;
	int			m_nBackPaneNo;

	// Generated message map functions
	//{{AFX_MSG(CPaneManualDrillSub)
	afx_msg void OnButtonBack();
	afx_msg void OnDestroy();
	afx_msg void OnButtonMoveRef();
	afx_msg void OnButtonSetRef();
	afx_msg void OnButtonFindFiducial();
	afx_msg void OnButtonApplyRef();
	afx_msg void OnButtonInspectionStart();
	afx_msg void OnButtonInspectionStop();
	afx_msg LRESULT GetVisionResult(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT SetROI(WPARAM wParam, LPARAM lParam);
	afx_msg void OnBtnGoFiducial();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALDRILLSUB_H__B7FB0DB3_C750_48D0_8FBE_C4ECD6181189__INCLUDED_)

#if !defined(AFX__H__C4A81FCB_467F_45AA_86A3_65804BE226F2__INCLUDED_)
#define AFX__H__C4A81FCB_467F_45AA_86A3_65804BE226F2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// .h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenDataEasy form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "DrillDataView.h"
#include "UEasyButtonEx.h"
#include "LedButton.h"
#include "..\model\dfiddata.h"
#include "ColorEdit.h"
#define MAX_FID_BLOCK		50 
class DProject;
class CDlgRecipeGen;

class CPaneRecipeGenDataEasy : public CFormView
{
protected:
	CPoint  m_ptFidPosition;
	CPoint  m_ptTotalMove;
	CPoint	m_ptDrawRectBack1;
	CPoint	m_ptDrawRectBack2;
	CPoint	m_ptFidPos;
	CPoint	m_ptMoveStart;
	CPoint  m_ptDrawStart;
	BOOL	m_bDrawMoveStart;
	BOOL	m_bUnitMoveStart;
	BOOL	m_bDisunifyMode;
	BOOL	m_bAddSubFidMode;

	// ������ Fiducial ���� ����
	BOOL	m_bSetMainFidMode;
	BOOL	m_bResetOneMainFidMode;
	BOOL	m_bSetSubFidMode;
	BOOL	m_bResetOneSubFidMode;

	CDrillDataView		m_clsDrillDataView;
	CPaneRecipeGenDataEasy();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneRecipeGenDataEasy)

// Form Data
public:
	//{{AFX_DATA(CPaneRecipeGenDataEasy)
	enum { IDD = IDD_DLG_RECIPE_GEN_DATA_EASY };
	double	m_dX;
	double	m_dY;
	UEasyButtonEx	m_btnZoomField;
	UEasyButtonEx	m_btnSelectClear;
	UEasyButtonEx	m_btnExcellonLoad;
	UEasyButtonEx	m_btnEasymarker;
	UEasyButtonEx	m_btnExcellonSave;
	UEasyButtonEx	m_btnFlipX;
	UEasyButtonEx	m_btnFlipY;
	UEasyButtonEx	m_btnRotate;
	UEasyButtonEx	m_btnMove;
	UEasyButtonEx	m_btnRemoveAlldata;
	CComboBox	m_cmbSelectComSol;
	CColorEdit m_edtLotIDComp;
	CString m_strLotIDComp;
	CString m_strLotIDSold;
	CString	m_strFile;
	CString m_strFilmName;

	CString m_strMaterialGroup;
	CString m_strMeterialMaker;
	CString m_strMaterialThick;
	CString m_strFiducialSize;
	CString m_strTrimFinalThick;
	CString m_strProductCount;
	CString m_strHoleSize;

	CString m_strLayUpCode;
	CString m_strCopperThick;
	CString m_strMeterialKind;
	CString m_strCustomerCode;
	CString m_strProcessCode;
	CString m_strBackwardLevel;
	CString m_strPrevProcessCode;


	CLedButton m_ledSelectFire;
	CLedButton m_ledNoFindFid;
	CLedButton m_ledNoPreWork;
	CLedButton m_ledNoVisionCompen;
	//}}AFX_DATA

// Attributes
public:
	int	m_nUserLevel;

	BOOL m_bShowSortIndex;
	int m_nFieldIndex;

	int  m_nStartFidIndex;
	BOOL m_bHeaderReadComplete;
	BOOL m_bSelectFidBlock[MAX_FID_BLOCK];
	BOOL		m_bSelectFire;
	BOOL     m_bNoFindFid;
	BOOL m_bNoUsePreWork;
// Operations
public:
	BOOL m_bExcellonChange;
	void ResetProject();
	void CalRefFidFlipPos(BOOL bX);
	void DisplayRotateInfo();
	BOOL IsPickUnit(CPoint ptPoint);
	void SetDrawRect();
	void DrawSelectionRect(CDC* pDC);
	CFont		m_fntBtn;
	CFont		m_fntStatic;
	void InitStaticControl();
	void InitBtnControl();
	void DrawSelectionRect(CDC *pDC, CPoint ptPoint1, CPoint ptPoint2);
	BOOL m_bViewerMoveMode;
	BOOL IsCheckPathViewMode(CPoint ptPick);
	BOOL IsCheckSelectViewMode(CPoint ptPick);
	BOOL IsPickToolVisible(CPoint ptPick);
	void ChangePosInfo(CPoint ptPick);
	void DrawData();
	CDlgRecipeGen* m_pParent;
	DProject* m_pProject;
	void SetProject(DProject* pProject);

	void EnableControl(BOOL bUse);
	void SetAuthorityByLevel(int nLevel);

	void ClearFiducialIndex();
	void MesDataFileCheck(int nCompSold =0);
	void SetRefFidLeftBottom(int nAxisMode);
		int m_nG821Count;
	BOOL DataCheck(CString strLotID1, int nComSol);
	CString FindDataName(CString strLotID, CString strManager, CString strLayer, int nComSol, CString strProcessCode, CString strBackwardLevel);
	BOOL SetValue(int nComSol, CString strMaterialGroup, CString strMeterialMaker, CString strMaterialThick, CString strFiducialSize, CString strTrimFinalThick, CString strProductCount, CString strHoleSize, CString strLayupCode, CString strCopperThick, CString strMeterialKind, CString strCustomerCode, CString strLayer, CString strProcessCode, CString strBackwardLevel, CString strPrevProcessCode);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneRecipeGenData)
	public:
	virtual void OnInitialUpdate();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneRecipeGenDataEasy();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneRecipeGenData)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	afx_msg void OnButtonExcellon();
	afx_msg void OnButtonEasymarker();
	afx_msg void OnButtonSaveExcellon();
	afx_msg void OnPaint();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnButtonPlt();
	afx_msg void OnButtonFlipx();
	afx_msg void OnButtonFlipy();
	afx_msg void OnButtonRotate();
	afx_msg void OnButtonMove();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnSelectFieldOne();
	afx_msg void OnSelectField();
	afx_msg void OnSelectFidBlock(UINT parm_control_id);
	afx_msg void OnSetTableOffset();
	afx_msg void OnStartFiducialSet();
	afx_msg void OnClearFiducialSet();
	afx_msg void OnFiducialAdd();
	afx_msg void OnFiducialMove();
	afx_msg void OnFiducialDel();
	afx_msg void OnSetRefFid();
	afx_msg void OnArrayCopy();
	afx_msg void OnAddSubFid();
	afx_msg void OnDelSubFidAll();
	afx_msg void OnMergeUnit();
	afx_msg void OnDisunifyUnit();
	afx_msg void OnButtonZoomAll();
	afx_msg void OnButtonClear();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnCopyField();
		
//	afx_msg void OnFiducialSetMain();
//	afx_msg void OnFiducialResetOneMain();
//	afx_msg void OnFiducialResetAllMain();
//	afx_msg void OnFiducialSetSub();
//	afx_msg void OnFiducialResetOneSub();
//	afx_msg void OnFiducialResetAllSub();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	afx_msg void OnBnClickedCheckSelectRun2();
	afx_msg void OnBnClickedCheckNoFindFid();
	afx_msg void OnBnClickedCheckNoUsePreWork();
	afx_msg void OnBnClickedCheckNoUseVisionCompen();
	
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANERECIPEGENDATA_H__C4A81FCB_467F_45AA_86A3_65804BE226F2__INCLUDED_)

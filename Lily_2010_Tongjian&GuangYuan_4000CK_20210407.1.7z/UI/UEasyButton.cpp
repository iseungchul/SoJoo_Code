// UEasyButton.cpp : implementation file
//

#include "stdafx.h"
#include "UEasyButton.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// UEasyButton

UEasyButton::UEasyButton()
{
	m_bCursorInBtn				= FALSE;
	m_bClick					= FALSE;
	m_nTimerID					= -1;
	m_nRectAlign				= RECT_LEFT;
	m_hCursor					= NULL;
	m_ttcToolTip.m_hWnd			= NULL;

	m_nColorType				= 0;
}

UEasyButton::~UEasyButton()
{
	if( m_hCursor )
		::DestroyCursor( m_hCursor );
}


BEGIN_MESSAGE_MAP(UEasyButton, CButton)
	//{{AFX_MSG_MAP(UEasyButton)
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
	ON_WM_SETCURSOR()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_MOUSELEAVE, OnMouseLeave)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// UEasyButton message handlers

void UEasyButton::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	DrawBtn(lpDrawItemStruct);
	DrawText(lpDrawItemStruct);
}

void UEasyButton::DrawText(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	CDC *pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	CRect rectClient(lpDrawItemStruct->rcItem);

	CString strText;
	GetWindowText(strText);

	int iTopOffset = 0;
	int iLeftOffset = 0;

	CRect rectText(0, 0, 0, 0);
	pDC->DrawText(
		strText,
		rectText,
		DT_CALCRECT
		);

	switch( m_nRectAlign )
	{
	case RECT_LEFT :
		iLeftOffset = rectClient.Width() + ( m_rtLeft.right - rectClient.left );
		iLeftOffset = (iLeftOffset - rectText.Width()) / 2;
		iTopOffset = (rectClient.Height() - rectText.Height()) / 2;
		break;
	case RECT_RIGHT :
		iLeftOffset = rectClient.Width() - ( rectClient.right - m_rtRight.left );
		iLeftOffset = ( iLeftOffset - rectText.Width()) / 2;
		iTopOffset = (rectClient.Height() - rectText.Height()) / 2;
		break;
	case RECT_BOTH :
		iLeftOffset = (rectClient.Width() - rectText.Width()) / 2;
		iTopOffset = (rectClient.Height() - rectText.Height()) / 2;
		break;
	default :
		iLeftOffset = (rectClient.Width() - rectText.Width()) / 2;
		iTopOffset = (rectClient.Height() - rectText.Height()) / 2;
		break;
	}

	rectText.left += iLeftOffset;
	rectText.top += iTopOffset;
	rectText.right += iLeftOffset;
	rectText.bottom += iTopOffset;

	BOOL bIsDisabled = (lpDrawItemStruct->itemState & ODS_DISABLED);

	if( bIsDisabled )
	{
		rectText.OffsetRect(1, 1);
		pDC->SetTextColor( ::GetSysColor(COLOR_3DHILIGHT) );
		pDC->DrawText(
			strText,
			rectText,
			DT_LEFT | DT_TOP
			);
		rectText.OffsetRect(-1, -1);
		pDC->SetTextColor( ::GetSysColor(COLOR_BTNSHADOW) );
		pDC->DrawText(
			strText,
			rectText,
			DT_LEFT | DT_TOP
			);
	}
	else
	{
		pDC->SetTextColor( ::GetSysColor( COLOR_BTNTEXT ) );
		pDC->SetBkColor( ::GetSysColor( COLOR_BTNFACE ) );
		pDC->DrawText(
			strText,
			rectText,
			DT_LEFT | DT_TOP
			);
	}
}

void UEasyButton::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_bCursorInBtn == FALSE)
	{
		m_bCursorInBtn = TRUE;

		Invalidate(FALSE);

		TRACKMOUSEEVENT tme;
		tme.cbSize = sizeof(tme);
		tme.dwFlags = TME_LEAVE;
		tme.dwHoverTime = HOVER_DEFAULT;
		tme.hwndTrack = this->m_hWnd;

		_TrackMouseEvent(&tme);
	}
	
	CButton::OnMouseMove(nFlags, point);
}

LRESULT UEasyButton::OnMouseLeave(WPARAM wParam, LPARAM lParam)
{
	if(m_bCursorInBtn != FALSE)
	{
		m_bCursorInBtn = FALSE;

		Invalidate(FALSE);
	}

	return 0L;
}

void UEasyButton::PreSubclassWindow() 
{
	UINT nBtnStyle	= this->GetButtonStyle();

	nBtnStyle |= BS_OWNERDRAW;

	this->SetButtonStyle( nBtnStyle );
	
	CButton::PreSubclassWindow();
}

void UEasyButton::DrawBtn(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	CRect rectClient;
	GetClientRect(rectClient);

	int nDiff = 0;

	nDiff				= rectClient.Height() / 5;
	
	m_rtLeft.left		= rectClient.left + nDiff;
	m_rtLeft.right		= rectClient.left + (nDiff*3);
	m_rtLeft.top		= rectClient.top + nDiff;
	m_rtLeft.bottom		= rectClient.bottom - nDiff;

	m_rtRight.left		= rectClient.right - (nDiff*3);
	m_rtRight.right		= rectClient.right - nDiff;
	m_rtRight.top		= rectClient.top + nDiff;
	m_rtRight.bottom	= rectClient.bottom - nDiff;

	CDC dcButton;
	dcButton.Attach(lpDrawItemStruct->hDC);

	dcButton.SetBkMode(TRANSPARENT);

	BOOL bIsPressed = (lpDrawItemStruct->itemState & ODS_SELECTED);
	CRect itemRect = lpDrawItemStruct->rcItem;

	CBrush* pOldBrush;
	CBrush brRec;
	CBrush brBack(::GetSysColor(COLOR_BTNFACE));
	COLORREF clrBk = ::GetSysColor(COLOR_BTNFACE);
	CBrush brBk;

	if( bIsPressed )
	{
		clrBk = RGB( 255, 251, 243 );
		brBk.CreateSolidBrush( clrBk );
	}
	else
		brBk.CreateSolidBrush( clrBk );

	dcButton.FillRect( itemRect, &brBk );
	
	pOldBrush = dcButton.SelectObject( &brBack );

	BOOL bIsDisabled = (lpDrawItemStruct->itemState & ODS_DISABLED);

	if( FALSE == bIsDisabled )
	{
		if( FALSE == m_bClick )
		{
			brRec.CreateSolidBrush( RGB(255,0,0) );
			dcButton.SelectObject(&brRec);
		}
		else
		{
			brRec.CreateSolidBrush( RGB(0, 255, 0) );
			dcButton.SelectObject(&brRec);
		}
	}
	else
	{
		brRec.CreateSolidBrush( ::GetSysColor(COLOR_BTNFACE) );
	}

	switch( m_nRectAlign )
	{
	case RECT_LEFT :
		dcButton.Rectangle( m_rtLeft );
		break;
	case RECT_RIGHT :
		dcButton.Rectangle( m_rtRight );
		break;
	case RECT_BOTH :
		dcButton.Rectangle( m_rtLeft );
		dcButton.Rectangle( m_rtRight );
		break;
	}

	dcButton.SelectObject( pOldBrush );

	if( FALSE == bIsPressed )
	{
		// Draw Button Boarder
		CPen penBtnHiLight(PS_SOLID, 0, GetSysColor(COLOR_BTNHILIGHT)); // White
		CPen pen3DLight(PS_SOLID, 0, GetSysColor(COLOR_3DLIGHT));       // Light gray
		CPen penBtnShadow(PS_SOLID, 0, GetSysColor(COLOR_BTNSHADOW));   // Dark gray
		
		// 2011.08.05
		DWORD wRGB;
		int nLine;
		if(m_nColorType == 1)
		{
			wRGB = RGB(0,0,255);
			nLine = 2;
		}
		else
		{
			wRGB = ::GetSysColor(COLOR_3DDKSHADOW); //Black
			nLine = 0;
		}
		CPen pen3DDKShadow( PS_SOLID, nLine, wRGB);

		// Draw top-left borders
		// White line
		CPen* pOldPen = dcButton.SelectObject(&penBtnHiLight);
		dcButton.MoveTo(itemRect.left, itemRect.bottom-1);
		dcButton.LineTo(itemRect.left, itemRect.top);
		dcButton.LineTo(itemRect.right, itemRect.top);
		// Light gray line
		dcButton.SelectObject(pen3DLight);
		dcButton.MoveTo(itemRect.left+1, itemRect.bottom-1);
		dcButton.LineTo(itemRect.left+1, itemRect.top+1);
		dcButton.LineTo(itemRect.right, itemRect.top+1);

		// Draw bottom-right borders
		// Black line
		dcButton.SelectObject(pen3DDKShadow);
		dcButton.MoveTo(itemRect.left, itemRect.bottom-1);
		dcButton.LineTo(itemRect.right-1, itemRect.bottom-1);
		dcButton.LineTo(itemRect.right-1, itemRect.top-1);
		// Dark gray line
		dcButton.SelectObject(penBtnShadow);
		dcButton.MoveTo(itemRect.left+1, itemRect.bottom-2);
		dcButton.LineTo(itemRect.right-2, itemRect.bottom-2);
		dcButton.LineTo(itemRect.right-2, itemRect.top);
		//
		dcButton.SelectObject(pOldPen);
	}
	else
	{
		CBrush brBtnShadow(GetSysColor(COLOR_BTNSHADOW));
		dcButton.FrameRect(itemRect, &brBtnShadow);
	}

	BOOL bIsFocus = lpDrawItemStruct->itemState & ODS_FOCUS;

	if( bIsFocus )
	{
		itemRect.DeflateRect(3,3);
		dcButton.DrawFocusRect( &itemRect );
	}

	dcButton.Detach();
}

void UEasyButton::SetClick(BOOL bClick)
{
	m_bClick = bClick;

	this->Invalidate();
}

void UEasyButton::OnTimer(UINT nIDEvent) 
{
	SetClick(!m_bClick);

	CButton::OnTimer(nIDEvent);
}

void UEasyButton::TimerControl(BOOL bStart)
{
	if( FALSE == bStart && -1 != m_nTimerID )
	{
		KillTimer( m_nTimerID );
		m_nTimerID	= -1;
	}
	else if( TRUE == bStart && -1 == m_nTimerID )
	{
		m_nTimerID = SetTimer(321, 700, NULL);
	}
	else
	{
		TRACE("NOTHING\n");
	}
}

BOOL UEasyButton::PreTranslateMessage(MSG* pMsg) 
{
	InitToolTip();
	m_ttcToolTip.RelayEvent( pMsg );

	if( WM_LBUTTONDBLCLK == pMsg->message )
	{
		TRACE("DOUBLE CLICK\n");
		pMsg->message = WM_LBUTTONDOWN;
	}

	return CButton::PreTranslateMessage(pMsg);
}

BOOL UEasyButton::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	if( NULL != m_hCursor )
	{
		::SetCursor( m_hCursor );

		return TRUE;
	}
	
	return CButton::OnSetCursor(pWnd, nHitTest, message);
}

void UEasyButton::SetBtnCursor(int nCursorID)
{
	HINSTANCE hInstResource = NULL;

	if( m_hCursor )
	{
		::DestroyCursor( m_hCursor );
		m_hCursor = NULL;
	}

	if( nCursorID )
	{
		hInstResource = ::AfxFindResourceHandle( MAKEINTRESOURCE(nCursorID), RT_GROUP_CURSOR );

		m_hCursor	= (HCURSOR)::LoadImage( hInstResource, MAKEINTRESOURCE(nCursorID), IMAGE_CURSOR, 0, 0, 0 );

		Invalidate();
	}
}

void UEasyButton::InitToolTip()
{
	if( NULL == m_ttcToolTip.m_hWnd )
	{
		m_ttcToolTip.Create( this, TTS_BALLOON );
		m_ttcToolTip.Activate( FALSE );
		m_ttcToolTip.SendMessage( TTM_SETMAXTIPWIDTH, 0, 400 );
	}
}

void UEasyButton::SetToolTipText(LPCTSTR lpszText, BOOL bActivate)
{
	if( NULL == lpszText )
		return;

	InitToolTip();

	if( 0 == m_ttcToolTip.GetToolCount() )
	{
		CRect rc;

		GetClientRect( &rc );
		m_ttcToolTip.AddTool( this, lpszText, rc, 1 );
	}

	m_ttcToolTip.UpdateTipText( lpszText, this, 1 );
	m_ttcToolTip.Activate( bActivate );
}

void UEasyButton::ActivateToolTip(BOOL bEnable)
{
	if( 0 == m_ttcToolTip.GetToolCount() )
		return;

	m_ttcToolTip.Activate( bEnable );
}
// PaneProcessSetupOption2.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneProcessSetupOption2.h"
#include "..\model\deasydrillerini.h"
#include "..\easydrillerdlg.h"
#include "..\model\DProcessINI.h"
#include "..\Model\DSystemINI.h"
#include "DlgAutoManualScaleTable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupOption2

IMPLEMENT_DYNCREATE(CPaneProcessSetupOption2, CFormView)

CPaneProcessSetupOption2::CPaneProcessSetupOption2()
	: CFormView(CPaneProcessSetupOption2::IDD)
{
	//{{AFX_DATA_INIT(CPaneProcessSetupOption2)
	m_bCheckSuctionError		= FALSE;
}

CPaneProcessSetupOption2::~CPaneProcessSetupOption2()
{
}

void CPaneProcessSetupOption2::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneProcessSetupOption2)
	DDX_Control(pDX, IDC_CHECK_SUCTION_ERROR, m_chkCheckSuctionError);
	DDX_Control(pDX, IDC_CHECK_SUCTION_REJECT, m_chkRejectSuctionOff);
	DDX_Control(pDX, IDC_CHECK_MARKING_DUAL, m_chkDualMode);
	
	DDX_Control(pDX, IDC_EDIT_2ND_PCB_HEIGHT_MIN, m_edt2ndPCBHeightMin);
	DDX_Control(pDX, IDC_EDIT_2ND_PCB_HEIGHT_MAX, m_edt2ndPCBHeightMax);
	DDX_Control(pDX, IDC_EDIT_1ST_PCB_HEIGHT_MIN, m_edt1stPCBHeightMin);
	DDX_Control(pDX, IDC_EDIT_1ST_PCB_HEIGHT_MAX, m_edt1stPCBHeightMax);

	DDX_Control(pDX, IDC_EDIT_2ND_PCB_HEIGHT_MIN2, m_edt2ndPCBHeightMin2);
	DDX_Control(pDX, IDC_EDIT_2ND_PCB_HEIGHT_MAX2, m_edt2ndPCBHeightMax2);
	DDX_Control(pDX, IDC_EDIT_1ST_PCB_HEIGHT_MIN2, m_edt1stPCBHeightMin2);
	DDX_Control(pDX, IDC_EDIT_1ST_PCB_HEIGHT_MAX2, m_edt1stPCBHeightMax2);

	DDX_Control(pDX, IDC_EDIT_ALIGN_TIME, m_edtAlignTime);
	DDX_Control(pDX, IDC_EDIT_LOAD_TIME, m_edtLoadTime);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_TIME, m_edtUnloadTime);
	DDX_Control(pDX, IDC_BUTTON_RESET_TOTAL_SHOTS, m_btnResetTotalShots);
	DDX_Control(pDX, IDC_EDIT_ALIGN_TIME_START, m_edtAlignStartTime);
	DDX_Control(pDX, IDC_EDIT_ALIGN_TIME_DUAL, m_edtAlignDualTime);
	DDX_Control(pDX, IDC_EDIT_ALIGN_TIME_SINGLE, m_edtAlignSingleTime);
	DDX_Control(pDX, IDC_EDIT_ALIGN_TIME_DUAL2, m_edtAlignDualTimeOnlyPCB);
	DDX_Control(pDX, IDC_EDIT_ALIGN_TIME_SINGLE2, m_edtAlignSingleTimeOnlyPCB);
	DDX_Control(pDX, IDC_EDIT_ZAXIS_TOL,m_edtZAxisTolerance);

	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSX, m_edtAcrylFlatPosX);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSY, m_edtAcrylFlatPosY);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSX2, m_edtAcrylFlatPosX2);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSY2, m_edtAcrylFlatPosY2);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSX3, m_edtAcrylFlatPosX3);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSY3, m_edtAcrylFlatPosY3);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSX4, m_edtAcrylFlatPosX4);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSY4, m_edtAcrylFlatPosY4);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSX5, m_edtAcrylFlatPosX5);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSY5, m_edtAcrylFlatPosY5);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSX6, m_edtAcrylFlatPosX6);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSY6, m_edtAcrylFlatPosY6);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSX7, m_edtAcrylFlatPosX7);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSY7, m_edtAcrylFlatPosY7);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSX8, m_edtAcrylFlatPosX8);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSY8, m_edtAcrylFlatPosY8);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSX9, m_edtAcrylFlatPosX9);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_POSY9, m_edtAcrylFlatPosY9);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_TOL, m_edtAcrylFlatTol);
	DDX_Control(pDX, IDC_EDIT_ACRYL_FLAT_REF, m_edtAcrylFlatRef);
	DDX_Control(pDX, IDC_BUTTON_AUTO_MANUAL_SCALE, m_btnAutoManualScale);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneProcessSetupOption2, CFormView)
	//{{AFX_MSG_MAP(CPaneProcessSetupOption2)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_RESET_TOTAL_SHOTS, OnButtonResetTotalShots)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_AUTO_MANUAL_SCALE, &CPaneProcessSetupOption2::OnBnClickedButtonAutoManualScale)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupOption2 diagnostics

#ifdef _DEBUG
void CPaneProcessSetupOption2::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneProcessSetupOption2::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupOption2 message handlers

void CPaneProcessSetupOption2::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitEditControl();
	InitBtnControl();
	
	if( gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 0)
	{
		m_edt2ndPCBHeightMax.SetWindowText( _T("NO USE") );
		m_edt2ndPCBHeightMax.EnableWindow(FALSE);
		m_edt2ndPCBHeightMin.SetWindowText( _T("NO USE") );
		m_edt2ndPCBHeightMin.EnableWindow(FALSE);
	}
	
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0)
	{
		m_edt2ndPCBHeightMax.SetWindowText( _T("NO USE") );
		m_edt2ndPCBHeightMax.EnableWindow(FALSE);
		m_edt2ndPCBHeightMin.SetWindowText( _T("NO USE") );
		m_edt2ndPCBHeightMin.EnableWindow(FALSE);
		
		if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		{
			m_edt1stPCBHeightMax.SetWindowText( _T("NO USE") );
			m_edt1stPCBHeightMax.EnableWindow(FALSE);
			m_edt1stPCBHeightMin.SetWindowText( _T("NO USE") );
			m_edt1stPCBHeightMin.EnableWindow(FALSE);
		}
	}
	
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_UMAC)
		m_edtAlignTime.EnableWindow(FALSE);
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		GetDlgItem(IDC_STATIC_PREHEAT_MODULATION_TIME2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_PREHEAT_TIME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_PREHEAT_MODULATION_TIME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_PREHEAT_TIME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_HOUR)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_MIN)->ShowWindow(SW_HIDE);
	}
	if(gSystemINI.m_sHardWare.nManualMachine)
	{
		GetDlgItem(IDC_STATIC_ALIGN)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_ALIGN_TIME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_ALIGN_TIME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SEC)->ShowWindow(SW_HIDE);
	}
}

HBRUSH CPaneProcessSetupOption2::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_PCB_HEIGHT_RANGE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SUCTION)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_ALIGN)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TOTAL_SHOTS_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_ALIGN_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SCAL_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_ACRYL_FLAT_POS)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

BOOL CPaneProcessSetupOption2::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneProcessSetupOption2::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(120, "Arial Bold");

	GetDlgItem(IDC_STATIC_ALIGN)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ALIGN_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNlOAD_TIME)->SetFont( &m_fntStatic );


	// The range of PCB's Height
	GetDlgItem(IDC_STATIC_PCB_HEIGHT_RANGE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PCB_HEIGHT_MAX)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PCB_HEIGHT_MIN)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_PCB_HEIGHT_MAX2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PCB_HEIGHT_MIN2)->SetFont( &m_fntStatic );


	// Suction Error Check
	GetDlgItem(IDC_STATIC_SUCTION)->SetFont( &m_fntStatic );

	// LaserShot
	GetDlgItem(IDC_STATIC_TOTAL_SHOTS_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TOTAL_SHOTS_MSG)->SetFont( &m_fntStatic );

	//Align Setting 
	GetDlgItem(IDC_STATIC_ALIGN_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ALIGN_TIME_SINGLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ALIGN_TIME_DUAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ALIGN_START)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSX)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSX2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSY2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSX3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSY3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSX4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSY4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSX5)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSY5)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSX6)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSY6)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSX7)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSY7)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSX8)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSY8)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSX9)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POSY9)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_ACRYL_FLAT_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ZAXIS_TOL)->SetFont( &m_fntStatic);
}

void CPaneProcessSetupOption2::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	m_edtAlignTime.SetFont( &m_fntEdit );
	m_edtAlignTime.SetForeColor( BLACK_COLOR );
	m_edtAlignTime.SetBackColor( WHITE_COLOR );
	m_edtAlignTime.SetReceivedFlag( 1 );
	m_edtAlignTime.SetWindowText( _T("100") );

	m_edtLoadTime.SetFont( &m_fntEdit );
	m_edtLoadTime.SetForeColor( BLACK_COLOR );
	m_edtLoadTime.SetBackColor( WHITE_COLOR );
	m_edtLoadTime.SetReceivedFlag( 1 );
	m_edtLoadTime.SetWindowText( _T("100") );

	m_edtUnloadTime.SetFont( &m_fntEdit );
	m_edtUnloadTime.SetForeColor( BLACK_COLOR );
	m_edtUnloadTime.SetBackColor( WHITE_COLOR );
	m_edtUnloadTime.SetReceivedFlag( 1 );
	m_edtUnloadTime.SetWindowText( _T("100") );

	// The range of PCB's Height
	m_edt1stPCBHeightMax.SetFont( &m_fntEdit );
	m_edt1stPCBHeightMax.SetForeColor( BLACK_COLOR );
	m_edt1stPCBHeightMax.SetBackColor( WHITE_COLOR );
	m_edt1stPCBHeightMax.SetReceivedFlag( 3 );
	m_edt1stPCBHeightMax.SetWindowText( _T("1.5") );

	m_edt1stPCBHeightMin.SetFont( &m_fntEdit );
	m_edt1stPCBHeightMin.SetForeColor( BLACK_COLOR );
	m_edt1stPCBHeightMin.SetBackColor( WHITE_COLOR );
	m_edt1stPCBHeightMin.SetReceivedFlag( 3 );
	m_edt1stPCBHeightMin.SetWindowText( _T("0.5") );

	m_edt2ndPCBHeightMax.SetFont( &m_fntEdit );
	m_edt2ndPCBHeightMax.SetForeColor( BLACK_COLOR );
	m_edt2ndPCBHeightMax.SetBackColor( WHITE_COLOR );
	m_edt2ndPCBHeightMax.SetReceivedFlag( 3 );
	m_edt2ndPCBHeightMax.SetWindowText( _T("1.5") );

	m_edt2ndPCBHeightMin.SetFont( &m_fntEdit );
	m_edt2ndPCBHeightMin.SetForeColor( BLACK_COLOR );
	m_edt2ndPCBHeightMin.SetBackColor( WHITE_COLOR );
	m_edt2ndPCBHeightMin.SetReceivedFlag( 3 );
	m_edt2ndPCBHeightMin.SetWindowText( _T("0.5") );



	m_edt1stPCBHeightMax2.SetFont( &m_fntEdit );
	m_edt1stPCBHeightMax2.SetForeColor( BLACK_COLOR );
	m_edt1stPCBHeightMax2.SetBackColor( WHITE_COLOR );
	m_edt1stPCBHeightMax2.SetReceivedFlag( 3 );
	m_edt1stPCBHeightMax2.SetWindowText( _T("0.05") );

	m_edt1stPCBHeightMin2.SetFont( &m_fntEdit );
	m_edt1stPCBHeightMin2.SetForeColor( BLACK_COLOR );
	m_edt1stPCBHeightMin2.SetBackColor( WHITE_COLOR );
	m_edt1stPCBHeightMin2.SetReceivedFlag( 3 );
	m_edt1stPCBHeightMin2.SetWindowText( _T("0.05") );

	m_edt2ndPCBHeightMax2.SetFont( &m_fntEdit );
	m_edt2ndPCBHeightMax2.SetForeColor( BLACK_COLOR );
	m_edt2ndPCBHeightMax2.SetBackColor( WHITE_COLOR );
	m_edt2ndPCBHeightMax2.SetReceivedFlag( 3 );
	m_edt2ndPCBHeightMax2.SetWindowText( _T("0.05") );

	m_edt2ndPCBHeightMin2.SetFont( &m_fntEdit );
	m_edt2ndPCBHeightMin2.SetForeColor( BLACK_COLOR );
	m_edt2ndPCBHeightMin2.SetBackColor( WHITE_COLOR );
	m_edt2ndPCBHeightMin2.SetReceivedFlag( 3 );
	m_edt2ndPCBHeightMin2.SetWindowText( _T("0.05") );


	//Align Single Time
	m_edtAlignSingleTime.SetFont( &m_fntEdit );
	m_edtAlignSingleTime.SetForeColor( BLACK_COLOR );
	m_edtAlignSingleTime.SetBackColor( WHITE_COLOR );
	m_edtAlignSingleTime.SetReceivedFlag( 1 );
	m_edtAlignSingleTime.SetWindowText( _T("10") );

	//Align dual Time
	m_edtAlignDualTime.SetFont( &m_fntEdit );
	m_edtAlignDualTime.SetForeColor( BLACK_COLOR );
	m_edtAlignDualTime.SetBackColor( WHITE_COLOR );
	m_edtAlignDualTime.SetReceivedFlag( 1 );
	m_edtAlignDualTime.SetWindowText( _T("10") );

	//Align Single Time only pcb
	m_edtAlignSingleTimeOnlyPCB.SetFont( &m_fntEdit );
	m_edtAlignSingleTimeOnlyPCB.SetForeColor( BLACK_COLOR );
	m_edtAlignSingleTimeOnlyPCB.SetBackColor( WHITE_COLOR );
	m_edtAlignSingleTimeOnlyPCB.SetReceivedFlag( 1 );
	m_edtAlignSingleTimeOnlyPCB.SetWindowText( _T("10") );

	//Align dual Time only pcb
	m_edtAlignDualTimeOnlyPCB.SetFont( &m_fntEdit );
	m_edtAlignDualTimeOnlyPCB.SetForeColor( BLACK_COLOR );
	m_edtAlignDualTimeOnlyPCB.SetBackColor( WHITE_COLOR );
	m_edtAlignDualTimeOnlyPCB.SetReceivedFlag( 1 );
	m_edtAlignDualTimeOnlyPCB.SetWindowText( _T("10") );

	//Z-Axis Focus Tolerance
	m_edtZAxisTolerance.SetFont(&m_fntEdit);
	m_edtZAxisTolerance.SetForeColor( BLACK_COLOR );
	m_edtZAxisTolerance.SetBackColor( WHITE_COLOR );
	m_edtZAxisTolerance.SetReceivedFlag( 3 );
	m_edtZAxisTolerance.SetWindowText( _T("3") );

	//Align Single Time
	m_edtAlignStartTime.SetFont( &m_fntEdit );
	m_edtAlignStartTime.SetForeColor( BLACK_COLOR );
	m_edtAlignStartTime.SetBackColor( WHITE_COLOR );
	m_edtAlignStartTime.SetReceivedFlag( 1 );
	m_edtAlignStartTime.SetWindowText( _T("10") );

	//Acryl Flat Position
	m_edtAcrylFlatPosX.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosX.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosX.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosX.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosX.SetWindowText( _T("0.0") );

	m_edtAcrylFlatPosY.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosY.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosY.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosY.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosY.SetWindowText( _T("0.0") );

	m_edtAcrylFlatPosX2.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosX2.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosX2.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosX2.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosX2.SetWindowText( _T("0.0") );					
	m_edtAcrylFlatPosY2.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosY2.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosY2.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosY2.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosY2.SetWindowText( _T("0.0") );

	m_edtAcrylFlatPosX3.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosX3.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosX3.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosX3.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosX3.SetWindowText( _T("0.0") );					
	m_edtAcrylFlatPosY3.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosY3.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosY3.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosY3.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosY3.SetWindowText( _T("0.0") );

	m_edtAcrylFlatPosX4.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosX4.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosX4.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosX4.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosX4.SetWindowText( _T("0.0") );					
	m_edtAcrylFlatPosY4.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosY4.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosY4.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosY4.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosY4.SetWindowText( _T("0.0") );
	
	m_edtAcrylFlatPosX5.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosX5.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosX5.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosX5.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosX5.SetWindowText( _T("0.0") );					
	m_edtAcrylFlatPosY5.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosY5.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosY5.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosY5.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosY5.SetWindowText( _T("0.0") );

	m_edtAcrylFlatPosX6.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosX6.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosX6.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosX6.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosX6.SetWindowText( _T("0.0") );					
	m_edtAcrylFlatPosY6.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosY6.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosY6.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosY6.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosY6.SetWindowText( _T("0.0") );

	m_edtAcrylFlatPosX7.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosX7.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosX7.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosX7.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosX7.SetWindowText( _T("0.0") );					
	m_edtAcrylFlatPosY7.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosY7.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosY7.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosY7.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosY7.SetWindowText( _T("0.0") );

	m_edtAcrylFlatPosX8.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosX8.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosX8.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosX8.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosX8.SetWindowText( _T("0.0") );					
	m_edtAcrylFlatPosY8.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosY8.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosY8.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosY8.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosY8.SetWindowText( _T("0.0") );

	m_edtAcrylFlatPosX9.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosX9.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosX9.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosX9.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosX9.SetWindowText( _T("0.0") );					
	m_edtAcrylFlatPosY9.SetFont( &m_fntEdit );
	m_edtAcrylFlatPosY9.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatPosY9.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatPosY9.SetReceivedFlag( 3 );
	m_edtAcrylFlatPosY9.SetWindowText( _T("0.0") );

	m_edtAcrylFlatTol.SetFont( &m_fntEdit );
	m_edtAcrylFlatTol.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatTol.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatTol.SetReceivedFlag( 3 );
	m_edtAcrylFlatTol.SetWindowText( _T("0.0") );

	m_edtAcrylFlatRef.SetFont( &m_fntEdit );
	m_edtAcrylFlatRef.SetForeColor( BLACK_COLOR );
	m_edtAcrylFlatRef.SetBackColor( WHITE_COLOR );
	m_edtAcrylFlatRef.SetReceivedFlag( 3 );
	m_edtAcrylFlatRef.SetWindowText( _T("0.0") );
	

}

void CPaneProcessSetupOption2::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_chkCheckSuctionError.SetFont( &m_fntBtn );
	m_chkCheckSuctionError.SetImageOrg( 10, 3 );
	m_chkCheckSuctionError.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkCheckSuctionError.EnableBallonToolTip();
	m_chkCheckSuctionError.SetToolTipText( _T("Check Suction Error") );
	m_chkCheckSuctionError.SetBtnCursor(IDC_HAND_1);

	m_chkRejectSuctionOff.SetFont( &m_fntBtn );
	m_chkRejectSuctionOff.SetImageOrg( 10, 3 );
	m_chkRejectSuctionOff.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkRejectSuctionOff.EnableBallonToolTip();
	m_chkRejectSuctionOff.SetToolTipText( _T("Suction off option") );
	m_chkRejectSuctionOff.SetBtnCursor(IDC_HAND_1);

	m_chkDualMode.SetFont( &m_fntBtn );
	m_chkDualMode.SetImageOrg( 10, 3 );
	m_chkDualMode.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkDualMode.EnableBallonToolTip();
	m_chkDualMode.SetToolTipText( _T("Use Marking Dual Mode") );
	m_chkDualMode.SetBtnCursor(IDC_HAND_1);
	
	// Reset Total Shots
	m_btnResetTotalShots.SetFont( &m_fntBtn );
	m_btnResetTotalShots.SetFlat( FALSE );
	m_btnResetTotalShots.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetTotalShots.EnableBallonToolTip();
	m_btnResetTotalShots.SetToolTipText( _T("Reset total shots") );
	m_btnResetTotalShots.SetBtnCursor( IDC_HAND_1 );
}

void CPaneProcessSetupOption2::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneProcessSetupOption2::DispProcessOption()
{
	CString strData;

	// Align Time
	strData.Format(_T("%d"), m_sProcessOption.nAlignTime);
	m_edtAlignTime.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%d"), m_sProcessOption.nLoadTime);
	m_edtLoadTime.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%d"), m_sProcessOption.nUnloadTime);
	m_edtUnloadTime.SetWindowText( (LPCTSTR)strData );

	// 1'st PCB Height Min, Max
	strData.Format(_T("%.2f"), m_sProcessOption.d1stPCBHeightMin);
	m_edt1stPCBHeightMin.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.2f"), m_sProcessOption.d1stPCBHeightMax);
	m_edt1stPCBHeightMax.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessOption.d1stAutoPCBHeightRangeMin);
	m_edt1stPCBHeightMin2.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sProcessOption.d1stAutoPCBHeightRangeMax);
	m_edt1stPCBHeightMax2.SetWindowText( (LPCTSTR)strData );

	if( gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 1 )
	{
		// 2'nd PCB Height Min, Max
		strData.Format(_T("%.2f"), m_sProcessOption.d2ndPCBHeightMin);
		m_edt2ndPCBHeightMin.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.2f"), m_sProcessOption.d2ndPCBHeightMax);
		m_edt2ndPCBHeightMax.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sProcessOption.d2ndAutoPCBHeightRangeMin);
		m_edt2ndPCBHeightMin2.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sProcessOption.d2ndAutoPCBHeightRangeMax);
		m_edt2ndPCBHeightMax2.SetWindowText( (LPCTSTR)strData );
	}

	// Check Suction Error
	m_bCheckSuctionError = m_sProcessOption.bCheckSuctionError;
	m_chkCheckSuctionError.SetCheck( m_bCheckSuctionError );

	// Reject Suction off 
	m_bRejectSuctionOff = m_sProcessOption.bRejectSuctionOff;
	m_chkRejectSuctionOff.SetCheck( m_bRejectSuctionOff );

	m_bDualMode = m_sProcessOption.bMarkingDualMode;
	m_chkDualMode.SetCheck( m_bDualMode );
	
	// Total Shot
	strData.Format(_T("%I64d"), m_sProcessOption.nShotCount);
	MakeReadableNumber( strData );
	SetDlgItemText(IDC_STATIC_TOTAL_SHOTS_MSG, (LPCTSTR)strData );



	//Z-Axis Focus Tol
	strData.Format(_T("%.3f"),m_sProcessOption.dLaserZAxisTol );
	m_edtZAxisTolerance.SetWindowText( (LPCTSTR)strData );


	//Align Dual Time
	strData.Format(_T("%d"), m_sProcessOption.nAlignDualTime);
	m_edtAlignDualTime.SetWindowText( (LPCTSTR)strData );

	//Align Single Time
	strData.Format(_T("%d"), m_sProcessOption.nAlignSingleTime);
	m_edtAlignSingleTime.SetWindowText( (LPCTSTR)strData );

	//Align Dual Time only pcb
	strData.Format(_T("%d"), m_sProcessOption.nAlignDualTimeOnlyPCB);
	m_edtAlignDualTimeOnlyPCB.SetWindowText( (LPCTSTR)strData );

	//Align Single Time only pcb
	strData.Format(_T("%d"), m_sProcessOption.nAlignSingleTimeOnlyPCB);
	m_edtAlignSingleTimeOnlyPCB.SetWindowText( (LPCTSTR)strData );

	//Align Start Percent
	strData.Format(_T("%d"), m_sProcessOption.nAlignStartPer);
	m_edtAlignStartTime.SetWindowText( (LPCTSTR)strData );

	//AcrylFlat Pos
	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosX[0]);
	m_edtAcrylFlatPosX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosY[0]);
	m_edtAcrylFlatPosY.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosX[1]);
	m_edtAcrylFlatPosX2.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosY[1]);
	m_edtAcrylFlatPosY2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosX[2]);
	m_edtAcrylFlatPosX3.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosY[2]);
	m_edtAcrylFlatPosY3.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosX[3]);
	m_edtAcrylFlatPosX4.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosY[3]);
	m_edtAcrylFlatPosY4.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosX[4]);
	m_edtAcrylFlatPosX5.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosY[4]);
	m_edtAcrylFlatPosY5.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosX[5]);
	m_edtAcrylFlatPosX6.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosY[5]);
	m_edtAcrylFlatPosY6.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosX[6]);
	m_edtAcrylFlatPosX7.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosY[6]);
	m_edtAcrylFlatPosY7.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosX[7]);
	m_edtAcrylFlatPosX8.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosY[7]);
	m_edtAcrylFlatPosY8.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosX[8]);
	m_edtAcrylFlatPosX9.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatPosY[8]);
	m_edtAcrylFlatPosY9.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatTol);
	m_edtAcrylFlatTol.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.3f"), m_sProcessOption.dAcrylFlatRef);
	m_edtAcrylFlatRef.SetWindowText( (LPCTSTR)strData );

	UpdateData(FALSE);
}

void CPaneProcessSetupOption2::SetProcessOption(SPROCESSOPTION sProcessOption)
{
	memcpy( &m_sProcessOption, &sProcessOption, sizeof(m_sProcessOption) );

	DispProcessOption();
}

void CPaneProcessSetupOption2::GetProcessOption(SPROCESSOPTION* pProcessOption)
{
	memcpy( pProcessOption, &m_sProcessOption, sizeof(m_sProcessOption) );
}

void CPaneProcessSetupOption2::OnApply()
{
	CString strData;

	UpdateData(TRUE);

	// Align Time
	m_edtAlignTime.GetWindowText( strData );
	m_sProcessOption.nAlignTime = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtLoadTime.GetWindowText( strData );
	m_sProcessOption.nLoadTime = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtUnloadTime.GetWindowText( strData );
	m_sProcessOption.nUnloadTime = atoi( (LPSTR)(LPCTSTR)strData );

	// 1'st PCB Height Min, Max
	m_edt1stPCBHeightMin.GetWindowText( strData );
	m_sProcessOption.d1stPCBHeightMin = atof( (LPSTR)(LPCTSTR)strData );
	m_edt1stPCBHeightMax.GetWindowText( strData );
	m_sProcessOption.d1stPCBHeightMax = atof( (LPSTR)(LPCTSTR)strData );
	m_edt1stPCBHeightMin2.GetWindowText( strData );
	m_sProcessOption.d1stAutoPCBHeightRangeMin = atof( (LPSTR)(LPCTSTR)strData );
	m_edt1stPCBHeightMax2.GetWindowText( strData );
	m_sProcessOption.d1stAutoPCBHeightRangeMax = atof( (LPSTR)(LPCTSTR)strData );



	
	if( gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 1 )
	{
		// 2'nd PCB Height Min, Max
		m_edt2ndPCBHeightMin.GetWindowText( strData );
		m_sProcessOption.d2ndPCBHeightMin = atof( (LPSTR)(LPCTSTR)strData );
		m_edt2ndPCBHeightMax.GetWindowText( strData );
		m_sProcessOption.d2ndPCBHeightMax = atof( (LPSTR)(LPCTSTR)strData );
		m_edt2ndPCBHeightMin2.GetWindowText( strData );
		m_sProcessOption.d2ndAutoPCBHeightRangeMin = atof( (LPSTR)(LPCTSTR)strData );
		m_edt2ndPCBHeightMax2.GetWindowText( strData );
		m_sProcessOption.d2ndAutoPCBHeightRangeMax = atof( (LPSTR)(LPCTSTR)strData );
	}

	//Z-Axis Focus Tolerance
	m_edtZAxisTolerance.GetWindowText(strData);
	m_sProcessOption.dLaserZAxisTol = atof( (LPSTR)(LPCTSTR)strData );

	// Check Suction Error
	m_bCheckSuctionError = m_chkCheckSuctionError.GetCheck();
	m_sProcessOption.bCheckSuctionError = m_bCheckSuctionError;

	// Reject Suction off 
	m_bRejectSuctionOff = m_chkRejectSuctionOff.GetCheck();
	m_sProcessOption.bRejectSuctionOff = m_bRejectSuctionOff;

	m_bDualMode = m_chkDualMode.GetCheck();
	m_sProcessOption.bMarkingDualMode = m_bDualMode;

	//Align Start Percent
	m_edtAlignStartTime.GetWindowText( strData );
	m_sProcessOption.nAlignStartPer = atoi( (LPSTR)(LPCTSTR)strData );

	//Align Dual Time
	m_edtAlignDualTime.GetWindowText( strData );
	m_sProcessOption.nAlignDualTime = atoi( (LPSTR)(LPCTSTR)strData );

	//Align Single Time
	m_edtAlignSingleTime.GetWindowText( strData );
	m_sProcessOption.nAlignSingleTime = atoi( (LPSTR)(LPCTSTR)strData );

	//Align Dual Time only pcb
	m_edtAlignDualTimeOnlyPCB.GetWindowText( strData );
	m_sProcessOption.nAlignDualTimeOnlyPCB = atoi( (LPSTR)(LPCTSTR)strData );

	//Align Single Time only pcb
	m_edtAlignSingleTimeOnlyPCB.GetWindowText( strData );
	m_sProcessOption.nAlignSingleTimeOnlyPCB = atoi( (LPSTR)(LPCTSTR)strData );

	//Acryl Flat Pos
	m_edtAcrylFlatPosX.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosX[0] = atof( (LPSTR)(LPCTSTR)strData );
	m_edtAcrylFlatPosY.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosY[0] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtAcrylFlatPosX2.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosX[1] = atof( (LPSTR)(LPCTSTR)strData );
	m_edtAcrylFlatPosY2.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosY[1] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtAcrylFlatPosX3.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosX[2] = atof( (LPSTR)(LPCTSTR)strData );
	m_edtAcrylFlatPosY3.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosY[2] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtAcrylFlatPosX4.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosX[3] = atof( (LPSTR)(LPCTSTR)strData );
	m_edtAcrylFlatPosY4.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosY[3] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtAcrylFlatPosX5.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosX[4] = atof( (LPSTR)(LPCTSTR)strData );
	m_edtAcrylFlatPosY5.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosY[4] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtAcrylFlatPosX6.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosX[5] = atof( (LPSTR)(LPCTSTR)strData );
	m_edtAcrylFlatPosY6.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosY[5] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtAcrylFlatPosX7.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosX[6] = atof( (LPSTR)(LPCTSTR)strData );
	m_edtAcrylFlatPosY7.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosY[6] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtAcrylFlatPosX8.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosX[7] = atof( (LPSTR)(LPCTSTR)strData );
	m_edtAcrylFlatPosY8.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosY[7] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtAcrylFlatPosX9.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosX[8] = atof( (LPSTR)(LPCTSTR)strData );
	m_edtAcrylFlatPosY9.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatPosY[8] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtAcrylFlatTol.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatTol = atof( (LPSTR)(LPCTSTR)strData );

	m_edtAcrylFlatRef.GetWindowText( strData );
	m_sProcessOption.dAcrylFlatRef = atof( (LPSTR)(LPCTSTR)strData );
	

}

void CPaneProcessSetupOption2::OnButtonResetTotalShots() 
{
	if( IDNO == ErrMessage(IDS_RESET_TOTAL_SHOTS, MB_YESNO | MB_ICONQUESTION) )
		return;
	
	CString strData;
	
//	strData.Format(_T("0"));
	strData = "Total fired shots is 0.";
	SetDlgItemText(IDC_STATIC_TOTAL_SHOTS_MSG, strData );

	strData.Format(_T("Previous total fired shots is %d"), m_sProcessOption.nShotCount);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog("Reset total fired shots.", strData, TRUE);

	m_sProcessOption.nShotCount = 0;
}

void CPaneProcessSetupOption2::MakeReadableNumber(CString& strVal)
{
	int nLen = strVal.GetLength();
	
	if (nLen <= 3)
	{
		strVal = "Total fired shots is " + strVal;
		return;
	}
	else
	{
		for( int nComma = nLen - 3; nComma > 0; nComma -= 3)
			strVal.Insert(nComma, _T(','));

		strVal = "Total fired shots is " + strVal;
	}
}

CString CPaneProcessSetupOption2::GetChangeValueStr()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));

	if(m_sProcessOption.nAlignTime != gProcessINI.m_sProcessOption.nAlignTime)
	{
		strTemp.Format(_T("| Align work Time : %d sec "), 
			m_sProcessOption.nAlignTime);
		strMessage += strTemp;
	}
	if(m_sProcessOption.nLoadTime != gProcessINI.m_sProcessOption.nLoadTime)
	{
		strTemp.Format(_T("| Load work Time : %d sec "), 
			m_sProcessOption.nLoadTime);
		strMessage += strTemp;
	}
	if(m_sProcessOption.nUnloadTime != gProcessINI.m_sProcessOption.nUnloadTime)
	{
		strTemp.Format(_T("| Unload work Time : %d sec "), 
			m_sProcessOption.nUnloadTime);
		strMessage += strTemp;
	}

	if(m_sProcessOption.d1stPCBHeightMin != gProcessINI.m_sProcessOption.d1stPCBHeightMin ||
		m_sProcessOption.d1stPCBHeightMax != gProcessINI.m_sProcessOption.d1stPCBHeightMax)
	{
		strTemp.Format(_T("| PCB Thickness : %.3f ~ %.3f )mm "), 
			m_sProcessOption.d1stPCBHeightMin,
			m_sProcessOption.d1stPCBHeightMax);
		strMessage += strTemp;
	}
	
	if( gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 1)
	{
		if(m_sProcessOption.d2ndPCBHeightMin != gProcessINI.m_sProcessOption.d2ndPCBHeightMin ||
			m_sProcessOption.d2ndPCBHeightMax != gProcessINI.m_sProcessOption.d2ndPCBHeightMax)
		{
			strTemp.Format(_T("| PCB Thickness : %.3f ~ %.3f )mm "), 
				m_sProcessOption.d2ndPCBHeightMin,
				m_sProcessOption.d2ndPCBHeightMax);
			strMessage += strTemp;
		}
	}
	
	if(m_sProcessOption.bCheckSuctionError != gProcessINI.m_sProcessOption.bCheckSuctionError)
	{
		if(m_sProcessOption.bCheckSuctionError)
			strTemp.Format(_T("| Use Suction check "));
		else
			strTemp.Format(_T("| Don't use Suction check "));
		strMessage += strTemp;
	}
		
	if(m_sProcessOption.nAlignDualTime != gProcessINI.m_sProcessOption.nAlignDualTime)
	{
		strTemp.Format(_T("| Align Dual Time : %d sec "), 
			m_sProcessOption.nAlignDualTime);
		strMessage += strTemp;
	}
	if(m_sProcessOption.nAlignSingleTime != gProcessINI.m_sProcessOption.nAlignSingleTime)
	{
		strTemp.Format(_T("| Align Single Time : %d sec "), 
			m_sProcessOption.nAlignSingleTime);
		strMessage += strTemp;
	}
	if(m_sProcessOption.nAlignStartPer != gProcessINI.m_sProcessOption.nAlignStartPer)
	{
		strTemp.Format(_T("| Algin Start Time : %d Percent "), 
			m_sProcessOption.nAlignStartPer);
		strMessage += strTemp;
	}
	
	return strMessage;
}

void CPaneProcessSetupOption2::EnableControl(BOOL bUse)
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC)
	{
		m_edtAlignTime.EnableWindow(bUse);
		m_edtLoadTime.EnableWindow(bUse);
		m_edtUnloadTime.EnableWindow(bUse);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 0)
	{
#ifndef __KUNSAN_LAVIA__
		m_edt1stPCBHeightMax.EnableWindow(bUse);
		m_edt1stPCBHeightMin.EnableWindow(bUse);
#else
		if( m_nLevel == 1)
		{
			m_edt1stPCBHeightMax.EnableWindow(TRUE);
			m_edt1stPCBHeightMin.EnableWindow(TRUE);
		}
		else
		{
			m_edt1stPCBHeightMax.EnableWindow(bUse);
			m_edt1stPCBHeightMin.EnableWindow(bUse);
		}

		m_edt1stPCBHeightMax2.EnableWindow(bUse);
		m_edt1stPCBHeightMin2.EnableWindow(bUse);

#endif
		
		if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 1 )
		{
	#ifndef __KUNSAN_LAVIA__
				m_edt2ndPCBHeightMax.EnableWindow(bUse);
				m_edt2ndPCBHeightMin.EnableWindow(bUse);
	#else
			if( m_nLevel == 1)
			{
				m_edt2ndPCBHeightMax.EnableWindow(TRUE);
				m_edt2ndPCBHeightMin.EnableWindow(TRUE);
			}
			else
			{
				m_edt2ndPCBHeightMax.EnableWindow(bUse);
				m_edt2ndPCBHeightMin.EnableWindow(bUse);
			}
			m_edt2ndPCBHeightMax2.EnableWindow(bUse);
			m_edt2ndPCBHeightMin2.EnableWindow(bUse);

	#endif
		}
	}
	else if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 1)
	{
#ifndef __KUNSAN_LAVIA__
		m_edt1stPCBHeightMax.EnableWindow(bUse);
		m_edt1stPCBHeightMin.EnableWindow(bUse);
#else
		if( m_nLevel == 1)
		{
			m_edt1stPCBHeightMax.EnableWindow(TRUE);
			m_edt1stPCBHeightMin.EnableWindow(TRUE);
		}
		else
		{
			m_edt1stPCBHeightMax.EnableWindow(bUse);
			m_edt1stPCBHeightMin.EnableWindow(bUse);
		}
		m_edt1stPCBHeightMax2.EnableWindow(bUse);
		m_edt1stPCBHeightMin2.EnableWindow(bUse);

#endif

	}
	m_chkRejectSuctionOff.EnableWindow(bUse);
	m_chkCheckSuctionError.EnableWindow(bUse);
	m_btnResetTotalShots.EnableWindow(bUse);
	m_chkDualMode.EnableWindow(bUse);

	m_edtAlignStartTime.EnableWindow(bUse);
	m_edtAlignDualTime.EnableWindow(bUse);
	m_edtAlignSingleTime.EnableWindow(bUse);
	m_edtAlignDualTimeOnlyPCB.EnableWindow(bUse);
	m_edtAlignSingleTimeOnlyPCB.EnableWindow(bUse);

	m_edtZAxisTolerance.EnableWindow(bUse);

}

void CPaneProcessSetupOption2::SetAuthorityByLevel(int nLevel)
{
	m_nLevel = nLevel;
	switch(nLevel)
	{
	case 0:
		EnableControl(FALSE);
		break;
	case 1:
#ifdef __KUNSAN_LAVIA__
		EnableControl(FALSE);
		break;
#endif
	case 2:
	case 3:
		EnableControl(TRUE);
		break;
	}
	if (m_nLevel < 3)
	{
		GetDlgItem(IDC_EDIT_ZAXIS_TOL)->EnableWindow(FALSE);
	}
}

BOOL CPaneProcessSetupOption2::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Process_Option2) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneProcessSetupOption2::OnBnClickedButtonAutoManualScale()
{
	CDlgAutoManualScaleTable dlg;

	dlg.SetAutoManualScale(gAutoManualScaleINI.m_sAutoManualScale);
	//	dlg.SetAuthorityByLevel(m_nUserLevel);
	if(dlg.DoModal() == IDOK)
	{

	}
}

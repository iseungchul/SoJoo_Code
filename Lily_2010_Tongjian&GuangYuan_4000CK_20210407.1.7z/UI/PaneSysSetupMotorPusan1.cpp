// PaneSysSetupMotorPusan1.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetupMotorPusan1.h"
#include "DlgComSetup.h"

#include "..\InterfaceMP920Module.h"
#include "..\device\HMotor.h"
//#include "..\device\devicemotor.h"
#include "..\device\HDeviceFactory.h"
#include "..\model\deasydrillerini.h"
#include "..\device\DeviceMotor.h"
#include "..\model\DSystemINI.h"

#include "..\EasyDrillerDlg.h"
#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "..\device\hvision.h"
#include "..\device\hvisionomi.h"
#include "..\device\HMotor.h"
#include "..\EasyDrillerDlg.h"
#include "PaneManualControl.h"
#include "PaneManualControlOneHole.h"

#include "..\Device\HHeightSensor.h"
#include "DlgVisionPixelSet.h"
#include "PaneManualControlPowerMeasurement.h"
#include "DlgMarkingParam.h"
#include "DlgMotorMove.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupMotorPusan1

IMPLEMENT_DYNCREATE(CPaneSysSetupMotorPusan1, CFormView)

CPaneSysSetupMotorPusan1::CPaneSysSetupMotorPusan1()
	: CFormView(CPaneSysSetupMotorPusan1::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupMotorPusan1)
	//}}AFX_DATA_INIT
	memset( &m_sSystemDevice, 0, sizeof(m_sSystemDevice) );
	memset( &m_pAxisInfo, 0, sizeof(m_pAxisInfo) );
	m_nIndex				= 0;
	m_nUserLevel			= 0;
}

CPaneSysSetupMotorPusan1::~CPaneSysSetupMotorPusan1()
{
}

void CPaneSysSetupMotorPusan1::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupMotorPusan1)
	DDX_Control(pDX, IDC_BUTTON_POWERMETER_PORT, m_btnPowermeterPort);
	DDX_Control(pDX, IDC_BUTTON_VISION_LAMP_PORT, m_btnVisionLampPort);
	DDX_Control(pDX, IDC_BUTTON_VISION_LAMP2_PORT, m_btnVisionLampPort2);
	
	DDX_Control(pDX, IDC_EDIT_VIBRATION_COUNT, m_edtVibrationCount);
	DDX_Control(pDX, IDC_EDIT_LP_UPDOWN, m_edtVibrationLPCount);
	DDX_Control(pDX, IDC_EDIT_SCANNER_FIELD_Y, m_edtScannerFieldY);
	DDX_Control(pDX, IDC_EDIT_SCANNER_FIELD_X, m_edtScannerFieldX);
	DDX_Control(pDX, IDC_EDIT_2ND_PANEL_ID, m_edt2ndPanelID);
	DDX_Control(pDX, IDC_EDIT_1ST_PANEL_ID, m_edt1stPanelID);
	DDX_Control(pDX, IDC_EDIT_SOFT_LIMIT_PLUS, m_edtSoftLimitPlus);
	DDX_Control(pDX, IDC_EDIT_SOFT_LIMIT_MINUS, m_edtSoftLimitMinus);
	DDX_Control(pDX, IDC_EDIT_MSCURVE, m_edtMoveSCurve);
	DDX_Control(pDX, IDC_EDIT_MACCEL, m_edtMoveAccel);
	DDX_Control(pDX, IDC_EDIT_MSCURVE_PRE, m_edtMoveSCurvePre);
	DDX_Control(pDX, IDC_EDIT_MACCEL_PRE, m_edtMoveAccelPre);
	DDX_Control(pDX, IDC_EDIT_MSCURVE_NEXT, m_edtMoveSCurveNext);
	DDX_Control(pDX, IDC_EDIT_MACCEL_NEXT, m_edtMoveAccelNext);
	DDX_Control(pDX, IDC_EDIT_MVELOCITY, m_edtMoveVelocity);
	DDX_Control(pDX, IDC_EDIT_SCALE, m_edtScale);
	DDX_Control(pDX, IDC_EDIT_VHEIGHT_2, m_edtLowVisionHeight);
	DDX_Control(pDX, IDC_EDIT_VHEIGHT_1, m_edtHighVisionHeight);
	DDX_Control(pDX, IDC_EDIT_HOFFSET_Y4, m_edtHOffset2ndLowY);
	DDX_Control(pDX, IDC_EDIT_HOFFSET_X4, m_edtHOffset2ndLowX);
	DDX_Control(pDX, IDC_EDIT_HOFFSET_Y3, m_edtHOffset2ndHighY);
	DDX_Control(pDX, IDC_EDIT_HOFFSET_X3, m_edtHOffset2ndHighX);
	DDX_Control(pDX, IDC_EDIT_HOFFSET_Y2, m_edtHOffset1stLowY);
	DDX_Control(pDX, IDC_EDIT_HOFFSET_X2, m_edtHOffset1stLowX);
	DDX_Control(pDX, IDC_EDIT_HOFFSET_Y1, m_edtHOffset1stHighY);
	DDX_Control(pDX, IDC_EDIT_HOFFSET_X1, m_edtHOffset1stHighX);

	DDX_Control(pDX, IDC_EDIT_WATER_FLOW1, m_edtWaterFlow1);
	DDX_Control(pDX, IDC_EDIT_WATER_FLOW2, m_edtWaterFlow2);
	DDX_Control(pDX, IDC_EDIT_WATER_FLOW_OFFSET1, m_edtWaterFlowOffset1);
	DDX_Control(pDX, IDC_EDIT_WATER_FLOW_OFFSET2, m_edtWaterFlowOffset2);
	DDX_Control(pDX, IDC_EDIT_MAIN_AIR, m_edtMainAir);
	DDX_Control(pDX, IDC_EDIT_DUST_SUCTION, m_edtDustSuction);
	DDX_Control(pDX, IDC_EDIT_TABLE_VACUUM1, m_edtTableVacuum1);
	DDX_Control(pDX, IDC_EDIT_TABLE_VACUUM2, m_edtTableVacuum2);

	DDX_Control(pDX, IDC_BUTTON_MARKING_PARAM, m_btnMarkingParam);
	DDX_Control(pDX, IDC_BUTTON_CAM_SET, m_btnPixelRevision);
	DDX_Control(pDX, IDC_LIST_AXIS, m_lbAxis);
	DDX_Control(pDX, IDC_BUTTON_MOTOR_MOVE, m_btnMotorMove);
	DDX_Control(pDX, IDC_BUTTON_SERVO_PORT, m_btnServoPort);
	DDX_Control(pDX, IDC_BUTTON_CHILLER, m_btnChillerPort);
	DDX_Control(pDX, IDC_BUTTON_HUMIDITY, m_btnHumidity);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupMotorPusan1, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupMotorPusan1)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_POWERMETER_PORT, OnButtonPowermeterPort)

	ON_BN_CLICKED(IDC_BUTTON_SERVO_PORT, OnButtonServoPort)
	ON_BN_CLICKED(IDC_BUTTON_MARKING_PARAM, OnButtonMarkingParam)
	ON_LBN_SELCHANGE(IDC_LIST_AXIS, OnSelchangeListAxis)
	ON_BN_CLICKED(IDC_BUTTON_CAM_SET, OnButtonCamSet)
	ON_BN_CLICKED(IDC_BUTTON_MOTOR_MOVE, OnButtonMove)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_CHILLER, &CPaneSysSetupMotorPusan1::OnBnClickedButtonChiller)
	ON_BN_CLICKED(IDC_BUTTON_HUMIDITY, &CPaneSysSetupMotorPusan1::OnBnClickedButtonHumidity)
	ON_BN_CLICKED(IDC_BUTTON_VISION_LAMP_PORT, &CPaneSysSetupMotorPusan1::OnBnClickedButtonVisionLampPort)
	ON_BN_CLICKED(IDC_BUTTON_VISION_LAMP2_PORT, &CPaneSysSetupMotorPusan1::OnBnClickedButtonVisionLamp2Port)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupMotorPusan1 diagnostics

#ifdef _DEBUG
void CPaneSysSetupMotorPusan1::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupMotorPusan1::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupMotorPusan1 message handlers

void CPaneSysSetupMotorPusan1::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitEditControl();
	InitListBoxControl();
	InitBtnControl();

	ShowAxisInfo( m_nIndex );
}

BOOL CPaneSysSetupMotorPusan1::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneSysSetupMotorPusan1::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130,_T("Arial Bold"));

	// Axis List
	GetDlgItem(IDC_STATIC_AXIS)->SetFont( &m_fntStatic );

	// Mechnical Setting
	GetDlgItem(IDC_STATIC_MECHANICAL_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HOFFSET_X1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HOFFSET_X2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HOFFSET_X3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HOFFSET_X4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HOFFSET_Y1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HOFFSET_Y2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HOFFSET_Y3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HOFFSET_Y4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VHEIGHT_1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VHEIGHT_2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCALE)->SetFont( &m_fntStatic );

	// Motor Setting
	GetDlgItem(IDC_STATIC_MOTOR_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MVELOCITY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MACCEL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MSCURVE)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_MACCEL_PRE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MSCURVE_PRE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MACCEL_NEXT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MSCURVE_NEXT)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_SOFT_LIMIT_PLUS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SOFT_LIMIT_MINUS)->SetFont( &m_fntStatic );

	// Height Sensor
	GetDlgItem(IDC_STATIC_HEIGHT_SENSOR)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_PANEL_ID)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_PANEL_ID)->SetFont( &m_fntStatic );

	if( 1 == gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
		GetDlgItem(IDC_STATIC_2ND_PANEL_ID)->EnableWindow(FALSE);
	else if( 0 == gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		GetDlgItem(IDC_STATIC_HEIGHT_SENSOR)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_1ST_PANEL_ID)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_2ND_PANEL_ID)->ShowWindow(SW_HIDE);
	}

	// Scanner Field Size
	GetDlgItem(IDC_STATIC_SCANNER_FIELD_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCANNER_FIELD_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCANNER_FIELD_Y)->SetFont( &m_fntStatic );

	// Vibration Setting
	GetDlgItem(IDC_STATIC_VIBRATION)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_VIBRATION_COUNT)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_LP_UPDOWN)->SetFont(&m_fntStatic);

	//any setting 
	GetDlgItem(IDC_STATIC_MOTOR_SETTING2)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_WATER_FLOW1)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_WATER_FLOW2)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_WATER_FLOW_OFFSET1)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_WATER_FLOW_OFFSET2)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_MAIN_AIR)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_DUST_SUCTION)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_TABLE_VACUUM1)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_TABLE_VACUUM2)->SetFont(&m_fntStatic);

#ifndef __KUNSAN_SAMSUNG_LARGE__
	GetDlgItem(IDC_STATIC_MOTOR_SETTING2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_WATER_FLOW1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_WATER_FLOW2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_MAIN_AIR)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_DUST_SUCTION)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_TABLE_VACUUM1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_TABLE_VACUUM2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_WATER_FLOW_OFFSET1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_WATER_FLOW_OFFSET2)->ShowWindow(SW_HIDE);

#endif
#ifndef __PUSAN1__
#ifndef __PUSAN2__
#ifndef __PUSAN_OLD_17__
#ifndef __KUNSAN_SAMSUNG_LARGE__
	GetDlgItem(IDC_STATIC_VIBRATION)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_VIBRATION_COUNT)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC1)->ShowWindow(SW_HIDE);
#endif
	GetDlgItem(IDC_STATIC_LP_UPDOWN)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC2)->ShowWindow(SW_HIDE);

#endif
#endif
#endif

	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		GetDlgItem(IDC_STATIC_MVELOCITY)->SetWindowText("Table Speed");
//		GetDlgItem(IDC_EDIT_MSCURVE)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_SCALE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SCALE)->ShowWindow(SW_HIDE);
	}

}

void CPaneSysSetupMotorPusan1::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130,_T("Arial Bold"));

	m_btnPowermeterPort.SetFont( &m_fntBtn );
	m_btnPowermeterPort.SetFlat( FALSE );
	m_btnPowermeterPort.SetImageOrg( 10, 3 );
	m_btnPowermeterPort.SetIcon( IDI_PORT );
	m_btnPowermeterPort.EnableBallonToolTip();
	m_btnPowermeterPort.SetToolTipText( _T("Setup Powermeter Port") );
	m_btnPowermeterPort.SetBtnCursor(IDC_HAND_1);

	m_btnVisionLampPort.SetFont(&m_fntBtn);
	m_btnVisionLampPort.SetFlat(FALSE);
	m_btnVisionLampPort.SetImageOrg(10, 3);
	m_btnVisionLampPort.SetIcon(IDI_PORT);
	m_btnVisionLampPort.EnableBallonToolTip();
	m_btnVisionLampPort.SetToolTipText(_T("Setup Vision Lamp Port"));
	m_btnVisionLampPort.SetBtnCursor(IDC_HAND_1);

	m_btnVisionLampPort2.SetFont(&m_fntBtn);
	m_btnVisionLampPort2.SetFlat(FALSE);
	m_btnVisionLampPort2.SetImageOrg(10, 3);
	m_btnVisionLampPort2.SetIcon(IDI_PORT);
	m_btnVisionLampPort2.EnableBallonToolTip();
	m_btnVisionLampPort2.SetToolTipText(_T("Setup Vision Lamp2 Port"));
	m_btnVisionLampPort2.SetBtnCursor(IDC_HAND_1);

	
	m_btnMarkingParam.SetFont( &m_fntBtn );
	m_btnMarkingParam.SetFlat( FALSE );
	m_btnMarkingParam.EnableBallonToolTip();
	m_btnMarkingParam.SetToolTipText( _T("Set Laser Marking Param") );
	m_btnMarkingParam.SetBtnCursor(IDC_HAND_1);

	m_btnPixelRevision.SetFont( &m_fntBtn );
	m_btnPixelRevision.SetFlat( FALSE );
	m_btnPixelRevision.EnableBallonToolTip();
	m_btnPixelRevision.SetToolTipText( _T("Pixel Revise") );
	m_btnPixelRevision.SetBtnCursor(IDC_HAND_1);

	m_btnMotorMove.SetFont( &m_fntBtn );
	m_btnMotorMove.SetFlat( FALSE );
	m_btnMotorMove.EnableBallonToolTip();
	m_btnMotorMove.SetToolTipText( _T("Motor Move Dialog") );
	m_btnMotorMove.SetBtnCursor(IDC_HAND_1);

	m_btnServoPort.SetFont( &m_fntBtn );
	m_btnServoPort.SetFlat( FALSE );
	m_btnServoPort.EnableBallonToolTip();
	m_btnServoPort.SetToolTipText( _T("Servo Motor Serial Port Dialog") );
	m_btnServoPort.SetBtnCursor(IDC_HAND_1);

	m_btnChillerPort.SetFont( &m_fntBtn );
	m_btnChillerPort.SetFlat( FALSE );
	m_btnChillerPort.EnableBallonToolTip();
	m_btnChillerPort.SetToolTipText( _T("Chiller Serial Port Dialog") );
	m_btnChillerPort.SetBtnCursor(IDC_HAND_1);
	if(!gSystemINI.m_sHardWare.bChillerConnect)
		m_btnChillerPort.ShowWindow(SW_HIDE);

	m_btnHumidity.SetFont( &m_fntBtn );
	m_btnHumidity.SetFlat( FALSE );
	m_btnHumidity.EnableBallonToolTip();
	m_btnHumidity.SetToolTipText( _T("Hhermo-hygrometer Serial Port Dialog") );
	m_btnHumidity.SetBtnCursor(IDC_HAND_1);
	if(!gSystemINI.m_sHardWare.bHumidityConnect)
		m_btnHumidity.ShowWindow(SW_HIDE);

#ifndef __SERVO_MOTOR__
	m_btnServoPort.ShowWindow(SW_HIDE);
#endif
	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 0)
	{
		m_btnPowermeterPort.ShowWindow(FALSE);
	}
	if (gSystemINI.m_sHardWare.nUseLampRS232 == 0)
	{
		m_btnVisionLampPort.ShowWindow(SW_HIDE);
		m_btnVisionLampPort2.ShowWindow(SW_HIDE);
	}
	else
	{
		m_btnVisionLampPort.ShowWindow(SW_SHOW);
#ifdef __OSAN_LG_2013__
		m_btnVisionLampPort2.ShowWindow(SW_SHOW);
#endif
	}
}

void CPaneSysSetupMotorPusan1::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150,_T("Arial Bold"));

	// Mechnical Setting
	m_edtHOffset1stHighX.SetFont( &m_fntEdit );
	m_edtHOffset1stHighX.SetForeColor( BLACK_COLOR );
	m_edtHOffset1stHighX.SetBackColor( WHITE_COLOR );
	m_edtHOffset1stHighX.SetReceivedFlag( 3 );
	m_edtHOffset1stHighX.SetWindowText( _T("0.0") );

	m_edtHOffset1stHighY.SetFont( &m_fntEdit );
	m_edtHOffset1stHighY.SetForeColor( BLACK_COLOR );
	m_edtHOffset1stHighY.SetBackColor( WHITE_COLOR );
	m_edtHOffset1stHighY.SetReceivedFlag( 3 );
	m_edtHOffset1stHighY.SetWindowText( _T("0.0") );

	m_edtHOffset1stLowX.SetFont( &m_fntEdit );
	m_edtHOffset1stLowX.SetForeColor( BLACK_COLOR );
	m_edtHOffset1stLowX.SetBackColor( WHITE_COLOR );
	m_edtHOffset1stLowX.SetReceivedFlag( 3 );
	m_edtHOffset1stLowX.SetWindowText( _T("0.0") );

	m_edtHOffset1stLowY.SetFont( &m_fntEdit );
	m_edtHOffset1stLowY.SetForeColor( BLACK_COLOR );
	m_edtHOffset1stLowY.SetBackColor( WHITE_COLOR );
	m_edtHOffset1stLowY.SetReceivedFlag( 3 );
	m_edtHOffset1stLowY.SetWindowText( _T("0.0") );

	m_edtHOffset2ndHighX.SetFont( &m_fntEdit );
	m_edtHOffset2ndHighX.SetForeColor( BLACK_COLOR );
	m_edtHOffset2ndHighX.SetBackColor( WHITE_COLOR );
	m_edtHOffset2ndHighX.SetReceivedFlag( 3 );
	m_edtHOffset2ndHighX.SetWindowText( _T("0.0") );

	m_edtHOffset2ndHighY.SetFont( &m_fntEdit );
	m_edtHOffset2ndHighY.SetForeColor( BLACK_COLOR );
	m_edtHOffset2ndHighY.SetBackColor( WHITE_COLOR );
	m_edtHOffset2ndHighY.SetReceivedFlag( 3 );
	m_edtHOffset2ndHighY.SetWindowText( _T("0.0") );

	m_edtHOffset2ndLowX.SetFont( &m_fntEdit );
	m_edtHOffset2ndLowX.SetForeColor( BLACK_COLOR );
	m_edtHOffset2ndLowX.SetBackColor( WHITE_COLOR );
	m_edtHOffset2ndLowX.SetReceivedFlag( 3 );
	m_edtHOffset2ndLowX.SetWindowText( _T("0.0") );

	m_edtHOffset2ndLowY.SetFont( &m_fntEdit );
	m_edtHOffset2ndLowY.SetForeColor( BLACK_COLOR );
	m_edtHOffset2ndLowY.SetBackColor( WHITE_COLOR );
	m_edtHOffset2ndLowY.SetReceivedFlag( 3 );
	m_edtHOffset2ndLowY.SetWindowText( _T("0.0") );

	m_edtHighVisionHeight.SetFont( &m_fntEdit );
	m_edtHighVisionHeight.SetForeColor( BLACK_COLOR );
	m_edtHighVisionHeight.SetBackColor( WHITE_COLOR );
	m_edtHighVisionHeight.SetReceivedFlag( 3 );
	m_edtHighVisionHeight.SetWindowText( _T("0.0") );

	m_edtLowVisionHeight.SetFont( &m_fntEdit );
	m_edtLowVisionHeight.SetForeColor( BLACK_COLOR );
	m_edtLowVisionHeight.SetBackColor( WHITE_COLOR );
	m_edtLowVisionHeight.SetReceivedFlag( 3 );
	m_edtLowVisionHeight.SetWindowText( _T("0.0") );

	m_edtScale.SetFont( &m_fntEdit );
	m_edtScale.SetForeColor( BLACK_COLOR );
	m_edtScale.SetBackColor( WHITE_COLOR );
	m_edtScale.SetReceivedFlag( 3 );
	m_edtScale.SetWindowText( _T("1000.0") );

	// Motor Setting
	m_edtMoveVelocity.SetFont( &m_fntEdit );
	m_edtMoveVelocity.SetForeColor( BLACK_COLOR );
	m_edtMoveVelocity.SetBackColor( WHITE_COLOR );
	m_edtMoveVelocity.SetReceivedFlag( 3 );
	m_edtMoveVelocity.SetWindowText( _T("0.0") );

	m_edtMoveAccel.SetFont( &m_fntEdit );
	m_edtMoveAccel.SetForeColor( BLACK_COLOR );
	m_edtMoveAccel.SetBackColor( WHITE_COLOR );
	m_edtMoveAccel.SetReceivedFlag( 3 );
	m_edtMoveAccel.SetWindowText( _T("0.0") );

	m_edtMoveSCurve.SetFont( &m_fntEdit );
	m_edtMoveSCurve.SetForeColor( BLACK_COLOR );
	m_edtMoveSCurve.SetBackColor( WHITE_COLOR );
	m_edtMoveSCurve.SetReceivedFlag( 3 );
	m_edtMoveSCurve.SetWindowText( _T("0.0") );

	m_edtMoveAccelPre.SetFont( &m_fntEdit );
	m_edtMoveAccelPre.SetForeColor( BLACK_COLOR );
	m_edtMoveAccelPre.SetBackColor( WHITE_COLOR );
	m_edtMoveAccelPre.SetReceivedFlag( 3 );
	m_edtMoveAccelPre.SetWindowText( _T("0.0") );
	
	m_edtMoveSCurvePre.SetFont( &m_fntEdit );
	m_edtMoveSCurvePre.SetForeColor( BLACK_COLOR );
	m_edtMoveSCurvePre.SetBackColor( WHITE_COLOR );
	m_edtMoveSCurvePre.SetReceivedFlag( 3 );
	m_edtMoveSCurvePre.SetWindowText( _T("0.0") );

	m_edtMoveAccelNext.SetFont( &m_fntEdit );
	m_edtMoveAccelNext.SetForeColor( BLACK_COLOR );
	m_edtMoveAccelNext.SetBackColor( WHITE_COLOR );
	m_edtMoveAccelNext.SetReceivedFlag( 3 );
	m_edtMoveAccelNext.SetWindowText( _T("0.0") );
	
	m_edtMoveSCurveNext.SetFont( &m_fntEdit );
	m_edtMoveSCurveNext.SetForeColor( BLACK_COLOR );
	m_edtMoveSCurveNext.SetBackColor( WHITE_COLOR );
	m_edtMoveSCurveNext.SetReceivedFlag( 3 );
	m_edtMoveSCurveNext.SetWindowText( _T("0.0") );

	m_edtSoftLimitPlus.SetFont( &m_fntEdit );
	m_edtSoftLimitPlus.SetForeColor( BLACK_COLOR );
	m_edtSoftLimitPlus.SetBackColor( WHITE_COLOR );
	m_edtSoftLimitPlus.SetReceivedFlag( 3 );
	m_edtSoftLimitPlus.SetWindowText( _T("0.0") );

	m_edtSoftLimitMinus.SetFont( &m_fntEdit );
	m_edtSoftLimitMinus.SetForeColor( BLACK_COLOR );
	m_edtSoftLimitMinus.SetBackColor( WHITE_COLOR );
	m_edtSoftLimitMinus.SetReceivedFlag( 3 );
	m_edtSoftLimitMinus.SetWindowText( _T("0.0") );

	// Height Sensor
	m_edt1stPanelID.SetFont( &m_fntEdit );
	m_edt1stPanelID.SetForeColor( BLACK_COLOR );
	m_edt1stPanelID.SetBackColor( WHITE_COLOR );
	m_edt1stPanelID.SetWindowText( _T("1'st Panel ID") );

	m_edt2ndPanelID.SetFont( &m_fntEdit );
	m_edt2ndPanelID.SetForeColor( BLACK_COLOR );
	m_edt2ndPanelID.SetBackColor( WHITE_COLOR );
	m_edt2ndPanelID.SetWindowText( _T("2'nd Panel ID") );

	if( 1 == gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
		m_edt2ndPanelID.EnableWindow(FALSE);
	else if(0 == gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum())
	{
		GetDlgItem(IDC_EDIT_1ST_PANEL_ID)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_2ND_PANEL_ID)->ShowWindow(SW_HIDE);
	}

	// Scanner Field Size
	m_edtScannerFieldX.SetFont( &m_fntEdit );
	m_edtScannerFieldX.SetReceivedFlag( 3 );
	m_edtScannerFieldX.SetWindowText( _T("50.0") );

	m_edtScannerFieldY.SetFont( &m_fntEdit );
	m_edtScannerFieldY.SetReceivedFlag( 3 );
	m_edtScannerFieldY.SetWindowText( _T("50.0") );


	// Vibration Setting
	m_edtVibrationCount.SetFont( &m_fntEdit );
	m_edtVibrationCount.SetReceivedFlag( 3 );
	m_edtVibrationCount.SetWindowText( _T("5") );

	m_edtVibrationLPCount.SetFont( &m_fntEdit );
	m_edtVibrationLPCount.SetReceivedFlag( 1 );
	m_edtVibrationLPCount.SetWindowText( _T("0") );
	

	m_edtWaterFlow1.SetFont( &m_fntEdit );
	m_edtWaterFlow1.SetForeColor( BLACK_COLOR );
	m_edtWaterFlow1.SetBackColor( WHITE_COLOR );
	m_edtWaterFlow1.SetWindowText( _T("0") );

	m_edtWaterFlow2.SetFont( &m_fntEdit );
	m_edtWaterFlow2.SetForeColor( BLACK_COLOR );
	m_edtWaterFlow2.SetBackColor( WHITE_COLOR );
	m_edtWaterFlow2.SetWindowText( _T("0") );

	m_edtWaterFlowOffset1.SetFont( &m_fntEdit );
	m_edtWaterFlowOffset1.SetForeColor( BLACK_COLOR );
	m_edtWaterFlowOffset1.SetBackColor( WHITE_COLOR );
	m_edtWaterFlowOffset1.SetWindowText( _T("0") );

	m_edtWaterFlowOffset2.SetFont( &m_fntEdit );
	m_edtWaterFlowOffset2.SetForeColor( BLACK_COLOR );
	m_edtWaterFlowOffset2.SetBackColor( WHITE_COLOR );
	m_edtWaterFlowOffset2.SetWindowText( _T("0") );

	m_edtMainAir.SetFont( &m_fntEdit );
	m_edtMainAir.SetForeColor( BLACK_COLOR );
	m_edtMainAir.SetBackColor( WHITE_COLOR );
	m_edtMainAir.SetWindowText( _T("0") );

	m_edtDustSuction.SetFont( &m_fntEdit );
	m_edtDustSuction.SetForeColor( BLACK_COLOR );
	m_edtDustSuction.SetBackColor( WHITE_COLOR );
	m_edtDustSuction.SetWindowText( _T("0") );

	m_edtTableVacuum1.SetFont( &m_fntEdit );
	m_edtTableVacuum1.SetForeColor( BLACK_COLOR );
	m_edtTableVacuum1.SetBackColor( WHITE_COLOR );
	m_edtTableVacuum1.SetWindowText( _T("0") );

	m_edtTableVacuum2.SetFont( &m_fntEdit );
	m_edtTableVacuum2.SetForeColor( BLACK_COLOR );
	m_edtTableVacuum2.SetBackColor( WHITE_COLOR );
	m_edtTableVacuum2.SetWindowText( _T("0") );

#ifndef __KUNSAN_SAMSUNG_LARGE__
	m_edtWaterFlow1.ShowWindow(SW_HIDE);
	m_edtWaterFlow2.ShowWindow(SW_HIDE);
	m_edtWaterFlowOffset1.ShowWindow(SW_HIDE);
	m_edtWaterFlowOffset2.ShowWindow(SW_HIDE);
	m_edtMainAir.ShowWindow(SW_HIDE);
	m_edtDustSuction.ShowWindow(SW_HIDE);
	m_edtTableVacuum1.ShowWindow(SW_HIDE);
	m_edtTableVacuum2.ShowWindow(SW_HIDE);

#endif


#ifndef __PUSAN1__
#ifndef __PUSAN2__
#ifndef __PUSAN_OLD_17__
#ifndef __KUNSAN_SAMSUNG_LARGE__
	m_edtVibrationCount.ShowWindow(SW_HIDE);
#endif
	m_edtVibrationLPCount.ShowWindow(SW_HIDE);
#endif
#endif
#endif

}

void CPaneSysSetupMotorPusan1::InitListBoxControl()
{
	// Set ListBox Font
	m_fntListBox.CreatePointFont(160,_T("Arial Bold"));

	m_lbAxis.SetFont( &m_fntListBox );

	// Set Axis Info
	int nMax = MOTOR_AXIS_MAX;
	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
		nMax = 5;

	for(int i = 0 ; i < nMax ; i++ )
		memcpy(m_pAxisInfo+i, &gSystemINI.m_sAxisInfo[i], sizeof(gSystemINI.m_sAxisInfo[i]));
	
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0)
		nMax = gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() + 1;

	for(int i = 0 ; i < nMax ; i++ )
	{
		/*if(gSystemINI.m_sHardWare.nLaserType == LASER_UV && (i == 4 || i == 5))
		{
			if(i == 4)
				m_lbAxis.AddString(_T("Attenuator1") );
			else
				m_lbAxis.AddString(_T("Attenuator2") );
		}
		else */if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G && (i == 3 || i == 4))
		{
			if(i == 4)
				m_lbAxis.AddString(_T("Attenuator1") );
			else
				m_lbAxis.AddString(_T("Theta") );
		}
		else
		{
			m_lbAxis.AddString( (m_pAxisInfo+i)->szName );
		}
	}
	m_nIndex = 0;
	m_lbAxis.SetCurSel( m_nIndex );
}

HBRUSH CPaneSysSetupMotorPusan1::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_AXIS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MECHANICAL_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MOTOR_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_DIST_PER_PIXEL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_SCANNER_FIELD_SIZE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_HEIGHT_SENSOR)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MOTOR_SETTING2)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_VIBRATION)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not zdesired
	return hbr;
}

void CPaneSysSetupMotorPusan1::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntListBox.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneSysSetupMotorPusan1::OnButtonPowermeterPort() 
{
	CDlgComSetup Dlg;
	Dlg.SetMode(MODE_POWER);
	Dlg.SetComPortData( &m_sSystemDevice.sPowermeterPort );

	if( IDOK == Dlg.DoModal() )
	{
		Dlg.GetComPortData( &m_sSystemDevice.sPowermeterPort );

		// ������ ����Ǿ��� �� ������ �翬�� �Ұ�
		if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pPowerMeasurement != NULL)
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pPowerMeasurement->DisconnectPort();
			
			::Sleep(1500);
			
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pPowerMeasurement->ConnectPort();
		}
	}
}
void CPaneSysSetupMotorPusan1::OnButtonMarkingParam()
{
	CDlgMarkingParam Dlg;
	Dlg.SetData(m_sSystemDevice.dJumpSpeed, m_sSystemDevice.nJumpDelay, m_sSystemDevice.nCornerDelay, m_sSystemDevice.nLineDelay, m_sSystemDevice.nPreMove, m_sSystemDevice.nJumpDelayShot);
	if(Dlg.DoModal() == IDOK)
		Dlg.GetData(m_sSystemDevice.dJumpSpeed, m_sSystemDevice.nJumpDelay, m_sSystemDevice.nCornerDelay, m_sSystemDevice.nLineDelay,  m_sSystemDevice.nPreMove, m_sSystemDevice.nJumpDelayShot);

}

void CPaneSysSetupMotorPusan1::SetSystemDevice(SSYSTEMDEVICE sSystemDevice)
{
	memcpy( &m_sSystemDevice, &sSystemDevice, sizeof(m_sSystemDevice) );

	// Set Axis Info
	int nMax = MOTOR_AXIS_MAX;

	for(int i = 0 ; i < nMax ; i++ )
		memcpy(m_pAxisInfo+i, &gSystemINI.m_sAxisInfo[i], sizeof(gSystemINI.m_sAxisInfo[i]));

	DispSystemDevice();
}

void CPaneSysSetupMotorPusan1::GetSystemDevice(SSYSTEMDEVICE* pSystemDevice)
{
	memcpy( pSystemDevice, &m_sSystemDevice, sizeof(m_sSystemDevice) );

	BOOL bChange = FALSE;
	int nMax = MOTOR_AXIS_MAX;

	SAXISINFO sAxisInfo;
	SAXISINFO* pAxisInfo;
	for(int i = 0 ; i < nMax ; i++ )
	{
		pAxisInfo = NULL;
		memset( &sAxisInfo, 0, sizeof(sAxisInfo) );

		pAxisInfo = (m_pAxisInfo + i);

		if( NULL == pAxisInfo )
			continue;

		memcpy(&sAxisInfo, &gSystemINI.m_sAxisInfo[i], sizeof(gSystemINI.m_sAxisInfo[i]));

		if( 0 == memcmp( pAxisInfo, &sAxisInfo, sizeof(sAxisInfo) ) )
			continue;

		memcpy( &sAxisInfo, pAxisInfo, sizeof(sAxisInfo) );
		memcpy(&gSystemINI.m_sAxisInfo[i], &sAxisInfo, sizeof(sAxisInfo));
		bChange = TRUE;
	}

	if( bChange )
	{// Download Axis Info to MP920
#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

		if( NULL != pMotor )
			pMotor->DownloadAxisInfo();
	}
}

void CPaneSysSetupMotorPusan1::DispSystemDevice()
{
	if (m_nUserLevel<3)//20190320
	{
		m_btnMarkingParam.ShowWindow(SW_HIDE);
	}
	else
	{
		m_btnMarkingParam.ShowWindow(SW_SHOW);
	}

	int nSize = MOTOR_AXIS_MAX;

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0)
		nSize = gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() + 1;

	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
		nSize = 5;

	m_lbAxis.ResetContent();

	for( int i = 0 ; i < nSize ; i++ )
	{
	/*	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV && (i == 4 || i == 5))
		{
			if(i == 4)
				m_lbAxis.AddString(_T("Attenuator1") );
			else
				m_lbAxis.AddString(_T("Attenuator2") );
		}
		else */if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G && (i == 3 || i == 4))
		{
			if(i == 4)
				m_lbAxis.AddString(_T("Attenuator1") );
			else
				m_lbAxis.AddString(_T("Theta") );
		}
		else
		{
			if(strcmp((m_pAxisInfo+i)->szName,(_T("Collimate"))) == 0)
				m_lbAxis.AddString(_T("BET1"));
			else if(strcmp((m_pAxisInfo+i)->szName,(_T("Collimate2"))) == 0)
				m_lbAxis.AddString(_T("BET2"));
			else
				m_lbAxis.AddString( (m_pAxisInfo+i)->szName );

		}
	}

	m_nIndex = 0;
	m_lbAxis.SetCurSel( m_nIndex );
	ShowAxisInfo( m_nIndex );
}

void CPaneSysSetupMotorPusan1::ShowAxisInfo(int nSel)
{
	CString strData;
	CString strAxisName;

	m_lbAxis.GetText( nSel, strAxisName );

	SAXISINFO *pAxisInfo = (m_pAxisInfo+nSel);
	
	if( NULL == pAxisInfo )
		return;

	GetDlgItem(IDC_STATIC_HOFFSET_X1)->SetWindowText("1st High Head Offset X");
	GetDlgItem(IDC_STATIC_HOFFSET_Y1)->SetWindowText("1st High Head Offset Y");
	GetDlgItem(IDC_STATIC_HOFFSET_X3)->SetWindowText("2nd High Head Offset X");
	GetDlgItem(IDC_STATIC_HOFFSET_Y3)->SetWindowText("2nd High Head Offset Y");

	m_edtMoveAccelPre.EnableWindow(FALSE);
	m_edtMoveSCurvePre.EnableWindow(FALSE);
	m_edtMoveAccelNext.EnableWindow(FALSE);
	m_edtMoveSCurveNext.EnableWindow(FALSE);

	strData.Format(_T("%.3f"), m_sSystemDevice.d1stHighHeadOffset.x);
	m_edtHOffset1stHighX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sSystemDevice.d1stLowHeadOffset.x);
	m_edtHOffset1stLowX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sSystemDevice.d2ndHighHeadOffset.x);
	m_edtHOffset2ndHighX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sSystemDevice.d2ndLowHeadOffset.x);
	m_edtHOffset2ndLowX.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sSystemDevice.d1stHighHeadOffset.y);
	m_edtHOffset1stHighY.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sSystemDevice.d1stLowHeadOffset.y);
	m_edtHOffset1stLowY.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sSystemDevice.d2ndHighHeadOffset.y);
	m_edtHOffset2ndHighY.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sSystemDevice.d2ndLowHeadOffset.y);
	m_edtHOffset2ndLowY.SetWindowText( (LPCTSTR)strData );


	if( 0 == strAxisName.CompareNoCase("X" ) )
	{
		if(m_nUserLevel > 1)
			m_edtHOffset1stHighX.EnableWindow( TRUE );
		else
			m_edtHOffset1stHighX.EnableWindow( FALSE );

//		m_edtHOffset1stHighY.SetWindowText(_T("NO USE") );
		m_edtHOffset1stHighY.EnableWindow( FALSE );

		if(m_nUserLevel > 1)
			m_edtHOffset1stLowX.EnableWindow( TRUE );
		else
			m_edtHOffset1stLowX.EnableWindow( FALSE );

//		m_edtHOffset1stLowY.SetWindowText(_T("NO USE") );
		m_edtHOffset1stLowY.EnableWindow( FALSE );
		
		if(m_nUserLevel > 1)
			m_edtHOffset2ndHighX.EnableWindow( TRUE );
		else
			m_edtHOffset2ndHighX.EnableWindow( FALSE );

//		m_edtHOffset2ndHighY.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndHighY.EnableWindow( FALSE );

		if(m_nUserLevel > 1)
			m_edtHOffset2ndLowX.EnableWindow( TRUE );
		else
			m_edtHOffset2ndLowX.EnableWindow( FALSE );

//		m_edtHOffset2ndLowY.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndLowY.EnableWindow( FALSE );

		m_edtHighVisionHeight.SetWindowText(_T("NO USE") );
		m_edtHighVisionHeight.EnableWindow( FALSE );

		m_edtLowVisionHeight.SetWindowText(_T("NO USE") );
		m_edtLowVisionHeight.EnableWindow( FALSE );

		// Table FeedRate
		strData.Format(_T("%.3f"), pAxisInfo->dTableFeedRate );
		m_edtMoveVelocity.SetWindowText( (LPCTSTR)strData );
		m_edtMoveVelocity.EnableWindow(TRUE);
		
		// Table Accelaration
		strData.Format(_T("%.3f"), pAxisInfo->dTableAcceleration );
		m_edtMoveAccel.SetWindowText( (LPCTSTR)strData );
		m_edtMoveAccel.EnableWindow(TRUE);
		
		// Table S Curve
		strData.Format(_T("%.3f"), pAxisInfo->dTableSCurve);
		m_edtMoveSCurve.SetWindowText( (LPCTSTR)strData );
		m_edtMoveSCurve.EnableWindow(TRUE);

		// Table Accelaration pre
		strData.Format(_T("%.3f"), pAxisInfo->dTableAccelerationPre );
		m_edtMoveAccelPre.SetWindowText( (LPCTSTR)strData );
		m_edtMoveAccelPre.EnableWindow(TRUE);
		// Table S Curve
		strData.Format(_T("%.3f"), pAxisInfo->dTableSCurvePre);
		m_edtMoveSCurvePre.SetWindowText( (LPCTSTR)strData );
		m_edtMoveSCurvePre.EnableWindow(TRUE);

		// Table Accelaration pre
		strData.Format(_T("%.3f"), pAxisInfo->dTableAccelerationNext );
		m_edtMoveAccelNext.SetWindowText( (LPCTSTR)strData );
		m_edtMoveAccelNext.EnableWindow(TRUE);
		// Table S Curve
		strData.Format(_T("%.3f"), pAxisInfo->dTableSCurveNext);
		m_edtMoveSCurveNext.SetWindowText( (LPCTSTR)strData );
		m_edtMoveSCurveNext.EnableWindow(TRUE);

#ifdef __PUSAN2__
		m_edtMoveAccelPre.EnableWindow(TRUE);
		m_edtMoveSCurvePre.EnableWindow(TRUE);
		m_edtMoveAccelNext.EnableWindow(TRUE);
		m_edtMoveSCurveNext.EnableWindow(TRUE);
#endif
	}
	else if( 0 == strAxisName.CompareNoCase(_T("Y")) )
	{
//		m_edtHOffset1stHighX.SetWindowText(_T("NO USE") );
		m_edtHOffset1stHighX.EnableWindow( FALSE );
		
		if(m_nUserLevel > 1)
			m_edtHOffset1stHighY.EnableWindow( TRUE );
		else
			m_edtHOffset1stHighY.EnableWindow( FALSE );
		
//		m_edtHOffset1stLowX.SetWindowText(_T("NO USE") );
		m_edtHOffset1stLowX.EnableWindow( FALSE );
		
		if(m_nUserLevel > 1)
			m_edtHOffset1stLowY.EnableWindow( TRUE );
		else
			m_edtHOffset1stLowY.EnableWindow( FALSE );
		
//		m_edtHOffset2ndHighX.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndHighX.EnableWindow( FALSE );
		
		if(m_nUserLevel > 1)
			m_edtHOffset2ndHighY.EnableWindow( TRUE );
		else
			m_edtHOffset2ndHighY.EnableWindow( FALSE );
		
//		m_edtHOffset2ndLowX.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndLowX.EnableWindow( FALSE );
		
		if(m_nUserLevel > 1)
			m_edtHOffset2ndLowY.EnableWindow( TRUE );
		else
			m_edtHOffset2ndLowY.EnableWindow( FALSE );

		m_edtHighVisionHeight.SetWindowText(_T("NO USE") );
		m_edtHighVisionHeight.EnableWindow( FALSE );
		
		m_edtLowVisionHeight.SetWindowText(_T("NO USE") );
		m_edtLowVisionHeight.EnableWindow( FALSE );

//		pAxisInfo = (m_pAxisInfo+0);
		// Table FeedRate
		strData.Format(_T("%.3f"), pAxisInfo->dTableFeedRate );
		m_edtMoveVelocity.SetWindowText( (LPCTSTR)strData );
#ifdef __KUNSAN_SAMSUNG_LARGE__
		m_edtMoveVelocity.EnableWindow(TRUE);
#else
		m_edtMoveVelocity.EnableWindow(FALSE);
#endif		
		// Table Accelaration
		strData.Format(_T("%.3f"), pAxisInfo->dTableAcceleration );
		m_edtMoveAccel.SetWindowText( (LPCTSTR)strData );
#ifdef __KUNSAN_SAMSUNG_LARGE__
		m_edtMoveAccel.EnableWindow(TRUE);
#else
		m_edtMoveAccel.EnableWindow(FALSE);
#endif	
		
		// Table S Curve
		strData.Format(_T("%.3f"), pAxisInfo->dTableSCurve);
		m_edtMoveSCurve.SetWindowText( (LPCTSTR)strData );
#ifdef __KUNSAN_SAMSUNG_LARGE__
		m_edtMoveSCurve.EnableWindow(TRUE);
#else
		m_edtMoveSCurve.EnableWindow(FALSE);
#endif	

		// Table Accelaration pre
		strData.Format(_T("%.3f"), pAxisInfo->dTableAccelerationPre );
		m_edtMoveAccelPre.SetWindowText( (LPCTSTR)strData );
#ifdef __KUNSAN_SAMSUNG_LARGE__
		m_edtMoveAccelPre.EnableWindow(TRUE);
#else
		m_edtMoveAccelPre.EnableWindow(FALSE);
#endif	
		// Table S Curve
		strData.Format(_T("%.3f"), pAxisInfo->dTableSCurvePre);
		m_edtMoveSCurvePre.SetWindowText( (LPCTSTR)strData );
#ifdef __KUNSAN_SAMSUNG_LARGE__
		m_edtMoveSCurvePre.EnableWindow(TRUE);
#else
		m_edtMoveSCurvePre.EnableWindow(FALSE);
#endif	
		
		// Table Accelaration pre
		strData.Format(_T("%.3f"), pAxisInfo->dTableAccelerationNext );
		m_edtMoveAccelNext.SetWindowText( (LPCTSTR)strData );
#ifdef __KUNSAN_SAMSUNG_LARGE__
		m_edtMoveAccelNext.EnableWindow(TRUE);
#else
		m_edtMoveAccelNext.EnableWindow(FALSE);
#endif	
		// Table S Curve
		strData.Format(_T("%.3f"), pAxisInfo->dTableSCurveNext);
		m_edtMoveSCurveNext.SetWindowText( (LPCTSTR)strData );
#ifdef __KUNSAN_SAMSUNG_LARGE__
		m_edtMoveSCurveNext.EnableWindow(TRUE);
#else
		m_edtMoveSCurveNext.EnableWindow(FALSE);
#endif	

#ifdef __PUSAN2__
		m_edtMoveVelocity.EnableWindow(TRUE);
		m_edtMoveAccel.EnableWindow(TRUE);
		m_edtMoveSCurve.EnableWindow(TRUE);

		m_edtMoveAccelPre.EnableWindow(TRUE);
		m_edtMoveSCurvePre.EnableWindow(TRUE);
		m_edtMoveAccelNext.EnableWindow(TRUE);
		m_edtMoveSCurveNext.EnableWindow(TRUE);
#endif

#ifdef __KUNSAN_1
		m_edtMoveVelocity.EnableWindow(TRUE);
		m_edtMoveAccel.EnableWindow(TRUE);
		m_edtMoveSCurve.EnableWindow(TRUE);
		
		m_edtMoveAccelPre.EnableWindow(TRUE);
		m_edtMoveSCurvePre.EnableWindow(TRUE);
		m_edtMoveAccelNext.EnableWindow(TRUE);
		m_edtMoveSCurveNext.EnableWindow(TRUE);
#endif

#ifdef __CUNGJU_JASMINE_OLD__
		m_edtMoveVelocity.EnableWindow(TRUE);
		m_edtMoveAccel.EnableWindow(TRUE);
		m_edtMoveSCurve.EnableWindow(TRUE);
		
		m_edtMoveAccelPre.EnableWindow(TRUE);
		m_edtMoveSCurvePre.EnableWindow(TRUE);
		m_edtMoveAccelNext.EnableWindow(TRUE);
		m_edtMoveSCurveNext.EnableWindow(TRUE);
#endif
	}
	else if( 0 == strAxisName.CompareNoCase(_T("Z1")) )
	{
//		m_edtHOffset1stHighX.SetWindowText(_T("NO USE") );
		m_edtHOffset1stHighX.EnableWindow( FALSE );

//		m_edtHOffset1stHighY.SetWindowText(_T("NO USE") );
		m_edtHOffset1stHighY.EnableWindow( FALSE );

//		m_edtHOffset1stLowX.SetWindowText(_T("NO USE") );
		m_edtHOffset1stLowX.EnableWindow( FALSE );

//		m_edtHOffset1stLowY.SetWindowText(_T("NO USE") );
		m_edtHOffset1stLowY.EnableWindow( FALSE );
		
//		m_edtHOffset2ndHighX.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndHighX.EnableWindow( FALSE );

//		m_edtHOffset2ndHighY.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndHighY.EnableWindow( FALSE );

//		m_edtHOffset2ndLowX.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndLowX.EnableWindow( FALSE );

//		m_edtHOffset2ndLowY.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndLowY.EnableWindow( FALSE );

//		strData.Format(_T("%.3f"), m_sSystemDevice.d1stLaserHeight );

		strData.Format(_T("%.3f"), m_sSystemDevice.d1stHighHeight );
		m_edtHighVisionHeight.SetWindowText( (LPCTSTR)strData );

		if(m_nUserLevel > 1)
			m_edtHighVisionHeight.EnableWindow( TRUE );
		else
			m_edtHighVisionHeight.EnableWindow( FALSE );

		strData.Format(_T("%.3f"), m_sSystemDevice.d1stLowHeight );
		m_edtLowVisionHeight.SetWindowText( (LPCTSTR)strData );

		if(m_nUserLevel > 1)
			m_edtLowVisionHeight.EnableWindow( TRUE );
		else
			m_edtLowVisionHeight.EnableWindow( FALSE );

		// Table FeedRate
		strData.Format(_T("%.3f"), pAxisInfo->dTableFeedRate );
		m_edtMoveVelocity.SetWindowText( (LPCTSTR)strData );
		m_edtMoveVelocity.EnableWindow(TRUE);
		
		// Table Accelaration
		strData.Format(_T("%.3f"), pAxisInfo->dTableAcceleration );
		m_edtMoveAccel.SetWindowText( (LPCTSTR)strData );
		m_edtMoveAccel.EnableWindow(TRUE);
		
		// Table S Curve
		strData.Format(_T("%.3f"), pAxisInfo->dTableSCurve);
		m_edtMoveSCurve.SetWindowText( (LPCTSTR)strData );
		m_edtMoveSCurve.EnableWindow(TRUE);
	}
	else if( 0 == strAxisName.CompareNoCase(_T("Z2")) )
	{
//		m_edtHOffset1stHighX.SetWindowText(_T("NO USE") );
		m_edtHOffset1stHighX.EnableWindow( FALSE );

//		m_edtHOffset1stHighY.SetWindowText(_T("NO USE") );
		m_edtHOffset1stHighY.EnableWindow( FALSE );

//		m_edtHOffset1stLowX.SetWindowText(_T("NO USE") );
		m_edtHOffset1stLowX.EnableWindow( FALSE );

//		m_edtHOffset1stLowY.SetWindowText(_T("NO USE") );
		m_edtHOffset1stLowY.EnableWindow( FALSE );
		
//		m_edtHOffset2ndHighX.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndHighX.EnableWindow( FALSE );

//		m_edtHOffset2ndHighY.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndHighY.EnableWindow( FALSE );

//		m_edtHOffset2ndLowX.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndLowX.EnableWindow( FALSE );

//		m_edtHOffset2ndLowY.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndLowY.EnableWindow( FALSE );

//		strData.Format(_T("%.3f"), m_sSystemDevice.d2ndLaserHeight );

		strData.Format(_T("%.3f"), m_sSystemDevice.d2ndHighHeight );
		m_edtHighVisionHeight.SetWindowText( (LPCTSTR)strData );

		if(m_nUserLevel > 1)
			m_edtHighVisionHeight.EnableWindow( TRUE );
		else
			m_edtHighVisionHeight.EnableWindow( FALSE );

		strData.Format(_T("%.3f"), m_sSystemDevice.d2ndLowHeight );
		m_edtLowVisionHeight.SetWindowText( (LPCTSTR)strData );

		if(m_nUserLevel > 1)
			m_edtLowVisionHeight.EnableWindow( TRUE );
		else
			m_edtLowVisionHeight.EnableWindow( FALSE );

		pAxisInfo = (m_pAxisInfo+2);
		// Table FeedRate
		strData.Format(_T("%.3f"), pAxisInfo->dTableFeedRate );
		m_edtMoveVelocity.SetWindowText( (LPCTSTR)strData );
		m_edtMoveVelocity.EnableWindow(FALSE);
		
		// Table Accelaration
		strData.Format(_T("%.3f"), pAxisInfo->dTableAcceleration );
		m_edtMoveAccel.SetWindowText( (LPCTSTR)strData );
		m_edtMoveAccel.EnableWindow(FALSE);
		
		// Table S Curve
		strData.Format(_T("%.3f"), pAxisInfo->dTableSCurve);
		m_edtMoveSCurve.SetWindowText( (LPCTSTR)strData );
		m_edtMoveSCurve.EnableWindow(FALSE);
	}
	else if(0 == strAxisName.CompareNoCase("Theta"))
	{
		GetDlgItem(IDC_STATIC_HOFFSET_X1)->SetWindowText("1st Center Pos. X");
		GetDlgItem(IDC_STATIC_HOFFSET_Y1)->SetWindowText("1st Center Pos. Y");
		GetDlgItem(IDC_STATIC_HOFFSET_X3)->SetWindowText("2nd Center Pos. X");
		GetDlgItem(IDC_STATIC_HOFFSET_Y3)->SetWindowText("2nd Center Pos. Y");
		m_edtHOffset1stHighX.EnableWindow( TRUE );
		m_edtHOffset1stHighY.EnableWindow( TRUE );
		m_edtHOffset1stLowX.EnableWindow( FALSE );
		m_edtHOffset1stLowY.EnableWindow( FALSE );

		strData.Format(_T("%.3f"), m_sSystemDevice.d1stThetaCenter.x);
		m_edtHOffset1stHighX.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sSystemDevice.d1stThetaCenter.y);
		m_edtHOffset1stHighY.SetWindowText( (LPCTSTR)strData );
		
		if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() != 0)
		{
			strData.Format(_T("%.3f"), m_sSystemDevice.d2ndThetaCenter.x);
			m_edtHOffset2ndHighX.SetWindowText( (LPCTSTR)strData );
			strData.Format(_T("%.3f"), m_sSystemDevice.d2ndThetaCenter.y);
			m_edtHOffset2ndHighY.SetWindowText( (LPCTSTR)strData );
			m_edtHOffset2ndHighX.EnableWindow( TRUE );
			m_edtHOffset2ndHighY.EnableWindow( TRUE );
		}
		else
		{
			m_edtHOffset2ndHighX.SetWindowText(_T("0") );
			m_edtHOffset2ndHighY.SetWindowText(_T("0") );
			m_edtHOffset2ndHighX.EnableWindow( FALSE );
			m_edtHOffset2ndHighY.EnableWindow( FALSE );
		}
		
		m_edtHOffset2ndLowX.EnableWindow( FALSE );
		m_edtHOffset2ndLowY.EnableWindow( FALSE );
		
		m_edtHighVisionHeight.SetWindowText(_T("NO USE") );
		m_edtHighVisionHeight.EnableWindow( FALSE );
		
		m_edtLowVisionHeight.SetWindowText(_T("NO USE") );
		m_edtLowVisionHeight.EnableWindow( FALSE );
		
		// Table FeedRate
		strData.Format(_T("%.3f"), pAxisInfo->dTableFeedRate );
		m_edtMoveVelocity.SetWindowText( (LPCTSTR)strData );
		m_edtMoveVelocity.EnableWindow(TRUE);
		
		// Table Accelaration
		strData.Format(_T("%.3f"), pAxisInfo->dTableAcceleration );
		m_edtMoveAccel.SetWindowText( (LPCTSTR)strData );
		m_edtMoveAccel.EnableWindow(TRUE);
		
		// Table S Curve
		strData.Format(_T("%.3f"), pAxisInfo->dTableSCurve);
		m_edtMoveSCurve.SetWindowText( (LPCTSTR)strData );
		m_edtMoveSCurve.EnableWindow(TRUE);
	}
	else if( 0 == strAxisName.CompareNoCase(_T("Mask")) || 0 == strAxisName.CompareNoCase(_T("Mask1")) || 0 == strAxisName.CompareNoCase("Mask2") || 0 == strAxisName.CompareNoCase(_T("Mask3")) || 
		0 == strAxisName.CompareNoCase(_T("Collimate")) ||
		0 == strAxisName.CompareNoCase(_T("L-Carrier")) || 0 == strAxisName.CompareNoCase(_T("U-Carrier")) ||
		0 == strAxisName.CompareNoCase(_T("Attenuator1")) || 0 == strAxisName.CompareNoCase(_T("Attenuator2")) ||
		0 == strAxisName.CollateNoCase(_T("BET1"))		||	0 == strAxisName.CompareNoCase(_T("BET2"))||
		0 == strAxisName.CollateNoCase(_T("A1"))		||	0 == strAxisName.CollateNoCase(_T("A2")))	//2011520
	{
//		m_edtHOffset1stHighX.SetWindowText(_T("NO USE") );
		m_edtHOffset1stHighX.EnableWindow( FALSE );

//		m_edtHOffset1stHighY.SetWindowText(_T("NO USE") );
		m_edtHOffset1stHighY.EnableWindow( FALSE );

//		m_edtHOffset1stLowX.SetWindowText(_T("NO USE") );
		m_edtHOffset1stLowX.EnableWindow( FALSE );

//		m_edtHOffset1stLowY.SetWindowText(_T("NO USE") );
		m_edtHOffset1stLowY.EnableWindow( FALSE );
		
//		m_edtHOffset2ndHighX.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndHighX.EnableWindow( FALSE );

//		m_edtHOffset2ndHighY.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndHighY.EnableWindow( FALSE );

//		m_edtHOffset2ndLowX.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndLowX.EnableWindow( FALSE );

//		m_edtHOffset2ndLowY.SetWindowText(_T("NO USE") );
		m_edtHOffset2ndLowY.EnableWindow( FALSE );

		m_edtHighVisionHeight.SetWindowText(_T("NO USE") );
		m_edtHighVisionHeight.EnableWindow( FALSE );

		m_edtLowVisionHeight.SetWindowText(_T("NO USE") );
		m_edtLowVisionHeight.EnableWindow( FALSE );

		// Table FeedRate
		strData.Format(_T("%.3f"), pAxisInfo->dTableFeedRate );
		m_edtMoveVelocity.SetWindowText( (LPCTSTR)strData );
		m_edtMoveVelocity.EnableWindow(TRUE);

		// Table Accelaration
		strData.Format(_T("%.3f"), pAxisInfo->dTableAcceleration );
		m_edtMoveAccel.SetWindowText( (LPCTSTR)strData );
		m_edtMoveAccel.EnableWindow(TRUE);
		
		// Table S Curve
		strData.Format(_T("%.3f"), pAxisInfo->dTableSCurve);
		m_edtMoveSCurve.SetWindowText( (LPCTSTR)strData );
		m_edtMoveSCurve.EnableWindow(TRUE);

		if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G &&
			0 == strAxisName.CompareNoCase("Attenuator1"))
		{
			m_edtMoveVelocity.EnableWindow(FALSE);
			m_edtMoveAccel.EnableWindow(FALSE);
			m_edtMoveSCurve.EnableWindow(FALSE);
		}
	}

	pAxisInfo = (m_pAxisInfo+nSel);

	// Soft Limit +
	strData.Format(_T("%.3f"), pAxisInfo->dLimitPlus );
	m_edtSoftLimitPlus.SetWindowText( (LPCTSTR)strData );

	// Soft Limit -
	strData.Format(_T("%.3f"), pAxisInfo->dLimitMinus);
	m_edtSoftLimitMinus.SetWindowText( (LPCTSTR)strData );

	// Scale
	strData.Format(_T("%.3f"), pAxisInfo->dScale);
	m_edtScale.SetWindowText( (LPCTSTR)strData );

	// 1st Height Sensor ID
	strData.Format(_T("%s"), m_sSystemDevice.sz1stHeightSensorID);
	m_edt1stPanelID.SetWindowText( (LPCTSTR)strData );

	// 2nd Height Sensor ID
	strData.Format(_T("%s"), m_sSystemDevice.sz2ndHeightSensorID);
	m_edt2ndPanelID.SetWindowText( (LPCTSTR)strData );

	// Scanner Field Size X, Y
	strData.Format(_T("%.2f"), m_sSystemDevice.dFieldSize.x);
	m_edtScannerFieldX.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemDevice.dFieldSize.y);
	m_edtScannerFieldY.SetWindowText( (LPCTSTR)strData );

	// Vibration Setting
	strData.Format(_T("%d"), m_sSystemDevice.nVibrationCount);
	m_edtVibrationCount.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%d"), m_sSystemDevice.nVibrationLPTime);
	m_edtVibrationLPCount.SetWindowText( (LPCTSTR)strData );


	strData.Format(_T("%.1f"), m_sSystemDevice.dWaterFlowSetting1);
	m_edtWaterFlow1.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemDevice.dWaterFlowSetting2);
	m_edtWaterFlow2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemDevice.dMainAirSetting);
	m_edtMainAir.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemDevice.dDustSuctionSetting);
	m_edtDustSuction.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemDevice.dTableVacuumSetting1);
	m_edtTableVacuum1.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemDevice.dTableVacuumSetting2);
	m_edtTableVacuum2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemDevice.dWaterFlowOffsetSetting1);
	m_edtWaterFlowOffset1.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.1f"), m_sSystemDevice.dWaterFlowOffsetSetting2);
	m_edtWaterFlowOffset2.SetWindowText( (LPCTSTR)strData );

	int nLevel = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetUserLevel();
	if(nLevel < 1)
		EnableControl(FALSE);

	switch(gEasyDrillerINI.m_clsHwOption.GetCameraNum())
	{
	case 1:
		m_edtHOffset1stLowX.EnableWindow(FALSE);
		m_edtHOffset1stLowY.EnableWindow(FALSE);
		m_edtHOffset2ndHighX.EnableWindow(FALSE);
		m_edtHOffset2ndHighY.EnableWindow(FALSE);
		m_edtHOffset2ndLowX.EnableWindow(FALSE);
		m_edtHOffset2ndLowY.EnableWindow(FALSE);
		m_edtLowVisionHeight.EnableWindow(FALSE);
		break;
	case 2:
		m_edtHOffset2ndHighX.EnableWindow(FALSE);
		m_edtHOffset2ndHighY.EnableWindow(FALSE);
		m_edtHOffset2ndLowX.EnableWindow(FALSE);
		m_edtHOffset2ndLowY.EnableWindow(FALSE);
		break;
	}	

	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		m_edtMoveSCurve.EnableWindow(FALSE);;
	}
}

void CPaneSysSetupMotorPusan1::OnApply()
{
	UpdateAxis();
	
	CString strData;

	// 1st Height Sensor ID
	m_edt1stPanelID.GetWindowText( strData );
	_stprintf_s( m_sSystemDevice.sz1stHeightSensorID,_T("%s"), strData );

	// 2nd Height Sensor ID
	m_edt2ndPanelID.GetWindowText( strData );
	_stprintf_s( m_sSystemDevice.sz2ndHeightSensorID,_T("%s"), strData );

	// Scanner Field Size X, Y
	m_edtScannerFieldX.GetWindowText( strData );
	m_sSystemDevice.dFieldSize.x = atof( (LPSTR)(LPCTSTR)strData );

//	m_edtScannerFieldY.GetWindowText( strData );
	m_sSystemDevice.dFieldSize.y = m_sSystemDevice.dFieldSize.x;

	// Vibration Setting
	m_edtVibrationCount.GetWindowText( strData );
	m_sSystemDevice.nVibrationCount = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtVibrationLPCount.GetWindowText( strData );
	m_sSystemDevice.nVibrationLPTime = atoi( (LPSTR)(LPCTSTR)strData );
	
	m_edtWaterFlow1.GetWindowText( strData );
	m_sSystemDevice.dWaterFlowSetting1 = atof( (LPSTR)(LPCTSTR)strData );

	m_edtWaterFlow2.GetWindowText( strData );
	m_sSystemDevice.dWaterFlowSetting2 = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMainAir.GetWindowText( strData );
	m_sSystemDevice.dMainAirSetting = atof( (LPSTR)(LPCTSTR)strData );

	m_edtDustSuction.GetWindowText( strData );
	m_sSystemDevice.dDustSuctionSetting = atof( (LPSTR)(LPCTSTR)strData );

	m_edtTableVacuum1.GetWindowText( strData );
	m_sSystemDevice.dTableVacuumSetting1 = atof( (LPSTR)(LPCTSTR)strData );

	m_edtTableVacuum2.GetWindowText( strData );
	m_sSystemDevice.dTableVacuumSetting2 = atof( (LPSTR)(LPCTSTR)strData );

	m_edtWaterFlowOffset1.GetWindowText( strData );
	m_sSystemDevice.dWaterFlowOffsetSetting1 = atof( (LPSTR)(LPCTSTR)strData );

	m_edtWaterFlowOffset2.GetWindowText( strData );
	m_sSystemDevice.dWaterFlowOffsetSetting2 = atof( (LPSTR)(LPCTSTR)strData );

}

void CPaneSysSetupMotorPusan1::OnSelchangeListAxis() 
{
	UpdateAxis();

	int nSel = m_lbAxis.GetCurSel();
	m_nIndex = nSel;

	ShowAxisInfo( m_nIndex );
}

void CPaneSysSetupMotorPusan1::UpdateAxis()
{
	CString strData;
	CString strAxisName;

	m_lbAxis.GetText( m_nIndex, strAxisName );

	if( 0 == strAxisName.CompareNoCase("X" ) )
	{
		m_edtHOffset1stHighX.GetWindowText( strData );
		m_sSystemDevice.d1stHighHeadOffset.x = atof( (LPSTR)(LPCTSTR)strData );

		m_edtHOffset1stLowX.GetWindowText( strData );
		m_sSystemDevice.d1stLowHeadOffset.x = atof( (LPSTR)(LPCTSTR)strData );

		m_edtHOffset2ndHighX.GetWindowText( strData );
		m_sSystemDevice.d2ndHighHeadOffset.x = atof( (LPSTR)(LPCTSTR)strData );

		m_edtHOffset2ndLowX.GetWindowText( strData );
		m_sSystemDevice.d2ndLowHeadOffset.x = atof( (LPSTR)(LPCTSTR)strData );
	}
	else if( 0 == strAxisName.CompareNoCase("Y") )
	{
		m_edtHOffset1stHighY.GetWindowText( strData );
		m_sSystemDevice.d1stHighHeadOffset.y = atof( (LPSTR)(LPCTSTR)strData );
		
		m_edtHOffset1stLowY.GetWindowText( strData );
		m_sSystemDevice.d1stLowHeadOffset.y = atof( (LPSTR)(LPCTSTR)strData );
		
		m_edtHOffset2ndHighY.GetWindowText( strData );
		m_sSystemDevice.d2ndHighHeadOffset.y = atof( (LPSTR)(LPCTSTR)strData );
		
		m_edtHOffset2ndLowY.GetWindowText( strData );
		m_sSystemDevice.d2ndLowHeadOffset.y = atof( (LPSTR)(LPCTSTR)strData );
	}
	else if( 0 == strAxisName.CompareNoCase("Z1") )
	{
		m_edtHighVisionHeight.GetWindowText( strData );
		m_sSystemDevice.d1stHighHeight = atof( (LPSTR)(LPCTSTR)strData );

		m_edtLowVisionHeight.GetWindowText( strData );
		m_sSystemDevice.d1stLowHeight = atof( (LPSTR)(LPCTSTR)strData );
	}
	else if( 0 == strAxisName.CompareNoCase("Z2") )
	{
		m_edtHighVisionHeight.GetWindowText( strData );
		m_sSystemDevice.d2ndHighHeight = atof( (LPSTR)(LPCTSTR)strData );

		m_edtLowVisionHeight.GetWindowText( strData );
		m_sSystemDevice.d2ndLowHeight = atof( (LPSTR)(LPCTSTR)strData );
	}
	else if( 0 == strAxisName.CompareNoCase("Theta") )
	{
		m_edtHOffset1stHighX.GetWindowText( strData );
		m_sSystemDevice.d1stThetaCenter.x = atof( (LPSTR)(LPCTSTR)strData );
		m_edtHOffset1stHighY.GetWindowText( strData );
		m_sSystemDevice.d1stThetaCenter.y = atof( (LPSTR)(LPCTSTR)strData );
		
		m_edtHOffset2ndHighX.GetWindowText( strData );
		m_sSystemDevice.d2ndThetaCenter.x = atof( (LPSTR)(LPCTSTR)strData );
		m_edtHOffset2ndHighY.GetWindowText( strData );
		m_sSystemDevice.d2ndThetaCenter.y = atof( (LPSTR)(LPCTSTR)strData );
	}

	SAXISINFO *pAxisInfo = (m_pAxisInfo+m_nIndex);

	if( NULL == pAxisInfo )
		return; 

	// Table FeedRate
	m_edtMoveVelocity.GetWindowText( strData );
	pAxisInfo->dTableFeedRate = atof( (LPSTR)(LPCTSTR)strData );
	
	// Table Accelaration
	m_edtMoveAccel.GetWindowText( strData );
	pAxisInfo->dTableAcceleration = atof( (LPSTR)(LPCTSTR)strData );

	// Table S Curve
	m_edtMoveSCurve.GetWindowText( strData );
	pAxisInfo->dTableSCurve = atof( (LPSTR)(LPCTSTR)strData );

	// Table Accelaration
	m_edtMoveAccelPre.GetWindowText( strData );
	pAxisInfo->dTableAccelerationPre = atof( (LPSTR)(LPCTSTR)strData );
	// Table S Curve
	m_edtMoveSCurvePre.GetWindowText( strData );
	pAxisInfo->dTableSCurvePre = atof( (LPSTR)(LPCTSTR)strData );

	// Table Accelaration
	m_edtMoveAccelNext.GetWindowText( strData );
	pAxisInfo->dTableAccelerationNext = atof( (LPSTR)(LPCTSTR)strData );
	// Table S Curve
	m_edtMoveSCurveNext.GetWindowText( strData );
	pAxisInfo->dTableSCurveNext = atof( (LPSTR)(LPCTSTR)strData );

	// Soft Limit +
	m_edtSoftLimitPlus.GetWindowText( strData );
	pAxisInfo->dLimitPlus = atof( (LPSTR)(LPCTSTR)strData );

	// Soft Limit -
	m_edtSoftLimitMinus.GetWindowText( strData );
	pAxisInfo->dLimitMinus = atof( (LPSTR)(LPCTSTR)strData );

	// Scale
	m_edtScale.GetWindowText( strData );
	pAxisInfo->dScale = atof( (LPSTR)(LPCTSTR)strData );
}

void CPaneSysSetupMotorPusan1::OnCamChange(int nCamNo)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnCamChange( nCamNo );
}

BOOL CPaneSysSetupMotorPusan1::MoveTable(double dPosX, double dPosY)
{
	if (!gDeviceFactory.GetMotor()->MoveXY(dPosX, dPosY))
	{
		TRACE("MOVE ERROR\r\n");
		return FALSE;
	}
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
		{
			TRACE("MOVE ERROR\r\n");
			return FALSE;
		}
	}
	return TRUE;
}


void CPaneSysSetupMotorPusan1::RefreshHeadOffset(int nCam, DPOINT dPoint)
{
	CString strData;
	switch(nCam)
	{
	case HIGH_1ST_CAM:
		m_sSystemDevice.d1stHighHeadOffset = dPoint;
		strData.Format(_T("%.3f"), m_sSystemDevice.d1stHighHeadOffset.x);
		m_edtHOffset1stHighX.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sSystemDevice.d1stHighHeadOffset.y);
		m_edtHOffset1stHighY.SetWindowText( (LPCTSTR)strData );
		break;
		
	case LOW_1ST_CAM:
		m_sSystemDevice.d1stLowHeadOffset = dPoint;
		strData.Format(_T("%.3f"), m_sSystemDevice.d1stLowHeadOffset.x);
		m_edtHOffset1stLowX.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sSystemDevice.d1stLowHeadOffset.y);
		m_edtHOffset1stLowY.SetWindowText( (LPCTSTR)strData );
		break;
		
	case HIGH_2ND_CAM:
		m_sSystemDevice.d2ndHighHeadOffset = dPoint;
		strData.Format(_T("%.3f"), m_sSystemDevice.d2ndHighHeadOffset.x);
		m_edtHOffset2ndHighX.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sSystemDevice.d2ndHighHeadOffset.y);
		m_edtHOffset2ndHighY.SetWindowText( (LPCTSTR)strData );
		break;
		
	case LOW_2ND_CAM:
		m_sSystemDevice.d2ndLowHeadOffset = dPoint;
		strData.Format(_T("%.3f"), m_sSystemDevice.d2ndLowHeadOffset.x);
		m_edtHOffset2ndLowX.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sSystemDevice.d2ndLowHeadOffset.y);
		m_edtHOffset2ndLowY.SetWindowText( (LPCTSTR)strData );
		break;
	}
}

CString CPaneSysSetupMotorPusan1::GetChangeValueStr()
{
	CString strMessage, strTemp, strId1, strId2;
	strMessage.Format(_T(""));
	BOOL bChangeCamOffset[4] = {0,};

	if(m_sSystemDevice.d1stHighHeadOffset.x != gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x ||
		m_sSystemDevice.d1stHighHeadOffset.y != gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y)
	{
		strTemp.Format(_T("| 1st H.H.Offset : ( %.3f, %.3f)mm "), 
			m_sSystemDevice.d1stHighHeadOffset.x,
			m_sSystemDevice.d1stHighHeadOffset.y);
		strMessage += strTemp;
		bChangeCamOffset[0] = TRUE; 
	}

	if(m_sSystemDevice.d2ndHighHeadOffset.x != gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x ||
		m_sSystemDevice.d2ndHighHeadOffset.y != gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y)
	{
		strTemp.Format(_T("| 2nd H.H.Offset : ( %.3f, %.3f)mm "), 
			m_sSystemDevice.d2ndHighHeadOffset.x,
			m_sSystemDevice.d2ndHighHeadOffset.y);
		strMessage += strTemp;
		bChangeCamOffset[2] = TRUE; 
	}

	if(m_sSystemDevice.d1stLowHeadOffset.x != gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x ||
		m_sSystemDevice.d1stLowHeadOffset.y != gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y)
	{
		strTemp.Format(_T("| 1st L.H.Offset : ( %.3f, %.3f)mm "), 
			m_sSystemDevice.d1stLowHeadOffset.x,
			m_sSystemDevice.d1stLowHeadOffset.y);
		strMessage += strTemp;
		bChangeCamOffset[1] = TRUE; 
	}

	if(m_sSystemDevice.d2ndLowHeadOffset.x != gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x ||
		m_sSystemDevice.d2ndLowHeadOffset.y != gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y)
	{
		strTemp.Format(_T("| 2nd L.H.Offset : ( %.3f, %.3f)mm "), 
			m_sSystemDevice.d2ndLowHeadOffset.x,
			m_sSystemDevice.d2ndLowHeadOffset.y);
		strMessage += strTemp;
		bChangeCamOffset[3] = TRUE; 
	}

	if(m_sSystemDevice.d1stHighHeight != gSystemINI.m_sSystemDevice.d1stHighHeight ||
		m_sSystemDevice.d1stLowHeight != gSystemINI.m_sSystemDevice.d1stLowHeight)
	{
		strTemp.Format(_T("| 1st Z Height : (H : %.3f, L : %.3f)mm "), 
			m_sSystemDevice.d1stHighHeight,
			m_sSystemDevice.d1stLowHeight);
		strMessage += strTemp;
		if(m_sSystemDevice.d1stHighHeight != gSystemINI.m_sSystemDevice.d1stHighHeight)
			bChangeCamOffset[0] = TRUE;
		else
			bChangeCamOffset[1] = TRUE;
	}

	if(m_sSystemDevice.d2ndHighHeight != gSystemINI.m_sSystemDevice.d2ndHighHeight ||
		m_sSystemDevice.d2ndLowHeight != gSystemINI.m_sSystemDevice.d2ndLowHeight)
	{
		strTemp.Format(_T("| 2nd Z Height : (H : %.3f, L : %.3f)mm "), 
			m_sSystemDevice.d2ndHighHeight,
			m_sSystemDevice.d2ndLowHeight);
		strMessage += strTemp;

		if(m_sSystemDevice.d2ndHighHeight != gSystemINI.m_sSystemDevice.d2ndHighHeight)
			bChangeCamOffset[2] = TRUE;
		else
			bChangeCamOffset[3] = TRUE;

	}

	if(m_sSystemDevice.d1stThetaCenter.x != gSystemINI.m_sSystemDevice.d1stThetaCenter.x ||
		m_sSystemDevice.d1stThetaCenter.y != gSystemINI.m_sSystemDevice.d1stThetaCenter.y)
	{
		strTemp.Format(_T("| 1st Theta Center : (%.3f,%.3f)mm "), 
			m_sSystemDevice.d1stThetaCenter.x,
			m_sSystemDevice.d1stThetaCenter.y);
		strMessage += strTemp;
	}

	if(m_sSystemDevice.d2ndThetaCenter.x != gSystemINI.m_sSystemDevice.d2ndThetaCenter.x ||
		m_sSystemDevice.d2ndThetaCenter.y != gSystemINI.m_sSystemDevice.d2ndThetaCenter.y)
	{
		strTemp.Format(_T("| 1st Theta Center : (%.3f,%.3f)mm "), 
			m_sSystemDevice.d2ndThetaCenter.x,
			m_sSystemDevice.d2ndThetaCenter.y);
		strMessage += strTemp;
	}

	for(int i = 0 ; i < MOTOR_AXIS_MAX ; i++ )
	{
		SAXISINFO *pAxisInfo = (m_pAxisInfo+i);
		
		if( NULL == pAxisInfo )
			return strMessage;
		
		if(pAxisInfo->dTableFeedRate != gSystemINI.m_sAxisInfo[i].dTableFeedRate ||
			pAxisInfo->dTableAcceleration != gSystemINI.m_sAxisInfo[i].dTableAcceleration ||
			pAxisInfo->dTableSCurve != gSystemINI.m_sAxisInfo[i].dTableSCurve ||
			pAxisInfo->dTableAccelerationPre != gSystemINI.m_sAxisInfo[i].dTableAccelerationPre ||
			pAxisInfo->dTableSCurvePre != gSystemINI.m_sAxisInfo[i].dTableSCurvePre ||
			pAxisInfo->dTableAccelerationNext != gSystemINI.m_sAxisInfo[i].dTableAccelerationNext ||
			pAxisInfo->dTableSCurveNext != gSystemINI.m_sAxisInfo[i].dTableSCurveNext ||
			pAxisInfo->dLimitPlus != gSystemINI.m_sAxisInfo[i].dLimitPlus ||
			pAxisInfo->dLimitMinus != gSystemINI.m_sAxisInfo[i].dLimitMinus ||
			pAxisInfo->dScale != gSystemINI.m_sAxisInfo[i].dScale)
		{
			strTemp.Format(_T("| %d-axis : (%.3f, %.3f, %.3f, %.3f, %.3f, %.3f, %.3f, %.3f, %.3f, %.3f) "), 
				i,
				pAxisInfo->dTableFeedRate,
				pAxisInfo->dTableAccelerationPre,
				pAxisInfo->dTableSCurvePre,
				pAxisInfo->dTableAccelerationNext,
				pAxisInfo->dTableSCurveNext,
				pAxisInfo->dTableAcceleration,
				pAxisInfo->dTableSCurve,
				pAxisInfo->dLimitMinus,
				pAxisInfo->dLimitPlus,
				pAxisInfo->dScale);
				strMessage += strTemp;
		}
	}
	
	for(int i = 0; i< MOTOR_MASK_MAX; i++)
	{
		if(m_sSystemDevice.d1stLaserHeight[i] != gSystemINI.m_sSystemDevice.d1stLaserHeight[i] ||
			m_sSystemDevice.d2ndLaserHeight[i] != gSystemINI.m_sSystemDevice.d2ndLaserHeight[i])
		{
			strTemp.Format(_T("| %d Mask Z-Height : 1st: %.3f, 2nd: %.3fmm "), 
				i,
				m_sSystemDevice.d1stLaserHeight[i],
				m_sSystemDevice.d2ndLaserHeight[i]);
			strMessage += strTemp;
		}
	}

	for(int i = 0; i< MOTOR_MASK_MAX; i++)
	{
		if(m_sSystemDevice.d1stLaserHeightTophat[i] != gSystemINI.m_sSystemDevice.d1stLaserHeightTophat[i] ||
			m_sSystemDevice.d2ndLaserHeightTophat[i] != gSystemINI.m_sSystemDevice.d2ndLaserHeightTophat[i])
		{
			strTemp.Format(_T("| %d Mask Z-Height TOP : 1st: %.3f, 2nd: %.3fmm "), 
				i,
				m_sSystemDevice.d1stLaserHeightTophat[i],
				m_sSystemDevice.d2ndLaserHeightTophat[i]);
			strMessage += strTemp;
		}
	}

	if(m_sSystemDevice.d1stHighPixel.x != gSystemINI.m_sSystemDevice.d1stHighPixel.x ||
		m_sSystemDevice.d1stHighPixel.y != gSystemINI.m_sSystemDevice.d1stHighPixel.y)
	{
		strTemp.Format(_T("| 1st H. Pixel : ( %.6f, %.6f)mm "), 
			m_sSystemDevice.d1stHighPixel.x,
			m_sSystemDevice.d1stHighPixel.y);
		strMessage += strTemp;
	}

	if(m_sSystemDevice.d1stLowPixel.x != gSystemINI.m_sSystemDevice.d1stLowPixel.x ||
		m_sSystemDevice.d1stLowPixel.y != gSystemINI.m_sSystemDevice.d1stLowPixel.y)
	{
		strTemp.Format(_T("| 1st L. Pixel : ( %.6f, %.6f)mm "), 
			m_sSystemDevice.d1stLowPixel.x,
			m_sSystemDevice.d1stLowPixel.y);
		strMessage += strTemp;
	}

	if(m_sSystemDevice.d2ndHighPixel.x != gSystemINI.m_sSystemDevice.d2ndHighPixel.x ||
		m_sSystemDevice.d2ndHighPixel.y != gSystemINI.m_sSystemDevice.d2ndHighPixel.y)
	{
		strTemp.Format(_T("| 2nd H. Pixel : ( %.6f, %.6f)mm "), 
			m_sSystemDevice.d2ndHighPixel.x,
			m_sSystemDevice.d2ndHighPixel.y);
		strMessage += strTemp;
	}
	
	if(m_sSystemDevice.d2ndLowPixel.x != gSystemINI.m_sSystemDevice.d2ndLowPixel.x ||
		m_sSystemDevice.d2ndLowPixel.y != gSystemINI.m_sSystemDevice.d2ndLowPixel.y)
	{
		strTemp.Format(_T("| 2nd L. Pixel : ( %.6f, %.6f)mm "), 
			m_sSystemDevice.d2ndLowPixel.x,
			m_sSystemDevice.d2ndLowPixel.y);
		strMessage += strTemp;
	}

	strId1.Format(_T("%s"), m_sSystemDevice.sz1stHeightSensorID);
	strId2.Format(_T("%s"), gSystemINI.m_sSystemDevice.sz1stHeightSensorID);
	BOOL bChangeHeight = FALSE;
	if(0 != strId1.CompareNoCase(strId2))
	{
		strTemp.Format(_T("| H.S. ID1 : %s "), strId1);
		gDeviceFactory.GetHeightSensor()->SetSensorID(0, gSystemINI.m_sSystemDevice.sz1stHeightSensorID);
		strMessage += strTemp;
		bChangeHeight = TRUE;
	}

	strId1.Format(_T("%s"), m_sSystemDevice.sz2ndHeightSensorID);
	strId2.Format(_T("%s"), gSystemINI.m_sSystemDevice.sz2ndHeightSensorID);
	
	if(0 != strId1.CompareNoCase(strId2))
	{
		strTemp.Format(_T("| H.S. ID2 : %s "), strId1);
		gDeviceFactory.GetHeightSensor()->SetSensorID(0, gSystemINI.m_sSystemDevice.sz2ndHeightSensorID);
		strMessage += strTemp;
		bChangeHeight = TRUE;
	}
	if(bChangeHeight)
		gDeviceFactory.GetHeightSensor()->InitHeightSensor();

	if(m_sSystemDevice.dFieldSize.x != gSystemINI.m_sSystemDevice.dFieldSize.x ||
		m_sSystemDevice.dFieldSize.y != gSystemINI.m_sSystemDevice.dFieldSize.y)
	{
		strTemp.Format(_T("| S.F.Size : ( %.3f, %.3f)mm "), 
			m_sSystemDevice.dFieldSize.x,
			m_sSystemDevice.dFieldSize.y);
		strMessage += strTemp;
		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, DO_SCANNER);
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (FieldSize) : S"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
//		ErrMessage(_T("Please re-make Scanner Inposition Table."));
	}

	if(m_sSystemDevice.nVibrationCount != gSystemINI.m_sSystemDevice.nVibrationCount)
	{
		strTemp.Format(_T("| VIB COUNT : %d "), m_sSystemDevice.nVibrationCount);
		strMessage += strTemp;
	}

	if(m_sSystemDevice.dVibrationDelay != gSystemINI.m_sSystemDevice.dVibrationDelay)
	{
		strTemp.Format(_T("| VIB DELAY : %.1f "), m_sSystemDevice.dVibrationDelay);
		strMessage += strTemp;
	}
	
	if(m_sSystemDevice.nVibrationLPTime != gSystemINI.m_sSystemDevice.nVibrationLPTime)
	{
		strTemp.Format(_T("| VIB LP TIME : %d "), m_sSystemDevice.nVibrationLPTime);
		strMessage += strTemp;
	}

	for(int e = 0; e< 4; e++)
	{
		if(bChangeCamOffset[e])
		{
			SaveChangeCamOffset(bChangeCamOffset);
			break;
		}
	}
	return strMessage;
}

void CPaneSysSetupMotorPusan1::EnableControl(BOOL bUse)
{
	m_edtHOffset1stHighX.EnableWindow(bUse);
	m_edtHOffset1stHighY.EnableWindow(bUse);
	m_edtHOffset1stLowX.EnableWindow(bUse);
	m_edtHOffset1stLowY.EnableWindow(bUse);
	m_edtHOffset2ndHighX.EnableWindow(bUse);
	m_edtHOffset2ndHighY.EnableWindow(bUse);
	m_edtHOffset2ndLowX.EnableWindow(bUse);
	m_edtHOffset2ndLowY.EnableWindow(bUse);

	m_edtHighVisionHeight.EnableWindow(bUse);
	m_edtLowVisionHeight.EnableWindow(bUse);
	m_edtScale.EnableWindow(bUse);
	m_edtMoveVelocity.EnableWindow(bUse);
	m_edtMoveAccel.EnableWindow(bUse);
	m_edtMoveSCurve.EnableWindow(bUse);

	m_edtMoveAccelPre.EnableWindow(bUse);
	m_edtMoveSCurvePre.EnableWindow(bUse);
	m_edtMoveAccelNext.EnableWindow(bUse);
	m_edtMoveSCurveNext.EnableWindow(bUse);

//	m_edtSoftLimitPlus.EnableWindow(bUse);
//	m_edtSoftLimitMinus.EnableWindow(bUse);
	if( 0 < gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
		m_edt1stPanelID.EnableWindow(bUse);

	if( 2 == gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
		m_edt2ndPanelID.EnableWindow(bUse);

	m_edtScannerFieldX.EnableWindow(bUse);
	m_edtScannerFieldY.EnableWindow(bUse);

	m_btnPowermeterPort.EnableWindow(bUse);

	m_edtVibrationCount.EnableWindow(bUse);
	m_edtVibrationLPCount.EnableWindow(bUse);
}

void CPaneSysSetupMotorPusan1::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;

	switch(nLevel)
	{
	case 0:
	case 1:
		EnableControl(FALSE);
		break;
	case 2:
	case 3:
		EnableControl(TRUE);
		OnSelchangeListAxis();
		break;
	}	
}

void CPaneSysSetupMotorPusan1::OnButtonCamSet() 
{
	// TODO: Add your control notification handler code here
	CDlgVisionPixelSet dlg;
	dlg.SetData(&m_sSystemDevice.dVisionPixcel1[0][0], &m_sSystemDevice.dVisionPixcel2[0][0]);
	if(dlg.DoModal() == IDOK)
	{
		dlg.GetData(&m_sSystemDevice.dVisionPixcel1[0][0], &m_sSystemDevice.dVisionPixcel2[0][0]);
	}
}
void CPaneSysSetupMotorPusan1::OnButtonMove()
{
	CDlgMotorMove dlg;
	dlg.SetDisplayOn(TRUE);
	dlg.DoModal();
}
void CPaneSysSetupMotorPusan1::OnButtonServoPort()
{
#ifndef __MP920_MOTOR__
	CDlgComSetup Dlg;
	Dlg.SetMode(MODE_SERVO);
	Dlg.SetComPortData( &m_sSystemDevice.sServoPort );
	long lBaudRate;
	BYTE nPort; 
	if( IDOK == Dlg.DoModal() )
	{
		Dlg.GetComPortData( &m_sSystemDevice.sServoPort );
		nPort = m_sSystemDevice.sServoPort.nPortNo + 1;
		switch(m_sSystemDevice.sServoPort.nBaudRate)
		{
		case 0: lBaudRate = 2400;	break;
		case 1: lBaudRate = 4800;	break;
		case 2: lBaudRate = 9600;	break;
		case 3: lBaudRate = 19200;	break;
		case 4: lBaudRate = 38400;	break;
		case 5: lBaudRate = 57600;	break;
		case 6: lBaudRate = 115200; break;
		}

		gDeviceFactory.GetMotor()->Disconnect();
		::Sleep(1500);
		
		if(!gDeviceFactory.GetMotor()->Connect(nPort, lBaudRate))
			ErrMessage(_T("Servo Motor Fail Connecting"));
	}
#endif

}

void CPaneSysSetupMotorPusan1::SaveChangeCamOffset(BOOL *pChangeCam)
{
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	strPathName += _T("ChangeHeadOffset");
	CTime curDate = CTime::GetCurrentTime();
	
	CString strCurTime, strBuf, strCam;
	strCurTime.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	strPathName += strCurTime;

	::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, DO_SCANNER);
	CString strFile, strLog;
	strFile.Format(_T("PreWork"));
	strLog.Format(_T("AnyDo (ChangeHeadOffset) : S"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	
	CStdioFile file;
	if (FALSE == file.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;
	
	TRY
	{
		file.SeekToEnd();
		if(pChangeCam[0]) // 1st - high
		{
			strCam.Format(_T("1st High"));
			strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %.3f | %.3f | %.3f | %.3f | %.3f| %.3f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				strCam,
				gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x , m_sSystemDevice.d1stHighHeadOffset.x,
				gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y , m_sSystemDevice.d1stHighHeadOffset.y,
				gSystemINI.m_sSystemDevice.d1stHighHeight , m_sSystemDevice.d1stHighHeight	);
			file.Write(strBuf, strBuf.GetLength());
		}
		
		if(pChangeCam[1]) // 1st - low
		{
			strCam.Format(_T("1st Low"));
			strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %.3f | %.3f | %.3f | %.3f | %.3f| %.3f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				strCam,
				gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x , m_sSystemDevice.d1stLowHeadOffset.x,
				gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y , m_sSystemDevice.d1stLowHeadOffset.y,
				gSystemINI.m_sSystemDevice.d1stLowHeight , m_sSystemDevice.d1stLowHeight);
			file.Write(strBuf, strBuf.GetLength());
		}
		
		if(pChangeCam[2]) // 2nd - high
		{
			strCam.Format(_T("2nd High"));
			strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %.3f | %.3f | %.3f | %.3f | %.3f| %.3f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				strCam,
				gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x , m_sSystemDevice.d2ndHighHeadOffset.x,
				gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y , m_sSystemDevice.d2ndHighHeadOffset.y,
				gSystemINI.m_sSystemDevice.d2ndHighHeight , m_sSystemDevice.d2ndHighHeight);
			file.Write(strBuf, strBuf.GetLength());
		}
		
		if(pChangeCam[3]) // 2nd - low
		{
			strCam.Format(_T("2nd Low"));
			strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %.3f | %.3f | %.3f | %.3f | %.3f| %.3f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				strCam,
				gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x , m_sSystemDevice.d2ndLowHeadOffset.x,
				gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y , m_sSystemDevice.d2ndLowHeadOffset.y,
				gSystemINI.m_sSystemDevice.d2ndLowHeight , m_sSystemDevice.d2ndLowHeight);
			file.Write(strBuf, strBuf.GetLength());
		}
		
		
		
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH
	file.Close();

	
}


BOOL CPaneSysSetupMotorPusan1::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(System_Align) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneSysSetupMotorPusan1::OnBnClickedButtonChiller()
{
	CDlgComSetup Dlg;
	Dlg.SetComPortData( &m_sSystemDevice.sChillerPort );
	if( IDOK == Dlg.DoModal() )
	{
		Dlg.GetComPortData( &m_sSystemDevice.sChillerPort );
		memcpy(&gSystemINI.m_sSystemDevice.sChillerPort, &m_sSystemDevice.sChillerPort, sizeof(m_sSystemDevice.sChillerPort));
		gDeviceFactory.GetMotor()->DisconnectAnyDevice(PORT_CHILLER);
		gDeviceFactory.GetMotor()->ConnectAnyDevice(PORT_CHILLER);
	}

}


void CPaneSysSetupMotorPusan1::OnBnClickedButtonHumidity()
{

	CDlgComSetup Dlg;
	Dlg.SetComPortData( &m_sSystemDevice.sHumidityPort );
	if( IDOK == Dlg.DoModal() )
	{
		Dlg.GetComPortData( &m_sSystemDevice.sHumidityPort );
		memcpy(&gSystemINI.m_sSystemDevice.sHumidityPort, &m_sSystemDevice.sHumidityPort, sizeof(m_sSystemDevice.sHumidityPort));
		gDeviceFactory.GetMotor()->DisconnectAnyDevice(PORT_HUMIDITY);
		gDeviceFactory.GetMotor()->ConnectAnyDevice(PORT_HUMIDITY);
	}

}


void CPaneSysSetupMotorPusan1::OnBnClickedButtonVisionLampPort()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CDlgComSetup Dlg;
	Dlg.SetComPortData(&m_sSystemDevice.sVisionLampPort);
	if (IDOK == Dlg.DoModal())
	{
		Dlg.GetComPortData(&m_sSystemDevice.sVisionLampPort);
		memcpy(&gSystemINI.m_sSystemDevice.sVisionLampPort, &m_sSystemDevice.sVisionLampPort, sizeof(m_sSystemDevice.sVisionLampPort));
		if (gDeviceFactory.GetVision()->m_VisionLamp->PortOpened())
		{
			gDeviceFactory.GetVision()->m_VisionLamp->Destroy();
		}


		gDeviceFactory.GetVision()->m_VisionLamp->SetParameter(gSystemINI.m_sSystemDevice.sVisionLampPort.nPortNo,
			gSystemINI.m_sSystemDevice.sVisionLampPort.nBaudRate,
			gSystemINI.m_sSystemDevice.sVisionLampPort.nParity,
			gSystemINI.m_sSystemDevice.sVisionLampPort.nDataBits,
			gSystemINI.m_sSystemDevice.sVisionLampPort.nStopBits,
			gSystemINI.m_sSystemDevice.sVisionLampPort.nFlowControl);

		if (!gDeviceFactory.GetVision()->m_VisionLamp->PortOpened())
		{
			if (!gDeviceFactory.GetVision()->m_VisionLamp->Create())
			{
				ErrMessage(_T("Vision Lamp Connect Failure"));
			}
		}

	}
}

void CPaneSysSetupMotorPusan1::OnBnClickedButtonVisionLamp2Port()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CDlgComSetup Dlg;
	Dlg.SetComPortData(&m_sSystemDevice.sVisionLampPort2);
	if (IDOK == Dlg.DoModal())
	{
		Dlg.GetComPortData(&m_sSystemDevice.sVisionLampPort2);
		memcpy(&gSystemINI.m_sSystemDevice.sVisionLampPort2, &m_sSystemDevice.sVisionLampPort2, sizeof(m_sSystemDevice.sVisionLampPort2));
		if (gDeviceFactory.GetVision()->m_VisionLamp2->PortOpened())
		{
			gDeviceFactory.GetVision()->m_VisionLamp2->Destroy();
		}


		gDeviceFactory.GetVision()->m_VisionLamp2->SetParameter(gSystemINI.m_sSystemDevice.sVisionLampPort2.nPortNo,
			gSystemINI.m_sSystemDevice.sVisionLampPort2.nBaudRate,
			gSystemINI.m_sSystemDevice.sVisionLampPort2.nParity,
			gSystemINI.m_sSystemDevice.sVisionLampPort2.nDataBits,
			gSystemINI.m_sSystemDevice.sVisionLampPort2.nStopBits,
			gSystemINI.m_sSystemDevice.sVisionLampPort2.nFlowControl);

		if (!gDeviceFactory.GetVision()->m_VisionLamp2->PortOpened())
		{
			if (!gDeviceFactory.GetVision()->m_VisionLamp2->Create())
			{
				ErrMessage(_T("Vision Lamp 2 Connect Failure"));
			}
		}

	}
}
#if !defined(AFX_PANEPROCESSSETUPSUB_H__77875465_C6B9_4D18_BAAA_FFB823ED6F79__INCLUDED_)
#define AFX_PANEPROCESSSETUPSUB_H__77875465_C6B9_4D18_BAAA_FFB823ED6F79__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneProcessSetupSub.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupSub form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"

class CPaneProcessSetupSub : public CFormView
{
protected:
	CPaneProcessSetupSub();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneProcessSetupSub)

// Form Data
public:
	//{{AFX_DATA(CPaneProcessSetupSub)
	enum { IDD = IDD_DLG_PROCESS_SETUP_SUB };
	UEasyButtonEx	m_btnProcessSetupApply;
	UEasyButtonEx	m_btnBack;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void SetAuthorityByLevel(int nLevel);
	void		InitBtnControl();
	void		SetBackPaneNo(int nPaneNo)	{ m_nBackPaneNo = nPaneNo; }
	int			GetBackPaneNo()		{ return m_nBackPaneNo; }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneProcessSetupSub)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneProcessSetupSub();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntBtn;
	int			m_nBackPaneNo;

	// Generated message map functions
	//{{AFX_MSG(CPaneProcessSetupSub)
	afx_msg void OnButtonBack();
	afx_msg void OnButtonProcessSetupApply();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEPROCESSSETUPSUB_H__77875465_C6B9_4D18_BAAA_FFB823ED6F79__INCLUDED_)

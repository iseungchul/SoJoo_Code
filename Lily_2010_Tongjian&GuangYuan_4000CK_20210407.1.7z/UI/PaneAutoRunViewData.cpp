// PaneAutoRunViewData.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneAutoRunViewData.h"
#include "..\model\DProject.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\device\HDeviceFactory.h"
#include "..\device\HLaser.h"
#include "..\device\DeviceMotor.h"
#include "..\device\HMotor.h"
#include "..\model\DSystemINI.h"
#include "..\EasyDrillerDlg.h"
#include "..\alarmmsg.h"
#include "..\Model\DProcessINI.h"
#include "..\device\HDeviceFactory.h"
#include "PaneAutoRun.h"
#include "DlgNGInfo.h"
#include "PaneRecipeGen.h"
#include "PaneRecipeGenFiducialNew.h"
#include "DlgJobMode.h"
#include "..\MODEL\GlobalVariable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


const UINT TIMER_UPDATE_DISPLAY = 1000;
/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewData

IMPLEMENT_DYNCREATE(CPaneAutoRunViewData, CFormView)

CPaneAutoRunViewData::CPaneAutoRunViewData()
	: CFormView(CPaneAutoRunViewData::IDD)
{

	m_bMotor = FALSE;
	m_bLaser = FALSE;
	m_bEStop = FALSE;
	m_bTableSuction = FALSE;
	m_bTableSuction2 = FALSE;
	m_bVacuumMotor = FALSE;
	m_bInit = FALSE;
	m_bFluorescentLamp = FALSE;
	m_bDummyFreeLamp = FALSE;
	m_bAutoRun = FALSE;
	m_bMainPower = FALSE;
	m_bClamp = FALSE;
	m_bClamp2 = FALSE;
	m_bViewerMoveMode = TRUE;
	m_nTimer = 0;
	
	m_ptMoveStart.x = 0;
	m_ptMoveStart.y = 0;
	m_bDrawMoveStart = FALSE;
	m_ptDrawRectBack1.x = m_ptDrawRectBack1.y = 0;
	m_ptDrawRectBack2.x = m_ptDrawRectBack2.y = 0;
	m_ptDrawStart.x = m_ptDrawStart.y = 0;

	m_bDrillRun = FALSE;
	m_bLoadUnload = FALSE;
	m_nNGBoxCondition = 0;

	m_nJobModeOld =0;
	m_nPMCount =0;
	m_nPnlCheckCount =0;
	m_nFailureCount =0;
	m_nTestCount =0;
	m_nJobOtherCount =0;

}

CPaneAutoRunViewData::~CPaneAutoRunViewData()
{
}

void CPaneAutoRunViewData::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneAutoRunViewData)
	DDX_Control(pDX, IDC_BUTTON_UNLOADING, m_btnUnloading);
	DDX_Control(pDX, IDC_BUTTON_LOADING, m_btnLoading);
	DDX_Control(pDX, IDC_BUTTON_CHANGE_BOARD1, m_btnChangeBoard);
	DDX_Control(pDX, IDC_BUTTON_UNLOAD_POS, m_btnUnloadPos);
	DDX_Control(pDX, IDC_BUTTON_UC_TABLE, m_btnUCTable);
	DDX_Control(pDX, IDC_BUTTON_UC_CART, m_btnUCCart);
	DDX_Control(pDX, IDC_BUTTON_LOAD_POS, m_btnLoadPos);
	DDX_Control(pDX, IDC_BUTTON_LC_TABLE, m_btnLCTable);
	DDX_Control(pDX, IDC_BUTTON_LC_CART, m_btnLCCart);
	DDX_Control(pDX, IDC_BUTTON_VIEW_VACUUM, m_btnVacuumViewer);
	DDX_Control(pDX, IDC_BUTTON_ALL_REJECT, m_btnAllReject);
	DDX_Control(pDX, IDC_CHECK_MAIN_POWER, m_ledMainPower);
	DDX_Control(pDX, IDC_CHECK_LASER, m_ledLaser);
	DDX_Control(pDX, IDC_CHECK_E_STOP2, m_ledEStop);
	DDX_Control(pDX, IDC_CHECK_AUTO_RUN2, m_ledAutoRun);
	DDX_Control(pDX, IDC_CHECK_MOTOR2010, m_ledMotor);
	DDX_Control(pDX, IDC_CHECK_DUMMY_FREE, m_ledDummyFree);
	DDX_Control(pDX, IDC_CHECK_TABLE_SUCTION, m_ledTableSuction);
	DDX_Control(pDX, IDC_CHECK_TABLE_SUCTION2, m_ledTableSuction2);
	DDX_Control(pDX, IDC_CHECK_TABLE_VACUUM_MOTOR, m_ledVacuumMotor);
	DDX_Control(pDX, IDC_CHECK_INITIALIZATION, m_ledInit);
	DDX_Control(pDX, IDC_CHECK_FLUORESCENT_LAMP, m_ledFluorescentLamp);
	DDX_Control(pDX, IDC_CHECK_TABLE_CLAMP1, m_ledClamp);
	DDX_Control(pDX, IDC_CHECK_TABLE_CLAMP2, m_ledClamp2);
	DDX_Control(pDX, IDC_CHECK_REVERSE, m_ledReverse);
	DDX_Control(pDX, IDC_BUTTON_JOB_MODE,m_btnJobMode);
	DDX_Control(pDX, IDC_STATIC_JOB_MODE,m_stcJobMode);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneAutoRunViewData, CFormView)
	//{{AFX_MSG_MAP(CPaneAutoRunViewData)
	ON_WM_PAINT()
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_VIEW_VACUUM, OnButtonViewVacuum)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_UC_CART, OnButtonUcCart)
	ON_BN_CLICKED(IDC_BUTTON_UC_TABLE, OnButtonUcTable)
	ON_BN_CLICKED(IDC_BUTTON_LC_TABLE, OnButtonLcTable)
	ON_BN_CLICKED(IDC_BUTTON_LC_CART, OnButtonLcCart)
	ON_BN_CLICKED(IDC_BUTTON_UNLOAD_POS, OnButtonUnloadPos)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_POS, OnButtonLoadPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADING, OnButtonLoading)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADING, OnButtonUnloading)
	ON_BN_CLICKED(IDC_BUTTON_CHANGE_BOARD1, OnButtonChangeBoard1)
	ON_BN_CLICKED(IDC_CHECK_TABLE_SUCTION, OnCheckTableSuction)
	ON_BN_CLICKED(IDC_CHECK_TABLE_SUCTION2, OnCheckTableSuction2)
	ON_BN_CLICKED(IDC_CHECK_TABLE_VACUUM_MOTOR, OnCheckVacuumMotor)
	ON_BN_CLICKED(IDC_CHECK_FLUORESCENT_LAMP, OnCheckFluorescentLamp)
	ON_BN_CLICKED(IDC_CHECK_REVERSE, OnCheckReverse)	
	ON_BN_CLICKED(IDC_BUTTON_ALL_REJECT, OnButtonAllReject)
	ON_BN_CLICKED(IDC_CHECK_TABLE_CLAMP1, OnCheckTableClamp)
	ON_BN_CLICKED(IDC_CHECK_TABLE_CLAMP2, OnCheckTableClamp2)
	ON_WM_LBUTTONDOWN()
	ON_WM_SETCURSOR()
	ON_WM_CANCELMODE()
	ON_WM_MOUSEWHEEL()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_BN_CLICKED(IDC_CHECK_DUMMY_FREE, OnCheckDummyFree)
	ON_BN_CLICKED(IDC_BUTTON_JOB_MODE, OnBnClickedJobMode)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewData diagnostics

#ifdef _DEBUG
void CPaneAutoRunViewData::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneAutoRunViewData::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewData message handlers

void CPaneAutoRunViewData::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStatic();
	InitBtnControl();
	InitTimer();
	m_dlgVacuumViewer.Create(IDD_DLG_VACUUM_VIEWER);
	m_dlgVacuumViewer.ShowWindow(SW_HIDE);

	if(gSystemINI.m_sHardWare.bTableVacuumSelect)
		m_ledVacuumMotor.ShowWindow(SW_SHOW);
	else
		m_ledVacuumMotor.ShowWindow(SW_HIDE);

#ifdef __KUNSAN_1__
	m_ledClamp.ShowWindow(SW_HIDE);
	m_ledClamp2.ShowWindow(SW_HIDE);
	m_ledClamp.EnableWindow(FALSE);
	m_ledClamp2.EnableWindow(FALSE);
#endif

#ifdef __KUNSAN_8__
	m_ledClamp.ShowWindow(SW_HIDE);
	m_ledClamp2.ShowWindow(SW_HIDE);
	m_ledDummyFree.ShowWindow(SW_HIDE);
#endif
#ifndef __KUNSAN_SAMSUNG_LARGE__
	m_ledReverse.ShowWindow(SW_HIDE);
#endif

#ifdef __3RDAOD__
	if(gSystemINI.m_sSystemDump.n3RDDummyType == DUMMY_3RD_NO_USE)
		m_ledDummyFree.ShowWindow(SW_HIDE);
#endif
}

BOOL CPaneAutoRunViewData::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

HBRUSH CPaneAutoRunViewData::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_DEVICE_STATUS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MOTOR)->GetSafeHwnd() == pWnd->m_hWnd  ||
		GetDlgItem(IDC_STATIC_COMMAND)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0,0, 255) );

	if(GetDlgItem(IDC_STATIC_DRY_RUN)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(255,0,0) );

	if(GetDlgItem(IDC_STATIC_NO_FIDUCIAL)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(255,0,0) );

	if(GetDlgItem(IDC_STATIC_NO_SUCTION)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(255,0,0) );
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneAutoRunViewData::InitStatic()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");
	m_fntStaticBig.CreatePointFont(170, "Arial Bold");
	
	GetDlgItem(IDC_STATIC_DEVICE_STATUS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOTOR)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_COMMAND)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOADER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOADER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TABLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MAIN_AIR_VALUE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_WATER_FLOW1_VALUE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_WATER_FLOW2_VALUE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CHILLER_VALUE)->SetFont( &m_fntStatic );

	
#ifdef __OSAN_LG_2013__
	GetDlgItem(IDC_STATIC_WATER_FLOW1_VALUE)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_WATER_FLOW2_VALUE)->ShowWindow(SW_SHOW);
#else
	GetDlgItem(IDC_STATIC_WATER_FLOW1_VALUE)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_WATER_FLOW2_VALUE)->ShowWindow(SW_HIDE);
#endif
	
	GetDlgItem(IDC_STATIC_DRY_RUN)->SetFont( &m_fntStaticBig );
	GetDlgItem(IDC_STATIC_NO_FIDUCIAL)->SetFont( &m_fntStaticBig );
	GetDlgItem(IDC_STATIC_NO_SUCTION)->SetFont( &m_fntStaticBig );

}

void CPaneAutoRunViewData::InitBtnControl()
{
	m_fntBtn.CreatePointFont(90, "Arial Bold");
	
	//Unloading pos
	m_btnUnloadPos.SetFont( &m_fntBtn );
	m_btnUnloadPos.SetFlat( FALSE );
	m_btnUnloadPos.EnableBallonToolTip();
	m_btnUnloadPos.SetToolTipText( _T("Move Table to Unloading Position") );
	m_btnUnloadPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadPos.SetBtnCursor(IDC_HAND_1);

	//Loading Pos
	m_btnLoadPos.SetFont( &m_fntBtn );
	m_btnLoadPos.SetFlat( FALSE );
	m_btnLoadPos.EnableBallonToolTip();
	m_btnLoadPos.SetToolTipText( _T("Move Table to Loading Position") );
	m_btnLoadPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadPos.SetBtnCursor(IDC_HAND_1);

	//Unload To Cart
	m_btnUCCart.SetFont( &m_fntBtn );
	m_btnUCCart.SetFlat( FALSE );
	m_btnUCCart.EnableBallonToolTip();
	m_btnUCCart.SetToolTipText( _T("Move Unload Carrier to Cart Position") );
	m_btnUCCart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUCCart.SetBtnCursor(IDC_HAND_1);

	//Unload To Table
	m_btnUCTable.SetFont( &m_fntBtn );
	m_btnUCTable.SetFlat( FALSE );
	m_btnUCTable.EnableBallonToolTip();
	m_btnUCTable.SetToolTipText( _T("Move Unload Carrier to Table Position") );
	m_btnUCTable.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUCTable.SetBtnCursor(IDC_HAND_1);

	//Load To Table
	m_btnLCTable.SetFont( &m_fntBtn );
	m_btnLCTable.SetFlat( FALSE );
	m_btnLCTable.EnableBallonToolTip();
	m_btnLCTable.SetToolTipText( _T("Move Load Carrier to Table Position") );
	m_btnLCTable.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLCTable.SetBtnCursor(IDC_HAND_1);

	//Load To Cart
	m_btnLCCart.SetFont( &m_fntBtn );
	m_btnLCCart.SetFlat( FALSE );
	m_btnLCCart.EnableBallonToolTip();
	m_btnLCCart.SetToolTipText( _T("Move Load Carrier to Cart Position") );
	m_btnLCCart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLCCart.SetBtnCursor(IDC_HAND_1);

	// Vacuum Viewer
	m_btnVacuumViewer.SetFont( &m_fntBtn );
	m_btnVacuumViewer.SetFlat( FALSE );
	m_btnVacuumViewer.EnableBallonToolTip();
	m_btnVacuumViewer.SetToolTipText( _T("Table Vacuum Viewer") );
	m_btnVacuumViewer.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVacuumViewer.SetBtnCursor(IDC_HAND_1);

	// Vacuum Viewer
	m_btnLoading.SetFont( &m_fntBtn );
	m_btnLoading.SetFlat( FALSE );
	m_btnLoading.EnableBallonToolTip();
	m_btnLoading.SetToolTipText( _T("Loading") );
	m_btnLoading.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoading.SetBtnCursor(IDC_HAND_1);
	
	// Unloading
	m_btnUnloading.SetFont( &m_fntBtn );
	m_btnUnloading.SetFlat( FALSE );
	m_btnUnloading.EnableBallonToolTip();
	m_btnUnloading.SetToolTipText( _T("Unloading ") );
	m_btnUnloading.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloading.SetBtnCursor(IDC_HAND_1);
	
	// Change Board
	m_btnChangeBoard.SetFont( &m_fntBtn );
	m_btnChangeBoard.SetFlat( FALSE );
	m_btnChangeBoard.EnableBallonToolTip();
	m_btnChangeBoard.SetToolTipText( _T("Align") );
	m_btnChangeBoard.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnChangeBoard.SetBtnCursor(IDC_HAND_1);

	// All Reject
	m_btnAllReject.SetFont( &m_fntBtn );
	m_btnAllReject.SetFlat( FALSE );
	m_btnAllReject.EnableBallonToolTip();
	m_btnAllReject.SetToolTipText( _T("Reject ") );
	m_btnAllReject.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAllReject.SetBtnCursor(IDC_HAND_1);

	//Job mode button
	m_btnJobMode.SetFont( &m_fntBtn );
	m_btnJobMode.SetFlat( FALSE );
	m_btnJobMode.EnableBallonToolTip();
	m_btnJobMode.SetToolTipText( _T("Job Mode") );
	m_btnJobMode.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnJobMode.SetBtnCursor(IDC_HAND_1);

	//Job Mode static
	m_stcJobMode.SetBackColor(VALUE_BACK_COLOR);

	// Motor
	m_ledMotor.SetFont( &m_fntBtn );
	m_ledMotor.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMotor.Depress( TRUE );

	// Motor
	m_ledDummyFree.SetFont( &m_fntBtn );
	m_ledDummyFree.SetImage( IDB_LEDCOLOR, 15 );
	m_ledDummyFree.Depress( TRUE );

	// Laser
	m_ledLaser.SetFont( &m_fntBtn );
	m_ledLaser.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLaser.Depress( TRUE );
	
	// Main Power
	m_ledMainPower.SetFont( &m_fntBtn );
	m_ledMainPower.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMainPower.Depress( TRUE );
	
	// E-Stop
	m_ledEStop.SetFont( &m_fntBtn );
	m_ledEStop.SetImage( IDB_LEDCOLOR, 15 );
	m_ledEStop.Depress( TRUE );
	
	// Table Suction1
	m_ledTableSuction.SetFont( &m_fntBtn );
	m_ledTableSuction.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTableSuction.Depress( TRUE );
//	m_ledTableSuction.SetCursor(IDC_HAND_1);
	
	// Table Suction2
	m_ledTableSuction2.SetFont( &m_fntBtn );
	m_ledTableSuction2.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTableSuction2.Depress( TRUE );
//	m_ledTableSuction2.SetBtnCursor(IDC_HAND_1);

	// Vacuum Motor
	m_ledVacuumMotor.SetFont( &m_fntBtn );
	m_ledVacuumMotor.SetImage( IDB_LEDCOLOR, 15 );
	m_ledVacuumMotor.Depress( TRUE );
//	m_ledVacuumMotor.SetBtnCursor(IDC_HAND_1);
	
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
	{
		m_ledTableSuction.SetWindowText("Suction On");
		m_ledTableSuction2.SetWindowText("Suction Off");
	}
	
	// Initialization
	m_ledInit.SetFont( &m_fntBtn );
	m_ledInit.SetImage( IDB_LEDCOLOR, 15 );
	m_ledInit.Depress( TRUE );
	
	// AutoRun
	m_ledAutoRun.SetFont( &m_fntBtn );
	m_ledAutoRun.SetImage( IDB_LEDCOLOR, 15 );
	m_ledAutoRun.Depress( TRUE );
		
	// Fluorescent Lamp
	m_ledFluorescentLamp.SetFont( &m_fntBtn );
	m_ledFluorescentLamp.SetImage( IDB_LEDCOLOR, 15 );
	m_ledFluorescentLamp.Depress( TRUE );
//	m_ledFluorescentLamp.SetBtnCursor(IDC_HAND_1);

	// Clamp1
	m_ledClamp.SetFont( &m_fntBtn );
	m_ledClamp.SetImage( IDB_LEDCOLOR, 15 );
	m_ledClamp.Depress( TRUE );
//	m_ledClamp.SetBtnCursor(IDC_HAND_1);
	
	// Clamp2
	m_ledClamp2.SetFont( &m_fntBtn );
	m_ledClamp2.SetImage( IDB_LEDCOLOR, 15 );
	m_ledClamp2.Depress( TRUE );
//	m_ledClamp2.SetBtnCursor(IDC_HAND_1);

	if(gSystemINI.m_sHardWare.nTableClamp < 1)
	{
		m_ledClamp.ShowWindow(SW_HIDE);
		m_ledClamp2.ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nTableClamp < 2)
		m_ledClamp2.ShowWindow(SW_HIDE);

	// Reverse Direction
	m_ledReverse.SetFont( &m_fntBtn );
	m_ledReverse.SetImage( IDB_LEDCOLOR, 15 );
	m_ledReverse.Depress( TRUE );

}


void CPaneAutoRunViewData::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	DrawData();
	// Do not call CFormView::OnPaint() for painting messages
}
void CPaneAutoRunViewData::DrawData()
{
	CClientDC dc(GetDlgItem(IDC_STC_RUN_VIEW));
	CDC BufferDC;
	CRect cRect;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetClientRect(&cRect);
	
	BufferDC.CreateCompatibleDC(&dc);
	CBitmap bmpBuffer;
	bmpBuffer.CreateCompatibleBitmap(&dc,cRect.Width(), cRect.Height());
	
	CBitmap *pOldBitmap = (CBitmap*)BufferDC.SelectObject(&bmpBuffer);
	
	CBrush cBr(RGB(0, 0, 0));
	BufferDC.FrameRect(&cRect, &cBr);
	BufferDC.FillSolidRect(&cRect, RGB(255, 255, 255));
	
	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	BufferDC.SelectClipRgn(&cRgn);
	
	//	SetDCCoord(&BufferDC);
	
	int nPenSize;
	nPenSize = 3;
	
	CPen pen;
	CPen* pOldPen;
	CBrush cBr2;
	CBrush* pOldBrush;
	
	pen.CreatePen(PS_SOLID, nPenSize, RGB(0, 0, 200));
	pOldPen = BufferDC.SelectObject(&pen);
	
	cBr2.CreateSolidBrush(RGB(0, 0, 200));
	pOldBrush = BufferDC.SelectObject(&cBr2);
	
	// draw
//	gDProject.InitialDrawRatio(cRect, 2);
	gDProject.Draw(&BufferDC, cRect, FALSE, 2);
	gDProject.DrawToolInfoRunView(&BufferDC, cRect);
	
	BufferDC.SelectObject(pOldBrush);
	BufferDC.SelectObject(pOldPen);
	
	//	GetDlgItem(IDC_STATIC_DRAW)->GetWindowRect(&cRect);
	dc.BitBlt(0,0,cRect.Width(),cRect.Height(),&BufferDC,0,0,SRCCOPY);
	
	BufferDC.SelectObject(pOldBitmap);

    ::AfxGetMainWnd()->SendMessage(UM_EASY_TEST_DRAW);
}



void CPaneAutoRunViewData::OnButtonViewVacuum() 
{
	// TODO: Add your control notification handler code here
/*	CRect rtPos;
	GetDlgItem(IDC_BUTTON_PRODUCT_COUNTER_CLEAR)->GetWindowRect( rtPos );
	
	CRect rcPane;
	rcPane.top		= rtPos.top;
	rcPane.left		= rtPos.left;
	rcPane.right	= rtPos.left + 360;
	rcPane.bottom	= rtPos.top + 300;
	
	m_dlgVacuumViewer.MoveWindow(rcPane);
*/	
#ifndef __MP920_MOTOR__
	m_dlgVacuumViewer.ShowWindow(SW_SHOW);
	m_dlgVacuumViewer.SetMotor(gDeviceFactory.GetMotor());
	m_dlgVacuumViewer.InitTimer();
#endif
}

void CPaneAutoRunViewData::UpdateLed()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

#ifdef __3RDAOD__
//	if(gSystemINI.m_sSystemDump.n3RDDummyType == DUMMY_3RD_NO_USE)
	{
		GetDlgItem(IDC_CHECK_DUMMY_FREE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_DUMMY_FREE)->ShowWindow(SW_HIDE);
	}
//	else
//	{
//		GetDlgItem(IDC_CHECK_DUMMY_FREE)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_BUTTON_DUMMY_FREE)->ShowWindow(SW_SHOW);
//	}
#endif

	// Motor
	m_bMotor = pMotor->IsReady();
	m_ledMotor.Depress( !m_bMotor );
	
	// Laser
	int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
	int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
	BOOL bAOM = pMotor->GetAOMStatus(); 
	BOOL bScanner = pMotor->GetScannerStatus();

	BOOL bPower, bShutter;
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
		gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
		gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		bPower = nPower;
		bShutter = nShutter;
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		if(nPower & 0x02) 
			bPower = TRUE;
		else
			bPower = FALSE;
		
		if(nShutter & 0x02)
			bShutter = TRUE;
		else
			bShutter = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_HYBRID)
	{
		if(nPower & 0x03) 
			bPower = TRUE;
		else
			bPower = FALSE;
		
		if(nShutter & 0x03)
			bShutter = TRUE;
		else
			bShutter = FALSE;
	}

	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
		m_bLaser = gDeviceFactory.GetLaser()->IsFireOK();
	else
		m_bLaser = bPower & bShutter & bAOM & bScanner;

	m_ledLaser.Depress( !m_bLaser );

	m_bClamp = gDeviceFactory.GetMotor()->GetCurrentTableClamp(TRUE, TRUE);
	m_bClamp2 = gDeviceFactory.GetMotor()->GetCurrentTableClamp(FALSE, TRUE);

	m_ledClamp.Depress( !m_bClamp );
	m_ledClamp2.Depress( !m_bClamp2 );

	BOOL bReverse = gDeviceFactory.GetMotor()->GetReverseDirection();
	m_ledReverse.Depress( !bReverse );

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_PMAC)
	{	
		// Main Power
		m_bMainPower = pMotor->IsReady();
		m_ledMainPower.Depress( !m_bMainPower );
	
		// E-Stop
		m_bEStop = pMotor->GetCurrentEMStop();
		m_ledEStop.Depress( !m_bEStop );
	
		// Table Suction
		BOOL bMotor, b1st = TRUE, b2nd = TRUE;
		int nSuction1;
		nSuction1 = pMotor->GetCurrentSuction();

		bMotor = pMotor->GetCurrentSuctionMotor();
	#ifdef __CUNGJU_JASMINE_OLD__
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->GetFileOpen())
		{
			if((nSuction1 == 5 || nSuction1 == 15) && bMotor)
				b1st = TRUE;
			else
				b1st = FALSE;
			
			if((nSuction1 == 11 || nSuction1 == 15) &&bMotor)
				b2nd = TRUE;
			else
				b2nd = FALSE;
		}
		else
		{
			if((nSuction1 == 5 || nSuction1 == 15) && bMotor)
				b1st = TRUE;
			else
				b1st = FALSE;

			if((nSuction1 == 11 || nSuction1 == 15) && bMotor)
				b2nd = TRUE;
			else
				b2nd = FALSE;
			
	
		}
	#else
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->GetFileOpen())
		{
			if((nSuction1 & 0x01) && bMotor)
				b1st = TRUE;
			else
				b1st = FALSE;
			
			if((nSuction1 & 0x02) &&bMotor)
				b2nd = TRUE;
			else
				b2nd = FALSE;
		}
		else
		{
			if(nSuction1 & 0x01 && bMotor)
				b1st = TRUE;
			else
				b1st = FALSE;

			if(nSuction1 & 0x02 && bMotor)
				b2nd = TRUE;
			else
				b2nd = FALSE;
			
	
		}
	#endif

		m_bTableSuction = b1st;
		m_ledTableSuction.Depress( !m_bTableSuction );

		m_bTableSuction2 = b2nd;
		m_ledTableSuction2.Depress( !m_bTableSuction2 );

		m_bVacuumMotor = bMotor;
		m_ledVacuumMotor.Depress( !m_bVacuumMotor );
	
		// Initialization
		m_bInit = pMotor->IsInOrigin(-1, FALSE);
		m_ledInit.Depress( !m_bInit );

		// Fluorescent Lamp
		m_bFluorescentLamp = pMotor->IsFluorescentLampOn();
		m_ledFluorescentLamp.Depress( !m_bFluorescentLamp );

		// AutoRun
		BOOL m_bModeNew = pMotor->GetCurrentMode();

		if(m_bModeNew == MODE_AUTO)
			m_bAutoRun = TRUE;
		else
			m_bAutoRun = FALSE;

		m_ledAutoRun.Depress( !m_bAutoRun );

		m_bDummyFreeLamp = gDeviceFactory.GetEocard()->IsStannbyShotRun();
		m_ledDummyFree.Depress( !m_bDummyFreeLamp);

		if(gProcessINI.m_sProcessSystem.bDryRun)
			GetDlgItem(IDC_STATIC_DRY_RUN)->ShowWindow(SW_SHOW);
		else
			GetDlgItem(IDC_STATIC_DRY_RUN)->ShowWindow(SW_HIDE);

		if(gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
			GetDlgItem(IDC_STATIC_NO_FIDUCIAL)->ShowWindow(SW_SHOW);
		else
			GetDlgItem(IDC_STATIC_NO_FIDUCIAL)->ShowWindow(SW_HIDE);

		if(gProcessINI.m_sProcessSystem.bNoUseSuction)
			GetDlgItem(IDC_STATIC_NO_SUCTION)->ShowWindow(SW_SHOW);
		else
			GetDlgItem(IDC_STATIC_NO_SUCTION)->ShowWindow(SW_HIDE);

	}
	
/*	CString str;
	int nValue = pMotor->GetMainAirValue();

	str.Format(_T("Main Air Value : %.1f MPa"), ((nValue - 169) / 670.0) );
	GetDlgItem(IDC_STATIC_MAIN_AIR_VALUE)->SetWindowText(str);


	CString str;
	double dVal;
	
	dVal = gDeviceFactory.GetMotor()->GetChillerTemp();
	
	str.Format(_T("Chiller Temp Value : %.1f"), dVal);
	GetDlgItem(IDC_STATIC_CHILLER_VALUE)->SetWindowText(str);
*/
#ifdef __OSAN_LG_2013__	
	CString str;
	str.GetBuffer(256);
	int WaterFlow1Value = pMotor->GetWaterFlow1Value();
	int WaterFlow2Value = pMotor->GetWaterFlow2Value();

	str.Format(_T("Water Flow1 Value : %.1f L/Min"), ((WaterFlow1Value - 156) / 6.0) );
	GetDlgItem(IDC_STATIC_WATER_FLOW1_VALUE)->SetWindowText(str);

	str.Format(_T("Water Flow2 Value : %.1f L/Min"), ((WaterFlow2Value - 156) / 6.0) );
	GetDlgItem(IDC_STATIC_WATER_FLOW2_VALUE)->SetWindowText(str);
	str.ReleaseBuffer(256);
#endif

	if(gVariable.m_nJobMode != m_nJobModeOld)
	{
		if(m_nJobModeOld == 1)
			::AfxGetMainWnd()->SendMessage(UM_SET_JOB_TIME, m_nPMCount, PM_JOB);
		else if(m_nJobModeOld == 2)
			::AfxGetMainWnd()->SendMessage(UM_SET_JOB_TIME, m_nPnlCheckCount, PNLCHK_JOB);
		else if(m_nJobModeOld == 3)
			::AfxGetMainWnd()->SendMessage(UM_SET_JOB_TIME, m_nTestCount, TEST_JOB);
		else if(m_nJobModeOld == 4)
			::AfxGetMainWnd()->SendMessage(UM_SET_JOB_TIME, m_nFailureCount, FAILURE_JOB);
		else
			::AfxGetMainWnd()->SendMessage(UM_SET_JOB_TIME, m_nJobOtherCount, OTHER_JOB);

		m_nJobModeOld = gVariable.m_nJobMode;
	}

	if(gVariable.m_nJobMode == 1)
	{
		m_nPMCount++;
		m_nPnlCheckCount = 0;
		m_nTestCount = 0;
		m_nFailureCount = 0;
		m_nJobOtherCount = 0;

		if(m_nPMCount >= 600)
		{
			::AfxGetMainWnd()->SendMessage(UM_SET_JOB_TIME, m_nPMCount, PM_JOB);
			m_nPMCount = 0;
		}
	}
	else if(gVariable.m_nJobMode == 2)
	{
		m_nPnlCheckCount++;
		m_nPMCount = 0;
		m_nTestCount = 0;
		m_nFailureCount = 0;
		m_nJobOtherCount = 0;

		if(m_nPnlCheckCount >= 600)
		{
			::AfxGetMainWnd()->SendMessage(UM_SET_JOB_TIME, m_nPnlCheckCount, PNLCHK_JOB);
			m_nPnlCheckCount = 0;
		}
	}
	else if(gVariable.m_nJobMode == 3)
	{
		m_nTestCount++;
		m_nPMCount = 0;
		m_nPnlCheckCount = 0;
		m_nFailureCount = 0;
		m_nJobOtherCount = 0;
		if(m_nTestCount >= 600)
		{
			::AfxGetMainWnd()->SendMessage(UM_SET_JOB_TIME, m_nTestCount, TEST_JOB);
			m_nTestCount = 0;
		}
	}
	else if (gVariable.m_nJobMode == 4)
	{
		m_nFailureCount++;
		m_nPMCount = 0;
		m_nPnlCheckCount = 0;
		m_nTestCount = 0;
		m_nJobOtherCount = 0;
		if(m_nFailureCount >= 600)
		{
			::AfxGetMainWnd()->SendMessage(UM_SET_JOB_TIME, m_nFailureCount, FAILURE_JOB);
			m_nFailureCount = 0;
		}
	}
	else if(gVariable.m_nJobMode == 5)
	{
		m_nJobOtherCount++;
		m_nPMCount = 0;
		m_nPnlCheckCount = 0;
		m_nTestCount = 0;
		m_nFailureCount = 0;
		if(m_nJobOtherCount >= 0)
		{
			::AfxGetMainWnd()->SendMessage(UM_SET_JOB_TIME, m_nJobOtherCount, OTHER_JOB);
			m_nJobOtherCount = 0;
		}
	}
	else
	{
		m_nPMCount = 0;
		m_nPnlCheckCount = 0;
		m_nFailureCount = 0;
		m_nTestCount = 0;
		m_nJobOtherCount = 0;
	}

}
 
void CPaneAutoRunViewData::InitTimer()
{
	if(!m_nTimer)
		m_nTimer = SetTimer(TIMER_UPDATE_DISPLAY, 1000, NULL);
}

void CPaneAutoRunViewData::DestroyTimer()
{	
	if(m_nTimer)
	{
		KillTimer(m_nTimer);
		m_nTimer = 0;
	}
}

void CPaneAutoRunViewData::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent == m_nTimer)
		UpdateLed();
	CFormView::OnTimer(nIDEvent);
}

void CPaneAutoRunViewData::OnButtonUcCart() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(m_bDrillRun)
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
	if(GetAutoRun())
		return;
	
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(pMotor->IsStartMode())
	{
		ErrMessage(_T(" Please Change Loader, Unloader Mode -> <STOP>"));
		return;
	}
#endif
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}

	pMotor->UnloaderCarrierUnloadPos();
}

void CPaneAutoRunViewData::OnButtonUcTable() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(GetAutoRun())
		return;
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(pMotor->IsStartMode())
	{
		ErrMessage(_T(" Please Change Loader, Unloader Mode -> <STOP>"));
		return;
	}
#endif

	if (m_bAutoRun)    //20190815 lsc
	{
		if(pMotor->GetCurrentMode() == MODE_MPG)
		{
			::ErrMsgDlg(STDGNALM209);
			return;
		}
		if(pMotor->IsSafetyMode())
		{
			::ErrMsgDlg(STDGNALM207);
			return;
		}
	}
	else
	{
		if(pMotor->GetCurrentMode() == MODE_MPG)
		{
			::ErrMsgDlg(STDGNALM209);
			return;
		}

		if(pMotor->IsSafetyMode())
		{
			::ErrMsgDlg(STDGNALM207);
			return;
		}
	}
	
	pMotor->UnloaderCarrierTablePos();
}

void CPaneAutoRunViewData::OnButtonLcTable() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(GetAutoRun())
		return;
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(pMotor->IsStartMode())
	{
		ErrMessage(_T(" Please Change Loader, Unloader Mode -> <STOP>"));
		return;
	}
#endif
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}

	pMotor->LoaderCarrierLoadPos();
}

void CPaneAutoRunViewData::OnButtonLcCart() 
{
	if(m_bDrillRun)
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(GetAutoRun())
		return;
#ifdef __KUNSAN_SAMSUNG_LARGE__	
	if(pMotor->IsStartMode())
	{
		ErrMessage(_T(" Please Change Loader, Unloader Mode -> <STOP>"));
		return;
	}
#endif
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}

	gDeviceFactory.GetMotor()->LoaderCarrierCartPos();
}

void CPaneAutoRunViewData::OnButtonUnloadPos() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return;
	}
	if(m_bDrillRun)
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}
	
	if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dUnloadPosX, gProcessINI.m_sProcessAutoSetting.dUnloadPosY, TRUE))
	{
		::ErrMsgDlg(STDGNALM438);
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis, TRUE);
	}
}

void CPaneAutoRunViewData::OnButtonLoadPos() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(m_bDrillRun)
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}
	
	if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX, gProcessINI.m_sProcessAutoSetting.dLoadPosY, TRUE))
	{
		::ErrMsgDlg(STDGNALM438);
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis, TRUE);
	}
}

void CPaneAutoRunViewData::OnButtonLoading() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(m_bDrillRun)
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}

	int nCmd;
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	if(gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		ErrMessage(IDS_NO_USE_HANDLER);
		return;
	}
	else
	{
		if(!pMotor->IsStartMode())
		{
			ErrMsgDlg(STDGNALM1152);
			return;
		}
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}
	EnableControl(FALSE); //20130412 jghan
	if(!pMotor->IsHandlerOperation( HANDLER_LOADER_ALIGN, TRUE, FALSE ))
	{
		// 110610 Start
		if(pMotor->IsHandlerOperation( HANDLER_LOADER_ALIGN, FALSE, FALSE ))
		{
			ErrMessage(_T("Align is in progress.\r\nAlign Command Reject."));
			EnableControl(TRUE); //20130412 jghan
			return;
		}
		// 110610 End
		
		if(pMotor->IsLoadCartNoPCB())
		{
			ErrMessage(_T("There is no PCB in Loader.\r\nAlign Command Reject."));
			EnableControl(TRUE); //20130412 jghan
			return;
		}
		
		UpdateData(TRUE);
		
		if(gDProject.m_nSeparation == USE_DUAL)
			nCmd = 0;
		else if(gDProject.m_nSeparation == USE_1ST)
			nCmd = 1;
		else
			nCmd = 2;

#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, nCmd);
#endif

		pMotor->HandlerOperation(HANDLER_LOADER_ALIGN);
		
		::Sleep(500);
		
		//	pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, TRUE, TRUE);
		
		if(!WaitHandler(HANDLER_ALIGNERSTOP))
		{
			if(pMotor->IsLoadCartNoPCB())
			{
				ErrMsgDlg(STDGNALM715);
				EnableControl(TRUE); //20130412 jghan
#ifdef __KUNSAN_SAMSUNG_LARGE__
				pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, FALSE);
#endif
				return;
			}
			else
			{
				ErrMsgDlg(STDGNALM721);
				EnableControl(TRUE); //20130412 jghan
#ifdef __KUNSAN_SAMSUNG_LARGE__
				pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, FALSE);
#endif
				return;
			}
		}
		if(m_bDrillRun)
			return;
#ifdef __KUNSAN_SAMSUNG_LARGE__
		pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, FALSE);
#endif
	}

	if(pMotor->IsHandlerOperation( HANDLER_LOADER_LOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("Loading is in progress.\r\nLoad Command Reject."));
		EnableControl(TRUE); //20130412 jghan
		return;
	}
#ifdef __KUNSAN_SAMSUNG_LARGE__
	pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
#endif
/*	if( (gDProject.m_nSeparation == USE_DUAL && (!pMotor->IsLoaderPicker1PCBExist() || !pMotor->IsLoaderPicker2PCBExist())) ||
		(gDProject.m_nSeparation == USE_1ST && !pMotor->IsLoaderPicker1PCBExist()) ||
		(gDProject.m_nSeparation == USE_2ND && !pMotor->IsLoaderPicker2PCBExist()))
	{
		if(gDProject.m_nSeparation == USE_DUAL)
			nCmd = 0;
		else if(gDProject.m_nSeparation == USE_1ST)
			nCmd = 1;
		else
			nCmd = 2;
	}
*/
	if( gDProject.m_nSeparation == USE_DUAL ||
		gDProject.m_nSeparation == USE_1ST  ||
		gDProject.m_nSeparation == USE_2ND)
	{
		if(gDProject.m_nSeparation == USE_DUAL)
			nCmd = 0;
		else if(gDProject.m_nSeparation == USE_1ST)
			nCmd = 1;
		else
			nCmd = 2;
	}

	BOOL bRes = FALSE;
	BOOL bTable1 = pMotor->IsTable1PCBExist();
	BOOL bTable2 = pMotor->IsTable2PCBExist();
	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	int nSuction1 = pMotor->GetCurrentSuction();
//	int nSuction2 = pMotor->GetCurrentSuction(FALSE);
	
	BOOL b1st = FALSE, b2nd = FALSE;
	if((nSuction1 & 0x01) && bMotor) b1st = TRUE;
	if((nSuction1 & 0x02) && bMotor) b2nd = TRUE;
	
	switch(nCmd)
	{
	case 0:
		if(!bTable1 && !bTable2 && !b1st && !b2nd)
			bRes = TRUE;
		else
			bRes = FALSE;
		break;
	case 1:
		if(!bTable1 && !b1st)
			bRes = TRUE;
		else
			bRes = FALSE;
		break;
	case 2:
		if(!bTable2 && !b2nd)
			bRes = TRUE;
		else
			bRes = FALSE;
		break;
	}

	if(!bRes)
	{
		ErrMessage(_T("There is PCB on Table.\r\nLoading Command Reject."));
		EnableControl(TRUE); //20130412 jghan
		return;
	}

#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, nCmd);
#endif
	
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(!pMotor->SetLoadPickerDownOK(FALSE, FALSE))
	{
		ErrMsgDlg(STDGNALM719); //���
		EnableControl(TRUE);
		pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
		return;
	}
	pMotor->HandlerOperation(HANDLER_LOADER_LOAD, TRUE);
	if(!pMotor->GetReverseDirection())
	{
		pMotor->MoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX,gProcessINI.m_sProcessAutoSetting.dLoadPosY );
	}
	else
	{
		pMotor->MoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX2, gProcessINI.m_sProcessAutoSetting.dLoadPosY2 );
	}

	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		EnableControl(TRUE);
		pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
		return;
	}
	BOOL bPicker1, bPicker2;
	if(nCmd == 0 )
	{
		bPicker1 = TRUE;
		bPicker2 = TRUE;
	}
	else if( nCmd == 1)
	{
		bPicker1 = TRUE;
		bPicker2 = FALSE;
	}
	else
	{
		bPicker1 = FALSE;
		bPicker2 = TRUE;
	}
	if(!pMotor->SetLoadPickerDownOK(bPicker1, bPicker2))
	{
		pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
		ErrMsgDlg(STDGNALM719); //���
		EnableControl(TRUE);
		return;
	}
	::Sleep(500);
	if(!WaitHandler(HANDLER_LOAD_PICKER_DOWN, bPicker1,bPicker2 ))
	{
		pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
		ErrMsgDlg(STDGNALM719); //���
		EnableControl(TRUE);
		return;
	}
	if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
	{
		pMotor->SetOutPort(PORT_TABLE_SUCTION1, bPicker1);
		pMotor->SetOutPort(PORT_TABLE_SUCTION2, bPicker2);
	}
	if(!pMotor->SetTablePCBExist(bPicker1, bPicker2))
	{
		pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
		ErrMsgDlg(STDGNALM993);
		EnableControl(TRUE);
		return ;
	}
#else
	pMotor->HandlerOperation(HANDLER_LOADER_LOAD, TRUE);
#endif
	::Sleep(500);

	if(!WaitHandler(HANDLER_LOADSTOP))
	{
		::ErrMsgDlg(STDGNALM719); //�ð� �ʰ�
	}
	if(m_bDrillRun)
		return;
#ifdef __KUNSAN_SAMSUNG_LARGE__
	pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
#endif
	EnableControl(TRUE);

#ifndef __NO_USE_OPC__
	BOOL bSuction1 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x01;
	BOOL bSuction2 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x02;
	//change status 
	CString strOPCTag;
	int nIndex;
	if(bSuction1)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 111; // S_001_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	if(bSuction2)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 112; // S_002_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
	
#endif
}

void CPaneAutoRunViewData::OnButtonUnloading() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(m_bDrillRun)
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}

	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); 
		return;
	}
	
	if(gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		ErrMessage(IDS_NO_USE_HANDLER);
		return;
	}
	else
	{
		if(!pMotor->IsStartMode())
		{
			ErrMsgDlg(STDGNALM1152);
			return;
		}
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}
#ifndef __TEST__
	if(pMotor->IsHandlerOperation( HANDLER_LOADER_LOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("Loading is in progress.\r\nUnload Command Reject."));
		return;
	}

	if(pMotor->IsHandlerOperation( HANDLER_UNLOADER_UNLOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("Unloading is in progress.\r\nUnload Command Reject."));
		return;
	}
#endif
#ifdef __KUNSAN_SAMSUNG_LARGE__
	pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
#endif
	UpdateData(TRUE);

	int nCmd;
/*	if( (gDProject.m_nSeparation == USE_DUAL && (!pMotor->IsUnloaderPicker1PCBExist() || !pMotor->IsUnloaderPicker2PCBExist())) ||
		(gDProject.m_nSeparation == USE_1ST && !pMotor->IsUnloaderPicker1PCBExist()) ||
		(gDProject.m_nSeparation == USE_2ND && !pMotor->IsUnloaderPicker2PCBExist()))
	{
		if(gDProject.m_nSeparation == USE_DUAL)
			nCmd = 0;
		else if(gDProject.m_nSeparation == USE_1ST)
			nCmd = 1;
		else
			nCmd = 2;
	}
	else
	{
		ErrMsgDlg(STDGNALM1026);
		EnableControl(TRUE); //20130412 jghan
		return;
	}*/

	if( gDProject.m_nSeparation == USE_DUAL ||
		gDProject.m_nSeparation == USE_1ST ||
		gDProject.m_nSeparation == USE_2ND )
	{
		if(gDProject.m_nSeparation == USE_DUAL)
			nCmd = 0;
		else if(gDProject.m_nSeparation == USE_1ST)
			nCmd = 1;
		else
			nCmd = 2;
	}

#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, nCmd);
#endif
	EnableControl(FALSE); //20130412 jghan
	
#ifdef __KUNSAN_SAMSUNG_LARGE__
	CDlgNGInfo dlg;
	
	dlg.SetFiredNGInfo(m_nNGBoxCondition);
	if(dlg.DoModal() == IDCANCEL )
	{
		EnableControl(TRUE);
		return;
	}
	int nVal = dlg.GetUseSetNGInfo();

	pMotor->SetNGPanel(nVal);

	CString strTitle, strMessage;
	strMessage.Format(_T("Fired NG Info : %d | Uset Set NG Info : %d\n"), m_nNGBoxCondition, nVal);
	strTitle.Format(_T("Manual Unloading NG Info"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strTitle), reinterpret_cast<WPARAM>(&strMessage));
	
	if(!pMotor->SetUnloadPickerDownOK(FALSE, FALSE))
	{
		ErrMsgDlg(STDGNALM719); //���
		EnableControl(TRUE);
		return;
	}
	pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, TRUE);
	if(!pMotor->GetReverseDirection())
	{
		if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dUnloadPosX, gProcessINI.m_sProcessAutoSetting.dUnloadPosY, TRUE))
		{
			ErrMsgDlg(STDGNALM438);
			EnableControl(TRUE);
			pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
			return;
		}
	}
	else
	{
		if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dUnloadPosX2, gProcessINI.m_sProcessAutoSetting.dUnloadPosY2, TRUE))
		{
			ErrMsgDlg(STDGNALM438);
			EnableControl(TRUE);
			pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
			return;
		}
	}


	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		EnableControl(TRUE);
		pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
		return;
	}

	BOOL bPicker1, bPicker2;
	if(nCmd == 0 )
	{
		bPicker1 = TRUE;
		bPicker2 = TRUE;
	}
	else if( nCmd == 1)
	{
		bPicker1 = TRUE;
		bPicker2 = FALSE;
	}
	else
	{
		bPicker1 = FALSE;
		bPicker2 = TRUE;
	}
	if(!pMotor->SetUnloadPickerDownOK(bPicker1, bPicker2))
	{
		ErrMsgDlg(STDGNALM726);
		EnableControl(TRUE);
		pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
		return;
	}
	::Sleep(500);
	if(!WaitHandler(HANDLER_UNLOAD_PICKER_DOWN, bPicker1, bPicker2))
	{
		ErrMsgDlg(STDGNALM726);
		EnableControl(TRUE);
		pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
		return;
	}
	if(!WaitHandler(HANDLER_UNLOAD_PICKER_DOWN, bPicker1, bPicker2))
	{
		ErrMsgDlg(STDGNALM726);
		EnableControl(TRUE);
		pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
		return;
	}
	if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
	{
		pMotor->SetOutPort(PORT_TABLE_SUCTION1, FALSE);
		pMotor->SetOutPort(PORT_TABLE_SUCTION2, FALSE);
	}
#else
	pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, TRUE);
#endif
	::Sleep(500);


	if(!WaitHandler(HANDLER_UNLOADSTOP))
	{
		ErrMsgDlg(STDGNALM726);
		EnableControl(TRUE); //20130412 jghan
		return;
	}
	if(m_bDrillRun)
		return;
	if(!pMotor->SetTablePCBExist(FALSE, FALSE))
	{
		ErrMsgDlg(STDGNALM993);
		pMotor->SetOutPort(PORT_ALARM, 1);
		Sleep(100);
		pMotor->SetOutPort(PORT_ALARM, 0);
	}

	BOOL bNeedUnload = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->GetNeedUnload();
	if(bNeedUnload)
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->SetNeedUnload(FALSE);
#ifdef __KUNSAN_SAMSUNG_LARGE__
	pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
#endif
	EnableControl(TRUE); //20130412 jghan
	
#ifndef __NO_USE_OPC__
	BOOL bSuction1 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x01;
	BOOL bSuction2 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x02;
	//change status 
	CString strOPCTag;
	int nIndex;
	if(bSuction1)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 111; // S_001_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	if(bSuction2)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 112; // S_002_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
	
#endif
}

void CPaneAutoRunViewData::OnButtonChangeBoard1() 
{
	if(m_bDrillRun)
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); 
		return;
	}
	
	if(gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		ErrMessage(IDS_NO_USE_HANDLER);
		return;
	}
	else
	{
		if(!pMotor->IsStartMode())
		{
			ErrMsgDlg(STDGNALM1152);
			return;
		}
	}

	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return;
	}
	
	if(pMotor->IsHandlerOperation( HANDLER_LOADER_ALIGN, FALSE, FALSE ))
	{
		ErrMessage(_T("Loading is in progress.\r\nUnload Command Reject."));
		return;
	}
#ifdef __KUNSAN_SAMSUNG_LARGE__
	pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, FALSE);
#endif
	UpdateData(TRUE);
	EnableControl(FALSE);
	int nCmd;
		
	if(gDProject.m_nSeparation == USE_DUAL)
		nCmd = 0;
	else if(gDProject.m_nSeparation == USE_1ST)
		nCmd = 1;
	else
		nCmd = 2;



#ifdef __PUSAN_LDD__
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, nCmd);
#else
	pMotor->SetOutPort(PORT_PCB_SINGLE, nCmd);
#endif

	pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, TRUE);

	::Sleep(500);

	if(!WaitHandler(HANDLER_ALIGNERSTOP))
	{
		if(pMotor->IsLoadCartNoPCB())
			ErrMsgDlg(STDGNALM715);
		else
			ErrMsgDlg(STDGNALM721);
	}
	if(m_bDrillRun)
		return;
#ifdef __KUNSAN_SAMSUNG_LARGE__
	pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, FALSE);
#endif
	EnableControl(TRUE);
}

BOOL CPaneAutoRunViewData::GetAutoRun()
{
	BOOL bAutoRun;
	bAutoRun = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->GetAutoRun();

	return bAutoRun;
}
BOOL CPaneAutoRunViewData::WaitHandler(int nCmd, BOOL b1st, BOOL b2nd)
{
	
#ifdef __TEST__
	int nWaitTime2 = gProcessINI.m_sProcessOption.nLoadTime * 1000 / 50; 
	int nCnt2 = 0;
	do {
		::Sleep(50);
		MessageLoop();
			nCnt2++;
		
		if( m_bDrillRun )
			return TRUE;

		if(nCnt2 > nWaitTime2)
		{
			return FALSE;
		}
	} while(TRUE);

	return TRUE;
#endif
	
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	int nGetTargetVal = 0;
	if(b1st) nGetTargetVal += 0x01;
	if(b2nd) nGetTargetVal += 0x02;
	BOOL bReverse = gDeviceFactory.GetMotor()->GetReverseDirection();
	
	int nWaitTime;
	if(nCmd == HANDLER_ALIGNERSTOP)
		nWaitTime = gProcessINI.m_sProcessOption.nAlignTime * 1000 / 50; 
	else if(nCmd == HANDLER_LOADSTOP || nCmd == HANDLER_LOAD_PICKER_DOWN)
		nWaitTime = gProcessINI.m_sProcessOption.nLoadTime * 1000 / 50; 
	else
		nWaitTime = gProcessINI.m_sProcessOption.nUnloadTime * 1000 / 50; 

	int nCnt = 0;
	LONG lError = 0;
	do {
		::Sleep(50);
		MessageLoop();
		
		enum { HANDLER_READY, HANDLER_ALARM, HANDLER_LOTEND, HANDLER_1STEXIST, HANDLER_2NDEXIST, 
			HANDLER_LOADREADY, HANDLER_LOADEND, HANDLER_LOADALARM, HANDLER_UNLOADREADY, HANDLER_UNLOADEND, HANDLER_UNLOADALARM,
			HANDLER_ALIGNERSTOP, HANDLER_LOADSTOP, HANDLER_UNLOADSTOP, HANDLER_UNLOAD_TO_LOADSTART};		
		
		switch(nCmd)
		{
		case HANDLER_ALIGNERSTOP:
			if(pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, TRUE, FALSE) &&
				!pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, FALSE, FALSE))
				return TRUE;
			
			// AlignEnd��ٸ��� �� ���Ǻ������� PLC���� ���� ������ Waiting�ߴ�
			lError = pMotor->GetCurrentError(ERROR_OTHERS2);
			if(lError & 0x8000)
				return FALSE;
			
#ifdef __KUNSAN_SAMSUNG_LARGE__
			if(!bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}
#else
			if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;

#endif
			break;
		case HANDLER_LOADSTOP:
			if(pMotor->IsHandlerOperation(HANDLER_LOADER_LOAD, TRUE, FALSE) &&
				!pMotor->IsHandlerOperation(HANDLER_LOADER_LOAD, FALSE, FALSE))
				return TRUE;
			
#ifdef __KUNSAN_SAMSUNG_LARGE__
			if(!bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}
#else
			if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;

#endif
			
			break;
		case HANDLER_UNLOADSTOP:
			if(pMotor->IsHandlerOperation(HANDLER_UNLOADER_UNLOAD, TRUE, FALSE) &&
				!pMotor->IsHandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE, FALSE))
				return TRUE;
			
#ifdef __KUNSAN_SAMSUNG_LARGE__
			if(bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}
#else
			if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;

#endif
			
			break;
		case HANDLER_UNLOAD_TO_LOADSTART:
			if(pMotor->IsHandlerOperation(HANDLER_UNLOADER_TO_LOAD_START, TRUE))
				return TRUE;
			
#ifdef __KUNSAN_SAMSUNG_LARGE__
			if(bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}
#else
			if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;

#endif
			break;
		case HANDLER_LOAD_PICKER_DOWN:
			if(nGetTargetVal == pMotor->IsHandlerOperation(HANDLER_LOAD_PICKER_DOWN, TRUE))
				return TRUE;

#ifdef __KUNSAN_SAMSUNG_LARGE__
			if(!bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}
#else
			if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;

#endif
			break;
		case HANDLER_UNLOAD_PICKER_DOWN:
			if(nGetTargetVal == pMotor->IsHandlerOperation(HANDLER_UNLOAD_PICKER_DOWN, TRUE))
				return TRUE;

#ifdef __KUNSAN_SAMSUNG_LARGE__
			if(bReverse)
			{
				if(pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}
#else
			if(pMotor->IsHandlerPartError(FALSE))
				return FALSE;

#endif
			break;
		}
		nCnt++;
		
		if( pMotor->IsAnyError() )
		{
			return FALSE;
		}
		
		if( m_bDrillRun )
			return TRUE;

		if(nCnt > nWaitTime)
		{
			return FALSE;
		}
	} while(TRUE);
	return FALSE;
}

void CPaneAutoRunViewData::MessageLoop()
{
	MSG msg;
	
	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
	}
}

void CPaneAutoRunViewData::SetDrill(BOOL Drill)
{
	m_bDrillRun = Drill;
	EnableControl(!Drill);
}

void CPaneAutoRunViewData::EnableControl(BOOL bUse)
{
	m_btnUnloading.EnableWindow(bUse);
	m_btnLoading.EnableWindow(bUse);
	m_btnChangeBoard.EnableWindow(bUse);
	m_btnUnloadPos.EnableWindow(bUse);
	m_btnUCCart.EnableWindow(bUse);
	m_btnLoadPos.EnableWindow(bUse);
	if(m_bDrillRun)
	{
		//	m_btnUCTable.EnableWindow(bUse);
		//	m_btnLCTable.EnableWindow(bUse);
	}
	else
	{
		m_btnUCTable.EnableWindow(bUse);
		m_btnLCTable.EnableWindow(bUse);
	}

	m_btnLCCart.EnableWindow(bUse);
	m_btnAllReject.EnableWindow(bUse);
//	m_btnVacuumViewer.EnableWindow(bUse);
	
	m_ledTableSuction.EnableWindow(bUse);
	m_ledTableSuction2.EnableWindow(bUse);
	m_ledClamp.EnableWindow(bUse);
	m_ledClamp2.EnableWindow(bUse);
	m_ledVacuumMotor.EnableWindow(bUse);
}

void CPaneAutoRunViewData::OnCheckTableSuction() 
{
	if(m_bDrillRun)
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	int nSuction = pMotor->GetCurrentSuction();
	
	if(nSuction & 0x01)
	{
		pMotor->WriteOutputIOBIt(2, 1, TRUE);
		pMotor->WriteOutputIOBIt(2, 0, FALSE);
#ifdef __CUNGJU__
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ACRYL_TABLE_SUCTION, FALSE);
#endif
#ifdef __CUNGJU_JASMINE_OLD__
		if(nSuction & 0x02)
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 2, TRUE);
		else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 0, TRUE);
#endif
#ifdef __PUSAN_LDD__
		if(nSuction & 0x02)
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 2, TRUE);
		else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 0, TRUE);
#endif
	}
	else
	{
		pMotor->WriteOutputIOBIt(2, 0, TRUE);
		pMotor->WriteOutputIOBIt(2, 1, FALSE);
#ifdef __CUNGJU__
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ACRYL_TABLE_SUCTION, TRUE);
#endif

#ifdef __CUNGJU_JASMINE_OLD__
	if(nSuction == 1)
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 1, TRUE);
	else if(nSuction == 5)
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 0, TRUE);
	else if(nSuction == 11)
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 3, TRUE);
	else if(nSuction == 15)
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 2, TRUE);
#endif
#ifdef __PUSAN_LDD__
	if(nSuction == 0)
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 1, TRUE);
	else if(nSuction & 0x02)
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 3, TRUE);
#endif
	}

	
#ifndef __NO_USE_OPC__
	BOOL bSuction1 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x01;
	BOOL bSuction2 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x02;
	//change status 
	CString strOPCTag;
	int nIndex;
	if(bSuction1)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 111; // S_001_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	if(bSuction2)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 112; // S_002_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
	
#endif
}

void CPaneAutoRunViewData::OnCheckTableSuction2() 
{
	if(m_bDrillRun)
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	int nSuction = pMotor->GetCurrentSuction();
	
	if(nSuction & 0x02)
	{
		pMotor->WriteOutputIOBIt(2, 2, FALSE);
		pMotor->WriteOutputIOBIt(2, 3, TRUE);

#ifdef __CUNGJU__
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ACRYL_TABLE_SUCTION2, FALSE);
#endif

#ifdef __CUNGJU_JASMINE_OLD__
		if(nSuction & 0x01)
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 1, TRUE);
		else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 0, TRUE);
#endif

#ifdef __PUSAN_LDD__
		if(nSuction & 0x01)
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 1, TRUE);
		else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 0, TRUE);
#endif
	}
	else
	{	
		pMotor->WriteOutputIOBIt(2, 2, TRUE);
		pMotor->WriteOutputIOBIt(2, 3, FALSE);

#ifdef __CUNGJU__
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ACRYL_TABLE_SUCTION2, TRUE);
#endif

#ifdef __CUNGJU_JASMINE_OLD__
	if(nSuction == 1)
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 2, TRUE);
	else if(nSuction == 5)
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 3, TRUE);
	else if(nSuction == 11)
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 0, TRUE);
	else if(nSuction == 15)
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 1, TRUE);
#endif
#ifdef __PUSAN_LDD__
	if(nSuction == 0)
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 2, TRUE);
	else if(nSuction & 0x01)
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_TABLE_SUCTION2, 3, TRUE);

#endif
	}
	
#ifndef __NO_USE_OPC__
	BOOL bSuction1 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x01;
	BOOL bSuction2 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x02;
	//change status 
	CString strOPCTag;
	int nIndex;
	if(bSuction1)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 111; // S_001_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	if(bSuction2)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 112; // S_002_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
	
#endif
}

void CPaneAutoRunViewData::OnCheckVacuumMotor() 
{
	if(m_bDrillRun)
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	
	if(bMotor)
	{
		pMotor->Table1VacuumMotor(FALSE);
	}
	else
	{
		pMotor->Table1VacuumMotor(TRUE);
	}
	
}


void CPaneAutoRunViewData::OnCheckFluorescentLamp() 
{
	BOOL bOn = gDeviceFactory.GetMotor()->IsFluorescentLampOn();
	
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(bOn)
		pMotor->SetOutPort(PORT_LAMP, FALSE);
	else
		pMotor->SetOutPort(PORT_LAMP, TRUE);
}

void CPaneAutoRunViewData::OnCheckReverse() 
{
	if(m_bDrillRun)
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}

	

	BOOL bReverse = gDeviceFactory.GetMotor()->GetReverseDirection();
	gDeviceFactory.GetMotor()->TablePCBReset();
//	::Sleep(1000);
	if(bReverse)
	{
		gDeviceFactory.GetMotor()->SetReverseDirection(FALSE);
	}
	else
	{
		gDeviceFactory.GetMotor()->SetReverseDirection(TRUE);
	}
}

void CPaneAutoRunViewData::OnButtonAllReject() 
{
	if(m_bDrillRun)
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
	// TODO: Add your control notification handler code here
	// 110610
	EnableControl(FALSE);
#ifndef __MP920_MOTOR__
	gDeviceFactory.GetMotor()->UnLoaderPCBReset();
	gDeviceFactory.GetMotor()->LoaderPCBReset();
	::Sleep(1000);
	gDeviceFactory.GetMotor()->TablePCBReset();
	::Sleep(3000);
#endif
#ifdef __PUSAN2__
	gDeviceFactory.GetMotor()->LoaderPCBReset();
	gDeviceFactory.GetMotor()->UnLoaderPCBReset();
#endif
#ifdef __KUNSAN_SAMSUNG_LARGE__
	gDeviceFactory.GetMotor()->HandlerOperation(HANDLER_LOADER_ALIGN, FALSE);
	gDeviceFactory.GetMotor()->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
	gDeviceFactory.GetMotor()->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
#endif
	EnableControl(TRUE);
}
void CPaneAutoRunViewData::OnCheckTableClamp()
{
	if(m_bDrillRun)
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	if(m_bClamp)
		pMotor->TableClamp(FALSE, TRUE);
	else
		pMotor->TableClamp(TRUE, TRUE);
}
void CPaneAutoRunViewData::OnCheckTableClamp2()
{
	if(m_bDrillRun)
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	if(m_bClamp2)
		pMotor->TableClamp(FALSE, FALSE);
	else
		pMotor->TableClamp(TRUE, FALSE);
}

void CPaneAutoRunViewData::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetWindowRect(&rect);
	ClientToScreen(&point);
	CClientDC dc(GetDlgItem(IDC_STC_RUN_VIEW));
	
	if(rect.PtInRect(point))
	{
		tempP.x = point.x - rect.left;
		tempP.y = point.y - rect.top;
//		if(IsPickToolVisible(tempP))
//			return;

		GetDlgItem(IDC_STC_RUN_VIEW)->SetFocus();
	}
	else
		return;

	m_ptDrawStart = tempP;
	m_ptMoveStart = tempP;
	m_bDrawMoveStart = TRUE;
	
	if(!m_bViewerMoveMode)
	{
		DrawSelectionRect(&dc, m_ptDrawStart, m_ptDrawStart);
	}
	CFormView::OnLButtonDown(nFlags, point);
}

BOOL CPaneAutoRunViewData::IsPickToolVisible(CPoint ptPick)
{
	
	CRect cRect;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetClientRect(&cRect);
	
	int nYstart = 5, nEndY;
	int nStartX, nEndX;
	nStartX = cRect.right - 60;
	nEndX = cRect.right - 5;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(gDProject.m_pToolCode[i]->m_bUseTool)
		{
			nEndY = nYstart + 18;
			if(ptPick.x <= nEndX && ptPick.x >= nStartX &&
				ptPick.y <=nEndY && ptPick.y >= nYstart)
			{
				if(gDProject.m_pToolCode[i]->m_bVisible && i != 0)
				{
					gDProject.m_pToolCode[i]->m_bVisible = FALSE; // apply click ���� ����
				}
				else
				{
					gDProject.m_pToolCode[i]->m_bVisible = TRUE; // apply click ���� ����
				}
				Invalidate(FALSE);
				return TRUE;
			}
			
			nYstart += 20;
		}
	}
	
	return FALSE;
}

BOOL CPaneAutoRunViewData::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	CRect cRect;
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Drill_Data) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	if (pMsg->message == WM_KEYDOWN)
	{
		switch (pMsg->wParam)
 		{

			case 77:	// M
			case 109:	// m : mode change : select mode <-> viwer move mode
//				if(m_bDrawMoveStart || m_bUnitMoveStart) // select or move ���߿��� flag ��ȭ ���Ѵ�
//					return TRUE;

				if(m_bViewerMoveMode)
					m_bViewerMoveMode = FALSE;
				else
					m_bViewerMoveMode = TRUE;
				return TRUE;
			case 70 :	// F
			case 102 :  // f : show sort index

	/*			if((gDProject.m_nDataLoadStep & 0x0b) < FIELD_DIVIED) // FieldDivide �������� flag ��ȭ ���Ѵ� // 20091029
				{
					m_bShowSortIndex = FALSE;
					return TRUE;
				}

				if(m_bDrawMoveStart || m_bUnitMoveStart) // select or move ���߿��� flag ��ȭ ���Ѵ�
				{
					m_bShowSortIndex = FALSE;
					return TRUE;
				}
				
				if(gDProject == NULL)
				{
					m_bShowSortIndex = FALSE;
					return TRUE;
				}

				m_bShowSortIndex = !m_bShowSortIndex;
				ClearFiducialIndex();
				
				gDProject->ChangeViewIndex();

				Invalidate(FALSE);
*/
				return TRUE;

		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}

BOOL CPaneAutoRunViewData::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_bViewerMoveMode)
	{
		::SetCursor(::AfxGetApp()->LoadCursor(IDC_CURSOR_HAND_RELEASE));
		return TRUE;
	}	
	return CFormView::OnSetCursor(pWnd, nHitTest, message);
}

void CPaneAutoRunViewData::OnCancelMode() 
{
	CFormView::OnCancelMode();

	
}

BOOL CPaneAutoRunViewData::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	// TODO: Add your message handler code here and/or call default

	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetWindowRect(&rect);
	if(rect.PtInRect(pt))
	{
		tempP.x = pt.x - rect.left;
		tempP.y = pt.y - rect.top;
		if(zDelta >= WHEEL_DELTA)
			gDProject.SetDrawRect(tempP, 1, 2);
		else
			gDProject.SetDrawRect(tempP, -1, 2);
		
		Invalidate(FALSE);
	}
	return CFormView::OnMouseWheel(nFlags, zDelta, pt);
}

void CPaneAutoRunViewData::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	m_bDrawMoveStart = FALSE;
	
	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetWindowRect(&rect);
	ClientToScreen(&point);
	
	CClientDC dc(GetDlgItem(IDC_STC_RUN_VIEW));
	
	if(rect.PtInRect(point))
	{
		tempP.x = point.x - rect.left;
		tempP.y = point.y - rect.top;
		
		Invalidate(FALSE);
	}

	CFormView::OnLButtonUp(nFlags, point);
}

void CPaneAutoRunViewData::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CClientDC dc(GetDlgItem(IDC_STC_RUN_VIEW));
	
	if(m_bDrawMoveStart)
	{
		CRect rect;
		CPoint tempP, endP;
		GetDlgItem(IDC_STC_RUN_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		if(rect.PtInRect(point))
		{
			endP.x = point.x - rect.left;
			endP.y = point.y - rect.top;
			tempP.x = endP.x - m_ptMoveStart.x;
			tempP.y = endP.y - m_ptMoveStart.y;
			
			if(m_ptMoveStart != tempP)
			{
				m_ptMoveStart = endP;
				gDProject.SetDrawRect(tempP, 0, 2);
				Invalidate(FALSE);
			}
		}
	}
	CFormView::OnMouseMove(nFlags, point);
}

void CPaneAutoRunViewData::DrawSelectionRect(CDC *pDC, CPoint ptPoint1, CPoint ptPoint2)
{
	CPoint ptStart;
	CPoint ptEnd;
	
	if(ptPoint1.x < ptPoint2.x)
	{
		ptStart.x = ptPoint1.x;
		ptEnd.x = ptPoint2.x;
	}
	else
	{
		ptStart.x = ptPoint2.x;
		ptEnd.x = ptPoint1.x;
	}
	
	if(ptPoint1.y < ptPoint2.y)
	{
		ptStart.y = ptPoint1.y;
		ptEnd.y = ptPoint2.y;
	}
	else
	{
		ptStart.y = ptPoint2.y;
		ptEnd.y = ptPoint1.y;
	}
	
	CRect rectRect(ptStart, ptEnd);
	
	m_ptDrawRectBack1 = ptStart;
	m_ptDrawRectBack2 = ptEnd;
	
	int iRopOld = pDC->SetROP2(R2_NOT);
	CBrush *pBrushOld = (CBrush *)pDC->SelectStockObject(NULL_BRUSH);
	
	pDC->Rectangle(rectRect);
	
	pDC->SetROP2(iRopOld);
	pDC->SelectObject(pBrushOld);
}

void CPaneAutoRunViewData::InitialDrawRatio()
{
	CRect cRect;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetClientRect(&cRect);
	gDProject.InitialDrawRatio(cRect, 2);
}

void CPaneAutoRunViewData::OnCheckDummyFree() 
{
	// TODO: Add your control notification handler code here
	if(m_bDrillRun)
		return;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	if(!gDeviceFactory.GetLaser()->IsPowerOn() || !gDeviceFactory.GetLaser()->IsShutterOpen() || !pMotor->GetAOMStatus())
	{
		ErrMessage(_T("Laser is off."));
		return;
	}
	
	
	if(gDeviceFactory.GetEocard()->IsStannbyShotRun())
	{
		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE, TRUE))
		{
			ErrMsgDlg(STDGNALM781);
			return;
		}
	}
	else
	{
		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE, TRUE))
		{
			ErrMsgDlg(STDGNALM781);
			return;
		}
	}
}


void CPaneAutoRunViewData::CheckInpositionError(int nAxis, BOOL bShow)
{
	switch(nAxis)
	{
	case IND_X : ErrMsgDlg(STDGNALM404); break;
	case IND_Y : ErrMsgDlg(STDGNALM405); break;
	case IND_Z1 : ErrMsgDlg(STDGNALM406); break;
	case IND_Z2 : ErrMsgDlg(STDGNALM407); break;
	case IND_M1 : ErrMsgDlg(STDGNALM408); break;
	case IND_M2 : ErrMsgDlg(STDGNALM409); break;
	case IND_M3 : ErrMsgDlg(STDGNALM990); break;
	case IND_C1 : ErrMsgDlg(STDGNALM410); break;
	case IND_C2 : ErrMsgDlg(STDGNALM411); break;
	}
}
void CPaneAutoRunViewData::SetFiredNGInfo(int nNG)
{
	m_nNGBoxCondition = nNG;
}

void CPaneAutoRunViewData::OnBnClickedJobMode()
{
	DlgJobMode	dlg;
	int nNewMode = 0;
	dlg.SetMode(gVariable.m_nJobMode);
	 
	int nResponse = dlg.DoModal();

	if (nResponse == IDOK)
	{
		nNewMode = dlg.GetMode();
		if(nNewMode == 0)
			m_stcJobMode.SetWindowText(_T("Job End"));
		else if(nNewMode == 1)
			m_stcJobMode.SetWindowText(_T("PM Job"));
		else if(nNewMode == 2)
			m_stcJobMode.SetWindowText(_T("PNL Check"));
		else if(nNewMode == 3)
			m_stcJobMode.SetWindowText(_T("Test"));
		else if(nNewMode == 4)
			m_stcJobMode.SetWindowText(_T("Failure"));
		else
			m_stcJobMode.SetWindowText(_T("Other"));

		if(gVariable.m_nJobMode != nNewMode)
		{
			gVariable.m_nJobMode = nNewMode;
		}
	}
}
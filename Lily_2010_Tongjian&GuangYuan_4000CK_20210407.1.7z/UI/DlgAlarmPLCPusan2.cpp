// DlgAlarmPLCPusan2.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgAlarmPLCPusan2.h"
#include "..\device\hdevicefactory.h"
#include "..\device\devicemotor.h"
#include "..\device\HMotor.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgAlarmPLCPusan1 dialog


CDlgAlarmPLCPusan2::CDlgAlarmPLCPusan2(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgAlarmPLCPusan2::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgAlarmPLCPusan2)
		// NOTE: the ClassWizard will add member initialization here
	m_bOnTimer = FALSE;
	m_nMsg = 0;
	m_nTimerID = 0;
	m_nMaxError = 30;
	//}}AFX_DATA_INIT
}


void CDlgAlarmPLCPusan2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgAlarmPLCPusan2)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_LIST_ALARM, m_ctrlListMsg);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgAlarmPLCPusan2, CDialog)
	//{{AFX_MSG_MAP(CDlgAlarmPLCPusan2)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgAlarmPLCPusan1 message handlers


BOOL CDlgAlarmPLCPusan2::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	for(int i=0; i<m_nMaxError; i++)
		m_strMsg[i] = _T("");
//		m_strMsg[i].Format(_T(""));
	
	m_ctrlListMsg.SetExtendedStyle(m_ctrlListMsg.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY | LVS_EX_GRIDLINES);
	InitListCtrl();
	m_lErrorNew = m_lErrorOld = 0;
	m_nTimerID = SetTimer(1212, 500, NULL);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgAlarmPLCPusan2::InitListCtrl()
{
	m_ctrlListMsg.DeleteAllItems();
	
	m_ctrlListMsg.DeleteColumn(0);
	
	TCHAR* ColumnHeadText = _T("Message");
	
	int ColumnHeadSize = 422;
	
	//  List control�� Column ����
	m_ctrlListMsg.InsertColumn(0, _T(""), LVCFMT_CENTER, 1);
	LV_COLUMN lvcolumn;

	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_CENTER;
	lvcolumn.pszText = ColumnHeadText;
	lvcolumn.iSubItem = 0;
	lvcolumn.cx = ColumnHeadSize;
	m_ctrlListMsg.InsertColumn(1, &lvcolumn);

	AddItems();
}

void CDlgAlarmPLCPusan2::AddItems()
{
	m_ctrlListMsg.DeleteAllItems();
	
	for(int i=0; i<m_nMaxError; i++)
	{
		m_ctrlListMsg.InsertItem(i, _T(""));

//		m_strMsg[i].Format(_T("msg #%d"), i+1);

		_stprintf_s(m_szText, "%s", m_strMsg[i]);
		m_ctrlListMsg.SetItemText(i, 1, m_szText);
	}
}

void CDlgAlarmPLCPusan2::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_bOnTimer == TRUE)
	{
		CDialog::OnTimer(nIDEvent);
		return;
	}
	m_bOnTimer = TRUE;

	UpdateMsg();
	
	m_bOnTimer = FALSE;
	CDialog::OnTimer(nIDEvent);
}

void CDlgAlarmPLCPusan2::UpdateMsg()
{
	m_nMsg = 0;

	BOOL bChange = FALSE;

//	for(int j=0; j<m_nMaxError; j++)
//		m_strMsg[j] = _T("");

	m_lErrorIoNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_IO);
	if (m_lErrorIoNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorIoNew;
		GetIoErrorMsg();
	}
	
#ifndef __ADD_MELSEC_MOTOR__
	m_lErrorLoadNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_LOAD);
	if (m_lErrorLoadNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorLoadNew;
		if(m_nMsg < m_nMaxError)
			GetLoadErrorMsg();
	}
	
	m_lErrorLoad2New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_LOAD2);
	if (m_lErrorLoad2New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorLoad2New;
		if(m_nMsg < m_nMaxError)
			GetLoad2ErrorMsg();
	}

	m_lErrorLoad3New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_LOAD3);
	if (m_lErrorLoad3New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorLoad3New;
		if(m_nMsg < m_nMaxError)
			GetLoad3ErrorMsg();
	}
	
	m_lErrorUnloadNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_UNLOAD);
	if (m_lErrorUnloadNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorUnloadNew;
		if(m_nMsg < m_nMaxError)
			GetUnloadErrorMsg();
	}

	m_lErrorUnload2New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_UNLOAD2);
	if (m_lErrorUnload2New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorUnload2New;
		if(m_nMsg < m_nMaxError)
			GetUnload2ErrorMsg();
	}

	m_lErrorUnload3New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_UNLOAD3);
	if (m_lErrorUnload3New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorUnload3New;
		if(m_nMsg < m_nMaxError)
			GetUnload3ErrorMsg();
	}
#endif
	
	m_lErrorTableLimitNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_TABLELIMIT);
	if (m_lErrorTableLimitNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorTableLimitNew;
		if(m_nMsg < m_nMaxError)
			GetTableLimitErrorMsg();
	}
	
	m_lErrorOtherLimitNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERLIMIT);
	if (m_lErrorOtherLimitNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorOtherLimitNew;
		if(m_nMsg < m_nMaxError)
			GetOtherLimitErrorMsg();
	}
	
	m_lErrorLaserNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_LASER);
	if (m_lErrorLaserNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorLaserNew;
		if(m_nMsg < m_nMaxError)
			GetLaserErrorMsg();
	}

	m_lErrorOthersNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS);
	if (m_lErrorOthersNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorOthersNew;
		if(m_nMsg < m_nMaxError)
			GetOthersErrorMsg();
	}

	m_lErrorOthers2New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS2);
	if (m_lErrorOthers2New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorOthers2New;
		if(m_nMsg < m_nMaxError)
			GetOthers2ErrorMsg();
	}

	m_lErrorOthers3New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS3);
	if (m_lErrorOthers3New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorOthers3New;
		if(m_nMsg < m_nMaxError)
			GetOthers3ErrorMsg();
	}

	m_lErrorOthers4New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS4);
	if (m_lErrorOthers4New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorOthers4New;
		if(m_nMsg < m_nMaxError)
			GetOthers4ErrorMsg();
	}
	
	m_lErrorOthers5New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS5);
	if (m_lErrorOthers5New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorOthers5New;
		if(m_nMsg < m_nMaxError)
			GetOthers5ErrorMsg();
	}

/*	m_lErrorOthers6New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS6);
	if (m_lErrorOthers6New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorOthers6New;
		if(m_nMsg < m_nMaxError)
			GetOthers6ErrorMsg();
	}
*/
	m_lErrorTableNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_TABLE);
	if (m_lErrorTableNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorTableNew;
		if(m_nMsg < m_nMaxError)
			GetTableErrorMsg();
	}
	
	m_lErrorMelsecMainNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_HANDLER_MAIN);
	if (m_lErrorMelsecMainNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorMelsecMainNew;
		if(m_nMsg < m_nMaxError)
			GetMelsecMainErrorMsg();
	}

	m_lErrorMelsecLoaderNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_HANDLER_LOADER);
	if (m_lErrorMelsecLoaderNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorMelsecLoaderNew;
		if(m_nMsg < m_nMaxError)
			GetMelsecLoaderErrorMsg();
	}

	m_lErrorMelsecUnloaderNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_HANDLER_UNLOADER);
	if (m_lErrorMelsecUnloaderNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorMelsecUnloaderNew;
		if(m_nMsg < m_nMaxError)
			GetMelsecUnloaderErrorMsg();
	}

	m_lErrorMelsecEtc1New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_HANDLER_ETC1);
	if (m_lErrorMelsecEtc1New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorMelsecEtc1New;
		if(m_nMsg < m_nMaxError)
			GetMelsecEtc1ErrorMsg();
	}

	m_lErrorMelsecEtc2New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_HANDLER_ETC2);
	if (m_lErrorMelsecEtc2New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorMelsecEtc2New;
		if(m_nMsg < m_nMaxError)
			GetMelsecEtc2ErrorMsg();
	}
	
	if(m_nMsg < 1 && !bChange && m_lErrorNew == m_lErrorOld) 
		return;
	
	m_lErrorOld = m_lErrorNew;
	m_lErrorNew = 0;
	
	for(int i=0; i<m_nMaxError; i++)
	{
		lstrcpy(m_szText, (LPCTSTR)m_strMsg[i]);
		m_ctrlListMsg.SetItemText(i, 1, m_szText);
	}
}

void CDlgAlarmPLCPusan2::GetIoErrorMsg()
{
	if(m_lErrorIoNew & 0x0001) // em stop
	{	
		m_strMsg[m_nMsg++] = "[MB6100] EM Stop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0002) // servo power off
	{
		m_strMsg[m_nMsg++] = "[MB6101] ServoPower Off";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0004) // main station initial error
	{
		m_strMsg[m_nMsg++] = "[MB6102] Main InitErr";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0010) // Front Door Open
	{
		m_strMsg[m_nMsg++] = "[MB6104] FrontDoor Open";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0020) // Rear Door Open
	{
		m_strMsg[m_nMsg++] = "[MB6105] RearDoor Open";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0040) // LaserPower Off
	{
		m_strMsg[m_nMsg++] = "[MB6107] LaserPower Off";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0080) // MainAir Error
	{
		m_strMsg[m_nMsg++] = "[MB6108] MainAir Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0100) // HeightSensor Up Error
	{
		m_strMsg[m_nMsg++] = "[MB6132] HeightSensor UpErr";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0200) // HeightSensor Down Error
	{
		m_strMsg[m_nMsg++] = "[MB6133] HeightSensor DownErr";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0400) // LoaderDoor Open
	{
		m_strMsg[m_nMsg++] = "[MB6207] LoaderDoor Open";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0800) // UnloaderDoor Open
	{
		m_strMsg[m_nMsg++] = "[MB6307] UnloaderDoor Open";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x1000) // Shutter1 open error
	{
		m_strMsg[m_nMsg++] = "[MB6128] 1stShutter OpenErr";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x2000) // Shutter1 close error
	{
		m_strMsg[m_nMsg++] = "[MB6129] 1stShutter CloseErr";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x4000) // Shutter2 open error
	{
		m_strMsg[m_nMsg++] = "[MB6130] 2ndShutter OpenErr";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x8000) // Shutter2 close error
	{
		m_strMsg[m_nMsg++] = "[MB6131] 2ndShutter CloseErr";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetLoadErrorMsg()
{
	if (m_lErrorLoadNew & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6263] Loader Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if (m_lErrorLoadNew & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6262] Loader Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[5210] LoadCart No PCB";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6201] L-Picker1 PCB Exist";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6202] L-Picker1 PCB NonExist";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6203] L-Picker2 PCB Exist";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6204]L-Picker2 PCB NonExist";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6200] Loader Init Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6206] L-AlignTable PCB NonExist";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6205] L-AlignTable PCB Exist";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6216] L-Picker1 Pad1 Up Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6217] L-Picker1 Pad1 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6218] L-Picker1 Pad1 Down2 Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	/*if(m_lErrorLoadNew & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6219] L-Picker1 Pad2 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	*/if(m_lErrorLoadNew & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6220] L-Picker1 Vacuum On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6221] L-Picker1 Vacuum Off Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetLoad2ErrorMsg()
{
	if(m_lErrorLoad2New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6222] L-Picker1 Blow On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6223] L-Picker2 Pad1 Up Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6224] L-Picker2 Pad1 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6225] L-Picker2 Pad1 Down2 Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6226] L-Picker2 Pad2 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6227] L-Picker2 Vacuum On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6228] L-Picker2 Vacuum Off Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6229] L-Picker2 Blow On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6232] L-Cart Clamp Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6233] L-Cart Unclamp Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6234] L-AlignSheetTable Forward Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6235] L-AlignSheetTable Backward Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6236] L-AlignGuide Forward Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6237] L-AlignGuide Backward Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6238] L-AlignTable Left Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6239] L-AlignTable Right Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetLoad3ErrorMsg()
{
	if(m_lErrorLoad3New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6240] L-Elevator LoadPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6241] L-Elevator OriginPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6242] L-Elevator Sensor Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6245] LC CartPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6246] LC LoadPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6247] LC Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6248] LC Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6249] LC FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6250] LC OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6253] LC Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6208] L-Picker1 PCB Ready Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6209] L-Picker2 PCB Ready Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6243] Loader Cart Detect Sensor Err";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorLoad3New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6244] Loader Elv. Axis Limit Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6254] Loader No PCB Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6256] Loader Carrier Axis Stop Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x10000)
	{
		m_strMsg[m_nMsg++] = "[MB6215] Loader Picker Danger Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x20000)
	{
		m_strMsg[m_nMsg++] = "[MB6257] Loader Left Picker Fall PCB Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x40000)
	{
		m_strMsg[m_nMsg++] = "[MB6254] LC Align Pos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorLoad3New & 0x80000)
	{
		m_strMsg[m_nMsg++] = "[MB6211] Loader Process Time Over Error ";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetUnloadErrorMsg()
{
	if(m_lErrorUnloadNew & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6363] Unloader Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6362] Unloader Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6305] U-Table PCB Exist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6306] U-Table PCB NonExist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6302] U-Picker1 PCB NonExist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6301] U-Picker1 PCB Exist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6304] U-Picker2 PCB NonExist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6303] U-Picker2 PCB Exist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6316] U-Picker1 Pad1 Up Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6317] U-Picker1 Pad1 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6318]U-Picker1 Pad1 Down2 Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6319] U-Picker1 Pad2 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6320] U-Picker1 Vacuum On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6321] U-Picker1 Vacuum Off Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6322] U-Picker1 Blow On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6323] U-Picker2 Pad1 Up Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetUnload2ErrorMsg()
{
	if(m_lErrorUnload2New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6325] U-Picker2 Pad1 Down2 Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
/*	if(m_lErrorUnload2New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6325] U-Picker2 Pad2 Up Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6326] U-Picker2 Pad2 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
*/	if(m_lErrorUnload2New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6327] U-Picker2 Vacuum On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6328] U-Picker2 Vacuum Off Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
/*	if(m_lErrorUnload2New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6329]U-Picker2 Blow On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
*/	if(m_lErrorUnload2New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6332] U-Cart Clamp Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6333] U-Cart Unclamp Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6338] U-AlignTable Left Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6339] U-AlignTable Right Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6340] U-Elevator LoadPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6341] U-Elevator OriginPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6342] U-Elevator Sensor Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6345] UC UnloadPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6346] UC CartPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6347] UC Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x10000)
	{
		m_strMsg[m_nMsg++] = "[MB6354] UC Align Pos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetUnload3ErrorMsg()
{
	if(m_lErrorUnload3New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6348] UC Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6349] UC FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6350] UC OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6353] UC Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6308] U-Picker1 PCB Ready Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6309] U-Picker2 PCB Ready Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6300] Unloader Init Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6343] Unloader Cart Detect Sensor Err";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorUnload3New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6344] Unloader Elv. Axis Limit Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6315] Unloader Picker Danger Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB5310] Unloader Cart PCB Full";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6356] Unloader Carrier Axis Stop Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6336] Unloader NG Box Forward Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6337] Unloader NG Box Backward Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetTableLimitErrorMsg()
{
	if(m_lErrorTableLimitNew & 0x0001) // X+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6003] X (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0002) // X- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6004] X (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0004) // Y+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6011] Y (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0008) // Y- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6012] Y (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0040) // Z1+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6019] Z1 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0080) // Z1- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6020] Z1 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0100) // Z2+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6027] Z2 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0200) // Z2- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6028] Z2 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0400) // A1+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6258] A1 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0800) // A1- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6259] A1 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x1000) // A2+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6358] A2 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x2000) // A2- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6359 A2 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetOtherLimitErrorMsg()
{
	if(m_lErrorOtherLimitNew & 0x0001) // C1+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6051] BET1 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0002) // C1- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6052] BET1 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0004) // P1+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6251] LC (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0008) // P1- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6252] LC (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0010) // C2+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6059] BET2 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0020) // C2- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6060] BET2 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0040) // P2+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6351] UC (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0080) // P2- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6352] UC (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0100) // M1+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6035] M (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0200) // M1- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6036] M (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0400) // M2+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6043] M2 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0800) // M2- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6044] M2 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetLaserErrorMsg()
{
	if(m_lErrorLaserNew & 0x0001) // Chiller Alarm
	{
		m_strMsg[m_nMsg++] = "[MB5425] Chiller On Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetTableErrorMsg()
{
	if(m_lErrorTableNew & 0x0001) // xy move danger error
	{
		m_strMsg[m_nMsg++] = "[MB6109] XY Move Danger";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0002) // xy stop error
	{
		m_strMsg[m_nMsg++] = "[MB6143] XY Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0004) // X Fault
	{
		m_strMsg[m_nMsg++] = "[MB6000] X Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0008) // X Fatal Following Err
	{
		m_strMsg[m_nMsg++] = "[MB6001] X FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0010) // X Open Loop
	{
		m_strMsg[m_nMsg++] = "[MB6002] X OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0020) // X Homing TimeOver
	{
		m_strMsg[m_nMsg++] = "[MB6005] X Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0040) // Y Fault
	{
		m_strMsg[m_nMsg++] = "[MB6008] Y Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0080) // Y Fatal Following Err
	{
		m_strMsg[m_nMsg++] = "[MB6009] Y FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0100) // Y Open Loop
	{
		m_strMsg[m_nMsg++] = "[MB6010] Y OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0200) // Y Homing TimeOver
	{
		m_strMsg[m_nMsg++] = "[MB6013] Y Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0400) // Z1 Fault
	{
		m_strMsg[m_nMsg++] = "[MB6016] Z1 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0800) // Z1 Fatal Following Err
	{
		m_strMsg[m_nMsg++] = "[MB6017] Z1 FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x1000) // Z1 Open Loop
	{
		m_strMsg[m_nMsg++] = "[MB6018] Z1 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x2000) // Z1 Homing TimeOver
	{
		m_strMsg[m_nMsg++] = "[MB6021] Z1 Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x4000) // Z2 Fault
	{
		m_strMsg[m_nMsg++] = "[MB6024] Z2 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x8000) // Z2 Fatal Following Err
	{
		m_strMsg[m_nMsg++] = "[MB6025] Z2 FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorTableNew & 0x10000) // 
	{
		m_strMsg[m_nMsg++] = "[MB6007] X Axis Servo Drive Over Temperature Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x20000) // 
	{
		m_strMsg[m_nMsg++] = "[MB6015] Y Axis Servo Drive Over Temperature Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetOthersErrorMsg()
{
	if(m_lErrorOthersNew & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6212] M1 Servo Drive Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6213] B1 Servo Drive Alarm ";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6214] B2 Servo Drive Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0008)
	{
//		m_strMsg[m_nMsg++] = "[MB6045] M2 Homing TimeOut";
//		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6124] Table1 Vacuum On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6125] Table1 Vacuum Off Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6126] Table2 Vacuum On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6127] Table2 Vacuum Off Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6134] PowerDetector Sensor Forward Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6135] PowerDetector Sensor Backward Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6038] M1 Servo Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6054] BET1 Servo Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6062] BET2 Servo Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6139] XY Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6141] XY Unload Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6142] XY Unload2 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}

	/*if(m_lErrorOthersNew & 0x10000)
	{
		m_strMsg[m_nMsg++] = "[MB5557] AOM Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	*/if(m_lErrorOthersNew & 0x20000)
	{
		m_strMsg[m_nMsg++] = "[MB6136] Suction Hood Air Open/Close Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetOthers2ErrorMsg()
{
	if(m_lErrorOthers2New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6157] XY Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6158] Z1 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6159] Z2 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6160] M1 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6162] BET1 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6062] TableClamp1 Sensor Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6032] M1 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6033] M1 FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6034] M1 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6037] M1 Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6048] BET1 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6049] BET1 FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6050] BET1 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6053] BET1 Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6063] TableClamp2 Sensor Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6161] M2 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x00010000)
	{
		m_strMsg[m_nMsg++] = "[MB6163] BET2 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x00020000)
	{
		m_strMsg[m_nMsg++] = "[MB6058] BET2 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x00040000)
	{
		m_strMsg[m_nMsg++] = "[MB6061] BET2 Homing TimeOut";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x00080000)
	{
		m_strMsg[m_nMsg++] = "[MB6056] BET2 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorOthers2New & 0x00100000)
	{
		m_strMsg[m_nMsg++] = "[MB6057] BET2 FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetOthers3ErrorMsg()
{
	if(m_lErrorOthers3New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6144] Z1 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6145] Z1 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6146] Z2 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6147] Z2 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6148] M1 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6149] M1 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6152] BET1 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6153] BET1 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
/*	if(m_lErrorOthers3New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6150] M2 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6151] M2 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6154] BET2 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6155] BET2 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6106] MPG On";
		if(m_nMsg > m_nMaxError-1) return;
	}
*/	if(m_lErrorOthers3New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6026] Z2 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6029] Z2 Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x10000) 
	{
		m_strMsg[m_nMsg++] = "[MB5557] AOM Off Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	
}

void CDlgAlarmPLCPusan2::GetOthers4ErrorMsg()
{
	if(m_lErrorOthers4New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6112] 1stTable PCB Exist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6113] 1stTable PCB NotExist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6114] 2ndTable PCB Exist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6115] 2ndTable PCB NotExist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6106] MPG On Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6054] Beam Pass Up/Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6055] Beam Pass Fwd/Bwd Err";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorOthers4New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6116] Suction Hood Open Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6117] Suction Hood Close Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6122] Height Sensor2 Up Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6123] Height Sensor2 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6210] L-Picker Not AllUp";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6310] UL-Picker Not AllUp";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6123] HeightSensor2 Up/Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6120] Tophat Fwd Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x10000)
	{
		m_strMsg[m_nMsg++] = "[MB6121] Tophat Bwd Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	/*
	if(m_lErrorOthers4New & 0x20000)
	{
		m_strMsg[m_nMsg++] = "[MB6311] Laser System Warning Err";
		if(m_nMsg > m_nMaxError-1) return;
	}*/

	if(m_lErrorOthers4New & 0x40000)
	{
		m_strMsg[m_nMsg++] = "[MB6137] Beam Pass Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	
	if(m_lErrorOthers4New & 0x80000)
	{
		m_strMsg[m_nMsg++] = "[MB6139] Beam Pass Down2 Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
/*
	if(m_lErrorOthers4New & 0x100000) // Laser Over Temp Fault Error 
	{
		m_strMsg[m_nMsg++] = "[MB6146] Laser Over Temp Fault Err";
		if(m_nMsg > m_nMaxError-1) return;
	}*/

	if(m_lErrorOthers4New & 0x400000)
	{
		m_strMsg[m_nMsg++] = "[MB5431] Dust Suction Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetOthers5ErrorMsg()
{
	if(m_lErrorOthers5New & 0x0001) //A1 Fault
	{
		m_strMsg[m_nMsg++] = "[MB6255] Att1 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0002) //A1 Fatal Following Error
	{
		m_strMsg[m_nMsg++] = "[MB6256] Att1 FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0004) //A1 Open Loop
	{
		m_strMsg[m_nMsg++] = "[MB6257] Att1 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0008) //A1 Homing TimeOut
	{
		m_strMsg[m_nMsg++] = "[MB6260] Att1 Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorOthers5New & 0x0010) //A1 MovePosition Error
	{
		m_strMsg[m_nMsg++] = "[MB6038] Att1 MovePosition Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0020) //A1 Stop Error
	{
		m_strMsg[m_nMsg++] = "[MB6039] Att1 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0040) //A1 MotionParameter Error
	{
		m_strMsg[m_nMsg++] = "[MB6030] Att1 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0080) //A2 Fault
	{
		m_strMsg[m_nMsg++] = "[MB6355] Att2 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorOthers5New & 0x0100) //A2 Fatal Following Error
	{
		m_strMsg[m_nMsg++] = "[MB6356] Att2 FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0200) //A2 Open Loop
	{
		m_strMsg[m_nMsg++] = "[MB6357] Att2 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0400) //A2 Homing TimeOut
	{
		m_strMsg[m_nMsg++] = "[MB6360] Att2 Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0800) //A2 MovePosition Error
	{
		m_strMsg[m_nMsg++] = "[MB6046] Att2 Move Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorOthers5New & 0x1000) //A2 Stop Error
	{
		m_strMsg[m_nMsg++] = "[MB6047] Att2 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x2000) //A2 MotionParameter Error
	{
		m_strMsg[m_nMsg++] = "[MB6031] Att2 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetOthers6ErrorMsg()
{
/*	if(m_lErrorOthers6New & 0x0001) //ATT1 Axis Servo Drive Alarm
	{
		m_strMsg[m_nMsg++] = "[MB6211] Att1 ServoDrive Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers6New & 0x0002) //ATT2 Axis Servo Drive Alarm
	{
		m_strMsg[m_nMsg++] = "[MB6212] Att2 ServoDrive Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers6New & 0x0004) //BET1 Axis Servo Drive Alarm
	{
		m_strMsg[m_nMsg++] = "[MB6213] BET1 ServoDrive Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers6New & 0x0008) //BET2 Axis Servo Drive Alarm
	{
		m_strMsg[m_nMsg++] = "[MB6214] BET2 ServoDrive Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorOthers6New & 0x0010) //Laser System Warning
	{
		m_strMsg[m_nMsg++] = "[MB6311] Laser System Warning";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers6New & 0x0020) //Laser Over Temp Fault
	{
		m_strMsg[m_nMsg++] = "[MB6312] Laser OverTemp.Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
*/
}

void CDlgAlarmPLCPusan2::GetMelsecMainErrorMsg()
{
	// Empty 7000

	if(m_lErrorMelsecMainNew & 0x00000002)
	{
		m_strMsg[m_nMsg++] = "[M7001] PLC CPU";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x00000004)
	{
		m_strMsg[m_nMsg++] = "[M7002] PLC CPU LowBattery";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x00000008)
	{
		m_strMsg[m_nMsg++] = "[M7003] PLC Fuse";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecMainNew & 0x00000010)
	{
		m_strMsg[m_nMsg++] = "[M7004] QD75Unit 1";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x00000020)
	{
		m_strMsg[m_nMsg++] = "[M7005] COM.ERR LED";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x00000040)
	{
		m_strMsg[m_nMsg++] = "[M7006] WDT Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x00000080)
	{
		m_strMsg[m_nMsg++] = "[M7007] QD75Unit 2";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecMainNew & 0x00000100)
	{
		m_strMsg[m_nMsg++] = "[M7008] Unloader cart Full";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecMainNew & 0x00000200)
	{
		m_strMsg[m_nMsg++] = "[M7009] MotorPower OFF";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x00000400)
	{
		m_strMsg[m_nMsg++] = "[M7010] MotorReady OFF";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x00000800)
	{
		m_strMsg[m_nMsg++] = "[M7011] LdUd Air OFF";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecMainNew & 0x00001000)
	{
		m_strMsg[m_nMsg++] = "[M7012] Emergency ON";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x00002000)
	{
		m_strMsg[m_nMsg++] = "[M7013] LdUd TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x00004000)
	{
		m_strMsg[m_nMsg++] = "[M7014] Ld Door Interlock";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x00008000)
	{
		m_strMsg[m_nMsg++] = "[M7015] Ud Door Interlock";
		if(m_nMsg > m_nMaxError-1) return;
	}
	
	if(m_lErrorMelsecMainNew & 0x00010000)
	{
		m_strMsg[m_nMsg++] = "[M7016] Loader No Basket";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x00020000)
	{
		m_strMsg[m_nMsg++] = "[M7017] Unloader No Basket";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x00040000)
	{
		m_strMsg[m_nMsg++] = "[M7018] LoadPart Initial";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x00080000)
	{
		m_strMsg[m_nMsg++] = "[M7019] UnloadPart Initial";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetMelsecLoaderErrorMsg()
{
	if(m_lErrorMelsecLoaderNew & 0x00000001)
	{
		m_strMsg[m_nMsg++] = "[M7020] LC Origin TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00000002)
	{
		m_strMsg[m_nMsg++] = "[M7021] LC Moving";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00000004)
	{
		m_strMsg[m_nMsg++] = "[M7022] LC PosData";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00000008)
	{
		m_strMsg[m_nMsg++] = "[M7023] LC Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecLoaderNew & 0x00000010)
	{
		m_strMsg[m_nMsg++] = "[M7024] LC(+) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00000020)
	{
		m_strMsg[m_nMsg++] = "[M7025] LC(-) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00000040)
	{
		m_strMsg[m_nMsg++] = "[M7026] LP1 Origin TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00000080)
	{
		m_strMsg[m_nMsg++] = "[M7027] LP1 Moving";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecLoaderNew & 0x00000100)
	{
		m_strMsg[m_nMsg++] = "[M7028] LP1 PosData";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00000200)
	{
		m_strMsg[m_nMsg++] = "[M7029] LP1 Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00000400)
	{
		m_strMsg[m_nMsg++] = "[M7030] LP1(+) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00000800)
	{
		m_strMsg[m_nMsg++] = "[M7031] LP1(-) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecLoaderNew & 0x00001000)
	{
		m_strMsg[m_nMsg++] = "[M7032] LP2 Origin TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00002000)
	{
		m_strMsg[m_nMsg++] = "[M7033] LP2 Moving";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00004000)
	{
		m_strMsg[m_nMsg++] = "[M7034] LP2 PosData";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00008000)
	{
		m_strMsg[m_nMsg++] = "[M7035] LP2 Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecLoaderNew & 0x00010000)
	{
		m_strMsg[m_nMsg++] = "[M7036] LP2(+) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00020000)
	{
		m_strMsg[m_nMsg++] = "[M7037] LP2(-) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00040000)
	{
		m_strMsg[m_nMsg++] = "[M7040] LP3 Origin TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00080000)
	{
		m_strMsg[m_nMsg++] = "[M7041] LP3 Moving";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecLoaderNew & 0x00100000)
	{
		m_strMsg[m_nMsg++] = "[M7042] LP3 PosData";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00200000)
	{
		m_strMsg[m_nMsg++] = "[M7043] LP3 Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00400000)
	{
		m_strMsg[m_nMsg++] = "[M7044] LP3(+) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x00800000)
	{
		m_strMsg[m_nMsg++] = "[M7045] LP3(-) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetMelsecUnloaderErrorMsg()
{
	if(m_lErrorMelsecUnloaderNew & 0x00000001)
	{
		m_strMsg[m_nMsg++] = "[M7046] UC Origin TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000002)
	{
		m_strMsg[m_nMsg++] = "[M7047] UC Moving";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000004)
	{
		m_strMsg[m_nMsg++] = "[M7048] UC PosData";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000008)
	{
		m_strMsg[m_nMsg++] = "[M7049] UC Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecUnloaderNew & 0x00000010)
	{
		m_strMsg[m_nMsg++] = "[M7050] UC(+) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000020)
	{
		m_strMsg[m_nMsg++] = "[M7051] UC(-) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000040)
	{
		m_strMsg[m_nMsg++] = "[M7052] UP1 Origin TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000080)
	{
		m_strMsg[m_nMsg++] = "[M7053] UP1 Moving";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecUnloaderNew & 0x00000100)
	{
		m_strMsg[m_nMsg++] = "[M7054] UP1 PosData";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000200)
	{
		m_strMsg[m_nMsg++] = "[M7055] UP1 Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000400)
	{
		m_strMsg[m_nMsg++] = "[M7056] UP1(+) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000800)
	{
		m_strMsg[m_nMsg++] = "[M7057] UP1(-) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecUnloaderNew & 0x00001000)
	{
		m_strMsg[m_nMsg++] = "[M7060] UP2 Origin TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00002000)
	{
		m_strMsg[m_nMsg++] = "[M7061] UP2 Moving";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00004000)
	{
		m_strMsg[m_nMsg++] = "[M7062] UP2 PosData";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00008000)
	{
		m_strMsg[m_nMsg++] = "[M7063] UP2 Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecUnloaderNew & 0x00010000)
	{
		m_strMsg[m_nMsg++] = "[M7064] UP2(+) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00020000)
	{
		m_strMsg[m_nMsg++] = "[M7065] UP2(-) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00040000)
	{
		m_strMsg[m_nMsg++] = "[M7066] UP3 Origin TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00080000)
	{
		m_strMsg[m_nMsg++] = "[M7067] UP3 Moving";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecUnloaderNew & 0x00100000)
	{
		m_strMsg[m_nMsg++] = "[M7068] UP3 PosData";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00200000)
	{
		m_strMsg[m_nMsg++] = "[M7069] UP3 Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00400000)
	{
		m_strMsg[m_nMsg++] = "[M7070] UP3(+) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x00800000)
	{
		m_strMsg[m_nMsg++] = "[M7071] UP3(-) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetMelsecEtc1ErrorMsg()
{
	if(m_lErrorMelsecEtc1New & 0x00000001)
	{
		m_strMsg[m_nMsg++] = "[M7080] Ld Elv Homing";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000002)
	{
		m_strMsg[m_nMsg++] = "[M7081] Ld Elv Loading";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000004)
	{
		m_strMsg[m_nMsg++] = "[M7082] Ld Elv Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000008)
	{
		m_strMsg[m_nMsg++] = "[M7083] Ld Elv(+) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecEtc1New & 0x00000010)
	{
		m_strMsg[m_nMsg++] = "[M7084] Ld Elv(-) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000020)
	{
		m_strMsg[m_nMsg++] = "[M7085] Ud Elv Homing";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000040)
	{
		m_strMsg[m_nMsg++] = "[M7086] Ud Elv Loading";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000080)
	{
		m_strMsg[m_nMsg++] = "[M7087] Ud Elv Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecEtc1New & 0x00000100)
	{
		m_strMsg[m_nMsg++] = "[M7088] Ud Elv(+) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000200)
	{
		m_strMsg[m_nMsg++] = "[M7089] Ud Elv(-) Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000400)
	{
		m_strMsg[m_nMsg++] = "[M7090] Ld Paper Trans Fwd/Bwd";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000800)
	{
		m_strMsg[m_nMsg++] = "[M7091] Ld PCB Trans Fwd/Bwd";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecEtc1New & 0x00001000)
	{
		m_strMsg[m_nMsg++] = "[M7092] Ld Align Sheet Fwd/Bwd";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00002000)
	{
		m_strMsg[m_nMsg++] = "[M7093] Ld Align Guid Fwd/Bwd";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00004000)
	{
		m_strMsg[m_nMsg++] = "[M7094] Ld Cart Clamp Up/Down";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00008000)
	{
		m_strMsg[m_nMsg++] = "[M7095] LP1 Vacuum";
		if(m_nMsg > m_nMaxError-1) return;
	}
	
	if(m_lErrorMelsecEtc1New & 0x00010000)
	{
		m_strMsg[m_nMsg++] = "[M7096] LP2 Vacuum";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00020000)
	{
		m_strMsg[m_nMsg++] = "[M7097] LP3 Vacuum";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00040000)
	{
		m_strMsg[m_nMsg++] = "[M7098] Ud Paper Trans Fwd/Bwd";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00080000)
	{
		m_strMsg[m_nMsg++] = "[M7099] Ud PCB Trans Fwd/Bwd";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecEtc1New & 0x00100000)
	{
		m_strMsg[m_nMsg++] = "[M7100] Ud Cart Clamp Up/Down";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00200000)
	{
		m_strMsg[m_nMsg++] = "[M7101] UP1 Vacuum";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00400000)
	{
		m_strMsg[m_nMsg++] = "[M7102] UP2 Vacuum";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00800000)
	{
		m_strMsg[m_nMsg++] = "[M7103] UP3 Vacuum";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecEtc1New & 0x01000000)
	{
		m_strMsg[m_nMsg++] = "[M7104] Ld Cart Detect Sensor";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x02000000)
	{
		m_strMsg[m_nMsg++] = "[M7105] Ud Cart Detect Sensor";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x04000000)
	{
		m_strMsg[m_nMsg++] = "[M7106] LP1 Status";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x08000000)
	{
		m_strMsg[m_nMsg++] = "[M7107] LP2 Status";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecEtc1New & 0x10000000)
	{
		m_strMsg[m_nMsg++] = "[M7108] LP3 Status";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x20000000)
	{
		m_strMsg[m_nMsg++] = "[M7109] Ld PCB Table Status";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x40000000)
	{
		m_strMsg[m_nMsg++] = "[M7110] Ld Paper Table Status";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x80000000)
	{
		m_strMsg[m_nMsg++] = "[M7111] UP1 Status";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::GetMelsecEtc2ErrorMsg()
{
	if(m_lErrorMelsecEtc2New & 0x00000001)
	{
		m_strMsg[m_nMsg++] = "[M7112] UP2 Status";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc2New & 0x00000002)
	{
		m_strMsg[m_nMsg++] = "[M7113] UP3 Status";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc2New & 0x00000004)
	{
		m_strMsg[m_nMsg++] = "[M7114] Ud PCB Table Status";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc2New & 0x00000008)
	{
		m_strMsg[m_nMsg++] = "[M7115] Ud Paper Table Status";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc2New & 0x00000010)
	{
		m_strMsg[m_nMsg++] = "[M7116] Ld PCB Drop in Danger Place";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc2New & 0x00000020)
	{
		m_strMsg[m_nMsg++] = "[M7117] Ud PCB Drop in Danger Place";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc2New & 0x00000040)
	{
		m_strMsg[m_nMsg++] = "[M7038] Ld Basket Paper Full";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc2New & 0x00000080)
	{
		m_strMsg[m_nMsg++] = "[M7058] Ud Elv PCB Full";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCPusan2::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

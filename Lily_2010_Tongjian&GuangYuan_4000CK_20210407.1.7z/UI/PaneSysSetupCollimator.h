#if !defined(AFX_PANESYSSETUPCOLLIMATOR_H__276920B5_ED73_45FB_A330_70CC5010895C__INCLUDED_)
#define AFX_PANESYSSETUPCOLLIMATOR_H__276920B5_ED73_45FB_A330_70CC5010895C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupCollimator.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupCollimator form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

class CPaneSysSetupCollimator : public CFormView
{
protected:
	CPaneSysSetupCollimator();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupCollimator)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupCollimator)
	enum { IDD = IDD_DLG_SYS_SETUP_COLLIMATOR };
	CColorEdit	m_edtMaskSize0;
	CColorEdit	m_edtMaskSize1;
	CColorEdit	m_edtMaskSize2;
	CColorEdit	m_edtMaskSize3;
	CColorEdit	m_edtMaskSize4;
	CColorEdit	m_edtMaskSize5;
	CColorEdit	m_edtMaskSize6;
	CColorEdit	m_edtMaskSize7;
	CColorEdit	m_edtMaskSize8;
	CColorEdit	m_edtMaskSize9;
	CColorEdit	m_edtBeamSize0;
	CColorEdit	m_edtBeamSize1;
	CColorEdit	m_edtBeamSize2;
	CColorEdit	m_edtBeamSize3;
	CColorEdit	m_edtBeamSize4;
	CColorEdit	m_edtBeamSize5;
	CColorEdit	m_edtBeamSize6;
	CColorEdit	m_edtBeamSize7;
	CColorEdit	m_edtBeamSize8;
	CColorEdit	m_edtBeamSize9;
	CColorEdit	m_edtPos0;
	CColorEdit	m_edtPos1;
	CColorEdit	m_edtPos2;
	CColorEdit	m_edtPos3;
	CColorEdit	m_edtPos4;
	CColorEdit	m_edtPos5;
	CColorEdit	m_edtPos6;
	CColorEdit	m_edtPos7;
	CColorEdit	m_edtPos8;
	CColorEdit	m_edtPos9;

	CColorEdit	m_edtPos0_2;
	CColorEdit	m_edtPos1_2;
	CColorEdit	m_edtPos2_2;
	CColorEdit	m_edtPos3_2;
	CColorEdit	m_edtPos4_2;
	CColorEdit	m_edtPos5_2;
	CColorEdit	m_edtPos6_2;
	CColorEdit	m_edtPos7_2;
	CColorEdit	m_edtPos8_2;
	CColorEdit	m_edtPos9_2;

	CColorEdit	m_edtMaskPos0;
	CColorEdit	m_edtMaskPos1;
	CColorEdit	m_edtMaskPos2;
	CColorEdit	m_edtMaskPos3;
	CColorEdit	m_edtMaskPos4;
	CColorEdit	m_edtMaskPos5;
	CColorEdit	m_edtMaskPos6;
	CColorEdit	m_edtMaskPos7;
	CColorEdit	m_edtMaskPos8;
	CColorEdit	m_edtMaskPos9;
	CColorEdit	m_edtMaskDuty0;
	CColorEdit	m_edtMaskDuty1;
	CColorEdit	m_edtMaskDuty2;
	CColorEdit	m_edtMaskDuty3;
	CColorEdit	m_edtMaskDuty4;
	CColorEdit	m_edtMaskDuty5;
	CColorEdit	m_edtMaskDuty6;
	CColorEdit	m_edtMaskDuty7;
	CColorEdit	m_edtMaskDuty8;
	CColorEdit	m_edtMaskDuty9;

	CColorEdit	m_edtMaskAOMDelay0;
	CColorEdit	m_edtMaskAOMDelay1;
	CColorEdit	m_edtMaskAOMDelay2;
	CColorEdit	m_edtMaskAOMDelay3;
	CColorEdit	m_edtMaskAOMDelay4;
	CColorEdit	m_edtMaskAOMDelay5;
	CColorEdit	m_edtMaskAOMDelay6;
	CColorEdit	m_edtMaskAOMDelay7;
	CColorEdit	m_edtMaskAOMDelay8;
	CColorEdit	m_edtMaskAOMDelay9;

	CColorEdit	m_edtMaskAOMDuty0;
	CColorEdit	m_edtMaskAOMDuty1;
	CColorEdit	m_edtMaskAOMDuty2;
	CColorEdit	m_edtMaskAOMDuty3;
	CColorEdit	m_edtMaskAOMDuty4;
	CColorEdit	m_edtMaskAOMDuty5;
	CColorEdit	m_edtMaskAOMDuty6;
	CColorEdit	m_edtMaskAOMDuty7;
	CColorEdit	m_edtMaskAOMDuty8;
	CColorEdit	m_edtMaskAOMDuty9;

	CColorEdit	m_edtPowerDuty0;
	CColorEdit	m_edtPowerDuty1;
	CColorEdit	m_edtPowerDuty2;
	CColorEdit	m_edtPowerDuty3;
	CColorEdit	m_edtPowerDuty4;
	CColorEdit	m_edtPowerDuty5;
	CColorEdit	m_edtPowerDuty6;
	CColorEdit	m_edtPowerDuty7;
	CColorEdit	m_edtPowerDuty8;
	CColorEdit	m_edtPowerDuty9;

	CColorEdit	m_edtPowerFreq0;
	CColorEdit	m_edtPowerFreq1;
	CColorEdit	m_edtPowerFreq2;
	CColorEdit	m_edtPowerFreq3;
	CColorEdit	m_edtPowerFreq4;
	CColorEdit	m_edtPowerFreq5;
	CColorEdit	m_edtPowerFreq6;
	CColorEdit	m_edtPowerFreq7;
	CColorEdit	m_edtPowerFreq8;
	CColorEdit	m_edtPowerFreq9;

	CColorEdit	m_edtPowerA1_0;
	CColorEdit	m_edtPowerA1_1;
	CColorEdit	m_edtPowerA1_2;
	CColorEdit	m_edtPowerA1_3;
	CColorEdit	m_edtPowerA1_4;
	CColorEdit	m_edtPowerA1_5;
	CColorEdit	m_edtPowerA1_6;
	CColorEdit	m_edtPowerA1_7;
	CColorEdit	m_edtPowerA1_8;
	CColorEdit	m_edtPowerA1_9;

	CColorEdit	m_edtPowerA2_0;
	CColorEdit	m_edtPowerA2_1;
	CColorEdit	m_edtPowerA2_2;
	CColorEdit	m_edtPowerA2_3;
	CColorEdit	m_edtPowerA2_4;
	CColorEdit	m_edtPowerA2_5;
	CColorEdit	m_edtPowerA2_6;
	CColorEdit	m_edtPowerA2_7;
	CColorEdit	m_edtPowerA2_8;
	CColorEdit	m_edtPowerA2_9;

	CColorEdit	m_edtFixedMask;

	CColorEdit	m_edtMemo_0;
	CColorEdit	m_edtMemo_1;
	CColorEdit	m_edtMemo_2;
	CColorEdit	m_edtMemo_3;
	CColorEdit	m_edtMemo_4;
	CColorEdit	m_edtMemo_5;
	CColorEdit	m_edtMemo_6;
	CColorEdit	m_edtMemo_7;
	CColorEdit	m_edtMemo_8;
	CColorEdit	m_edtMemo_9;
	//}}AFX_DATA

// Attributes
public:

// Attributes
protected :
	CFont		m_fntStatic;
	CFont		m_fntStatic2;
	CFont		m_fntEdit;
	CFont		m_fntEdit2;
	CFont		m_fntBtn;

	SSYSTEMCOLLIMATOR	m_sSystemCollimator;	

// Operations
public:
	CString GetChangeValueStr();
	void InitBtnControl();
	void InitStaticControl();
	void InitEditControl();

	void SetSystemCollimator(SSYSTEMCOLLIMATOR sSystemCollimator);
	void GetSystemCollimator(SSYSTEMCOLLIMATOR* pSystemCollimator);
	void DispSystemCollimator();
	void OnApply();
	
	void EnableControl(BOOL bUse, BOOL bShow);
	void SetAuthorityByLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupCollimator)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupCollimator();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupCollimator)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPCOLLIMATOR_H__276920B5_ED73_45FB_A330_70CC5010895C__INCLUDED_)

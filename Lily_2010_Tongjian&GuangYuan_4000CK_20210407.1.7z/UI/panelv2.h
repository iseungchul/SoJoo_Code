#if !defined(AFX_PANELV2_H__F7C75355_5E11_4625_AF50_36411010C7F5__INCLUDED_)
#define AFX_PANELV2_H__F7C75355_5E11_4625_AF50_36411010C7F5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// panelv2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneLV2 form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CPaneLV2 : public CFormView
{
protected:
	CPaneLV2();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneLV2)

// Form Data
public:
	//{{AFX_DATA(CPaneLV2)
#ifdef __USE_COGNEX_7_LIB__
	enum { IDD = IDD_LV_2 };
#else
	enum { IDD = IDD_LV_2_NEW };
#endif
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneLV2)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneLV2();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneLV2)
	afx_msg void OnDestroy();
	afx_msg void OnDblClickVisionpro2l();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANELV2_H__F7C75355_5E11_4625_AF50_36411010C7F5__INCLUDED_)

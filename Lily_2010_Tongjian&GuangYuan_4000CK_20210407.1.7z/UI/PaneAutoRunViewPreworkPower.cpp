// PaneAutoRunViewPreworkPower.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneAutoRunViewPreworkPower.h"
#include "..\model\DProcessINI.h"
#include "..\model\DProject.h"
#include "..\model\DTempINI.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPreworkPower

IMPLEMENT_DYNCREATE(CPaneAutoRunViewPreworkPower, CFormView)

CPaneAutoRunViewPreworkPower::CPaneAutoRunViewPreworkPower()
	: CFormView(CPaneAutoRunViewPreworkPower::IDD)
{
	//{{AFX_DATA_INIT(CPaneAutoRunViewPreworkPower)
		// NOTE: the ClassWizard will add member initialization here
	m_nMeasureCount = 0;
	m_bOldPanel = TRUE;
	//}}AFX_DATA_INIT

	for(int i =0; i<MAX_TOOL_NO;i++)
	{
		m_bDoPower[i][0] = FALSE;
		m_bDoPower[i][1] = FALSE;
		m_dAvgPower[i][0] = 0.0;
		m_dAvgPower[i][1] = 0.0;
	}
}

CPaneAutoRunViewPreworkPower::~CPaneAutoRunViewPreworkPower()
{
}

void CPaneAutoRunViewPreworkPower::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneAutoRunViewPreworkPower)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_LIST_POWER_TOOL, m_listPowerTool);
	DDX_Control(pDX, IDC_LIST_RESULT, m_lboxResult);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneAutoRunViewPreworkPower, CFormView)
	//{{AFX_MSG_MAP(CPaneAutoRunViewPreworkPower)
	ON_WM_CTLCOLOR()
	ON_NOTIFY(NM_CLICK, IDC_LIST_POWER_TOOL, OnClickListPowerTool)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPreworkPower diagnostics

#ifdef _DEBUG
void CPaneAutoRunViewPreworkPower::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneAutoRunViewPreworkPower::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPreworkPower message handlers

BOOL CPaneAutoRunViewPreworkPower::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

void CPaneAutoRunViewPreworkPower::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStatic();
	InitListControl();
}
void CPaneAutoRunViewPreworkPower::InitListControl()
{
	m_fntList.CreatePointFont(90, "Arial Bold");
	
	//Tool List
	m_listPowerTool.SetFont( &m_fntList );
	m_listPowerTool.SetExtendedStyle(m_listPowerTool.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);
	
	m_listPowerTool.DeleteAllItems();
	
	m_listPowerTool.InsertColumn(0, _T(" Tool "), LVCFMT_CENTER, 50);
	m_listPowerTool.InsertColumn(1, _T(" Freq. "), LVCFMT_CENTER, 60);
	m_listPowerTool.InsertColumn(2, _T(" Duty "), LVCFMT_CENTER, 60);
	m_listPowerTool.InsertColumn(3, _T(" AOM Duty "), LVCFMT_CENTER, 90);
	m_listPowerTool.InsertColumn(4, _T(" AOM Delay "), LVCFMT_CENTER, 90);
	m_listPowerTool.InsertColumn(5, _T(" Min "), LVCFMT_CENTER, 60);
	m_listPowerTool.InsertColumn(6, _T(" Max "), LVCFMT_CENTER, 60);
	m_listPowerTool.InsertColumn(7, _T(" Result 1st"), LVCFMT_CENTER, 80);
	m_listPowerTool.InsertColumn(8, _T(" Result 2nd"), LVCFMT_CENTER, 80);

	//Result List
	m_lboxResult.SetFont( &m_fntList );
}

void CPaneAutoRunViewPreworkPower::InitStatic()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");

	GetDlgItem(IDC_STATIC_POWER_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER_SETTING2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MODULATION_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AFTER_TIME)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_MODULATION_TIME_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AFTER_TIME_VAL)->SetFont( &m_fntStatic );


}

HBRUSH CPaneAutoRunViewPreworkPower::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_POWER_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_POWER_SETTING2)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}


void CPaneAutoRunViewPreworkPower::ChangeDisplay(int nIndex)
{
	CString str;

	SUBTOOLDATA subTool;
	POSITION pos;
	int nBeamPath = 0;
	pos = gDProject.m_pToolCode[nIndex]->m_SubToolData.GetHeadPosition();
	if(pos)
	{
		subTool = gDProject.m_pToolCode[nIndex]->m_SubToolData.GetNext(pos);
		nBeamPath = subTool.nMask;
	}

	str.Format(_T("%d"), gProcessINI.m_sProcessCal.nValidMeasureTime);
	GetDlgItem(IDC_STATIC_MODULATION_TIME_VAL)->SetWindowText(str);
	
	time_t timeNow;
	time(&timeNow);
	
	time_t timeEnd;
	timeEnd = gTempINI.m_sTempTime.nAutoPowerEndTime[nBeamPath][0];
	
	double dNowTime;
	
	dNowTime = difftime(timeNow, timeEnd); //sec
	
	dNowTime = dNowTime / 60 / 60 ; // hour  
	str.Format(_T("%.1f"), dNowTime);
	GetDlgItem(IDC_STATIC_AFTER_TIME_VAL1)->SetWindowText(str);
	
	ResetList();
}

void CPaneAutoRunViewPreworkPower::ResetList()
{
	m_listPowerTool.DeleteAllItems();
	int nCount = 0;
	CString strData;
	for(int i = 0; i<MAX_TOOL_NO; i++)
	{
		if(!gDProject.m_pToolCode[i]->m_bUseTool)
			continue;
		//���߿��� �Ŀ������ϴ� ���� �����ͼ� ���÷��� �ϱ� 
		//���� ������1�� �������̸� ù��° ������ ~ 
		
		SUBTOOLDATA subTool;
		POSITION pos;
		pos = gDProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		
		if(pos == NULL)
			continue;

		subTool = gDProject.m_pToolCode[i]->m_SubToolData.GetNext(pos);
		
		if(subTool.nTotalShot <= 0)
			continue;
		
		if(gDProject.m_pToolCode[i]->m_bPreworkPower)
		{
			m_listPowerTool.InsertItem(nCount, _T(""));


			//Tool No
			strData.Format(_T("%d"), i);
			m_listPowerTool.SetItemText(nCount, 0, strData);

			//Freq
			strData.Format(_T("%d"), subTool.nFrequency);
			m_listPowerTool.SetItemText(nCount, 1, strData);

			//Duty
			strData.Format(_T("%.2f"), subTool.dShotDuty[0]);
			m_listPowerTool.SetItemText(nCount, 2, strData);

			//AOM Duty
			strData.Format(_T("%.2f"), subTool.dShotAOMDuty[0]);
			m_listPowerTool.SetItemText(nCount, 3, strData);

			//AOM Delay 
			strData.Format(_T("%.2f"), subTool.dShotAOMDelay[0]);
			m_listPowerTool.SetItemText(nCount, 4, strData);

			//Min
			strData.Format(_T("%.2f"), subTool.dMinPower);
			m_listPowerTool.SetItemText(nCount, 5, strData);

			//Max
			strData.Format(_T("%.2f"), subTool.dMaxPower);
			m_listPowerTool.SetItemText(nCount, 6, strData);
			
			//Result
			if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST)
			{
				if(m_bDoPower[i][0])
				{
					strData.Format(_T("%.1f"), m_dAvgPower[i][0]);
					m_listPowerTool.SetItemText(nCount, 7, strData);
				}
				else
					m_listPowerTool.SetItemText(nCount, 7, "Not yet");
			}
			else
				m_listPowerTool.SetItemText(nCount, 7, "No Use");
			
			if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_2ND)
			{
				if(m_bDoPower[i][1])
				{
					strData.Format(_T("%.1f"), m_dAvgPower[i][1]);
					m_listPowerTool.SetItemText(nCount, 8, strData);
				}
				else
					m_listPowerTool.SetItemText(nCount, 8, "Not yet");
			}
			else
				m_listPowerTool.SetItemText(nCount, 8, "No Use");

			nCount++;
		}
	}
}

void CPaneAutoRunViewPreworkPower::InsertPowerResult(double dResult, BOOL b1st,  int nToolNo)
{
	int nCount = m_lboxResult.GetCount();

	if(b1st != m_bOldPanel)
	{
		m_nMeasureCount = 0;
		m_bOldPanel = b1st;
	}

	CString str, strTemp;
	if(b1st)
		strTemp.Format(_T("Tool%d --- 1st Panel #%d : "), nToolNo ,m_nMeasureCount+1);
	else
		strTemp.Format(_T("Tool%d --- 2nd Panel #%d : "), nToolNo , m_nMeasureCount+1);

	str.Format(_T("%.1f"), dResult);

	strTemp += str;
	m_lboxResult.SetCurSel(nCount - 1);
	m_lboxResult.AddString(strTemp);

	m_nMeasureCount++;
	
}

void CPaneAutoRunViewPreworkPower::InsertAvgResult(int nToolNo, double dResult)
{
	int n = m_listPowerTool.GetItemCount();
	CString str;
	for(int nIndex = 0; nIndex < n; nIndex++)
	{
		str = m_listPowerTool.GetItemText(nIndex, 0);
		if(atoi(str) == nToolNo)
		{
			//Result
			str.Format(_T("%.1f"), dResult);
			m_listPowerTool.SetItemText(nIndex, 7, str);
			
			if(m_bOldPanel)
			{
				m_dAvgPower[nToolNo][0] = dResult;
				m_bDoPower[nToolNo][0] = TRUE;
			}
			else
			{
				m_dAvgPower[nToolNo][1] = dResult;
				m_bDoPower[nToolNo][1] = TRUE;
			}
			break;
		}
	}
	ResetList();
}

void CPaneAutoRunViewPreworkPower::RemoveList()
{
	m_lboxResult.ResetContent();
}
void CPaneAutoRunViewPreworkPower::OnClickListPowerTool(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int nSel = m_listPowerTool.GetSelectionMark();
	if (-1 == nSel)
		return;
	
	TCHAR cTemp[5] = {0,};
	m_listPowerTool.GetItemText(nSel, 0 ,cTemp, 2);
	int nTool = atoi(cTemp);
	ChangeDisplay(nTool); // tool num 
	*pResult = 0;
}
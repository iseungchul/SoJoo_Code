#pragma once

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "ColorStatic.h"
// CPaneAutoRunViewOPC �� ���Դϴ�.

class CPaneAutoRunViewOPC : public CFormView
{
	DECLARE_DYNCREATE(CPaneAutoRunViewOPC)

protected:
	CPaneAutoRunViewOPC();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CPaneAutoRunViewOPC();

public:
	enum { IDD = IDD_DLG_AUTORUN_VIEW_OPC };
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	CColorStatic m_stcUserName;
	CColorStatic m_stcBasketID;
	CColorStatic m_stcStatus;
	CColorStatic m_stcConnect1;
	CColorStatic m_stcConnect2;

	UEasyButtonEx m_btnLoss;
	UEasyButtonEx m_btnSchedule;
	UEasyButtonEx m_chkRMSOnAI;
	UEasyButtonEx m_chkRMSOn;
	UEasyButtonEx m_chkRMSOff;
	UEasyButtonEx m_chkPNLCheckOn;
	UEasyButtonEx m_chkPNLCheckOff;
	UEasyButtonEx m_chkCurrentFire;
	UEasyButtonEx m_chkPreFire;
	UEasyButtonEx m_chkPostFire;
	UEasyButtonEx m_chkTestFire;
	UEasyButtonEx m_chkAICom;
	UEasyButtonEx m_chkAISol;
	UEasyButtonEx m_chkAIBoth;

	CEdit			m_editwnd;
	
	CListCtrl m_listProject;
	void EnableControl(BOOL bEnable);
	void InsertList(BOOL bClear = FALSE);
	void InitListControl();
	void InitStatic();
	void InitBtnControl();
	void DestroyTimer();
	void InitTimer();
	void SetStartDirectionInfo(BOOL bReverse);
	CFont m_fntStatic;
	CFont m_fntBtn;
	CFont m_fntList;
	int m_nRMSType;
	int m_nAIType;
	BOOL m_bPNLCheck;

	int m_nTimer;
	int m_nSelectIndex;
	BOOL m_bStartReverseInfo;
	void ChangeDisplay();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual void OnInitialUpdate();
	afx_msg void OnBnClickedButtonLossInput();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedButtonRmsOnAi();
	afx_msg void OnBnClickedButtonRmsOn();
	afx_msg void OnBnClickedButtonRmsOff();
	afx_msg void OnBnClickedButtonPanelCheckOn();
	afx_msg void OnBnClickedButtonPanelCheckOff();
	afx_msg void OnBnClickedButtonCurrentLot();
	afx_msg void OnBnClickedButtonPre();
	afx_msg void OnBnClickedButtonRe();
	afx_msg void OnDestroy();
	afx_msg void OnClickListProject(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedButtonSchudle();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	afx_msg void OnBnClickedButtonTestFire();
	afx_msg void OnBnClickedButtonCom();
	afx_msg void OnBnClickedButtonSol();
	afx_msg void OnBnClickedButtonBoth();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnEnUpdateEditBox();
};



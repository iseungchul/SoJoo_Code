#pragma once

#include "ColorEdit.h"
#include "ColorComboEx.h"
#include "DlgLaserMeasurement.h"
// CDlgDispatch dialog

class CDlgDispatch : public CDialog
{
	DECLARE_DYNAMIC(CDlgDispatch)

public:
	CDlgDispatch(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgDispatch();

// Dialog Data
	enum { IDD = IDD_DLG_DISPATCH };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CComboBox m_cmbCode;
	CColorEdit m_edt1stLot;
	CColorEdit m_edtChangeInfo;
	CColorEdit m_edtCurrentLot;
	CColorEdit m_edtReason;

	CFont m_fntStatic;
	CFont m_fntEdit;
	CFont m_fntCmb;
	CDlgLaserMeasurement m_dlgOPCWait;

	int m_nVal2;
	int m_nVal1;
	int m_nErrCode;
	int m_nSelectPrjIndex;
	int	m_nDispatchCode;
	char m_szLot1[128];
	char m_szLot2[128];
	char m_szResult[128];
	char m_szMessage[128];
	void InitEditControl();
	void InitStaticControl();
	void InitCmbControl();
	void SetPrjIndex(int nIndex);
	void ChangeDisplay();
	void SetLotInfo(char* strLot1, char* strLot2, int nVal1, int nVal2);
	void GetResult(int& nErrCode, BOOL& bResult, char* szMessage);
	BOOL WaitOPCRecvMessage();
	void ResetOPCRecvMessage();
	virtual BOOL OnInitDialog();
	afx_msg void OnCbnSelchangeComboCode();
	afx_msg void OnBnClickedOk();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

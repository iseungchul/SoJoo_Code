#if !defined(AFX_TestThumnailView_H__711D2F0D_1831_4390_80BE_683099E6BB14__INCLUDED_)
#define AFX_TestThumnailView_H__711D2F0D_1831_4390_80BE_683099E6BB14__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TestThumnailView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTestThumnailView view

class CTestThumnailView : public CScrollView
{
protected:
	CTestThumnailView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CTestThumnailView)

// Attributes
public:

// Operations
public:
	void setAxis(int nAxis);
	void DisplayMovePosition(int nPositionX, int nPositionY);
	static LRESULT CALLBACK WindowProcedure(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam);
	static BOOL RegisterTestThumnailViewClass(HINSTANCE hInstance);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestThumnailView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual void OnInitialUpdate();     // first time after construct
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CTestThumnailView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CTestThumnailView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_nOffsetY;
	int m_nOffsetX;
	COLORREF m_clrMovePosition;
	CPen m_PenMovePosition;
	void DrawMovePosition_Left_270(CDC *pDC, CRect rectField);
	void DrawMovePosition_Left_180(CDC *pDC, CRect rectField);
	void DrawMovePosition_Left_90(CDC *pDC, CRect rectField);
	void DrawMovePosition_Left_0(CDC *pDC, CRect rectField);
	void DrawMovePosition_270(CDC *pDC, CRect rectField);
	void DrawMovePosition_180(CDC *pDC, CRect rectField);
	void DrawMovePosition_90(CDC *pDC, CRect rectField);
	void DrawMovePosition_0(CDC *pDC, CRect rectField);
	int m_nAxis;
	int m_nPositionY;
	int m_nPositionX;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TestThumnailView_H__711D2F0D_1831_4390_80BE_683099E6BB14__INCLUDED_)

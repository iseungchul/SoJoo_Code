// PaneManualControlIOMonitorOutput.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlIOMonitorOutput.h"
#ifdef __PUSAN_LDD__
	#include "PaneManualControlIOMonitorOutputSub1LDD.h"
#else
	#include "PaneManualControlIOMonitorOutputSub1.h"
	#include "PaneManualControlIOMonitorOutputSub2.h"
#endif


#include "..\model\deasydrillerini.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutput

IMPLEMENT_DYNCREATE(CPaneManualControlIOMonitorOutput, CFormView)

CPaneManualControlIOMonitorOutput::CPaneManualControlIOMonitorOutput()
	: CFormView(CPaneManualControlIOMonitorOutput::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlIOMonitorOutput)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pSub1 = NULL;
	m_pSub2 = NULL;
	m_nPaneNo = -1;
}

CPaneManualControlIOMonitorOutput::~CPaneManualControlIOMonitorOutput()
{
}

void CPaneManualControlIOMonitorOutput::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlIOMonitorOutput)
	DDX_Control(pDX, IDC_TAB_MANUAL_CONTROL, m_tabManualControl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlIOMonitorOutput, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlIOMonitorOutput)
	ON_NOTIFY(NM_CLICK, IDC_TAB_MANUAL_CONTROL, OnClickTabManualControl)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutput diagnostics

#ifdef _DEBUG
void CPaneManualControlIOMonitorOutput::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlIOMonitorOutput::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutput message handlers
void CPaneManualControlIOMonitorOutput::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitTabControl();
}

void CPaneManualControlIOMonitorOutput::InitTabControl()
{
	// Set Button Font
	m_fntTab.CreatePointFont(150, "Arial Bold");
	
	BOOL bRet = 0;
	
	m_tabManualControl.SetFont( &m_fntTab );
	
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_PMAC)
	{
#ifdef __PUSAN_LDD__
		// Output
		bRet = m_tabManualControl.AddPane( _T(" Output1 "), RUNTIME_CLASS(CPaneManualControlIOMonitorOutputSub1LDD) );
		if( FALSE != bRet )
		{
			m_pSub1 = static_cast<CPaneManualControlIOMonitorOutputSub1LDD*>(m_tabManualControl.GetPane(0));
			m_pSub1->OnInitialUpdate();
		}

// 		bRet = m_tabManualControl.AddPane( _T(" Output2 "), RUNTIME_CLASS(CPaneManualControlIOMonitorOutputSub2) );
// 		if( FALSE != bRet )
// 		{
// 			m_pSub2 = static_cast<CPaneManualControlIOMonitorOutputSub2*>(m_tabManualControl.GetPane(1));
// 			m_pSub2->OnInitialUpdate();
// 		}
#else
		// Output
		bRet = m_tabManualControl.AddPane( _T(" Output1 "), RUNTIME_CLASS(CPaneManualControlIOMonitorOutputSub1) );
		if( FALSE != bRet )
		{
			m_pSub1 = static_cast<CPaneManualControlIOMonitorOutputSub1*>(m_tabManualControl.GetPane(0));
			m_pSub1->OnInitialUpdate();
		}
		
		bRet = m_tabManualControl.AddPane( _T(" Output2 "), RUNTIME_CLASS(CPaneManualControlIOMonitorOutputSub2) );
		if( FALSE != bRet )
		{
			m_pSub2 = static_cast<CPaneManualControlIOMonitorOutputSub2*>(m_tabManualControl.GetPane(1));
			m_pSub2->OnInitialUpdate();
		}
#endif
		m_tabManualControl.ShowPane(0);
	}
}

void CPaneManualControlIOMonitorOutput::ShowTabPane(int nPaneNo)
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;
	
	if( nPaneNo >= 0 && nPaneNo < 2 )
	{
		m_tabManualControl.ShowPane( nPaneNo );
		
		m_nPaneNo = nPaneNo;
	}
}

void CPaneManualControlIOMonitorOutput::ChangeSubPane()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;

	if(m_nPaneNo == -1)
		m_nPaneNo = 0;
	m_tabManualControl.ShowPane(m_nPaneNo);
	
	switch(m_nPaneNo)
	{
	case 0:
		m_pSub1->InitTimer();
		break;
	case 1:
		m_pSub2->InitTimer();
		break;
	}
}

void CPaneManualControlIOMonitorOutput::KillSubTimer()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;

	if(m_nPaneNo == -1)
		return;
	else
	{
		switch(m_nPaneNo)
		{
		case 0:
			m_pSub1->DestroyTimer();
			break;
		case 1:
			m_pSub2->DestroyTimer();
			break;
		}
	}
}

void CPaneManualControlIOMonitorOutput::OnClickTabManualControl(NMHDR* pNMHDR, LRESULT* pResult) 
{
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->ActiveStaticForKeyboardError();

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;

	int nSel = m_tabManualControl.GetCurSel();
	
	if( nSel == m_nPaneNo )
		return;
	
	switch(m_nPaneNo)
	{
	case 0:
		m_pSub1->DestroyTimer();
		break;
	case 1:
		m_pSub2->DestroyTimer();
		break;
	}
	
	switch( nSel )
	{
	case 0:
		m_pSub1->InitTimer();
		break;
	case 1:
		m_pSub2->InitTimer();
		break;
	}
	
	m_nPaneNo = nSel;
	
	*pResult = 0;
}

void CPaneManualControlIOMonitorOutput::OnDestroy() 
{
	m_fntTab.DeleteObject();
	
	CFormView::OnDestroy();
}

BOOL CPaneManualControlIOMonitorOutput::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}
// PaneManualControlIOMonitorInputSub2.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlIOMonitorInputSub2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub2

IMPLEMENT_DYNCREATE(CPaneManualControlIOMonitorInputSub2, CFormView)

CPaneManualControlIOMonitorInputSub2::CPaneManualControlIOMonitorInputSub2()
	: CFormView(CPaneManualControlIOMonitorInputSub2::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlIOMonitorInputSub2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nTimerID = 0;
}

CPaneManualControlIOMonitorInputSub2::~CPaneManualControlIOMonitorInputSub2()
{
}

void CPaneManualControlIOMonitorInputSub2::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlIOMonitorInputSub2)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlIOMonitorInputSub2, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlIOMonitorInputSub2)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub2 diagnostics

#ifdef _DEBUG
void CPaneManualControlIOMonitorInputSub2::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlIOMonitorInputSub2::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub2 message handlers

void CPaneManualControlIOMonitorInputSub2::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
}

void CPaneManualControlIOMonitorInputSub2::UpdateStatus()
{
}

void CPaneManualControlIOMonitorInputSub2::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlIOMonitorInputSub2::InitTimer()
{
	if(m_nTimerID == 0)
		m_nTimerID = SetTimer(9972, 1000, NULL);
}

void CPaneManualControlIOMonitorInputSub2::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}
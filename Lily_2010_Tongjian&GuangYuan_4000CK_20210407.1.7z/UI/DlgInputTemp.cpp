// DlgInputTemp.cpp : implementation file
//

#include "stdafx.h"



#include "easydriller.h"
#include "DlgInputTemp.h"
#include "model\DProject.h"
#include "EasyDrillerDlg.h"
#include "UI\PaneAutoRun.h"
#include "model\DEasyDrillerINI.h"

#include "UI\PaneRecipeGenSub.h"
#include "UI\PaneRecipeGen.h"
#include "UI\PaneRecipeGenData.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInputTemp dialog


CDlgInputTemp::CDlgInputTemp(CWnd* pParent /*=NULL*/)
: CDialog(CDlgInputTemp::IDD, pParent)
{
	//}}AFX_DATA_INIT
	m_bRepairMarkingFlag=FALSE;
}


void CDlgInputTemp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_BARCODE_CONTENTS, m_editBarcodeContents);
	DDX_Control(pDX, IDC_EDIT_PNL_NO, m_editPnlNo);
	DDX_Control(pDX, IDC_EDIT_ARRAY_NO, m_editArrayNo);
	DDX_Control(pDX, IDC_EDIT_OCR_CODE, m_editLotID);
	DDX_Control(pDX, IDC_EDIT_TOP_BOTTOM, m_editTopBottom);
	DDX_Control(pDX, IDC_EDIT_PRODUCT_LOT, m_editProductLot);
	DDX_Control(pDX, IDC_EDIT_PRODUCT_PN, m_editProductPN);
	DDX_Control(pDX, IDC_EDIT_SPARE2, m_editStatic);
	DDX_Control(pDX, IDC_EDIT_CUSTOM_NO, m_editCustomerNo);
	DDX_Control(pDX, IDC_EDIT_SPARE, m_editSpare);
	DDX_Control(pDX, IDC_BTN_GET_DATA_FROM_UI, m_btnGetDataFromUI);
	DDX_Control(pDX, IDC_BTN_TEMP, m_btnGenTempData);
	DDX_Control(pDX, IDC_BTN_SET_CLEAR, m_btnClear);
	DDX_Control(pDX, IDC_OK, m_btnApplyAndClose);
	DDX_Control(pDX, IDC_CANCEL, m_btnClose);
}


BEGIN_MESSAGE_MAP(CDlgInputTemp, CDialog)
ON_BN_CLICKED(IDC_BTN_TEMP, OnBtnTemp)
ON_BN_CLICKED(IDC_OK, OnOk)
ON_BN_CLICKED(IDC_BTN_GET_DATA_FROM_UI, OnBtnGetDataFromUi)
ON_BN_CLICKED(IDC_BTN_SET_CLEAR, OnBtnSetClear)
ON_WM_SHOWWINDOW()
ON_BN_CLICKED(IDC_CANCEL, OnCancel)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInputTemp message handlers

BOOL CDlgInputTemp::Create(CWnd* pParentWnd) 
{

	return CDialog::Create(IDD, pParentWnd);
}

BOOL CDlgInputTemp::OnInitDialog() 
{
	CDialog::OnInitDialog();

	InitStaticControl();
	InitEditControl();
	InitBtnControl();
	return TRUE;  
}

void CDlgInputTemp::InitStaticControl()
{
	m_fntStatic.CreatePointFont(110, "Arial Bold");

	GetDlgItem(IDC_ST_BARCODE_CONTENTS)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_ST_ARRAY_NO)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_ST_OCR_CODE)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_ST_PRODUCT_PN)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_ST_SPARE2)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_ST_CUSTOM_NO)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_ST_PNL_NO)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_ST_SPARE)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_ST_TOP_BOTTOM)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_ST_PRODUCT_LOT)->SetFont(&m_fntStatic);
	
	
	
}
void CDlgInputTemp::InitEditControl()
{
	m_fntEdit.CreatePointFont(110, "Arial Bold");

	m_editBarcodeContents.SetFont(&m_fntEdit);
	m_editBarcodeContents.SetForeColor( BLACK_COLOR );
	m_editBarcodeContents.SetBackColor( WHITE_COLOR );

	m_editArrayNo.SetFont(&m_fntEdit);
	m_editArrayNo.SetForeColor( BLACK_COLOR );
	m_editArrayNo.SetBackColor( WHITE_COLOR );

	m_editLotID.SetFont(&m_fntEdit);
	m_editLotID.SetForeColor( BLACK_COLOR );
	m_editLotID.SetBackColor( WHITE_COLOR );

	m_editProductPN.SetFont(&m_fntEdit);
	m_editProductPN.SetForeColor( BLACK_COLOR );
	m_editProductPN.SetBackColor( WHITE_COLOR );

	m_editStatic.SetFont(&m_fntEdit);
	m_editStatic.SetForeColor( BLACK_COLOR );
	m_editStatic.SetBackColor( WHITE_COLOR );

	m_editCustomerNo.SetFont(&m_fntEdit);
	m_editCustomerNo.SetForeColor( BLACK_COLOR );
	m_editCustomerNo.SetBackColor( WHITE_COLOR );

	m_editPnlNo.SetFont(&m_fntEdit);
	m_editPnlNo.SetForeColor( BLACK_COLOR );
	m_editPnlNo.SetBackColor( WHITE_COLOR );

	m_editSpare.SetFont(&m_fntEdit);
	m_editSpare.SetForeColor( BLACK_COLOR );
	m_editSpare.SetBackColor( WHITE_COLOR );

	m_editTopBottom.SetFont(&m_fntEdit);
	m_editTopBottom.SetForeColor( BLACK_COLOR );
	m_editTopBottom.SetBackColor( WHITE_COLOR );

	m_editProductLot.SetFont(&m_fntEdit);
	m_editProductLot.SetForeColor( BLACK_COLOR );
	m_editProductLot.SetBackColor( WHITE_COLOR );

	m_editArrayNo.SetWindowText(_T("2"));
	m_editLotID.SetWindowText(_T("M12345678XX"));
	m_editProductPN.SetWindowText(_T("MZ7LN"));
	m_editStatic.SetWindowText(_T("XXXX"));
	m_editCustomerNo.SetWindowText(_T("S"));
	m_editPnlNo.SetWindowText(_T("012004"));
	m_editSpare.SetWindowText(_T("XXXX"));

	/*
	GetDlgItem(IDC_EDIT_TOP_BOTTOM)->SetWindowText(_T(""));
	GetDlgItem(IDC_EDIT_PRODUCT_LOT)->SetWindowText(_T(""));
	*/
}
void CDlgInputTemp::InitBtnControl()
{
	m_fntBtn.CreatePointFont(110, "Arial Bold");

	m_btnGetDataFromUI.SetFont( &m_fntBtn );
	m_btnGetDataFromUI.SetFlat( FALSE );
	m_btnGetDataFromUI.EnableBallonToolTip();
	m_btnGetDataFromUI.SetToolTipText( _T("Get Data From UI") );
	m_btnGetDataFromUI.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGetDataFromUI.SetBtnCursor(IDC_HAND_1);

	m_btnGenTempData.SetFont( &m_fntBtn );
	m_btnGenTempData.SetFlat( FALSE );
	m_btnGenTempData.EnableBallonToolTip();
	m_btnGenTempData.SetToolTipText( _T("Generate Temp Data") );
	m_btnGenTempData.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGenTempData.SetBtnCursor(IDC_HAND_1);

	m_btnClear.SetFont( &m_fntBtn );
	m_btnClear.SetFlat( FALSE );
	m_btnClear.EnableBallonToolTip();
	m_btnClear.SetToolTipText( _T("Clear") );
	m_btnClear.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnClear.SetBtnCursor(IDC_HAND_1);

	m_btnApplyAndClose.SetFont( &m_fntBtn );
	m_btnApplyAndClose.SetFlat( FALSE );
	m_btnApplyAndClose.EnableBallonToolTip();
	m_btnApplyAndClose.SetToolTipText( _T("Apply And Close") );
	m_btnApplyAndClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApplyAndClose.SetBtnCursor(IDC_HAND_1);

	m_btnClose.SetFont( &m_fntBtn );
	m_btnClose.SetFlat( FALSE );
	m_btnClose.EnableBallonToolTip();
	m_btnClose.SetToolTipText( _T("Close") );
	m_btnClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnClose.SetBtnCursor(IDC_HAND_1);



}


CString CDlgInputTemp::GetDlgData(int m_nIndex) 
{
	UpdateData( TRUE );
	
	CString str="";
	
	switch (m_nIndex)
	{
	case 0:
		GetDlgItem(IDC_EDIT_BARCODE_CONTENTS)->GetWindowText(str);
		break;
	case 1:
		GetDlgItem(IDC_EDIT_TOP_BOTTOM)->GetWindowText(str);
		break;
	case 2:
		GetDlgItem(IDC_EDIT_OCR_CODE)->GetWindowText(str);
		break;
	case 3:
		GetDlgItem(IDC_EDIT_PRODUCT_PN)->GetWindowText(str);
		break;
	case 4:
		GetDlgItem(IDC_EDIT_SPARE2)->GetWindowText(str);
		break;
	case 5:
		GetDlgItem(IDC_EDIT_CUSTOM_NO)->GetWindowText(str);
		break;
	case 6:
		GetDlgItem(IDC_EDIT_SPARE)->GetWindowText(str);
		break;
	}
	
	return str;	
}

void CDlgInputTemp::OnBtnTemp() 
{
	m_editBarcodeContents.SetWindowText(_T("2M12345678XXMZ7LNXXXXS012004XXXX"));
	m_editTopBottom.SetWindowText(_T("2"));
	m_editLotID.SetWindowText(_T("M12345678XX"));
	m_editProductPN.SetWindowText(_T("MZ7LN"));
	m_editStatic.SetWindowText(_T("XXXX"));
	m_editCustomerNo.SetWindowText(_T("S"));
	//m_editPnlNo.SetWindowText(_T("012004"));
	m_editSpare.SetWindowText(_T("XXXX"));

}

void CDlgInputTemp::OnOk() 
{
	// TODO: Add your control notification handler code here
	
	CString str;
	str.Format("%s",gDProject.m_szProjectName);
	
	if(!IsValidDataFormat())
		return;

	CString strTmp; //2015.12.01


	m_editTopBottom.GetWindowText(strTmp);

	int nComSol = atoi(strTmp); //2015.12.11
	if(nComSol == 2)
		nComSol = 0;

	gDProject.m_nComSol = nComSol;

	m_editLotID.GetWindowText(strTmp);
	strcpy_s(gDProject.m_szLotId, strTmp);

	m_editProductPN.GetWindowText(strTmp);
	strcpy_s(gDProject.m_szProductPN, strTmp);

	m_editStatic.GetWindowText(strTmp);
	strcpy_s(gDProject.m_szStatic, strTmp);

	m_editCustomerNo.GetWindowText(strTmp);
	strcpy_s(gDProject.m_szCustomerNo, strTmp);

	m_editSpare.GetWindowText(strTmp);
	strcpy_s(gDProject.m_szSpare, strTmp);

	/*
	//2015.11.30
	gDProject.m_sDataInfo.m_strBarcodeContents=GetDlgData(1);
	gDProject.m_sDataInfo.m_strPnlNo=GetDlgData(2);
	gDProject.m_sDataInfo.m_strArrayNo=GetDlgData(3);
	gDProject.m_sDataInfo.m_strOcrCode=GetDlgData(4);
    


	gDProject.m_sDataInfo.m_nCustom = m_cmbManageCustom.GetCurSel();


	gDProject.m_sDataInfo.m_strSpare =GetDlgData(8);//20150511
	gDProject.m_sDataInfo.m_strProductPN =GetDlgData(9);
//	gDProject.m_sDataInfo.m_strCustomNo =GetDlgData(10); 
    gDProject.m_sDataInfo.m_strCustomNo = "D";//20151001

	*/

/*
	gDProject.m_sDataInfo.m_nStartArrayNo=((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->GetCardNum_Repair(gDProject.m_sDataInfo.m_strArrayNo);//jjh 2012.02.06 Repair Marking ���� 
	
	if(gDProject.m_sDataInfo.m_nStartArrayNo<0)
	{
		gDProject.InitDataInfo();
		return;
	}
	
	if(m_bRepairMarkingFlag)
	{
		
		gDProject.m_sDataInfo.m_strRepairLot=GetDlgData(5);
		gDProject.m_sDataInfo.m_strPCS_No=GetDlgData(6);		
        ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->ChangeLotInput(TRUE);//Lot Count�� 1�� ���� 
	}
	gDProject.m_sDataInfo.m_strFileLocation=GetDlgData(7);
*/

//2015.11.30	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->DisplayDataFormat();


	   //////3.���� DB���� Data�� �����´� //////////////////////////////////////////////////////////

/*
	CString strMsg;
	strMsg.Format("�������� �ҷ��� Exellon Data�� ���� �Ͻðڽ��ϱ�?" );

	if ( IDYES == ::AfxMessageBox(strMsg, MB_YESNO ) )
	{		
		
		CString strExellonRawPath;
		CString strFTPFolderPath;
		CString strFTPFileName;
		

		strExellonRawPath= gDProject.m_sDataInfo.m_strFileLocation;

		if(strExellonRawPath=="")
		{
			AfxMessageBox("FTP �� ���� Location�� ���� ���� �ʾҽ��ϴ�");
			return;
		}

		strExellonRawPath.TrimLeft();
		strExellonRawPath.TrimRight();
		int nTotalRen = strlen(strExellonRawPath);
		
		char*	pszTemp = LPTSTR(LPCTSTR(strExellonRawPath));
		
		char buf[255];
		memset(buf, 0, 255);
		
		int m_nCount=0;
		
		for(int a=0; a<nTotalRen; a++)
		{
			if(pszTemp[a]=='/')
			{
				m_nCount=a;
				
			}
		}
		
		if(m_nCount==0)
		{
			AfxMessageBox("FTP �� ���� ��ΰ� ��Ȯ���� �ʽ��ϴ�");
			return;
		}
		
		CString TempFolderPath;
		CString TempFileName;

		TempFolderPath = strExellonRawPath.Left(m_nCount);
        TempFileName = strExellonRawPath.Right(nTotalRen-(m_nCount+1));

		strFTPFolderPath = TempFolderPath;

		//TempFileName.TrimLeft(".dat");

	
       if(!gDProject.m_bUserSelectReverse_Card) 
		strFTPFileName.Format("%s_CS.dat",TempFileName);
       else
		strFTPFileName.Format("%s_SS.dat",TempFileName);



        ////
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->m_threadMDFileSvr.Connect(strFTPFolderPath))
		{
			AfxMessageBox("FTP ���� ���� ����");
			return;
		}

		
		  if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->m_threadMDFileSvr.DownloadFile(strFTPFolderPath,strFTPFileName))
		  {
		  AfxMessageBox("FTP�� �������� Excellon File �������� �۾��� �����Ͽ����ϴ� ");
		  return;
		  }
		  
		  CString strFilePath,strNewFilePath;
		  strFilePath.Format("D:\\viahole\\Data\\%s",strFTPFileName);
		  strNewFilePath.Format("D:\\viahole\\Data_New\\%s",strFTPFileName);
		  
		  if(((CEasyDrillerDlg*)::AfxGetMainWnd())->IsFileExist(strNewFilePath) == FALSE)
		  {
			  AfxMessageBox("�������� ������ Exellon ������ �������� �ʽ��ϴ�");
			return;
		  }
		  if(((CEasyDrillerDlg*)::AfxGetMainWnd())->IsFileExist(strFilePath) == TRUE)
		  {
	    	DeleteFile(strFilePath);
			CopyFile(strNewFilePath, strFilePath, FALSE);
		  }
		  else
		  {
            CopyFile(strNewFilePath, strFilePath, FALSE);
		  }			
		
	
		  //////4.������ Excellon File�� open �Ѵ�  ////////////////////////////////////////////////
			  BOOL m_bRet=((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pDataLoad->OpenExcellonFile(strFTPFileName);
			  
			  if(!m_bRet)
			  {
				AfxMessageBox("Get Excellon Fail ");
				return;
			  }
			  BOOL m_bRet2=((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGenSub->PrjApply();
				
			if(!m_bRet2)
			{
				AfxMessageBox("New Excellon Apply Fail ");
				return;
			}	  
		
	
	}
*/
	CDialog::OnOK();
}

void CDlgInputTemp::SetRepairMarkingFlag(BOOL m_bFlag) 
{
    m_bRepairMarkingFlag=m_bFlag;
}

void CDlgInputTemp::OnCancel() 
{
	CDialog::OnCancel();
}

void CDlgInputTemp::OnBtnGetDataFromUi() 
{
	CString strBarContents, strTmp;
	strBarContents.Empty();
	strTmp.Empty();

	int nComSol = 0; //2015.12.11
	if(gDProject.m_nComSol == 0) //Comp
	{
		nComSol = 2;
	}
	else if(gDProject.m_nComSol == 1) //Sold
	{
		nComSol = 1;
	}

	strTmp.Format(_T("%d"), nComSol); //Side
	strBarContents+=strTmp;
	m_editTopBottom.SetWindowText(strTmp);
	

	strTmp.Format(_T("%s"), gDProject.m_szLotId); //Lot ID
	strTmp.MakeUpper();
	m_editLotID.SetWindowText(strTmp);
	int nTemp = 11 - strTmp.GetLength();
	for(int i = 0; i < nTemp; i++)
	{
		strTmp += "X";
	}
	strBarContents+=strTmp;
	
	strTmp.Format(_T("MZ7LN")); //PN
	strBarContents+=strTmp;
	m_editProductPN.SetWindowText(strTmp);

	strTmp.Format(_T("XXXX")); //Static
	strBarContents+=strTmp;
	m_editStatic.SetWindowText(strTmp);

	strTmp.Format(_T("S")); //Customer No
	strBarContents+=strTmp;
	m_editCustomerNo.SetWindowText(strTmp);

	strTmp.Format(_T("000000")); //Pnl No/Array No
	strBarContents+=strTmp;

	strTmp.Format(_T("XXXX")); //Spare
	strBarContents+=strTmp;
	m_editSpare.SetWindowText(strTmp);

	m_editBarcodeContents.SetWindowText(strBarContents);
}

void CDlgInputTemp::OnBtnSetClear() 
{
	
	m_editBarcodeContents.SetWindowText(_T(""));
	m_editTopBottom.SetWindowText(_T(""));
	m_editLotID.SetWindowText(_T(""));
	m_editProductPN.SetWindowText(_T(""));
	m_editStatic.SetWindowText(_T(""));
	m_editCustomerNo.SetWindowText(_T(""));
	m_editSpare.SetWindowText(_T(""));

}

BOOL CDlgInputTemp::IsValidDataFormat()
{
	CString strBarcode, strTopBottom, strLotID, strProductPN, strStatic, strCustomerNo, strSpare;
	strBarcode=GetDlgData(0);
	strTopBottom=GetDlgData(1);
	strLotID=GetDlgData(2);
	strProductPN=GetDlgData(3);
	strStatic=GetDlgData(4);
	strCustomerNo=GetDlgData(5);
	strSpare=GetDlgData(6);

	//Check Length of Data
	if(strBarcode.GetLength() != 32)
	{
		AfxMessageBox("Barcode Contents �������� ���̰� �߸� �����Ǿ����ϴ�.");
		return FALSE;
	}
	if(strTopBottom.GetLength() != 1)
	{
		AfxMessageBox("Top/Bottom �������� ���̰� �߸� ���� �Ǿ����ϴ�.");
		return FALSE;
	}
	if(strLotID.GetLength() == 0)
	{
		AfxMessageBox("Lot ID �������� ���̰� �߸� ���� �Ǿ����ϴ�.");
		return FALSE;
	}
	if(strProductPN.GetLength() != 5)
	{
		AfxMessageBox("Product PN �������� ���̰� �߸� ���� �Ǿ����ϴ�.");
		return FALSE;
	}
	if(strStatic.GetLength() != 4)
	{
		AfxMessageBox("Static �������� ���̰� �߸� ���� �Ǿ����ϴ�.");
		return FALSE;
	}
	if(strCustomerNo.GetLength() != 1)
	{
		AfxMessageBox("Customer No. �������� ���̰� �߸� ���� �Ǿ����ϴ�.");
		return FALSE;
	}
	if(strSpare.GetLength() != 4)
	{
		AfxMessageBox("Spare �������� ���̰� �߸� ���� �Ǿ����ϴ�.");
		return FALSE;
	}
	
	//Check Format of Data
	char* pszData = LPTSTR(LPCSTR(strTopBottom));
	if(pszData[0]!='2' && pszData[0]!='1')
	{
		AfxMessageBox(_T("Top/Bottom �� ������ ���� 2(Comp) Ȥ�� 1(Sold)�̿��� �մϴ�."));
		return FALSE;
	}

	pszData = LPTSTR(LPCSTR(strProductPN));
	for(int i=0; i<strlen(pszData); i++)
	{
		if((pszData[i]<'A' || pszData[i]>'Z')
			&& (pszData[i]<'0' || pszData[i]>'9'))
		{
			AfxMessageBox(_T("Product PN �� ������ ���� �������� �Դϴ�."));
			return FALSE;
		}
	}

	pszData = LPTSTR(LPCSTR(strStatic));
	for(int i=0; i<strlen(pszData); i++)
	{
		if((pszData[i]<'A' || pszData[i]>'Z')
			&& (pszData[i]<'0' || pszData[i]>'9'))
		{
			AfxMessageBox(_T("Static �� ������ ���� �������� �Դϴ�."));
			return FALSE;
		}
	}

	pszData = LPTSTR(LPCSTR(strCustomerNo));
	if((pszData[0]<'A' || pszData[0]>'Z')
		&& (pszData[0]<'0' || pszData[0]>'9'))
	{
		AfxMessageBox(_T("Customer No. �� ������ ���� �������� �Դϴ�."));
		return FALSE;
	}

	pszData = LPTSTR(LPCSTR(strSpare));
	for(int i=0; i<strlen(pszData); i++)
	{
		if((pszData[i]<'A' || pszData[i]>'Z')
			&& (pszData[i]<'0' || pszData[i]>'9'))
		{
			AfxMessageBox(_T("Spare �� ������ ���� �������� �Դϴ�."));
			return FALSE;
		}
	}

	pszData = NULL;
	return TRUE;
}

BOOL CDlgInputTemp::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
		  if(WM_KEYDOWN == pMsg->message)
		  {
			  
			  if(VK_RETURN == pMsg->wParam)
			  {
				 // AfxMessageBox("");
				  return TRUE;
			  }
			  
		  }
	return CDialog::PreTranslateMessage(pMsg);
}
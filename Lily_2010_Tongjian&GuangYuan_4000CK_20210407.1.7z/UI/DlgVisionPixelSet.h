#if !defined(AFX_DLGVISIONPIXELSET_H__5ED14BF8_4250_4989_B44F_43B6880BAF5A__INCLUDED_)
#define AFX_DLGVISIONPIXELSET_H__5ED14BF8_4250_4989_B44F_43B6880BAF5A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgVisionPixelSet.h : header file
//

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgVisionPixelSet dialog

class CDlgVisionPixelSet : public CDialog
{
// Construction
public:
	CDlgVisionPixelSet(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgVisionPixelSet)
	enum { IDD = IDD_DLG_PIXEL_SET };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgVisionPixelSet)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL


public:
	void GetData(DPOINT* pOriPos, DPOINT* pTransPos);
	void SetData(DPOINT* OriPos, DPOINT* TransPos);
	void DispPosData();
	void InitStaticControl();
	void InitEditControl();
	void InitBtnControl();
	UEasyButtonEx	m_btnApply;
	UEasyButtonEx	m_btnCancel;
	UEasyButtonEx	m_btnUpdate;
	UEasyButtonEx	m_btnInit;
	CColorEdit		m_edtPos1X1;
	CColorEdit		m_edtPos1Y1;
	CColorEdit		m_edtPos1X2;
	CColorEdit		m_edtPos1Y2;
	CColorEdit		m_edtPos2X1;
	CColorEdit		m_edtPos2Y1;
	CColorEdit		m_edtPos2X2;
	CColorEdit		m_edtPos2Y2;
	CColorEdit		m_edtPos3X1;
	CColorEdit		m_edtPos3Y1;
	CColorEdit		m_edtPos3X2;
	CColorEdit		m_edtPos3Y2;
	CColorEdit		m_edtPos4X1;
	CColorEdit		m_edtPos4Y1;
	CColorEdit		m_edtPos4X2;
	CColorEdit		m_edtPos4Y2;
	CComboBox		m_cmbCam;
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	CFont			m_fntBtn;

	DPOINT			m_dOriPos[MAX_CAMERA][4];//[ī�޶�][������].x
	DPOINT			m_dTransPos[MAX_CAMERA][4];

	int				m_nCamNo;
// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgVisionPixelSet)
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonUpdate();
	afx_msg void OnEditchangeComboCam();
	afx_msg void OnSelchangeComboCam();
	afx_msg void OnButtonInit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGVISIONPIXELSET_H__5ED14BF8_4250_4989_B44F_43B6880BAF5A__INCLUDED_)

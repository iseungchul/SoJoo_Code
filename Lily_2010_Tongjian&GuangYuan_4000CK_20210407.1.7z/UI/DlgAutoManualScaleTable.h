
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgAutoManualScaleTable.h : header file
//

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "UEasyButtonEx.h"
#include "resource.h"
#include "easydriller.h"
#include "..\MODEL\AutoManualScaleINIFile.h"
#include "..\MODEL\DAutoManualScaleINI.h"
//#include "GridCtrl_src\GridCtrl.h"
#include "GridCtrl.h"

#define		TABLE0  0
#define		TABLE1  1

#define		TABLE0_COLUMN_COUNT 2
#define		TABLE1_COLUMN_COUNT 28

#define		COLUMNWIDTH  13	// �÷��� �ѱ��ڴ� �Ҵ�Ǵ� ������ ���� 

#define		TABLETEXT_COLOR		RGB(0,0,0)
#define		TABLE1_COLOR		RGB(255,255,255)
#define		TABLE2_COLOR		RGB(230,230,230)
/////////////////////////////////////////////////////////////////////////////
// CDlgAutoManualScaleTable dialog

class CDlgAutoManualScaleTable : public CDialog
{
	DECLARE_DYNAMIC(CDlgAutoManualScaleTable)
// Construction
public:
	CDlgAutoManualScaleTable(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgAutoManualScaleTable();
// Dialog Data
	//{{AFX_DATA(CDlgAutoManualScaleTable)
	enum { IDD = IDD_DLG_AUTO_MANUAL_SCALE_TABLE };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgAutoManualScaleTable)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Operation
public :
	void			InitBtnControl();
	void			InitGrid();
	void			InitEditControl();
	void			InsertGridValue(GV_ITEM Gvitem, int startNo, int TableNo, int ColCount);
	void			InsertListComumn(int startNo, int TableNo);
	void			SetDrawMember(int listcount);
	void			FillTable0Data(int x, int y, CString str);
	void			FillTable1Data(int x, int y, CString str);
	void			ListUpdate(CPoint ClickedPos, CString str);
	void			OnKillfocusEditGrid();
	void			OnCheckRefresh();
	void			SetAutoManualScale(SAUTOMANUALSCALE sAutoManualScale);
	void			GetAutoManualScale(SAUTOMANUALSCALE* pAutoManualScale);

	int				m_nUserLevel;

	CString strTable0[TABLE0_COLUMN_COUNT];// = {"No", "ToolPowerComepn"};
	CString strTable1[TABLE1_COLUMN_COUNT];

// Attribute
	CFont					m_fntBtn;
	CFont					m_fntStatic;
	CFont					m_fntEdit;
	UEasyButtonEx		m_btnSave;
	CComboBox			m_cmbComSol;
	int						m_nColumnCount;
	CGridCtrl				m_Grid;
	CPoint				m_posClicked;

	CColorEdit	m_edtDailyPowerCompenStartTime;
	CColorEdit	m_edtDailyPowerCompenEndTime;

	SAUTOMANUALSCALE		m_sAutoManualScale;
// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgAutoManualScaleTable)
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonSave();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
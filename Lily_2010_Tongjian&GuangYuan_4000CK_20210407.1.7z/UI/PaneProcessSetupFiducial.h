#if !defined(AFX_PANEPROCESSSETUPFIDUCIAL_H__4B552125_21B0_4BA6_98B0_909D31968391__INCLUDED_)
#define AFX_PANEPROCESSSETUPFIDUCIAL_H__4B552125_21B0_4BA6_98B0_909D31968391__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneProcessSetupFiducial.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupFiducial form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "ColorEdit.h"

class CPaneProcessSetupFiducial : public CFormView
{
protected:
	CPaneProcessSetupFiducial();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneProcessSetupFiducial)

// Form Data
public:
	//{{AFX_DATA(CPaneProcessSetupFiducial)
	enum { IDD = IDD_DLG_PROCESS_SETUP_FIDUCIAL };
	CColorEdit	m_edtMoveLenHighY;
	CColorEdit	m_edtMoveLenHighX;
	UEasyButtonEx	m_chkAutoProcessFidRecheck;
	UEasyButtonEx	m_chkAllFidParam;
	UEasyButtonEx	m_chkUseCompensation;
	UEasyButtonEx	m_chkUseOperRun;
	CComboBox	m_cmbFidNum;
	CComboBox	m_cmbHoleCount;
	CComboBox	m_cmbAreaCount;
	CColorEdit	m_edtTotalRetrial;
	CColorEdit	m_edtFidAngle;
	CColorEdit	m_edtPCBLenTolerance;
	CColorEdit	m_edtPCBLenTolerance2;
	CColorEdit	m_edtMoveLenY;
	CColorEdit	m_edtMoveLenX;
	CColorEdit	m_edtRecheckTolerance;
	CColorEdit	m_edtRefPosX;
	CColorEdit	m_edtRefPosY;
	CColorEdit	m_edtRefPosX2;
	CColorEdit	m_edtRefPosY2;
	CColorEdit	m_edtRefPosX3;
	CColorEdit	m_edtRefPosY3;
	CColorEdit	m_edtNearPosX;
	CColorEdit	m_edtNearPosX2;
	CColorEdit	m_edtNearPosY;
	CColorEdit	m_edtNearPosY2;
	CColorEdit	m_edtPreLimit;
	CColorEdit	m_edtScaleMinusLimit;
	CColorEdit	m_edtScalePlusLimit;

	CColorEdit m_edtDiagonalScaleMinusLimit;
	CColorEdit m_edtDiagonalScalePlusLimit;
	CColorEdit	m_edtPostLimit;
	CColorEdit	m_edtOperRunLimit;
	CColorEdit	m_edtSize;
	CColorEdit	m_edtRatio;
	CColorEdit	m_edtRotation;
	//}}AFX_DATA

// Attributes
public:

// Attributes
protected :
	CFont		m_fntStatic;
	CFont		m_fntEdit;
	CFont		m_fntCombo;
	CFont		m_fntBtn;

	SPROCESSFIDFIND		m_sProcessFidFind;
	int			m_nFidFindMethod[2];
	int			m_nUserLevel;
	BOOL		m_bHoleFindAreaPos[9];
	BOOL		m_bHoleFindHolePos[9];
// Operations
public:
	BOOL SetAcceptScore();
	CString GetChangeValueStr();
	void InitStaticControl();
	void InitEditControl();
	void InitComboControl();
	void InitBtnControl();

	void SetProcessFidFind(SPROCESSFIDFIND sProcessFidFind);
	void GetProcessFidFind(SPROCESSFIDFIND* pProcessFidFind);
	void DispProcessFidFind();
	BOOL OnApply();
	
	void EnableControl(BOOL bUse);
	void SetAuthorityByLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneProcessSetupFiducial)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneProcessSetupFiducial();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneProcessSetupFiducial)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	afx_msg void OnCheckAutoProcessFidRecheck();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedStaticAcceptScore();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEPROCESSSETUPFIDUCIAL_H__4B552125_21B0_4BA6_98B0_909D31968391__INCLUDED_)

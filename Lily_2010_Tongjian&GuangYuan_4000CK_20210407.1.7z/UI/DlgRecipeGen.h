#if !defined(AFX_DLGRECIPEGEN_H__604C9ABC_9B6A_41B5_889A_EABBBDC3B000__INCLUDED_)
#define AFX_DLGRECIPEGEN_H__604C9ABC_9B6A_41B5_889A_EABBBDC3B000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgRecipeGen.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGen form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "USimpleTab.h"
#include "UEasyButtonEx.h"
#include "ColorStatic.h"
#include "..\Model\DProject.h"

class	CPaneRecipeGenLayoutEasy;
class	CPaneRecipeGenDataEasy;
class	CPaneRecipeGenParameterNewEasy;
//class	CPaneRecipeGenFiducialNew;


class CDlgRecipeGen : public CDialog
{
DECLARE_DYNCREATE(CDlgRecipeGen)

// Form Data
public:
		  	CDlgRecipeGen(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgRecipeGen();
	enum { IDD = IDD_DLG_RECIPE_GEN_EASY };
	CColorStatic	m_stcCadPath;
	UEasyButtonEx	m_btnCadData;
	USimpleTab	m_tabRecipe;
	//}}AFX_DATA

// Attributes
public:
	BOOL	m_bProjectOpen;
	int			m_nPaneNo;

// Operations
public:
	void EnableTab(BOOL bEnable);
	BOOL SortArea();
	int	GetShowPane() {return m_nPaneNo;};
	void ShowTabPane(int nPaneNo);
	void OnMoveVisionView();
	void SetDataLoadStep(int nStep);
	void SetWindowForSkiving(BOOL bSkiving);
	void SetFocusViewer();
	BOOL CheckSameName(CString strPath);

	CPaneRecipeGenDataEasy*			m_pDataLoad;
	CPaneRecipeGenLayoutEasy*		m_pLayout;


	CPaneRecipeGenParameterNewEasy* m_pParamNew;
	//CPaneRecipeGenFiducialNew*	m_pFiducialNew;


	BOOL ApplyProject();
	BOOL OpenProject(CString strPath);
	BOOL SetData();
	BOOL SaveProject(CString strPath);
	void InitTabControl();
	void InitBtnControl();
	void InitStaticControl();
	void GetDutyOffset();
	void SetDutyOffset();

	void SetAuthorityByLevel(int nLevel);
	void ChangeProjectInfo(CString strTotalHoleCnt);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgRecipeGen)
public:
	virtual BOOL Create(CWnd* pParentWnd);

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:


	CFont						m_fntTab;
	CFont						m_fntBtn;
	CFont						m_fntStatic;
	DProject					m_DProject;

	// Generated message map functions
	//{{AFX_MSG(CDlgRecipeGen)
		virtual BOOL OnInitDialog();
	afx_msg void OnButtonCadData();
	afx_msg void OnClickTabRecipe(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGRECIPEGEN_H__604C9ABC_9B6A_41B5_889A_EABBBDC3B000__INCLUDED_)

#if !defined(AFX_DLGCHANGEFIELD_H__BEA05DBB_39DF_4EA8_9F50_A6710C115A7F__INCLUDED_)
#define AFX_DLGCHANGEFIELD_H__BEA05DBB_39DF_4EA8_9F50_A6710C115A7F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgChangeField.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgChangeField dialog

class CDlgChangeField : public CDialog
{
// Construction
public:
	CDlgChangeField(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgChangeField)
	enum { IDD = IDD_CHANGE_FIELD };
	double	m_dFieldSizeX;
	double	m_dFieldSizeY;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgChangeField)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CFont	m_dlgFont;
	CFont	m_editFont;
	CFont	m_btnFont;

	void SetDlgFont();

	// Generated message map functions
	//{{AFX_MSG(CDlgChangeField)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeEdtFieldSizeX();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCHANGEFIELD_H__BEA05DBB_39DF_4EA8_9F50_A6710C115A7F__INCLUDED_)

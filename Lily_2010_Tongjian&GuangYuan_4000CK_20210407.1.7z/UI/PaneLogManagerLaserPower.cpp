// PaneLogManagerLaserPower.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneLogManagerLaserPower.h"
#include <cfloat>
#include "..\Model\DEasyDrillerIni.h"
#include "..\model\dsystemini.h"
#include "..\model\dbeampathini.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const double		NONE_DATA	= DBL_MAX;

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerLaserPower

IMPLEMENT_DYNCREATE(CPaneLogManagerLaserPower, CFormView)

CPaneLogManagerLaserPower::CPaneLogManagerLaserPower()
	: CFormView(CPaneLogManagerLaserPower::IDD)
{
	//{{AFX_DATA_INIT(CPaneLogManagerLaserPower)
	m_ctEnd = CTime::GetCurrentTime();
	m_ctStart = CTime::GetCurrentTime();
	m_nSelectHead = -1;
	//}}AFX_DATA_INIT

	m_bShow			= FALSE;
	m_bOnTimer		= FALSE;

	m_nTimerID		= 0;

	m_logFont.lfHeight = 140;
	m_logFont.lfWidth = 0;
	m_logFont.lfEscapement = 0;
	m_logFont.lfOrientation = 0;
	m_logFont.lfWeight = FW_NORMAL;
	m_logFont.lfItalic = FALSE;
	m_logFont.lfStrikeOut = FALSE;
	m_logFont.lfUnderline = FALSE;
	m_logFont.lfCharSet = DEFAULT_CHARSET;
	m_logFont.lfOutPrecision = OUT_CHARACTER_PRECIS;
	m_logFont.lfClipPrecision = OUT_CHARACTER_PRECIS;
	m_logFont.lfQuality = DEFAULT_QUALITY;
	m_logFont.lfPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE;
	lstrcpy(m_logFont.lfFaceName, DEF_FONT_FACE_NAME);

	m_dSetMin = 99999;
	m_dSetMax = 0;
	m_nBeamPath = gBeamPathINI.m_sBeampath.nLastIndex + 1;
	m_nShot = 0;
}

CPaneLogManagerLaserPower::~CPaneLogManagerLaserPower()
{
}

void CPaneLogManagerLaserPower::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneLogManagerLaserPower)
	DDX_Control(pDX, IDC_LIST_POWER_TRAND, m_listPowerTrend);
	DDX_Control(pDX, IDC_DATETIMEPICKER_START, m_dtcStart);
	DDX_Control(pDX, IDC_DATETIMEPICKER_END, m_dtcEnd);
	DDX_Control(pDX, IDC_COMBO_HEAD, m_cmbHead);
	DDX_Control(pDX, IDC_BUTTON_VIEW, m_btnView);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER_END, m_ctEnd);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER_START, m_ctStart);
	DDX_CBIndex(pDX, IDC_COMBO_HEAD, m_nSelectHead);
	DDX_Control(pDX, IDC_COMBO_BEAMPATH, m_cmbBeamPath);
	DDX_Control(pDX, IDC_COMBO_SHOT, m_cmbShot);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneLogManagerLaserPower, CFormView)
	//{{AFX_MSG_MAP(CPaneLogManagerLaserPower)
	ON_WM_TIMER()
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BUTTON_VIEW, OnButtonView)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_CBN_SELCHANGE(IDC_COMBO_BEAMPATH, &CPaneLogManagerLaserPower::OnCbnSelchangeComboBeampath)
	ON_CBN_SELCHANGE(IDC_COMBO_SHOT, &CPaneLogManagerLaserPower::OnCbnSelchangeComboShot)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerLaserPower diagnostics

#ifdef _DEBUG
void CPaneLogManagerLaserPower::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneLogManagerLaserPower::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerLaserPower message handlers

void CPaneLogManagerLaserPower::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitStaticControl();
	InitListControl();
	InitEtcControl();
	
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		m_cmbHead.SetCurSel(0);
		m_cmbHead.EnableWindow(FALSE);
		m_nSelectHead = 0;
	}
}

BOOL CPaneLogManagerLaserPower::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneLogManagerLaserPower::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// View
	m_btnView.SetFont( &m_fntBtn );
	m_btnView.SetFlat( FALSE );
	m_btnView.EnableBallonToolTip();
	m_btnView.SetToolTipText( _T("View") );
	m_btnView.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnView.SetBtnCursor(IDC_HAND_1);

	if(m_nTimerID == 0)
		m_nTimerID = SetTimer(501, 300, NULL);
}

void CPaneLogManagerLaserPower::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_STATIC_1)->SetFont( &m_fntStatic );
}

void CPaneLogManagerLaserPower::InitListControl()
{
	// Set List Font
	m_fntList.CreatePointFont(130, "Arial Bold");

	m_listPowerTrend.SetFont(&m_fntList);

	m_listPowerTrend.SetExtendedStyle(m_listPowerTrend.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);

	m_ImageList.DeleteImageList();
	m_ImageList.Create(IDB_SMALL_TYPE, 16, 1, RGB(0, 0, 0));
	
	m_listPowerTrend.DeleteAllItems();
	m_listPowerTrend.SetImageList(&m_ImageList, LVSIL_SMALL);

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		lstrcpy(m_lpszColumnHead[0], " Date ");
		lstrcpy(m_lpszColumnHead[1], " Time ");
		lstrcpy(m_lpszColumnHead[2], " 1st PNL ");
		lstrcpy(m_lpszColumnHead[3], " 2nd PNL ");
		lstrcpy(m_lpszColumnHead[4], " Freq(hz) ");
		lstrcpy(m_lpszColumnHead[5], " Att.1 ");
		lstrcpy(m_lpszColumnHead[6], " Att.2 ");
		lstrcpy(m_lpszColumnHead[7], " Curr.(%) ");
		lstrcpy(m_lpszColumnHead[8], " Therm.Track ");
		lstrcpy(m_lpszColumnHead[9], " 1st Z ");
		lstrcpy(m_lpszColumnHead[10], " 2nd Z ");
		
		m_listPowerTrend.InsertColumn(0, _T(" "), LVCFMT_CENTER, 1);
		m_listPowerTrend.InsertColumn(1, m_lpszColumnHead[0], LVCFMT_CENTER, 100);
		m_listPowerTrend.InsertColumn(2, m_lpszColumnHead[1], LVCFMT_CENTER, 90);
		m_listPowerTrend.InsertColumn(3, m_lpszColumnHead[2], LVCFMT_RIGHT, 70);
		m_listPowerTrend.InsertColumn(4, m_lpszColumnHead[3], LVCFMT_RIGHT, 70);
		m_listPowerTrend.InsertColumn(5, m_lpszColumnHead[4], LVCFMT_RIGHT, 95);
		m_listPowerTrend.InsertColumn(6, m_lpszColumnHead[5], LVCFMT_RIGHT, 70);
		m_listPowerTrend.InsertColumn(7, m_lpszColumnHead[6], LVCFMT_RIGHT, 70);
		m_listPowerTrend.InsertColumn(8, m_lpszColumnHead[7], LVCFMT_RIGHT, 95);
		m_listPowerTrend.InsertColumn(9, m_lpszColumnHead[8], LVCFMT_RIGHT, 120);
		m_listPowerTrend.InsertColumn(10, m_lpszColumnHead[9], LVCFMT_RIGHT, 70);
		m_listPowerTrend.InsertColumn(11, m_lpszColumnHead[10], LVCFMT_RIGHT, 70);
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		lstrcpy(m_lpszColumnHead[0], " Date ");
		lstrcpy(m_lpszColumnHead[1], " Time ");
		lstrcpy(m_lpszColumnHead[2], " 1st PNL ");
		lstrcpy(m_lpszColumnHead[3], " 2nd PNL ");
		lstrcpy(m_lpszColumnHead[4], " Freq(hz) ");
		lstrcpy(m_lpszColumnHead[5], " Width(%) ");
		lstrcpy(m_lpszColumnHead[6], " Current ");
		lstrcpy(m_lpszColumnHead[7], " Z1 ");
		lstrcpy(m_lpszColumnHead[8], " Z2 ");
		
		m_listPowerTrend.InsertColumn(0, _T(" "), LVCFMT_CENTER, 1);
		m_listPowerTrend.InsertColumn(1, m_lpszColumnHead[0], LVCFMT_CENTER, 105);
		m_listPowerTrend.InsertColumn(2, m_lpszColumnHead[1], LVCFMT_CENTER, 105);
		m_listPowerTrend.InsertColumn(3, m_lpszColumnHead[2], LVCFMT_RIGHT, 105);
		m_listPowerTrend.InsertColumn(4, m_lpszColumnHead[3], LVCFMT_RIGHT, 105);
		m_listPowerTrend.InsertColumn(5, m_lpszColumnHead[4], LVCFMT_RIGHT, 105);
		m_listPowerTrend.InsertColumn(6, m_lpszColumnHead[5], LVCFMT_RIGHT, 105);
		m_listPowerTrend.InsertColumn(7, m_lpszColumnHead[6], LVCFMT_RIGHT, 105);
		m_listPowerTrend.InsertColumn(8, m_lpszColumnHead[7], LVCFMT_RIGHT, 120);
		m_listPowerTrend.InsertColumn(9, m_lpszColumnHead[8], LVCFMT_RIGHT, 120);
	}
	else
	{
		lstrcpy(m_lpszColumnHead[0], " Date ");
		lstrcpy(m_lpszColumnHead[1], " Time ");
		lstrcpy(m_lpszColumnHead[2], " 1st PNL ");
		lstrcpy(m_lpszColumnHead[3], " 2nd PNL ");
		lstrcpy(m_lpszColumnHead[4], " Min ");
		lstrcpy(m_lpszColumnHead[5], " Max ");
		lstrcpy(m_lpszColumnHead[6], " Freq(hz) ");
#ifdef __3RDAOD__
		lstrcpy(m_lpszColumnHead[7], " LM ");	
#else
		lstrcpy(m_lpszColumnHead[7], " LM, AD, AL(us) ");
#endif
		lstrcpy(m_lpszColumnHead[8], " BeamPath ");
		lstrcpy(m_lpszColumnHead[9], " Mask");
		lstrcpy(m_lpszColumnHead[10], " Z1 ");
		lstrcpy(m_lpszColumnHead[11], " Z2 ");
		lstrcpy(m_lpszColumnHead[12], " Shot ");
		lstrcpy(m_lpszColumnHead[13], " RefPower ");
		lstrcpy(m_lpszColumnHead[14], " PowerTol ");

		m_listPowerTrend.InsertColumn(0, _T(" "), LVCFMT_CENTER, 1);
		m_listPowerTrend.InsertColumn(1, m_lpszColumnHead[0], LVCFMT_CENTER, 105);
		m_listPowerTrend.InsertColumn(2, m_lpszColumnHead[1], LVCFMT_CENTER, 105);
		m_listPowerTrend.InsertColumn(3, m_lpszColumnHead[2], LVCFMT_RIGHT, 85);
		m_listPowerTrend.InsertColumn(4, m_lpszColumnHead[3], LVCFMT_RIGHT, 95);
		m_listPowerTrend.InsertColumn(5, m_lpszColumnHead[4], LVCFMT_RIGHT, 65);
		m_listPowerTrend.InsertColumn(6, m_lpszColumnHead[5], LVCFMT_RIGHT, 65);
		m_listPowerTrend.InsertColumn(7, m_lpszColumnHead[6], LVCFMT_RIGHT, 90);
#ifdef __3RDAOD__
		m_listPowerTrend.InsertColumn(8, m_lpszColumnHead[7], LVCFMT_RIGHT, 60);
#else
		m_listPowerTrend.InsertColumn(8, m_lpszColumnHead[7], LVCFMT_RIGHT, 150);
#endif
		m_listPowerTrend.InsertColumn(9, m_lpszColumnHead[8], LVCFMT_RIGHT, 120);
		m_listPowerTrend.InsertColumn(10, m_lpszColumnHead[9], LVCFMT_RIGHT, 60);
		m_listPowerTrend.InsertColumn(11, m_lpszColumnHead[10], LVCFMT_RIGHT, 60);
		m_listPowerTrend.InsertColumn(12, m_lpszColumnHead[11], LVCFMT_RIGHT, 60);
		m_listPowerTrend.InsertColumn(13, m_lpszColumnHead[12], LVCFMT_RIGHT, 60);
		m_listPowerTrend.InsertColumn(14, m_lpszColumnHead[13], LVCFMT_RIGHT, 120);
		m_listPowerTrend.InsertColumn(15, m_lpszColumnHead[14], LVCFMT_RIGHT, 120);
	}
}

void CPaneLogManagerLaserPower::InitEtcControl()
{
	// Set Etc Font
	m_fntEtc.CreatePointFont(150, "Arial Bold");

	m_cmbHead.SetFont( &m_fntEtc );
	m_nSelectHead = 2;
	m_cmbHead.ResetContent();
	m_cmbHead.AddString(_T("1'st PNL"));
	m_cmbHead.AddString(_T("2'nd PNL"));
	m_cmbHead.AddString(_T("Both"));
	m_cmbHead.SetCurSel(m_nSelectHead);

	m_cmbBeamPath.SetFont( &m_fntEtc );
	SetToolComboBox();
	m_cmbBeamPath.SetCurSel(gBeamPathINI.m_sBeampath.nLastIndex + 1);
	m_dtcStart.SetFont( &m_fntEtc );
	m_dtcEnd.SetFont( &m_fntEtc );

	m_cmbShot.SetFont( &m_fntEtc );
	SetShotComboBox();
	m_cmbShot.SetCurSel(0);
}

void CPaneLogManagerLaserPower::OnTimer(UINT nIDEvent) 
{
	if( m_bOnTimer )
	{
		CFormView::OnTimer(nIDEvent);
		return;
	}

	m_bOnTimer = FALSE;

	switch(nIDEvent)
	{
	case 501:
		if (!m_bShow)
		{
			ShowBackGround();
			m_bShow = TRUE;
		}
		else
		{
			if(m_nTimerID)
			{
				KillTimer(m_nTimerID);
				m_nTimerID = 0;
			}
		}
		break;
	default:
		break;
	}

	m_bOnTimer = FALSE;

	CFormView::OnTimer(nIDEvent);
}

void CPaneLogManagerLaserPower::ShowBackGround()
{
	CClientDC dc(GetDlgItem(IDC_TREND_GRAPH));
	CRect cRect;
	GetDlgItem(IDC_TREND_GRAPH)->GetClientRect(&cRect);
	CBrush cBr(RGB(0, 0, 0));
	dc.FrameRect(&cRect, &cBr);
	cRect.DeflateRect(1, 1);
	dc.FillSolidRect(&cRect, RGB(255, 255, 255));
}

void CPaneLogManagerLaserPower::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	if (m_bShow)
		ShowGraph();
}

void CPaneLogManagerLaserPower::ShowGraph()
{
	CWnd* pGraph = GetDlgItem(IDC_TREND_GRAPH);
	CClientDC dc(pGraph);
	CRect cRect;
	pGraph->GetClientRect(&cRect);
	cRect.DeflateRect(1, 1);
	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	dc.SelectClipRgn(&cRgn);
	dc.FillSolidRect(&cRect, RGB(255, 255, 255));

	int nXRange = m_listPowerTrend.GetItemCount();
	if (nXRange <= 1)
		return;

	const int nX = 1300;
	double dXUnit = 1000.0 / (nXRange - 1);

	double dTempMax, dTempMin;

	dTempMax = max(m_dMax, m_dSetMax);
	dTempMin = min(m_dMin, m_dSetMin);
	double dYRange = dTempMax - dTempMin;//(m_dMax - m_dMin);
	if (dYRange == 0.0)
	{
		m_dMax += 2.0;
		dYRange = 2.0;
	}

	const int nY = 1600;
	double dYUnit = 1000.0 / dYRange;

	int nXOffset = static_cast<int>(cRect.Width() / static_cast<double>(12) + 0.5);
	int nYOffset = static_cast<int>(cRect.Height() / static_cast<double>(16) + 0.5);

	dc.SetMapMode(MM_ANISOTROPIC);
	dc.SetWindowOrg(0, 0);
	dc.SetViewportOrg(nXOffset, cRect.Height() - 2 * nYOffset);
	dc.SetViewportExt(cRect.Width(), -cRect.Height());
	dc.SetWindowExt(nX, nY);



	if (m_nSelectHead == 1 || m_nSelectHead == 2) //slave
	{
		CPen pen(PS_SOLID, 20, RGB(0, 0, 255));
		CPen* pOldPen = dc.SelectObject(&pen);

		CString strVal;
		bool bFirst = true;
		for (int i = 0; i < nXRange; i++)
		{
			strVal = m_listPowerTrend.GetItemText(i, 4);
			double dVal = atof(strVal);
			dVal -= dTempMin;
#ifdef __TEST__
			if (dVal < 0)
				dVal = 0.0;
#endif

			if (bFirst)
			{
				dc.MoveTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
				bFirst = false;
			}
			else
				dc.LineTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
		}

		dc.MoveTo(600, 1250);
		dc.LineTo(800, 1250);
		CFont cFont, *pOldFont;
		cFont.CreateFontIndirect(&m_logFont);
		pOldFont = dc.SelectObject(&cFont);
		dc.TextOut(830, 1320, _T("2'nd PNL"));
		dc.SelectObject(pOldFont);
		dc.SelectObject(pOldPen);
	}

	if (m_nSelectHead == 0 || m_nSelectHead == 2) //master
	{
		CPen pen(PS_SOLID, 20, RGB(255, 0, 0));
		CPen* pOldPen = dc.SelectObject(&pen);

		CString strVal;
		bool bFirst = true;
		for (int i = 0; i < nXRange; i++)
		{
			strVal = m_listPowerTrend.GetItemText(i, 3);
			double dVal = atof(strVal);
			dVal -= dTempMin;
#ifdef __TEST__
			if (dVal < 0)
				dVal = 0.0;
#endif

			if (bFirst)
			{
				dc.MoveTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
				bFirst = false;
			}
			else
				dc.LineTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
		}

		dc.MoveTo(100, 1250);
		dc.LineTo(300, 1250);
		CFont cFont, *pOldFont;
		cFont.CreateFontIndirect(&m_logFont);
		pOldFont = dc.SelectObject(&cFont);
		dc.TextOut(330, 1320, _T("1'st PNL"));
		dc.SelectObject(pOldFont);
		dc.SelectObject(pOldPen);
	}
	
	//min max 
	{
		CPen penMin(PS_DOT, 1, RGB(105,185,211));
		CPen* pOldPen = dc.SelectObject(&penMin);
		CString strVal;
		bool bFirst = true;
		for (int i = 0; i < nXRange; i++)
		{
			strVal = m_listPowerTrend.GetItemText(i, 5);
			double dVal = atof(strVal);
			dVal -= dTempMin;
#ifdef __TEST__
			if (dVal < 0)
				dVal = 0.0;
#endif

			if (bFirst)
			{
				dc.MoveTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
				bFirst = false;
			}
			else
				dc.LineTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
		}

		
		dc.SelectObject(pOldPen);
	}
	//min max 
	{
		CPen penMin(PS_DOT, 1, RGB(250,150,70));
		CPen* pOldPen = dc.SelectObject(&penMin);
		CString strVal;
		bool bFirst = true;
		for (int i = 0; i < nXRange; i++)
		{
			strVal = m_listPowerTrend.GetItemText(i, 6);
			double dVal = atof(strVal);
			dVal -= dTempMin;
#ifdef __TEST__
			if (dVal < 0)
				dVal = 0.0;
#endif

			if (bFirst)
			{
				dc.MoveTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
				bFirst = false;
			}
			else
				dc.LineTo(static_cast<int>(dXUnit * i + 0.5) + 50, static_cast<int>(dVal * dYUnit + 0.5) + 100);
		}


		dc.SelectObject(pOldPen);
	}

	// �ѷ��δ� �簢�� �׸���
	dc.MoveTo(0, 0);
	dc.LineTo(1100, 0);
	dc.LineTo(1100, 1150);
	dc.LineTo(0, 1150);
	dc.LineTo(0, 0);

	// X ��
	CString strVal;
	for (int i = 0; i < nXRange; i++)
	{
		if (i == 0 || i == (nXRange - 1) / 2 || i == nXRange - 1)
		{
			strVal = m_listPowerTrend.GetItemText(i, 1);
			int n = strVal.Find(_T('/'));
			strVal = strVal.Right(strVal.GetLength() - n - 1);
			if (strVal[0] == _T('0'))
				strVal.SetAt(0, _T(' '));

			LOGFONT logFont = m_logFont;
			logFont.lfHeight = 120;
			
			CFont cfDate, *pOldFont;
			cfDate.CreateFontIndirect(&logFont);
			pOldFont = dc.SelectObject(&cfDate);
			dc.TextOut(static_cast<int>(dXUnit * i + 0.5), -10, strVal);
			dc.SelectObject(pOldFont);
			
			dc.MoveTo(static_cast<int>(dXUnit * i + 0.5) + 50, 0);
			dc.LineTo(static_cast<int>(dXUnit * i + 0.5) + 50, 30);
		}
	}

	// Y ��
	dc.MoveTo(0, 100);
	dc.LineTo(15, 100);
	strVal.Format(_T("%.1f"), dTempMin);

	LOGFONT logFont = m_logFont;
	logFont.lfHeight = 120;
	
	CFont cfDate, *pOldFont;
	cfDate.CreateFontIndirect(&logFont);
	pOldFont = dc.SelectObject(&cfDate);
	dc.SetTextAlign(TA_RIGHT);
	dc.TextOut(-10, 160, strVal);

	dc.MoveTo(0, 600);
	dc.LineTo(15, 600);
	strVal.Format(_T("%.1f"), (dTempMax - dTempMin)/2);
	dc.TextOut(-10, 600, strVal);

	dc.MoveTo(0, 1100);
	dc.LineTo(15, 1100);
	strVal.Format(_T("%.1f"), dTempMax);
	dc.TextOut(-10, 1160, strVal);
	dc.SelectObject(pOldFont);
}

void CPaneLogManagerLaserPower::OnButtonView() 
{
	UpdateData(TRUE);
	UpdateTime();

	m_listPowerTrend.DeleteAllItems();
	m_dMax = m_dMasterMax = m_dSlaveMax = m_dSetMax = -NONE_DATA;
	m_dMin = m_dMasterMin = m_dSlaveMin = m_dSetMin = NONE_DATA;
	FillList();
	ShowGraph();
}

void CPaneLogManagerLaserPower::UpdateTime()
{
	if (m_ctStart > m_ctEnd)
	{
		m_ctStart = m_ctEnd;
		UpdateData(FALSE);
	}

	int nYear = m_ctStart.GetYear();
	int nMon = m_ctStart.GetMonth();
	int nDay = m_ctStart.GetDay();

	m_ctStart = CTime(nYear, nMon, nDay, 0, 0, 0);

	nYear = m_ctEnd.GetYear();
	nMon = m_ctEnd.GetMonth();
	nDay = m_ctEnd.GetDay();
	
	m_ctEnd = CTime(nYear, nMon, nDay, 23, 59, 59);
}

void CPaneLogManagerLaserPower::FillList()
{
	CString strProcessLog;
	strProcessLog.Format( _T("%s") , gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
	CString strTrendFile(strProcessLog);
	strTrendFile += _T("PowerTrend");
	
	FILE* fp;
	if (NULL != fopen_s(&fp, (LPCTSTR)strTrendFile, _T("r")))
		return;

	TCHAR szBuf[8192];
	TCHAR *token, seps[] = _T("|\r\n");
	TCHAR *szNext;
	CString strDate, strTime, strMasterPower, strSlavePower, strFreq, strWidth, strBeamPath, strMask, strMasterZ, strSlaveZ, strTemp, strMin, strMax, strShot, strRefPower, strPowerTol;
	CString strAtt1, strAtt2, strCurr, strTrack;
	int nYear, nMon, nDay;
	int nBeamPath, nIndex;
	int nShot;
	double dTempM, dTempS;
	double dTempSetMin, dTempSetMax;
	
	for(int nStart = m_listPowerTrend.GetItemCount(); fgets(szBuf, 8192, fp); nStart++)
	{
		if (NULL == (token = strtok_s(szBuf, seps, &szNext)))		// ��¥
		{
			if (feof(fp))
				break;
			else
				continue;
		}

		strDate = token;
		strDate.TrimLeft();
		strDate.TrimRight();

		int nPos = strDate.Find(_T('/'));
		int nLen = strDate.GetLength();
		nYear = atoi(strDate.Left(nPos));
		strTemp = strDate.Right(nLen - nPos - 1);
		nPos = strTemp.Find(_T('/'));
		nLen = strTemp.GetLength();
		nMon = atoi(strTemp.Left(nPos));
		nDay = atoi(strTemp.Right(nLen - nPos - 1));

		CTime cTime(nYear, nMon, nDay, 1, 1, 1);
		if (cTime < m_ctStart || cTime > m_ctEnd)
			continue;
		
		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// �ð�
			continue;
		
		strTime = token;
		strTime.TrimLeft();
		strTime.TrimRight();
		
		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Master Power
			continue;
		
		strMasterPower = token;
		strMasterPower.TrimLeft();
		strMasterPower.TrimRight();
		dTempM = atof(strMasterPower);

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// Slave Power
			continue;

		strSlavePower = token;
		strSlavePower.TrimLeft();
		strSlavePower.TrimRight();
		dTempS = atof(strSlavePower);

// From below for format compatibility
		if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Pulse Freq
		{		
			strFreq = token;
			strFreq.TrimLeft();
			strFreq.TrimRight();
		}

		if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		{
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Attenuator1
			{		
				strAtt1 = token;
				strAtt1.TrimLeft();
				strAtt1.TrimRight();
			}
			
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Attenuator2
			{		
				strAtt2 = token;
				strAtt2.TrimLeft();
				strAtt2.TrimRight();
			}
			
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Diode Current
			{		
				strCurr = token;
				strCurr.TrimLeft();
				strCurr.TrimRight();
			}
			
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Thermal Track
			{		
				strTrack = token;
				strTrack.TrimLeft();
				strTrack.TrimRight();
			}

			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Master Z Height
			{		
				strMasterZ = token;
				strMasterZ.TrimLeft();
				strMasterZ.TrimRight();
			}
			
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Slave Z Height
			{		
				strSlaveZ = token;
				strSlaveZ.TrimLeft();
				strSlaveZ.TrimRight();
			}
		
			if (dTempM > m_dMasterMax)
				m_dMasterMax = dTempM;
			if (dTempM < m_dMasterMin)
				m_dMasterMin = dTempM;

			if (dTempS > m_dSlaveMax)
				m_dSlaveMax = dTempS;
			if (dTempS < m_dSlaveMin)
				m_dSlaveMin = dTempS;

			dTempM = max(m_dMasterMax, m_dSlaveMax);
			dTempS = min(m_dMasterMin, m_dSlaveMin);

			m_dMax = max(m_dMax, dTempM);
			m_dMin = min(m_dMin, dTempS);

			int nInsert = m_listPowerTrend.InsertItem(nStart, _T(""));
			m_listPowerTrend.SetItemText(nInsert, 1, strDate);
			m_listPowerTrend.SetItemText(nInsert, 2, strTime);
			m_listPowerTrend.SetItemText(nInsert, 3, strMasterPower);
			m_listPowerTrend.SetItemText(nInsert, 4, strSlavePower);
			m_listPowerTrend.SetItemText(nInsert, 5, strFreq);
			m_listPowerTrend.SetItemText(nInsert, 6, strAtt1);
			m_listPowerTrend.SetItemText(nInsert, 7, strAtt2);
			m_listPowerTrend.SetItemText(nInsert, 8, strCurr);
			m_listPowerTrend.SetItemText(nInsert, 9, strTrack);
			m_listPowerTrend.SetItemText(nInsert, 10, strMasterZ);
			m_listPowerTrend.SetItemText(nInsert, 11, strSlaveZ);
		}
		else
		{
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Pulse Width
			{		
				strWidth = token;
				strWidth.TrimLeft();
				strWidth.TrimRight();
			}

			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Mask Number
			{		
				strMask = token;
				strMask.TrimLeft();
				strMask.TrimRight();
			
				nIndex = strMask.Find(',');
				if(nIndex == -1)
				{
					strBeamPath = strMask;
				}
				else
				{
					strBeamPath = strMask.Left(nIndex);
					strBeamPath.TrimLeft();
					strBeamPath.TrimRight();
					strMask = strMask.Mid(nIndex+1);

				}
				nBeamPath = atoi(strBeamPath);

				if(m_nBeamPath <= gBeamPathINI.m_sBeampath.nLastIndex && nBeamPath != -1)
				{
					if(nBeamPath != m_nBeamPath)
						continue;
				}
			}


			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Master Z Height
			{		
				strMasterZ = token;
				strMasterZ.TrimLeft();
				strMasterZ.TrimRight();
			}

			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Slave Z Height
			{		
				strSlaveZ = token;
				strSlaveZ.TrimLeft();
				strSlaveZ.TrimRight();
			}
			
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Min
			{		
				strMin = token;
				strMin.TrimLeft();
				strMin.TrimRight();
				dTempSetMin = atof(strMin);
			}
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Max
			{		
				strMax = token;
				strMax.TrimLeft();
				strMax.TrimRight();
				dTempSetMax = atof(strMax);
			}
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Shot
			{		
				strShot = token;
				strShot.TrimLeft();
				strShot.TrimRight();
				nShot = atoi(strShot);

				if(m_nShot < MAX_BEAM_HOLE)
				{
					if(nShot != m_nShot)
						continue;
				}
			}
			else
			{
				strShot = "0";
				nShot = 0;
				if(m_nShot < MAX_BEAM_HOLE)
				{
					if(nShot != m_nShot)
						continue;
				}
			}
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Ref Power
			{		
				strRefPower = token;
				strRefPower.TrimLeft();
				strRefPower.TrimRight();
			}
			else
			{
				strRefPower = _T("0");
			}
			if (NULL != (token = strtok_s(NULL, seps, &szNext)))		// Power Tolerance
			{		
				strPowerTol = token;
				strPowerTol.TrimLeft();
				strPowerTol.TrimRight();
			}
			else
			{
				strPowerTol = _T("0");
			}
			

			if (dTempM > m_dMasterMax)
				m_dMasterMax = dTempM;
			if (dTempM < m_dMasterMin)
				m_dMasterMin = dTempM;

			if (dTempS > m_dSlaveMax)
				m_dSlaveMax = dTempS;
			if (dTempS < m_dSlaveMin)
				m_dSlaveMin = dTempS;

			dTempM = max(m_dMasterMax, m_dSlaveMax);
			dTempS = min(m_dMasterMin, m_dSlaveMin);

			m_dMax = max(m_dMax, dTempM);
			m_dMin = min(m_dMin, dTempS);

			m_dSetMin = min(m_dSetMin, dTempSetMin);
			m_dSetMax = max(m_dSetMax, dTempSetMax);

			int nInsert = m_listPowerTrend.InsertItem(nStart, _T(""));
			m_listPowerTrend.SetItemText(nInsert, 1, strDate);
			m_listPowerTrend.SetItemText(nInsert, 2, strTime);
			m_listPowerTrend.SetItemText(nInsert, 3, strMasterPower);
			m_listPowerTrend.SetItemText(nInsert, 4, strSlavePower);
			m_listPowerTrend.SetItemText(nInsert, 5, strMin);
			m_listPowerTrend.SetItemText(nInsert, 6, strMax);
			m_listPowerTrend.SetItemText(nInsert, 7, strFreq);
			m_listPowerTrend.SetItemText(nInsert, 8, strWidth);
			m_listPowerTrend.SetItemText(nInsert, 9, strBeamPath); 
			m_listPowerTrend.SetItemText(nInsert, 10, strMask); // IPG Pulse�� ��� Current��
			m_listPowerTrend.SetItemText(nInsert, 11, strMasterZ);
			m_listPowerTrend.SetItemText(nInsert, 12, strSlaveZ);
			m_listPowerTrend.SetItemText(nInsert, 13, strShot);
			m_listPowerTrend.SetItemText(nInsert, 14, strRefPower);
			m_listPowerTrend.SetItemText(nInsert, 15, strPowerTol);
		}
	}

	fclose(fp);
}

void CPaneLogManagerLaserPower::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntEtc.DeleteObject();
	m_fntList.DeleteObject();
	m_fntStatic.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneLogManagerLaserPower::SetToolComboBox()
{
	m_cmbBeamPath.ResetContent();
	
	CString strTool;
	
	for(int i = 0; i <= gBeamPathINI.m_sBeampath.nLastIndex; i++)
	{
		strTool.Format(_T("No %d : %s"), gBeamPathINI.m_sBeampath.nInfoId[i], gBeamPathINI.m_sBeampath.strInfoName[i]);
		m_cmbBeamPath.AddString(strTool);
	}
	
	strTool.Format(_T("Non Select"));
	m_cmbBeamPath.AddString(strTool);

}


void CPaneLogManagerLaserPower::OnCbnSelchangeComboBeampath()
{
	// TODO: Add your control notification handler code here
	m_nBeamPath = m_cmbBeamPath.GetCurSel();
}


void CPaneLogManagerLaserPower::OnCbnSelchangeComboShot()
{
	m_nShot = m_cmbShot.GetCurSel();
}

void CPaneLogManagerLaserPower::SetShotComboBox()
{
	m_cmbShot.ResetContent();
	CString strShot;
	for(int i = 0; i < MAX_BEAM_HOLE; i++)
	{
		strShot.Format(_T("Shot No %d"), i);
		m_cmbShot.AddString(strShot);
	}
	strShot.Format(_T("Non Select"));
	m_cmbShot.AddString(strShot);
}
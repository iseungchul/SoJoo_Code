#if !defined(AFX_DLGADDFIDUCIAL_H__86315C07_5F16_41EF_9183_2CB2A27FDAAA__INCLUDED_)
#define AFX_DLGADDFIDUCIAL_H__86315C07_5F16_41EF_9183_2CB2A27FDAAA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgAddFiducial.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgAddFiducial dialog

class CDlgAddFiducial : public CDialog
{
// Construction
public:
	void SetData(int nX, int nY);
	CDlgAddFiducial(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgAddFiducial)
	enum { IDD = IDD_DLG_ADD_FID };
	double	m_dX;
	double	m_dY;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgAddFiducial)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgAddFiducial)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGADDFIDUCIAL_H__86315C07_5F16_41EF_9183_2CB2A27FDAAA__INCLUDED_)

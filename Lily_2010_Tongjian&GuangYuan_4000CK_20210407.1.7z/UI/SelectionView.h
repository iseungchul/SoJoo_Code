#if !defined(AFX_SelectionView_H__DA1601EF_7AAE_4B1B_928D_4837D6E766EF__INCLUDED_)
#define AFX_SelectionView_H__DA1601EF_7AAE_4B1B_928D_4837D6E766EF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SelectionView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSelectionView view

class CSelectionView : public CScrollView
{
protected:
	CSelectionView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CSelectionView)

// Attributes
public:

// Operations
public:
	BOOL getRegionSelected();
	void setRegionSelected(BOOL bRegionSelected);
	void SetAxis(int nAxis);
	static BOOL RegisterSelectionViewClass(HINSTANCE hInstance);
	static LRESULT CALLBACK WindowProcedure(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSelectionView)
	public:
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual void OnInitialUpdate();     // first time after construct
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CSelectionView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CSelectionView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL m_bDrawRectTracker;
	CRectTracker m_rectTracker;
	BOOL m_bRegionSelected;
	void ChangeFieldToAxis();
	CRect m_rectSelectedInAxis;
	CRect m_rectSelectedInField;
	bool SelectNode();
	POINT m_ptDragEnd;
	POINT m_ptDragStart;
	void DrawSelectionRect(POINT ptLeftTop, POINT ptRightBottom);
	BOOL m_bSelectionMode;
	COLORREF m_clrSelectedNodeColor;
	COLORREF m_clrUnselectedNodeColor;
	int m_nAxis;
	BOOL m_bNodeSelected[65][65];
	const int c_nOffset;
	void DrawNode(CDC *pDC);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SelectionView_H__DA1601EF_7AAE_4B1B_928D_4837D6E766EF__INCLUDED_)

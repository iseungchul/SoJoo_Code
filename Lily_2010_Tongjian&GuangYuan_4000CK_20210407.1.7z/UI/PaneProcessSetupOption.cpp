// PaneProcessSetupOption.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneProcessSetupOption.h"
#include "..\model\deasydrillerini.h"
#include "..\easydrillerdlg.h"
#include "..\model\DProcessINI.h"
#include "..\Model\DSystemINI.h"
#include "..\MODEL\DBeampathINI.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupOption

IMPLEMENT_DYNCREATE(CPaneProcessSetupOption, CFormView)

CPaneProcessSetupOption::CPaneProcessSetupOption()
	: CFormView(CPaneProcessSetupOption::IDD)
{
	//{{AFX_DATA_INIT(CPaneProcessSetupOption)
	//}}AFX_DATA_INIT
	m_bSkipBoardCheck			= FALSE;
	m_bApplyTolerance			= FALSE;
}

CPaneProcessSetupOption::~CPaneProcessSetupOption()
{
}

void CPaneProcessSetupOption::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneProcessSetupOption)
	DDX_Control(pDX, IDC_EDIT_ERROR_RETRY_COUNT, m_edtErrorRetryCount);
	DDX_Control(pDX, IDC_EDIT_AUTO_CAL_2ND_PANE_Y, m_edtAutoCal2ndPaneY);
	DDX_Control(pDX, IDC_EDIT_AUTO_CAL_2ND_PANE_X, m_edtAutoCal2ndPaneX);
	DDX_Control(pDX, IDC_EDIT_AUTO_CAL_1ST_PANE_Y, m_edtAutoCal1stPaneY);
	DDX_Control(pDX, IDC_EDIT_AUTO_CAL_1ST_PANE_X, m_edtAutoCal1stPaneX);
	DDX_Control(pDX, IDC_EDIT_PREWORK_AUTO_CAL_2ND_PANE_Y, m_edtPreworkAutoCal2ndPaneY);
	DDX_Control(pDX, IDC_EDIT_PREWORK_AUTO_CAL_2ND_PANE_X, m_edtPreworkAutoCal2ndPaneX);
	DDX_Control(pDX, IDC_EDIT_PREWORK_AUTO_CAL_1ST_PANE_Y, m_edtPreworkAutoCal1stPaneY);
	DDX_Control(pDX, IDC_EDIT_PREWORK_AUTO_CAL_1ST_PANE_X, m_edtPreworkAutoCal1stPaneX);
	DDX_Control(pDX, IDC_CHECK_USE_APPLY_TOLERANCE, m_chkUseApplyTolerance);
	DDX_Control(pDX, IDC_EDIT_VALID_TIME, m_edtValidTime);
	DDX_Control(pDX, IDC_EDIT_POWER_MEASURE_TIME, m_edtValidMeasureTime);
	DDX_Control(pDX, IDC_EDIT_SCAL_REL_TIME, m_edtSCalRelTime);
	DDX_Control(pDX, IDC_EDIT_SCAL_PNL, m_edtSCalPNL);
	DDX_Control(pDX, IDC_EDIT_SCAL_PNL2, m_edtSCalPNL2);
	DDX_Control(pDX, IDC_EDIT_POWER_REL_TIME, m_edtPowerRelTime);
	DDX_Control(pDX, IDC_EDIT_POWER_PNL, m_edtPowerPNL);
	DDX_Control(pDX, IDC_EDIT_PREHEAT_MODULATION_TIME2, m_edtPreheatModulationTime);
	DDX_Control(pDX, IDC_EDIT_PREHEAT_TIME2, m_edtPreheatTime);
	DDX_Control(pDX, IDC_EDIT_PREHEAT_TIME3, m_edtAutoRunPreheatTime);
	DDX_Control(pDX, IDC_EDIT_DUTY, m_edtPreheatDuty);
	DDX_Control(pDX, IDC_EDIT_FREQ, m_edtPreheatFreq);
	DDX_Control(pDX, IDC_EDIT_PREHEAT_REL_TIME, m_edtPreheatRelTime);
	DDX_Control(pDX, IDC_EDIT_PREHEAT_PNL, m_edtPreheatPNL);
	DDX_Control(pDX, IDC_CHECK_USE_PREWORK_COUNT, m_chkUsePreworkPerCount);
	DDX_Control(pDX, IDC_CHECK_POWER_END_LOT, m_chkPowerLotEnd);
	DDX_Control(pDX, IDC_CHECK_USE_VISION_CAL_MODE, m_chkVisionCalMode);
	DDX_Control(pDX, IDC_COMBO_TOOL, m_cmbTool);
	DDX_Control(pDX, IDC_EDIT_SCAL_FIELD_COUNT, m_edtScalFieldCount);
	DDX_Control(pDX, IDC_EDIT_VISION_FIELD_COUNT, m_edtVisionCalFieldCount);
	DDX_Control(pDX, IDC_CHECK_USE_POWER_OCMPENSATIOM_MODE, m_chkUsePowerCompensationMode);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneProcessSetupOption, CFormView)
	//{{AFX_MSG_MAP(CPaneProcessSetupOption)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHECK_USE_PREWORK_COUNT, OnCheckUseCountUnit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupOption diagnostics

#ifdef _DEBUG
void CPaneProcessSetupOption::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneProcessSetupOption::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupOption message handlers

void CPaneProcessSetupOption::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitEditControl();
	InitBtnControl();
	InitComboControl();
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		m_edtAutoCal2ndPaneX.EnableWindow(FALSE);
		m_edtAutoCal2ndPaneY.EnableWindow(FALSE);
		m_edtAutoCal2ndPaneX.SetWindowText("NO USE");
		m_edtAutoCal2ndPaneY.SetWindowText("NO USE");
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 0)
		m_edtValidMeasureTime.EnableWindow(FALSE);

}

HBRUSH CPaneProcessSetupOption::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_AUTO_CAL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_POWER_MEASURE)->GetSafeHwnd() == pWnd->m_hWnd||
		GetDlgItem(IDC_STATIC_PREHEAT_TIME_SETTING)->GetSafeHwnd() == pWnd->m_hWnd)
//		||	GetDlgItem(IDC_STATIC_EVERY_PANEL_THICKNESS)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0, 0, 255) );

	// TODO: Return a different brush if the default is not desired
	return hbr;
}

BOOL CPaneProcessSetupOption::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneProcessSetupOption::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(120, "Arial Bold");

	// PowerMeasure
	GetDlgItem(IDC_STATIC_POWER_MEASURE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER_MEASURE_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AUTOCALIBRATION_POWER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER_RELATIVE_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER_PNL_COUNT)->SetFont( &m_fntStatic );
	// Auto Calibration
	GetDlgItem(IDC_STATIC_AUTO_CAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TOLERANCE_LIMIT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TOLERANCE_LIMIT_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TOLERANCE_LIMIT_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREWORK_TOLERANCE_LIMIT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREWORK_TOLERANCE_LIMIT_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREWORK_TOLERANCE_LIMIT_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ERROR_RETRY_COUNT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VALID_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AUTOCALIBRATION_SCANNER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCAL_RELATIVE_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCAL_PNL_COUNT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCAL_FIELD_COUNT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VISON_FIELD_COUNT)->SetFont( &m_fntStatic );
	// LaserPreHeat
	GetDlgItem(IDC_STATIC_PREHEAT_TIME_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_TIME2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_TIME3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUTY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FREQ)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_MODULATION_TIME3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AUTO_LASER_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_RELATIVE_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PREHEAT_PNL_COUNT)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_TOOL_NO3)->SetFont( &m_fntStatic );
	
	
#if defined ( __OSAN_LG_2013__) || defined (__ANSAN_KCC__) || defined(__OSAN_LG__)
	GetDlgItem(IDC_STATIC_TOOL_NO3)->ShowWindow(SW_HIDE);
#else
	if(gProcessINI.m_sProcessSystem.bNoUsePrework)
	{
		GetDlgItem(IDC_STATIC_SCAL_PNL_COUNT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_POWER_PNL_COUNT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_MIN3)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_PREWORK_TOLERANCE_LIMIT)->SetWindowText(_T("Idle Tolerance Limit "));
	}
	else
		GetDlgItem(IDC_STATIC_TOOL_NO3)->ShowWindow(SW_HIDE);
#endif

	
	

}

void CPaneProcessSetupOption::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	// Auto Calibration
	m_edtAutoCal1stPaneX.SetFont( &m_fntEdit );
	m_edtAutoCal1stPaneX.SetForeColor( BLACK_COLOR );
	m_edtAutoCal1stPaneX.SetBackColor( WHITE_COLOR );
	m_edtAutoCal1stPaneX.SetReceivedFlag( 1 );
	m_edtAutoCal1stPaneX.SetWindowText( _T("10") );

	m_edtAutoCal1stPaneY.SetFont( &m_fntEdit );
	m_edtAutoCal1stPaneY.SetForeColor( BLACK_COLOR );
	m_edtAutoCal1stPaneY.SetBackColor( WHITE_COLOR );
	m_edtAutoCal1stPaneY.SetReceivedFlag( 1 );
	m_edtAutoCal1stPaneY.SetWindowText( _T("10") );

	m_edtAutoCal2ndPaneX.SetFont( &m_fntEdit );
	m_edtAutoCal2ndPaneX.SetForeColor( BLACK_COLOR );
	m_edtAutoCal2ndPaneX.SetBackColor( WHITE_COLOR );
	m_edtAutoCal2ndPaneX.SetReceivedFlag( 1 );
	m_edtAutoCal2ndPaneX.SetWindowText( _T("10") );

	m_edtAutoCal2ndPaneY.SetFont( &m_fntEdit );
	m_edtAutoCal2ndPaneY.SetForeColor( BLACK_COLOR );
	m_edtAutoCal2ndPaneY.SetBackColor( WHITE_COLOR );
	m_edtAutoCal2ndPaneY.SetReceivedFlag( 1 );
	m_edtAutoCal2ndPaneY.SetWindowText( _T("10") );

	m_edtPreworkAutoCal1stPaneX.SetFont( &m_fntEdit );
	m_edtPreworkAutoCal1stPaneX.SetForeColor( BLACK_COLOR );
	m_edtPreworkAutoCal1stPaneX.SetBackColor( WHITE_COLOR );
	m_edtPreworkAutoCal1stPaneX.SetReceivedFlag( 1 );
	m_edtPreworkAutoCal1stPaneX.SetWindowText( _T("10") );

	m_edtPreworkAutoCal1stPaneY.SetFont( &m_fntEdit );
	m_edtPreworkAutoCal1stPaneY.SetForeColor( BLACK_COLOR );
	m_edtPreworkAutoCal1stPaneY.SetBackColor( WHITE_COLOR );
	m_edtPreworkAutoCal1stPaneY.SetReceivedFlag( 1 );
	m_edtPreworkAutoCal1stPaneY.SetWindowText( _T("10") );

	m_edtPreworkAutoCal2ndPaneX.SetFont( &m_fntEdit );
	m_edtPreworkAutoCal2ndPaneX.SetForeColor( BLACK_COLOR );
	m_edtPreworkAutoCal2ndPaneX.SetBackColor( WHITE_COLOR );
	m_edtPreworkAutoCal2ndPaneX.SetReceivedFlag( 1 );
	m_edtPreworkAutoCal2ndPaneX.SetWindowText( _T("10") );

	m_edtPreworkAutoCal2ndPaneY.SetFont( &m_fntEdit );
	m_edtPreworkAutoCal2ndPaneY.SetForeColor( BLACK_COLOR );
	m_edtPreworkAutoCal2ndPaneY.SetBackColor( WHITE_COLOR );
	m_edtPreworkAutoCal2ndPaneY.SetReceivedFlag( 1 );
	m_edtPreworkAutoCal2ndPaneY.SetWindowText( _T("10") );

	m_edtErrorRetryCount.SetFont( &m_fntEdit );
	m_edtErrorRetryCount.SetForeColor( BLACK_COLOR );
	m_edtErrorRetryCount.SetBackColor( WHITE_COLOR );
	m_edtErrorRetryCount.SetReceivedFlag( 1 );
	m_edtErrorRetryCount.SetWindowText( _T("3") );

	// Time Validity of power measurement
	m_edtValidMeasureTime.SetFont( &m_fntEdit );
	m_edtValidMeasureTime.SetForeColor( BLACK_COLOR );
	m_edtValidMeasureTime.SetBackColor( WHITE_COLOR );
	m_edtValidMeasureTime.SetReceivedFlag( 1 );
	m_edtValidMeasureTime.SetWindowText( _T("12") );

	// Time Validity of scanner calibration
	m_edtValidTime.SetFont( &m_fntEdit );
	m_edtValidTime.SetForeColor( BLACK_COLOR );
	m_edtValidTime.SetBackColor( WHITE_COLOR );
	m_edtValidTime.SetReceivedFlag( 1 );
	m_edtValidTime.SetWindowText( _T("12") );	

	// Auto scanner calibration by relative time
	m_edtSCalRelTime.SetFont( &m_fntEdit );
	m_edtSCalRelTime.SetForeColor( BLACK_COLOR );
	m_edtSCalRelTime.SetBackColor( WHITE_COLOR );
	m_edtSCalRelTime.SetReceivedFlag( 1 );
	m_edtSCalRelTime.SetWindowText( _T("8") );

	// Auto scanner calibration by PNL
	m_edtSCalPNL.SetFont( &m_fntEdit );
	m_edtSCalPNL.SetForeColor( BLACK_COLOR );
	m_edtSCalPNL.SetBackColor( WHITE_COLOR );
	m_edtSCalPNL.SetReceivedFlag( 1 );
	m_edtSCalPNL.SetWindowText( _T("10") );

	// Auto scanner calibration by PNL
	m_edtSCalPNL2.SetFont( &m_fntEdit );
	m_edtSCalPNL2.SetForeColor( BLACK_COLOR );
	m_edtSCalPNL2.SetBackColor( WHITE_COLOR );
	m_edtSCalPNL2.SetReceivedFlag( 1 );
	m_edtSCalPNL2.SetWindowText( _T("10") );

	// Auto power measurement by PNL
	m_edtPowerPNL.SetFont( &m_fntEdit );
	m_edtPowerPNL.SetForeColor( BLACK_COLOR );
	m_edtPowerPNL.SetBackColor( WHITE_COLOR );
	m_edtPowerPNL.SetReceivedFlag( 1 );
	m_edtPowerPNL.SetWindowText( _T("10") );

	// Auto power measurement by relative time
	m_edtPowerRelTime.SetFont( &m_fntEdit );
	m_edtPowerRelTime.SetForeColor( BLACK_COLOR );
	m_edtPowerRelTime.SetBackColor( WHITE_COLOR );
	m_edtPowerRelTime.SetReceivedFlag( 1 );
	m_edtPowerRelTime.SetWindowText( _T("8") );

	// Preheat Modulation Time
	m_edtPreheatModulationTime.SetFont( &m_fntEdit );
	m_edtPreheatModulationTime.SetForeColor( BLACK_COLOR );
	m_edtPreheatModulationTime.SetBackColor( WHITE_COLOR );
	m_edtPreheatModulationTime.SetReceivedFlag( 1 );
	m_edtPreheatModulationTime.SetWindowText( _T("8") );
	
	// Preheat Manual Time
	m_edtPreheatTime.SetFont( &m_fntEdit );
	m_edtPreheatTime.SetForeColor( BLACK_COLOR );
	m_edtPreheatTime.SetBackColor( WHITE_COLOR );
	m_edtPreheatTime.SetReceivedFlag( 1 );
	m_edtPreheatTime.SetWindowText( _T("60") );

	// Preheat AutoRun Time
	m_edtAutoRunPreheatTime.SetFont( &m_fntEdit );
	m_edtAutoRunPreheatTime.SetForeColor( BLACK_COLOR );
	m_edtAutoRunPreheatTime.SetBackColor( WHITE_COLOR );
	m_edtAutoRunPreheatTime.SetReceivedFlag( 1 );
	m_edtAutoRunPreheatTime.SetWindowText( _T("60") );

	// PreHeat AutoRun Duty
	m_edtPreheatDuty.SetFont( &m_fntEdit );
	m_edtPreheatDuty.SetForeColor( BLACK_COLOR );
	m_edtPreheatDuty.SetBackColor( WHITE_COLOR );
	m_edtPreheatDuty.SetReceivedFlag( 1 );
//	m_edtPreheatDuty.SetWindowText( _T("60") );


	// PreHeat AutoRun Freq.
	m_edtPreheatFreq.SetFont( &m_fntEdit );
	m_edtPreheatFreq.SetForeColor( BLACK_COLOR );
	m_edtPreheatFreq.SetBackColor( WHITE_COLOR );
	m_edtPreheatFreq.SetReceivedFlag( 1 );
	//	m_edtPreheatFreq.SetWindowText( _T("60") );

	// Auto preheat by relative time
	m_edtPreheatRelTime.SetFont( &m_fntEdit );
	m_edtPreheatRelTime.SetForeColor( BLACK_COLOR );
	m_edtPreheatRelTime.SetBackColor( WHITE_COLOR );
	m_edtPreheatRelTime.SetReceivedFlag( 1 );
	m_edtPreheatRelTime.SetWindowText( _T("8") );

	// Auto preheat by PNL
	m_edtPreheatPNL.SetFont( &m_fntEdit );
	m_edtPreheatPNL.SetForeColor( BLACK_COLOR );
	m_edtPreheatPNL.SetBackColor( WHITE_COLOR );
	m_edtPreheatPNL.SetReceivedFlag( 1 );
	m_edtPreheatPNL.SetWindowText( _T("10") );

	// SCal Field Count
	m_edtScalFieldCount.SetFont( &m_fntEdit );
	m_edtScalFieldCount.SetForeColor( BLACK_COLOR );
	m_edtScalFieldCount.SetBackColor( WHITE_COLOR );
	m_edtScalFieldCount.SetReceivedFlag( 1 );
	m_edtScalFieldCount.SetWindowText( _T("2") );

	// VisionCal Field Count
	m_edtVisionCalFieldCount.SetFont( &m_fntEdit );
	m_edtVisionCalFieldCount.SetForeColor( BLACK_COLOR );
	m_edtVisionCalFieldCount.SetBackColor( WHITE_COLOR );
	m_edtVisionCalFieldCount.SetReceivedFlag( 1 );
	m_edtVisionCalFieldCount.SetWindowText( _T("3") );




}

void CPaneProcessSetupOption::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Use Apply Tolerance
	m_chkUseApplyTolerance.SetFont( &m_fntBtn );
	m_chkUseApplyTolerance.SetImageOrg( 10, 3 );
	m_chkUseApplyTolerance.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseApplyTolerance.EnableBallonToolTip();
	m_chkUseApplyTolerance.SetToolTipText( _T("Skip Board Check") );
	m_chkUseApplyTolerance.SetBtnCursor(IDC_HAND_1);

	//prework 
	m_chkUsePreworkPerCount.SetFont( &m_fntBtn );
	m_chkUsePreworkPerCount.SetImageOrg( 10, 3 );
	m_chkUsePreworkPerCount.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUsePreworkPerCount.EnableBallonToolTip();
	m_chkUsePreworkPerCount.SetToolTipText( _T("Prework Unit") );
	m_chkUsePreworkPerCount.SetBtnCursor(IDC_HAND_1);

	//prework 
	m_chkPowerLotEnd.SetFont( &m_fntBtn );
	m_chkPowerLotEnd.SetImageOrg( 10, 3 );
	m_chkPowerLotEnd.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkPowerLotEnd.EnableBallonToolTip();
	m_chkPowerLotEnd.SetToolTipText( _T("Prework Unit") );
	m_chkPowerLotEnd.SetBtnCursor(IDC_HAND_1);

	m_chkVisionCalMode.SetFont( &m_fntBtn );
	m_chkVisionCalMode.SetImageOrg( 10, 3 );
	m_chkVisionCalMode.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkVisionCalMode.EnableBallonToolTip();
	m_chkVisionCalMode.SetToolTipText( _T("Prework Unit") );
	m_chkVisionCalMode.SetBtnCursor(IDC_HAND_1);

	m_chkUsePowerCompensationMode.SetFont( &m_fntBtn );
	m_chkUsePowerCompensationMode.SetImageOrg( 10, 3 );
	m_chkUsePowerCompensationMode.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUsePowerCompensationMode.EnableBallonToolTip();
	m_chkUsePowerCompensationMode.SetToolTipText( _T("Use PowerCompensation Mode") );
	m_chkUsePowerCompensationMode.SetBtnCursor(IDC_HAND_1);
	


}

void CPaneProcessSetupOption::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneProcessSetupOption::DispProcessCal()
{
	CString strData;

	// 1'st Tolerance Limit
	strData.Format(_T("%d"), m_sProcessCal.n1stToleranceX);
	m_edtAutoCal1stPaneX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%d"), m_sProcessCal.n1stToleranceY);
	m_edtAutoCal1stPaneY.SetWindowText( (LPCTSTR)strData );

	// 2'nd Tolerance Limit
	strData.Format(_T("%d"), m_sProcessCal.n2ndToleranceX);
	m_edtAutoCal2ndPaneX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%d"), m_sProcessCal.n2ndToleranceY);
	m_edtAutoCal2ndPaneY.SetWindowText( (LPCTSTR)strData );

	// Prework 1'st Tolerance Limit
	strData.Format(_T("%d"), m_sProcessCal.n1stPreworkToleranceX);
	m_edtPreworkAutoCal1stPaneX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%d"), m_sProcessCal.n1stPreworkToleranceY);
	m_edtPreworkAutoCal1stPaneY.SetWindowText( (LPCTSTR)strData );

	// Prework 2'nd Tolerance Limit
	strData.Format(_T("%d"), m_sProcessCal.n2ndPreworkToleranceX);
	m_edtPreworkAutoCal2ndPaneX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%d"), m_sProcessCal.n2ndPreworkToleranceY);
	m_edtPreworkAutoCal2ndPaneY.SetWindowText( (LPCTSTR)strData );

	// Auto Calibration Retry Count
	strData.Format(_T("%d"), m_sProcessCal.nAutoCalibrationCount);
	m_edtErrorRetryCount.SetWindowText( (LPCTSTR)strData );

	// Valid measure time
	strData.Format(_T("%d"), m_sProcessCal.nValidMeasureTime);
	m_edtValidMeasureTime.SetWindowText( (LPCTSTR)strData );

	// Valid Time
	strData.Format(_T("%d"), m_sProcessCal.nValidTime);
	m_edtValidTime.SetWindowText( (LPCTSTR)strData );

	// Check Apply Tolerance
	m_bApplyTolerance = m_sProcessCal.bUseApplyTolerance;
	m_chkUseApplyTolerance.SetCheck( m_bApplyTolerance );

	// Auto scanner calibration by relative time
	strData.Format(_T("%d"), m_sProcessCal.nScalRelTime);
	m_edtSCalRelTime.SetWindowText( (LPCTSTR)strData );

	// Auto scanner calibration by Count
	strData.Format(_T("%d"), m_sProcessCal.nScalCountTime);
	m_edtSCalPNL.SetWindowText( (LPCTSTR)strData );

	// Auto scanner calibration by Count
	strData.Format(_T("%d"), m_sProcessCal.nScalCountTime2);
	m_edtSCalPNL2.SetWindowText( (LPCTSTR)strData );

	// SCal Field Count
	strData.Format(_T("%d"), m_sProcessCal.nAutoCalibrationFieldCount);
	m_edtScalFieldCount.SetWindowText( (LPCTSTR)strData );

	// Vision Field Count
	strData.Format(_T("%d"), m_sProcessCal.nVisionCalibrationFieldCount);
	m_edtVisionCalFieldCount.SetWindowText( (LPCTSTR)strData );

	// Auto power measurement by relative time
	strData.Format(_T("%d"), m_sProcessCal.nPowerRelTime);
	m_edtPowerRelTime.SetWindowText( (LPCTSTR)strData );

	// Auto power measurement by Count
	strData.Format(_T("%d"), m_sProcessCal.nPowerCountTime);
	m_edtPowerPNL.SetWindowText( (LPCTSTR)strData );

	// Auto preheat by relative time
	strData.Format(_T("%d"), m_sProcessCal.nPreheatRelTime);
	m_edtPreheatRelTime.SetWindowText( (LPCTSTR)strData );

	// Auto preheat by Count
	strData.Format(_T("%d"), m_sProcessCal.nPreheatCountTime);
	m_edtPreheatPNL.SetWindowText( (LPCTSTR)strData );

	// Preheat Modulation TIme
	strData.Format(_T("%d"), m_sProcessCal.nPreheatModulationTime);
	m_edtPreheatModulationTime.SetWindowText( (LPCTSTR)strData );
	
	// Preheat Manual Time
	strData.Format(_T("%d"), m_sProcessCal.nPreheatTime);
	m_edtPreheatTime.SetWindowText( (LPCTSTR)strData );

	// Preheat AutoRun Time
	strData.Format(_T("%d"), m_sProcessCal.nAutoRunPreheatTime);
	m_edtAutoRunPreheatTime.SetWindowText( (LPCTSTR)strData );
	
	// Preheat AutoRun Duty
	strData.Format(_T("%.2f"), m_sProcessCal.dAutoRunPreheatDuty);
	m_edtPreheatDuty.SetWindowText( (LPCTSTR)strData );

	// Preheat AutoRun Freq.
	strData.Format(_T("%d"), m_sProcessCal.nAutoRunPreheatFreq);
	m_edtPreheatFreq.SetWindowText( (LPCTSTR)strData );

	// Prework 
	m_chkUsePreworkPerCount.SetCheck( m_sProcessCal.bUsePNLCountUnit );
	OnCheckUseCountUnit();

	m_chkPowerLotEnd.SetCheck(m_sProcessCal.bPowerEndLot);

	m_chkUsePowerCompensationMode.SetCheck(m_sProcessCal.bUsePowerCompensationMode);

	m_chkVisionCalMode.SetCheck(m_sProcessCal.nVisionCalMode);

	SetToolComboBox();
	m_cmbTool.SetCurSel(m_sProcessCal.nIdleBeamPath);

	UpdateData(FALSE);
}

void CPaneProcessSetupOption::SetProcessCal(SPROCESSCALIBRATION sProcessCal)
{
	memcpy( &m_sProcessCal, &sProcessCal, sizeof(m_sProcessCal) );

	DispProcessCal();
}

void CPaneProcessSetupOption::GetProcessCal(SPROCESSCALIBRATION* pProcessCal)
{
	memcpy( pProcessCal, &m_sProcessCal, sizeof(m_sProcessCal) );
}

void CPaneProcessSetupOption::OnApply()
{
	CString strData;

	UpdateData(TRUE);

	// 1'st Tolerance Limit
	m_edtAutoCal1stPaneX.GetWindowText( strData );
	m_sProcessCal.n1stToleranceX = atoi( (LPSTR)(LPCTSTR)strData );
	m_edtAutoCal1stPaneY.GetWindowText( strData );
	m_sProcessCal.n1stToleranceY = atoi( (LPSTR)(LPCTSTR)strData );

	// 2'nd Tolerance Limit
	m_edtAutoCal2ndPaneX.GetWindowText( strData );
	m_sProcessCal.n2ndToleranceX = atoi( (LPSTR)(LPCTSTR)strData );
	m_edtAutoCal2ndPaneY.GetWindowText( strData );
	m_sProcessCal.n2ndToleranceY = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtPreworkAutoCal1stPaneX.GetWindowText( strData );
	m_sProcessCal.n1stPreworkToleranceX = atoi( (LPSTR)(LPCTSTR)strData );
	m_edtPreworkAutoCal1stPaneY.GetWindowText( strData );
	m_sProcessCal.n1stPreworkToleranceY = atoi( (LPSTR)(LPCTSTR)strData );

	// 2'nd Tolerance Limit
	m_edtPreworkAutoCal2ndPaneX.GetWindowText( strData );
	m_sProcessCal.n2ndPreworkToleranceX = atoi( (LPSTR)(LPCTSTR)strData );
	m_edtPreworkAutoCal2ndPaneY.GetWindowText( strData );
	m_sProcessCal.n2ndPreworkToleranceY = atoi( (LPSTR)(LPCTSTR)strData );

	// Auto Calibration Retry Count
	m_edtErrorRetryCount.GetWindowText( strData );
	m_sProcessCal.nAutoCalibrationCount = atoi( (LPSTR)(LPCTSTR)strData );

	// Valid measure time
	m_edtValidMeasureTime.GetWindowText( strData );
	m_sProcessCal.nValidMeasureTime = atoi( (LPSTR)(LPCTSTR)strData );

	// Valid Time
	m_edtValidTime.GetWindowText( strData );
	m_sProcessCal.nValidTime = atoi( (LPSTR)(LPCTSTR)strData );
			
	// Check Apply Tolerance
	m_bApplyTolerance = m_chkUseApplyTolerance.GetCheck();
	m_sProcessCal.bUseApplyTolerance = m_bApplyTolerance;

	// auto scanner calibration by count
	m_edtSCalPNL.GetWindowText( strData );
	m_sProcessCal.nScalCountTime = atoi( (LPSTR)(LPCTSTR)strData );

	// auto scanner calibration by count
	m_edtSCalPNL2.GetWindowText( strData );
	m_sProcessCal.nScalCountTime2 = atoi( (LPSTR)(LPCTSTR)strData );

	// auto scanner calibration by relative time
	m_edtSCalRelTime.GetWindowText( strData );
	m_sProcessCal.nScalRelTime = atoi( (LPSTR)(LPCTSTR)strData );

	// auto power measurement by relative time
	m_edtPowerPNL.GetWindowText( strData );
	m_sProcessCal.nPowerCountTime = atoi( (LPSTR)(LPCTSTR)strData );

	// SCal Field Count
	m_edtScalFieldCount.GetWindowText( strData );
	m_sProcessCal.nAutoCalibrationFieldCount = atoi( (LPSTR)(LPCTSTR)strData );

	// Vision Field Count
	m_edtVisionCalFieldCount.GetWindowText( strData );
	m_sProcessCal.nVisionCalibrationFieldCount = atoi( (LPSTR)(LPCTSTR)strData );

	// auto power measurement by relative time
	m_edtPowerRelTime.GetWindowText( strData );
	m_sProcessCal.nPowerRelTime = atoi( (LPSTR)(LPCTSTR)strData );

	// Preheat Modulation TIme
	m_edtPreheatModulationTime.GetWindowText( strData );
	m_sProcessCal.nPreheatModulationTime = atoi( (LPSTR)(LPCTSTR)strData );	
	
	// Preheat Manual Time
	m_edtPreheatTime.GetWindowText( strData );
	m_sProcessCal.nPreheatTime = atoi( (LPSTR)(LPCTSTR)strData );

	// AutoRun Preheat Time
	m_edtAutoRunPreheatTime.GetWindowText( strData );
	m_sProcessCal.nAutoRunPreheatTime = atoi( (LPSTR)(LPCTSTR)strData );

	// AutoRun Preheat Duty
	m_edtPreheatDuty.GetWindowText( strData );
	m_sProcessCal.dAutoRunPreheatDuty = atof( (LPSTR)(LPCTSTR)strData );

	// AutoRun Preheat Freq
	m_edtPreheatFreq.GetWindowText( strData );
	m_sProcessCal.nAutoRunPreheatFreq = atoi( (LPSTR)(LPCTSTR)strData );

	//auto preheat relative time
	m_edtPreheatRelTime.GetWindowText( strData );
	m_sProcessCal.nPreheatRelTime = atoi( (LPSTR)(LPCTSTR)strData );

	
	//auto preheat Count
	m_edtPreheatPNL.GetWindowText( strData );
	m_sProcessCal.nPreheatCountTime = atoi( (LPSTR)(LPCTSTR)strData );

	m_sProcessCal.bUsePNLCountUnit = m_chkUsePreworkPerCount.GetCheck();
	m_sProcessCal.bPowerEndLot = m_chkPowerLotEnd.GetCheck();

	m_sProcessCal.bUsePowerCompensationMode = m_chkUsePowerCompensationMode.GetCheck();

	m_sProcessCal.nVisionCalMode =  m_chkVisionCalMode.GetCheck();

	m_sProcessCal.nIdleBeamPath = m_cmbTool.GetCurSel();
}

CString CPaneProcessSetupOption::GetChangeValueStr()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));

	if(m_sProcessCal.n1stToleranceX != gProcessINI.m_sProcessCal.n1stToleranceX ||
		m_sProcessCal.n1stToleranceY != gProcessINI.m_sProcessCal.n1stToleranceY)
	{
		strTemp.Format(_T("| AGC 1st-P Tol. : ( %d, %d)um "), 
			m_sProcessCal.n1stToleranceX,
			m_sProcessCal.n1stToleranceY);
		strMessage += strTemp;
	}

	if(m_sProcessCal.n2ndToleranceX != gProcessINI.m_sProcessCal.n2ndToleranceX ||
		m_sProcessCal.n2ndToleranceY != gProcessINI.m_sProcessCal.n2ndToleranceY)
	{
		strTemp.Format(_T("| AGC 2nd-P Tol. : ( %d, %d)um "), 
			m_sProcessCal.n2ndToleranceX,
			m_sProcessCal.n2ndToleranceY);
		strMessage += strTemp;
	}

	if(m_sProcessCal.n1stPreworkToleranceX != gProcessINI.m_sProcessCal.n1stPreworkToleranceX ||
		m_sProcessCal.n1stPreworkToleranceY != gProcessINI.m_sProcessCal.n1stPreworkToleranceY)
	{
		strTemp.Format(_T("| AGC 1st-P Tol. : ( %d, %d)um "), 
			m_sProcessCal.n1stPreworkToleranceX,
			m_sProcessCal.n1stPreworkToleranceY);
		strMessage += strTemp;
	}

	if(m_sProcessCal.n2ndPreworkToleranceX != gProcessINI.m_sProcessCal.n2ndPreworkToleranceX ||
		m_sProcessCal.n2ndPreworkToleranceY != gProcessINI.m_sProcessCal.n2ndPreworkToleranceY)
	{
		strTemp.Format(_T("| AGC 2nd-P Tol. : ( %d, %d)um "), 
			m_sProcessCal.n2ndPreworkToleranceX,
			m_sProcessCal.n2ndPreworkToleranceY);
		strMessage += strTemp;
	}

	if(m_sProcessCal.nValidMeasureTime != gProcessINI.m_sProcessCal.nValidMeasureTime)
	{
		strTemp.Format(_T("| Valid measure time : %d Hours "), 
			m_sProcessCal.nValidMeasureTime);
		strMessage += strTemp;
	}

	if(m_sProcessCal.nValidTime != gProcessINI.m_sProcessCal.nValidTime)
	{
		strTemp.Format(_T("| AGC Valid time : %d Hours "), 
			m_sProcessCal.nValidTime);
		strMessage += strTemp;
	}

	if(m_sProcessCal.bUseApplyTolerance != gProcessINI.m_sProcessCal.bUseApplyTolerance)
	{
		if(m_sProcessCal.bUseApplyTolerance)
			strTemp.Format(_T("| Use AGC Tol. limit "));
		else
			strTemp.Format(_T("| Don't use AGC Tol. limit "));
		strMessage += strTemp;
	}

	if(m_sProcessCal.nScalMethod != gProcessINI.m_sProcessCal.nScalMethod)
	{
		strTemp.Format(_T("| Scal Method : %d "), 
			m_sProcessCal.nScalMethod);
		strMessage += strTemp;
	}

	if(m_sProcessCal.nPowerMethod != gProcessINI.m_sProcessCal.nPowerMethod)
	{
		strTemp.Format(_T("| Power Method : %d "), 
			m_sProcessCal.nPowerMethod);
		strMessage += strTemp;
	}

	if(m_sProcessCal.nScalAbsTime != gProcessINI.m_sProcessCal.nScalAbsTime)
	{
		strTemp.Format(_T("| Scal Abs Time : %d "),
			m_sProcessCal.nScalAbsTime);
		strMessage += strTemp;
	}

	if(m_sProcessCal.nScalRelTime != gProcessINI.m_sProcessCal.nScalRelTime)
	{
		strTemp.Format(_T("| Scal Rel Time : %d "),
			m_sProcessCal.nScalRelTime);
		strMessage += strTemp;
	}

	if(m_sProcessCal.nScalCountTime != gProcessINI.m_sProcessCal.nScalCountTime)
	{
		strTemp.Format(_T("| Scal Count Time : %d "),
			m_sProcessCal.nScalCountTime);
		strMessage += strTemp;
	}

	if(m_sProcessCal.nScalCountTime2 != gProcessINI.m_sProcessCal.nScalCountTime2)
	{
		strTemp.Format(_T("| Scal Count Time 2 : %d "),
			m_sProcessCal.nScalCountTime2);
		strMessage += strTemp;
	}
	if(m_sProcessCal.nPowerAbsTime != gProcessINI.m_sProcessCal.nPowerAbsTime)
	{
		strTemp.Format(_T("| Power Abs Time : %d"),
			m_sProcessCal.nPowerAbsTime);
		strMessage += strTemp;
	}

	if(m_sProcessCal.nPowerRelTime != gProcessINI.m_sProcessCal.nPowerRelTime)
	{
		strTemp.Format(_T("| Power Rel Time : %d"),
			m_sProcessCal.nPowerRelTime);
		strMessage += strTemp;
	}

	if(m_sProcessCal.nPowerCountTime != gProcessINI.m_sProcessCal.nPowerCountTime)
	{
		strTemp.Format(_T("| Power Count Time : %d"),
			m_sProcessCal.nPowerCountTime);
		strMessage += strTemp;
	}

	if(m_sProcessCal.nPreheatModulationTime != gProcessINI.m_sProcessCal.nPreheatModulationTime)
	{
		strTemp.Format(_T("| Preheat Modulation Time : %d Hours "), 
			m_sProcessCal.nPreheatModulationTime);
		strMessage += strTemp;
	}
	
	if(m_sProcessCal.nPreheatTime != gProcessINI.m_sProcessCal.nPreheatTime)
	{
		strTemp.Format(_T("| Preheat Time : %d Hours "), 
			m_sProcessCal.nPreheatTime);
		strMessage += strTemp;
	}

	if(m_sProcessCal.nAutoRunPreheatTime != gProcessINI.m_sProcessCal.nAutoRunPreheatTime)
	{
		strTemp.Format(_T("| AutoRun Preheat Time : %d Hours "), 
			m_sProcessCal.nAutoRunPreheatTime);
		strMessage += strTemp;
	}
	
	if(m_sProcessCal.dAutoRunPreheatDuty != gProcessINI.m_sProcessCal.dAutoRunPreheatDuty)
	{
		strTemp.Format(_T("| AutoRun Preheat Duty : %.2f "), 
			m_sProcessCal.dAutoRunPreheatDuty);
		strMessage += strTemp;
	}

	if(m_sProcessCal.nAutoRunPreheatFreq != gProcessINI.m_sProcessCal.nAutoRunPreheatFreq)
	{
		strTemp.Format(_T("| AutoRun Preheat Duty : %d "), 
			m_sProcessCal.nAutoRunPreheatFreq);
		strMessage += strTemp;
	}
	
	if(m_sProcessCal.nPreheatAbsTime != gProcessINI.m_sProcessCal.nPreheatAbsTime)
	{
		strTemp.Format(_T("| Preheat Abs Time : %d"),
			m_sProcessCal.nPreheatAbsTime);
		strMessage += strTemp;
	}
	
	if(m_sProcessCal.nPreheatCountTime != gProcessINI.m_sProcessCal.nPreheatCountTime)
	{
		strTemp.Format(_T("| Preheat Count Time : %d"),
			m_sProcessCal.nPreheatCountTime);
		strMessage += strTemp;
	}

	if(m_sProcessCal.nPreheatRelTime != gProcessINI.m_sProcessCal.nPreheatRelTime)
	{
		strTemp.Format(_T("| Preheat Rel Time : %d"),
			m_sProcessCal.nPreheatRelTime);
		strMessage += strTemp;
	}

	if(m_sProcessCal.bUsePowerCompensationMode != gProcessINI.m_sProcessCal.bUsePowerCompensationMode)
	{
		strTemp.Format(_T("| Use Power Compensation Mode : %d"),
			m_sProcessCal.bUsePowerCompensationMode);
		strMessage += strTemp;
	}
	
	return strMessage;
}

void CPaneProcessSetupOption::EnableControl(BOOL bUse)
{
#ifndef __KUNSAN_LAVIA__
	m_edtAutoCal1stPaneX.EnableWindow(bUse);
	m_edtAutoCal1stPaneY.EnableWindow(bUse);
#else
	if( m_nLevel == 1) 
	{
		m_edtAutoCal1stPaneX.EnableWindow(TRUE);
		m_edtAutoCal1stPaneY.EnableWindow(TRUE);
	}
	else
	{
		m_edtAutoCal1stPaneX.EnableWindow(bUse);
		m_edtAutoCal1stPaneY.EnableWindow(bUse);
	}
#endif
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() != 1)
	{
		#ifndef __KUNSAN_LAVIA__
			m_edtAutoCal2ndPaneX.EnableWindow(bUse);
			m_edtAutoCal2ndPaneY.EnableWindow(bUse);
		#else
			if( m_nLevel == 1) 
			{
				m_edtAutoCal2ndPaneX.EnableWindow(TRUE);
				m_edtAutoCal2ndPaneY.EnableWindow(TRUE);
			}
			else
			{
				m_edtAutoCal2ndPaneX.EnableWindow(bUse);
				m_edtAutoCal2ndPaneY.EnableWindow(bUse);
			}
		#endif
	}

	m_edtErrorRetryCount.EnableWindow(bUse);
	
	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 1)
		m_edtValidMeasureTime.EnableWindow(bUse);

	m_edtValidTime.EnableWindow(bUse);
	m_chkUseApplyTolerance.EnableWindow(bUse);

	UpdateData(TRUE);

	m_edtPreheatModulationTime.EnableWindow(bUse);
	m_edtPreheatTime.EnableWindow(bUse);
	m_edtAutoRunPreheatTime.EnableWindow(bUse);
	m_edtPreheatDuty.EnableWindow(bUse);
	m_edtPreheatFreq.EnableWindow(bUse);
	m_edtSCalPNL.EnableWindow(bUse);
	m_edtSCalPNL2.EnableWindow(bUse);
	m_edtPowerPNL.EnableWindow(bUse);
	m_edtPreheatPNL.EnableWindow(bUse);
	m_edtSCalRelTime.EnableWindow(bUse);
	m_edtPowerRelTime.EnableWindow(bUse);
	m_edtPreheatRelTime.EnableWindow(bUse);
	m_edtPreworkAutoCal1stPaneX.EnableWindow(bUse);
	m_edtPreworkAutoCal1stPaneY.EnableWindow(bUse);
	m_edtPreworkAutoCal2ndPaneX.EnableWindow(bUse);
	m_edtPreworkAutoCal2ndPaneY.EnableWindow(bUse);
	m_chkPowerLotEnd.EnableWindow(bUse);
	m_chkVisionCalMode.EnableWindow(bUse);
	m_chkUsePreworkPerCount.EnableWindow(bUse);
	m_edtScalFieldCount.EnableWindow(bUse);
	m_edtVisionCalFieldCount.EnableWindow(bUse);
#ifndef __KUNSAN_LAVIA__
	m_chkUseApplyTolerance.EnableWindow(bUse);
#else
	if(m_nLevel == 1)
		m_chkUseApplyTolerance.EnableWindow(TRUE);
	else
		m_chkUseApplyTolerance.EnableWindow(bUse);
#endif
	m_edtPreheatRelTime.EnableWindow(bUse);
	m_edtPreworkAutoCal2ndPaneY.EnableWindow(bUse);
	m_edtPreworkAutoCal2ndPaneX.EnableWindow(bUse);
	m_edtPreworkAutoCal1stPaneY.EnableWindow(bUse);
	m_edtPreworkAutoCal1stPaneX.EnableWindow(bUse);

	m_chkUsePowerCompensationMode.EnableWindow(bUse);
}

void CPaneProcessSetupOption::SetAuthorityByLevel(int nLevel)
{
	m_nLevel = nLevel;

	switch(nLevel)
	{
	case 0:
		EnableControl(FALSE);
		break;
	case 1:
#ifdef __KUNSAN_LAVIA__
		EnableControl(FALSE);
		break;
#endif
	case 2:
	case 3:
		EnableControl(TRUE);
		break;
	}
	m_nLevel = nLevel;
}
void CPaneProcessSetupOption::OnCheckUseCountUnit()
{
	BOOL bCheck = m_chkUsePreworkPerCount.GetCheck();

	if(m_nLevel == 0)
		return;
#ifdef __KUNSAN_LAVIA__
	if(m_nLevel == 1)
		return;
#endif
//	m_edtPreheatRelTime.EnableWindow(!bCheck);
	m_edtSCalRelTime.EnableWindow(!bCheck);
	m_edtPowerRelTime.EnableWindow(!bCheck);

	m_edtSCalPNL.EnableWindow(bCheck);
	m_edtSCalPNL2.EnableWindow(bCheck);
//	m_edtPreheatPNL.EnableWindow(bCheck);
	m_edtPowerPNL.EnableWindow(bCheck);

}

BOOL CPaneProcessSetupOption::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Process_Option) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}
void CPaneProcessSetupOption::InitComboControl()
{
	m_fntCombo.CreatePointFont(130, _T("Arial Bold"));

	m_cmbTool.SetFont( &m_fntCombo );
	m_cmbTool.SetCurSel( 0 );

#if defined ( __OSAN_LG_2013__) || defined (__ANSAN_KCC__) || defined(__OSAN_LG__)
	m_cmbTool.ShowWindow(SW_HIDE);
#else
	if(!gProcessINI.m_sProcessSystem.bNoUsePrework)
		m_cmbTool.ShowWindow(SW_HIDE);
#endif

	SetToolComboBox();
}

void CPaneProcessSetupOption::SetToolComboBox()
{
	m_cmbTool.ResetContent();

	CString strTool;

	for(int i = 0; i <= gBeamPathINI.m_sBeampath.nLastIndex; i++)
	{
		strTool.Format(_T("No %d : %s"), gBeamPathINI.m_sBeampath.nInfoId[i], gBeamPathINI.m_sBeampath.strInfoName[i]);
		m_cmbTool.AddString(strTool);
	}
}
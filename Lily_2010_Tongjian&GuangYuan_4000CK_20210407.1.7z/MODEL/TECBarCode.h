/*===========================================================================*/
/*                        Copyright (C) 1996-2000 by                         */
/*                                                                           */
/*                    -- TEC-IT Datenverarbeitung GmbH --                    */
/*   -- team for engineering and consulting in information technologies --   */
/*                                                                           */
/*                           All rights reserved.                            */
/*                                                                           */
/*              This is a part of the TEC-IT Standard Software.              */
/*                                                                           */
/*    This source code is only intended as a supplement to the References    */
/*      and related electronic documentation provided with the product.      */
/*                                                                           */
/*     See these sources for detailed information regarding this product     */
/*===========================================================================*/
#ifndef __TECBARCODE_H__
#define __TECBARCODE_H__

#undef TECIT_DLLSPEC
#ifdef WIN32
#ifdef TECIT_DLLEXPORT
#define TECIT_DLLSPEC _declspec (dllexport)
#endif
#ifdef TECIT_DLLIMPORT
#define TECIT_DLLSPEC _declspec (dllimport)
#endif
#endif	
#ifndef TECIT_DLLSPEC
#define TECIT_DLLSPEC
#endif

#ifdef __cplusplus
	extern "C"
	{
#endif

/*/////////////////////////////////////////////////////////////////////////////
//
//	We are using 8 Byte Alignment
//
/////////////////////////////////////////////////////////////////////////////*/
//TN #pragma pack (push, 8)
/*/////////////////////////////////////////////////////////////////////////////
//
//	General Information
//
/////////////////////////////////////////////////////////////////////////////*/
/*/////////////////////////////////////////////////////////////////////////////
//
//   If any of the BCxxxx functions below returns an error code not equal to 
//	 zero than DO NOT call subsequent BCxxxx functions except of BCDeInit ().
//
//   An error code <> 0 indicates an error condition at subsequent calls 
//	 (except to BCDeInit) may fail and produce unexpected results.
//
/////////////////////////////////////////////////////////////////////////////*/
/*/////////////////////////////////////////////////////////////////////////////
//
//	 BCLicenseMe:This function licenses the DLL. It's not required to call this
//				function each time you use the DLL in your program (although
//				it's allowed). 
//				Licensing must be performed per computer system at least once.
//				(e.g. in the setup program of your application)
//
//   BCAlloc:	This function initalizes the Barcode-Info structure.
//				It must be called before any other BCxxxx function.
//
//   BCCheck:	This function checks if the data charcters are valid for the
//				selected barcode type. If invalid data was encountered it 
//				returns an error-code <> 0.
//				It must be called before BCCalcCD().
//
//   BCCalcCD:	This function computes the check digit(s) for the given data.
//				It must be called before BCCreate().
//
//   BCCreate:	This function prepares the barcode-info structure to be drawn 
//				with BCDraw. It returns ErrOk if the everything is
//				ok. If not it returns an error-code which specifies the
//				error in more detail.
//
//   BCDraw:	This function draws a barcode into the given device-
//				context. No spacial mapping is performed. 
// 
//				* if nBarWidth is equal to BC_USEDEFAULT the standard  
//				bar/space ratios are used. See TECBCEnum.h
//
//				* if sRatio is not NULL and is not equal to an empty string  
//				then it is analyzed and the print ratios are adjusted as 
//				specified in sRatio. See TECBCEnum.h
//
//				* if sModWidth is not NULL and is not equal to an empty string  
//				then it is converted to a numeber which specifies the modul
//				width [1/1000 mm]. See TECBCEnum.h
//
//	 BCGetReatioString 
//				This function return a string containing intoamtion about the
//				expected ratio input.
//
//	 BCGetMaxLenOfData 
//				This function returns a long, representing the maximum allowed
//				number of chars for the pIn (RawData)
//
//
//   BCFree:	This function de-initalizes the Barcode-Info structure and
//				frees allocated memory. It must be called as last function.
//
/////////////////////////////////////////////////////////////////////////////*/

#ifndef TEC_UNIX
	#include <windef.h>
#endif

#ifndef TBC_ATL
	#define	TECIT_NO_HELPSTRINGS
	#include "TECBCEnum.h"
	#undef	TECIT_NO_HELPSTRINGS
#else
	#include "../TBarCode_ATL/TBarCode_ATL.h"
#endif

#ifdef TEC_UNIX
	#include "TECBarCStruct.h"
	#include "TECBCEnum.h"
#else
/*/////////////////////////////////////////////////////////////////////////////
//
//	Forwards
//
/////////////////////////////////////////////////////////////////////////////*/
typedef struct tag_BarCode	t_BarCode;
#endif

typedef	struct tag_Victor	t_Victor;
#define	ERRCODE				LONG

typedef ERRCODE				(CALLBACK *fn_DrawRow)	(VOID*, t_BarCode* const, HDC, HDC, RECT*);

typedef	ERRCODE				(CALLBACK *fn_DrawBar)	(VOID*, HDC, RECT*);
typedef ERRCODE				(CALLBACK *fn_DrawText)	(VOID*, HDC, LPLOGFONT, INT, INT, UINT, LPCTSTR, INT);

/*typedef ERRCODE			(CALLBACK *fn_DrawText)	
							(
							VOID*,			// user data
							HDC,			// device context
							LPLOGFONT,		// log font structure
							INT,			// horiz. position
							INT,			// vert. position
							UINT,			// alignment (use windows defines)
							LPCTSTR,		// text to be drawn
							INT				// text length
							);
*/

/*/////////////////////////////////////////////////////////////////////////////
//
//	Constants
//
/////////////////////////////////////////////////////////////////////////////*/
#define	BC_USEDEFAULT	-1


/*----------------------------------------------------------------------------/
	
		A T T A C H / D E T A C H	- library

		call these functions to inititialize/deinitialize the library
		for use with TBarCode_LIB only (not needed by DLL users)

/----------------------------------------------------------------------------*/

///////////////////////////////////////////////////////////////////////////////
//	lib attach
///////////////////////////////////////////////////////////////////////////////
BOOL _stdcall	BCAttach 
(
);

////////////////////////////////////////////////////////////////////////////////
//	lib attach (with given instance handle)
///////////////////////////////////////////////////////////////////////////////
BOOL _stdcall	BCAttachInstance 
(
HINSTANCE		hInstance
);

//////////////////////////////////////////////////////////////////////////////
//	lib detach
///////////////////////////////////////////////////////////////////////////////
BOOL _stdcall	BCDetach();


/*----------------------------------------------------------------------------/
	
		I N I T / D E I N I T   - Functions

/----------------------------------------------------------------------------*/

/*/////////////////////////////////////////////////////////////////////////////
//	Allocate and initialize bar code structure
//	
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCAlloc
(
t_BarCode**					pBarCode	/* OUT : Ptr To Barcode struct		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	DeInitialize and free bar code structure
//	
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCFree
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);


/*----------------------------------------------------------------------------/
	
		P R O P E R T Y	  S E T - Functions

/----------------------------------------------------------------------------*/

/*/////////////////////////////////////////////////////////////////////////////
//	Set bar code color
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC 
ERRCODE		_stdcall		BCSetColorBC
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
COLORREF					color		/* IN : color						 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set font color
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetColorFont
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
COLORREF					color		/* IN : color						 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set background color
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetColorBk
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
COLORREF					color		/* IN : color						 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set background mode/background style
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetBkMode
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nMode		/* IN : background mode				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set GDI drawing method (use DrawRect instead of clipped TextOut)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetDrawMode
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
BOOL						bUseGDIRect /* IN : true = Use GDI Rectangle for Drawing */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Quietzone
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetQuietZone
(
t_BarCode*	const			pBarCode,		/* IN : Ptr To Barcode-Definition						*/
LPRECT		const			prQuietZone,	/* IN : Ptr to rectangle that specifies quietzone		*/
e_QZMUnit					eQZMUnit        /* IN : Unit for Quietzone values (mm, Modules, mils...)*/
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set log font
//	attention:	set lfHeight field to the point size of the font!
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetLogFont
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
const LOGFONT*				lf			/* IN : logfont						 */
);


/*/////////////////////////////////////////////////////////////////////////////
//	Set bar code type
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetBCType
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
e_BarCType					eType		/* IN : bar code type				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set check digit method
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetCDMethod
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
e_CDMethod					eMethod		/* IN : check digit method			 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set auto correct
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetAutoCorrect
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
BOOL						bAutoCorrect/* IN : autocorrect -> T/F			 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set rotation
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetRotation
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
e_Degree					eRotation	/* IN : rotation					 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set print text / text above
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetPrintText
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
BOOL						bReadable,	/* IN : print readable text			 */
BOOL						bAbove		/* IN : print text above 
												(only, if readable)			 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set guard width
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetGuardWidth
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nGuardWidth	/* IN : guard width  [1/1000 mm]	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set text distance
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetTextDist
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nTextDist	/* IN : Text distance: bar code 
												<--> text [1/1000 mm]		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set notch height (bar code types EAN..., UPC...)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetNotchHeight
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nHeight		/* IN : notch height [1/1000 mm]	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Tranlate Escape Sequences
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetTranslateEsc
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
BOOL						bTranslate	/* IN : translate -> T/F			 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set 'must fit' flag
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetMustFit
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
BOOL						bMustFit	/* IN : must bar code fit into 
												bounding rectangle -> T/F	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set 'round to pixel' flag
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetOptResolution
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
BOOL						bOpt		/* IN : optimze for resolution->T/F	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set mirror flag
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetMirror
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
BOOL						bMirror		/* IN : mirror bar code -> T/F		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set user definded resolution
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetDPI
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nDPIHorz,	/* IN :	user defined horizontal DPI	 */
LONG						nDPIVert	/* IN :	user defined vertical DPI	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set bar code text
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetText
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LPCTSTR						szText,		/* IN : barcode text				 */
LONG						nLen		/* IN :	length of input string, 
												0 .. terminated by \0		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set bar code text (unicode version)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetTextW
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LPCWSTR						szText,		/* IN : barcode text				 */
LONG						nLen		/* IN :	length of input string, 
												0 .. terminated by \0		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set display text
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetDisplayText
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LPCTSTR						szText		/* IN : display text				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set module width
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetModWidth
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LPCTSTR						szModWidth	/* IN : module width				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set format
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetFormat
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LPCTSTR						szFormat	/* IN : format						 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set ratio
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetRatio
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LPCTSTR						szRatio		/* IN : ratio						 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set code width reduction
//
//	If the reduction factor is set, the width each bar is reduced by
//	module width * factor
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetBarWidthReduction
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nFactor		/* IN : reduction in percent		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set text alignment (left, right, center, default)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetTextAlignment
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
e_BCAlign					eAlign		/* IN : text alignment				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set call back function for drawing a single row
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSetFuncDrawRow
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
fn_DrawRow					fn,			/* IN : call-back function			 */
LPVOID						pData		/* IN :	custom data to pass to call	 */
										/*		back functions				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set PDF417 rows
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_Rows
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nRows		/* IN : number of rows [3..90]		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set PDF417 columns
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_Columns
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nColumns	/* IN : number of columns [1..30]	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set PDF417 error correction level
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_ECLEvel
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nLevel		/* IN : error correction level [0..8]*/
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set PDF417 row height
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_RowHeight
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nHeight		/* IN : row height [1/1000 mm]		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set PDF417 row/column ratio
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_RowColRatio
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LPCTSTR						szRatio		/* IN : ratio rows:columns			 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Macro PDF417 segment index
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_SegIndex
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nSegInx		/* IN : segment index				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Macro PDF417 FileID
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_FileID
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LPCTSTR						szFileID	/* IN : File ID string				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set if actual segment symbol is the last one
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_SegLast
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
BOOL						bSegLast	/* IN : Is last segment T/F			 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Macro PDF417 File Name
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_FileName
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LPCTSTR						szFileName	/* IN : File name					 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Macro PDF417 segment count
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_SegCount
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nSegCount	/* IN : segment count				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Macro PDF417 Time Stamp
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_TimeStamp
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nTimeStamp	/* IN : time stamp					 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Macro PDF417 Sender
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_Sender
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LPCTSTR						szSender	/* IN : Sender						 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Macro PDF417 Addressee
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_Addressee
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LPCTSTR						szAddressee	/* IN : Addressee					 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Macro PDF417 File Size
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_FileSize
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nFileSize	/* IN : File Size					 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Macro PDF417 File Size
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_PDF417_CheckSum
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nCheckSum	/* IN : Check sum					 */
);


/*/////////////////////////////////////////////////////////////////////////////
//	Set Maxi code mode
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_Maxi_Mode
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nMode		/* IN : mode [2..5]					 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Maxi code structured append
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_Maxi_Append
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nSum,		/* IN : number of symbols [2..8]	 */
LONG						nIndex		/* IN : index of symbol [1..8]		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Maxi code undercut of hexagon
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_Maxi_UnderCut
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nUndercut	/* IN : undercut in percent [1..100] */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Maxi code use preamble
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_Maxi_UsePreamble
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
BOOL						bUse,		/* IN : Use preamble ("[)>...")->T/F */
LPCTSTR						szDate		/* IN :	preamble date 
												(only, if using preamble)	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Maxi code structured carrier message (SCM)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_Maxi_SCM
(
t_BarCode*	const			pBarCode,		/* IN : Ptr To Barcode-Definition*/
LPCTSTR						szServiceClass,	/* IN : service class			 */
LPCTSTR						szCountryCode,	/* IN : country code			 */
LPCTSTR						szPostalCode	/* IN : postal code				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Data Matrix Size
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_DM_Size
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
e_DMSizes					eSize		/* IN :	bar code size				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Is Data Matrix rectangular -> TRUE/FALSE
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_DM_Rectangular
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
BOOL						bRect		/* IN :	rectangular TRUE/FALSE		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Data Matrix Format (UCC/EAN, Macro05, Macro06, 
//	particual industry, default)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_DM_Format
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
e_DMFormat					eFormat		/* IN : Data Matrix format			 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Data Matrix structured append
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_DM_Append
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nSum,		/* IN : number of symbols [2..16]	 */
LONG						nIndex,		/* IN : index of symbol [1..16]		 */
LONG						nFileID		/* IN : File ID 
											(must be the same in all symbols)*/
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set QR Code version (= symbol size)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_QR_Version
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
e_QRVersion					eVersion	/* IN :	symbol version (size)		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set QR Code Format (UCC/EAN, Industry, default)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_QR_Format
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
e_QRFormat					eFormat		/* IN : QR Code format				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set QR Code Format application indicator (used with Industry format)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_QR_FmtAppIndicator
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LPCTSTR						szIndicator	/* IN :	format application indicator */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get QR Code Error Correction Level
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_QR_ECLevel
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
e_QRECLevel					eECLevel	/* IN : error correction level		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set QR Code Mask pattern (0-7)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_QR_Mask
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
e_QRMask					eMask		/* IN :	Mask pattern				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get QR Code structured append sum
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_QR_Append
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nSum,		/* IN : number of symbols [2..16]	 */
LONG						nIndex,		/* IN : index of symbol [1..16]		 */
BYTE						bParity		/* IN : parity byte
											(must be the same in all symbols)*/
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Codablock F rows
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_CBF_Rows
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nRows		/* IN : number of rows [2..44]		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Codablock F columns
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_CBF_Columns
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nColumns	/* IN : number of columns [4..62]	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Codablock F row height
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_CBF_RowHeight
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nHeight		/* IN : row height [1/1000 mm]		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Codablock F row separator height
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_CBF_RowSeparatorHeight
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
LONG						nHeight		/* IN : row separator height 
															[1/1000 mm]		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Set Codablock F Code Format (UCC/EAN, default)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCSet_CBF_Format
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
e_CBFFormat					eFormat		/* IN : Codablock F format			 */
);


/*----------------------------------------------------------------------------/
	
		P R O P E R T Y	  G E T - Functions

/----------------------------------------------------------------------------*/

/*/////////////////////////////////////////////////////////////////////////////
//	Get bar code color
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
COLORREF	_stdcall		BCGetColorBC
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get font color
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
COLORREF	_stdcall		BCGetColorFont
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get background color
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
COLORREF	_stdcall		BCGetColorBk
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get background mode/background style
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGetBkMode
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get GDI drawing method (use Rectangle = true; use clipped TextOut = false)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
BOOL		_stdcall		BCGetDrawMode
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Quietzone
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCRECT		_stdcall		BCGetQuietZone
(
t_BarCode*	const			pBarCode	   /* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Quietzone Unit
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
e_QZMUnit	  _stdcall		BCGetQuietZoneUnit
(
t_BarCode*	const			pBarCode	   /* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get log font
//	attention:	Get lfHeight field to the point size of the font!
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LOGFONT*	_stdcall		BCGetLogFont
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);


/*/////////////////////////////////////////////////////////////////////////////
//	Get bar code type
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
e_BarCType	_stdcall		BCGetBCType
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get check digit method
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
e_CDMethod	_stdcall		BCGetCDMethod
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get auto correct
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
BOOL		_stdcall		BCGetAutoCorrect
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get rotation
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
e_Degree	_stdcall		BCGetRotation
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get print text
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
BOOL		_stdcall		BCGetPrintText
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get text above
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
BOOL		_stdcall		BCGetTextAbove
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get guard width
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGetGuardWidth
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get text distance
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGetTextDist
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get notch height
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGetNotchHeight
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Tranlate Escape Sequences
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
BOOL		_stdcall		BCGetTranslateEsc
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get 'must fit' flag
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
BOOL		_stdcall		BCGetMustFit
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get 'round to pixel' flag
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
BOOL		_stdcall		BCGetOptResolution
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get mirror flag
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
BOOL		_stdcall		BCGetMirror
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get user defined resolution (horizontal)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGetDPIHorz
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get user defined resolution (vertical)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGetDPIVert
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get bar code text
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGetText
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get bar code text (unicode version)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCWSTR		_stdcall		BCGetTextW
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get display text
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGetDisplayText
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	determine if currently set text is in UNICODE or ANSI character set
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
BOOL		_stdcall		BCIsTextUnicode
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get bar code text length
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGetTextLen
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get module width
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGetModWidth
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get format
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGetFormat
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get ratio
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGetRatio
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get code width reduction (in percent)
//
//	If the reduction factor is set, the width each bar is reduced by
//	module width * factor
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGetBarWidthReduction
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get text alignment (left, right, center, default)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
e_BCAlign		_stdcall	BCGetTextAlignment
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get call back function for drawing a single row
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
fn_DrawRow	_stdcall		BCGetFuncDrawRow
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get PDF417 rows
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_PDF417_Rows
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get PDF417 columns
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_PDF417_Columns
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get PDF417 error correction level
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_PDF417_ECLEvel
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get PDF417 row height
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_PDF417_RowHeight
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get PDF417 row/column ratio
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGet_PDF417_RowColRatio
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Macro PDF417 segment index
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_PDF417_SegIndex
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Macro PDF417 FileID
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGet_PDF417_FileID
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Returns if actual segment symbol is the last one
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
BOOL		_stdcall		BCGet_PDF417_SegLast
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Macro PDF417 File Name
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGet_PDF417_FileName
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Macro PDF417 segment count
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_PDF417_SegCount
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Macro PDF417 Time Stamp
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_PDF417_TimeStamp
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Macro PDF417 Sender
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGet_PDF417_Sender
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Macro PDF417 Addressee
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGet_PDF417_Addressee
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Macro PDF417 File Size
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_PDF417_FileSize
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Macro PDF417 File Size
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_PDF417_CheckSum
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Maxi code mode
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_Maxi_Mode
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Maxi code structured append sum
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_Maxi_AppendSum
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Maxi code structured append index
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_Maxi_AppendIndex
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Maxi code undercut of hexagon
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_Maxi_UnderCut
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Maxi code use preamble
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
BOOL		_stdcall		BCGet_Maxi_UsePreamble
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Maxi code preamble date
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGet_Maxi_PreambleDate
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Maxi code structured carrier message (SCM)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGet_Maxi_SCMServClass
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Maxi code structured carrier message (SCM)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGet_Maxi_SCMCountryCode
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Maxi code structured carrier message (SCM)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGet_Maxi_SCMPostalCode
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Data Matrix Size
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
e_DMSizes	_stdcall		BCGet_DM_Size
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Is Data Matrix rectangular -> TRUE/FALSE
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
BOOL		_stdcall		BCGet_DM_Rectangular
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Data Matrix Format (UCC/EAN, Macro05, Macro06, 
//	particual industry, default)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
e_DMFormat	_stdcall		BCGet_DM_Format
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Data Matrix structured append sum
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_DM_AppendSum
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */

);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Data Matrix structured append index
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_DM_AppendIndex
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Data Matrix structured append file ID
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_DM_AppendFileID
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get QR Code version (= symbol size)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
e_QRVersion	_stdcall		BCGet_QR_Version
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get QR Code Format (UCC/EAN, Industry, default)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
e_QRFormat	_stdcall		BCGet_QR_Format
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get QR Code Format application indicator (used with Industry format)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGet_QR_FmtAppIndicator
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get QR Code Error Correction Level
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
e_QRECLevel	_stdcall		BCGet_QR_ECLevel
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get QR Code Mask pattern (0-7)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
e_QRMask	_stdcall		BCGet_QR_Mask
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get QR Code structured append sum
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_QR_AppendSum
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */

);

/*/////////////////////////////////////////////////////////////////////////////
//	Get QR Code structured append index
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_QR_AppendIndex
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get QR Code structured append parity byte
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
BYTE		_stdcall		BCGet_QR_AppendParity
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Codablock F rows
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_CBF_Rows
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Codablock F columns
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_CBF_Columns
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Codablock F row height
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_CBF_RowHeight
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Codablock F row seperator height
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGet_CBF_RowSeparatorHeight
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get Codablock F Format (UCC/EAN, default)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
e_CBFFormat	_stdcall		BCGet_CBF_Format
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*----------------------------------------------------------------------------/
	
		M E T H O D S

/----------------------------------------------------------------------------*/

/*/////////////////////////////////////////////////////////////////////////////
//	License the DLL
//	
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCLicenseMe
(
LPCTSTR						lpszLicensee,	/* IN : Licensee name			 */
e_licKind					eKindOfLicense,	/* IN : kind of license			 */
DWORD						dwNoOfLicenses,	/* IN : number of licenses		 */
LPCTSTR						lpszKey,		/* IN : License Key				 */
e_licProduct				eProductID		/* IN : Product ID				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Returns ratio-String
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGetRatioString
(
e_BarCType					eType		/* IN : bar code					 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Returns ratio-String
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR		_stdcall		BCGetRatioHint
(
e_BarCType					eType		/* IN : bar code	 				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Returns the exact number of chars that have to be in pIn (RawData)
//  Returns 0 if there is no specified length or BarcodeType not known
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGetMaxLenOfData
(
e_BarCType					eType		/* IN : bar code	 				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Check barcode input data for validity
//	
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCCheck
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Calculate Check Digit
//	
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCCalcCD
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	Create barcode-string from data according to the specified barcode-struct
//	
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCCreate
(
t_BarCode*	const			pBarCode	/* IN : Ptr To Barcode-Definition	 */
);

#ifndef TEC_UNIX
/*/////////////////////////////////////////////////////////////////////////////
//	Draw barcode into Device Context
//	
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCDraw
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
HDC							hDC,		/* IN : Device Context Handle		 */
RECT*						pRect		/* IN : Bounding Rectangle			 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	callback version of draw function
//	
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE		_stdcall		BCDrawCB
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	 */
HDC							hDC,		/* IN : Device Context Handle		 */
RECT*						pRect,		/* IN : Bounding Rectangle			 */
fn_DrawBar					fnDrawBar,	/* IN : callback -> drawing bars	 */ 
fn_DrawText					fnDrawText,	/* IN : callback -> drawing text	 */ 
LPVOID						pData		/* IN :	custom data to pass to call	 */
										/*		back functions				 */
);
#endif

/*/////////////////////////////////////////////////////////////////////////////
//	Returns List of implemented Barcodes (in Text)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR*	_stdcall		BCGetBCList
(
);

/*/////////////////////////////////////////////////////////////////////////////
//	Returns Size of barcode list
/////////////////////////////////////////////////////////////////////////////*/	
TECIT_DLLSPEC	
LONG		_stdcall		BCGetBCCount
(
);

/*/////////////////////////////////////////////////////////////////////////////
//	Returns List of implemented Check Digits (in Text), dependent on type
/////////////////////////////////////////////////////////////////////////////*/	
TECIT_DLLSPEC	
e_CDMethod*	_stdcall		BCGetCDListByType
(
e_BarCType	eBCType
);

/*/////////////////////////////////////////////////////////////////////////////
//	returns name of check digit method
/////////////////////////////////////////////////////////////////////////////*/	
TECIT_DLLSPEC	
LPCTSTR	_stdcall			BCGetNameFromEnum
(
e_CDMethod	eCDMethod
);

/*/////////////////////////////////////////////////////////////////////////////
//	Returns List of implemented Check Digit methods (in Text)
/////////////////////////////////////////////////////////////////////////////*/	
TECIT_DLLSPEC	
LPCTSTR*	_stdcall		BCGetCDList
(
);

/*/////////////////////////////////////////////////////////////////////////////
//	Returns Size of check digit method list
/////////////////////////////////////////////////////////////////////////////*/	
TECIT_DLLSPEC	
LONG		_stdcall		BCGetCDCount
(
);

/*/////////////////////////////////////////////////////////////////////////////
//	Copies check digits into buffer (lpszCDText = NULL returns number of check digits)
//	
//	Returns: count of copied check digits (-1 = error, buffer size to small)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG		_stdcall		BCGetCheckDigits
(
t_BarCode*	const			pBarCode,	/* IN : Ptr To Barcode-Definition	*/
LPTSTR						lpszCDText,	/* IO:	check digit text buffer		*/
LONG						nSize		/* IN :	buffer size of szText		*/
);


/*/////////////////////////////////////////////////////////////////////////////
//	Returns List of implemented Data Matrix sizes
/////////////////////////////////////////////////////////////////////////////*/	
TECIT_DLLSPEC	
LPCTSTR*	_stdcall		BCGetDataMatrixSizes
(
);

/*/////////////////////////////////////////////////////////////////////////////
//	Returns Size of Data Matrix sizes list
/////////////////////////////////////////////////////////////////////////////*/	
TECIT_DLLSPEC	
LONG		_stdcall		BCGetDataMatrixSizesCount
(
);

/*/////////////////////////////////////////////////////////////////////////////
//	Returns List of implemented QR Code versions
/////////////////////////////////////////////////////////////////////////////*/	
TECIT_DLLSPEC	
LPCTSTR*	_stdcall		BCGetQRCodeVersions
(
);

/*/////////////////////////////////////////////////////////////////////////////
//	Returns Size of QR Code versions list
/////////////////////////////////////////////////////////////////////////////*/	
TECIT_DLLSPEC	
LONG		_stdcall		BCGetQRCodeVersionCount
(
);

/*/////////////////////////////////////////////////////////////////////////////
//	computes the number of modules in code
//	
//	Returns: number of modules
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
DOUBLE	_stdcall		BCGetCountModules
(
const t_BarCode* const	pBarCode		/* IN : Ptr To Barcode-Definition	 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	computes the number of rows in code
//	
//	Returns: number of rows
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
DOUBLE	_stdcall		BCGetCountRows
(
const t_BarCode* const	pBarCode		/* IN : Ptr To Barcode-Definition	 */
);

#ifndef TEC_UNIX
/*/////////////////////////////////////////////////////////////////////////////
//	computes the module width in 
//	
//	Returns: module width
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
DOUBLE	_stdcall	BCGetModuleWidth
(
t_BarCode*	const	pBarCode,			/* IN : Ptr To Barcode-Definition	 */
LPRECT				pRect,				/* IN : bounding rectangle			 */
HDC					hDC,				/* IN : Device Context Handle		 */
e_MUnit				eUnit				/* IN : unit of measure				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	computes the barcode width
//	
//	Returns: barcode width
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
DOUBLE	_stdcall	BCGetBarcodeWidth
(
t_BarCode*	const	pBarCode,			/* IN : Ptr To Barcode-Definition	 */
LPRECT				pRect,				/* IN : bounding rectangle			 */
HDC					hDC,				/* IN : Device Context Handle		 */
e_MUnit				eUnit				/* IN : unit of measure				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	computes the barcode height
//
//	Returns: barcode width
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
DOUBLE	_stdcall	BCGetBarcodeHeight
(
t_BarCode* const	pBarCode,			/* IN : Ptr To Barcode-Definition	 */
LPRECT				pRect,				/* IN : bounding rectangle			 */
HDC					hDC,				/* IN : Device Context Handle		 */
e_MUnit				eUnit				/* IN : unit of measure              */
);
#endif

/*/////////////////////////////////////////////////////////////////////////////
//	returns number of bar widths for given barcode type
//	
//	Returns: number of bar widths (or -1 if not successfull)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG	_stdcall	BCGetCountBars
(
e_BarCType			eBarCType			/* IN : barcode type				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	returns number of space widths for given barcode type
//	
//	Returns: number of space widths (or -1 if not successfull)
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG	_stdcall	BCGetCountSpaces
(
e_BarCType			eBarCType			/* IN : barcode type				 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	returns drawing quality of barcode (in percent)
//	0 .. unreadable, 100 .. perfect
//	
//	Returns: bar code drawing quality
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG	_stdcall	BCGetQuality
(
t_BarCode*	const	pBarCode,	/* IN : Ptr To Barcode-Definition	*/
HDC					hDC,		/* IN : Device Context Handle		*/
RECT*				pRect		/* IN : Bounding Rectangle			*/
);

/*/////////////////////////////////////////////////////////////////////////////
//	Get number of PDF417 code words
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LONG	_stdcall	BCGet_PDF417_CodeWords
(
t_BarCode*	const	pBarCode			/* IN : Ptr To Barcode-Definition	*/
);

/*/////////////////////////////////////////////////////////////////////////////
//	calculate structured append parity byte
// 
//	Returns: parity byte
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
BYTE	_stdcall	BCCalcStructApp_Parity
(
LPCTSTR				szIntData,			/* IN:	input data					*/
LONG				nIntData			/* IN:	length of input data		*/
);

/*/////////////////////////////////////////////////////////////////////////////
//	get metadata representation of bar code
// --------------------------------------------------------------------------
//	this function must be called from within the row callback function
//	set by BCSetFuncDrawRow (function type fn_DrawRow). 
//	Otherwise always NULL is returned.
// --------------------------------------------------------------------------
//	Returns: meta data string
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
LPCTSTR	_stdcall	BCGetMetaData
(
t_BarCode*	const	pBarCode			/* IN : Ptr To Barcode-Definition	*/
);

#ifndef TEC_UNIX
/*/////////////////////////////////////////////////////////////////////////////
//	returns error text to given error code
//	
//	Returns: error code of function
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
VOID	 _stdcall	BCGetErrorText
(
ERRCODE				eCode,				/* IN :	error code					 */
LPTSTR				szText,				/* IO:	error text buffer			 */
size_t				nSize				/* IN :	buffer size of szText		 */
);

/*/////////////////////////////////////////////////////////////////////////////
//	copies barcode to clipboard
//	
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE	_stdcall	BCCopyToClipboard
(
t_BarCode*	const	pBarCode,			/* IN : Ptr To Barcode-Definition	 */
LONG				nWidth,				/* IN : width of barcode to copy     */
LONG				nHeight				/* IN : height of barcode to copy    */
);

/*/////////////////////////////////////////////////////////////////////////////
//	copies barcode to clipboard
//	
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE	_stdcall	BCCopyToClipboardEx
(
t_BarCode*	const	pBarCode,		/* IN : Ptr To Barcode-Definition							*/
HDC					hDC,			/* IN : device context to copy from (default: NULL)			*/
LONG				nWidth,			/* IN : width of barcode to copy							*/
LONG				nHeight,		/* IN : height of barcode to copy							*/
BOOL				fTransparent,	/* IN : Barcode transparent or not							*/
COLORREF			crBkCol,		/* IN : Background color (only if fTransparent == FALSE)	*/
LPCTSTR				szFileName		/* IN : name of enh. metafile, that the barcode should		*/
									/*      be copied to (NULL for clipboard only)				*/
);

/*/////////////////////////////////////////////////////////////////////////////
//	draws barcode and saves it as image to a file
//	
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE	_stdcall	BCSaveImage
(
t_BarCode*	const	pBarCode,			/* IN : Ptr To Barcode-Definition	                    */
LPCTSTR				lpszFileName,		/* IN : Filename										*/
e_IMType			eImageType,			/* IN : Enumeration for the type of the image			*/
LONG				lXSize,				/* IN : X-Size of the image [pixel]						*/
LONG				lYSize,				/* IN : Y-Size of the image [pixel]						*/
LONG				lXRes,				/* IN : X-Resolution of the image [pixels / inch]		*/
LONG				lYRes				/* IN : Y-Resolution of the image [pixels / inch]		*/
);

/*/////////////////////////////////////////////////////////////////////////////
//	draws barcode and saves it as image to a file
//	
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE	_stdcall	BCSaveImageEx
(
t_BarCode*	const	pBarCode,			/* IN : Ptr To Barcode-Definition	                    */
HDC					hDC,				/* IN :	device context (default: NULL)					*/
LPCTSTR				lpszFileName,		/* IN : Filename										*/
e_IMType			eImageType,			/* IN : Enumeration for the type of the image			*/
LONG				lQuality,			/* IN : Image Quality (meaning depends on image type)	*/		
LONG				lXSize,				/* IN : X-Size of the image [pixel]						*/
LONG				lYSize,				/* IN : Y-Size of the image [pixel]						*/
LONG				lXRes,				/* IN : X-Resolution of the image [pixels / inch]		*/
LONG				lYRes				/* IN : Y-Resolution of the image [pixels / inch]		*/
);

/*/////////////////////////////////////////////////////////////////////////////
//	draws barcode and saves it as image to a memory buffer
//	
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE	_stdcall	BCSaveImageToBuffer
(
t_BarCode*	const	pBarCode,			/* IN : Ptr To Barcode-Definition	                    */
LPSTR*				lpszBuffer,			/* OUT: buffer											*/
e_IMType			eImageType,			/* IN : Enumeration for the type of the image			*/
LONG				lXSize,				/* IN : X-Size of the image [pixel]						*/
LONG				lYSize,				/* IN : Y-Size of the image [pixel]						*/
LONG				lXRes,				/* IN : X-Resolution of the image [pixels / inch]		*/
LONG				lYRes				/* IN : Y-Resolution of the image [pixels / inch]		*/
);

/*/////////////////////////////////////////////////////////////////////////////
//	draws barcode and saves it as image to a memory buffer
//	
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE	_stdcall	BCSaveImageToBufferEx
(
t_BarCode*	const	pBarCode,			/* IN : Ptr To Barcode-Definition	                    */
HDC					hDC,				/* IN :	device context (default: NULL)					*/
LPSTR*				lpszBuffer,			/* OUT: buffer											*/
e_IMType			eImageType,			/* IN : Enumeration for the type of the image			*/
LONG				lQuality,			/* IN : Image Quality (meaning depends on image type)	*/		
LONG				lXSize,				/* IN : X-Size of the image [pixel]						*/
LONG				lYSize,				/* IN : Y-Size of the image [pixel]						*/
LONG				lXRes,				/* IN : X-Resolution of the image [pixels / inch]		*/
LONG				lYRes				/* IN : Y-Resolution of the image [pixels / inch]		*/
);

/*/////////////////////////////////////////////////////////////////////////////
//	copies barcode into meta file
//	-------------------------------------------------------------------------
//	ATTENTION:	phEMF must be released with the DeleteEnhMetaFile function
//				after use.
//	-------------------------------------------------------------------------
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
TECIT_DLLSPEC	
ERRCODE	_stdcall	BCGetEnhMetaFile
(
t_BarCode*	const	pBarCode,			/* IN : Ptr To Barcode-Definition		*/
HENHMETAFILE*		phEMF,				/* OUT: metafile handle to be drawn in	*/
LONG				nWidth,				/* IN : width of barcode to copy		*/
LONG				nHeight				/* IN : height of barcode to copy		*/
);

/*/////////////////////////////////////////////////////////////////////////////
//	copies barcode into meta file (extended version)
//	-------------------------------------------------------------------------
//	ATTENTION:	phEMF must be released with the DeleteEnhMetaFile function
//				after use.
//	-------------------------------------------------------------------------
//	Returns: ErrOk if ok 
/////////////////////////////////////////////////////////////////////////////*/
ERRCODE	_stdcall	BCGetEnhMetaFileEx
(
t_BarCode*	const	pBarCode,			/* IN : Ptr To Barcode-Definition						*/
HENHMETAFILE*		phEMF,				/* OUT: metafile handle to be drawn in					*/
HDC					hDC,				/* IN : device context to copy from (default: NULL)     */
LONG				nWidth,				/* IN : width of barcode to copy						*/
LONG				nHeight,			/* IN : height of barcode to copy						*/
BOOL				fTransparent		/* IN : Barcode transparent or not                      */
);

#endif

/*///////////////////////////////////////////////////////////////////////////*/


#ifdef __cplusplus
	}
#endif

#endif
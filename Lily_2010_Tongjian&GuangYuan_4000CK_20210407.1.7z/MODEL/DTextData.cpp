// DTextData.cpp: implementation of the DTextData class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DTextData.h"
#include "deasydrillerini.h"
#include "2Dbarcode.h"
#include "..\EasyDriller.h"
//#include "..\sysdef.h"
#include <math.h>
#include "..\model\DProcessINI.h"

DTextData gTextData;
DTextData gTextDataTemp;
struct TJumpTable 
{
	UINT offset ;
	UINT size ;
};

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DTextData::DTextData()
{
	m_nUmFieldSize = 50000;
	m_pos = NULL;
	m_nSelChar = -1;
	m_nDivide = -1;

	m_nOneCharLeft = 0;
	m_nOneCharRight = 0;
	m_nOneCharBottom = 0;
	m_nOneCharTop = 0;

	memset(m_bGrid, 0, sizeof(m_bGrid));

	// 0 : 
	m_OCRFontInfo[0].nCount = 10;
	m_OCRFontInfo[0].ptData[0].x = 3; m_OCRFontInfo[0].ptData[0].y = 14 - 1;
	m_OCRFontInfo[0].ptData[1].x = 5; m_OCRFontInfo[0].ptData[1].y = 14 - 1;
	m_OCRFontInfo[0].ptData[2].x = 7; m_OCRFontInfo[0].ptData[2].y = 14 - 4;
	m_OCRFontInfo[0].ptData[3].x = 7; m_OCRFontInfo[0].ptData[3].y = 14 - 7;
	m_OCRFontInfo[0].ptData[4].x = 7; m_OCRFontInfo[0].ptData[4].y = 14 - 10;
	m_OCRFontInfo[0].ptData[5].x = 5; m_OCRFontInfo[0].ptData[5].y = 14 - 13;
	m_OCRFontInfo[0].ptData[6].x = 3; m_OCRFontInfo[0].ptData[6].y = 14 - 13;
	m_OCRFontInfo[0].ptData[7].x = 1; m_OCRFontInfo[0].ptData[7].y = 14 - 10;
	m_OCRFontInfo[0].ptData[8].x = 1; m_OCRFontInfo[0].ptData[8].y = 14 - 7;
	m_OCRFontInfo[0].ptData[9].x = 1; m_OCRFontInfo[0].ptData[9].y = 14 - 4;

	// 1
	m_OCRFontInfo[1].nCount = 7;
	m_OCRFontInfo[1].ptData[0].x = 3; m_OCRFontInfo[1].ptData[0].y = 14 - 1;
	m_OCRFontInfo[1].ptData[1].x = 5; m_OCRFontInfo[1].ptData[1].y = 14 - 1;
	m_OCRFontInfo[1].ptData[2].x = 5; m_OCRFontInfo[1].ptData[2].y = 14 - 5;
	m_OCRFontInfo[1].ptData[3].x = 5; m_OCRFontInfo[1].ptData[3].y = 14 - 9;
	m_OCRFontInfo[1].ptData[4].x = 3; m_OCRFontInfo[1].ptData[4].y = 14 - 13;
	m_OCRFontInfo[1].ptData[5].x = 5; m_OCRFontInfo[1].ptData[5].y = 14 - 13;
	m_OCRFontInfo[1].ptData[6].x = 7; m_OCRFontInfo[1].ptData[6].y = 14 - 13;

	// 2
	m_OCRFontInfo[2].nCount = 11;
	m_OCRFontInfo[2].ptData[0].x = 1; m_OCRFontInfo[2].ptData[0].y = 14 - 3;
	m_OCRFontInfo[2].ptData[1].x = 3; m_OCRFontInfo[2].ptData[1].y = 14 - 1;
	m_OCRFontInfo[2].ptData[2].x = 5; m_OCRFontInfo[2].ptData[2].y = 14 - 1;
	m_OCRFontInfo[2].ptData[3].x = 7; m_OCRFontInfo[2].ptData[3].y = 14 - 3;
	m_OCRFontInfo[2].ptData[4].x = 7; m_OCRFontInfo[2].ptData[4].y = 14 - 5;
	m_OCRFontInfo[2].ptData[5].x = 5; m_OCRFontInfo[2].ptData[5].y = 14 - 7;
	m_OCRFontInfo[2].ptData[6].x = 3; m_OCRFontInfo[2].ptData[6].y = 14 - 9;
	m_OCRFontInfo[2].ptData[7].x = 1; m_OCRFontInfo[2].ptData[7].y = 14 - 11;
	m_OCRFontInfo[2].ptData[8].x = 1; m_OCRFontInfo[2].ptData[8].y = 14 - 13;
	m_OCRFontInfo[2].ptData[9].x = 4; m_OCRFontInfo[2].ptData[9].y = 14 - 13;
	m_OCRFontInfo[2].ptData[10].x = 7; m_OCRFontInfo[2].ptData[10].y = 14 - 13;

	// 3
	m_OCRFontInfo[3].nCount = 12;
	m_OCRFontInfo[3].ptData[0].x = 1; m_OCRFontInfo[3].ptData[0].y = 14 - 3;
	m_OCRFontInfo[3].ptData[1].x = 3; m_OCRFontInfo[3].ptData[1].y = 14 - 1;
	m_OCRFontInfo[3].ptData[2].x = 5; m_OCRFontInfo[3].ptData[2].y = 14 - 1;
	m_OCRFontInfo[3].ptData[3].x = 7; m_OCRFontInfo[3].ptData[3].y = 14 - 3;
	m_OCRFontInfo[3].ptData[4].x = 7; m_OCRFontInfo[3].ptData[4].y = 14 - 5;
	m_OCRFontInfo[3].ptData[5].x = 5; m_OCRFontInfo[3].ptData[5].y = 14 - 7;
	m_OCRFontInfo[3].ptData[6].x = 3; m_OCRFontInfo[3].ptData[6].y = 14 - 7;
	m_OCRFontInfo[3].ptData[7].x = 7; m_OCRFontInfo[3].ptData[7].y = 14 - 9;
	m_OCRFontInfo[3].ptData[8].x = 7; m_OCRFontInfo[3].ptData[8].y = 14 - 11;
	m_OCRFontInfo[3].ptData[9].x = 5; m_OCRFontInfo[3].ptData[9].y = 14 - 13;
	m_OCRFontInfo[3].ptData[10].x = 3; m_OCRFontInfo[3].ptData[10].y = 14 - 13;
	m_OCRFontInfo[3].ptData[11].x = 1; m_OCRFontInfo[3].ptData[11].y = 14 - 11;

	// 4
	m_OCRFontInfo[4].nCount = 8;
	m_OCRFontInfo[4].ptData[0].x = 1; m_OCRFontInfo[4].ptData[0].y = 14 - 9;
	m_OCRFontInfo[4].ptData[1].x = 3; m_OCRFontInfo[4].ptData[1].y = 14 - 6;
	m_OCRFontInfo[4].ptData[2].x = 5; m_OCRFontInfo[4].ptData[2].y = 14 - 4;
	m_OCRFontInfo[4].ptData[3].x = 8; m_OCRFontInfo[4].ptData[3].y = 14 - 1;
	m_OCRFontInfo[4].ptData[4].x = 8; m_OCRFontInfo[4].ptData[4].y = 14 - 5;
	m_OCRFontInfo[4].ptData[5].x = 8; m_OCRFontInfo[4].ptData[5].y = 14 - 9;
	m_OCRFontInfo[4].ptData[6].x = 8; m_OCRFontInfo[4].ptData[6].y = 14 - 13;
	m_OCRFontInfo[4].ptData[7].x = 5; m_OCRFontInfo[4].ptData[7].y = 14 - 9;

	// 5
	m_OCRFontInfo[5].nCount = 11;
	m_OCRFontInfo[5].ptData[0].x = 7; m_OCRFontInfo[5].ptData[0].y = 14 - 1;
	m_OCRFontInfo[5].ptData[1].x = 4; m_OCRFontInfo[5].ptData[1].y = 14 - 1;
	m_OCRFontInfo[5].ptData[2].x = 1; m_OCRFontInfo[5].ptData[2].y = 14 - 1;
	m_OCRFontInfo[5].ptData[3].x = 1; m_OCRFontInfo[5].ptData[3].y = 14 - 3;
	m_OCRFontInfo[5].ptData[4].x = 1; m_OCRFontInfo[5].ptData[4].y = 14 - 5;
	m_OCRFontInfo[5].ptData[5].x = 4; m_OCRFontInfo[5].ptData[5].y = 14 - 5;
	m_OCRFontInfo[5].ptData[6].x = 7; m_OCRFontInfo[5].ptData[6].y = 14 - 7;
	m_OCRFontInfo[5].ptData[7].x = 7; m_OCRFontInfo[5].ptData[7].y = 14 - 10;
	m_OCRFontInfo[5].ptData[8].x = 5; m_OCRFontInfo[5].ptData[8].y = 14 - 13;
	m_OCRFontInfo[5].ptData[9].x = 3; m_OCRFontInfo[5].ptData[9].y = 14 - 13;
	m_OCRFontInfo[5].ptData[10].x = 1; m_OCRFontInfo[5].ptData[10].y = 14 - 11;

	// 6
	m_OCRFontInfo[6].nCount = 12;
	m_OCRFontInfo[6].ptData[0].x = 7; m_OCRFontInfo[6].ptData[0].y = 14 - 3;
	m_OCRFontInfo[6].ptData[1].x = 5; m_OCRFontInfo[6].ptData[1].y = 14 - 1;
	m_OCRFontInfo[6].ptData[2].x = 3; m_OCRFontInfo[6].ptData[2].y = 14 - 1;
	m_OCRFontInfo[6].ptData[3].x = 1; m_OCRFontInfo[6].ptData[3].y = 14 - 3;
	m_OCRFontInfo[6].ptData[4].x = 1; m_OCRFontInfo[6].ptData[4].y = 14 - 6;
	m_OCRFontInfo[6].ptData[5].x = 3; m_OCRFontInfo[6].ptData[5].y = 14 - 7;
	m_OCRFontInfo[6].ptData[6].x = 5; m_OCRFontInfo[6].ptData[6].y = 14 - 7;
	m_OCRFontInfo[6].ptData[7].x = 7; m_OCRFontInfo[6].ptData[7].y = 14 - 9;
	m_OCRFontInfo[6].ptData[8].x = 6; m_OCRFontInfo[6].ptData[8].y = 14 - 12;
	m_OCRFontInfo[6].ptData[9].x = 4; m_OCRFontInfo[6].ptData[9].y = 14 - 13;
	m_OCRFontInfo[6].ptData[10].x = 2; m_OCRFontInfo[6].ptData[10].y = 14 - 12;
	m_OCRFontInfo[6].ptData[11].x = 1; m_OCRFontInfo[6].ptData[11].y = 14 - 9;

	// 7
	m_OCRFontInfo[7].nCount = 7;
	m_OCRFontInfo[7].ptData[0].x = 1; m_OCRFontInfo[7].ptData[0].y = 14 - 1;
	m_OCRFontInfo[7].ptData[1].x = 4; m_OCRFontInfo[7].ptData[1].y = 14 - 1;
	m_OCRFontInfo[7].ptData[2].x = 7; m_OCRFontInfo[7].ptData[2].y = 14 - 1;
	m_OCRFontInfo[7].ptData[3].x = 7; m_OCRFontInfo[7].ptData[3].y = 14 - 5;
	m_OCRFontInfo[7].ptData[4].x = 5; m_OCRFontInfo[7].ptData[4].y = 14 - 7;
	m_OCRFontInfo[7].ptData[5].x = 3; m_OCRFontInfo[7].ptData[5].y = 14 - 9;
	m_OCRFontInfo[7].ptData[6].x = 1; m_OCRFontInfo[7].ptData[6].y = 14 - 11;

	// 8
	m_OCRFontInfo[8].nCount = 14;
	m_OCRFontInfo[8].ptData[0].x = 1; m_OCRFontInfo[8].ptData[0].y = 14 - 3;
	m_OCRFontInfo[8].ptData[1].x = 3; m_OCRFontInfo[8].ptData[1].y = 14 - 1;
	m_OCRFontInfo[8].ptData[2].x = 5; m_OCRFontInfo[8].ptData[2].y = 14 - 1;
	m_OCRFontInfo[8].ptData[3].x = 7; m_OCRFontInfo[8].ptData[3].y = 14 - 3;
	m_OCRFontInfo[8].ptData[4].x = 7; m_OCRFontInfo[8].ptData[4].y = 14 - 5;
	m_OCRFontInfo[8].ptData[5].x = 5; m_OCRFontInfo[8].ptData[5].y = 14 - 7;
	m_OCRFontInfo[8].ptData[6].x = 3; m_OCRFontInfo[8].ptData[6].y = 14 - 7;
	m_OCRFontInfo[8].ptData[7].x = 7; m_OCRFontInfo[8].ptData[7].y = 14 - 9;
	m_OCRFontInfo[8].ptData[8].x = 7; m_OCRFontInfo[8].ptData[8].y = 14 - 11;
	m_OCRFontInfo[8].ptData[9].x = 5; m_OCRFontInfo[8].ptData[9].y = 14 - 13;
	m_OCRFontInfo[8].ptData[10].x = 3; m_OCRFontInfo[8].ptData[10].y = 14 - 13;
	m_OCRFontInfo[8].ptData[11].x = 1; m_OCRFontInfo[8].ptData[11].y = 14 - 11;
	m_OCRFontInfo[8].ptData[12].x = 1; m_OCRFontInfo[8].ptData[12].y = 14 - 9;
	m_OCRFontInfo[8].ptData[13].x = 1; m_OCRFontInfo[8].ptData[13].y = 14 - 5;

	// 9
	m_OCRFontInfo[9].nCount = 12;
	m_OCRFontInfo[9].ptData[0].x = 1; m_OCRFontInfo[9].ptData[0].y = 14 - 11;
	m_OCRFontInfo[9].ptData[1].x = 3; m_OCRFontInfo[9].ptData[1].y = 14 - 13;
	m_OCRFontInfo[9].ptData[2].x = 5; m_OCRFontInfo[9].ptData[2].y = 14 - 13;
	m_OCRFontInfo[9].ptData[3].x = 7; m_OCRFontInfo[9].ptData[3].y = 14 - 11;
	m_OCRFontInfo[9].ptData[4].x = 7; m_OCRFontInfo[9].ptData[4].y = 14 - 8;
	m_OCRFontInfo[9].ptData[5].x = 5; m_OCRFontInfo[9].ptData[5].y = 14 - 7;
	m_OCRFontInfo[9].ptData[6].x = 3; m_OCRFontInfo[9].ptData[6].y = 14 - 7;
	m_OCRFontInfo[9].ptData[7].x = 1; m_OCRFontInfo[9].ptData[7].y = 14 - 5;
	m_OCRFontInfo[9].ptData[8].x = 2; m_OCRFontInfo[9].ptData[8].y = 14 - 2;
	m_OCRFontInfo[9].ptData[9].x = 4; m_OCRFontInfo[9].ptData[9].y = 14 - 1;
	m_OCRFontInfo[9].ptData[10].x = 6; m_OCRFontInfo[9].ptData[10].y = 14 - 2;
	m_OCRFontInfo[9].ptData[11].x = 7; m_OCRFontInfo[9].ptData[11].y = 14 - 5;

	// 10 : A
	m_OCRFontInfo[10].nCount = 11;
	m_OCRFontInfo[10].ptData[0].x = 1; m_OCRFontInfo[10].ptData[0].y = 1;
	m_OCRFontInfo[10].ptData[1].x = 1; m_OCRFontInfo[10].ptData[1].y = 4;
	m_OCRFontInfo[10].ptData[2].x = 1; m_OCRFontInfo[10].ptData[2].y = 7;
	m_OCRFontInfo[10].ptData[3].x = 1; m_OCRFontInfo[10].ptData[3].y = 10;
	m_OCRFontInfo[10].ptData[4].x = 4; m_OCRFontInfo[10].ptData[4].y = 13;
	m_OCRFontInfo[10].ptData[5].x = 7; m_OCRFontInfo[10].ptData[5].y = 10;
	m_OCRFontInfo[10].ptData[6].x = 7; m_OCRFontInfo[10].ptData[6].y = 7;
	m_OCRFontInfo[10].ptData[7].x = 7; m_OCRFontInfo[10].ptData[7].y = 4;
	m_OCRFontInfo[10].ptData[8].x = 7; m_OCRFontInfo[10].ptData[8].y = 1;
	m_OCRFontInfo[10].ptData[9].x = 3; m_OCRFontInfo[10].ptData[9].y = 7;
	m_OCRFontInfo[10].ptData[10].x = 5; m_OCRFontInfo[10].ptData[10].y = 7;
	// 11 : B
	m_OCRFontInfo[11].nCount = 14;
	m_OCRFontInfo[11].ptData[0].x = 1; m_OCRFontInfo[11].ptData[0].y = 1;
	m_OCRFontInfo[11].ptData[1].x = 1; m_OCRFontInfo[11].ptData[1].y = 4;
	m_OCRFontInfo[11].ptData[2].x = 1; m_OCRFontInfo[11].ptData[2].y = 7;
	m_OCRFontInfo[11].ptData[3].x = 1; m_OCRFontInfo[11].ptData[3].y = 10;
	m_OCRFontInfo[11].ptData[4].x = 1; m_OCRFontInfo[11].ptData[4].y = 13;
	m_OCRFontInfo[11].ptData[5].x = 3; m_OCRFontInfo[11].ptData[5].y = 13;
	m_OCRFontInfo[11].ptData[6].x = 5; m_OCRFontInfo[11].ptData[6].y = 13;
	m_OCRFontInfo[11].ptData[7].x = 7; m_OCRFontInfo[11].ptData[7].y = 11;
	m_OCRFontInfo[11].ptData[8].x = 5; m_OCRFontInfo[11].ptData[8].y = 9;
	m_OCRFontInfo[11].ptData[9].x = 3; m_OCRFontInfo[11].ptData[9].y = 9;
	m_OCRFontInfo[11].ptData[10].x = 7; m_OCRFontInfo[11].ptData[10].y = 7;
	m_OCRFontInfo[11].ptData[11].x = 7; m_OCRFontInfo[11].ptData[11].y = 4;
	m_OCRFontInfo[11].ptData[12].x = 5; m_OCRFontInfo[11].ptData[12].y = 1;
	m_OCRFontInfo[11].ptData[13].x = 3; m_OCRFontInfo[11].ptData[13].y = 1;
	
	// 12 : C
	m_OCRFontInfo[12].nCount = 9;
	m_OCRFontInfo[12].ptData[0].x = 7; m_OCRFontInfo[12].ptData[0].y = 3;
	m_OCRFontInfo[12].ptData[1].x = 5; m_OCRFontInfo[12].ptData[1].y = 1;
	m_OCRFontInfo[12].ptData[2].x = 3; m_OCRFontInfo[12].ptData[2].y = 1;
	m_OCRFontInfo[12].ptData[3].x = 1; m_OCRFontInfo[12].ptData[3].y = 3;
	m_OCRFontInfo[12].ptData[4].x = 1; m_OCRFontInfo[12].ptData[4].y = 7;
	m_OCRFontInfo[12].ptData[5].x = 1; m_OCRFontInfo[12].ptData[5].y = 11;
	m_OCRFontInfo[12].ptData[6].x = 3; m_OCRFontInfo[12].ptData[6].y = 13;
	m_OCRFontInfo[12].ptData[7].x = 5; m_OCRFontInfo[12].ptData[7].y = 13;
	m_OCRFontInfo[12].ptData[8].x = 7; m_OCRFontInfo[12].ptData[8].y = 11;
	
	// 13 : D
	m_OCRFontInfo[13].nCount = 12;
	m_OCRFontInfo[13].ptData[0].x = 1; m_OCRFontInfo[13].ptData[0].y = 1;
	m_OCRFontInfo[13].ptData[1].x = 1; m_OCRFontInfo[13].ptData[1].y = 4;
	m_OCRFontInfo[13].ptData[2].x = 1; m_OCRFontInfo[13].ptData[2].y = 7;
	m_OCRFontInfo[13].ptData[3].x = 1; m_OCRFontInfo[13].ptData[3].y = 10;
	m_OCRFontInfo[13].ptData[4].x = 1; m_OCRFontInfo[13].ptData[4].y = 13;
	m_OCRFontInfo[13].ptData[5].x = 3; m_OCRFontInfo[13].ptData[5].y = 13;
	m_OCRFontInfo[13].ptData[6].x = 5; m_OCRFontInfo[13].ptData[6].y = 13;
	m_OCRFontInfo[13].ptData[7].x = 7; m_OCRFontInfo[13].ptData[7].y = 11;
	m_OCRFontInfo[13].ptData[8].x = 7; m_OCRFontInfo[13].ptData[8].y = 7;
	m_OCRFontInfo[13].ptData[9].x = 7; m_OCRFontInfo[13].ptData[9].y = 3;
	m_OCRFontInfo[13].ptData[10].x = 5; m_OCRFontInfo[13].ptData[10].y = 1;
	m_OCRFontInfo[13].ptData[11].x = 3; m_OCRFontInfo[13].ptData[11].y = 1;
		m_nFinalRotation = ROT_NONE;
}

DTextData::~DTextData()
{
	RemoveAllCharInfo();
	RemoveResultData();
}

BOOL DTextData::InitCharData()
{
	CFile source;
	BOOL isBeingChar;
	CString strFontName;
	unsigned short usMagicNumber, usCharNumber, usHeight;
	unsigned int  uiJumpOffset;
	char cDescription[92];
	TJumpTable JumpTable[128];
	
	char dumy[1032];
	m_nCharHeight = 0;
	m_nCharWidth = 0;
	strFontName.Format(_T("%sTEXT.FNT"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
//	strFontName.Format(_T("%s"), gEasyDrillerINI.m_clsDirPath.GetFontFilePath());
	
	if (source.Open(strFontName, CFile::modeRead|CFile::typeBinary) == 0) 
	{
		TRACE(_T("Font File %s do not exist.\n"), strFontName);
		return FALSE;
	}

	source.Read( (char *)&usMagicNumber, sizeof( usMagicNumber ) );
	source.Read( (char *)&usCharNumber,  sizeof( usCharNumber ) ) ;
	source.Read( (char *)&uiJumpOffset,  sizeof( uiJumpOffset ) ) ;
	source.Read( (char *)&usHeight,      sizeof( usHeight ) ) ;
	source.Read( cDescription, 92 ) ;
	
	source.Seek( uiJumpOffset, CFile::begin ) ;
	
	source.Read((char *)(JumpTable), sizeof( JumpTable ) ) ;
	source.Read( (char *)dumy,         1032 ) ;
	
//	m_dMinWidthB = m_Height*2./3.;
	///////////////////////////////////////////////////
	isBeingChar = false;
	for( int i = 0 ; i < 127 ; ++ i ){
		
		if(readEOChar(source, i, JumpTable[i].offset, JumpTable[i].size ) ==TRUE)
		{
			m_CharList[i].nCenterX = (m_nLeft + m_nRight)/2;
			m_CharList[i].nCenterY = (m_nTop + m_nBottom)/2;
			m_CharList[i].nWidth = (m_nRight - m_nLeft);
			m_CharList[i].nHeight = (m_nTop - m_nBottom);
		}
		else
		{
			m_CharList[i].nWidth = usHeight*2/3;
			m_CharList[i].nHeight = usHeight;
			m_CharList[i].nCenterX = m_CharList[i].nWidth/2;
			m_CharList[i].nCenterY = m_CharList[i].nHeight/2;
		}
		if(m_nCharHeight < m_CharList[i].nWidth)
			m_nCharHeight = m_CharList[i].nWidth;

		if(m_nCharWidth < m_CharList[i].nWidth)
			m_nCharWidth = m_CharList[i].nWidth;
	}
	source.Close() ;
	return TRUE;
}


BOOL DTextData::readEOChar(CFile &file, int index, int offset, int size)
{
	unsigned char cmd,prevcmd=MARK_JUMP ;
	int xval, yval ;
	int px = 0, py = 0 ;
	short ReadX,ReadY;
	LPCHARLINE pLine;
	BOOL bIsData = FALSE;
	//	int count=0;

	m_nLeft = INT_MAX;
	m_nRight = -INT_MAX;
	m_nBottom = INT_MAX;
	m_nTop = -INT_MAX;

	RemoveOneCharData(index);
	
	if ( size < 15 ) return FALSE;
	
	file.Seek( offset, CFile::begin ) ;
	CPoint start,end;
	for( int i = 0 ; i < size / 5 ; ++ i )
	{
		file.Read( (char *)&cmd,  sizeof( cmd ) ) ;
		file.Read( (char *)&ReadX, sizeof( ReadX ) ) ;
		file.Read( (char *)&ReadY, sizeof( ReadY ) ) ;
		
		xval = ReadX;
		yval = ReadY;
		switch( cmd )
		{
		case 0x01://PA //JUMP
			px = xval; py = yval;
			start=CPoint(px,py);
			prevcmd = MARK_JUMP;
			break ;
		case 0x02://PR // JUMP
			px += xval; py += yval;
			start=CPoint(px,py);
			prevcmd = MARK_JUMP;
			break ;
		case 0x03://PA //MARK
			px = xval; py = yval;
			end=CPoint(px,py);

			pLine = new CHARLINE;
			pLine->npStartPos.x = start.x;
			pLine->npStartPos.y = start.y;
			pLine->npEndPos.x = end.x;
			pLine->npEndPos.y = end.y;

			m_CharList[index].lpCharData.AddTail(pLine);
			start=end;

			if(pLine->npStartPos.x < m_nLeft) m_nLeft = pLine->npStartPos.x;
			if(pLine->npStartPos.x > m_nRight) m_nRight = pLine->npStartPos.x;
			if(pLine->npEndPos.x < m_nLeft) m_nLeft = pLine->npEndPos.x;
			if(pLine->npEndPos.x > m_nRight) m_nRight = pLine->npEndPos.x;

			if(pLine->npStartPos.y < m_nBottom) m_nBottom = pLine->npStartPos.y;
			if(pLine->npStartPos.y > m_nTop) m_nTop = pLine->npStartPos.y;
			if(pLine->npEndPos.y < m_nBottom) m_nBottom = pLine->npEndPos.y;
			if(pLine->npEndPos.y > m_nTop) m_nTop = pLine->npEndPos.y;
			
			prevcmd = MARK_DRAW;
			bIsData = TRUE;
			break ;
		case 0x04://PR // MARK
			px += xval; py += yval;
			end=CPoint(px,py);
			
			pLine = new CHARLINE;
			pLine->npStartPos.x = start.x;
			pLine->npStartPos.y = start.y;
			pLine->npEndPos.x = end.x;
			pLine->npEndPos.y = end.y;
			
			m_CharList[index].lpCharData.AddTail(pLine);
			start=end;

			if(pLine->npStartPos.x < m_nLeft) m_nLeft = pLine->npStartPos.x;
			if(pLine->npStartPos.x > m_nRight) m_nRight = pLine->npStartPos.x;
			if(pLine->npEndPos.x < m_nLeft) m_nLeft = pLine->npEndPos.x;
			if(pLine->npEndPos.x > m_nRight) m_nRight = pLine->npEndPos.x;
			
			if(pLine->npStartPos.y < m_nBottom) m_nBottom = pLine->npStartPos.y;
			if(pLine->npStartPos.y > m_nTop) m_nTop = pLine->npStartPos.y;
			if(pLine->npEndPos.y < m_nBottom) m_nBottom = pLine->npEndPos.y;
			if(pLine->npEndPos.y > m_nTop) m_nTop = pLine->npEndPos.y;

			prevcmd = MARK_DRAW; 
			bIsData = TRUE;
			break ;
		case 0x76://END
			break ;
		}
	}// end for
	return bIsData;
}

void DTextData::RemoveAllCharInfo()
{
	for(int i = 0; i < 128; i++)
	{
		RemoveOneCharData(i);
	}
}

void DTextData::RemoveOneCharData(int nIndex)
{
	LPCHARLINE pLine;
	POSITION pos;
	pos = m_CharList[nIndex].lpCharData.GetHeadPosition();
	while (pos)
	{
		pLine = m_CharList[nIndex].lpCharData.GetNext(pos);
		delete pLine;
		pLine = NULL;
	}
	m_CharList[nIndex].lpCharData.RemoveAll();
}

void DTextData::SaveExcellon()
{
	FILE *fp = NULL;
	CString strFileName;
	strFileName.Format(_T("D:\\viahole\\Temp\\Text.txt"));
	
	if (NULL == fopen_s(&fp, strFileName, _T("w")))
	{
		fprintf(fp, _T("T02\n"));
		
		LPCHARLINE pLine;
		POSITION pos;
		pos = m_LineData.GetHeadPosition();
		while (pos)
		{
			pLine = m_LineData.GetNext(pos);
			fprintf(fp, _T("X%dY%dG85X%dY%d\n"), pLine->npStartPos.x, pLine->npStartPos.y,
											 pLine->npEndPos.x, pLine->npEndPos.y);
		}
		
		fprintf(fp, _T("T03\n"));
		LPCHARHOLE pHole;
		pos = m_HoleData.GetHeadPosition();
		while (pos)
		{
			pHole = m_HoleData.GetNext(pos);
			fprintf(fp, _T("X%dY%d\n"), pHole->npHolePos.x, pHole->npHolePos.y);
		}
		fprintf(fp, _T("M30"));
		fclose(fp);
		return;
	}
	else
	{
		ErrMessage(_T("Can not write file"));
		return;
	}
}

// nRef = 0, 1, 2, 3, 4, 5, 6, 7
//		
//		0-----------1----------2
//		3           4          5
//		6-----------7----------8
//     nRef = (0, 0) ����
BOOL DTextData::GetTextData(CString str, int nSize, int nGabSize, BOOL bDot, int nRefMode, int umFieldSize, BOOL bFlipX, BOOL bFlipY, int nRotate, double dInterval, int nAxisInfo, BOOL bUseInnerOCRFont)
{

	str.MakeUpper();
	nRefMode = 3;

	char cVal; 
	m_nLeft = INT_MAX;
	m_nRight = -INT_MAX;
	m_nBottom = INT_MAX;
	m_nTop = -INT_MAX;
	m_nUmFieldSize = umFieldSize;

	int nStartX = 0;

	//nGabSize = 6000;//nSize / 8 ;

	m_dOcrWidth_mm = 0;
	m_dOneOcrWidth_mm = 0;

	if(bUseInnerOCRFont)
	{
		double dGap = nSize / 14.;
		double dWidth = dGap * 10;
		RemoveResultData();
		for(int i = 0; i < str.GetLength(); i++)
		{
			m_nSelChar = -1;
			cVal = str.GetAt(i);
			if(cVal > 47 && cVal < 58)
				m_nSelChar = cVal - 48;
			else if(cVal > 64 && cVal < 69)
				m_nSelChar = cVal - 55;
			else
				continue;
			
			for(int k = 0; k < m_OCRFontInfo[m_nSelChar].nCount; k++)
			{
				LPPOINT ptElemet = NULL;
				TRY
				{
					LPCHARHOLE pHole;
					pHole = new CHARHOLE;
					pHole->npHolePos.x = (int)(m_OCRFontInfo[m_nSelChar].ptData[k].x * dGap + nStartX);
					pHole->npHolePos.y = (int)(m_OCRFontInfo[m_nSelChar].ptData[k].y * dGap);
					
					if(pHole->npHolePos.x < m_nLeft)	m_nLeft = pHole->npHolePos.x;
					if(pHole->npHolePos.x > m_nRight)	m_nRight = pHole->npHolePos.x;
					
					if(!AddHoletoTempData(pHole))
					{
						delete pHole;
						pHole = NULL;
						return FALSE;
					}
				}
				CATCH (CMemoryException, e)
				{
					e->ReportError();
					e->Delete();
					return FALSE;
				}
				END_CATCH
			}
			SaveTempHoleToList();
			nStartX += (int)(dWidth + nSize * dInterval);
		}
	}
	else
	{
		
		POSITION pos;
		LPCHARLINE pLine, pChangeLine;

		RemoveResultData();

		if(bDot) pChangeLine = new CHARLINE;

		for(int i = 0; i < str.GetLength(); i++)
		{
			m_nSelChar = -1;
			memset(m_bGrid, 0 , sizeof(m_bGrid));

			cVal = str.GetAt(i);
			if(cVal < 0 || cVal > 127)
				continue;
			//double dRatioX = (double(1500)) / m_CharList[cVal].nWidth;
			/*
			double dRatioX = (double(nSizeX)) / m_CharList[cVal].nWidth;
			double dRatioY = (double(nSizeY)) / m_CharList[cVal].nHeight;
			*/

			double dRatioX = (double(nSize)) / m_nCharWidth;
			double dRatioY = (double(nSize)) / m_nCharHeight;

			if(cVal == 45)
			{
				dRatioY = (double(nSize)) / m_nCharHeight; 
			}
			m_nSelChar = cVal;
//			GetOneCharSize(dRatio, nStartX);

			pos = m_CharList[cVal].lpCharData.GetHeadPosition();
			while(pos)
			{
				
				pLine = m_CharList[cVal].lpCharData.GetNext(pos);

				if(!bDot)
					pChangeLine = new CHARLINE;
		
				pChangeLine->npStartPos.x = (int)(pLine->npStartPos.x * dRatioX + nStartX);
				pChangeLine->npStartPos.y = (int)(pLine->npStartPos.y * dRatioY);
				pChangeLine->npEndPos.x = (int)(pLine->npEndPos.x * dRatioX + nStartX);
				pChangeLine->npEndPos.y = (int)(pLine->npEndPos.y * dRatioY);

				if(pChangeLine->npStartPos.x < m_nLeft)		m_nLeft = pChangeLine->npStartPos.x;
				if(pChangeLine->npStartPos.x > m_nRight)	m_nRight = pChangeLine->npStartPos.x;
				if(pChangeLine->npEndPos.x < m_nLeft)		m_nLeft = pChangeLine->npEndPos.x;
				if(pChangeLine->npEndPos.x > m_nRight)		m_nRight = pChangeLine->npEndPos.x;
				
				if(pChangeLine->npStartPos.y < m_nBottom)	m_nBottom = pChangeLine->npStartPos.y;
				if(pChangeLine->npStartPos.y > m_nTop)		m_nTop = pChangeLine->npStartPos.y;
				if(pChangeLine->npEndPos.y < m_nBottom)		m_nBottom = pChangeLine->npEndPos.y;
				if(pChangeLine->npEndPos.y > m_nTop)		m_nTop = pChangeLine->npEndPos.y;

				if(bDot)
				{
					SetOneLine(pChangeLine, nGabSize);
				}
				else
					m_LineData.AddTail(pChangeLine);
			}
			// 100901 text interval
			if(bDot)
			{
				//AddGridHole();
				SaveTempHoleToList();
			}
			nStartX += (int)(m_nCharWidth * dRatioX + 1500 * dInterval); //0.3);
			m_dOcrWidth_mm = nStartX / 1000.;
			m_dOneOcrWidth_mm = (m_nCharWidth * dRatioX + 1500 * dInterval) / 1000.;
		}

		if(bDot) delete pChangeLine;
	}

//	nRefMode = GetAxis(nRefMode, nAxisInfo);//20200901
	//------------------------
	RepositionData(nRefMode);

   if(gProcessINI.m_sProcessSystem.bUseFixOCRDirection)
	  nAxisInfo = X_Y;

	ChangeAxis(bFlipX, bFlipY, nRotate,nAxisInfo);

	return TRUE;
}

int DTextData::GetAxis(int nRefMode, int nAxisInfo)
{
	int nReturn = 6;
	if(nRefMode == 6)
	{
		if(nAxisInfo == X_Y)
			nReturn = 6;
		else if(nAxisInfo == MX_Y)
			nReturn = 8;
		else if(nAxisInfo == X_MY)
			nReturn = 0;
		else if(nAxisInfo == MX_MY)
			nReturn = 2;
		else if(nAxisInfo == Y_X)
			nReturn = 6;
		else if(nAxisInfo == MY_X)
			nReturn = 8;
		else if(nAxisInfo == Y_MX)
			nReturn = 0;
		else
			nReturn = 2;
	}
	else if(nRefMode == 8)
	{
		if(nAxisInfo == X_Y)
			nReturn = 8;
		else if(nAxisInfo == MX_Y)
			nReturn = 6;
		else if(nAxisInfo == X_MY)
			nReturn = 2;
		else if(nAxisInfo == MX_MY)
			nReturn = 0;
		else if(nAxisInfo == Y_X)
			nReturn = 8;
		else if(nAxisInfo == MY_X)
			nReturn = 6;
		else if(nAxisInfo == Y_MX)
			nReturn = 2;
		else
			nReturn = 0;
	}
	else if(nRefMode == 0)
	{
		if(nAxisInfo == X_Y)
			nReturn = 0;
		else if(nAxisInfo == MX_Y)
			nReturn = 2;
		else if(nAxisInfo == X_MY)
			nReturn = 6;
		else if(nAxisInfo == MX_MY)
			nReturn = 8;
		else if(nAxisInfo == Y_X)
			nReturn = 0;
		else if(nAxisInfo == MY_X)
			nReturn = 2;
		else if(nAxisInfo == Y_MX)
			nReturn = 6;
		else
			nReturn = 8;
	}
	else if(nRefMode == 0)
	{
		if(nAxisInfo == X_Y)
			nReturn = 2;
		else if(nAxisInfo == MX_Y)
			nReturn = 0;
		else if(nAxisInfo == X_MY)
			nReturn = 8;
		else if(nAxisInfo == MX_MY)
			nReturn = 6;
		else if(nAxisInfo == Y_X)
			nReturn = 2;
		else if(nAxisInfo == MY_X)
			nReturn = 0;
		else if(nAxisInfo == Y_MX)
			nReturn = 8;
		else
			nReturn = 6;
	}
	else if(nRefMode == 3)
	{
		if(nAxisInfo == MX_Y || nAxisInfo == MX_MY || nAxisInfo == MY_X || nAxisInfo == MY_MX)
			nReturn = 5;
		else
			nReturn = 3;
	}
	else if(nRefMode == 5)
	{
		if(nAxisInfo == MX_Y || nAxisInfo == MX_MY || nAxisInfo == MY_X || nAxisInfo == MY_MX)
			nReturn = 3;
		else
			nReturn = 5;
	}
	else if(nRefMode == 7)
	{
		if(nAxisInfo == X_MY || nAxisInfo == MX_MY || nAxisInfo == Y_MX || nAxisInfo == MY_MX)
			nReturn = 1;
		else
			nReturn = 7;
	}
	else if(nRefMode == 1)
	{
		if(nAxisInfo == X_MY || nAxisInfo == MX_MY || nAxisInfo == Y_MX || nAxisInfo == MY_MX)
			nReturn = 7;
		else
			nReturn = 1;
	}
	else
		nReturn = 4;

	return nReturn;
}

void DTextData::GetOneCharSize(double dRatio, int nStartX)
{
	m_nOneCharLeft = INT_MAX;
	m_nOneCharRight = -INT_MAX;
	m_nOneCharBottom = INT_MAX;
	m_nOneCharTop = -INT_MAX;

	LPCHARLINE pLine, pChangeLine;
	pChangeLine = new CHARLINE;

	POSITION pos = m_CharList[m_nSelChar].lpCharData.GetHeadPosition();
	while(pos)
	{
		pLine = m_CharList[m_nSelChar].lpCharData.GetNext(pos);

		pChangeLine->npStartPos.x = (int)(pLine->npStartPos.x * dRatio + nStartX);
		pChangeLine->npStartPos.y = (int)(pLine->npStartPos.y * dRatio);
		pChangeLine->npEndPos.x = (int)(pLine->npEndPos.x * dRatio + nStartX);
		pChangeLine->npEndPos.y = (int)(pLine->npEndPos.y * dRatio);
		
		if(pChangeLine->npStartPos.x < m_nOneCharLeft)		m_nOneCharLeft = pChangeLine->npStartPos.x;
		if(pChangeLine->npStartPos.x > m_nOneCharRight)		m_nOneCharRight = pChangeLine->npStartPos.x;
		if(pChangeLine->npEndPos.x < m_nOneCharLeft)		m_nOneCharLeft = pChangeLine->npEndPos.x;
		if(pChangeLine->npEndPos.x > m_nOneCharRight)		m_nOneCharRight = pChangeLine->npEndPos.x;
		
		if(pChangeLine->npStartPos.y < m_nOneCharBottom)	m_nOneCharBottom = pChangeLine->npStartPos.y;
		if(pChangeLine->npStartPos.y > m_nOneCharTop)		m_nOneCharTop = pChangeLine->npStartPos.y;
		if(pChangeLine->npEndPos.y < m_nOneCharBottom)		m_nOneCharBottom = pChangeLine->npEndPos.y;
		if(pChangeLine->npEndPos.y > m_nOneCharTop)			m_nOneCharTop = pChangeLine->npEndPos.y;
	}
}

void DTextData::RemoveResultData()
{
	LPCHARLINE pLine;
	POSITION pos;
	pos = m_LineData.GetHeadPosition();
	while (pos)
	{
		pLine = m_LineData.GetNext(pos);
		delete pLine;
		pLine = NULL;
	}
	m_LineData.RemoveAll();

	LPCHARHOLE pHole;
	pos = m_HoleData.GetHeadPosition();
	while (pos)
	{
		pHole = m_HoleData.GetNext(pos);
		delete pHole;
		pHole = NULL;
	}
	m_HoleData.RemoveAll();
}

void DTextData::RemoveTempData()
{
	LPCHARHOLE pHole;
	POSITION pos = m_tempHoleData.GetHeadPosition();
	while (pos)
	{
		pHole = m_tempHoleData.GetNext(pos);
		delete pHole;
		pHole = NULL;
	}
	m_tempHoleData.RemoveAll();
}

void DTextData::SetOneLine(LPCHARLINE pLine, int nGab)
{
	LPCHARHOLE pHole;
	double dLeng = sqrt((double)(pLine->npStartPos.x - pLine->npEndPos.x) * (pLine->npStartPos.x - pLine->npEndPos.x) +
						(pLine->npStartPos.y - pLine->npEndPos.y) * (pLine->npStartPos.y - pLine->npEndPos.y));
	int nDivide = (int)(dLeng /nGab + 0.5);
	double dX, dY;
	dX = pLine->npEndPos.x - pLine->npStartPos.x;
	dY = pLine->npEndPos.y - pLine->npStartPos.y;

	if(nDivide == 0)
	{
		pHole = new CHARHOLE;
		pHole->npHolePos.x = pLine->npEndPos.x;
		pHole->npHolePos.y = pLine->npEndPos.y;
		if(!AddHoletoTempData(pHole))
		{
			delete pHole;
			pHole = NULL;
		}
	}
	else
	{
		for(int i = 0; i <= nDivide; i++)
		{
			pHole = new CHARHOLE;
			pHole->npHolePos.x = (int)(pLine->npStartPos.x + dX * i / nDivide);
			pHole->npHolePos.y = (int)(pLine->npStartPos.y + dY * i / nDivide);

		//	TRACE(_T("%d\t%d\n"), pHole->npHolePos.x, pHole->npHolePos.y);
		//	::Sleep(10);
			if(!AddHoletoTempData(pHole))
			{
				delete pHole;
				pHole = NULL;
			}
		}
	}
/*
	double dLeng = sqrt((double)(pLine->npStartPos.x - pLine->npEndPos.x) * (pLine->npStartPos.x - pLine->npEndPos.x) +
						(pLine->npStartPos.y - pLine->npEndPos.y) * (pLine->npStartPos.y - pLine->npEndPos.y));
//	int nDivide = (int)(dLeng /nGab + 0.5);
//	m_nDivide = nDivide;
	
	int nX, nY;
	nX = pLine->npEndPos.x - pLine->npStartPos.x;
	nY = pLine->npEndPos.y - pLine->npStartPos.y;
	int nGabX = (m_nOneCharRight - m_nOneCharLeft)/(GRID_X - 1);
	int nGabY = (m_nOneCharTop - m_nOneCharBottom)/(GRID_Y - 1); 

	if(nX == 0 && nY == 0)
	{
		SetTextGrid(pLine->npStartPos.x, pLine->npStartPos.y);
		return;
	}

	if(abs(nX) < abs(nY))
	{
		double dGap;
		dGap = (double)nX/abs(nY);
		for(int i = 0; i <= abs(nY); i++)
			SetTextGrid(pLine->npStartPos.x + (int)(i * dGap), pLine->npStartPos.y + i * (int)((nY/abs(nY))) );
		return;
	}
	else
	{
		double dGap;
		dGap = (double)nY/abs(nX);
		for(int i = 0; i <= abs(nX); i++)
			SetTextGrid(pLine->npStartPos.x + (int)(i * (nX/abs(nX))), pLine->npStartPos.y + (int)(i * dGap ));
		return;
	}
*/
}

BOOL DTextData::AddGridHole()
{
	if(m_nSelChar == -1)
		return FALSE;

	LPCHARHOLE pHole;
	
	int nStartX = m_nOneCharLeft;
	int nStartY = m_nOneCharBottom;
	
	int nGabX = (m_nOneCharRight - m_nOneCharLeft)/(GRID_X - 1);
	int nGabY = (m_nOneCharTop - m_nOneCharBottom)/(GRID_Y - 1); //�Է¹��� ���ΰ����� �ؾ��� 
	
	int nPosX, nPosY;
	
	for(int j = 0; j<GRID_Y; j++ )
	{
		for(int i = 0; i < GRID_X; i++)
		{
			if(m_bGrid[i][j])
			{
				nPosX = nStartX + (i * nGabX);
				nPosY = nStartY + (j * nGabY);

				pHole = new CHARHOLE;
				pHole->npHolePos.x = nPosX;
				pHole->npHolePos.y = nPosY;
//				TRACE(_T("%d\t%d\n"), nPosX, nPosY);
//				::Sleep(10);
				
				if(!AddHoletoTempData(pHole))
				{
					delete pHole;
					pHole = NULL;
					return FALSE;
				}
			}	
		}
	}
	return TRUE;
}

void DTextData::SetTextGrid(int nX, int nY)
{
	if(m_nSelChar == -1)
		return ;
	
	int nStartX = m_nOneCharLeft;
	int nStartY = m_nOneCharBottom;
	
	int nGabX = (m_nOneCharRight - m_nOneCharLeft)/(GRID_X - 1);
	int nGabY = (m_nOneCharTop - m_nOneCharBottom)/(GRID_Y - 1); 
	
	int nPosX, nPosY;
	
	for(int j = 0; j<GRID_Y; j++ )
	{
		for(int i = 0; i < GRID_X; i++)
		{
			nPosX = nStartX + (i * nGabX);
			nPosY = nStartY + (j * nGabY);
			//���ڿ� ���߱�
			if(nX >= nPosX - 3 && nX <= nPosX + 3 &&
				nY >= nPosY - 3 && nY <= nPosY + 3 )
			{
				m_bGrid[i][j] = TRUE;
				return;
			}
		}
	}
	return;
}
void DTextData::SaveTempHoleToList()
{
	LPCHARHOLE pHole;
	POSITION pos = m_tempHoleData.GetHeadPosition();
	while (pos)
	{
		pHole = m_tempHoleData.GetNext(pos);
		m_HoleData.AddTail(pHole);
	}
	m_tempHoleData.RemoveAll();
}

void DTextData::RepositionData(int nMode)
{
	int nX, nY;
	if(nMode == 0)
	{
		nX = -m_nLeft;
		nY = -m_nTop;
	}
	else if(nMode == 1)
	{
		nX = -(m_nLeft + m_nRight)/2;
		nY = -m_nTop;
	}
	else if(nMode == 2)
	{
		nX = -m_nRight;
		nY = -m_nTop;
	}
	else if(nMode == 3)
	{
		nX = -m_nLeft;
		nY = -(m_nTop + m_nBottom)/2;
	}
	else if(nMode == 4)
	{
		nX = -(m_nLeft + m_nRight)/2;
		nY = -(m_nTop + m_nBottom)/2;
	}
	else if(nMode == 5)
	{
		nX = -m_nRight;
		nY = -(m_nTop + m_nBottom)/2;
	}
	else if(nMode == 6)
	{
		nX = -m_nLeft;
		nY = -m_nBottom;
	}
	else if(nMode == 7)
	{
		nX = -(m_nLeft + m_nRight)/2;
		nY = -m_nBottom;
	}
	else if(nMode == 8)
	{
		nX = -m_nRight;
		nY = -m_nBottom;
	}
	//-----
	LPCHARLINE pLine;
	POSITION pos;
	pos = m_LineData.GetHeadPosition();
	while (pos)
	{
		pLine = m_LineData.GetNext(pos);
		pLine->npStartPos.x +=nX;
		pLine->npStartPos.y +=nY;
		pLine->npEndPos.x +=nX;
		pLine->npEndPos.y +=nY;
	}
	
	LPCHARHOLE pHole;
	pos = m_HoleData.GetHeadPosition();
	while (pos)
	{
		pHole = m_HoleData.GetNext(pos);
		pHole->npHolePos.x +=nX;
		pHole->npHolePos.y +=nY;
	}
}

BOOL DTextData::AddHoletoTempData(LPCHARHOLE pHole)
{
	LPCHARHOLE pHoleRef;
	POSITION pos = m_tempHoleData.GetHeadPosition();
	while (pos)
	{
		pHoleRef = m_tempHoleData.GetNext(pos);
		if(abs(pHole->npHolePos.x - pHoleRef->npHolePos.x) < 2 && // 2um ���̳��� ���� ���� ��ġ�� �Ǵ�
			abs(pHole->npHolePos.y - pHoleRef->npHolePos.y) < 2)
			return FALSE;
	}
	m_tempHoleData.AddTail(pHole);
	return TRUE;
}

void DTextData::ChangeAxis(BOOL bFilpX, BOOL bFilpY, int nRotate ,int nAxisInfo)
{
	int nX, nY, nResultX, nResultY;
	double cosTheta, sinTheta;
	LPCHARLINE pLine;
	POSITION pos;

	m_nLeft = INT_MAX;
	m_nRight = -INT_MAX;
	m_nBottom = INT_MAX;
	m_nTop = -INT_MAX;

	cosTheta = cos(nRotate * M_PI / 180.);
	sinTheta = sin(nRotate * M_PI / 180.);

	int nTransX = 0;
	int nTransY = 0;

	pos = m_LineData.GetHeadPosition();
	while (pos)
	{
		pLine = m_LineData.GetNext(pos);
		if(bFilpX)
			nX = -pLine->npStartPos.x;
		else
			nX = pLine->npStartPos.x;
		if(bFilpY)
			nY = -pLine->npStartPos.y;
		else
			nY = pLine->npStartPos.y;

		nResultX = (int)(cosTheta*(nX) - sinTheta*(nY));
		nResultY = (int)(sinTheta*(nX) + cosTheta*(nY));


		GetXY(nAxisInfo, nResultX, nResultY, nTransX, nTransY);
		nResultX = nTransX;
		nResultY = nTransY;

		pLine->npStartPos.x = nResultX;
		pLine->npStartPos.y = nResultY;

		if(bFilpX)
			nX = -pLine->npEndPos.x;
		else
			nX = pLine->npEndPos.x;
		if(bFilpY)
			nY = -pLine->npEndPos.y;
		else
			nY = pLine->npEndPos.y;
		
		nResultX = (int)(cosTheta*(nX) - sinTheta*(nY));
		nResultY = (int)(sinTheta*(nX) + cosTheta*(nY));
		
		 nTransX = 0;
		 nTransY = 0;
		GetXY(nAxisInfo, nResultX, nResultY, nTransX, nTransY);
		nResultX = nTransX;
		nResultY = nTransY;

		pLine->npEndPos.x = nResultX;
		pLine->npEndPos.y = nResultY;

		if(pLine->npStartPos.x < m_nLeft)	m_nLeft = pLine->npStartPos.x;
		if(pLine->npStartPos.x > m_nRight)	m_nRight = pLine->npStartPos.x;
		if(pLine->npEndPos.x < m_nLeft)		m_nLeft = pLine->npEndPos.x;
		if(pLine->npEndPos.x > m_nRight)	m_nRight = pLine->npEndPos.x;
		
		if(pLine->npStartPos.y < m_nBottom)	m_nBottom = pLine->npStartPos.y;
		if(pLine->npStartPos.y > m_nTop)	m_nTop = pLine->npStartPos.y;
		if(pLine->npEndPos.y < m_nBottom)	m_nBottom = pLine->npEndPos.y;
		if(pLine->npEndPos.y > m_nTop)		m_nTop = pLine->npEndPos.y;
	}
	
	LPCHARHOLE pHole;
	pos = m_HoleData.GetHeadPosition();
	while (pos)
	{
		pHole = m_HoleData.GetNext(pos);

		if(bFilpX)
			nX = -pHole->npHolePos.x;
		else
			nX = pHole->npHolePos.x;
		if(bFilpY)
			nY = -pHole->npHolePos.y;
		else
			nY = pHole->npHolePos.y;
		
		nResultX = (int)(cosTheta*(nX) - sinTheta*(nY));
		nResultY = (int)(sinTheta*(nX) + cosTheta*(nY));
		
		GetXY(nAxisInfo, nResultX, nResultY, nTransX, nTransY);
		nResultX = nTransX;
		nResultY = nTransY;

		pHole->npHolePos.x = nResultX;
		pHole->npHolePos.y = nResultY;
		
		if(pHole->npHolePos.x < m_nLeft)	m_nLeft = pHole->npHolePos.x;
		if(pHole->npHolePos.x > m_nRight)	m_nRight = pHole->npHolePos.x;
		if(pHole->npHolePos.y < m_nBottom)	m_nBottom = pHole->npHolePos.y;
		if(pHole->npHolePos.y > m_nTop)		m_nTop = pHole->npHolePos.y;
	}


	int nTemp[4] = {0,};
	nTemp[0] = abs(m_nLeft);
	nTemp[1] = abs(m_nRight);
	nTemp[2] = abs(m_nBottom);
	nTemp[3] = abs(m_nTop);

	int nMaxNo = 0;
	int nMaxValue = -1;
	for(int ii = 0; ii < 4; ii++)
	{
		if(nTemp[ii] > nMaxValue)
		{
			nMaxNo = ii;
			nMaxValue = nTemp[ii];
		}
	}

	if(nMaxNo == 0)
		m_nFinalRotation = ROT_180;
	else if(nMaxNo == 1)
		m_nFinalRotation = ROT_NONE;
	else if(nMaxNo == 2)
		m_nFinalRotation = ROT_270;
	else if(nMaxNo == 3)
		m_nFinalRotation = ROT_90;
}


void DTextData::GetXY(int nMode, int nX, int nY, int &nTransX, int &nTransY)
{
	if(nMode == X_Y)
	{
		nTransX = nX;
		nTransY = nY;
	}
	else if(nMode == MX_Y)
	{
		nTransX = -nX;
		nTransY = nY;
	}
	else if(nMode == X_MY)
	{
		nTransX = nX;
		nTransY = -nY;
	}
	else if(nMode == MX_MY)
	{
		nTransX = -nX;
		nTransY = -nY;
	}
	else if(nMode == Y_X)
	{
		nTransX = nY;
		nTransY = nX;
	}
	else if(nMode == MY_X)
	{
		nTransX = -nY;
		nTransY = nX;
	}
	else if(nMode == Y_MX)
	{
		nTransX = nY;
		nTransY = -nX;
	}
	else
	{
		nTransX = -nY;
		nTransY = -nX;
	}
}

int DTextData::GetDataCount(BOOL bDot)
{
	if(bDot)
	{
		m_pos = m_HoleData.GetHeadPosition();
		return m_HoleData.GetCount();	
	}
	else
	{
		m_pos = m_LineData.GetHeadPosition();
		return m_LineData.GetCount();
	}
}

BOOL DTextData::GetNextPoint(BOOL bDot, int &nX, int &nY, int &nX2, int &nY2)
{
	if(m_pos == NULL)
		return FALSE;
	if(bDot)
	{
		LPCHARHOLE pHole;
		pHole = m_HoleData.GetNext(m_pos);
		nX = 65535 * pHole->npHolePos.x / m_nUmFieldSize;
		nY = 65535 * pHole->npHolePos.y / m_nUmFieldSize;
		nX2 = 65535 * pHole->npHolePos.x / m_nUmFieldSize;
		nY2 = 65535 * pHole->npHolePos.y / m_nUmFieldSize;
	}
	else
	{
		LPCHARLINE pLine;
		pLine = m_LineData.GetNext(m_pos);
		nX = 65535 * pLine->npStartPos.x / m_nUmFieldSize;
		nY = 65535 * pLine->npStartPos.y / m_nUmFieldSize;
		nX2 = 65535 * pLine->npEndPos.x / m_nUmFieldSize;
		nY2 = 65535 * pLine->npEndPos.y / m_nUmFieldSize;
	}
	return TRUE;
}


// AutoManualScaleINIFile.h: interface for the CAutoManualScaleINIFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AutoManualScaleINIFile_H__FDDBB95A_81DA_4805_9B2C_3A37922E7E68__INCLUDED_)
#define AFX_AutoManualScaleINIFile_H__FDDBB95A_81DA_4805_9B2C_3A37922E7E68__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DAutoManualScaleINI;
class DSystemINI;

class CAutoManualScaleINIFile  
{
public:
	CAutoManualScaleINIFile();
	virtual ~CAutoManualScaleINIFile();

	BOOL	GetOldAutoManualScaleData(DAutoManualScaleINI& clsAutoManualScaleINI, DSystemINI clsSystemINI);
	BOOL	OpenAutoManualScaleINIFile(CString strFilePath, DAutoManualScaleINI& clsAutoManualScaleINI);
	BOOL	ParsingAutoManualScale(CStdioFile& sFile, DAutoManualScaleINI& clsAutoManualScaleINI);

	
	BOOL	SaveAutoManualScaleINIFile(CString strFilePath, DAutoManualScaleINI clsAutoManualScaleINI);
	BOOL	SaveAutoManualScale(CStdioFile& sFile, DAutoManualScaleINI clsAutoManualScaleINI);

	
	void	WriteLog(CString strLog);
};

#endif // !defined(AFX_AutoManualScaleINIFile_H__FDDBB95A_81DA_4805_9B2C_3A37922E7E68__INCLUDED_)

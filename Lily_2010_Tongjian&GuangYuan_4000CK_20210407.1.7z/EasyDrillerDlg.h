// EasyDrillerDlg.h : header file
//

#if !defined(AFX_EASYDRILLERDLG_H__8B49EFC0_C8DB_4C91_8FE2_EED2DD24BB6C__INCLUDED_)
#define AFX_EASYDRILLERDLG_H__8B49EFC0_C8DB_4C91_8FE2_EED2DD24BB6C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CEasyDrillerDlg dialog

#include "UI\UEasyButtonEx.h"
//#include "UI\EDClock.h"
#include "UI\ColorStatic.h"
#include "UI\ClockST.h"
#include "DPaneArray.h"
#include "UI\DlgSideVision.h"
#include "UI\DlgMotorMove.h"
#include "UI\DlgRecipeGen.h"
#include "UI\DlgTableView.h"
#include "UI\DlgIdleMode.h"
#include "device\OPCSvr.h"
#include "UI\DlgLpcView.h"
#include "UI\DlgIdleMode.h"
#include "UI\DlgLaserMeasurement.h"
#include "UI\DlgComponentTime.h"
//#include "device\comimotion.h"
//#include "device\comidaq.h"

// Main Pane
class CPaneMainMenu;
class CPaneRecipeGen;
class CPaneAutoRun;
class CPaneManualControl;
class CPaneProcessSetup;
class CPaneSysSetup;
class CPaneLogManager;
class CPaneUserAccount;
class CPaneDrillDisplay;

// Sub Pane
class CPaneAutoRunSub;
class CPaneRecipeGenSub;
class CPaneManualDrillSub;
class CPaneManualControlSub;
class CPaneProcessSetupSub;
class CPaneSysSetupSub;
class CPaneLogManagerSub;
class CPaneUserAccountSub;
class CPaneDrillDisplaySub;
class CPaneMotorSetupSub;

// utility pane
class CDlgFiducialView;

#ifdef __PUSAN1__	
	class CPaneSubMotorPositionPusan1;
#endif

#ifdef __PUSAN2__ 
	class CPaneSubMotorPositionPusan1;
#endif

#ifdef __KUNSAN_6__	
	class CPaneSubMotorPositionPusan1;
#endif
	
#ifdef __KUNSAN_8__	
	class CPaneSubMotorPositionKunsan8;
#endif

#ifdef __PUSAN_OLD_17__
	class CPaneSubMotorPositionPusan1;
#endif
	
#ifdef __PUSAN_OLD_32__
	class CPaneSubMotorPosition;
#endif

#ifdef __PUSAN_LDD__
	class CPaneSubMotorPositionLDD;
#endif
	
#ifdef __KUNSAN_1__	
	class CPaneSubMotorPosition;
#endif

#ifdef __OSAN_LG__	
	class CPaneSubMotorPositionPusan1;
#endif

#ifdef __KUNSAN_SAMSUNG_LARGE__ 
	class CPaneSubMotorPositionLarge;
#endif

class CDlgVisionView;
class CDlgMatroxVisionView;
class CDlgVisionProView;
class CDlgMotorMove;
class DlgRecipeGen;
class CDlgTableView;
class CDlgLpcView;
class CDlgComponent;
class CEasyDrillerDlg : public CDialog
{
// Construction
public:
	CEasyDrillerDlg(CWnd* pParent = NULL);	// standard constructor

	int		m_nBMInitialCount;
	int		m_nBeamDumperNo;
	void	InitBtnControl();
	void	InitStaticControl();
	void	InitPaneControl();
	void	InitSubPaneControl();
	void	InitSubPaneMotorPosition();
	void	InitSubPaneUtilityControl();

	void	ShowBtnControl(BOOL bShow=TRUE);
	void	ShowMenuBtnControl(BOOL bShow=TRUE);
	void	SetMenuBtn(int nID);

	void	SetErrorMsg(CString strMsg);
	void	SetPrjName(CString strName);
	CString	GetPrjName();
	void	SetDataName(CString strName);
	void	OnVisionView(int nIndex);
	void	OnResetLive();
	void	OnMoveVisionView();
	void SaveJobTimeLog(int ndiff, int nJobType);
	BOOL ShutterMove(BOOL bMaster, BOOL bSlave, BOOL bShowMessage = TRUE);

	void WriteProcessLog(CString strEvent, CString strInfo, BOOL bIsError = FALSE);
	void WriteLog(CString strFile, CString strLog);

	void CameraChangeHigh1st();
	void CameraChangeLow1st();
	void CameraChangeHigh2nd();
	void CameraChangeLow2nd();

// Dialog Data
	//{{AFX_DATA(CEasyDrillerDlg)
	enum { IDD = IDD_EASYDRILLER_DIALOG };
	UEasyButtonEx	m_btnMotorSetup;
	UEasyButtonEx	m_btnErrList;
	UEasyButtonEx	m_btnIniChange;
	CColorStatic	m_stcCadFileName;
	UEasyButtonEx	m_btnSystemSetup;
	UEasyButtonEx	m_btnProcessSetup;
	UEasyButtonEx	m_btnManualOperation;
	UEasyButtonEx	m_btnLogout;
	UEasyButtonEx	m_btnLogManager;
	UEasyButtonEx	m_btnDrill;
	UEasyButtonEx	m_btnLock;
	CColorStatic	m_stcCadName;
	CColorStatic	m_stcPrjName;
	CColorStatic	m_stcMsg;
	CColorStatic	m_stcMsgIdle;
	CColorStatic	m_stcSafety;
	UEasyButtonEx	m_btnExit;
	UEasyButtonEx	m_btnUserAccount;
	UEasyButtonEx	m_btnLogin;
//	CXJWDigitClock	m_stcDigitTime;
	CClockST		m_stcDigitTime;
	UEasyButtonEx	m_btnAlarm;
	UEasyButtonEx	m_btnErrPLC;
//	CComiMotion		m_ctrlMotion;
//	CComiDaq		m_ctrlDaq;
	//}}AFX_DATA

	CDlgLaserMeasurement m_dlgOPCWait;
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEasyDrillerDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

public :
	void ShowComponent();
	void GetVisionPosRect(CRect &rc);
	void ResetOPCRecvMessage();
	BOOL WaitOPCRecvMessage();
	void MessageLoop();
	BOOL OPCRecipeValidation(CString strLotID);
	BOOL OPCRecipeDelete();
	BOOL OPCRecipeCreate(CString strPrj, BOOL bChange);
	BOOL SendOPCRecipeInfo(int nType, DProject& myProject, CString strLotID = " ");
	BOOL RecvOPCRecipeInfo(int nType);
	BOOL OPCInOutAlarm();
	BOOL OPCRecipeUpdate();
	BOOL OPCRecipeDown();
	BOOL OPCRecipeList();
	void UpdateTagMessage(long nIndex, LPCTSTR szData);
	BOOL GetOPCConnection1();
	BOOL GetOPCConnection2();
	CString GetOPCStatus(int nNum);
	int GetCurrentLotID(CString& strLotID1, CString& strLotID2, CString& strPrj1, CString& strPrj2);
	CString GetMESReturnData1();
	BOOL GetRMSReturnData(CString& strLotCount, CString& strFilmNo, CString& strProcessCode);
	BOOL GetMESReturnData2(CString strLotID);
	BOOL GetMESCancelReturnData();
	CString GetDataName();

	void SetButtonInfo(CString str); // 20130522
	void ResetAllBitMap();
	void SetBitMap(HBITMAP hBitmap, BOOL bFirst, int nFidIndex, int nFidBlock);
	void ActiveStaticForKeyboardError();
	void ResetPowerScannerCalTime(BOOL bScanner, BOOL bPower);
	void BackupOldLogFile(void);
	BOOL GetSideStatus();
	void SetLilyVersion();
	void ResetProject();
	BOOL CheckOldINIFile(CString strFilePath);
	int	GetUserLevel() { return m_nUserLevel; }
	void SetAuthorityByLevel();
	BOOL ApplyProject();
	BOOL OpenProject(CString strPath);
	BOOL SaveProject(CString strPath);
	BOOL OpenRecentProject(CString strPath);
	void SetFileOpen(BOOL bOpen);
	BOOL GetFileOpen();
	BOOL GetLaserPower();
	BOOL CheckCalibrationTime();
	BOOL CheckPowerMeasureTime();
	BOOL CheckLaserPreheatTime();
	bool IsFileExist(CString &strFileName);
	void ParsingPowerTrend();
	void ParsingSCalLog();
	void LogCopy();
	void Capture();
	void ChangeLilySize(BOOL bBig);
	BOOL IsShowEasyTestDlg();
	BOOL m_bShowEasyTestDlg;
	BOOL m_bEasyTestEnable;
	// Main Pane
	CPaneMainMenu*			m_pMainMenu;
	CPaneRecipeGen*			m_pRecipeGen;
	CPaneAutoRun*			m_pAutoRun;
	CPaneManualControl*		m_pManualControl;
	CPaneProcessSetup*		m_pProcessSetup;
	CPaneSysSetup*			m_pSysSetup;
	CPaneLogManager*		m_pLog;
	CPaneUserAccount*		m_pUserAccount;
	HWND					m_hUserAccount;
	CPaneDrillDisplay*		m_pDrillDisplay;
	HWND					m_hMotorSetup;

//	CDlgVisionView*			m_pVisionView;
	CDlgVisionProView*		m_pVisionProView;
	CDlgMatroxVisionView*	m_pMatroxVisionView;
	CDlgSideVision			m_dlgSideVision;
	CDlgMotorMove			m_dlgSideMotor;
		CDlgRecipeGen*			m_pDlgRecipeGen;
	CDlgTableView			m_dlgTable;
	CDlgLpcView				m_dlgLpc;
	CPaneManualDrillSub*	m_pManualDrillSub;
	CWnd*					m_pVisionView;

	//CDlgComponentTime		m_dlgComponent;

	CRITICAL_SECTION		m_CritLog;
	int						m_nIdleFireStatus;
	int						m_nIdleRepeatCount;
//	double					m_dIdleFireTime;
//	double					m_dIldeStopTime;
	BOOL					m_bShowIdleDlg;
	char					m_cButtonInfo[256]; // 20130522
	COPCSvr*				m_pOpc;
	CPaneRecipeGenSub*		m_pRecipeGenSub;
// Implementation
protected:
	HICON					m_hIcon;
	CFont					m_fntBtn;
	CFont					m_fntStatic;
	CFont					m_fntStatic2;
	DPaneArray				m_clsPaneArray;
	DPaneArray				m_clsSubPaneArray;
	DPaneArray				m_clsUtiliyPaneArray;
	int						m_nUserLevel;
	int						m_nTimer1;
	CRect					hidden_rect ;
	CRect					hidden_rect2;
	CRect					hidden_rect3;
	CRect					hidden_rect4;
	int						hidden_point ;
	BOOL					m_bRegenIO;
	int						m_nLockCnt;
	BOOL					m_bLocked;
	BOOL					m_bLogIned;
	BOOL					m_bLogCopy;
	CTime					m_ctTime;
	int						m_nStartTime;
	BOOL					m_bVisionSide; // double click event�� ȭ�� �̵��Ѱ��
	static BOOL				m_bOPCFirst;
	CWnd*					m_pOPCHandle;
	// Sub Pane
	CPaneAutoRunSub*		m_pAutoRunSub;
	
//	CPaneManualDrillSub*	m_pManualDrillSub;
	CPaneManualControlSub*	m_pManualControlSub;
	CPaneProcessSetupSub*	m_pProcessSetupSub;
	CPaneSysSetupSub*		m_pSysSetupSub;
	CPaneLogManagerSub*		m_pLogManagerSub;
	CPaneUserAccountSub*	m_pUserAccountSub;
	CPaneDrillDisplaySub*	m_pDrillDisplaySub;
	CPaneMotorSetupSub*		m_pMotorSetupSub;
	CDlgFiducialView*		m_dlgFiducialAllView;

#ifdef __PUSAN1__	
	CPaneSubMotorPositionPusan1*	m_pSubMotorPosition;
#endif
	
#ifdef __PUSAN2__ 
	CPaneSubMotorPositionPusan1*	m_pSubMotorPosition;
#endif

#ifdef __KUNSAN_6__	
	CPaneSubMotorPositionPusan1*	m_pSubMotorPosition;
#endif
	
#ifdef __OSAN_LG__	
	CPaneSubMotorPositionPusan1*	m_pSubMotorPosition;
#endif

#ifdef __KUNSAN_8__	
	CPaneSubMotorPositionKunsan8*	m_pSubMotorPosition;
#endif
	
#ifdef __PUSAN_OLD_17__
	CPaneSubMotorPositionPusan1*	m_pSubMotorPosition;
#endif

#ifdef __PUSAN_OLD_32__
	CPaneSubMotorPosition*	m_pSubMotorPosition;
#endif

#ifdef __PUSAN_LDD__
	CPaneSubMotorPositionLDD*	m_pSubMotorPosition;
#endif

#ifdef __KUNSAN_1__	
	CPaneSubMotorPosition*	m_pSubMotorPosition;
#endif

#ifdef __KUNSAN_SAMSUNG_LARGE__	
	CPaneSubMotorPositionLarge*	m_pSubMotorPosition;
#endif

	// Generated message map functions
	//{{AFX_MSG(CEasyDrillerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnCancel();
	afx_msg void OnButtonLogin();
	afx_msg void OnButtonUserAccount();
	afx_msg void OnButtonDrill();
	afx_msg void OnButtonManualOperation();
	afx_msg void OnButtonProcessSetup();
	afx_msg void OnButtonSystemSetup();
	afx_msg void OnButtonLogManager();
	afx_msg void OnButtonLogout();
	afx_msg void OnButtonLock();
	afx_msg void OnButtonErrList();
	afx_msg void OnButtonIniChange();
	afx_msg void OnButtonErrorClear();
	afx_msg void OnButtonErrPLC();
	virtual void OnOK();
	afx_msg void OnButtonMotorSetup();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMove(int x, int y);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	afx_msg LRESULT OnChangePane(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnChangeSubPane(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnGetBackPaneNo(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnApplyProcess(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnApplySystem(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnLogMessage(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnButtonMessage(WPARAM wParam = NULL, LPARAM lParam = NULL); // 20130522
	afx_msg LRESULT OnDrillStart(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnDrillOneCycle(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnDrillPause(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnDrillStop(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnSendErrMsg(WPARAM wParam, LPARAM lParam = NULL);
	afx_msg LRESULT OnSaveINIFile(WPARAM wParam, LPARAM lParam = FALSE);
	afx_msg LRESULT OnSystemSubUIChange(WPARAM wParam, LPARAM lParam = NULL);
	afx_msg LRESULT OnChangeDataFile(WPARAM wParam = TRUE, LPARAM lParam = NULL);
	afx_msg LRESULT OnSetErrMsg(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnControlTabEnable(WPARAM wParam = NULL, LPARAM lParam = FALSE);
	afx_msg LRESULT OnControlTabEnableEasyMode(WPARAM wParam = NULL, LPARAM lParam = FALSE);

	afx_msg LRESULT OnDoCalibration(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnModeChange(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnVisionLive(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnSetErrMsgID(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnWriteLog(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnAutoPowerMeasure(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnResetSwitch(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnComponentPreAcq(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnDoPowerMeasurement(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnChillerAlarm(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnAddFidResult(WPARAM wParam, LPARAM lParam = NULL);
	afx_msg LRESULT OnChangeView(WPARAM wParam, LPARAM lParam = NULL);
	afx_msg LRESULT OnChangePrework(WPARAM wParam, LPARAM lParam = NULL);
	afx_msg LRESULT OnPowerResult(WPARAM wParam, LPARAM lParam = NULL);
	afx_msg LRESULT OnScannerResult(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnPreDoingDraw(WPARAM wParam, LPARAM lParam = NULL);
	afx_msg LRESULT OnDoApplySCalResult(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnDoChangeSCalPreWorkInfo(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnSetAnyPrework(WPARAM wParam, LPARAM lParam = NULL);
	afx_msg LRESULT OnDrillOneCycleNoUnload(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnIniUIUpdate(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnWindowReadyForFidCap(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnEnableSafetyMode(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnResortArea(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnSideWindowShowHide(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnIsShowEasyTestWindow(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnEnableEasyTestWindow(WPARAM wParam, LPARAM lParam);

	afx_msg LRESULT OnEasyTestWindowShowHide(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnEasyTestDraw(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnEasyTestDraw2(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnMainUIMoveTopLeft(WPARAM wParam = NULL, LPARAM lParam = NULL);
	afx_msg LRESULT OnOldProjectBackUpAndDelete(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnResizeVision(WPARAM wParam, LPARAM lParam = NULL);
	afx_msg LRESULT OnInputFidImage(WPARAM wParam, LPARAM lParam = FALSE);
	afx_msg LRESULT OnCalAutoScalPos(WPARAM wParam = FALSE, LPARAM lParam = FALSE);
	afx_msg LRESULT OnChangeTableMode(WPARAM wParam, LPARAM lParam = FALSE);
	afx_msg LRESULT OnIdleMode(WPARAM wParam = FALSE, LPARAM lParam = FALSE);
	afx_msg LRESULT OnUpdateTag(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnUpdateError(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnUpdateErrorClear(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnUpdateRecipe(WPARAM wParam, LPARAM lParam = NULL);
	afx_msg LRESULT OnSetCurrentLotID(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnOPCStatus(WPARAM wParam, LPARAM lParam = NULL);
	afx_msg LRESULT OnSetJobTime(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonChangeSize();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EASYDRILLERDLG_H__8B49EFC0_C8DB_4C91_8FE2_EED2DD24BB6C__INCLUDED_)

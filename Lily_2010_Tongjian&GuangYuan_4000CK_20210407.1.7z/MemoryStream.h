#define MEMORY_STRING_DECL\
  LPSTREAM lpStream = NULL;

#define MEMORY_STRING_CREATE\
  CreateStreamOnHGlobal(NULL, TRUE, &lpStream);

#define MEMORY_STRING_RESET {\
  LARGE_INTEGER liBeggining = { 0 };\
  lpStream -> Seek(liBeggining, STREAM_SEEK_SET, NULL);\
}

#define MEMORY_STRINGCOPY(lpString, lpbError) {\
  ULONG ulBytesWritten = 0;\
  ULONG ulSize = 0;\
  ULARGE_INTEGER uliSize = { 0 };\
\
  MEMORY_STRING_RESET\
\
  lpStream -> SetSize (uliSize);\
\
  ulSize = (ULONG)strlen(lpString);\
  lpStream -> Write((void const*)lpString, (ULONG)ulSize, (ULONG*)&ulBytesWritten);\
\
  if (lpbError)\
  {\
    if (ulSize == ulBytesWritten)\
    {\
      *((BOOL*)lpbError) = FALSE;\
    }\
    else\
    {\
      *((BOOL*)lpbError) = TRUE;\
    }\
  }\
}

#define MEMORY_STRINGCAT(lpString, lpbError) {\
  ULONG ulBytesWritten = 0;\
  ULONG ulSize = 0;\
\
  ulSize = strlen(lpString);\
  lpStream -> Write((void const*)lpString, (ULONG)ulSize, (ULONG*)&ulBytesWritten);\
\
  if (lpbError)\
  {\
    if (ulSize == ulBytesWritten)\
    {\
      *((BOOL*)lpbError) = FALSE;\
    }\
    else\
    {\
      *((BOOL*)lpbError) = TRUE;\
    }\
  }\
}

#define MEMORY_STRING_READ(lpReceiver, lpulSizeReceiver)\
{\
  STATSTG statstg;\
\
  MEMORY_STRING_RESET\
\
  memset (&statstg, 0, sizeof(statstg));\
  lpStream -> Stat(&statstg, STATFLAG_NONAME);\
\
  if ((ULONG*)lpulSizeReceiver)\
  {\
    *((ULONG*)lpulSizeReceiver) = statstg.cbSize.LowPart;\
  }\
\
  if ((void*)lpReceiver)\
  {\
    memset ((void*)lpReceiver, 0, statstg.cbSize.LowPart + sizeof(char));\
    lpStream -> Read((void*)lpReceiver, statstg.cbSize.LowPart, NULL);\
  }\
}

#define MEMORY_STRING_DESTROY\
  if (lpStream)\
  {\
    lpStream -> Release();\
	lpStream = NULL;\
  }


  

HRESULT StreamResetPointer (LPSTREAM lpStream);
HRESULT StreamStringCopy (LPSTREAM lpStream, LPCTSTR lpString);
HRESULT StreamStringCat (LPSTREAM lpStream, LPCTSTR lpString);
HRESULT StreamStringRead (LPSTREAM lpStream, LPTSTR lpszReceiver, ULONG* lpulSizeReceiver);


  
  
  

#include "stdafx.h"
#include "DPowerAttenCompensation.h"
#include "DEasyDrillerINI.h"
#include <math.h>


DPowerAttenCompensation::DPowerAttenCompensation(void)
{
	m_calHead.dOffset = NULL;
	m_bCompenOK[0] = m_bCompenOK[1] = FALSE;
}


DPowerAttenCompensation::~DPowerAttenCompensation(void)
{
	if(m_calHead.dOffset)
	{
		delete [] m_calHead.dOffset;
		m_calHead.dOffset = NULL;
	}
}

void DPowerAttenCompensation::SetRawData( double dPowerVal)
{
	if(m_nAddCount >= m_nCount)
		return;

	m_calHead.dOffset[m_nAddCount * m_calHead.nGridY + 0].x = dPowerVal;
	m_calHead.dOffset[m_nAddCount * m_calHead.nGridY + 1].x = dPowerVal;
	m_calHead.dOffset[m_nAddCount * m_calHead.nGridY + 2].x = dPowerVal;
	m_calHead.dOffset[m_nAddCount * m_calHead.nGridY + 3].x = dPowerVal;

	m_calHead.dOffset[m_nAddCount * m_calHead.nGridY + 0].y = dPowerVal;
	m_calHead.dOffset[m_nAddCount * m_calHead.nGridY + 1].y = dPowerVal;
	m_calHead.dOffset[m_nAddCount * m_calHead.nGridY + 2].y = dPowerVal;
	m_calHead.dOffset[m_nAddCount * m_calHead.nGridY + 3].y = dPowerVal;

	m_nAddCount++;
}

void DPowerAttenCompensation::SetCount(int nCount, double dDeltaAttenPos, double dStartAttenPos)
{
	if(m_calHead.dOffset)
	{
		delete [] m_calHead.dOffset;
		m_calHead.dOffset = NULL;
	}

	m_nCount = nCount;
	DPOINT* pdOffsetVal;
	pdOffsetVal = new DPOINT[nCount * 4]; 
	m_calHead.dOffset = pdOffsetVal;
	m_calHead.dXStart = dStartAttenPos;
	m_calHead.dYStart = 0;
	m_calHead.dGap = dDeltaAttenPos;
	m_calHead.nGridX = m_nCount;
	m_calHead.nGridY = 4;
	m_nAddCount = 0;
}

BOOL DPowerAttenCompensation::MakeTable(BOOL b1stPanel)
{
	CBicubicInterpolation* pTempTable = new CBicubicInterpolation;
	pTempTable->SetMatrixToZero();
	pTempTable->UpdateCalibration(m_calHead);

	int n1st2ndIndex = 1;
	if(b1stPanel)
		n1st2ndIndex = 0;

	double dMinVal = 1000000, dMaxVal = -1000000;
	double dPower1, dPower2;
	int nAttenPos;
	m_nStartAttenPos[n1st2ndIndex] = (int)m_calHead.dXStart ;
	m_nEndAttenPos[n1st2ndIndex] = (int)m_calHead.dXStart + (m_nCount - 1) * (int)m_calHead.dGap ;
	for(nAttenPos = m_nStartAttenPos[n1st2ndIndex]; nAttenPos <= m_nEndAttenPos[n1st2ndIndex]; nAttenPos++)
	{
		if(nAttenPos < 0 || nAttenPos >= ATTEN_MAX_VAL)
			continue;
		pTempTable->GetCalibrationOffset((double)nAttenPos, 0.0, dPower1, dPower2);
		if(dPower1 < dMinVal)
			dMinVal = dPower1;
		if(dPower1 > dMaxVal)
			dMaxVal = dPower1;

		m_dPowerPercent[n1st2ndIndex][nAttenPos] = dPower1;
		TRACE(_T("%.5f\n"), dPower1);
	}

	for(nAttenPos = m_nStartAttenPos[n1st2ndIndex]; nAttenPos <= m_nEndAttenPos[n1st2ndIndex]; nAttenPos++)
	{
		if(nAttenPos < 0 || nAttenPos >= ATTEN_MAX_VAL)
			continue;

		m_dPowerPercent[n1st2ndIndex][nAttenPos] = (m_dPowerPercent[n1st2ndIndex][nAttenPos] - dMinVal)/(dMaxVal - dMinVal) * 100;
		TRACE(_T("%.5f\n"), dPower1);
	}
	delete pTempTable;
	return SaveFile(n1st2ndIndex);

}

BOOL DPowerAttenCompensation::SaveFile(int n1st2ndIndex)
{
	CString strCalPath;
	if(n1st2ndIndex == 0) // 1st panel
		strCalPath.Format(_T("%sAtten1st.cal"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());
	else
		strCalPath.Format(_T("%sAtten2nd.cal"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());


	FILE* fileStream;
	errno_t err;
	TRY
	{
		err = fopen_s(&fileStream, strCalPath, _T("w+"));
		if(err != NULL)
		{
			return FALSE;		
		}

		fprintf(fileStream, _T("%d\n"), m_nStartAttenPos[n1st2ndIndex]);
		fprintf(fileStream, _T("%d\n"), m_nEndAttenPos[n1st2ndIndex]);

		for(int nAttenPos = m_nStartAttenPos[n1st2ndIndex]; nAttenPos <= m_nEndAttenPos[n1st2ndIndex]; nAttenPos++)
		{
			if(nAttenPos < 0 || nAttenPos >= ATTEN_MAX_VAL)
				continue;
			fprintf(fileStream, _T("%.4f\n"), m_dPowerPercent[n1st2ndIndex][nAttenPos]);
		}
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		return FALSE;
	}
	END_CATCH

	m_bCompenOK[n1st2ndIndex] = TRUE;
	fclose(fileStream);
	return TRUE;
}

BOOL DPowerAttenCompensation::LoadFile(int n1st2ndIndex)
{
	CString strCalPath;
	if(n1st2ndIndex == 0) // 1st panel
		strCalPath.Format(_T("%sAtten1st.cal"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());
	else
		strCalPath.Format(_T("%sAtten2nd.cal"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());


	FILE* fileStream;
	errno_t err;
	TRY
	{
		err = fopen_s(&fileStream, strCalPath, _T("r"));
		if(err != NULL)
			return FALSE;		

		CString str;
		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_nStartAttenPos[n1st2ndIndex] = atoi(str);
		fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		m_nEndAttenPos[n1st2ndIndex] = atoi(str);

		for(int nAttenPos = m_nStartAttenPos[n1st2ndIndex]; nAttenPos <= m_nEndAttenPos[n1st2ndIndex]; nAttenPos++)
		{
			if(nAttenPos < 0 || nAttenPos >= ATTEN_MAX_VAL)
				continue;

			fscanf(fileStream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			m_dPowerPercent[n1st2ndIndex][nAttenPos] = atof(str);
		}
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		return FALSE;
	}
	END_CATCH

	fclose(fileStream);

	m_bCompenOK[n1st2ndIndex] = TRUE;
	return TRUE;
}

BOOL DPowerAttenCompensation::IsTableOK(int n1st2ndIndex)
{
	return m_bCompenOK[n1st2ndIndex];
}

int DPowerAttenCompensation::GetTagerAttenPos(int n1st2ndIndex, double dTagetPower, double dCurrentPower, int nCurrentAttenPos)
{
	int nTransCurrentAttenPos = nCurrentAttenPos % ATTEN_CYCLE;
	while(nTransCurrentAttenPos < m_nStartAttenPos[n1st2ndIndex])
	{
		nTransCurrentAttenPos += ATTEN_CYCLE;
	}
	double dCurrentRatio= m_dPowerPercent[n1st2ndIndex][nTransCurrentAttenPos] / 100.0;
	double dCanGetMaxPower = dCurrentPower / dCurrentRatio;
	if(dCanGetMaxPower <= dTagetPower) // �ϴ� max��ġ�� �̵��غ���.
	{
		for(int nAttenPos = m_nStartAttenPos[n1st2ndIndex]; nAttenPos <= m_nEndAttenPos[n1st2ndIndex]; nAttenPos++)
		{
			if(nAttenPos < 0 || nAttenPos >= ATTEN_MAX_VAL)
				continue;

			if(m_dPowerPercent[n1st2ndIndex][nAttenPos] >= 99.999)
				return nAttenPos - nCurrentAttenPos;
		}
	}
	else
	{
		double dTargetPercent = dTagetPower / dCanGetMaxPower * 100.0;
		double dMinDiff = 100000;
		int nAttenPosIndex = nCurrentAttenPos;
		for(int nAttenPos = m_nStartAttenPos[n1st2ndIndex]; nAttenPos <= m_nEndAttenPos[n1st2ndIndex]; nAttenPos++)
		{
			if(nAttenPos < 0 || nAttenPos >= ATTEN_MAX_VAL)
				continue;

			if(dMinDiff > fabs(m_dPowerPercent[n1st2ndIndex][nAttenPos] - dTargetPercent))
			{
				dMinDiff = fabs(m_dPowerPercent[n1st2ndIndex][nAttenPos] - dTargetPercent);
				nAttenPosIndex = nAttenPos;
			}
		}
		return nAttenPosIndex - nCurrentAttenPos;
	}
	return 0; // 0�� ���� �Ŀ� ������ ������ ���̴�.
}

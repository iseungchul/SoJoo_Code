// PltReader.h: interface for the PltReader class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PLTREADER_H__B13FF4B8_C40B_4C1A_A653_A18D5B23D798__INCLUDED_)
#define AFX_PLTREADER_H__B13FF4B8_C40B_4C1A_A653_A18D5B23D798__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "GlyphPlt.h"

class PltReader  
{
public:
	BOOL ReadFile(LPCTSTR lpszFileName, GlyphPlt* pGlyphPlt, int nFieldSize);
	GlyphPlt* m_pGlyphPlt;
	PltReader();
	virtual ~PltReader();

};

#endif // !defined(AFX_PLTREADER_H__B13FF4B8_C40B_4C1A_A653_A18D5B23D798__INCLUDED_)

// DSystemINI.cpp: implementation of the DSystemINI class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DSystemINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
DSystemINI gSystemINI;

DSystemINI::DSystemINI()
{
	memset( &m_sHardWare, 0, sizeof(m_sHardWare) );
	memset( &m_sSystemDevice, 0, sizeof(m_sSystemDevice) );
	memset( &m_sSystemCollimator, 0, sizeof(m_sSystemCollimator) );
	memset( &m_sSystemDump, 0, sizeof(m_sSystemDump) );
	memset( &m_sAxisInfo, 0, sizeof(m_sAxisInfo) );
	memset( &m_sSystemTophat, 0, sizeof(m_sSystemTophat) );
	memset( &m_sSystemComponent, 0, sizeof(m_sSystemComponent));	//201164
	InitValue();
}

DSystemINI::~DSystemINI()
{

}

void DSystemINI::InitValue()
{
	m_sHardWare.nBeamType = HEAD2_BEAM1_LASER1;
	m_sHardWare.nLaserType = LASER_CO2;
	m_sHardWare.nUseLampRS232 = FALSE;

	m_sSystemDevice.nMinCycleTime = 2; // 2ms
	m_sSystemDevice.nMinShotTime = 0; // 0us for AVIA 20W UV
	m_sSystemDevice.nShotDrillType = SHOT_DRILL_ORIGIN; //  ���� ���
	m_sSystemDevice.nNoUseVision = FALSE; // IDD UV
	m_sSystemDevice.nUseFidFindInCenter = TRUE;
	m_sSystemDevice.nSelfLineDivide = TRUE;
	m_sSystemDevice.nFlyingDelayTime = 0; // 0us
	
	m_sSystemDevice.nAviaUserLevel = 0;
	
	m_sSystemDevice.dOriginFieldSize.x = 58.0;
	m_sSystemDevice.dOriginFieldSize.y = 58.0;
	m_sSystemDevice.dFieldSize.x = 50.0;
	m_sSystemDevice.dFieldSize.y = 58.0;

	m_sSystemDevice.dPowerMeasurementMSize.x = 58.0;
	m_sSystemDevice.dPowerMeasurementMSize.y = 65.0;
	m_sSystemDevice.dPowerMeasurementSSize.x = 58.0;
	m_sSystemDevice.dPowerMeasurementSSize.y = 65.0;
	
	m_sSystemDevice.dJumpSpeed = 3000; // mm/s
	m_sSystemDevice.nCornerDelay = 10;
	m_sSystemDevice.nLineDelay = 250;
	m_sSystemDevice.nJumpDelay = 350;
	
	m_sSystemDevice.nLowCalArea = 200;
	m_sSystemDevice.nHighCalArea = 450;

	m_sSystemDevice.sChillerPort.dCH1 = 23;
	m_sSystemDevice.sChillerPort.dCH2 = 18;
	
	m_sHardWare.nUseBeamDumper = FALSE; // 20070730
	m_sSystemDump.nPtBeanDumper1.x = m_sSystemDump.nPtBeanDumper2.x = 32767; // 20070730
	m_sSystemDump.nPtBeanDumper1.y = m_sSystemDump.nPtBeanDumper2.y = 65000;
	m_sHardWare.nManualMachine = TRUE; // no loader/unloader
	m_sHardWare.nDustTableUse = FALSE; // IDD UV ���� ������. ���̺� Ư�� ���ۿ� ������ ����
	m_sHardWare.nScannerAxisType = NX_NY;	//  X <------
											//			 |
											//			 |		
											//			 V	y
	m_sHardWare.nScannerAxisType2 = NX_NY;
	m_sHardWare.nExcellonOpenAxis = PX_PY;
	m_sHardWare.nUseEocardAxis = EO_USE_1ST + EO_USE_2ND;
	m_sHardWare.nShortLineDutyOffset = 0;
	m_sHardWare.nShortLineLength = 4000;
	m_sHardWare.nAOMType = 0;
	m_sHardWare.nEocardType = 0;
	m_sHardWare.bTableVacuumSelect = TRUE;
	m_sHardWare.nUseBarcodeReader = 0;
	m_sHardWare.nUseAOD = TRUE;
	m_sHardWare.bUseWideMonitor = FALSE;
	m_sHardWare.nAutoLockTime = 600; // 10��
	m_sHardWare.nAODMSSelect = TRUE;
	m_sHardWare.bUseVacummmotor = TRUE;
	m_sHardWare.nUseFirstOrder = TRUE;

	m_sHardWare.nUseDualBand = FALSE;
	m_sHardWare.nLanguageType = 0;
	m_sHardWare.dScannerWaringLevelmm = 0.005;
	m_sHardWare.dScannerAlarmLevelmm = 0.01;
	m_sHardWare.dLPCMinTolerence = 0.8;
	m_sHardWare.dLPCMaxTolerence = 1.2;
	m_sHardWare.dLPCStartTolerencePercent = 20;
	m_sHardWare.nLPCStartSkipCount = 200;

	m_sHardWare.bUseFastInposition = FALSE;
	m_sHardWare.bUseLPC = FALSE;
	m_sHardWare.nMachineNo = 1;
	m_sHardWare.nTableShootLimit = 30; // um
	m_sHardWare.nLPCMinimum = 100;





	m_sHardWare.bLaserCalAlarm = 0; //20130515 bskim
	m_sHardWare.bSaveButtonLog = TRUE; // 20130522
	m_sHardWare.bChillerConnect = FALSE;
	m_sHardWare.bHumidityConnect = FALSE;
	m_sHardWare.bTemperCompConnect = FALSE;
	m_sHardWare.bVoltageConnect = FALSE;
	m_sHardWare.bLinkRS485 = FALSE;
	m_sHardWare.bCheckMCMode = FALSE;
	m_sHardWare.bFirstOffsetMode = FALSE;

	m_sSystemDevice.d2DCompTableOffset.x = m_sSystemDevice.d2DCompTableOffset.y = 0;
	
	m_sSystemDevice.nEocardDownCount = 1000;
	m_sSystemDump.nDummyShot = 200;
	m_sSystemDump.nDummyInterval = 350; // us
	m_sSystemDump.nDummyFreq = 3000;
	m_sSystemDump.nDummyDuty = 67;
	m_sSystemDump.nDummyAOMDelay = 0;
	m_sSystemDump.nDummyAOMDuty = 1;
	m_sSystemDump.nDummyStartAfterTableStop = 0;
	m_sSystemDevice.bCheckHoleData = FALSE;

	m_sSystemDump.nDummyShot2 = 200;
	m_sSystemDump.nDummyInterval2 = 350; // us
	m_sSystemDump.nDummyFreq2 = 3000;
	m_sSystemDump.nDummyDuty2 = 67;
	m_sSystemDump.nDummyAOMDelay2 = 0;
	m_sSystemDump.nDummyAOMDuty2 = 1;
	
	m_sSystemDump.nStandbyTime = 3000;
	m_sSystemDump.nStandbyMinFreq = 2000;
	m_sSystemDump.nStandbyMaxFreq = 4000;
	m_sSystemDump.nStandbyInterval = 3000;
	m_sSystemDump.nStandbyDuty = 40;
	m_sSystemDump.nStandbyInpositionTime = 20;
	m_sSystemDump.dStandby1stV = 90;
	m_sSystemDump.dStandby2ndV = 90;
	m_sSystemDump.nStandbyTurnOffTime = 10; // time 10 min

	m_sSystemDump.nStandbyTime_Scal = 10;

	m_sSystemDump.nStandbyTime2 = -999;
	m_sSystemDump.nStandbyMinFreq2 = -999;
	m_sSystemDump.nStandbyMaxFreq2 = -999;
	m_sSystemDump.nStandbyInterval2 = -999;
	m_sSystemDump.nStandbyDuty2 = -999;
	m_sSystemDump.nStandbyInpositionTime2 = -999;
	m_sSystemDump.dStandby1stV2 = -999;
	m_sSystemDump.dStandby2ndV2 = -999;
	m_sSystemDump.nStandbyTurnOffTime2 = -999; // time 10 min




	m_sSystemDevice.dAcceptScore = 0.9;
	m_sSystemDevice.dAcceptEdgeScore = 0.6;
	m_sSystemDevice.dRotateHoleAcceptScore = 0.6;
	m_sSystemDevice.dResultScore = 0.6;
	m_sSystemDevice.dExposure = 0.02;
	m_sSystemDevice.nCalGridDelay = 1000;
	m_sSystemDevice.nCalGridMode = 0;
	m_sSystemDevice.nEStop = 0; 

	m_sSystemDevice.dLowFOVX = 8;
	m_sSystemDevice.dLowFOVY = 6;
	m_sSystemDevice.dHighFOVX = 1.2;
	m_sSystemDevice.dHighFOVY = 1;
	m_sSystemDevice.nCameraPixelX = 1020;
	m_sSystemDevice.nCameraPixelY = 766;
	m_sSystemDevice.nBlob = 0;

	for(int i = 0; i < 4; i++)
	{
		m_sSystemDevice.dVisionPixcel1[i][0].x = 0; m_sSystemDevice.dVisionPixcel1[i][0].y = 0;//[cam][position] 
		m_sSystemDevice.dVisionPixcel2[i][0].x = 0; m_sSystemDevice.dVisionPixcel2[i][0].y = 0;

		m_sSystemDevice.dVisionPixcel1[i][1].x = 1020; m_sSystemDevice.dVisionPixcel1[i][1].y = 0;//[cam][position] 
		m_sSystemDevice.dVisionPixcel2[i][1].x = 1020; m_sSystemDevice.dVisionPixcel2[i][1].y = 0;

		m_sSystemDevice.dVisionPixcel1[i][2].x = 1020; m_sSystemDevice.dVisionPixcel1[i][2].y = 766;//[cam][position] 
		m_sSystemDevice.dVisionPixcel2[i][2].x = 1020; m_sSystemDevice.dVisionPixcel2[i][2].y = 766;

		m_sSystemDevice.dVisionPixcel1[i][3].x = 0; m_sSystemDevice.dVisionPixcel1[i][3].y = 766;//[cam][position] 
		m_sSystemDevice.dVisionPixcel2[i][3].x = 0; m_sSystemDevice.dVisionPixcel2[i][3].y = 766;
	}

	m_sSystemDevice.nVibrationCount = 5;
	m_sSystemDevice.dVibrationDelay = 1.5;
	m_sSystemDevice.nVibrationLPTime = 0;

	m_sSystemComponent.nPreAcTime = 0;	//201164
	
	m_sSystemVacuum.dVacuumOffset = 50.0;
	m_sSystemVacuum.dVacuumOffset2 = 50.0;
	m_sSystemVacuum.dSuctionHoodOffset= 50.0;
	for(int i = 0; i<4; i++)
	{
		m_sSystemVacuum.dTable1Vacuum[i] = 50.0;
		m_sSystemVacuum.dTable2Vacuum[i] = 50.0;
	}
	
	m_sSystemDevice.dTextGap = 0.4;
	m_sSystemDevice.nTextRefMode = 6;
	m_sSystemDevice.bUseInnerOCRFont = FALSE;
	m_sSystemDevice.nFiducialFindType = 1;

	m_sSystemDevice.dTableLimitMaxX = 1000;
	m_sSystemDevice.dTableLimitMaxY = 1000;
	m_sSystemDevice.dTableLimitMinX = -1000;
	m_sSystemDevice.dTableLimitMinY = -1000;
	m_sSystemDevice.dTableSizeX = 550;
	m_sSystemDevice.dTableSizeY = 650;
	m_sSystemDevice.dTableAcrSizeX = 550;
	m_sSystemDevice.dTableAcrSizeY = 150;

	m_sSystemDevice.nMaskInposWait = 0;

	m_sSystemDevice.bCheckDownloadASCValue = TRUE;
}

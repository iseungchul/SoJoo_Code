// GerberReader.cpp: implementation of the GerberReader class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GerberReader.h"
#include "..\EasyDriller.h"
#include "..\resource.h"
#include "DProject.h"
//#include "..\sysdef.h"
#include "DUodoRedo.h"
#include <math.h>
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#define METRIC_RATE		0.1   //20121218 �⺻ ������ 0.1-> �׽�Ʈ 0.01�ٲٱ�

GerberReader::GerberReader()
{

	m_bReadStart	= TRUE;
	m_nOldTCode		= 0;
	m_nNewTCode		= 1;
	m_nNewMCode		= 0;
	m_nLength		= 0;

	m_bRepeat		= FALSE;
	m_bIsSwap		= FALSE;
	m_bStoreData	= FALSE;
	m_nMirrorX		= 1;
	m_nMirrorY		= 1;
	m_bIsRead		= FALSE;
	m_bSetFid		= FALSE;
	m_bSetFid2		= FALSE;
	m_nFidBlock		= -1;
	m_nHoleSize			= 0;
	m_bOverlapXY		= FALSE;

	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;
	m_pGlyphExcell = NULL;
	m_pDProject = NULL;
	m_pUnit		= NULL;
	m_nToolCnt  = 0; 
	m_bOldLine	= FALSE;
	m_nRRepeatX = 1; //x�� �ݺ� Ƚ�� 
	m_nRRepeatY = 1; //y�� �ݺ� Ƚ�� 
	m_nRDupliMX = 0; //�ݺ� X Offset
	m_nRDupliMY = 0; //�ݺ� Y Offset
	m_dDivide	= 5;
	m_bCycle = FALSE;
	m_bCW = TRUE;
	memset(m_nToolMatch,0,sizeof(m_nToolMatch));
	memset(m_nToolFirstType,0,sizeof(m_nToolFirstType));
	m_nCurrentToolType = 0;

	m_pDuplexUnit = NULL;

}

GerberReader::~GerberReader()
{

}

int GerberReader::Read(CString strPath, short nLzs, int nInputUnit, GlyphExcellon *pExcellon, DProject *pProject, int nDivide)
{
	m_nFidBlock = -1;
	m_dDivide = nDivide;
	if(m_dDivide < 3)
		m_dDivide = 3;
	
	m_bCorrectTool = TRUE;
	char chBuffer[BUFMAX + 1], *token;

	TCHAR *szNext;
	FILE* pFile;
	fopen_s(&pFile,strPath, "rb");
	if (pFile != NULL)
	{
		m_pGlyphExcell = pExcellon;
		m_pDProject = pProject;
		InitData(nLzs, nInputUnit);
		m_pUnit = new DUnit;

		m_pDuplexUnit = new DUnit;
		
		while (!feof(pFile))
		{
			fgets(chBuffer, BUFMAX, pFile);

			CString strTemp;
			strTemp.Format("%s",chBuffer);
			strTemp.TrimLeft();
			strTemp.TrimRight();
			int nCnt = strTemp.GetLength();
			if(nCnt > 80)
			{
				TRACE("Gerber Cnt %d \n",nCnt);
				continue;
			}
			

			token = strtok_s(chBuffer, " \t\r\n",&szNext);
			if (token == NULL)
				continue;
			for (char* szPos = token; *szPos != '*'; szPos++)
				*szPos = static_cast<char>(toupper(*szPos));
			ReadNums(token); // Write to buffer
		};
		fclose(pFile);
	}
	
	// 080818
	if(m_bOverlapXY)
	{
		//		::MessageDlg(STDGNALM510, MB_ICONSTOP);
		m_bOverlapXY = FALSE;
		
		delete m_pUnit;
		m_pUnit = NULL;

		delete m_pDuplexUnit;
		m_pDuplexUnit = NULL;
		
		return FALSE;
	}
	
	if(!m_bCorrectTool)
	{
		ErrMessage("Check the File Tool No. : 0 < Tool No. <27.");
		delete m_pUnit;
		m_pUnit = NULL;

		delete m_pDuplexUnit;
		m_pDuplexUnit = NULL;
		
		return FALSE;
	}
	if(!m_pGlyphExcell->IsValidTool(m_pUnit))
	{
		ErrMessage(IDS_ERR_TOOL_TYPE);
		
		delete m_pUnit;
		m_pUnit = NULL;

		delete m_pDuplexUnit;
		m_pDuplexUnit = NULL;
		
		return FALSE;
	}
	
	if(m_bUseDuplex)
		CopyDuplexData();

	
	m_pGlyphExcell->m_Units.AddTail(m_pUnit);
	gDUndoRedo.AddGlyphtoList(m_pUnit);
	gDUndoRedo.AddGlyph();
	
	m_pDProject->m_nMaxFidBlock = m_nFidBlock;
	
	if(m_pGlyphExcell->m_nMaxX < m_nMaxX)
		m_pGlyphExcell->m_nMaxX = m_nMaxX;
	if(m_pGlyphExcell->m_nMaxY < m_nMaxY)
		m_pGlyphExcell->m_nMaxY = m_nMaxY;
	if(m_pGlyphExcell->m_nMinX > m_nMinX)
		m_pGlyphExcell->m_nMinX = m_nMinX;
	if(m_pGlyphExcell->m_nMinY > m_nMinY)
		m_pGlyphExcell->m_nMinY = m_nMinY;
	
	m_pUnit = NULL;
	m_pDuplexUnit = NULL;
	
	m_pGlyphExcell->SortFiducial(DEFAULT_FID_INDEX);
	m_pGlyphExcell->SortFiducial(ADDED_FID_INDEX);
	
	return 0;

}
void GerberReader::CopyDuplexData()
{
	HOLEDATA* pHoleData, newDataHole;
	LINEDATA* pLineData;
	
	POSITION Holepos = m_pDuplexUnit->m_HoleData.GetHeadPosition();
	while(Holepos)
	{
		pHoleData = m_pDuplexUnit->m_HoleData.GetNext(Holepos);
		memcpy(&newDataHole, pHoleData, sizeof(HOLEDATA));
		m_pUnit->m_HoleData.AddTail(newDataHole);
	}
	
	POSITION LinePos = m_pDuplexUnit->m_LineData.GetHeadPosition();
	while(LinePos)
	{
		pLineData = m_pDuplexUnit->m_LineData.GetNext(LinePos);
		m_pUnit->m_LineData.AddTail(pLineData);	
	}	
}


void GerberReader::InitData(short nLzs, int nInputUnit)
{
	m_nLzs = nLzs;
	m_nInputUnit = nInputUnit;
	SetMetric();
	
	m_dDivide = m_dDivide * m_dMetric * METRIC_RATE;
	m_bReadStart	= TRUE;
	m_nNewTCode		= 1;
	m_nNewMCode		= 0;
	m_nLength		= 0;
	m_nToolCnt		= 0;
	
	m_bRepeat		= FALSE;
	m_bIsSwap		= FALSE;
	m_bStoreData	= FALSE;
	m_nMirrorX		= 1;
	m_nMirrorY		= 1;
	m_bIsRead		= FALSE;
	m_bSetFid		= FALSE;
	m_bSetFid2		= FALSE;
	
	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;

	m_bCycle	= FALSE;

	
	memset(m_nToolMatch, 0, sizeof(m_nToolMatch));
	m_listData.RemoveAll();
	m_listLineData.RemoveAll();
	m_RepeatlistData.RemoveAll();
	m_RepeatlistLineData.RemoveAll();

}

void GerberReader::SetMetric()
{
	if (m_nInputUnit != em1inch)
	{
		switch (m_nInputUnit)
		{

		case em01um		: m_dMetric = 0.1; break;
		case em1um		: m_dMetric = 1; break;
		case em10um		: m_dMetric = 10;  break;
		case em100um	: m_dMetric = 100;   break;
		case em1000um	: m_dMetric = 1000;    break;
		default			: m_dMetric = 1;	 break;

		} 
	}
	else
		m_dMetric = 25400;
}

void GerberReader::ReadNums(char *szBuffer)
{
	bool bSavePos = false, bSaveFid = false, bSaveMFid = false, bLine = false;
	CString str;
	BOOL bUse1 = FALSE, bUse2 = FALSE, bUse3 = FALSE, bUse4 = FALSE, bRRepeat = FALSE;
	m_bRepeatXFlip = m_bRepeatYFlip = m_bRepeatSwap = FALSE;
	double dParam1 = 0.0, dParam2 = 0.0, dParam3 = 0.0, dParam4 = 0.0;


	if(!GetParam(szBuffer, dParam1, dParam2, dParam3, dParam4, bUse1, bUse2, bUse3, bUse4))
		return;

	if(szBuffer[0] == 'X' || szBuffer[0] == 'Y' || szBuffer[0] == 'A' || szBuffer[0] == 'B' || (szBuffer[0] == 'G' && szBuffer[1] =='0' && szBuffer[2] == '1')) //data 
	{
		m_nStartX = m_nPositionX;
		m_nStartY = m_nPositionY;

		if(bUse1)
		{
			m_nPositionX = (int)( dParam1 * m_dMetric * METRIC_RATE );
			bSavePos = TRUE;
		}
		if(bUse2)
		{
			m_nPositionY = (int)( dParam2 * m_dMetric * METRIC_RATE );
			bSavePos = TRUE;
		}
		if(bUse3)
		{
			m_nStartX = m_nPositionX;
			m_nPositionX = (int)( dParam3 * m_dMetric * METRIC_RATE );
			bSavePos = TRUE;
			bLine = TRUE;
		}
		if(bUse4) 
		{
			m_nStartY = m_nPositionY;
			m_nPositionY = (int)( dParam4 * m_dMetric * METRIC_RATE );
			bSavePos = true;
			bLine = TRUE;
		}


		if(szBuffer[0] == 'A')
			bSaveFid = true;
		if(szBuffer[0] == 'B')
			bSaveMFid = true;
	}
	else if(szBuffer[0] == 'S' && szBuffer[1] == 'R') //Repeat 
	{
		if(bUse1)
		{
			m_nRRepeatX = (int)dParam1;
		}
		if(bUse2)
		{
			m_nRRepeatY = (int)dParam2;
		}
		if(bUse3)
		{
			m_nRDupliMX = (int)( dParam3 * m_dMetric * METRIC_RATE );
		}
		if(bUse4)
		{
			m_nRDupliMY = (int)( dParam4 * m_dMetric * METRIC_RATE );
		}

	}
	else if((szBuffer[1] == 'A' && szBuffer[2] =='D') ||  //tool 
		(szBuffer[0] == 'G' && szBuffer[1] == '5' && szBuffer[2] == '4' ))
	{
		if (bUse1 && dParam1 >= 0 && dParam1 < MAX_TOOL_NO - 1)
		{
			m_nNewTCode	= static_cast<byte>(dParam1);
			ReadTCode();
			if(dParam1 < 0 && dParam1 >= MAX_TOOL_NO - 1)
				m_bOverlapXY = TRUE;
		}
		if(bUse2)
		{
			m_nHoleSize = (int)( dParam2 * m_dMetric * METRIC_RATE );
			ReadCCode();
		}

	}
	else if(szBuffer[0] == 'M' && szBuffer[1] == 'I') //mirror 
	{
		if(bUse1)
		{
			if(dParam1 == 1)
				m_nMirrorX = -1;
			else
				m_nMirrorX = 1;
		}
		if(bUse2)
		{
			if(dParam2 == 1)
				m_nMirrorY = -1;
			else
				m_nMirrorY = 1;
		}
	}
	else if(szBuffer[0] == 'G' && szBuffer[1] == '7' && szBuffer[2] == '5')
	{
//		if(szBuffer[2] == '3') //cycle
 		{
 			m_nStartX = m_nPositionX;
 			m_nStartY = m_nPositionY;
 		}
	}
	else if(szBuffer[0] == 'G' && szBuffer[1] == '0' && (szBuffer[2] == '2' || szBuffer[2] == '3')) //��ϰ�� 
	{
 		CDPoint StartP, EndP, OffsetP;
		m_nStartX = m_nPositionX;
		m_nStartY = m_nPositionY;
		if(bUse1) // x 
		{
			m_nPositionX = (int)( dParam1 * m_dMetric * METRIC_RATE );
		}
		if(bUse2) //y 
		{
			m_nPositionY = (int)( dParam2 * m_dMetric * METRIC_RATE );
		}
		if(bUse3) //offset X
		{
			OffsetP.x = (int)( dParam3 * m_dMetric * METRIC_RATE );
		}
		if(bUse4) //offset Y 
		{
			OffsetP.y = (int)( dParam4 * m_dMetric * METRIC_RATE );
		}
// 		if(szBuffer[2] == '3') //cycle
// 		{
// 			m_nStartX = m_nPositionX;
// 			m_nStartY = m_nPositionY;
// 		}
		StartP.x = m_nStartX;
		StartP.y = m_nStartY;
		EndP.x = m_nPositionX;
		EndP.y = m_nPositionY;
		CalCurvLine(StartP, EndP, OffsetP);
		return ;
	}
	if (m_bRepeat == FALSE)
	{
		m_nDupliMovX = 0;
		m_nDupliMovY = 0;
	}

	if (m_bRepeat == TRUE && bSavePos == TRUE) //�ݺ� ������ ���� 
	{

		if (m_nPositionX != 0.0 || m_nPositionY != 0.0)
		{
			for(int i = 0; i < m_nRRepeatX; i++)
			{
				for(int j = 0 ; j < m_nRRepeatY; j++)
				{
					m_nDupliMovX	= m_nRDupliMX * i;
					m_nDupliMovY	= m_nRDupliMY * j;
					
					ToolComparison();
					if(bLine)
//						CalLine();
						ReadLine(); 
					else
					{
						if(m_strOldDCmd != "D02")
							ReadPosition();
						else
						{
							break; break;
						}
					}
				} 
			} 
			ToolRestore();
		}			
	}
	else if (bSavePos == TRUE && bSaveFid == FALSE && bSaveMFid == FALSE) //�ݺ� No, Data ���� 
	{
		ToolComparison();
		if(bLine)
//			CalLine();
			ReadLine();
		else
		{
			if(m_strOldDCmd != "D02")
				ReadPosition();
		}
		ToolRestore();
	}
	//Fiducial 
	if(m_bRepeat && (bSaveFid || bSaveMFid))
	{
		for(int i = 0; i < m_nRRepeatX; i++)
		{
			for(int j = 0; j < m_nRRepeatY; j++)
			{
				m_nPositionX	+= m_nRDupliMX * i;
				m_nPositionY	+= m_nRDupliMY * j;

				if (bSaveFid == TRUE)
					ReadFiducial(DEFAULT_FID_INDEX);
				
				if(bSaveMFid == TRUE)
					ReadFiducial(ADDED_FID_INDEX);
			}
		}
	}
	else if(!m_bRepeat && (bSaveFid || bSaveMFid))
	{
		if (bSaveFid == true)
			ReadFiducial(DEFAULT_FID_INDEX);
		
		if(bSaveMFid == true)
			ReadFiducial(ADDED_FID_INDEX);
	}
}

void GerberReader::ReadFiducial(int nFidKind)
{
	if(m_nFidBlock == -1)
		m_nFidBlock++;
	int nFidNo = m_pGlyphExcell->m_FiducialData[nFidKind].m_PositionData.GetCount();
	if (IsFiducialMarkExist(m_nPositionX, m_nPositionY))
		return;
	
	LPFIDDATA pFidData = new FID_DATA;
	memset(pFidData, 0, sizeof(FID_DATA));
	if (m_nNewMCode != 30)
	{
		pFidData->npPosition.x = m_nPositionX;
		pFidData->npPosition.y = m_nPositionY;
		pFidData->cType = FID_FILE_USE;
		pFidData->nFindIndex = nFidNo;
		pFidData->nFidBlock = m_nFidBlock;
		pFidData->bSelected = FALSE;
		pFidData->dOffsetZ = 0;
		pFidData->bCheckScaleLimit = TRUE;

		if(nFidKind == DEFAULT_FID_INDEX)
			pFidData->nFidType = FID_PRIMARY + FID_FIND;	
		else
		{
			pFidData->nFidType = FID_SECONDARY + FID_DRILL;
			pFidData->nToolNo = 0;
		}

		if(m_pDProject->m_bSaveRefFidData)
		{
			pFidData->nCam = m_pDProject->m_pRefFidData->nCam;
			pFidData->dOffsetZ = m_pDProject->m_pRefFidData->dOffsetZ;
//			pFidData->nFidType = m_pDProject->m_pRefFidData->nFidType;
			if(nFidKind == DEFAULT_FID_INDEX)
				pFidData->nToolNo = m_pDProject->m_pRefFidData->nToolNo;
			pFidData->sVisInfo.dAspectRatio = m_pDProject->m_pRefFidData->sVisInfo.dAspectRatio;
			pFidData->sVisInfo.dScoreAngle = m_pDProject->m_pRefFidData->sVisInfo.dScoreAngle;
			pFidData->sVisInfo.dScoreSize = m_pDProject->m_pRefFidData->sVisInfo.dScoreSize;
			pFidData->sVisInfo.dSizeA = m_pDProject->m_pRefFidData->sVisInfo.dSizeA;
			pFidData->sVisInfo.dSizeB = m_pDProject->m_pRefFidData->sVisInfo.dSizeB;
			pFidData->sVisInfo.dSizeC = m_pDProject->m_pRefFidData->sVisInfo.dSizeC;
			pFidData->sVisInfo.nModelType = m_pDProject->m_pRefFidData->sVisInfo.nModelType;
			pFidData->sVisInfo.nPolarity = m_pDProject->m_pRefFidData->sVisInfo.nPolarity;

			for(int i=0; i<4; i++)
			{
				pFidData->sVisInfo.dBrightness[i] = m_pDProject->m_pRefFidData->sVisInfo.dBrightness[i];
				pFidData->sVisInfo.dContrast[i] = m_pDProject->m_pRefFidData->sVisInfo.dContrast[i];
				pFidData->sVisInfo.nCoaxial[i] = m_pDProject->m_pRefFidData->sVisInfo.nCoaxial[i];
				pFidData->sVisInfo.nRing[i] = m_pDProject->m_pRefFidData->sVisInfo.nRing[i];
				pFidData->sVisInfo.nIR[i] = m_pDProject->m_pRefFidData->sVisInfo.nIR[i];
			}
		}
		else
		{
			
			// FID_PRIMARY : Primary ������, FID_SECONDARY : Secondary ������,
			// FID_FIND : Ž���� ������, FID_DRILL : ������ ������,
			// FID_VERIFY : ��ġ������ ������,

			pFidData->sVisInfo.dAspectRatio = 10;
			pFidData->sVisInfo.dScoreAngle = 10;
			pFidData->sVisInfo.dScoreSize = 10;
			pFidData->sVisInfo.dSizeA = 0.5;
			pFidData->sVisInfo.dSizeB = 0;
			pFidData->sVisInfo.dSizeC = 0;
			pFidData->sVisInfo.nModelType = 1;
			pFidData->sVisInfo.nPolarity = 0;

			for(int i=0; i<4; i++)
			{
				pFidData->sVisInfo.dBrightness[i] = 0.5;
				pFidData->sVisInfo.dContrast[i] = 0.5;
				pFidData->sVisInfo.nCoaxial[i] = 0;
				pFidData->sVisInfo.nRing[i] = 255;
				pFidData->sVisInfo.nIR[i] = 0;
			}
		}
		m_pGlyphExcell->m_FiducialData[nFidKind].AddFidData(pFidData);
	}
	
	if(nFidKind == DEFAULT_FID_INDEX)
	{
		if (m_bSetFid == FALSE && m_bSetFid2 == FALSE)
		{
			m_nMinX = m_nPositionX;
			m_nMinY = m_nPositionY;
			m_nMaxX = m_nPositionX;
			m_nMaxY = m_nPositionY;
			m_bSetFid = TRUE;
		}
		else
		{
			if (m_nPositionX > m_nMaxX)
				m_nMaxX = m_nPositionX;
			
			if (m_nPositionX < m_nMinX)
				m_nMinX = m_nPositionX;
			
			if (m_nPositionY > m_nMaxY)
				m_nMaxY = m_nPositionY;
			
			if (m_nPositionY < m_nMinY)
				m_nMinY = m_nPositionY;
		}
		
		if (m_nNewMCode == 30)
			m_bSetFid = TRUE;
	}
	else
	{
		if (m_bSetFid == FALSE && m_bSetFid2 == FALSE)
		{
			m_nMinX = m_nPositionX;
			m_nMinY = m_nPositionY;
			m_nMaxX = m_nPositionX;
			m_nMaxY = m_nPositionY;
			m_bSetFid2 = TRUE;
		}
		else
		{
			if (m_nPositionX > m_nMaxX)
				m_nMaxX = m_nPositionX;
			
			if (m_nPositionX < m_nMinX)
				m_nMinX = m_nPositionX;
			
			if (m_nPositionY > m_nMaxY)
				m_nMaxY = m_nPositionY;
			
			if (m_nPositionY < m_nMinY)
				m_nMinY = m_nPositionY;
		}
		
		if (m_nNewMCode == 30)
			m_bSetFid2 = TRUE;
		
#ifndef __FIND_SKIVING_AS_ROTATE_INFO
		m_pDProject->m_pToolCode[0]->m_bUseTool = TRUE;
		m_pDProject->m_pToolCode[0]->m_nToolColor = 0;
#endif
	}
}

BOOL GerberReader::IsFiducialMarkExist(double dX, double dY)
{
	if (m_pGlyphExcell->m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetCount() == 0)
		return FALSE;
	LPFIDDATA pFidData;
	POSITION pos = m_pGlyphExcell->m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_pGlyphExcell->m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		if (dX == pFidData->npPosition.x && 
			dY == pFidData->npPosition.y)
			return TRUE;
	}
	return FALSE;
}
//data�� ���� 
BOOL GerberReader::GetParam(char *szBuffer, double &dParam1, double &dParam2, double &dParam3, double &dParam4, BOOL &bUse1, BOOL &bUse2, BOOL &bUse3, BOOL &bUse4)
{
	memset(m_szData, 0, sizeof(m_szData));
	int nCount =0;
	int nTotalLen = strlen(szBuffer);
	char szCmd[3]={0,};
	CString strBuffer, strDCmd;
	strBuffer.Format(_T("%s"),szBuffer);

	if(szBuffer[0] == 'A' || szBuffer[0] == 'B')  // Fiducial AX#Y#
	{
		int i = 0;
		for(i = 0; i <nTotalLen-1; i++ )
			m_szData[i] = szBuffer[i+1];
		m_szData[i] = '\0';
		if(GetXYPos(m_szData, dParam1, dParam2, bUse1, bUse2))
			return TRUE;
		else
			return FALSE;
	}
	else if(szBuffer[0] == '%' ) 
	{
		szCmd[0] = szBuffer[1];
		szCmd[1] = szBuffer[2];	
		if(strncmp(szCmd,"AD",2) == 0) // ������ 
		{
			bUse1 = TRUE;
			nCount = 0;	
		
			CString strData = szBuffer;
			int nIndex = strData.Find("ADD");
			strData  = strData.Mid(nIndex+3);
			char szData[256];
			memset(szData,0,sizeof(szData));
			strcpy(szData, strData);
			for(int j = 0; j< nTotalLen; j++)
			{
				if(szData[j] >= '0' && szData[j] <= '9')
					m_szData[nCount++] = szData[j];
				else 
					break;

			}
			m_szData[nCount] = '\0';
			dParam1 = atoi(m_szData); //����ȣ 
		
			m_nToolMatch[m_nToolCnt][0] = m_nToolCnt+1;
			m_nToolMatch[m_nToolCnt][1] = (int)dParam1;
			dParam1 = m_nToolCnt+1;
			m_nToolCnt++;
			for(int i = 0; i <nTotalLen; i++)
			{
				if(szBuffer[i] == ',')
				{
					nCount = 0;
					for(int k = i+1; k<nTotalLen; k++ )
					{
						if((szBuffer[k] >= '0' &&  szBuffer[k] <= '9') || szBuffer[k] == '.')
							m_szData[nCount++] = szBuffer[k];
						else
							break;
					}
					m_szData[nCount] = '\0';
					dParam2 = atof(m_szData) * 1000.0; //um, inch
					bUse2 = TRUE;
					return TRUE;
				}
			}
		}
		else
			return FALSE;

	}

	else if(szBuffer[0] == 'G')  //G �ڵ� 
	{
		szCmd[0] = szBuffer[1];
		szCmd[1] = szBuffer[2];

		if(strncmp(szCmd, "01", 2) == 0) //���� 
		{
			int i = 0;
			m_bCycle = FALSE;
			nCount = 0;
			for(i = 0; i <nTotalLen-1; i++ )
			{
				if(szBuffer[i] == '*')
					break;
				if(i>2)
					m_szData[i-3] = szBuffer[i];
			}			
			m_szData[i] = '\0';
			
			strDCmd = strBuffer.Right(4).Left(3);
			if(strDCmd[0] != 'D') //cmd ���� 
				strDCmd = m_strOldDCmd;
			
			if(strDCmd == "D03") //shot�� �ƴϸ�
			{
				GetXYPos(m_szData, dParam1, dParam2, bUse1, bUse2);		
				m_strOldDCmd = strDCmd;
				
			}
			else if(strDCmd == "D02") //move command 
			{
				GetXYPos(m_szData, dParam1, dParam2, bUse1, bUse2);
				m_strOldDCmd = strDCmd;
				if(bUse1)
					m_dStartPos.x = dParam1;
				if(bUse2)
					m_dStartPos.y = dParam2;
			}
			else if(strDCmd == "D01") 
			{
				bUse1 = TRUE;
				bUse2 = TRUE;
				dParam1 = m_dStartPos.x;
				dParam2 = m_dStartPos.y;
				GetXYPos(m_szData, dParam3, dParam4, bUse3, bUse4);
				
				if(bUse3)
					m_dStartPos.x = dParam3;
				if(bUse4)
					m_dStartPos.y = dParam4;
				m_strOldDCmd = strDCmd;
			}
			else 
				return FALSE;

			return TRUE;
		}
		else if (strncmp(szCmd, "02", 2) == 0 || strncmp(szCmd, "03" ,2) == 0) // � 
		{
			if(strncmp(szCmd, "02",2) == 0)
				m_bCW = TRUE;
			else
				m_bCW = FALSE;

			nCount = 0;
			strDCmd = strBuffer.Right(4).Left(3);
			m_strOldDCmd = strDCmd;
			for(int i = 3; i < nTotalLen; i++)
			{
				if(szBuffer[i] == 'I' || szBuffer[i] == 'J' || szBuffer[i] == 'D') //XY���� ���� 
					break;
				m_szData[nCount++] = szBuffer[i];
			}
			m_szData[nCount] = '\0';
			GetXYPos(m_szData, dParam1, dParam2, bUse1, bUse2);
			if(bUse1)
				m_dStartPos.x = dParam1;
			if(bUse2)
				m_dStartPos.y = dParam2;

			for(int j = nCount+1; j<nTotalLen; j++)
			{
				if(szBuffer[j] == 'I')
				{
					nCount = 0;
					for(int k = j+1; k < nTotalLen; k++)
					{
						if(szBuffer[k] >= '0' && szBuffer[k] <= '9' ||  szBuffer[k] == '.' || szBuffer[k] == '-')
							m_szData[nCount++] = szBuffer[k];
						else
							break;
					}
					m_szData[nCount] = '\0';
					bUse3 = TRUE;
					dParam3 = atof(m_szData);
				}

				if(szBuffer[j] == 'J')
				{
					nCount = 0;
					for(int k = j+1; k < nTotalLen; k++)
					{
						if(szBuffer[k] >= '0' && szBuffer[k] <= '9' ||  szBuffer[k] == '.' || szBuffer[k] == '-')
							m_szData[nCount++] = szBuffer[k];
						else
							break;
					}
					m_szData[nCount] = '\0';
					bUse4 = TRUE;
					dParam4 = atof(m_szData);
				}
			}

		}
		else if (strncmp(szCmd, "54", 2) == 0) // ������ 
		{
			nCount = 0; 
			bUse1 = TRUE;
			for(int i= 0; i<nTotalLen; i++)
			{
				if(szBuffer[i] == 'D')
				{
					for(int k = i+1; k<nTotalLen; k++)
					{
						if(szBuffer[k]>='0' && szBuffer[k] <='9')
							m_szData[nCount++] = szBuffer[k];
						else 
							break;
					}
					m_szData[nCount] = '\0';
					int nTool = atoi(m_szData);
					for(int j =0; j<MAX_TOOL_NO-1; j++)
					{
						if(m_nToolMatch[j][1] == nTool)
						{
							dParam1 = m_nToolMatch[j][0];
							m_nCurrentTool = m_nToolMatch[j][0];
							break;
						}
					}
					if(dParam1>0)
						return TRUE;
					else
						return FALSE;
				}
			}
		}
		else if(strncmp(szCmd, "75", 2) == 0) //�� �׸���  
			m_bCycle = TRUE;
		else if(strncmp(szCmd, "74", 2) == 0)
			m_bCycle = FALSE;
	}
	else if(szBuffer[0] == 'X' || szBuffer[0] == 'Y')// ||  // X Y Position �̰ų� 
	{		
		int i=0;
		for(i = 0; i <nTotalLen-1; i++ )
		{
			if(szBuffer[i] == '*')
				break;
			m_szData[i] = szBuffer[i];
		}			
		m_szData[i] = '\0';
		
		strDCmd = strBuffer.Right(4).Left(3);
		if(strDCmd[0] != 'D') //cmd ���� 
			strDCmd = m_strOldDCmd;
		
		FirstToolType(strDCmd);
		if(strDCmd == "D03") //shot�� �ƴϸ�
		{
			GetXYPos(m_szData, dParam1, dParam2, bUse1, bUse2);		
			m_strOldDCmd = strDCmd;
			m_nCurrentToolType = 2;
			
		}
		else if(strDCmd == "D02") //move command 
		{
			GetXYPos(m_szData, dParam1, dParam2, bUse1, bUse2);
			m_strOldDCmd = strDCmd;
			if(bUse1)
				m_dStartPos.x = dParam1;
			if(bUse2)
				m_dStartPos.y = dParam2;
			m_nCurrentToolType = 1;
		}
		else if(strDCmd == "D01") 
		{
			bUse1 = TRUE;
			bUse2 = TRUE;
			dParam1 = m_dStartPos.x;
			dParam2 = m_dStartPos.y;
			GetXYPos(m_szData, dParam3, dParam4, bUse3, bUse4);
			
			if(bUse3)
				m_dStartPos.x = dParam3;
			if(bUse4)
				m_dStartPos.y = dParam4;
			m_strOldDCmd = strDCmd;
			m_nCurrentToolType = 1;
		}
		else
			return FALSE;	
		
	}
	else if(szBuffer[0] == 'S' && szBuffer[1] == 'R') //Repeat (excellon->m02)
	{
		for(int i = 2; i<nTotalLen; i++)
		{
			if(szBuffer[i] == 'X') 
			{
				nCount = 0;
				for(int k = i+1; k<nTotalLen; k++)
				{
					if(szBuffer[k] >= '0' && szBuffer[k] <= '9')
						m_szData[nCount++] = szBuffer[k];
					else 
						break;
				}
				m_szData[nCount] = '\0';
				bUse1 = TRUE; 
				dParam1 = atoi(m_szData); //x ������ �ݺ�Ƚ�� 
			}
			if(szBuffer[i] == 'Y') 
			{
				nCount = 0;
				for(int k = i+1; k<nTotalLen; k++)
				{
					if(szBuffer[k] >= '0' && szBuffer[k] <= '9')
						m_szData[nCount++] = szBuffer[k];
					else 
						break;
				}
				m_szData[nCount] = '\0';
				bUse2 = TRUE; 
				dParam2 = atoi(m_szData); //y ������ �ݺ�Ƚ�� 
			}
			if(szBuffer[i] == 'I') 
			{
				nCount = 0;
				for(int k = i+1; k<nTotalLen; k++)
				{
					if(szBuffer[k] >= '0' && szBuffer[k] <= '9' ||  szBuffer[k] == '.' || szBuffer[k] == '-')
						m_szData[nCount++] = szBuffer[k];
					else 
						break;
				}
				m_szData[nCount] = '\0';
				bUse3 = TRUE; 
				dParam3 = atof(m_szData); //x�� Offset
			}
			if(szBuffer[i] == 'J') 
			{
				nCount = 0;
				for(int k = i+1; k<nTotalLen; k++)
				{
					if(szBuffer[k] >= '0' && szBuffer[k] <= '9' ||  szBuffer[k] == '.' || szBuffer[k] == '-')
						m_szData[nCount++] = szBuffer[k];
					else 
						break;
				}
				m_szData[nCount] = '\0';
				bUse4 = TRUE; 
				dParam4 = atof(m_szData); //y�� Offset
			}
		}

		if(dParam1 == 1 && dParam2 == 1)
			m_bRepeat = FALSE;
		else
			m_bRepeat = TRUE;
		
	}
	else if(szBuffer[0] == 'M' && szBuffer[1] == 'I') //mirror 
	{
		for(int i = 1; i<nTotalLen; i++)
		{
			if(szBuffer[i] == 'A')
			{
				memset(m_szData, 0, sizeof(m_szData));
				m_szData[0] = szBuffer[i+1];
				bUse1 = TRUE;
				dParam1 = atoi(m_szData);
			}
			
			if(szBuffer[i] == 'B')
			{
				memset(m_szData, 0, sizeof(m_szData));
				m_szData[0] = szBuffer[i+1];
				bUse2 = TRUE;
				dParam2 = atoi(m_szData);
			}
		}
	}

	return TRUE;
}

int GerberReader::GetXYPos(char *szBuffer, double &dParam1, double &dParam2, BOOL &bUse1, BOOL &bUse2)
{
	char	m_TempData[BUFMAX];
	int nTotalLen = strlen(szBuffer);
	if(szBuffer[0] == 'X')
	{
		if(szBuffer[1] == 'Y')
		{
			int i = 0;
			int nCount = 0;
			BOOL bStart = FALSE;
			for(i = 2; i < nTotalLen; i++)
			{
				if((szBuffer[i] >= '0' && szBuffer[i] <= '9') || szBuffer[i] == '-' || szBuffer[i] == '.')
				{
					bStart = TRUE;
					m_TempData[nCount++] = szBuffer[i];
				}
				else if (szBuffer[i] == ' ')
				{
					if(bStart)
						break;
				}
				else
					break;
			}
			m_TempData[nCount] = '\0';
			
			if(bStart == FALSE)
				return FALSE;
			bUse1 = FALSE;
			bUse2 = TRUE;

			if (m_TempData[0] == '-')
				nCount = nCount - 1;
			IsTzs(nCount);
			dParam2 = atof(m_TempData) * m_lTzsLzs;
			return i;
		}
		else
		{
			int i =0;
			int nCount = 0;
			BOOL bStart = FALSE;
			for(i = 1; i < nTotalLen; i++)
			{
				if((szBuffer[i] >= '0' && szBuffer[i] <= '9') || szBuffer[i] == '-' || szBuffer[i] == '.')
				{
					bStart = TRUE;
					m_TempData[nCount++] = szBuffer[i];
				}
				else if (szBuffer[i] == ' ')
				{
					if(bStart)
						break;
				}
				else
					break;
			}
			m_TempData[nCount] = '\0';
			
			if(bStart == FALSE)
			{
				bUse1 = FALSE;
			}
			else
			{
				bUse1 = TRUE;
				if (m_TempData[0] == '-')
					nCount = nCount - 1;
				IsTzs(nCount);
				dParam1 = atof(m_TempData) * m_lTzsLzs;
			}
			
			BOOL bY = FALSE;
			bStart = FALSE;
			nCount = 0;
			for(i; i < nTotalLen; i++)
			{
				if(bY)
				{
					if((szBuffer[i] >= '0' && szBuffer[i] <= '9') || szBuffer[i] == '-' || szBuffer[i] == '.')
					{
						bStart = TRUE;
						m_TempData[nCount++] = szBuffer[i];
					}
					else if (szBuffer[i] == ' ')
					{
						if(bStart)
							break;
					}
					else if(szBuffer[i] == 'X' || szBuffer[i] == 'Y')
					{
						m_bOverlapXY = TRUE;
						break;
					}
					else
						break;
				}

				if(szBuffer[i] == 'X')
				{
					m_bOverlapXY = TRUE;
					break;
				}

				if(szBuffer[i] == 'Y')
				{
					bY = TRUE;
				}				
			}
			m_TempData[nCount] = '\0';

			if(bY && bStart)
			{
				bUse2 = TRUE;
				if (m_TempData[0] == '-')
					nCount = nCount - 1;
				IsTzs(nCount);
				dParam2 = atof(m_TempData) * m_lTzsLzs;
			}
			else
				bUse2 = FALSE;

			if(bUse1 || bUse2)
				return i;
			else
				return FALSE;
		}
	}
	else if(szBuffer[0] == 'Y') //y���� ���� 
	{
		int i = 0;
		int nCount = 0;
		BOOL bStart = FALSE;
		for(i = 1; i < nTotalLen; i++)
		{
			if((szBuffer[i] >= '0' && szBuffer[i] <= '9') || szBuffer[i] == '-' || szBuffer[i] == '.')
			{
				bStart = TRUE;
				m_TempData[nCount++] = szBuffer[i];
			}
			else if (szBuffer[i] == ' ')
			{
				if(bStart)
					break;
			}
			else if(szBuffer[i] == 'X' || szBuffer[i] == 'Y')
			{
				m_bOverlapXY = TRUE;
				break;
			}
			else
				break;
		}
		m_TempData[nCount] = '\0';
		
		if(bStart == FALSE)
			return FALSE;
		bUse1 = FALSE;
		bUse2 = TRUE;
		if (m_TempData[0] == '-')
			nCount = nCount - 1;
		IsTzs(nCount);
		dParam2 = atof(m_TempData) * m_lTzsLzs;
		return i;
	}
	else
		return FALSE;
}

BOOL GerberReader::ReadDuplicatePos()
{
	
	if (!m_listData.IsEmpty() || !m_listLineData.IsEmpty())
	{
		POSITION pos = m_listData.GetHeadPosition();
		while (pos != NULL)
		{
			HOLEDATA drData = m_listData.GetNext(pos);
			m_nNewTCode = drData.nToolNo;
			m_nPositionX = drData.npPos.x;
			m_nPositionY = drData.npPos.y;
			ReadPosition();
		}
		
		pos = m_listLineData.GetHeadPosition();
		while (pos != NULL)
		{
			LINEDATA drLine = m_listLineData.GetNext(pos);
			m_nNewTCode = drLine.nToolNo;
			m_nStartX = drLine.npStartPos.x;
			m_nStartY = drLine.npStartPos.y;
			m_nPositionX = drLine.npEndPos.x;
			m_nPositionY = drLine.npEndPos.y;
//			CalLine();
			ReadLine();
		}
		
		return TRUE;
	}
	else
		return FALSE;
}

void GerberReader::ReadPosition()
{
	CString strPos;
	HOLEDATA HoleData;
	if (m_nNewMCode != 30)
	{
		if (m_nNewTCode < 0 || m_nNewTCode >= MAX_TOOL_NO - 1)
			return;
		
		//		if (m_pExcellon != NULL)
		{
			int nX, nY;
			if (m_bIsSwap == false)
			{
				nX = m_nMirrorX * m_nPositionX + m_nDupliMovX;
				nY = m_nMirrorY * m_nPositionY + m_nDupliMovY;
			}
			else
			{
				nX = m_nMirrorY * m_nPositionY + m_nDupliMovX;
				nY = m_nMirrorX * m_nPositionX + m_nDupliMovY;
			}
			
			if(m_nNewTCode <= 0 || m_nNewTCode > MAX_TOOL_NO)
				m_bCorrectTool = FALSE;

			HoleData.npPos.x = nX;
			HoleData.npPos.y = nY;
			HoleData.nToolNo = (int)m_nNewTCode;
			HoleData.nFidBlock = m_nFidBlock;
			HoleData.nBlockName2= 0;
			HoleData.cIsPattern= 0;
//			memset(HoleData.chContents, 0, sizeof(HoleData.chContents));
			m_pUnit->m_HoleData.AddTail(HoleData);
			m_listData.AddTail(HoleData);

			if(m_bStoreData)
			{
				HOLEDATA drData;
				drData.npPos.x = nX;
				drData.npPos.y = nY;
				drData.nToolNo = (int)m_nNewTCode;
				m_RepeatlistData.AddTail(drData);
			}
			if(nX > m_nMaxX)
				m_nMaxX = nX;
			if(nX < m_nMinX)
				m_nMinX = nX;	
			if(nY > m_nMaxY)
				m_nMaxY = nY;
			if(nY < m_nMinY)
				m_nMinY = nY;
			
			if(nX > m_pUnit->m_nMaxX)
				m_pUnit->m_nMaxX = nX;
			if(nX < m_pUnit->m_nMinX)
				m_pUnit->m_nMinX = nX;	
			if(nY > m_pUnit->m_nMaxY)
				m_pUnit->m_nMaxY = nY;
			if(nY < m_pUnit->m_nMinY)
				m_pUnit->m_nMinY = nY;


			// 20120423 duplex �ڵ�
			if(m_bUseDuplex == TRUE)
			{
//				int nDuplexX, nDuplexY;
				HOLEDATA DuplexHoleData;
				//	pDuplexHoleData = pHoleData;
				DuplexHoleData.npPos.x = (long)( HoleData.npPos.x + m_dDuplexLenX );
				DuplexHoleData.npPos.y = HoleData.npPos.y;
				DuplexHoleData.nToolNo = (int)m_nNewTCode;
				DuplexHoleData.nFidBlock = m_nFidBlock;
				DuplexHoleData.nBlockName2= 0;
				DuplexHoleData.cIsPattern= 0;
				m_pDuplexUnit->m_HoleData.AddTail(DuplexHoleData);
				
				if(DuplexHoleData.npPos.x > m_nMaxX)
					m_nMaxX = DuplexHoleData.npPos.x;
				if(DuplexHoleData.npPos.x < m_nMinX)
					m_nMinX = DuplexHoleData.npPos.x;
				
				if(DuplexHoleData.npPos.x > m_pUnit->m_nMaxX)
					m_pUnit->m_nMaxX = DuplexHoleData.npPos.x;
				if(DuplexHoleData.npPos.x < m_pUnit->m_nMinX)
					m_pUnit->m_nMinX = DuplexHoleData.npPos.x;
			}

		}
	}
}
int GerberReader::GetRepeatAxisInfo(char *szBuffer)
{
	char	m_TempData[BUFMAX];
	int nTotalLen = strlen(szBuffer);
	int j = 0;
	
	for(int i = 0; i < nTotalLen; i++)
	{
		if(szBuffer[i] == 'M')
		{
			int nCount = 0;
			BOOL bStart = FALSE;
			for( j = i+1; j < nTotalLen; j++ )
			{
				if((szBuffer[j] >= '0' && szBuffer[j] <= '9'))
				{
					bStart = TRUE;
					m_TempData[nCount++] = szBuffer[j];
				}
				else if (szBuffer[j] == ' ')
				{
					if(bStart)
						break;
				}
				else
					break;
			}
			m_TempData[nCount] = '\0';
			
			if(bStart == FALSE)
				return TRUE;
			
			int nVal = atoi(m_TempData);
			if(nVal == 70) 
				m_bRepeatSwap = TRUE;
			else if(nVal == 80)
				m_bRepeatXFlip = TRUE;
			else if(nVal == 90)
				m_bRepeatYFlip = TRUE;
			else
			{
				
			}
			i = j - 1;
		}
	}
	return TRUE;
}

void GerberReader::IsTzs(int nCount)
{
	if (m_nLzs == emTZS)
	{
		m_lTzsLzs = 1;
	}
	else
	{
		switch (nCount)
		{
		case 1 : m_lTzsLzs = 100000; break;
		case 2 : m_lTzsLzs = 10000;  break;
		case 3 : m_lTzsLzs = 1000;   break;
		case 4 : m_lTzsLzs = 100;    break;
		case 5 : m_lTzsLzs = 10;     break;
		case 6 : m_lTzsLzs = 1;      break;
		default : m_lTzsLzs = 1;	 break;
		} 
	}
}

void GerberReader::ReadTCode()
{
	if (m_pDProject)
	{
		if(m_nNewTCode <= 0 || m_nNewTCode > MAX_TOOL_NO)
			return;
		m_pDProject->m_pToolCode[m_nNewTCode]->m_bUseTool = TRUE;
		m_pDProject->m_pToolCode[m_nNewTCode]->m_nToolColor = m_nNewTCode;
	}
}

void GerberReader::ReadLine()
{
	CString strPos;
	LINEDATA* pLineData;
	if (m_nNewMCode != 30)
	{
		if (m_nNewTCode < 0 || m_nNewTCode >= MAX_TOOL_NO - 1)
			return;
		
		//		if (m_pExcellon != NULL)
		{
			int nX, nY, nEndX, nEndY;
			if (m_bIsSwap == false)
			{
				nX = m_nMirrorX * m_nStartX + m_nDupliMovX;
				nY = m_nMirrorY * m_nStartY + m_nDupliMovY;
				nEndX = m_nMirrorX * m_nPositionX + m_nDupliMovX;
				nEndY = m_nMirrorY * m_nPositionY + m_nDupliMovY;
			}
			else
			{
				nX = m_nMirrorY * m_nStartY + m_nDupliMovY;
				nY = m_nMirrorX * m_nStartX + m_nDupliMovX;
				nEndX = m_nMirrorY * m_nPositionY + m_nDupliMovX;
				nEndY = m_nMirrorX * m_nPositionX + m_nDupliMovY;
			}
			if( nX == nEndX && nY == nEndY )
				return;
			
			if(m_nNewTCode <= 0 || m_nNewTCode > MAX_TOOL_NO)
				m_bCorrectTool = FALSE;
			pLineData = new LINEDATA;
			pLineData->npStartPos.x = nX;
			pLineData->npStartPos.y = nY;
			pLineData->npEndPos.x = nEndX;
			pLineData->npEndPos.y = nEndY;
			pLineData->nToolNo = (int)m_nNewTCode;
			pLineData->nRefNo = 1;
			pLineData->nFidBlock = m_nFidBlock;	
			m_pUnit->m_LineData.AddTail(pLineData);
			m_listLineData.AddTail(*pLineData); 

	
			if(m_bStoreData)
			{
				LINEDATA drData;
				drData.npStartPos.x = nX;
				drData.npStartPos.y = nY;
				drData.npEndPos.x = nEndX;
				drData.npEndPos.y = nEndY;
				drData.nToolNo = (int)m_nNewTCode;
				drData.nFidBlock = m_nFidBlock;
				m_RepeatlistLineData.AddTail(drData);
			}
			if(nX > m_nMaxX)
				m_nMaxX = nX;
			if(nX < m_nMinX)
				m_nMinX = nX;	
			if(nY > m_nMaxY)
				m_nMaxY = nY;
			if(nY < m_nMinY)
				m_nMinY = nY;
			
			if(nEndX > m_nMaxX)
				m_nMaxX = nEndX;
			if(nEndX < m_nMinX)
				m_nMinX = nEndX;	
			if(nEndY > m_nMaxY)
				m_nMaxY = nEndY;
			if(nEndY < m_nMinY)
				m_nMinY = nEndY;
			
			if(nX > m_pUnit->m_nMaxX)
				m_pUnit->m_nMaxX = nX;
			if(nX < m_pUnit->m_nMinX)
				m_pUnit->m_nMinX = nX;	
			if(nY > m_pUnit->m_nMaxY)
				m_pUnit->m_nMaxY = nY;
			if(nY < m_pUnit->m_nMinY)
				m_pUnit->m_nMinY = nY;
			
			if(nEndX > m_pUnit->m_nMaxX)
				m_pUnit->m_nMaxX = nEndX;
			if(nEndX < m_pUnit->m_nMinX)
				m_pUnit->m_nMinX = nEndX;	
			if(nEndY > m_pUnit->m_nMaxY)
				m_pUnit->m_nMaxY = nEndY;
			if(nEndY < m_pUnit->m_nMinY)
				m_pUnit->m_nMinY = nEndY;


			if(m_bUseDuplex == TRUE)
			{
//				int nDuplexX, nDuplexY, nDuplexEndX, nDuplexEndY;
				LINEDATA* pDuplexLineData;
				pDuplexLineData = new LINEDATA;
				
				//	pDuplexLineData = pLineData;
				
				pDuplexLineData->npStartPos.x = (long)( pLineData->npStartPos.x + m_dDuplexLenX );
				pDuplexLineData->npEndPos.x = (long)( pLineData->npEndPos.x +m_dDuplexLenX );
				
				
				pDuplexLineData->npStartPos.x = (long)( pLineData->npStartPos.x + m_dDuplexLenX );
				pDuplexLineData->npStartPos.y = (long)( pLineData->npStartPos.y );
				pDuplexLineData->npEndPos.x = (long)( pLineData->npEndPos.x +m_dDuplexLenX );
				pDuplexLineData->npEndPos.y = (long)pLineData->npEndPos.y;
				pDuplexLineData->nToolNo = (int)m_nNewTCode;
				//			pLineData->bSelect = FALSE;
				pLineData->nRefNo = 1;
				pDuplexLineData->nFidBlock = m_nFidBlock;
				m_pDuplexUnit->m_LineData.AddTail(pDuplexLineData);
				
				
				
				if(pDuplexLineData->npStartPos.x > m_nMaxX)
					m_nMaxX = pDuplexLineData->npStartPos.x;
				if(pDuplexLineData->npStartPos.x < m_nMinX)
					m_nMinX = pDuplexLineData->npStartPos.x;
				
				if(pDuplexLineData->npEndPos.x > m_nMaxX)
					m_nMaxX = pDuplexLineData->npEndPos.x;
				if(pDuplexLineData->npEndPos.x < m_nMinX)
					m_nMinX = pDuplexLineData->npEndPos.x;
				
				
				if(pDuplexLineData->npStartPos.x > m_pUnit->m_nMaxX)
					m_pUnit->m_nMaxX = pDuplexLineData->npStartPos.x;
				if(pDuplexLineData->npStartPos.x < m_pUnit->m_nMinX)
					m_pUnit->m_nMinX = pDuplexLineData->npStartPos.x;
				
				if(pDuplexLineData->npEndPos.x > m_pUnit->m_nMaxX)
					m_pUnit->m_nMaxX = pDuplexLineData->npEndPos.x;
				if(pDuplexLineData->npEndPos.x < m_pUnit->m_nMinX)
					m_pUnit->m_nMinX = pDuplexLineData->npEndPos.x;
			}
		}
	}
}

void GerberReader::ReadCCode()
{
	if (m_pDProject)
	{
		m_pDProject->m_pToolCode[m_nNewTCode]->m_nToolSize = m_nHoleSize;
	}
}

void GerberReader::CalCurvLine(CDPoint StartP, CDPoint EndP, CDPoint OffsetP)
{

	double dR; //������ 
	double dTheta = 0.0; 
	double dAlpha = 0.0;
//	double dTotalTheata; 
//	double dDivideCount;
	double dTempX, dTempY;
	double dStartA, dEndA;
	double dCenterPX, dCenterPY;

	if (m_bRepeat == FALSE)
	{
		m_nDupliMovX = 0;
		m_nDupliMovY = 0;
	}

	dR = sqrt((OffsetP.x * OffsetP.x) + (OffsetP.y * OffsetP.y));

	if(dR == 0) //�������� ������ ���
		return;

	dCenterPX = StartP.x + OffsetP.x;
	dCenterPY = StartP.y + OffsetP.y;
 
	//�ݽð���� ���� 
	if(StartP.x == EndP.x && StartP.y == EndP.y)
	{
		dStartA = atan2(-OffsetP.y, -OffsetP.x);
		if(m_bCW)
		{
			dEndA = dStartA - 2 * M_PI;
		}
		else
		{
			dEndA = dStartA + 2 * M_PI;
		}
	}
	else
	{
		dStartA = atan2(-OffsetP.y, -OffsetP.x);
		dEndA = atan2(EndP.y - dCenterPY , EndP.x - dCenterPX);
		
		if(dStartA < 0) dStartA += (2 * M_PI);
		if(dEndA < 0) dEndA += (2 * M_PI);
		
		
		if(m_bCW)
		{
			if(dStartA < dEndA)
				dStartA += (2 * M_PI);
		}
		else
		{
			if(dStartA > dEndA)
				dStartA -= (2 * M_PI);
		}
	}
	

	dTheta =2 * acos((dR - m_dDivide)/dR); //chordal error 
	int nCount = (int)ceil((fabs(dEndA - dStartA))/dTheta);
	dTheta = (dEndA - dStartA)/nCount;


	for(int i = 1; i <= nCount; i ++)
	{
		MessageLoop();

		if(m_bCW)
		{
			dTempX = (StartP.x+dR) - dR * cos(dStartA + i * dTheta); 


			dTempY = StartP.y - dR * sin(dAlpha + i * dTheta);

		}
		else
		{
			dTempX = dR * sin(dAlpha + dTheta * i) + (StartP.x);
			dTempY = dR * cos(dAlpha + dTheta * i) + (StartP.y - dR);
		}

		m_nPositionX = (int)( dCenterPX + dR * cos(dStartA + i * dTheta) ); 
		m_nPositionY = (int)( dCenterPY + dR * sin(dStartA + i * dTheta) );

		if(i == nCount)
		{
			m_nPositionX = (int)EndP.x;
			m_nPositionY = (int)EndP.y;
		}
		ReadLine();

		m_nStartX = m_nPositionX;
		m_nStartY = m_nPositionY;		
	}

}

void GerberReader::MessageLoop()
{
	MSG msg;
	
	if (PeekMessage((LPMSG)&msg,(HWND)NULL,(WORD)NULL,(WORD)NULL,PM_REMOVE))
	{
		TranslateMessage((LPMSG)&msg);
		DispatchMessage((LPMSG)&msg);
	}
}

BOOL GerberReader::CalLine()
{
	double dLenX, dLenY;
	
	dLenX = m_nPositionX - m_nStartX;
	dLenY = m_nPositionY - m_nStartY;
	int nLength =  (int)( sqrt((dLenY * dLenY) + (dLenX * dLenX)) );
	double dTheta;
	double dTempStartX, dTempStartY, dTempEndX, dTempEndY;
	//�ӽ� ���� 

	dTempStartX = m_nStartX;
	dTempStartY = m_nStartY;
	dTempEndX = m_nPositionX;
	dTempEndY = m_nPositionY;
	
	dTheta = atan2(dLenY, dLenX);

	int nCount = (int)( ceil(nLength / m_dDivide) ); //���� Ƚ�� 
	if(nCount <= 0)
		return FALSE;

 	double dStepLenX = dLenX/ nCount; //���� ���� 
	double dStepLenY = dLenY/ nCount;

	for(int i = 1; i <= nCount; i++)
	{
		m_nPositionX = (int)( m_nStartX + dStepLenX );
		m_nPositionY = (int)( m_nStartY + dStepLenY );
		if(i == nCount)
		{
			m_nPositionX = (int)dTempEndX;
			m_nPositionY = (int)dTempEndY;
		}
		ReadLine();
		m_nStartX = m_nPositionX;
		m_nStartY = m_nPositionY;
	}
	return TRUE;
}

void GerberReader::ToolComparison()
{
	for(int j =0; j<MAX_TOOL_NO-1; j++)
	{
		if(m_nToolMatch[j][0] == m_nCurrentTool)
		{
			if(m_nToolFirstType[j] != m_nCurrentToolType)
			{
				m_nOldTCode = m_nNewTCode;
				m_nNewTCode = m_nToolCnt + j +1;
				ReadTCode();
			}	
		}
	}
}

void GerberReader::FirstToolType(CString strCmd)
{
	for(int j =0; j<MAX_TOOL_NO-1; j++)
	{
		if(m_nToolMatch[j][0] == m_nCurrentTool)
		{
			if(m_nToolFirstType[j] == 0 )
			{
				if(strCmd == "D03") //shot�� �ƴϸ�
				{
					m_nToolFirstType[j] = 2;

				}
				else 
				{
					m_nToolFirstType[j] = 1;
				}
			}
		}
	}
}

void GerberReader::ToolRestore()
{
	for(int j =0; j<MAX_TOOL_NO-1; j++)
	{
		if(m_nToolMatch[j][0] == m_nCurrentTool)
		{
			if(m_nToolFirstType[j] != m_nCurrentToolType)
			{
				m_nNewTCode = m_nOldTCode;
			}	
		}
	}
}
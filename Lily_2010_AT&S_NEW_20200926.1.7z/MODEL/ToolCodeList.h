#if !defined(AFX_TOOLCODELIST_H__7E87DC6C_088E_4C9A_9899_BDD805CA1C3F__INCLUDED_)
#define AFX_TOOLCODELIST_H__7E87DC6C_088E_4C9A_9899_BDD805CA1C3F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ToolCodeList.h : header file
//

#include "ArchiveMark.h"

#define MAX_PATH_LEN		255
#define MAX_SHOT			15

#define BURST_MODE			0
#define CYCLE_MODE			1
#define STEP_MODE           2

enum { MARKING_TYPE, SHOT_DRILL_TYPE, TEXT_TYPE, LINE_DRILL_TYPE, FLYING_TYPE, BARCODE_TYPE };

struct SUBTOOLDATA {
	int			nSubToolNo;
	int			nToolType;

	// Mark
	double		dDrawStep;
	int			nJumpStep;
	int			nJumpStepPeriod;
	int			nDrawStepPeriod;
	int			nCornerDelay;
	int			nJumpDelay;
	int			nLineDelay;
	int			nLaserOnDelay;
	int			nLaserOffDelay;
	int			nFrequency;
	int			nFPS;
	int			nMinShotTime;
	double		dCurrent;
	double		dA1; 
	double		dA2;

	BOOL		bBarcodeLineDrill;

	// Drill
	int			nShotMode;
	int			nMatrix;
	int			nTotalShot;
	int			nBurstShot;
	int			nMask;		// mask->BeamPath ��ȣ�� �����ؼ� �� 
	BOOL		bUseTophat;
	double		dShotDuty[MAX_SHOT];
	double		dShotAOMDelay[MAX_SHOT];
	double		dShotAOMDuty[MAX_SHOT];
	double		dShotMinFreq[MAX_SHOT];
	double		dShotMaxFreq[MAX_SHOT];
	double		dPowerMin[MAX_SHOT];
	double		dPowerMax[MAX_SHOT];
	TCHAR		cAOMFilePath[MAX_SHOT][255];

	double		dShotDutyOffsetM[MAX_SHOT];
	double		dShotDutyOffsetS[MAX_SHOT];
	double		dShotVolOffsetM[MAX_SHOT];
	double		dShotVolOffsetS[MAX_SHOT];

	BOOL		bUseAperture;
	int			nApertureBurst;
	int			nThermalTrack;
	double		dZOffset;
	TCHAR		cFilePath[MAX_PATH_LEN];


	double		dShotLPCMin_M[MAX_SHOT];
	double		dShotLPCMax_M[MAX_SHOT];
	double		dShotLPCMin_S[MAX_SHOT];
	double		dShotLPCMax_S[MAX_SHOT];

	// Flying
	int			nLeadIn;
	int			nLeadOut;
	int			nTableSpeed;
	
	// Barcode
	BOOL		bFlipX;
	BOOL		bFlipY;
	int			nRotate;
	
	// Memo
	TCHAR		cToolMemo[MAX_PATH_LEN];
	double		dMinPower;
	double		dMaxPower;
	double		dHoleSize;


	TCHAR		cAscFile[256];
};
typedef	SUBTOOLDATA*	LPSUBTOOLDATA;

typedef CTypedPtrList <CPtrList, LPSUBTOOLDATA>	SubToolDataList;

/////////////////////////////////////////////////////////////////////////////
// CToolCodeList command target

class CToolCodeList : public CObject
{
// Attributes
public:

// Operations
public:
	CToolCodeList();
	virtual ~CToolCodeList();

	void Initialize();

	CList <SUBTOOLDATA, SUBTOOLDATA> m_SubToolData;

	int		 m_nLeadIn;
	int		 m_nLeadOut;
	BOOL	 m_bVisible;
	int		 m_nToolNo;
	BOOL	 m_bUseTool;
	BOOL	 m_bToolOrder;
	int		 m_nToolSize;
	int		 m_nApertureSize;
	COLORREF m_nToolColor;
	int		 m_nRefToolNo;

	int		 m_nApertureCount;
	BOOL	 m_bCountOver;
	
	int		 m_nTotalSubNo;

	CRect	m_rcAperture;

	int		 m_nTempToolIsHole; //just display 
	BOOL	 m_bContainBlockData; //just display 
	//Prework Use Info
	BOOL		m_bPreworkPower; 
	BOOL		m_bPreworkScanner;
	BOOL		m_bPreworkPreheat;
	int		 m_nMarkingSize;
	BOOL	 m_bHoldFind;
	BOOL     m_bHoleSorting;
// Overrides
public:
	void SetDutyOffsettoMDB();
	void GetDutyOffsetfromMDB();
	BOOL IsSameBeamPath(CToolCodeList* pToolCode);
	BOOL IsSameMinMaxFreq(CToolCodeList* pToolCode);
	int CompareBeamPath(SUBTOOLDATA subTool, int nToolNo, int nSubIndex);
	
	BOOL SaveFile10000(CArchiveMark &ar, int nVersion);
	BOOL LoadFile10000(CArchiveMark &ar, int nVersion, BOOL bGlobal = FALSE, BOOL bPenOpen = FALSE);
	BOOL IsVisable();
	BOOL IsSameSubTool(SUBTOOLDATA& subTool1, SUBTOOLDATA& subTool2);
	BOOL IsSameSubTool2(SUBTOOLDATA& subTool1, SUBTOOLDATA& subTool2);
	BOOL IsSameTool(CToolCodeList* pToolCode ,BOOL bChangeSave = FALSE);
	int GetToolSumInfo();
	BOOL ParseApertureData(CString str, CRect& rect, BOOL bCalArea);
	void CalApertureSizeAndLeadInOut();
	int GetApertureSize();
	BOOL IsValidCount();
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CToolCodeList)
	public:
	virtual void Serialize(CArchiveMark& ar);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CToolCodeList)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TOOLCODELIST_H__7E87DC6C_088E_4C9A_9899_BDD805CA1C3F__INCLUDED_)

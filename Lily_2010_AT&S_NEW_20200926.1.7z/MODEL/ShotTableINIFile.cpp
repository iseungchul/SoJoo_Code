// ShotTableINIFile.cpp: implementation of the CShotTableINIFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "ShotTableINIFile.h"
#include "DShotTableINI.h"
#include "DSystemINI.h"
#include "DEasyDrillerINI.h"



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CShotTableINIFile::CShotTableINIFile()
{

}

CShotTableINIFile::~CShotTableINIFile()
{

}

BOOL CShotTableINIFile::OpenShotTableINIFile(CString strFilePath, DShotTableINI& clsShotTableINI)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;

	if( FALSE == sFile.Open( strFilePath, CFile::modeRead | CFile::typeText ) )
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, strFilePath);
		ErrMessage(strMsg);
		//MultiMessageDlg(STDMESSAGE2,strMsg);

//		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		WriteLog(strMsg);
		return bRet;
	}

	CString strGetData;

	CString strMsg;

	while( sFile.ReadString( strGetData ) )
	{
		if( 0 == strGetData.CompareNoCase(_T("// START SHOTTABLE SECTION")) )
		{
			if( FALSE == ParsingShotTable( sFile, clsShotTableINI ) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingLaserScanner"));
				ErrMessage(strMsg);
				//MultiMessageDlg(STDMESSAGE94);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
	
		else if( 0 == strGetData.CompareNoCase(_T("// END SHOTTABLE INI FILE")) )
		{
			bRet = TRUE;
			break;
		}
	}

	sFile.Close();

	return bRet;
}

BOOL CShotTableINIFile::GetOldShotTableData(DShotTableINI& clsShotTableINI, DSystemINI clsSystemINI)
{
	CString strTemp;
	for(int i = 0; i < 10; i++)
	{


		clsShotTableINI.m_sShotGroupTable.nGroupLastIndex = 2;
		clsShotTableINI.m_sShotGroupTable.bGroupSelectedList[i] = FALSE;
		

		clsShotTableINI.m_sShotGroupTable.nGroupInfoId[i] = i;

		clsShotTableINI.m_sShotGroupTable.nToolType[i] = 1;
		clsShotTableINI.m_sShotGroupTable.nShotMode[i] = 0;
		clsShotTableINI.m_sShotGroupTable.nFirstWaitMode[i] = 0;
		clsShotTableINI.m_sShotGroupTable.bUseAom[i] = 0;
		clsShotTableINI.m_sShotGroupTable.nDummyType[i] = 0;

		clsShotTableINI.m_sShotGroupTable.nShotFrequency[i] = 3500;
		clsShotTableINI.m_sShotGroupTable.nShotMinFrequency[i] = 3500;

		clsShotTableINI.m_sShotGroupTable.dShotDuty_Percent[i] = 9;
		clsShotTableINI.m_sShotGroupTable.dShotLMDuty_us[i] = 20;

		clsShotTableINI.m_sShotGroupTable.nTotalShotCount[i] = 1;
		clsShotTableINI.m_sShotGroupTable.nBurstShotCount[i] = 0;

		clsShotTableINI.m_sShotGroupTable.dVoltage_M[i] = 90;
		clsShotTableINI.m_sShotGroupTable.dVoltage_S[i] = 90;
		clsShotTableINI.m_sShotGroupTable.bUseAperture[i] = 0;

		strTemp.Format(_T("Aperture %d"), i);
		sprintf_s( clsShotTableINI.m_sShotGroupTable.strAperturePath[i], BUFMAX,  _T("%s"), strTemp );

		clsShotTableINI.m_sShotGroupTable.nLaserOnDelay[i] = 0;
		clsShotTableINI.m_sShotGroupTable.nLaserOffDelay[i] = 0;
		clsShotTableINI.m_sShotGroupTable.nDrawSpeed[i] = 0;
		clsShotTableINI.m_sShotGroupTable.nJumpSpeed[i] = 0;
		clsShotTableINI.m_sShotGroupTable.nConerDelay[i] = 0;
		clsShotTableINI.m_sShotGroupTable.nJumpDelay[i] = 0;
		clsShotTableINI.m_sShotGroupTable.nLineDelay[i] = 0;


		clsShotTableINI.m_sShotGroupTable.nTextSizeX[i] = 1000;
		clsShotTableINI.m_sShotGroupTable.nTextSizeY[i] = 1000;

		clsShotTableINI.m_sShotGroupTable.nCavityDrawInOffset[i] = 0;
		clsShotTableINI.m_sShotGroupTable.nCavityDrawOutOffset[i] = 0;

		if(i == 0)
			clsShotTableINI.m_sShotGroupTable.bGroupSelectedList[i] = TRUE;

		strTemp.Format(_T("Group %d"), i);
		sprintf_s( clsShotTableINI.m_sShotGroupTable.strInfoName[i], BUFMAX,  _T("%s"), strTemp );


		for(int j = 0; j < SHOT_COUNT; j++)
		{
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].nLastIndex = SHOT_COUNT -1;
	

			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].bSelectedList[j] = FALSE;
			//Information
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].nInfoId[j] = j;
	

			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOnTime_M[j] = 10;				// ���� ī�޶�
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOnTime_S[j] = 10;

			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dRefPower[j] = 5;
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dPower_Tol[j] = 5;

			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].nAOMNum_M[j] = 5;
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dAOMWait_M[j] = 5;
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].nAOMNum_S[j] = 5;
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dAOMWait_S[j] = 5;

			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetMax_M[j] = 10;
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetMin_M[j] = 4;

			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOntimeOffset_M[j] = 0;
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOntimeOffset_S[j] = 0;

			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOntimeOffset2_M[j] = 0;
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOntimeOffset2_S[j] = 0;

			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dShotScaleX_um_M[j] = 0;
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dShotScaleY_um_M[j] = 0;
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dShotScaleX_um_S[j] = 0;
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dShotScaleY_um_S[j] = 0;

			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetLPCMax_M[j] = 3000;
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetLPCMin_M[j] = 100;
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetLPCMax_S[j] = 3000;
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetLPCMin_S[j] = 100;

			for(int k = 0; k < AOM_COUNT; k++)
			{

	
				clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].m_sAOMParam[j].nInfoId[k] = k;
                clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_ON_M[k] = 0;
				clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_OFF_M[k] = 0;
				clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_ON_S[k] = 0;
				clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_OFF_S[k] = 0;
			}
	
		  }


	}
	
	return TRUE;
}

BOOL CShotTableINIFile::ParsingShotTable(CStdioFile& sFile, DShotTableINI& clsShotTableINI)
{
	BOOL bRet = FALSE;
	CString strGetData;
	CString strTarget;
	int nIndex = 0;
	int nGroupIndex = 0;
	int nAOMIndex = 0;

	while( sFile.ReadString( strGetData ) )
	{

		if( ScanSys( strGetData, _T("GROUP LASTINDEX ="), clsShotTableINI.m_sShotGroupTable.nGroupLastIndex ) )
			continue;

		// Index
		if( ScanSys( strGetData, _T("GROUP INDEX ="), nGroupIndex ) )
		{
			nIndex = 0;
			continue;
		}

		if( ScanSys( strGetData, _T("GROUP INFO NAME ="), strTarget) )
		{
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( clsShotTableINI.m_sShotGroupTable.strInfoName[nGroupIndex], BUFMAX, _T("%s"), strTarget );
			continue;
		}

		if( ScanSys( strGetData, _T("GROUP TOOL TYPE ="), clsShotTableINI.m_sShotGroupTable.nToolType[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP SHOT MODE ="), clsShotTableINI.m_sShotGroupTable.nShotMode[nGroupIndex] ) )
			continue;

		if( ScanSys( strGetData, _T("FIRST WAIT MODE ="), clsShotTableINI.m_sShotGroupTable.nFirstWaitMode[nGroupIndex] ) )
			continue;

		if( ScanSys( strGetData, _T("GROUP USE AOM ="), clsShotTableINI.m_sShotGroupTable.bUseAom[nGroupIndex] ) )
		{
#ifdef __PKG_MODIFY__
			clsShotTableINI.m_sShotGroupTable.bUseAom[nGroupIndex] = TRUE;
#endif
			continue;
		}
		if( ScanSys( strGetData, _T("GROUP DUMMY TYPE ="), clsShotTableINI.m_sShotGroupTable.nDummyType[nGroupIndex] ) )
			continue;
		

		if( ScanSys( strGetData, _T("GROUP SHOT MIN FREQUENCY ="), clsShotTableINI.m_sShotGroupTable.nShotMinFrequency[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP SHOT FREQUENCY ="), clsShotTableINI.m_sShotGroupTable.nShotFrequency[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP SHOT DUTY PERCENT ="), clsShotTableINI.m_sShotGroupTable.dShotDuty_Percent[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP SHOT LM ="), clsShotTableINI.m_sShotGroupTable.dShotLMDuty_us[nGroupIndex] ) )
			continue;



		if( ScanSys( strGetData, _T("GROUP TOTAL SHOT COUNT ="), clsShotTableINI.m_sShotGroupTable.nTotalShotCount[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP BURST SHOT COUNT ="), clsShotTableINI.m_sShotGroupTable.nBurstShotCount[nGroupIndex] ) )
			continue;



		if( ScanSys( strGetData, _T("GROUP VOLTAGE M ="), clsShotTableINI.m_sShotGroupTable.dVoltage_M[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP VOLTAGE S ="), clsShotTableINI.m_sShotGroupTable.dVoltage_S[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP USE APERTURE ="), clsShotTableINI.m_sShotGroupTable.bUseAperture[nGroupIndex] ) )
			continue;

		if( ScanSys( strGetData, _T("GROUP APERTURE PATH ="), strTarget) )
		{
			strTarget.TrimLeft(); strTarget.TrimRight();
			sprintf_s( clsShotTableINI.m_sShotGroupTable.strAperturePath[nGroupIndex], BUFMAX, _T("%s"), strTarget );
			continue;
		}

		if( ScanSys( strGetData, _T("GROUP TEXT SIZE X ="), clsShotTableINI.m_sShotGroupTable.nTextSizeX[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP TEXT SIZE Y ="), clsShotTableINI.m_sShotGroupTable.nTextSizeY[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP DRAW IN ="), clsShotTableINI.m_sShotGroupTable.nCavityDrawInOffset[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP DRAW OUT ="), clsShotTableINI.m_sShotGroupTable.nCavityDrawOutOffset[nGroupIndex] ) )
			continue;
		/////
		if( ScanSys( strGetData, _T("GROUP LASER ON DELAY ="), clsShotTableINI.m_sShotGroupTable.nLaserOnDelay[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP LASER OFF DELAY ="), clsShotTableINI.m_sShotGroupTable.nLaserOffDelay[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP DRAW SPEED ="), clsShotTableINI.m_sShotGroupTable.nDrawSpeed[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP JUMP SPEED ="), clsShotTableINI.m_sShotGroupTable.nJumpSpeed[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP CONER DELAY ="), clsShotTableINI.m_sShotGroupTable.nConerDelay[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP JUMP DELAY ="), clsShotTableINI.m_sShotGroupTable.nJumpDelay[nGroupIndex] ) )
			continue;
		if( ScanSys( strGetData, _T("GROUP LINE DELAY ="), clsShotTableINI.m_sShotGroupTable.nLineDelay[nGroupIndex] ) )
			continue;

		//total count
		if( ScanSys( strGetData, _T("LASTINDEX ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].nLastIndex ) )
		{
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].nLastIndex  = SHOT_COUNT -1;
			continue;
		}

	// Index
		if( ScanSys( strGetData, _T("INDEX ="), nIndex ) )
			continue;
		//information
		// id
		clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].nInfoId[nIndex] = nIndex;
		if( ScanSys( strGetData, _T("INFO ID ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].nInfoId[nIndex]) )
			continue;
		// name



		if( ScanSys( strGetData, _T("SHOT DUTY ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dOnTime_M[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("SHOT DUTY SLAVE ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dOnTime_S[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("SHOT POWER ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dRefPower[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("SHOT POWER TOL ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dPower_Tol[nIndex]) )
			continue;

		if( ScanSys( strGetData, _T("AOM NUM M ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].nAOMNum_M[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("AOM WAIT M ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dAOMWait_M[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("AOM NUM S ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].nAOMNum_S[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("AOM WAIT S ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dAOMWait_S[nIndex]) )
			continue;

		if( ScanSys( strGetData, _T("TARGET MAX M ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dTargetMax_M[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("TARGET MIN M ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dTargetMin_M[nIndex]) )
			continue;

		if( ScanSys( strGetData, _T("SHOT ONTIME OFFSET M ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dOntimeOffset_M[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("SHOT ONTIME OFFSET S ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dOntimeOffset_S[nIndex]) )
			continue;

		if( ScanSys( strGetData, _T("SHOT ONTIME OFFSET2 M ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dOntimeOffset2_M[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("SHOT ONTIME OFFSET2 S ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dOntimeOffset2_S[nIndex]) )
			continue;

		if( ScanSys( strGetData, _T("SHOT SCALE X UM M ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dShotScaleX_um_M[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("SHOT SCALE Y UM M ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dShotScaleY_um_M[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("SHOT SCALE X UM S ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dShotScaleX_um_S[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("SHOT SCALE Y UM S ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dShotScaleY_um_S[nIndex]) )
			continue;

		if( ScanSys( strGetData, _T("TARGET LPC MAX M ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dTargetLPCMax_M[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("TARGET LPC MIN M ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dTargetLPCMin_M[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("TARGET LPC MAX S ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dTargetLPCMax_S[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("TARGET LPC MIN S ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].dTargetLPCMin_S[nIndex]) )
			continue;

		if( ScanSys( strGetData, _T("AOM INDEX ="), nAOMIndex ) )
			continue;
		if( ScanSys( strGetData, _T("AOM MODULE M ON ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].m_sAOMParam[nIndex].dAOM_ON_M[nAOMIndex]) )
			continue;
		if( ScanSys( strGetData, _T("AOM MODULE M OFF ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].m_sAOMParam[nIndex].dAOM_OFF_M[nAOMIndex]) )
			continue;
		if( ScanSys( strGetData, _T("AOM MODULE S ON ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].m_sAOMParam[nIndex].dAOM_ON_S[nAOMIndex]) )
			continue;
		if( ScanSys( strGetData, _T("AOM MODULE S OFF ="), clsShotTableINI.m_sShotGroupTable.m_sShotParam[nGroupIndex].m_sAOMParam[nIndex].dAOM_OFF_S[nAOMIndex]) )
			continue;

		if( 0 == strGetData.CompareNoCase(_T("// END SHOTTABLE SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}
	
	if(bRet == FALSE)
		WriteLog(strGetData);
	
	return bRet;
}



BOOL CShotTableINIFile::SaveShotTableNIFile(CString strFilePath, DShotTableINI clsShotTableINI)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;
	
	if(FALSE == sFile.Open(strFilePath,CFile::modeCreate|CFile::modeWrite|CFile::typeText) )
	{
		//		CString strMsg;
		
		//		strMsg.Format(_T("Can't Save %s file  "), strFilePath);
		//		ErrMessage(strMsg, MB_ICONERROR);
		
		return bRet;
	}
	
	CString strSetData;
	
	strSetData.Format(_T("// START SHOTTABLE INI FILE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	CTime CurTime = CTime::GetCurrentTime();
	strSetData.Format(_T("Last Update Time : %04d-%02d-%02d %02d:%02d:%2d\n\n"), CurTime.GetYear(), 
					   CurTime.GetMonth(), CurTime.GetDay(), CurTime.GetHour(), CurTime.GetMinute(), 
					   CurTime.GetSecond() );
	sFile.WriteString( strSetData );
	

	strSetData.Format(_T("// START SHOTTABLE SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("GROUP LASTINDEX = %d\n"), clsShotTableINI.m_sShotGroupTable.nGroupLastIndex);
	sFile.WriteString( (LPCTSTR)strSetData );

	int nGroupRepeatcount = clsShotTableINI.m_sShotGroupTable.nGroupLastIndex;


	for(int i = 0 ;i <= nGroupRepeatcount ;i++)
	{

		strSetData.Format(_T("GROUP INDEX = %d\n"), i);
		sFile.WriteString( (LPCTSTR)strSetData );

		// id
		clsShotTableINI.m_sShotGroupTable.nGroupInfoId[i] = i;
		strSetData.Format(_T("GROUP INFO ID = %d\n"), clsShotTableINI.m_sShotGroupTable.nGroupInfoId[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("GROUP INFO NAME = %s\n"), clsShotTableINI.m_sShotGroupTable.strInfoName[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		////
		strSetData.Format(_T("GROUP TOOL TYPE = %d\n"), clsShotTableINI.m_sShotGroupTable.nToolType[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("GROUP SHOT MODE = %d\n"), clsShotTableINI.m_sShotGroupTable.nShotMode[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("FIRST WAIT MODE = %d\n"), clsShotTableINI.m_sShotGroupTable.nFirstWaitMode[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
#ifdef __PKG_MODIFY__
		clsShotTableINI.m_sShotGroupTable.bUseAom[i] = TRUE;
#endif
		strSetData.Format(_T("GROUP USE AOM = %d\n"), clsShotTableINI.m_sShotGroupTable.bUseAom[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("GROUP DUMMY TYPE = %d\n"), clsShotTableINI.m_sShotGroupTable.nDummyType[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("GROUP SHOT MIN FREQUENCY = %d\n"), clsShotTableINI.m_sShotGroupTable.nShotMinFrequency[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("GROUP SHOT FREQUENCY = %d\n"), clsShotTableINI.m_sShotGroupTable.nShotFrequency[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("GROUP SHOT DUTY PERCENT = %.2f\n"), clsShotTableINI.m_sShotGroupTable.dShotDuty_Percent[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("GROUP SHOT LM = %.2f\n"), clsShotTableINI.m_sShotGroupTable.dShotLMDuty_us[i]);
		sFile.WriteString( (LPCTSTR)strSetData );



		strSetData.Format(_T("GROUP TOTAL SHOT COUNT = %d\n"), clsShotTableINI.m_sShotGroupTable.nTotalShotCount[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("GROUP BURST SHOT COUNT = %d\n"), clsShotTableINI.m_sShotGroupTable.nBurstShotCount[i]);
		sFile.WriteString( (LPCTSTR)strSetData );





		strSetData.Format(_T("GROUP VOLTAGE M = %.2f\n"), clsShotTableINI.m_sShotGroupTable.dVoltage_M[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("GROUP VOLTAGE S = %.2f\n"), clsShotTableINI.m_sShotGroupTable.dVoltage_S[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("GROUP USE APERTURE = %d\n"), clsShotTableINI.m_sShotGroupTable.bUseAperture[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("GROUP APERTURE PATH = %s\n"), clsShotTableINI.m_sShotGroupTable.strAperturePath[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		/////

		strSetData.Format(_T("GROUP TEXT SIZE X = %d\n"), clsShotTableINI.m_sShotGroupTable.nTextSizeX[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("GROUP TEXT SIZE Y = %d\n"), clsShotTableINI.m_sShotGroupTable.nTextSizeY[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("GROUP DRAW IN = %d\n"), clsShotTableINI.m_sShotGroupTable.nCavityDrawInOffset[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("GROUP DRAW OUT = %d\n"), clsShotTableINI.m_sShotGroupTable.nCavityDrawOutOffset[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		/////
		strSetData.Format(_T("GROUP LASER ON DELAY = %d\n"), clsShotTableINI.m_sShotGroupTable.nLaserOnDelay[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		strSetData.Format(_T("GROUP LASER OFF DELAY = %d\n"), clsShotTableINI.m_sShotGroupTable.nLaserOffDelay[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		strSetData.Format(_T("GROUP DRAW SPEED = %d\n"), clsShotTableINI.m_sShotGroupTable.nDrawSpeed[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		strSetData.Format(_T("GROUP JUMP SPEED = %d\n"), clsShotTableINI.m_sShotGroupTable.nJumpSpeed[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		strSetData.Format(_T("GROUP CONER DELAY = %d\n"), clsShotTableINI.m_sShotGroupTable.nConerDelay[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		strSetData.Format(_T("GROUP JUMP DELAY = %d\n"), clsShotTableINI.m_sShotGroupTable.nJumpDelay[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
		strSetData.Format(_T("GROUP LINE DELAY = %d\n"), clsShotTableINI.m_sShotGroupTable.nLineDelay[i]);
		sFile.WriteString( (LPCTSTR)strSetData );

		// Total count
		strSetData.Format(_T("LASTINDEX = %d\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].nLastIndex);
		sFile.WriteString( (LPCTSTR)strSetData );





		int nRepeatcount = clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].nLastIndex;

		for(int j = 0 ;j <= nRepeatcount ;j++)
		{
			// Index
			strSetData.Format(_T("INDEX = %d\n"), j);
			sFile.WriteString( (LPCTSTR)strSetData );

			//information
			// id
			clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].nInfoId[j] = j;
			strSetData.Format(_T("INFO ID = %d\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].nInfoId[j]);
			sFile.WriteString( (LPCTSTR)strSetData );

			strSetData.Format(_T("SHOT DUTY = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOnTime_M[j]);
			sFile.WriteString( (LPCTSTR)strSetData );

			strSetData.Format(_T("SHOT DUTY SLAVE = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOnTime_S[j]);
			sFile.WriteString( (LPCTSTR)strSetData );

			
			strSetData.Format(_T("SHOT POWER = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dRefPower[j]);
			sFile.WriteString( (LPCTSTR)strSetData );

			strSetData.Format(_T("SHOT POWER TOL = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dPower_Tol[j]);
			sFile.WriteString( (LPCTSTR)strSetData );

			strSetData.Format(_T("AOM NUM M = %d\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].nAOMNum_M[j]);
			sFile.WriteString( (LPCTSTR)strSetData );
			strSetData.Format(_T("AOM WAIT M = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dAOMWait_M[j]);
			sFile.WriteString( (LPCTSTR)strSetData );
			strSetData.Format(_T("AOM NUM S = %d\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].nAOMNum_S[j]);
			sFile.WriteString( (LPCTSTR)strSetData );
			strSetData.Format(_T("AOM WAIT S = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dAOMWait_S[j]);
			sFile.WriteString( (LPCTSTR)strSetData );

			strSetData.Format(_T("TARGET MAX M = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetMax_M[j]);
			sFile.WriteString( (LPCTSTR)strSetData );
			strSetData.Format(_T("TARGET MIN M = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetMin_M[j]);
			sFile.WriteString( (LPCTSTR)strSetData );

			strSetData.Format(_T("SHOT ONTIME OFFSET M = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOntimeOffset_M[j]);
			sFile.WriteString( (LPCTSTR)strSetData );
			strSetData.Format(_T("SHOT ONTIME OFFSET S = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOntimeOffset_S[j]);
			sFile.WriteString( (LPCTSTR)strSetData );

			strSetData.Format(_T("SHOT ONTIME OFFSET2 M = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOntimeOffset2_M[j]);
			sFile.WriteString( (LPCTSTR)strSetData );
			strSetData.Format(_T("SHOT ONTIME OFFSET2 S = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dOntimeOffset2_S[j]);
			sFile.WriteString( (LPCTSTR)strSetData );

			strSetData.Format(_T("SHOT SCALE X UM M = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dShotScaleX_um_M[j]);
			sFile.WriteString( (LPCTSTR)strSetData );
			strSetData.Format(_T("SHOT SCALE Y UM M = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dShotScaleY_um_M[j]);
			sFile.WriteString( (LPCTSTR)strSetData );
			strSetData.Format(_T("SHOT SCALE X UM S = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dShotScaleX_um_S[j]);
			sFile.WriteString( (LPCTSTR)strSetData );
			strSetData.Format(_T("SHOT SCALE Y UM S = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dShotScaleY_um_S[j]);
			sFile.WriteString( (LPCTSTR)strSetData );

			strSetData.Format(_T("TARGET LPC MAX M = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetLPCMax_M[j]);
			sFile.WriteString( (LPCTSTR)strSetData );
			strSetData.Format(_T("TARGET LPC MIN M = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetLPCMin_M[j]);
			sFile.WriteString( (LPCTSTR)strSetData );
			strSetData.Format(_T("TARGET LPC MAX S = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetLPCMax_S[j]);
			sFile.WriteString( (LPCTSTR)strSetData );
			strSetData.Format(_T("TARGET LPC MIN S = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].dTargetLPCMin_S[j]);
			sFile.WriteString( (LPCTSTR)strSetData );

			int nMasterAOMModule = clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].nAOMNum_M[j];
			for(int k = 0; k <nMasterAOMModule; k++)
			{
				// Index
				strSetData.Format(_T("AOM INDEX = %d\n"), k);
				sFile.WriteString( (LPCTSTR)strSetData );
				strSetData.Format(_T("AOM MODULE M ON = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_ON_M[k]);
				sFile.WriteString( (LPCTSTR)strSetData );
				strSetData.Format(_T("AOM MODULE M OFF = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_OFF_M[k]);
				sFile.WriteString( (LPCTSTR)strSetData );
				strSetData.Format(_T("AOM MODULE S ON = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_ON_S[k]);
				sFile.WriteString( (LPCTSTR)strSetData );
				strSetData.Format(_T("AOM MODULE S OFF = %.2f\n"), clsShotTableINI.m_sShotGroupTable.m_sShotParam[i].m_sAOMParam[j].dAOM_OFF_S[k]);
				sFile.WriteString( (LPCTSTR)strSetData );
			}
		}
	}

	strSetData.Format(_T("// END SHOTTABLE SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );


	strSetData.Format(_T("// END SHOTTABLE INI FILE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	sFile.Close();
	bRet = TRUE;
	
	return bRet;
}

void CShotTableINIFile::WriteLog(CString strLog)
{
	CString strPathName;
	strPathName.Format(_T("D:\\ViaHole\\ErrorLog\\"));
	CTime EventTime = CTime::GetCurrentTime();
	strPathName += EventTime.Format(_T("INI_%y%m%d"));
	
	CStdioFile cFile;
	if (FALSE == cFile.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;
	
	CString strWrite;
	strWrite.Format(_T("%02d:%02d:%02d | %s\n"),
		EventTime.GetHour(),
		EventTime.GetMinute(),
		EventTime.GetSecond(),
		strLog);
	TRY
	{
		cFile.SeekToEnd();		
		cFile.Write(strWrite, strWrite.GetLength());
		cFile.Close();
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH
}
// DFidData.cpp: implementation of the DFidData class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DFidData.h"
#include "sysdef.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DFidData::DFidData()
{	
}

DFidData::~DFidData()
{
	RemovePanel();
}

void DFidData::RemoveFidData()
{
	LPFIDDATA pFidData;
	POSITION pos = m_PositionData.GetHeadPosition();
	while (pos)
	{
		pFidData = m_PositionData.GetNext(pos);
		delete pFidData;
	}
	m_PositionData.RemoveAll();
}

void DFidData::AddFidData(LPFIDDATA pFidData)
{
	if((pFidData->nFidType & FID_DRILL) != FID_DRILL) // 20130419 select�� skiving select ������ �����ϱ� ����
		pFidData->bSelected = FALSE;

	m_PositionData.AddTail(pFidData);
}

int DFidData::GetFidNo()
{
	return m_PositionData.GetCount();
}

void DFidData::SetFidIndex(int nIndex, int nVal)
{
	LPFIDDATA pFidData;
	POSITION pos = m_PositionData.GetHeadPosition();
	int i = 0;
	while (pos)
	{
		pFidData = m_PositionData.GetNext(pos);
		if(nIndex == i)
		{
			pFidData->nFindIndex = nVal;
			return;
		}
		i++;
	}
}

LPFIDDATA DFidData::GetFidData(int nIndex)
{
	LPFIDDATA pFidData = NULL;
	POSITION pos = m_PositionData.GetHeadPosition();
	int i = 0;
	while (pos)
	{
		pFidData = m_PositionData.GetNext(pos);
		if(nIndex == i)
		{
			return pFidData;
		}
		i++;
	}
	return NULL;
}

void DFidData::SetFidCamNum(int nIndex, int nCam)
{
	LPFIDDATA pFidData;
	POSITION pos = m_PositionData.GetHeadPosition();
	int i = 0;
	while (pos)
	{
		pFidData = m_PositionData.GetNext(pos);
		if(nIndex == i)
		{
			pFidData->nCam = nCam;
			return;
		}
		i++;
	}
}

int	DFidData::GetFidCamNum(int nIndex)
{
	LPFIDDATA pFidData;
	POSITION pos = m_PositionData.GetHeadPosition();
	int i = 0;
	while (pos)
	{
		pFidData = m_PositionData.GetNext(pos);
		if(nIndex == i)
		{
			return pFidData->nCam;
		}
		i++;
	}
	return -1;
}

void DFidData::SetFidVisInfo(int nIndex, VISION_INFO sVisInfo)
{
	LPFIDDATA pFidData;
	POSITION pos = m_PositionData.GetHeadPosition();
	int i = 0;
	while (pos)
	{
		pFidData = m_PositionData.GetNext(pos);
		if(nIndex == i)
		{
			pFidData->sVisInfo.nModelType = sVisInfo.nModelType;
			pFidData->sVisInfo.nPolarity = sVisInfo.nPolarity;
			pFidData->sVisInfo.dSizeA = sVisInfo.dSizeA;
			pFidData->sVisInfo.dSizeB = sVisInfo.dSizeB;
			pFidData->sVisInfo.dSizeC = sVisInfo.dSizeC;
//			pFidData->sVisInfo.dOrientation = sVisInfo.dOrientation;
			pFidData->sVisInfo.dScoreAngle = sVisInfo.dScoreAngle;
			pFidData->sVisInfo.dScoreSize = sVisInfo.dScoreSize;
			pFidData->sVisInfo.dAspectRatio = sVisInfo.dAspectRatio;

			for(int j=0; j<4; j++)
			{
				pFidData->sVisInfo.nCoaxial[j] = 0;//sVisInfo.nCoaxial[j];
				pFidData->sVisInfo.nRing[j] = 255;//sVisInfo.nRing[j];
				pFidData->sVisInfo.nIR[j] = 50;
				pFidData->sVisInfo.dContrast[j] = sVisInfo.dContrast[j];
				pFidData->sVisInfo.dBrightness[j] = sVisInfo.dBrightness[j];
			}

			return;
		}
		i++;
	}
}

VISION_INFO DFidData::GetFidVisInfo(int nIndex)
{
	LPFIDDATA pFidData = NULL;
	VISION_INFO sVisInfo;
	memset(&sVisInfo, NULL, sizeof(sVisInfo));
	POSITION pos = m_PositionData.GetHeadPosition();
	int i = 0;
	while (pos)
	{
		pFidData = m_PositionData.GetNext(pos);
		if(nIndex == i)
		{
			return pFidData->sVisInfo;
		}
		i++;
	}
	return sVisInfo;
}

LPPNLFIDINFO DFidData::GetPanel(int nIndex, BOOL b1st)
{
	LPPNLFIDINFO pPanel;
	POSITION pos = m_PanelFid.GetHeadPosition();
	int i = 0;
	while(pos)
	{
		pPanel = m_PanelFid.GetNext(pos);
		if(nIndex == i)
		{
			return pPanel;
		}
		i++;
	}
	return NULL;
}
LPPNLFIDINFO DFidData::GetPanelReverse(int nIndex,  BOOL b1st)
{
	LPPNLFIDINFO pPanel;
	POSITION pos = m_PanelFid.GetTailPosition();
	int i = 0;
	while(pos)
	{
		pPanel = m_PanelFid.GetPrev(pos);
		if(nIndex == i && b1st == pPanel->b1st )
		{
			return pPanel;
		}
		i++;
	}
	return NULL;
}
int DFidData::GetPanelCount()
{
	return m_PanelFid.GetCount();
}
BOOL DFidData::IsFidFound(int nPanelNo,  CPoint npFilePos )
{
	LPPNLFIDINFO pPanel = NULL;
	pPanel = GetPanel(nPanelNo, TRUE);
	
	if(pPanel == NULL)
		return FALSE;

	LPFIDRESULT pResult = NULL;
	POSITION pos = pPanel->FidResult.GetHeadPosition();
	int i =0;
	while(pos)
	{
		pResult = pPanel->FidResult.GetNext(pos);

		if(pResult->npRefPosition == npFilePos)
			return pResult->bFound;
	}
	return FALSE;
}
LPFIDRESULT DFidData::GetFidResult(int nPanelNo, CPoint npFilePos ,  int nFidBlock)
{
	//only use drawing fid result 
	LPFIDRESULT pResult = NULL, pReturnResult = NULL;
	LPPNLFIDINFO pPanel = NULL;
	pPanel = GetPanel(nPanelNo, TRUE);
	if(pPanel == NULL)
		return pReturnResult;

	POSITION pos = pPanel->FidResult.GetHeadPosition();
	int i =0;
	while(pos)
	{
		pResult = pPanel->FidResult.GetNext(pos);
		
		if(pResult->nFidBlock != nFidBlock)
			continue;

		if(pResult->npRefPosition == npFilePos)
			return pResult;
		i++;
	}

	return pReturnResult;
}
 
LPFIDRESULT DFidData::GetFidResult(LPPNLFIDINFO pPanel, CPoint npFilePos , int nFidBlock)
{
//	return NULL; // bhLee for Multi fiducial

	LPFIDRESULT pResult = NULL, pReturnResult = NULL;
	POSITION pos = pPanel->FidResult.GetHeadPosition();
	int i =0;
	while(pos)
	{
		pResult = pPanel->FidResult.GetNext(pos);
		
		if(pResult->nFidBlock != nFidBlock)
			continue;

		if(pResult->npRefPosition == npFilePos)
			return pResult;
		i++;
	}

	return pReturnResult;
}

LPFIDRESULT DFidData::GetFidResult(LPPNLFIDINFO pPanel, int nFidNo, int nFidBlock)
{
	return NULL; // bhLee for Multi fiducial
}

void DFidData::AddFidResult(int nPanelIndex, LPFIDRESULT sResult, LPPNLFIDINFO pPanel)
{
/*	LPPNLFIDINFO pPanel;
	POSITION pos = m_PanelFid.GetHeadPosition();
	int i = 0;
	if(pos == NULL)
		return;

	while(pos)
	{
		pPanel = m_PanelFid.GetNext(pos);
		if(nPanelIndex == i)
			break;
		i++;
	}
*/
	if(pPanel == NULL)
		return;

	pPanel->FidResult.AddTail(sResult);

}

void DFidData::AddPanel(LPPNLFIDINFO Panel)
{
	m_PanelFid.AddTail( Panel );	
}

void DFidData::RemoveFidResult(int nPanelIndex)
{
	LPPNLFIDINFO pPanel;
	POSITION pos = m_PanelFid.GetHeadPosition();
	int i = 0;
	while(pos)
	{
		pPanel = m_PanelFid.GetNext(pos);
		if(nPanelIndex == i)
			break;
		i++;
	}

	LPFIDRESULT pResult;
	POSITION FidPos;
	FidPos = pPanel->FidResult.GetHeadPosition();
	while(FidPos)
	{
		pResult = pPanel->FidResult.GetNext(FidPos);
		delete pResult;
	}
	
	pPanel->FidResult.RemoveAll();
}

void DFidData::RemovePanel()
{
	LPPNLFIDINFO pPanel;
	POSITION pos = m_PanelFid.GetHeadPosition();
	int i = 0;
	while(pos)
	{
		pPanel = m_PanelFid.GetNext(pos);
		if(pPanel == NULL)
			continue;
		RemoveFidResult(i);
		delete pPanel;
		i++;
	}

	m_PanelFid.RemoveAll();

}


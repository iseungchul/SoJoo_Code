// DBeampathINI.h: interface for the DBeampathINI class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DBEAMPATHINI_H__BC0669B0_A041_4C2A_99FD_A711FBE1FC06__INCLUDED_)
#define AFX_DBEAMPATHINI_H__BC0669B0_A041_4C2A_99FD_A711FBE1FC06__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DBeampathINI  
{
public:
	DBeampathINI();
	virtual ~DBeampathINI();

	SBEAMPATH		m_sBeampath;

};

extern DBeampathINI gBeamPathINI;

#endif // !defined(AFX_DBEAMPATHINI_H__BC0669B0_A041_4C2A_99FD_A711FBE1FC06__INCLUDED_)

// ParamOdbc.h: interface for the CBarcodeOdbc class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PARAMODBC_H__F88ADDD4_19AF_40AA_9A54_3789C27A18A3__INCLUDED_)
#define AFX_PARAMODBC_H__F88ADDD4_19AF_40AA_9A54_3789C27A18A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>
#include <stdio.h>
#include <sqlext.h>
#include <conio.h>


class ParamOdbc  
{
public:
	CString m_strWorkingDir;
	SQLHSTMT m_hStmt;
	SQLHDBC m_hDbc;
	SQLHENV m_hEnv;
	BOOL m_bOpen;

	void GetDiagonostics();
	BOOL SetDutyOffset(int nShotNo, BOOL bShotType, int nBeamPath, double* dMaxFreq, double* dDuty, double* dOffset); // ���� �߰�
	BOOL GetStartIndex(int nShotNo, BOOL bShotType, int nBeamPath, double* dMaxFreq, double* dDuty, int* nIndex,  double* dOffset); // ���� ������ ��
	BOOL SetUpdateDutyOffset(int nShotNo, int nIndex, BOOL bShotType, int nBeamPath, double* dMaxFreq, double* dDuty, double* dOffset); // ���� ������Ʈ
	void DBDisconnect();
	BOOL DBConnect();
	ParamOdbc();
	virtual ~ParamOdbc();

};

#endif // !defined(AFX_PARAMODBC_H__F88ADDD4_19AF_40AA_9A54_3789C27A18A3__INCLUDED_)

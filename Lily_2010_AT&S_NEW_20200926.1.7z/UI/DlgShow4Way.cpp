// PaneRecipeGen.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgShow4Way.h"
#include "PaneRecipeGen.h"
#include "PaneRecipeGenDataEasy.h"
#include "PaneRecipeGenLayoutEasy.h"
#include "PaneRecipeGenDrillMethod.h"
#include "PaneRecipeGenFiducial.h"
#include "PaneRecipeGenParameter.h"
#include "PaneRecipeGenParameterNewEasy.h"
#include "PaneRecipeGenFiducialNew.h"
#include "PaneRecipeGenParameterNewNext.h"
#include "PaneAutoRun.h"

#include "PaneAutoRunViewData.h"

#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "DlgMatroxVisionView.h"

#include "..\model\DEasyDrillerINI.h"
#include "..\model\DSystemInI.h"
#include "..\model\ExcellonReader.h"
#include "..\model\DUodoRedo.h"

#include "..\EasyDrillerDlg.h"
#include "..\Model\DProcessINI.h"
#include "..\EasyDriller.h"

#include "..\device\HDeviceFactory.h"

#include "..\device\DeviceMotor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGen

IMPLEMENT_DYNAMIC(CDlgShow4Way, CDialog)

CDlgShow4Way::CDlgShow4Way(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgShow4Way::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPaneRecipeGen)
	//}}AFX_DATA_INIT

}

CDlgShow4Way::~CDlgShow4Way()
{
}

void CDlgShow4Way::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgShow4Way)
	DDX_Control(pDX, IDC_LIST_RESULT, m_lboxResult);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgShow4Way, CDialog)
	//{{AFX_MSG_MAP(CDlgShow4Way)
	
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BTN_PRODUCT_CLEAR, &CDlgShow4Way::OnBnClickedBtnProductClear)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGen diagnostics



/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGen message handlers
BOOL CDlgShow4Way::Create(CWnd* pParentWnd) 
{
	// TODO: Add your specialized code here and/or call the base class

	return CDialog::Create(IDD, pParentWnd);
}
BOOL CDlgShow4Way::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add your specialized code here and/or call the base class


	m_fntList.CreatePointFont(90, "Arial Bold");
	m_lboxResult.SetFont( &m_fntList );

	return TRUE;
}

void CDlgShow4Way::DisplayShow4Way(CString strStatus)
{


	CString str, strTemp;



	m_lboxResult.AddString((LPCTSTR)strStatus);

	m_lboxResult.SetCurSel(m_lboxResult.GetCount()-1);


}
void CDlgShow4Way::InitBtnControl()
{

}


void CDlgShow4Way::OnDestroy() 
{

	m_fntList.DeleteObject();

	CDialog::OnDestroy();
}



void CDlgShow4Way::OnBnClickedBtnProductClear()
{
	m_lboxResult.ResetContent();
}

// DlgCalResult.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgCalResult.h"
#include "..\device\heocard.h"
#include "..\device\CalViaHole.h"
#include "..\device\hdevicefactory.h"
#include "..\device\fcalibration.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\model\dprocessini.h"
#include "..\model\globalvariable.h"
#include "..\model\ProcessINIFile.h"
#include "..\model\DBeampathINI.h"
#include "..\model\DTempINI.h"
#include "..\alarmmsg.h"
#include "..\EasyDrillerDlg.h"
#include "..\Model\DSystemINI.h"
#include "..\DEVICE\HDeviceFactory.h"
#include "..\DEVICE\DevTemperCompen.h"
#include "..\MODEL\DTemperCompensation.h"


#include <cmath>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const int SEL_HEAD_BOTH		= 0;
const int SEL_HEAD_MASTER	= 1;
const int SEL_HEAD_SLAVE	= 2;

/////////////////////////////////////////////////////////////////////////////
// CDlgCalResult dialog
CDlgCalResult::CDlgCalResult(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgCalResult::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgCalResult)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nGridSize				= 17;
	m_dMaxOffsetMasterX		= 0.;
	m_dMaxOffsetMasterY		= 0.;
	m_dMaxOffsetSlaveX		= 0.;
	m_dMaxOffsetSlaveY		= 0.;
	m_dMaxOffsetMasterR		= 0.;
	m_dMaxOffsetSlaveR		= 0.;
	m_bShow					= FALSE;
	m_bOnTimer				= FALSE;
	m_bIsAutoProcessMode	= FALSE;
	m_bDrillingLimitOK[0]	= FALSE;
	m_bDrillingLimitOK[1]	= FALSE;
	m_nTimerID				= 0;
	m_nTool					= 0;
	memset(m_ptMasterGridOffset, 0, sizeof(DPOINT)*MAX_GRIDSIZE*MAX_GRIDSIZE);
	memset(m_ptSlaveGridOffset, 0, sizeof(DPOINT)*MAX_GRIDSIZE*MAX_GRIDSIZE);

	m_hEndView = INVALID_HANDLE_VALUE;

	memset(m_c1st1ASC, NULL, 256);
	memset(m_c2nd1ASC, NULL, 256);
	m_pcalAGCMaster = NULL;
	m_pcalAGCSlave = NULL;

	m_d1stTemperature = 0;
	m_d2ndTemperature = 0;
	m_d1stSBTemperature = 0;
	m_d2ndSBTemperature = 0;
	memset(m_dAllTemper, 0, sizeof(m_dAllTemper));
	m_bFullCoolingAGC = FALSE;
}

void CDlgCalResult::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgCalResult)
	DDX_Control(pDX, IDOK, m_btnApply);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_STATIC_2ND_Y, m_stc2ndY);
	DDX_Control(pDX, IDC_STATIC_2ND_X, m_stc2ndX);
	DDX_Control(pDX, IDC_STATIC_1ST_Y, m_stc1stY);
	DDX_Control(pDX, IDC_STATIC_1ST_X, m_stc1stX);
	DDX_Control(pDX, IDC_STATIC_1ST_R, m_stc1stR);
	DDX_Control(pDX, IDC_STATIC_2ND_R, m_stc2ndR);
	DDX_Control(pDX, IDC_STATIC_2ND_CAL_PATH, m_stc2ndCalPath);
	DDX_Control(pDX, IDC_STATIC_1ST_CAL_PATH, m_stc1stCalPath);
	DDX_Control(pDX, IDC_CHECK_SAVE_CAL_RESULT_FILE, m_chkSaveCalResultFile);
	DDX_Control(pDX, IDC_CHECK_APPLY_CAL_RESULT, m_chkApplyCalResult);
	DDX_Control(pDX, IDC_BUTTON_2ND_CAL, m_btn2ndCal);
	DDX_Control(pDX, IDC_BUTTON_1ST_CAL, m_btn1stCal);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgCalResult, CDialog)
	//{{AFX_MSG_MAP(CDlgCalResult)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_1ST_CAL, OnButton1stCal)
	ON_BN_CLICKED(IDC_BUTTON_2ND_CAL, OnButton2ndCal)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgCalResult message handlers

BOOL CDlgCalResult::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitBtnControl();
	InitStaticControl();

	CString strMaster, strSlave;
	strMaster.Format(_T("%s"), m_c1st1ASC);
	strSlave.Format(_T("%s"), m_c2nd1ASC);
	m_stc1stCalPath.SetWindowText(strMaster);
	m_stc2ndCalPath.SetWindowText(strSlave);

	m_bShow = TRUE;

	if(ReadCalOffsetFile())
	{
		m_nTimerID = SetTimer( 398, 5000, NULL );
		m_hEndView = ::CreateEvent(NULL, TRUE, TRUE, NULL);
	}
	else
		EndDialog(IDCANCEL);

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		GetDlgItem(IDC_STATIC_2ND_X)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_2ND_Y)->EnableWindow(FALSE);
		m_stc2ndX.SetWindowText("NO USE");
		m_stc2ndY.SetWindowText("NO USE");
		m_stc2ndR.SetWindowText("NO USE");
		
		GetDlgItem(IDC_STATIC_2ND_CAL_PATH)->EnableWindow(FALSE);
		m_stc2ndCalPath.SetWindowText("NO USE");
		
		GetDlgItem(IDC_STATIC_2ND_PANEL_GRAPH)->ShowWindow(SW_HIDE);

		CRect rtPos;
		GetDlgItem(IDC_STATIC_1ST_PANEL_GRAPH)->GetWindowRect( rtPos );
		GetDlgItem(IDC_STATIC_1ST_PANEL_GRAPH)->MoveWindow( rtPos.left + 50, rtPos.top - 50, rtPos.Width(), rtPos.Height(), TRUE );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgCalResult::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// 1st Cal Path
	m_btn1stCal.SetFont( &m_fntBtn );
	m_btn1stCal.SetFlat( FALSE );
	m_btn1stCal.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btn1stCal.EnableBallonToolTip();
	m_btn1stCal.SetToolTipText( _T("1st Panel Calibration File") );
	m_btn1stCal.SetBtnCursor(IDC_HAND_1);

	// 2nd Cal Path
	m_btn2ndCal.SetFont( &m_fntBtn );
	m_btn2ndCal.SetFlat( FALSE );
	m_btn2ndCal.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btn2ndCal.EnableBallonToolTip();
	m_btn2ndCal.SetToolTipText( _T("2nd Panel Calibration File") );
	m_btn2ndCal.SetBtnCursor(IDC_HAND_1);

	// Apply(OK)
	m_btnApply.SetFont( &m_fntBtn );
	m_btnApply.SetFlat( FALSE );
	m_btnApply.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApply.EnableBallonToolTip();
	m_btnApply.SetToolTipText( _T("Apply") );
	m_btnApply.SetBtnCursor(IDC_HAND_1);

	// Cancel
	m_btnCancel.SetFont( &m_fntBtn );
	m_btnCancel.SetFlat( FALSE );
	m_btnCancel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCancel.EnableBallonToolTip();
	m_btnCancel.SetToolTipText( _T("Cancel") );
	m_btnCancel.SetBtnCursor(IDC_HAND_1);

	// Apply the calibration result
	m_chkApplyCalResult.SetFont( &m_fntBtn );
	m_chkApplyCalResult.SetImageOrg( 10, 3 );
	m_chkApplyCalResult.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkApplyCalResult.EnableBallonToolTip();
	m_chkApplyCalResult.SetToolTipText( _T("Apply the calibration result") );
	m_chkApplyCalResult.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_chkApplyCalResult.SetBtnCursor(IDC_HAND_1);

	// Save the calibration result to file 
	m_chkSaveCalResultFile.SetFont( &m_fntBtn );
	m_chkSaveCalResultFile.SetImageOrg( 10, 3 );
	m_chkSaveCalResultFile.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkSaveCalResultFile.EnableBallonToolTip();
	m_chkSaveCalResultFile.SetToolTipText( _T("Save the calibration result to file") );
	m_chkSaveCalResultFile.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_chkSaveCalResultFile.SetBtnCursor(IDC_HAND_1);
}

void CDlgCalResult::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_STATIC_MAX_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_R)->SetFont( &m_fntStatic );

	m_stc1stX.SetFont( &m_fntStatic );
	m_stc1stX.SetForeColor( VALUE_FORE_COLOR );
	m_stc1stX.SetBackColor( VALUE_BACK_COLOR );

	m_stc1stY.SetFont( &m_fntStatic );
	m_stc1stY.SetForeColor( VALUE_FORE_COLOR );
	m_stc1stY.SetBackColor( VALUE_BACK_COLOR );

	m_stc2ndX.SetFont( &m_fntStatic );
	m_stc2ndX.SetForeColor( VALUE_FORE_COLOR );
	m_stc2ndX.SetBackColor( VALUE_BACK_COLOR );

	m_stc2ndY.SetFont( &m_fntStatic );
	m_stc2ndY.SetForeColor( VALUE_FORE_COLOR );
	m_stc2ndY.SetBackColor( VALUE_BACK_COLOR );

	m_stc1stR.SetFont( &m_fntStatic );
	m_stc1stR.SetForeColor( VALUE_FORE_COLOR );
	m_stc1stR.SetBackColor( VALUE_BACK_COLOR );

	m_stc2ndR.SetFont( &m_fntStatic );
	m_stc2ndR.SetForeColor( VALUE_FORE_COLOR );
	m_stc2ndR.SetBackColor( VALUE_BACK_COLOR );

	GetDlgItem(IDC_STATIC_CAL_FILE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_CAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_CAL)->SetFont( &m_fntStatic );

	//m_stc1stCalPath.SetFont( &m_fntStatic );
	m_stc1stCalPath.SetForeColor( VALUE_FORE_COLOR );
	m_stc1stCalPath.SetBackColor( VALUE_BACK_COLOR );

	//m_stc2ndCalPath.SetFont( &m_fntStatic );
	m_stc2ndCalPath.SetForeColor( VALUE_FORE_COLOR );
	m_stc2ndCalPath.SetBackColor( VALUE_BACK_COLOR );
}

HBRUSH CDlgCalResult::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_MAX_VAL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_CAL_FILE)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CDlgCalResult::OnButton1stCal() 
{
	TCHAR BASED_CODE szFilter[] = _T("asc Files (*.asc)|*.asc|All Files (*.*)|*.*||");

	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	CString strPath( gEasyDrillerINI.m_clsDirPath.GetCorrectDir() );

	CFileDialog dlg(FALSE, _T("*.asc"), NULL, dwFlags, szFilter);

	dlg.m_ofn.lpstrInitialDir = (LPCTSTR)strPath;

	if(IDOK != dlg.DoModal())
		return;

	strPath.Format(_T("%s"), dlg.GetPathName());
	m_stc1stCalPath.SetWindowText( (LPCTSTR)strPath );
	gEasyDrillerINI.m_clsDirPath.Set1stMasterCalFilePath(strPath);
}

void CDlgCalResult::OnButton2ndCal() 
{
	TCHAR BASED_CODE szFilter[] = _T("asc Files (*.asc)|*.asc|All Files (*.*)|*.*||");

	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	CString strPath( gEasyDrillerINI.m_clsDirPath.GetCorrectDir() );

	CFileDialog dlg(FALSE, _T("*.asc"), NULL, dwFlags, szFilter);

	dlg.m_ofn.lpstrInitialDir = (LPCTSTR)strPath;

	if(IDOK != dlg.DoModal())
		return;

	strPath.Format(_T("%s"), dlg.GetPathName());
	m_stc2ndCalPath.SetWindowText( (LPCTSTR)strPath );
	gEasyDrillerINI.m_clsDirPath.Set2ndMasterCalFilePath(strPath);
}

void CDlgCalResult::Show1stPanelOffset()
{
	if (m_nGridSize == 0)
		return;

	::ResetEvent(m_hEndView);
	
	Show1stPanelBackGround();

	CWnd* pGraph = GetDlgItem(IDC_STATIC_1ST_PANEL_GRAPH);
	CClientDC dc(pGraph);
	CRect cRect;
	pGraph->GetClientRect(&cRect);
	cRect.DeflateRect(1, 1);
	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	dc.SelectClipRgn(&cRgn);

	int nXOffset = static_cast<int>(cRect.Width() / static_cast<double>(12));
	int nYOffset = static_cast<int>(cRect.Height() / static_cast<double>(12));
	
	dc.SetMapMode(MM_ANISOTROPIC);
	dc.SetWindowOrg(0, 0);
	dc.SetViewportOrg(nXOffset, cRect.Height() - nYOffset);
	dc.SetViewportExt(cRect.Width(), -cRect.Height());
	dc.SetWindowExt((m_nGridSize - 1) * 1200, (m_nGridSize - 1) * 1200);

	int nRadius, nPenSize;

	switch(m_nGridSize)
	{
	case 3:
	case 5:
		nPenSize = 40;
		nRadius = 100;
		break;
	case 9:
		nPenSize = 70;
		nRadius = 200;
		break;
	case 17:
		nPenSize = 60;
		nRadius = 200;
		break;
	default:
		nPenSize = 10;
		nRadius = 20;
		break;
	}

	const double dMaxOffset = 10;

	CPen pen;
	CPen* pOldPen;
	CBrush cBr;
	CBrush* pOldBrush;
	int nRatio = 400;
	if (m_dMaxOffsetMasterX <= dMaxOffset && m_dMaxOffsetMasterY <= dMaxOffset)
	{
		pen.CreatePen(PS_SOLID, nPenSize, RGB(0, 0, 200));
		pOldPen = dc.SelectObject(&pen);

		cBr.CreateSolidBrush(RGB(0, 0, 200));
		pOldBrush = dc.SelectObject(&cBr);
	}
	else
	{
		pen.CreatePen(PS_SOLID, nPenSize, RGB(200, 0, 0));
		pOldPen = dc.SelectObject(&pen);

		cBr.CreateSolidBrush(RGB(200, 0, 0));
		pOldBrush = dc.SelectObject(&cBr);
	}

	// m_ptMasterGridOffset[] ����� ����
	// 2 5 8
	// 1 4 7
	// 0 3 6
	int nX, nY;
	for (int i = 0; i < m_nGridSize; i++)
	{
		for (int j = 0; j < m_nGridSize; j++)
		{
//			nX = i * 1000 + static_cast<int>(nRatio * 1000 * m_ptMasterGridOffset[i * m_nGridSize + j].x / m_dMaxOffsetMasterX + 0.5);
//			nY = j * 1000 + static_cast<int>(nRatio * 1000 * m_ptMasterGridOffset[i * m_nGridSize + j].y / m_dMaxOffsetMasterY + 0.5);

			nX = i * 1000 + static_cast<int>(nRatio * 1000 * m_ptMasterGridOffset[(m_nGridSize - i - 1) * m_nGridSize + j].x / m_dMaxOffsetMasterX + 0.5);
			nY = j * 1000 + static_cast<int>(nRatio * 1000 * m_ptMasterGridOffset[(m_nGridSize - i - 1) * m_nGridSize + j].y / m_dMaxOffsetMasterY + 0.5);
				
			if (j == 0)
				dc.MoveTo(nX, nY);
			else
				dc.LineTo(nX, nY);

			dc.Ellipse(nX - nRadius, nY - nRadius, nX + nRadius, nY + nRadius);
		}
	}

	for(int i =  0; i < m_nGridSize; i++)
	{
		for (int j = 0; j < m_nGridSize; j++)
		{
//			nX = j * 1000 + static_cast<int>(nRatio * 1000 * m_ptMasterGridOffset[j * m_nGridSize + i].x / m_dMaxOffsetMasterX + 0.5);
//			nY = i * 1000 + static_cast<int>(nRatio * 1000 * m_ptMasterGridOffset[j * m_nGridSize + i].y / m_dMaxOffsetMasterY + 0.5);

			nX = j * 1000 + static_cast<int>(nRatio * 1000 * m_ptMasterGridOffset[(m_nGridSize - j - 1) * m_nGridSize + i].x / m_dMaxOffsetMasterX + 0.5);
			nY = i * 1000 + static_cast<int>(nRatio * 1000 * m_ptMasterGridOffset[(m_nGridSize - j - 1) * m_nGridSize + i].y / m_dMaxOffsetMasterY + 0.5);
			
			if (j == 0)
				dc.MoveTo(nX, nY);
			else
				dc.LineTo(nX, nY);

			dc.Ellipse(nX - nRadius, nY - nRadius, nX + nRadius, nY + nRadius);
		}
	}

	dc.SelectObject(pOldBrush);
	dc.SelectObject(pOldPen);

	::SetEvent(m_hEndView);
}

void CDlgCalResult::Show1stPanelBackGround()
{
	CClientDC dc(GetDlgItem(IDC_STATIC_1ST_PANEL_GRAPH));
	CRect cRect;
	GetDlgItem(IDC_STATIC_1ST_PANEL_GRAPH)->GetClientRect(&cRect);
	CBrush cBr(RGB(0, 0, 0));
	dc.FrameRect(&cRect, &cBr);
	cRect.DeflateRect(1, 1);
	dc.FillSolidRect(&cRect, RGB(255, 255, 255));

	int nXOffset = static_cast<int>(cRect.Width() / static_cast<double>(12));
	int nYOffset = static_cast<int>(cRect.Height() / static_cast<double>(12));
	int nViewSize = (m_nGridSize - 1)* 1000;

	dc.SetMapMode(MM_ANISOTROPIC);
	dc.SetWindowOrg(0, 0);
	dc.SetViewportOrg(nXOffset, cRect.Height() - nYOffset);
	dc.SetViewportExt(cRect.Width(), -cRect.Height());
	dc.SetWindowExt((m_nGridSize - 1) * 1200, (m_nGridSize - 1) * 1200);

	for (int i = 0; i < m_nGridSize; i++)
	{
		dc.MoveTo(0, i * 1000);
		dc.LineTo(nViewSize, i * 1000);
	}
	for(int i =  0; i < m_nGridSize; i++)
	{
		dc.MoveTo(i * 1000, 0);
		dc.LineTo(i * 1000, nViewSize);
	}
}

void CDlgCalResult::Show2ndPanelOffset()
{
	if (m_nGridSize == 0)
		return;

	::ResetEvent(m_hEndView);

	Show2ndPanelBackGround();
	
	CWnd* pGraph = GetDlgItem(IDC_STATIC_2ND_PANEL_GRAPH);
	CClientDC dc(pGraph);
	CRect cRect;
	pGraph->GetClientRect(&cRect);
	cRect.DeflateRect(1, 1);
	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	dc.SelectClipRgn(&cRgn);
	
	int nXOffset = static_cast<int>(cRect.Width() / static_cast<double>(12));
	int nYOffset = static_cast<int>(cRect.Height() / static_cast<double>(12));
	
	dc.SetMapMode(MM_ANISOTROPIC);
	dc.SetWindowOrg(0, 0);
	dc.SetViewportOrg(nXOffset, cRect.Height() - nYOffset);
	dc.SetViewportExt(cRect.Width(), -cRect.Height());
	dc.SetWindowExt((m_nGridSize - 1) * 1200, (m_nGridSize - 1) * 1200);
	
	int nRadius, nPenSize;
	
	switch(m_nGridSize)
	{
	case 3:
	case 5:
		nPenSize = 40;
		nRadius = 100;
		break;
	case 9:
		nPenSize = 70;
		nRadius = 200;
		break;
	case 17:
		nPenSize = 60;
		nRadius = 200;
		break;
	default:
		nPenSize = 10;
		nRadius = 20;
		break;
	}

	const double dMaxOffset = 10.;
	
	CPen pen;
	CPen* pOldPen;
	CBrush cBr;
	CBrush* pOldBrush;
	int nRatio = 400;
	if (m_dMaxOffsetSlaveX <= dMaxOffset && m_dMaxOffsetSlaveY <= dMaxOffset)
	{
		pen.CreatePen(PS_SOLID, nPenSize, RGB(0, 0, 200));
		pOldPen = dc.SelectObject(&pen);
		
		cBr.CreateSolidBrush(RGB(0, 0, 200));
		pOldBrush = dc.SelectObject(&cBr);
	}
	else
	{
		pen.CreatePen(PS_SOLID, nPenSize, RGB(200, 0, 0));
		pOldPen = dc.SelectObject(&pen);
		
		cBr.CreateSolidBrush(RGB(200, 0, 0));
		pOldBrush = dc.SelectObject(&cBr);
	}
	
	int nX, nY;
	for (int i = 0; i < m_nGridSize; i++)
	{
		for (int j = 0; j < m_nGridSize; j++)
		{
//			nX = i * 1000 + static_cast<int>(nRatio * 1000 * m_ptSlaveGridOffset[i * m_nGridSize + j].x / m_dMaxOffsetSlaveX + 0.5);
//			nY = j * 1000 + static_cast<int>(nRatio * 1000 * m_ptSlaveGridOffset[i * m_nGridSize + j].y / m_dMaxOffsetSlaveY + 0.5);

			nX = i * 1000 + static_cast<int>(nRatio * 1000 * m_ptSlaveGridOffset[(m_nGridSize - i - 1) * m_nGridSize + j].x / m_dMaxOffsetSlaveX + 0.5);
			nY = j * 1000 + static_cast<int>(nRatio * 1000 * m_ptSlaveGridOffset[(m_nGridSize - i - 1) * m_nGridSize + j].y / m_dMaxOffsetSlaveX + 0.5);
			
			if (j == 0)
				dc.MoveTo(nX, nY);
			else
				dc.LineTo(nX, nY);
			
			dc.Ellipse(nX - nRadius, nY - nRadius, nX + nRadius, nY + nRadius);
		}
	}
	for(int i =  0; i < m_nGridSize; i++)
	{
		for (int j = 0; j < m_nGridSize; j++)
		{
//			nX = j * 1000 + static_cast<int>(nRatio * 1000 * m_ptSlaveGridOffset[j * m_nGridSize + i].x / m_dMaxOffsetSlaveX + 0.5);
//			nY = i * 1000 + static_cast<int>(nRatio * 1000 * m_ptSlaveGridOffset[j * m_nGridSize + i].y / m_dMaxOffsetSlaveY + 0.5);

			nX = j * 1000 + static_cast<int>(nRatio * 1000 * m_ptSlaveGridOffset[(m_nGridSize - j - 1) * m_nGridSize + i].x / m_dMaxOffsetSlaveX + 0.5);
			nY = i * 1000 + static_cast<int>(nRatio * 1000 * m_ptSlaveGridOffset[(m_nGridSize - j - 1) * m_nGridSize + i].y / m_dMaxOffsetSlaveX + 0.5);
			
			if (j == 0)
				dc.MoveTo(nX, nY);
			else
				dc.LineTo(nX, nY);
			
			dc.Ellipse(nX - nRadius, nY - nRadius, nX + nRadius, nY + nRadius);
		}
	}
	
	dc.SelectObject(pOldBrush);
	dc.SelectObject(pOldPen);

	::SetEvent(m_hEndView);
}

void CDlgCalResult::Show2ndPanelBackGround()
{
	CClientDC dc(GetDlgItem(IDC_STATIC_2ND_PANEL_GRAPH));
	CRect cRect;
	GetDlgItem(IDC_STATIC_2ND_PANEL_GRAPH)->GetClientRect(&cRect);
	CBrush cBr(RGB(0, 0, 0));
	dc.FrameRect(&cRect, &cBr);
	cRect.DeflateRect(1, 1);
	dc.FillSolidRect(&cRect, RGB(255, 255, 255));
	
	int nXOffset = static_cast<int>(cRect.Width() / static_cast<double>(12));
	int nYOffset = static_cast<int>(cRect.Height() / static_cast<double>(12));
	int nViewSize = (m_nGridSize - 1) * 1000;
	
	dc.SetMapMode(MM_ANISOTROPIC);
	dc.SetWindowOrg(0, 0);
	dc.SetViewportOrg(nXOffset, cRect.Height() - nYOffset);
	dc.SetViewportExt(cRect.Width(), -cRect.Height());
	dc.SetWindowExt((m_nGridSize - 1) * 1200, (m_nGridSize - 1) * 1200);
	
	for (int i = 0; i < m_nGridSize; i++)
	{
		dc.MoveTo(0, i * 1000);
		dc.LineTo(nViewSize, i * 1000);
	}
	for(int i =  0; i < m_nGridSize; i++)
	{
		dc.MoveTo(i * 1000, 0);
		dc.LineTo(i * 1000, nViewSize);
	}
}

void CDlgCalResult::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	if( m_bShow )
	{
		Show1stPanelOffset();
		Show2ndPanelOffset();
	}
	// Do not call CDialog::OnPaint() for painting messages
}

void CDlgCalResult::OnTimer(UINT nIDEvent) 
{
	if( FALSE == m_bOnTimer )
	{
		m_bOnTimer	= TRUE;

		if( m_bShow )
		{
			Show1stPanelOffset();
			Show2ndPanelOffset();
		}

		m_bOnTimer	= FALSE;
	}
	
	CDialog::OnTimer(nIDEvent);
}

void CDlgCalResult::OnOK() 
{
	if(m_nTimerID)
	{
		KillTimer( m_nTimerID );
		m_nTimerID = 0;
	}

	UpdateData(TRUE);

	if (!SaveRawFile())
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_CREATE);
		strMsg.Format(strString, "ASC Raw");
		ErrMessage(strMsg);

		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
//		CDialog::OnOK();
		return;
	}

	CCalViaHole* pCalibration = NULL;
	TRY
	{
		pCalibration = new CCalViaHole;
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		return;
	}
	END_CATCH

	CString strMaster, strSlave;
	strMaster.Format(_T("%s"), m_c1st1ASC);
	strSlave.Format(_T("%s"), m_c2nd1ASC);

	TCHAR sz1stBackupFile[255], sz2ndBackupFile[255];
	lstrcpy(sz1stBackupFile, gEasyDrillerINI.m_clsDirPath.Get1stMasterCalFilePath());
	lstrcpy(sz2ndBackupFile, gEasyDrillerINI.m_clsDirPath.Get2ndMasterCalFilePath());
	gEasyDrillerINI.m_clsDirPath.Set1stMasterCalFilePath(strMaster);
	gEasyDrillerINI.m_clsDirPath.Set2ndMasterCalFilePath(strSlave);
		
	if (pCalibration)
	{
/*		if (!pCalibration->Calibration())
		{
			gEasyDrillerINI.m_clsDirPath.Set1stMasterCalFilePath(sz1stBackupFile);
			gEasyDrillerINI.m_clsDirPath.Set2ndMasterCalFilePath(sz2ndBackupFile);

			delete pCalibration;
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_FILE_CREATE);
			strMsg.Format(strString, "ASC Calibration");
			ErrMessage(strMsg);

			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
			return;
		}
*/		delete pCalibration;
	}

	if(m_pcalAGCMaster)
	{
		if(0 != m_pcalAGCMaster->CreateAGCFile())
		{
			gEasyDrillerINI.m_clsDirPath.Set1stMasterCalFilePath(sz1stBackupFile);
			gEasyDrillerINI.m_clsDirPath.Set2ndMasterCalFilePath(sz2ndBackupFile);
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_FILE_CREATE);
			strMsg.Format(strString, "ASC Calibration");
			ErrMessage(strMsg);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
			return;
		}
		SaveScalTimeLog(TRUE, strMaster);
	}
	if(m_pcalAGCSlave)
	{
		if(0 != m_pcalAGCSlave->CreateAGCFile())
		{
			gEasyDrillerINI.m_clsDirPath.Set1stMasterCalFilePath(sz1stBackupFile);
			gEasyDrillerINI.m_clsDirPath.Set2ndMasterCalFilePath(sz2ndBackupFile);
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_FILE_CREATE);
			strMsg.Format(strString, "ASC Calibration");
			ErrMessage(strMsg);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
			return;
		}
		SaveScalTimeLog(FALSE, strSlave);
	}

//	TCHAR sz1stFile[255], sz2ndFile[255];
//	lstrcpy(sz1stFile, gEasyDrillerINI.m_clsDirPath.Get1stMasterCalFilePath());
//	lstrcpy(sz2ndFile, gEasyDrillerINI.m_clsDirPath.Get2ndMasterCalFilePath());

//	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
//		strcpy_s(sz2ndFile, sz1stFile);

	if(!SetCalMatrix(m_c1st1ASC, m_c2nd1ASC))
	{
		gEasyDrillerINI.m_clsDirPath.Set1stMasterCalFilePath(sz1stBackupFile);
		gEasyDrillerINI.m_clsDirPath.Set2ndMasterCalFilePath(sz2ndBackupFile);
		
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
		strMsg.Format(strString, "ASC");
		ErrMessage(strMsg);

		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		return;
	}

	CString strEvent, strInfo;
	strEvent = _T("Applyed automatic scanner calibration result and make asc file.");

	strInfo.Format(_T("1st Panel asc file = %s | 2nd Panel asc file = %s | 1st Panel Head Max. error ( X = %f um, Y = %f um, R = %f um) | 2nd Panel Head Max. error ( X = %fum, Y = %f um, R = %f um )"),
		gEasyDrillerINI.m_clsDirPath.Get1stMasterCalFilePath(), gEasyDrillerINI.m_clsDirPath.Get2ndMasterCalFilePath(), m_dMaxOffsetMasterX, m_dMaxOffsetMasterY, m_dMaxOffsetMasterR, m_dMaxOffsetSlaveX, m_dMaxOffsetSlaveY, m_dMaxOffsetSlaveR);

	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
	
// 	time_t timeApply;
// 	time(&timeApply);
	
	if(m_nSelectHead == SEL_HEAD_MASTER)
	{
//		gProcessINI.m_sProcessCal.n1stCalTime = timeApply;

		gProcessINI.m_sProcessScannerCal.dScanMasterX = gProcessINI.m_sProcessScannerCal.dScanXTemp;
		gProcessINI.m_sProcessScannerCal.dScanMasterY = gProcessINI.m_sProcessScannerCal.dScanYTemp;
		gProcessINI.m_sProcessScannerCal.dMasterCalTablePosX = m_dCalTablePosX;
		gProcessINI.m_sProcessScannerCal.dMasterCalTablePosY = m_dCalTablePosY;
	}
	else if(m_nSelectHead == SEL_HEAD_SLAVE)
	{
//		gProcessINI.m_sProcessCal.n2ndCalTime = timeApply;
		
		gProcessINI.m_sProcessScannerCal.dScanSlaveX = gProcessINI.m_sProcessScannerCal.dScanXTemp;
		gProcessINI.m_sProcessScannerCal.dScanSlaveY = gProcessINI.m_sProcessScannerCal.dScanYTemp;	
		gProcessINI.m_sProcessScannerCal.dSlaveCalTablePosX = m_dCalTablePosX;
		gProcessINI.m_sProcessScannerCal.dSlaveCalTablePosY = m_dCalTablePosY;
	}
	else
	{
//		gProcessINI.m_sProcessCal.n1stCalTime = timeApply;
//		gProcessINI.m_sProcessCal.n2ndCalTime = timeApply;
		
		gProcessINI.m_sProcessScannerCal.dScanMasterX = gProcessINI.m_sProcessScannerCal.dScanXTemp;
		gProcessINI.m_sProcessScannerCal.dScanMasterY = gProcessINI.m_sProcessScannerCal.dScanYTemp;	
		gProcessINI.m_sProcessScannerCal.dScanSlaveX = gProcessINI.m_sProcessScannerCal.dScanXTemp;
		gProcessINI.m_sProcessScannerCal.dScanSlaveY = gProcessINI.m_sProcessScannerCal.dScanYTemp;	

		gProcessINI.m_sProcessScannerCal.dMasterCalTablePosX = m_dCalTablePosX;
		gProcessINI.m_sProcessScannerCal.dMasterCalTablePosY = m_dCalTablePosY;
		gProcessINI.m_sProcessScannerCal.dSlaveCalTablePosX = m_dCalTablePosX;
		gProcessINI.m_sProcessScannerCal.dSlaveCalTablePosY = m_dCalTablePosY;
	}

	gProcessINI.m_sProcessScannerCal.dMaxOffsetMasterX = m_dMaxOffsetMasterX;
	gProcessINI.m_sProcessScannerCal.dMaxOffsetMasterY = m_dMaxOffsetMasterY;
	gProcessINI.m_sProcessScannerCal.dMaxOffsetSlaveX = m_dMaxOffsetSlaveX;
	gProcessINI.m_sProcessScannerCal.dMaxOffsetSlaveY = m_dMaxOffsetSlaveY;

	
	int nCount = gBeamPathINI.m_sBeampath.nLastIndex;
	TCHAR cASC[256] ={0,};
	
	_stprintf_s(cASC, gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_nTool]);
	
	time_t timeNow;
	time(&timeNow);

	CString strFile, strLog;
	strFile.Format(_T("PreWork"));
	
	if(m_nGridSize > 5)
	{
		for(int j =0; j<=nCount; j++)  
		{
			if(strcmp(cASC, gBeamPathINI.m_sBeampath.strBeamPathAscFile[j]) == 0)
			{
				if(m_bDrillingLimitOK[0])
				{
					if(m_nSelectHead != SEL_HEAD_SLAVE)
					{
						if((m_d1stTemperature >= gProcessINI.m_sProcessOption.dTemperMinTLimit && m_d1stTemperature <= gProcessINI.m_sProcessOption.dTemperMaxTLimit) || // &&
//							m_d1stSBTemperature >= gProcessINI.m_sProcessOption.dTemperMinTLimit && m_d1stSBTemperature <= gProcessINI.m_sProcessOption.dTemperMaxTLimit) ||
							!gProcessINI.m_sProcessOption.bTemperCompensationMode)
						{
							gTempINI.m_sTempTime.nAutoScalEndTime[j][0] = (int)timeNow;
							strLog.Format(_T("Manual ScannerSaveTime 1st [%d] = %d"), j, timeNow);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

							gTempINI.m_sTempTime.dAutoScalTemperature[j][0] = m_d1stTemperature;
							if(m_bFullCoolingAGC)
							{
								gDeviceFactory.Get1stTemperCompen()->SetRefTemperature(m_d1stTemperature);
								gDeviceFactory.Get1stTemperCompen()->SetAutoRunLastTemperature(m_d1stTemperature + gProcessINI.m_sProcessOption.dTemperEndT);
							}
							gTempINI.m_sTempTime.dAutoScalEndTemperature[j][0] = gDeviceFactory.Get1stTemperCompen()->GetAutoRunLastTemperature();
							if(gTempINI.m_sTempTime.dAutoScalTemperature[j][0] > gTempINI.m_sTempTime.dAutoScalEndTemperature[j][0])
								gTempINI.m_sTempTime.dAutoScalTemperature[j][0] = gTempINI.m_sTempTime.dAutoScalEndTemperature[j][0];
							strLog.Format(_T("Manual ScannerSave Temperature 1st [%d] = %.4f, %.4f, FullCoolingAGC = %d, AGC Last T = %.4f"), j, m_d1stTemperature, m_d1stTemperature + gProcessINI.m_sProcessOption.nTemperDutyStepNo * gProcessINI.m_sProcessOption.nTemperStepDuty, m_bFullCoolingAGC,  gDeviceFactory.Get1stTemperCompen()->GetAutoRunLastTemperature());
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							gDeviceFactory.Get1stTemperCompen()->SetAutoRunStartTemperature(m_d1stTemperature);
						}
					}
				}
				if(m_bDrillingLimitOK[1])
				{
					if (m_nSelectHead != SEL_HEAD_MASTER)
					{
						if((m_d2ndTemperature >= gProcessINI.m_sProcessOption.dTemperMinTLimit && m_d2ndTemperature <= gProcessINI.m_sProcessOption.dTemperMaxTLimit) || // &&
//							m_d2ndSBTemperature >= gProcessINI.m_sProcessOption.dTemperMinTLimit && m_d2ndSBTemperature <= gProcessINI.m_sProcessOption.dTemperMaxTLimit) ||
							!gProcessINI.m_sProcessOption.bTemperCompensationMode)
						{
							gTempINI.m_sTempTime.nAutoScalEndTime[j][1] = (int)timeNow;
							strLog.Format(_T("Manual ScannerSaveTime 2nd [%d] = %d"), j, timeNow);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

							gTempINI.m_sTempTime.dAutoScalTemperature[j][1] = m_d2ndTemperature;
							if(m_bFullCoolingAGC)
							{
								gDeviceFactory.Get2ndTemperCompen()->SetRefTemperature(m_d2ndTemperature);
								gDeviceFactory.Get2ndTemperCompen()->SetAutoRunLastTemperature(m_d2ndTemperature + gProcessINI.m_sProcessOption.dTemperEndT);
							}
							gTempINI.m_sTempTime.dAutoScalEndTemperature[j][1] =gDeviceFactory.Get2ndTemperCompen()->GetAutoRunLastTemperature();
							if(gTempINI.m_sTempTime.dAutoScalTemperature[j][1] > gTempINI.m_sTempTime.dAutoScalEndTemperature[j][1])
								gTempINI.m_sTempTime.dAutoScalTemperature[j][1] = gTempINI.m_sTempTime.dAutoScalEndTemperature[j][1];
							strLog.Format(_T("Manual ScannerSave Temperature 2nd [%d] = %.4f, %.4f, FullCoolingAGC = %d, AGC Last T = %.4f"), j, m_d2ndTemperature, m_d2ndTemperature + gProcessINI.m_sProcessOption.nTemperDutyStepNo * gProcessINI.m_sProcessOption.nTemperStepDuty, m_bFullCoolingAGC,  gDeviceFactory.Get2ndTemperCompen()->GetAutoRunLastTemperature());
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							gDeviceFactory.Get2ndTemperCompen()->SetAutoRunStartTemperature(m_d2ndTemperature);
						}
					}
				}
			}
		}
	}

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, TEMP_INI))
		ErrMsgDlg(STDGNALM119);
	// Save Process INI File
//	CProcessINIFile clsProcessINI;
	
//	strEvent.Format(_T("%sProcess.ini"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	
	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
		ErrMsgDlg(STDGNALM108);
	
	::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, PROCESS_PREWORK);
//	clsProcessINI.SaveProcessINIFile( strEvent, gProcessINI );
	CDialog::OnOK();
}

void CDlgCalResult::SetTemperature(BOOL bFullCooling, double d1st, double d2nd, double d1stSB, double d2ndSB, double* pTempVal)
{
	m_d1stTemperature = d1st;
	m_d2ndTemperature = d2nd;
	m_d1stSBTemperature = d1stSB;
	m_d2ndSBTemperature = d2ndSB;
	memcpy(m_dAllTemper, pTempVal, sizeof(m_dAllTemper));
	m_bFullCoolingAGC = bFullCooling;
}

void CDlgCalResult::OnCancel() 
{
	if(m_nTimerID)
	{
		KillTimer( m_nTimerID );
		m_nTimerID = 0;
	}

	::WaitForSingleObject(m_hEndView, INFINITE);
	
	CString strEvent, strInfo;
	strEvent = _T("Canceled automatic scanner calibration result.");
	strInfo.Format(_T("1st Panel Head Max. error ( X = %f um, Y = %f um, R = %f ) | 2nd Panel Head Max. error ( X = %f um, Y = %f um, R = %f )"),
		m_dMaxOffsetMasterX, m_dMaxOffsetMasterY, m_dMaxOffsetMasterR, m_dMaxOffsetSlaveX, m_dMaxOffsetMasterR, m_dMaxOffsetSlaveY, m_dMaxOffsetSlaveR, m_dMaxOffsetSlaveR);

	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
	
	CDialog::OnCancel();
}

BOOL CDlgCalResult::DestroyWindow() 
{
	m_fntBtn.DeleteObject();
	m_fntStatic.DeleteObject();
	
	return CDialog::DestroyWindow();
}

void CDlgCalResult::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here	
}

void CDlgCalResult::SetSelectHead(int nSelHead)
{
	m_nSelectHead = nSelHead;
}

void CDlgCalResult::SetAutoProcessMode()
{
	m_bIsAutoProcessMode = TRUE;
}

BOOL CDlgCalResult::SaveRawFile()
{
	CString strFilePath = gEasyDrillerINI.m_clsDirPath.GetConvertedDir();
	strFilePath += _T("CalOffset.txt");
	
	CFile file;
	if(!file.Open(strFilePath, CFile::modeRead))
		return FALSE;
	
	TCHAR *cFileView = NULL;
	DWORD dwFileSize;							//File size
	TRY 
	{
		dwFileSize = (DWORD)file.GetLength();				// ������ ���̸� ����
		cFileView = new TCHAR[dwFileSize];			// ����ũ�� ��ŭ �޸��Ҵ� 
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;
		
		return FALSE;
	}
	AND_CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		
		return FALSE;
	}
	END_CATCH
		
	TRY
	{
		file.Read(cFileView, dwFileSize);
		if (file.m_hFile != CFile::hFileNull)
			file.Close();
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;
		
		return FALSE;
	}
	END_CATCH
		
	strFilePath = gEasyDrillerINI.m_clsDirPath.GetBackupDir();
	strFilePath += _T("CalOffsetApplied");
	CTime cTime = CTime::GetCurrentTime();
	CString strFileName = cTime.Format(_T("%Y%m%d%H%M"));
	strFilePath += strFileName + _T(".txt");
	
	if(!file.Open(strFilePath, CFile::modeCreate | CFile::modeWrite))
	{
		delete [] cFileView;
		return FALSE;
	}
	
	TRY
	{
		file.Write(cFileView, dwFileSize);
		file.Close();
		delete [] cFileView;
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;
		
		return FALSE;
	}
	END_CATCH
		
	return TRUE;
}

BOOL CDlgCalResult::ReadCalOffsetFile()
{
	m_dMaxOffsetMasterX = m_dMaxOffsetMasterY = m_dMaxOffsetSlaveX = m_dMaxOffsetSlaveY = m_dMaxOffsetMasterR = m_dMaxOffsetSlaveR = 0.0;
	double dMaxTemp = 0.0;
	int LineNum, MaxLineNum;	//Data number
	TCHAR buf[100];				//buffer
	int i,j=0;
	int M_size;					//Matrix Size

	CString strFilePath = gEasyDrillerINI.m_clsDirPath.GetConvertedDir();
	strFilePath += _T("CalOffset.txt");

	CFile file;
	TCHAR *cFileView = NULL, *data = NULL;
	if(!file.Open(strFilePath, CFile::modeRead)) 	// �б� ���� ���� ����
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("Calibration Offset"));
		ErrMessage(strMsg);
		return FALSE;
	}

	DWORD dwFileSize;							//File size
	TRY
	{
		dwFileSize = (DWORD)file.GetLength();				// ������ ���̸� ����
		cFileView = new TCHAR[dwFileSize + 2];			// ����ũ�� ��ŭ �޸��Ҵ� 
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;

		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T("Calibration Offset"));
		ErrMessage(strMsg);
		return FALSE;
	}
	AND_CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;

		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, "Calibration Offset");
		ErrMessage(strMsg);
		return FALSE;
	}
	END_CATCH

	data = cFileView;								// access�� ������ �Ҵ�..

	TRY
	{
		file.Read(cFileView,dwFileSize);
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		delete [] cFileView;

		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, "Calibration Offset");
		ErrMessage(strMsg);
		return FALSE;
	}
	END_CATCH

	cFileView[dwFileSize] = _T('\n');
	cFileView[dwFileSize+1] = _T('\0');

	///////////////////////////////////////////////
	//to the end of file checking ','  for line number
	while (*data!=_T('\0'))
	{
		if(*data==_T(',')) j++;		
		data++;
	}
	
	//calculate line number
	if((j%3)!=0) 
	{
		delete [] cFileView;
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, "Calibration Offset");
		ErrMessage(strMsg);
		return FALSE;
	}
	
	LineNum=j/3;		//total line num.
	MaxLineNum=LineNum;	//store Max Line Num.

	/////////////////////////////////////////////////
	//Calculate Matrix size.
	M_size=(int)sqrt((double)LineNum/2);	//except two lines from above and bottom

	if((M_size*M_size)!=(LineNum/2))
	{
		delete [] cFileView;
		ErrMessage(IDS_ERR_CAL_DATA);
		return FALSE;
	}

	m_nGridSize = M_size;

	LineNum=0;						//Line check �� ������ �ʱ�ȭ
	data=cFileView;					// access�� ������ �ʱ�ȭ
	i=0;							//array variable �ʱ�ȭ

	int nX = m_nGridSize - 1, nY = m_nGridSize - 1;
	while (*data!=_T('\0'))	//EOF	//to the end of file
	{
		//check the end of line
		while(*data!=_T('\n'))
		{
			buf[i++]=*data;
			data++;
		}
		LineNum++;
		i=0;						//buffer pointer initialize.
		data++;

		if (LineNum == 1 || LineNum == (M_size * M_size + 1))
		{
			nX = m_nGridSize - 1;
			nY = m_nGridSize - 1;
		}

		////////////////////////
		// for master... 
		if(LineNum < (M_size * M_size + 1))
		{
			//position.
			while(buf[i]!=_T('(')) i++;
			while(buf[i]!=_T(',')) i++;

			//offset value.
			while(buf[i]!=_T('(')) i++;
			m_ptMasterGridOffset[nX * m_nGridSize + nY].x = atof(buf+i+1);
			dMaxTemp = fabs(m_ptMasterGridOffset[nX * m_nGridSize + nY].x);
			if (m_dMaxOffsetMasterX < dMaxTemp)
				m_dMaxOffsetMasterX = dMaxTemp;

			while(buf[i]!=_T(',')) i++;
			m_ptMasterGridOffset[nX * m_nGridSize + nY].y = atof(buf+i+1);
			dMaxTemp = fabs(m_ptMasterGridOffset[nX * m_nGridSize + nY].y);
			if (m_dMaxOffsetMasterY < dMaxTemp)
				m_dMaxOffsetMasterY = dMaxTemp;

			dMaxTemp = sqrt(m_ptMasterGridOffset[nX * m_nGridSize + nY].x * m_ptMasterGridOffset[nX * m_nGridSize + nY].x 
							+m_ptMasterGridOffset[nX * m_nGridSize + nY].y * m_ptMasterGridOffset[nX * m_nGridSize + nY].y);
			if(m_dMaxOffsetMasterR < dMaxTemp)
				m_dMaxOffsetMasterR = dMaxTemp;

			nY--;
			if (nY < 0)
			{
				nX--;
				nY = m_nGridSize - 1;
			}
		}
		////////////////////////
		// for slave... 
		else
		{
			//position.
			while(buf[i]!=_T('(')) i++;
			while(buf[i]!=_T(',')) i++;

			//offset value.
			while(buf[i]!=_T('(')) i++;
			m_ptSlaveGridOffset[nX * m_nGridSize + nY].x = atof(buf+i+1);
			dMaxTemp = fabs(m_ptSlaveGridOffset[nX * m_nGridSize + nY].x);
			if (m_dMaxOffsetSlaveX < dMaxTemp)
				m_dMaxOffsetSlaveX = dMaxTemp;

			while(buf[i]!=_T(',')) i++;
			m_ptSlaveGridOffset[nX * m_nGridSize + nY].y = atof(buf+i+1);
			dMaxTemp = fabs(m_ptSlaveGridOffset[nX * m_nGridSize + nY].y);
			if (m_dMaxOffsetSlaveY < dMaxTemp)
				m_dMaxOffsetSlaveY = dMaxTemp;

			dMaxTemp = sqrt(m_ptSlaveGridOffset[nX * m_nGridSize + nY].x * m_ptSlaveGridOffset[nX * m_nGridSize + nY].x 
				+m_ptSlaveGridOffset[nX * m_nGridSize + nY].y * m_ptSlaveGridOffset[nX * m_nGridSize + nY].y);
			if(m_dMaxOffsetSlaveR < dMaxTemp)
				m_dMaxOffsetSlaveR = dMaxTemp;

			nY--;
			if (nY < 0)
			{
				nX--;
				nY = m_nGridSize - 1;
			}
		}
		i=0;
	}
	delete [] cFileView;
	
	if (LineNum != M_size * M_size * 2 + 1)
		return FALSE;

	TCHAR str[15];
	m_dMaxOffsetMasterX *= 1000.;
	m_dMaxOffsetMasterY *= 1000.;
	m_dMaxOffsetMasterR *= 1000.;

	m_dMaxOffsetSlaveX *= 1000.;
	m_dMaxOffsetSlaveY *= 1000.;
	m_dMaxOffsetSlaveR *= 1000.;
	CFont cFont;
	cFont.CreateFont(DEF_COLOR_TEXT_HEIGHT, 0, 0, 0, FW_ULTRABOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);

	const double dMaxOffset1stX = gProcessINI.m_sProcessCal.n1stToleranceX; //apply limit 
	const double dMaxOffset1stY = gProcessINI.m_sProcessCal.n1stToleranceY;
	const double dMaxOffset1stR = gProcessINI.m_sProcessCal.n1stToleranceR;
	const double dMaxOffset2ndX = gProcessINI.m_sProcessCal.n2ndToleranceX; // drilling limit
	const double dMaxOffset2ndY = gProcessINI.m_sProcessCal.n2ndToleranceY;
	const double dMaxOffset2ndR = gProcessINI.m_sProcessCal.n2ndToleranceR;

	_stprintf_s(str, "%.4f", m_dMaxOffsetMasterX);

	m_stc1stX.SetBackColor(RGB(255, 255, 255));
	if (m_dMaxOffsetMasterX > dMaxOffset1stX)
		m_stc1stX.SetForeColor(RGB(255, 0, 0));
	else
		m_stc1stX.SetForeColor(RGB(0, 0, 255));
	m_stc1stX.SetFont(&cFont);
	m_stc1stX.SetWindowText(str);

	_stprintf_s(str, "%.4f", m_dMaxOffsetMasterY );

	m_stc1stY.SetBackColor(RGB(255, 255, 255));
	if (m_dMaxOffsetMasterY > dMaxOffset1stY)
		m_stc1stY.SetForeColor(RGB(255, 0, 0));
	else
		m_stc1stY.SetForeColor(RGB(0, 0, 255));
	m_stc1stY.SetFont(&cFont);
	m_stc1stY.SetWindowText(str);


	_stprintf_s(str, "%.4f", m_dMaxOffsetMasterR );

	m_stc1stR.SetBackColor(RGB(255, 255, 255));
	m_stc1stR.SetForeColor(RGB(0, 0, 255));
	m_stc1stR.SetFont(&cFont);
	m_stc1stR.SetWindowText(str);

	_stprintf_s(str, "%.4f", m_dMaxOffsetSlaveX );


	m_stc2ndX.SetBackColor(RGB(255, 255, 255));
	if (m_dMaxOffsetSlaveX > dMaxOffset1stX)
		m_stc2ndX.SetForeColor(RGB(255, 0, 0));
	else
		m_stc2ndX.SetForeColor(RGB(0, 0, 255));
	m_stc2ndX.SetFont(&cFont);
	m_stc2ndX.SetWindowText(str);

	_stprintf_s(str, "%.4f", m_dMaxOffsetSlaveY);

	m_stc2ndY.SetBackColor(RGB(255, 255, 255));
	if (m_dMaxOffsetSlaveY > dMaxOffset1stY)
		m_stc2ndY.SetForeColor(RGB(255, 0, 0));
	else
		m_stc2ndY.SetForeColor(RGB(0, 0, 255));
	m_stc2ndY.SetFont(&cFont);
	m_stc2ndY.SetWindowText(str);

	_stprintf_s(str, "%.4f", m_dMaxOffsetSlaveR );

	m_stc2ndR.SetBackColor(RGB(255, 255, 255));
	m_stc2ndR.SetForeColor(RGB(0, 0, 255));
	m_stc2ndR.SetFont(&cFont);
	m_stc2ndR.SetWindowText(str);

	if(gProcessINI.m_sProcessCal.bUseApplyTolerance)
	{
		if ((m_dMaxOffsetMasterX > dMaxOffset1stX) || (m_dMaxOffsetMasterY > dMaxOffset1stY) ||
			(m_dMaxOffsetSlaveX > dMaxOffset1stX)  || (m_dMaxOffsetSlaveY > dMaxOffset1stY) ||
			(m_dMaxOffsetMasterR > dMaxOffset1stR) || (m_dMaxOffsetSlaveR > dMaxOffset1stR))
			GetDlgItem(IDOK)->EnableWindow(FALSE);
	}
	m_bDrillingLimitOK[0] = m_bDrillingLimitOK[1] = FALSE;
	if(m_nSelectHead != SEL_HEAD_SLAVE)
	{
		if ((m_dMaxOffsetMasterX <= dMaxOffset2ndX) && (m_dMaxOffsetMasterY <= dMaxOffset2ndY) && (m_dMaxOffsetMasterR <= dMaxOffset2ndR))
		{
			m_bDrillingLimitOK[0] = TRUE;
		}
	}
	if(m_nSelectHead != SEL_HEAD_MASTER)
	{
		if ((m_dMaxOffsetSlaveX <= dMaxOffset2ndX) && (m_dMaxOffsetSlaveY <= dMaxOffset2ndY) && (m_dMaxOffsetSlaveR <= dMaxOffset2ndR))
		{
			m_bDrillingLimitOK[1] = TRUE;
		}
	}
#ifdef __TEST__
	m_bDrillingLimitOK[0] = TRUE;
	m_bDrillingLimitOK[1] = TRUE;
#endif
	// change by Choi
	file.Close();
	if(m_bIsAutoProcessMode)
	{
		if ((m_dMaxOffsetMasterX > dMaxOffset1stX) || (m_dMaxOffsetMasterY > dMaxOffset1stY) ||
		    (m_dMaxOffsetSlaveX > dMaxOffset2ndX)   || (m_dMaxOffsetSlaveY > dMaxOffset2ndY))
		{
			gVariable.m_sGlobal.bCalFalse = TRUE;
			OnOK();
		}
		else
		{
			gVariable.m_sGlobal.bCalFalse = FALSE;
			OnOK();
		}
	}
	gVariable.m_sGlobal.bCalFalse = FALSE;

	return TRUE;
}

BOOL CDlgCalResult::SetCalMatrix(TCHAR* szMasterFile, TCHAR* szSlaveFile)
{
	HEocard* pEoCard = gDeviceFactory.GetEocard();
	return pEoCard->LoadCalibrationFile(szMasterFile, szSlaveFile);
}

void CDlgCalResult::SetASCFilePath(CString str1st, CString str2nd)
{
	lstrcpy(m_c1st1ASC, str1st);
	lstrcpy(m_c2nd1ASC, str2nd);
}

void CDlgCalResult::CallOnOk()
{
	OnOK();
}

void CDlgCalResult::SetAGCUnit(CalAGC *pMaster, CalAGC *pSlave)
{
	m_pcalAGCMaster = pMaster;
	m_pcalAGCSlave = pSlave;
}

void CDlgCalResult::SetTablePos(double dx, double dy)
{
	m_dCalTablePosX = dx;
	m_dCalTablePosY = dy;
}

void CDlgCalResult::SetToolIndex(int nTool)
{
	m_nTool = nTool;
}


BOOL CDlgCalResult::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CDialog::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CDialog::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_Scal_Result) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}

void CDlgCalResult::SaveScalTimeLog(BOOL bMaster, CString strASCFile)
{
	float fData;
	char buf[256];
	FILE* fp;
	fp = NULL;
	errno_t err;
	double dX[4], dY[4];
	int nSaveIndex;

	err = fopen_s(&fp, strASCFile,_T("r"));	

	if(NULL != err)
		return;
		
	fgets(buf, sizeof(buf), fp);	
	for (int k=0; k < 2; k++) 
	{
		nSaveIndex = 0;
		for  (int j=0; j<65; j++) 
		{
			for (int i=0; i<65; i++)   
			{
				fscanf(fp, _T("%f"), &fData);
				if(k == 0)
				{
					if( (i != 0 && i != 64) || (j != 0 && j != 64))
						continue;
					else
					{
						dY[nSaveIndex++] = (double)fData;
					}
				}
				else
				{
					if( (i != 0 && i != 64) || (j != 0 && j != 64))
						continue;
					else
					{
						dX[nSaveIndex++] = (double)fData;
					}
				}
			}//  for (i)
		}//  for (j)
	} //  for (k)	
	fclose(fp);

	CString strFile, strLog;
	strFile.Format(_T("SCal_Time_Log"));
	if(bMaster)
	{
		strLog.Format(_T("Mater \t MSCAL \t %d \t 0 \t 0 \t %.4f \t %.4f \t 0 \t 1 \t %.4f \t %.4f \t 1 \t 0 \t %.4f \t %.4f \t1 \t1 \t %.4f \t %.4f \t"),   
						m_nTool,
						dX[0], dY[0], dX[2], dY[2],										
						dX[1], dY[1], dX[3], dY[3]);
	}
	else
	{
		strLog.Format(_T("Slave \t MSCAL \t %d \t 0 \t 0 \t %.4f \t %.4f \t 0 \t 1 \t %.4f \t %.4f \t 1 \t 0 \t %.4f \t %.4f \t1 \t1 \t %.4f \t %.4f \t"),   
						m_nTool,
						dX[0], dY[0], dX[2], dY[2],										
						dX[1], dY[1], dX[3], dY[3]);
	}
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	strLog.Format(_T("Temp All MSCAL \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f"),   
						m_dAllTemper[0], m_dAllTemper[1], m_dAllTemper[2], m_dAllTemper[3], m_dAllTemper[4],
						m_dAllTemper[5], m_dAllTemper[6], m_dAllTemper[7], m_dAllTemper[8], m_dAllTemper[9]);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

}
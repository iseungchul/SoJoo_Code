// PaneManualControlIOMonitorNullSub.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlIOMonitorNullSub.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorNullSub

IMPLEMENT_DYNCREATE(CPaneManualControlIOMonitorNullSub, CFormView)

CPaneManualControlIOMonitorNullSub::CPaneManualControlIOMonitorNullSub()
	: CFormView(CPaneManualControlIOMonitorNullSub::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlIOMonitorNullSub)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneManualControlIOMonitorNullSub::~CPaneManualControlIOMonitorNullSub()
{
}

void CPaneManualControlIOMonitorNullSub::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlIOMonitorNullSub)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlIOMonitorNullSub, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlIOMonitorNullSub)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorNullSub diagnostics

#ifdef _DEBUG
void CPaneManualControlIOMonitorNullSub::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlIOMonitorNullSub::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorNullSub message handlers

BOOL CPaneManualControlIOMonitorNullSub::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}
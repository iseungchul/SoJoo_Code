#if !defined(AFX_PANESUBMOTORPOSITIONLARGE_H__49F4EC25_019C_4371_9151_30FB0FD4ABE9__INCLUDED_)
#define AFX_PANESUBMOTORPOSITIONLARGE_H__49F4EC25_019C_4371_9151_30FB0FD4ABE9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSubMotorPositionLarge.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSubMotorPositionLarge form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "ColorStatic.h"


class CPaneSubMotorPositionLarge : public CFormView
{
protected:
	CPaneSubMotorPositionLarge();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSubMotorPositionLarge)

// Form Data
public:
	//{{AFX_DATA(CPaneSubMotorPositionLarge)
	enum { IDD = IDD_DLG_SUB_MOTOR_POSITION_LARGE };
	CColorStatic m_stcPosX;
	CColorStatic m_stcPosY;
	CColorStatic m_stcPosZ1;
	CColorStatic m_stcPosZ2;
	CColorStatic m_stcPosM;
	CColorStatic m_stcPosM2;
	CColorStatic m_stcPosM3;

	CColorStatic m_stcPosM4;
	CColorStatic m_stcPosTop;
	CColorStatic m_stcPosRot;

	CColorStatic m_stcPosC;
	CColorStatic m_stcPosC2;
	CColorStatic m_stcPosLC;
	CColorStatic m_stcPosUC;
	//2011524
	CColorStatic m_stcPos1A;
	CColorStatic m_stcPos2A;

	CColorStatic m_stcPosLP1;
	CColorStatic m_stcPosLP2;
	CColorStatic m_stcPosUP1;
	CColorStatic m_stcPosUP2;
	//}}AFX_DATA

// Attributes
public:
	void InitStaticControl();
	void DispStatus();

	void InitTimer();
	void DestroyTimer();

	CFont m_fntStatic;
	CFont m_fntStatic2;

	BOOL m_bTimer;
	int	 m_nTimerID;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSubMotorPositionLarge)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSubMotorPositionLarge();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSubMotorPositionLarge)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESUBMOTORPOSITIONLARGE_H__49F4EC25_019C_4371_9151_30FB0FD4ABE9__INCLUDED_)

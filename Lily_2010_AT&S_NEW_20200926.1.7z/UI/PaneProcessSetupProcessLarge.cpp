// PaneProcessSetupProcessLarge.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneProcessSetupProcessLarge.h"
#include "..\model\deasydrillerini.h"
#include "..\device\HDeviceFactory.h"

#include "..\device\devicemotor.h"

#include "..\model\DProcessINI.h"
#include "..\model\dsystemini.h"
#include "..\MODEL\DBeampathINI.h"
#include "..\EasyDrillerDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupProcessLarge

IMPLEMENT_DYNCREATE(CPaneProcessSetupProcessLarge, CFormView)

CPaneProcessSetupProcessLarge::CPaneProcessSetupProcessLarge()
	: CFormView(CPaneProcessSetupProcessLarge::IDD)
{
	//{{AFX_DATA_INIT(CPaneProcessSetupProcessLarge)
	//}}AFX_DATA_INIT
}

CPaneProcessSetupProcessLarge::~CPaneProcessSetupProcessLarge()
{
}

void CPaneProcessSetupProcessLarge::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneProcessSetupProcessLarge)
	DDX_Control(pDX, IDC_EDIT_SUCTION_NO, m_edtSuctionNo);
	DDX_Control(pDX, IDC_EDIT_SUCTION_TABLE_X, m_edtSuctionTableX);
	DDX_Control(pDX, IDC_EDIT_SUCTION_TABLE_Y, m_edtSuctionTableY);
	DDX_Control(pDX, IDC_EDIT_2ND_POWERMETER_TABLE_Y, m_edt2ndPowermeterY);
	DDX_Control(pDX, IDC_EDIT_2ND_POWERMETER_TABLE_X, m_edt2ndPowermeterX);
	DDX_Control(pDX, IDC_EDIT_1ST_POWERMETER_TABLE_Y, m_edt1stPowermeterY);
	DDX_Control(pDX, IDC_EDIT_1ST_POWERMETER_TABLE_X, m_edt1stPowermeterX);
	DDX_Control(pDX, IDC_EDIT_2ND_THICKNESS_SENSOR_HEAD_Z, m_edt2ndThicknessHeadZ);
	DDX_Control(pDX, IDC_EDIT_2ND_THICKNESS_SENSOR_BASE_Z, m_edt2ndThicknessBaseZ);
	DDX_Control(pDX, IDC_EDIT_2ND_THICKNESS_SENSOR_OFFSET_Y, m_edt2ndThicknessOffsetY);
	DDX_Control(pDX, IDC_EDIT_2ND_THICKNESS_SENSOR_OFFSET_X, m_edt2ndThicknessOffsetX);
	DDX_Control(pDX, IDC_EDIT_2ND_THICKNESS_SENSOR_AUTO_Y, m_edt2ndThicknessAutoY);
	DDX_Control(pDX, IDC_EDIT_2ND_THICKNESS_SENSOR_AUTO_X, m_edt2ndThicknessAutoX);
	DDX_Control(pDX, IDC_EDIT_2ND_THICKNESS_MANUAL_Y, m_edt2ndThicknessManualY);
	DDX_Control(pDX, IDC_EDIT_2ND_THICKENSS_MANUAL_X, m_edt2ndThicknessManualX);
	DDX_Control(pDX, IDC_EDIT_1ST_THICKNESS_SENSOR_HEAD_Z, m_edt1stThicknessHeadZ);
	DDX_Control(pDX, IDC_EDIT_1ST_THICKNESS_SENSOR_BASE_Z, m_edt1stThicknessBaseZ);
	DDX_Control(pDX, IDC_EDIT_1ST_THICKNESS_SENSOR_OFFSET_Y, m_edt1stThicknessOffsetY);
	DDX_Control(pDX, IDC_EDIT_1ST_THICKNESS_SENSOR_OFFSET_X, m_edt1stThicknessOffsetX);
	DDX_Control(pDX, IDC_EDIT_1ST_THICKNESS_SENSOR_AUTO_Y, m_edt1stThicknessAutoY);
	DDX_Control(pDX, IDC_EDIT_1ST_THICKNESS_SENSOR_AUTO_X, m_edt1stThicknessAutoX);
	DDX_Control(pDX, IDC_EDIT_1ST_THICKNESS_MANUAL_Y, m_edt1stThicknessManualY);
	DDX_Control(pDX, IDC_EDIT_1ST_THICKENSS_MANUAL_X, m_edt1stThicknessManualX);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_TABLE_Y, m_edtUnloadY);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_TABLE_X, m_edtUnloadX);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_TABLE_Y2, m_edtUnloadY2);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_TABLE_X2, m_edtUnloadX2);
	DDX_Control(pDX, IDC_EDIT_LOAD_TABLE_Y, m_edtLoadY);
	DDX_Control(pDX, IDC_EDIT_LOAD_TABLE_X, m_edtLoadX);
	DDX_Control(pDX, IDC_EDIT_LOAD_TABLE_Y2, m_edtLoadY2);
	DDX_Control(pDX, IDC_EDIT_LOAD_TABLE_X2, m_edtLoadX2);
	DDX_Control(pDX, IDC_EDIT_LOAD_CARRIER_CART, m_edtLCCart);
	DDX_Control(pDX, IDC_EDIT_LOAD_CARRIER_LOAD, m_edtLCLoad);
	DDX_Control(pDX, IDC_EDIT_LOAD_CARRIER_LOAD2, m_edtLCLoad2);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_CARRIER_CART, m_edtUCCart);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_CARRIER_UNLOAD, m_edtUCUnload);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_CARRIER_UNLOAD2, m_edtUCUnload2);
	DDX_Control(pDX, IDC_EDIT_UNCLAMP_Y_LIMIT, m_edtUnclampLimit);
	DDX_Control(pDX, IDC_BUTTON_POS_ADD, m_btnSuctionAdd);
	DDX_Control(pDX, IDC_BUTTON_POS_DELETE, m_btnSuctionDelete);
	DDX_Control(pDX, IDC_BUTTON_POS_UPDATE, m_btnSuctionUpdate);
	DDX_Control(pDX, IDC_LIST_SUCTION_POS, m_listPosition);
	DDX_Control(pDX, IDC_EDIT_SCAL_MIN_X2, m_edtSCalMinX);
	DDX_Control(pDX, IDC_EDIT_SCAL_MIN_Y2, m_edtSCalMinY);
	DDX_Control(pDX, IDC_EDIT_SCAL_MAX_X2, m_edtSCalMaxX);
	DDX_Control(pDX, IDC_EDIT_SCAL_MAX_Y2, m_edtSCalMaxY);
	DDX_Control(pDX, IDC_EDIT_LOAD_CARRIER_ALIGN, m_edtLCAlign);
	DDX_Control(pDX, IDC_EDIT_UNLOAD_CARRIER_ALIGN, m_edtUCAlign);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_STATIC_LOAD_POS, m_stcLoadPosition);
	DDX_Control(pDX, IDC_STATIC_UNLOAD_POS, m_stcUnloadPosition);
	DDX_Control(pDX, IDC_STATIC_LOAD_POS2, m_stcLoadPosition2);
	DDX_Control(pDX, IDC_STATIC_LOAD_CARRIER_POS, m_stcLoaderCarrierPosition);
	DDX_Control(pDX, IDC_STATIC_UNLOAD_CARRIER_POS, m_stcUnloadetCarrierPosition);

	DDX_Control(pDX, IDC_BUTTON_LOAD_POS, m_btnLoadPosition);
	DDX_Control(pDX, IDC_BUTTON_UNLOAD_POS, m_btnUnloadPosition);
	DDX_Control(pDX, IDC_BUTTON_LOAD_POS2, m_btnLoadPosition2);
	DDX_Control(pDX, IDC_BUTTON_UNLOAD_POS2, m_btnUnloadPosition2);
	DDX_Control(pDX, IDC_BUTTON_LDCART_POS, m_btnLCCartPosition);
	DDX_Control(pDX, IDC_BUTTON_LDLOAD_POS, m_btnLCLoadPosition);

	DDX_Control(pDX, IDC_BUTTON_LDALIGN_POS, m_btnLCAlignPosition);
	DDX_Control(pDX, IDC_BUTTON_UDCART_POS, m_btnUCCartPosition);
	DDX_Control(pDX, IDC_BUTTON_UDUNLOAD_POS, m_btnUCUnloadPosition);
	DDX_Control(pDX, IDC_BUTTON_UDALIGN_POS, m_btnUCAlignPosition);

	DDX_Control(pDX, IDC_EDIT_IDLE_POS_X, m_edtIdleShotX);
	DDX_Control(pDX, IDC_EDIT_IDLE_POS_Y, m_edtIdleShotY);
	DDX_Control(pDX, IDC_EDIT_IDLE_POS_Z1, m_edtIdleShotZ1);
	DDX_Control(pDX, IDC_EDIT_IDLE_POS_Z2, m_edtIdleShotZ2);
	DDX_Control(pDX, IDC_COMBO_TOOL, m_cmbTool);

	DDX_Control(pDX, IDC_EDIT_TC_CLEAN_X, m_edtTCCleanX);
	DDX_Control(pDX, IDC_EDIT_TC_CLEAN_Y, m_edtTCCleanY);
	DDX_Control(pDX, IDC_EDIT_TC_CLEAN_Z1, m_edtTCCleanZ1);
	DDX_Control(pDX, IDC_EDIT_TC_CLEAN_Z2, m_edtTCCleanZ2);
	DDX_Control(pDX, IDC_BUTTON_TC_CLEAN_POS, m_btnTCCleanPos);
}


BEGIN_MESSAGE_MAP(CPaneProcessSetupProcessLarge, CFormView)
	//{{AFX_MSG_MAP(CPaneProcessSetupProcessLarge)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_POS_ADD, OnButtonSuctionAdd)
	ON_BN_CLICKED(IDC_BUTTON_POS_DELETE, OnButtonSuctionDelete)
	ON_BN_CLICKED(IDC_BUTTON_POS_UPDATE, OnButtonSuctionUpdate)
	ON_NOTIFY(NM_CLICK, IDC_LIST_SUCTION_POS, OnClickListRefuse)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_UDCART_POS, &CPaneProcessSetupProcessLarge::OnBnClickedButtonUdcartPos)
	ON_BN_CLICKED(IDC_BUTTON_UDUNLOAD_POS, &CPaneProcessSetupProcessLarge::OnBnClickedButtonUdunloadPos)
	ON_BN_CLICKED(IDC_BUTTON_UDALIGN_POS, &CPaneProcessSetupProcessLarge::OnBnClickedButtonUdalignPos)
	ON_BN_CLICKED(IDC_BUTTON_LDCART_POS, &CPaneProcessSetupProcessLarge::OnBnClickedButtonLdcartPos)
	ON_BN_CLICKED(IDC_BUTTON_LDLOAD_POS, &CPaneProcessSetupProcessLarge::OnBnClickedButtonLdloadPos)
	ON_BN_CLICKED(IDC_BUTTON_LDALIGN_POS, &CPaneProcessSetupProcessLarge::OnBnClickedButtonLdalignPos)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_POS, &CPaneProcessSetupProcessLarge::OnBnClickedButtonLoadPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOAD_POS, &CPaneProcessSetupProcessLarge::OnBnClickedButtonUnloadPos)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_POS2, &CPaneProcessSetupProcessLarge::OnBnClickedButtonLoadPos2)
	ON_BN_CLICKED(IDC_BUTTON_UNLOAD_POS2, &CPaneProcessSetupProcessLarge::OnBnClickedButtonUnloadPos2)
	ON_BN_CLICKED(IDC_BUTTON_TC_CLEAN_POS, &CPaneProcessSetupProcessLarge::OnBnClickedButtonTcCleanPos)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupProcessLarge diagnostics

#ifdef _DEBUG
void CPaneProcessSetupProcessLarge::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneProcessSetupProcessLarge::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupProcessLarge message handlers

void CPaneProcessSetupProcessLarge::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitEditControl();
	InitBtnControl();
	InitListControl();
	InitComboControl();
	
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		m_edt2ndPowermeterX.EnableWindow(FALSE);
		m_edt2ndPowermeterY.EnableWindow(FALSE);

		m_edt2ndPowermeterX.SetWindowText("NO USE");
		m_edt2ndPowermeterY.SetWindowText("NO USE");
	}

	if(gSystemINI.m_sHardWare.nTableClamp < 1)
	{
		m_edtUnclampLimit.EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_TABLE_UNCLAMP_LIMIT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_UNCLAMP_Y_LIMIT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_UNCLAMP_Y_LIMIT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_UNCLAMP_Y_LIMIT_MM)->ShowWindow(SW_HIDE);
	}

	if( 1 > gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		m_edt1stThicknessHeadZ.EnableWindow(FALSE);
		m_edt1stThicknessBaseZ.EnableWindow(FALSE);
		m_edt1stThicknessOffsetY.EnableWindow(FALSE);
		m_edt1stThicknessOffsetX.EnableWindow(FALSE);
		m_edt1stThicknessAutoY.EnableWindow(FALSE);
		m_edt1stThicknessAutoX.EnableWindow(FALSE);
		m_edt1stThicknessManualY.EnableWindow(FALSE);
		m_edt1stThicknessManualX.EnableWindow(FALSE);
	}
	if( 2 > gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		m_edt2ndThicknessHeadZ.EnableWindow(FALSE);
		m_edt2ndThicknessBaseZ.EnableWindow(FALSE);
		m_edt2ndThicknessOffsetY.EnableWindow(FALSE);
		m_edt2ndThicknessOffsetX.EnableWindow(FALSE);
		m_edt2ndThicknessAutoY.EnableWindow(FALSE);
		m_edt2ndThicknessAutoX.EnableWindow(FALSE);
		m_edt2ndThicknessManualY.EnableWindow(FALSE);
		m_edt2ndThicknessManualX.EnableWindow(FALSE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 0)
	{
		m_edt1stPowermeterX.EnableWindow(FALSE);
		m_edt1stPowermeterY.EnableWindow(FALSE);
		m_edt2ndPowermeterX.EnableWindow(FALSE);
		m_edt2ndPowermeterY.EnableWindow(FALSE);
	}


	m_edtTCCleanX.ShowWindow(SW_SHOW);
	m_edtTCCleanY.ShowWindow(SW_SHOW);
	m_edtTCCleanZ1.ShowWindow(SW_SHOW);
	m_edtTCCleanZ2.ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_TC_CLEANING_POSITION)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_TC_CLEAN_X)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_TC_CLEAN_Y)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_TC_CLEAN_Z1)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_TC_CLEAN_Z2)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_BUTTON_TC_CLEAN_POS)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_TC_CLEAN_X_MM)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_TC_CLEAN_Y_MM)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_TC_CLEAN_Z1_MM)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_TC_CLEAN_Z2_MM)->ShowWindow(SW_SHOW);

	m_edt1stThicknessAutoX.EnableWindow(FALSE);
	m_edt1stThicknessAutoY.EnableWindow(FALSE);
	m_edt2ndThicknessAutoY.EnableWindow(FALSE);
	m_edt2ndThicknessAutoX.EnableWindow(FALSE);
	

	// 100609 UnclampPos Unlimit
//	GetDlgItem(IDC_STATIC_TABLE_UNCLAMP_LIMIT)->ShowWindow(SW_HIDE);
//	GetDlgItem(IDC_STATIC_UNCLAMP_Y_LIMIT)->ShowWindow(SW_HIDE);
//	GetDlgItem(IDC_EDIT_UNCLAMP_Y_LIMIT)->ShowWindow(SW_HIDE);
//	GetDlgItem(IDC_STATIC_UNCLAMP_Y_LIMIT_MM)->ShowWindow(SW_HIDE);
}

BOOL CPaneProcessSetupProcessLarge::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneProcessSetupProcessLarge::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(120, "Arial Bold");

	// Load Position #1
	GetDlgItem(IDC_STATIC_LOAD_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_TABLE_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_TABLE_Y)->SetFont( &m_fntStatic );
	
	// Load Position #2
	GetDlgItem(IDC_STATIC_LOAD_POS2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_TABLE_X2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_TABLE_Y2)->SetFont( &m_fntStatic );

	// Load Carrier Position
	GetDlgItem(IDC_STATIC_LOAD_CARRIER_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_CARRIER_CART)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_CARRIER_LOAD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_CARRIER_ALIGN)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOAD_CARRIER_LOAD2)->SetFont( &m_fntStatic );

	// Unload Position
	GetDlgItem(IDC_STATIC_UNLOAD_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_TABLE_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_TABLE_Y)->SetFont( &m_fntStatic );

	// Unload Position #2 
	GetDlgItem(IDC_STATIC_UNLOAD_POS2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_TABLE_X2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_TABLE_Y2)->SetFont( &m_fntStatic );

	// Unload Carrier Position
	GetDlgItem(IDC_STATIC_UNLOAD_CARRIER_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_CARRIER_CART)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_CARRIER_UNLOAD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_CARRIER_ALIGN)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNLOAD_CARRIER_UNLOAD2)->SetFont( &m_fntStatic );

	// Table Unclamp Limit
	GetDlgItem(IDC_STATIC_TABLE_UNCLAMP_LIMIT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_UNCLAMP_Y_LIMIT)->SetFont( &m_fntStatic );

	// 1'st Height Sensor Position
	GetDlgItem(IDC_STATIC_1ST_THICKNESS_SENSOR_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_THICKNESS_SENSOR_MANUAL_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_THICKNESS_SENSOR_MANUAL_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_THICKNESS_SENSOR_AUTO_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_THICKNESS_SENSOR_AUTO_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_THICKNESS_SENSOR_OFFSET_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_THICKNESS_SENSOR_OFFSET_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_THICKNESS_SENSOR_HEAD_Z)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_THICKNESS_SENSOR_BASE_Z)->SetFont( &m_fntStatic );

	// 2'nd Height Sensor Position
	GetDlgItem(IDC_STATIC_2ND_THICKNESS_SENSOR_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_THICKNESS_SENSOR_MANUAL_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_THICKNESS_SENSOR_MANUAL_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_THICKNESS_SENSOR_AUTO_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_THICKNESS_SENSOR_AUTO_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_THICKNESS_SENSOR_OFFSET_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_THICKNESS_SENSOR_OFFSET_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_THICKNESS_SENSOR_HEAD_Z)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_THICKNESS_SENSOR_BASE_Z)->SetFont( &m_fntStatic );

	// 1'st Powermeter Position
	GetDlgItem(IDC_STATIC_1ST_POWERMETER_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_POWERMETER_TABLE_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_POWERMETER_TABLE_Y)->SetFont( &m_fntStatic );

	// 2'nd Powermeter Position
	GetDlgItem(IDC_STATIC_2ND_POWERMETER_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_POWERMETER_TABLE_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_POWERMETER_TABLE_Y)->SetFont( &m_fntStatic );

	// Suction Point Setting
	GetDlgItem(IDC_STATIC_POINT_NO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUCTION_TABLE_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUCTION_TABLE_Y)->SetFont( &m_fntStatic );

//	if(!gSystemINI.m_sHardWare.nDustTableUse)
	{
		GetDlgItem(IDC_STATIC_POINT_NO)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUCTION_TABLE_X)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SUCTION_TABLE_Y)->ShowWindow(SW_HIDE);
	}

	GetDlgItem(IDC_STATIC_CAL_POS2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCAL_MIN_X2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCAL_MIN_Y2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCAL_MAX_X2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCAL_MAX_Y2)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_IDLE_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_IDLE_POS_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_IDLE_POS_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_IDLE_POS_Z)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_IDLE_POS_Z2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TOOL_NO)->SetFont( &m_fntStatic );

	//T/C lens Cleaning position
	GetDlgItem(IDC_STATIC_TC_CLEANING_POSITION)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TC_CLEAN_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TC_CLEAN_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TC_CLEAN_Z1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TC_CLEAN_Z2)->SetFont( &m_fntStatic );
	
}

void CPaneProcessSetupProcessLarge::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	// Load Position #1
	m_edtLoadX.SetFont( &m_fntEdit );
	m_edtLoadX.SetForeColor( BLACK_COLOR );
	m_edtLoadX.SetBackColor( WHITE_COLOR );
	m_edtLoadX.SetReceivedFlag( 3 );
	m_edtLoadX.SetWindowText( _T("0.0") );

	m_edtLoadY.SetFont( &m_fntEdit );
	m_edtLoadY.SetForeColor( BLACK_COLOR );
	m_edtLoadY.SetBackColor( WHITE_COLOR );
	m_edtLoadY.SetReceivedFlag( 3 );
	m_edtLoadY.SetWindowText( _T("0.0") );

	// Load Position #2
	m_edtLoadX2.SetFont( &m_fntEdit );
	m_edtLoadX2.SetForeColor( BLACK_COLOR );
	m_edtLoadX2.SetBackColor( WHITE_COLOR );
	m_edtLoadX2.SetReceivedFlag( 3 );
	m_edtLoadX2.SetWindowText( _T("0.0") );
	
	m_edtLoadY2.SetFont( &m_fntEdit );
	m_edtLoadY2.SetForeColor( BLACK_COLOR );
	m_edtLoadY2.SetBackColor( WHITE_COLOR );
	m_edtLoadY2.SetReceivedFlag( 3 );
	m_edtLoadY2.SetWindowText( _T("0.0") );

	// Load Carrier Position
	m_edtLCCart.SetFont( &m_fntEdit );
	m_edtLCCart.SetForeColor( BLACK_COLOR );
	m_edtLCCart.SetBackColor( WHITE_COLOR );
	m_edtLCCart.SetReceivedFlag( 3 );
	m_edtLCCart.SetWindowText( _T("0.0") );
	
	m_edtLCAlign.SetFont( &m_fntEdit );
	m_edtLCAlign.SetForeColor( BLACK_COLOR );
	m_edtLCAlign.SetBackColor( WHITE_COLOR );
	m_edtLCAlign.SetReceivedFlag( 3 );
	m_edtLCAlign.SetWindowText( _T("0.0") );

	m_edtLCLoad.SetFont( &m_fntEdit );
	m_edtLCLoad.SetForeColor( BLACK_COLOR );
	m_edtLCLoad.SetBackColor( WHITE_COLOR );
	m_edtLCLoad.SetReceivedFlag( 3 );
	m_edtLCLoad.SetWindowText( _T("0.0") );

	m_edtLCLoad2.SetFont( &m_fntEdit );
	m_edtLCLoad2.SetForeColor( BLACK_COLOR );
	m_edtLCLoad2.SetBackColor( WHITE_COLOR );
	m_edtLCLoad2.SetReceivedFlag( 3 );
	m_edtLCLoad2.SetWindowText( _T("0.0") );
	
	// Unload Position
	m_edtUnloadX.SetFont( &m_fntEdit );
	m_edtUnloadX.SetForeColor( BLACK_COLOR );
	m_edtUnloadX.SetBackColor( WHITE_COLOR );
	m_edtUnloadX.SetReceivedFlag( 3 );
	m_edtUnloadX.SetWindowText( _T("0.0") );

	m_edtUnloadY.SetFont( &m_fntEdit );
	m_edtUnloadY.SetForeColor( BLACK_COLOR );
	m_edtUnloadY.SetBackColor( WHITE_COLOR );
	m_edtUnloadY.SetReceivedFlag( 3 );
	m_edtUnloadY.SetWindowText( _T("0.0") );

	// Unload Position2
	m_edtUnloadX2.SetFont( &m_fntEdit );
	m_edtUnloadX2.SetForeColor( BLACK_COLOR );
	m_edtUnloadX2.SetBackColor( WHITE_COLOR );
	m_edtUnloadX2.SetReceivedFlag( 3 );
	m_edtUnloadX2.SetWindowText( _T("0.0") );

	m_edtUnloadY2.SetFont( &m_fntEdit );
	m_edtUnloadY2.SetForeColor( BLACK_COLOR );
	m_edtUnloadY2.SetBackColor( WHITE_COLOR );
	m_edtUnloadY2.SetReceivedFlag( 3 );
	m_edtUnloadY2.SetWindowText( _T("0.0") );


	// Unload Carrier Position
	m_edtUCCart.SetFont( &m_fntEdit );
	m_edtUCCart.SetForeColor( BLACK_COLOR );
	m_edtUCCart.SetBackColor( WHITE_COLOR );
	m_edtUCCart.SetReceivedFlag( 3 );
	m_edtUCCart.SetWindowText( _T("0.0") );
	
	m_edtUCUnload.SetFont( &m_fntEdit );
	m_edtUCUnload.SetForeColor( BLACK_COLOR );
	m_edtUCUnload.SetBackColor( WHITE_COLOR );
	m_edtUCUnload.SetReceivedFlag( 3 );
	m_edtUCUnload.SetWindowText( _T("0.0") );

	m_edtUCUnload2.SetFont( &m_fntEdit );
	m_edtUCUnload2.SetForeColor( BLACK_COLOR );
	m_edtUCUnload2.SetBackColor( WHITE_COLOR );
	m_edtUCUnload2.SetReceivedFlag( 3 );
	m_edtUCUnload2.SetWindowText( _T("0.0") );

	m_edtUCAlign.SetFont( &m_fntEdit );
	m_edtUCAlign.SetForeColor( BLACK_COLOR );
	m_edtUCAlign.SetBackColor( WHITE_COLOR );
	m_edtUCAlign.SetReceivedFlag( 3 );
	m_edtUCAlign.SetWindowText( _T("0.0") );

	// Table Unclamp Limit
	m_edtUnclampLimit.SetFont( &m_fntEdit );
	m_edtUnclampLimit.SetForeColor( BLACK_COLOR );
	m_edtUnclampLimit.SetBackColor( WHITE_COLOR );
	m_edtUnclampLimit.SetReceivedFlag( 3 );
	m_edtUnclampLimit.SetWindowText( _T("0.0") );

	// 1'st Height Sensor Position
	m_edt1stThicknessManualX.SetFont( &m_fntEdit );
	m_edt1stThicknessManualX.SetForeColor( BLACK_COLOR );
	m_edt1stThicknessManualX.SetBackColor( WHITE_COLOR );
	m_edt1stThicknessManualX.SetReceivedFlag( 3 );
	m_edt1stThicknessManualX.SetWindowText( _T("0.0") );

	m_edt1stThicknessManualY.SetFont( &m_fntEdit );
	m_edt1stThicknessManualY.SetForeColor( BLACK_COLOR );
	m_edt1stThicknessManualY.SetBackColor( WHITE_COLOR );
	m_edt1stThicknessManualY.SetReceivedFlag( 3 );
	m_edt1stThicknessManualY.SetWindowText( _T("0.0") );

	m_edt1stThicknessAutoX.SetFont( &m_fntEdit );
	m_edt1stThicknessAutoX.SetForeColor( BLACK_COLOR );
	m_edt1stThicknessAutoX.SetBackColor( WHITE_COLOR );
	m_edt1stThicknessAutoX.SetReceivedFlag( 3 );
	m_edt1stThicknessAutoX.SetWindowText( _T("0.0") );

	m_edt1stThicknessAutoY.SetFont( &m_fntEdit );
	m_edt1stThicknessAutoY.SetForeColor( BLACK_COLOR );
	m_edt1stThicknessAutoY.SetBackColor( WHITE_COLOR );
	m_edt1stThicknessAutoY.SetReceivedFlag( 3 );
	m_edt1stThicknessAutoY.SetWindowText( _T("0.0") );

	m_edt1stThicknessOffsetX.SetFont( &m_fntEdit );
	m_edt1stThicknessOffsetX.SetForeColor( BLACK_COLOR );
	m_edt1stThicknessOffsetX.SetBackColor( WHITE_COLOR );
	m_edt1stThicknessOffsetX.SetReceivedFlag( 3 );
	m_edt1stThicknessOffsetX.SetWindowText( _T("0.0") );

	m_edt1stThicknessOffsetY.SetFont( &m_fntEdit );
	m_edt1stThicknessOffsetY.SetForeColor( BLACK_COLOR );
	m_edt1stThicknessOffsetY.SetBackColor( WHITE_COLOR );
	m_edt1stThicknessOffsetY.SetReceivedFlag( 3 );
	m_edt1stThicknessOffsetY.SetWindowText( _T("0.0") );

	m_edt1stThicknessBaseZ.SetFont( &m_fntEdit );
	m_edt1stThicknessBaseZ.SetForeColor( BLACK_COLOR );
	m_edt1stThicknessBaseZ.SetBackColor( WHITE_COLOR );
	m_edt1stThicknessBaseZ.SetReceivedFlag( 3 );
	m_edt1stThicknessBaseZ.SetWindowText( _T("0.0") );

	m_edt1stThicknessHeadZ.SetFont( &m_fntEdit );
	m_edt1stThicknessHeadZ.SetForeColor( BLACK_COLOR );
	m_edt1stThicknessHeadZ.SetBackColor( WHITE_COLOR );
	m_edt1stThicknessHeadZ.SetReceivedFlag( 3 );
	m_edt1stThicknessHeadZ.SetWindowText( _T("0.0") );

	// 1'st Powermeter Position
	m_edt1stPowermeterX.SetFont( &m_fntEdit );
	m_edt1stPowermeterX.SetForeColor( BLACK_COLOR );
	m_edt1stPowermeterX.SetBackColor( WHITE_COLOR );
	m_edt1stPowermeterX.SetReceivedFlag( 3 );
	m_edt1stPowermeterX.SetWindowText( _T("0.0") );
	
	m_edt1stPowermeterY.SetFont( &m_fntEdit );
	m_edt1stPowermeterY.SetForeColor( BLACK_COLOR );
	m_edt1stPowermeterY.SetBackColor( WHITE_COLOR );
	m_edt1stPowermeterY.SetReceivedFlag( 3 );
	m_edt1stPowermeterY.SetWindowText( _T("0.0") );

	// 2'nd Height Sensor Position
	m_edt2ndThicknessManualX.SetFont( &m_fntEdit );
	m_edt2ndThicknessManualX.SetForeColor( BLACK_COLOR );
	m_edt2ndThicknessManualX.SetBackColor( WHITE_COLOR );
	m_edt2ndThicknessManualX.SetReceivedFlag( 3 );
	m_edt2ndThicknessManualX.SetWindowText( _T("0.0") );

	m_edt2ndThicknessManualY.SetFont( &m_fntEdit );
	m_edt2ndThicknessManualY.SetForeColor( BLACK_COLOR );
	m_edt2ndThicknessManualY.SetBackColor( WHITE_COLOR );
	m_edt2ndThicknessManualY.SetReceivedFlag( 3 );
	m_edt2ndThicknessManualY.SetWindowText( _T("0.0") );

	m_edt2ndThicknessAutoX.SetFont( &m_fntEdit );
	m_edt2ndThicknessAutoX.SetForeColor( BLACK_COLOR );
	m_edt2ndThicknessAutoX.SetBackColor( WHITE_COLOR );
	m_edt2ndThicknessAutoX.SetReceivedFlag( 3 );
	m_edt2ndThicknessAutoX.SetWindowText( _T("0.0") );

	m_edt2ndThicknessAutoY.SetFont( &m_fntEdit );
	m_edt2ndThicknessAutoY.SetForeColor( BLACK_COLOR );
	m_edt2ndThicknessAutoY.SetBackColor( WHITE_COLOR );
	m_edt2ndThicknessAutoY.SetReceivedFlag( 3 );
	m_edt2ndThicknessAutoY.SetWindowText( _T("0.0") );

	m_edt2ndThicknessOffsetX.SetFont( &m_fntEdit );
	m_edt2ndThicknessOffsetX.SetForeColor( BLACK_COLOR );
	m_edt2ndThicknessOffsetX.SetBackColor( WHITE_COLOR );
	m_edt2ndThicknessOffsetX.SetReceivedFlag( 3 );
	m_edt2ndThicknessOffsetX.SetWindowText( _T("0.0") );

	m_edt2ndThicknessOffsetY.SetFont( &m_fntEdit );
	m_edt2ndThicknessOffsetY.SetForeColor( BLACK_COLOR );
	m_edt2ndThicknessOffsetY.SetBackColor( WHITE_COLOR );
	m_edt2ndThicknessOffsetY.SetReceivedFlag( 3 );
	m_edt2ndThicknessOffsetY.SetWindowText( _T("0.0") );

	m_edt2ndThicknessBaseZ.SetFont( &m_fntEdit );
	m_edt2ndThicknessBaseZ.SetForeColor( BLACK_COLOR );
	m_edt2ndThicknessBaseZ.SetBackColor( WHITE_COLOR );
	m_edt2ndThicknessBaseZ.SetReceivedFlag( 3 );
	m_edt2ndThicknessBaseZ.SetWindowText( _T("0.0") );

	m_edt2ndThicknessHeadZ.SetFont( &m_fntEdit );
	m_edt2ndThicknessHeadZ.SetForeColor( BLACK_COLOR );
	m_edt2ndThicknessHeadZ.SetBackColor( WHITE_COLOR );
	m_edt2ndThicknessHeadZ.SetReceivedFlag( 3 );
	m_edt2ndThicknessHeadZ.SetWindowText( _T("0.0") );

	// 2'nd Powermeter Position
	m_edt2ndPowermeterX.SetFont( &m_fntEdit );
	m_edt2ndPowermeterX.SetForeColor( BLACK_COLOR );
	m_edt2ndPowermeterX.SetBackColor( WHITE_COLOR );
	m_edt2ndPowermeterX.SetReceivedFlag( 3 );
	m_edt2ndPowermeterX.SetWindowText( _T("0.0") );

	m_edt2ndPowermeterY.SetFont( &m_fntEdit );
	m_edt2ndPowermeterY.SetForeColor( BLACK_COLOR );
	m_edt2ndPowermeterY.SetBackColor( WHITE_COLOR );
	m_edt2ndPowermeterY.SetReceivedFlag( 3 );
	m_edt2ndPowermeterY.SetWindowText( _T("0.0") );

	// Suction Point
	m_edtSuctionNo.SetFont( &m_fntEdit );
	m_edtSuctionNo.SetForeColor( BLACK_COLOR );
	m_edtSuctionNo.SetBackColor( WHITE_COLOR );
	m_edtSuctionNo.SetReceivedFlag( 1 );
	m_edtSuctionNo.SetWindowText( _T("0") );
	m_edtSuctionNo.EnableWindow(FALSE);

	m_edtSuctionTableX.SetFont( &m_fntEdit );
	m_edtSuctionTableX.SetForeColor( BLACK_COLOR );
	m_edtSuctionTableX.SetBackColor( WHITE_COLOR );
	m_edtSuctionTableX.SetReceivedFlag( 3 );
	m_edtSuctionTableX.SetWindowText( _T("0.0") );

	m_edtSuctionTableY.SetFont( &m_fntEdit );
	m_edtSuctionTableY.SetForeColor( BLACK_COLOR );
	m_edtSuctionTableY.SetBackColor( WHITE_COLOR );
	m_edtSuctionTableY.SetReceivedFlag( 3 );
	m_edtSuctionTableY.SetWindowText( _T("0.0") );

	if( 1 > gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		m_edt1stThicknessManualX.SetWindowText( _T("NO USE") );
		m_edt1stThicknessManualX.EnableWindow(FALSE);
		
		m_edt1stThicknessManualY.SetWindowText( _T("NO USE") );
		m_edt1stThicknessManualY.EnableWindow(FALSE);
		
		m_edt1stThicknessAutoX.SetWindowText( _T("NO USE") );
		m_edt1stThicknessAutoX.EnableWindow(FALSE);
		
		m_edt1stThicknessAutoY.SetWindowText( _T("NO USE") );
		m_edt1stThicknessAutoY.EnableWindow(FALSE);
		
		m_edt1stThicknessOffsetX.SetWindowText( _T("NO USE") );
		m_edt1stThicknessOffsetX.EnableWindow(FALSE);
		
		m_edt1stThicknessOffsetY.SetWindowText( _T("NO USE") );
		m_edt1stThicknessOffsetY.EnableWindow(FALSE);
		
		m_edt1stThicknessHeadZ.SetWindowText( _T("NO USE") );
		m_edt1stThicknessHeadZ.EnableWindow(FALSE);
		
		m_edt1stThicknessBaseZ.SetWindowText( _T("NO USE") );
		m_edt1stThicknessBaseZ.EnableWindow(FALSE);
	}
	if( 2 > gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		m_edt2ndThicknessManualX.SetWindowText( _T("NO USE") );
		m_edt2ndThicknessManualX.EnableWindow(FALSE);

		m_edt2ndThicknessManualY.SetWindowText( _T("NO USE") );
		m_edt2ndThicknessManualY.EnableWindow(FALSE);

		m_edt2ndThicknessAutoX.SetWindowText( _T("NO USE") );
		m_edt2ndThicknessAutoX.EnableWindow(FALSE);

		m_edt2ndThicknessAutoY.SetWindowText( _T("NO USE") );
		m_edt2ndThicknessAutoY.EnableWindow(FALSE);

		m_edt2ndThicknessOffsetX.SetWindowText( _T("NO USE") );
		m_edt2ndThicknessOffsetX.EnableWindow(FALSE);

		m_edt2ndThicknessOffsetY.SetWindowText( _T("NO USE") );
		m_edt2ndThicknessOffsetY.EnableWindow(FALSE);

		m_edt2ndThicknessHeadZ.SetWindowText( _T("NO USE") );
		m_edt2ndThicknessHeadZ.EnableWindow(FALSE);

		m_edt2ndThicknessBaseZ.SetWindowText( _T("NO USE") );
		m_edt2ndThicknessBaseZ.EnableWindow(FALSE);
	}

//	if(!gSystemINI.m_sHardWare.nDustTableUse)
	{
		m_edtSuctionNo.ShowWindow(SW_HIDE);
		m_edtSuctionTableX.ShowWindow(SW_HIDE);
		m_edtSuctionTableY.ShowWindow(SW_HIDE);
	}
	
	if(gSystemINI.m_sHardWare.nManualMachine)
	{
//		m_edtLoadX.EnableWindow(FALSE);
//		m_edtLoadY.EnableWindow(FALSE);
		m_edtLoadX2.EnableWindow(FALSE);
		m_edtLoadY2.EnableWindow(FALSE);
//		m_edtUnloadX.EnableWindow(FALSE);
//		m_edtUnloadY.EnableWindow(FALSE);
	}

	m_edtSCalMinX.SetFont( &m_fntEdit );
	m_edtSCalMinX.SetForeColor( BLACK_COLOR );
	m_edtSCalMinX.SetBackColor( WHITE_COLOR );
	m_edtSCalMinX.SetReceivedFlag( 3 );
	m_edtSCalMinX.SetWindowText( _T("0.0") );
	m_edtSCalMinX.EnableWindow(FALSE);
	
	m_edtSCalMinY.SetFont( &m_fntEdit );
	m_edtSCalMinY.SetForeColor( BLACK_COLOR );
	m_edtSCalMinY.SetBackColor( WHITE_COLOR );
	m_edtSCalMinY.SetReceivedFlag( 3 );
	m_edtSCalMinY.SetWindowText( _T("0.0") );
	m_edtSCalMinY.EnableWindow(FALSE);
	
	m_edtSCalMaxX.SetFont( &m_fntEdit );
	m_edtSCalMaxX.SetForeColor( BLACK_COLOR );
	m_edtSCalMaxX.SetBackColor( WHITE_COLOR );
	m_edtSCalMaxX.SetReceivedFlag( 3 );
	m_edtSCalMaxX.SetWindowText( _T("0.0") );
	m_edtSCalMaxX.EnableWindow(FALSE);
	
	m_edtSCalMaxY.SetFont( &m_fntEdit );
	m_edtSCalMaxY.SetForeColor( BLACK_COLOR );
	m_edtSCalMaxY.SetBackColor( WHITE_COLOR );
	m_edtSCalMaxY.SetReceivedFlag( 3 );
	m_edtSCalMaxY.SetWindowText( _T("0.0") );
	m_edtSCalMaxY.EnableWindow(FALSE);

	m_edtIdleShotX.SetFont( &m_fntEdit );
	m_edtIdleShotX.SetForeColor( BLACK_COLOR );
	m_edtIdleShotX.SetBackColor( WHITE_COLOR );
	m_edtIdleShotX.SetReceivedFlag( 3 );
	m_edtIdleShotX.SetWindowText( _T("0.0") );

	m_edtIdleShotY.SetFont( &m_fntEdit );
	m_edtIdleShotY.SetForeColor( BLACK_COLOR );
	m_edtIdleShotY.SetBackColor( WHITE_COLOR );
	m_edtIdleShotY.SetReceivedFlag( 3 );
	m_edtIdleShotY.SetWindowText( _T("0.0") );

	m_edtIdleShotZ1.SetFont( &m_fntEdit );
	m_edtIdleShotZ1.SetForeColor( BLACK_COLOR );
	m_edtIdleShotZ1.SetBackColor( WHITE_COLOR );
	m_edtIdleShotZ1.SetReceivedFlag( 3 );
	m_edtIdleShotZ1.SetWindowText( _T("0.0") );

	m_edtIdleShotZ2.SetFont( &m_fntEdit );
	m_edtIdleShotZ2.SetForeColor( BLACK_COLOR );
	m_edtIdleShotZ2.SetBackColor( WHITE_COLOR );
	m_edtIdleShotZ2.SetReceivedFlag( 3 );
	m_edtIdleShotY.SetWindowText( _T("0.0") );

	// TC Lens Cleaning Position
	m_edtTCCleanX.SetFont( &m_fntEdit );
	m_edtTCCleanX.SetForeColor( BLACK_COLOR );
	m_edtTCCleanX.SetBackColor( WHITE_COLOR );
	m_edtTCCleanX.SetReceivedFlag( 3 );
	m_edtTCCleanX.SetWindowText( _T("0.0") );

	m_edtTCCleanY.SetFont( &m_fntEdit );
	m_edtTCCleanY.SetForeColor( BLACK_COLOR );
	m_edtTCCleanY.SetBackColor( WHITE_COLOR );
	m_edtTCCleanY.SetReceivedFlag( 3 );
	m_edtTCCleanY.SetWindowText( _T("0.0") );

	m_edtTCCleanZ1.SetFont( &m_fntEdit );
	m_edtTCCleanZ1.SetForeColor( BLACK_COLOR );
	m_edtTCCleanZ1.SetBackColor( WHITE_COLOR );
	m_edtTCCleanZ1.SetReceivedFlag( 3 );
	m_edtTCCleanZ1.SetWindowText( _T("0.0") );

	m_edtTCCleanZ2.SetFont( &m_fntEdit );
	m_edtTCCleanZ2.SetForeColor( BLACK_COLOR );
	m_edtTCCleanZ2.SetBackColor( WHITE_COLOR );
	m_edtTCCleanZ2.SetReceivedFlag( 3 );
	m_edtTCCleanZ2.SetWindowText( _T("0.0") );

}

void CPaneProcessSetupProcessLarge::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnSuctionAdd.SetFont( &m_fntBtn );
	m_btnSuctionAdd.SetFlat( FALSE );
	m_btnSuctionAdd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuctionAdd.EnableBallonToolTip();
	m_btnSuctionAdd.SetToolTipText( _T("Position Add") );
	m_btnSuctionAdd.SetBtnCursor( IDC_HAND_1 );
	
	m_btnSuctionDelete.SetFont( &m_fntBtn );
	m_btnSuctionDelete.SetFlat( FALSE );
	m_btnSuctionDelete.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuctionDelete.EnableBallonToolTip();
	m_btnSuctionDelete.SetToolTipText( _T("Position Delete") );
	m_btnSuctionDelete.SetBtnCursor( IDC_HAND_1 );
	
	m_btnSuctionUpdate.SetFont( &m_fntBtn );
	m_btnSuctionUpdate.SetFlat( FALSE );
	m_btnSuctionUpdate.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuctionUpdate.EnableBallonToolTip();
	m_btnSuctionUpdate.SetToolTipText( _T("Position Update") );
	m_btnSuctionUpdate.SetBtnCursor( IDC_HAND_1 );

	if(gSystemINI.m_sHardWare.nLaserType != LASER_UV)
	{
		m_btnSuctionAdd.ShowWindow(SW_HIDE);
		m_btnSuctionDelete.ShowWindow(SW_HIDE);
		m_btnSuctionUpdate.ShowWindow(SW_HIDE);
	}

	m_btnLoadPosition.SetFont( &m_fntBtn );
	m_btnLoadPosition.SetFlat( FALSE );
	m_btnLoadPosition.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadPosition.EnableBallonToolTip();
	m_btnLoadPosition.SetToolTipText( _T("Set load pos. to current pos.") );
	m_btnLoadPosition.SetBtnCursor( IDC_HAND_1 );

	m_btnUnloadPosition.SetFont( &m_fntBtn );
	m_btnUnloadPosition.SetFlat( FALSE );
	m_btnUnloadPosition.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadPosition.EnableBallonToolTip();
	m_btnUnloadPosition.SetToolTipText( _T("Set unload pos. to current pos.") );
	m_btnUnloadPosition.SetBtnCursor( IDC_HAND_1 );

	m_btnLoadPosition2.SetFont( &m_fntBtn );
	m_btnLoadPosition2.SetFlat( FALSE );
	m_btnLoadPosition2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadPosition2.EnableBallonToolTip();
	m_btnLoadPosition2.SetToolTipText( _T("Set load pos.2 to current pos.") );
	m_btnLoadPosition2.SetBtnCursor( IDC_HAND_1 );

	m_btnUnloadPosition2.SetFont( &m_fntBtn );
	m_btnUnloadPosition2.SetFlat( FALSE );
	m_btnUnloadPosition2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadPosition2.EnableBallonToolTip();
	m_btnUnloadPosition2.SetToolTipText( _T("Set unload pos.2 to current pos.") );
	m_btnUnloadPosition2.SetBtnCursor( IDC_HAND_1 );


	m_btnLCCartPosition.SetFont( &m_fntBtn );
	m_btnLCCartPosition.SetFlat( FALSE );
	m_btnLCCartPosition.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLCCartPosition.EnableBallonToolTip();
	m_btnLCCartPosition.SetToolTipText( _T("Suction Down") );
	m_btnLCCartPosition.SetBtnCursor( IDC_HAND_1 );

	m_btnLCLoadPosition.SetFont( &m_fntBtn );
	m_btnLCLoadPosition.SetFlat( FALSE );
	m_btnLCLoadPosition.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLCLoadPosition.EnableBallonToolTip();
	m_btnLCLoadPosition.SetToolTipText( _T("Suction Down") );
	m_btnLCLoadPosition.SetBtnCursor( IDC_HAND_1 );

	m_btnLCAlignPosition.SetFont( &m_fntBtn );
	m_btnLCAlignPosition.SetFlat( FALSE );
	m_btnLCAlignPosition.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLCAlignPosition.EnableBallonToolTip();
	m_btnLCAlignPosition.SetToolTipText( _T("Suction Down") );
	m_btnLCAlignPosition.SetBtnCursor( IDC_HAND_1 );

	m_btnUCCartPosition.SetFont( &m_fntBtn );
	m_btnUCCartPosition.SetFlat( FALSE );
	m_btnUCCartPosition.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUCCartPosition.EnableBallonToolTip();
	m_btnUCCartPosition.SetToolTipText( _T("Suction Down") );
	m_btnUCCartPosition.SetBtnCursor( IDC_HAND_1 );

	m_btnUCUnloadPosition.SetFont( &m_fntBtn );
	m_btnUCUnloadPosition.SetFlat( FALSE );
	m_btnUCUnloadPosition.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUCUnloadPosition.EnableBallonToolTip();
	m_btnUCUnloadPosition.SetToolTipText( _T("Suction Down") );
	m_btnUCUnloadPosition.SetBtnCursor( IDC_HAND_1 );

	m_btnUCAlignPosition.SetFont( &m_fntBtn );
	m_btnUCAlignPosition.SetFlat( FALSE );
	m_btnUCAlignPosition.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUCAlignPosition.EnableBallonToolTip();
	m_btnUCAlignPosition.SetToolTipText( _T("Suction Down") );
	m_btnUCAlignPosition.SetBtnCursor( IDC_HAND_1 );

	m_cmbTool.SetFont( &m_fntCombo );
	m_cmbTool.SetCurSel( 0 );

	m_btnTCCleanPos.SetFont( &m_fntBtn );
	m_btnTCCleanPos.SetFlat( FALSE );
	m_btnTCCleanPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTCCleanPos.EnableBallonToolTip();
	m_btnTCCleanPos.SetToolTipText( _T("T/C Lens Cleaning Position.") );
	m_btnTCCleanPos.SetBtnCursor( IDC_HAND_1 );
}
void CPaneProcessSetupProcessLarge::InitComboControl()
{
	m_fntCombo.CreatePointFont(130, _T("Arial Bold"));

	m_cmbTool.SetFont( &m_fntCombo );
	m_cmbTool.SetCurSel( 0 );

	SetToolComboBox();
}
void CPaneProcessSetupProcessLarge::SetToolComboBox()
{
	m_cmbTool.ResetContent();

	CString strTool;

	for(int i = 0; i <= gBeamPathINI.m_sBeampath.nLastIndex; i++)
	{
		strTool.Format(_T("No %d : %s"), gBeamPathINI.m_sBeampath.nInfoId[i], gBeamPathINI.m_sBeampath.strInfoName[i]);
		m_cmbTool.AddString(strTool);
	}
}
void CPaneProcessSetupProcessLarge::InitListControl()
{
	// Set List Font
	m_fntList.CreatePointFont(130, _T("Arial Bold"));

	m_listPosition.SetFont( &m_fntList );
	
	int nMaxColumnNum = 3;
	LV_COLUMN lvcolumn;
	CString strText;
	TCHAR szText[256] = {0,};
	
	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_CENTER;
	
	for(int i = 0 ; i < nMaxColumnNum ; i++ )
	{
		switch( i )
		{
		case 0 :
			strText.Format(_T(" No"));
			lvcolumn.cx = 50;
			break;
		case 1 :
			strText.Format(_T("X"));
			lvcolumn.cx = 115;
			break;
		case 2 :
			strText.Format(_T("Y"));
			lvcolumn.cx = 115;
			break;
		}
		
		_stprintf_s( szText, _T("%s"), strText );
		lvcolumn.pszText = szText;
		lvcolumn.iSubItem = i;
		
		m_listPosition.InsertColumn(i, &lvcolumn);
	}
	
	DWORD dwStyle = m_listPosition.GetStyle();
	dwStyle |= LVS_EX_FULLROWSELECT;
	dwStyle |= LVS_EX_GRIDLINES;
	
	m_listPosition.SetExtendedStyle( dwStyle );
	
	m_listPosition.DeleteAllItems();

	if(gSystemINI.m_sHardWare.nLaserType != LASER_UV)
		m_listPosition.ShowWindow(SW_HIDE);
}

HBRUSH CPaneProcessSetupProcessLarge::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_LOAD_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LOAD_POS2)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LOAD_CARRIER_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_UNLOAD_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_UNLOAD_POS2)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_UNLOAD_CARRIER_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_1ST_THICKNESS_SENSOR_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_2ND_THICKNESS_SENSOR_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_1ST_POWERMETER_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_2ND_POWERMETER_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TABLE_UNCLAMP_LIMIT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_IDLE_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_CAL_POS2)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TC_CLEANING_POSITION)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0,0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneProcessSetupProcessLarge::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();
	m_fntList.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneProcessSetupProcessLarge::SetProcessPosition(SAUTOSETTING sAutoSetting)
{
	memcpy( &m_sAutoSetting, &sAutoSetting, sizeof(m_sAutoSetting) );

	DispProcessPosition();

	m_pRefuse = gVariable.m_pRefuse;

	AddItems();
}

void CPaneProcessSetupProcessLarge::GetProcessPosition(SAUTOSETTING* pAutoSetting)
{
	if( 0 == memcmp( pAutoSetting, &m_sAutoSetting, sizeof(m_sAutoSetting) ) )
		return;

	memcpy( pAutoSetting, &m_sAutoSetting, sizeof(m_sAutoSetting) );

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if( NULL == pMotor )
		return;

	pMotor->SetAutoSetting( m_sAutoSetting );
	pMotor->DownloadAutoSetting();
}

void CPaneProcessSetupProcessLarge::DispProcessPosition()
{
	CString strData;

	// Load Position #1 X, Y
	strData.Format(_T("%.3f"), m_sAutoSetting.dLoadPosX);
	m_edtLoadX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dLoadPosY);
	m_edtLoadY.SetWindowText( (LPCTSTR)strData );

	// Load Position #2 X, Y
	strData.Format(_T("%.3f"), m_sAutoSetting.dLoadPosX2);
	m_edtLoadX2.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dLoadPosY2);
	m_edtLoadY2.SetWindowText( (LPCTSTR)strData );

	// Load Carrier Position
	strData.Format(_T("%.3f"), m_sAutoSetting.dLoaderCartPos);
	m_edtLCCart.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dLoaderLoadPos);
	m_edtLCLoad.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dLoaderLoadPos2);
	m_edtLCLoad2.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dLoaderAlignPos);
	m_edtLCAlign.SetWindowText( (LPCTSTR)strData );

	// Unload Position X, Y
	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloadPosX);
	m_edtUnloadX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloadPosY);
	m_edtUnloadY.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloadPosX2);
	m_edtUnloadX2.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloadPosY2);
	m_edtUnloadY2.SetWindowText( (LPCTSTR)strData );


	// Unload Carrier Position
	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloaderCartPos);
	m_edtUCCart.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloaderUnloadPos);
	m_edtUCUnload.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloaderUnloadPos2);
	m_edtUCUnload2.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dUnloaderAlignPos);
	m_edtUCAlign.SetWindowText( (LPCTSTR)strData );

	// Table Unclamp Limit
	strData.Format(_T("%.3f"), m_sAutoSetting.dUnclampLimitY);
	m_edtUnclampLimit.SetWindowText( (LPCTSTR)strData );

	// 1'st Height Sensor
	strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dManualX);
	m_edt1stThicknessManualX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dManualY);
	m_edt1stThicknessManualY.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dAutoX);
	m_edt1stThicknessAutoX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dAutoY);
	m_edt1stThicknessAutoY.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dOffsetX);
	m_edt1stThicknessOffsetX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dOffsetY);
	m_edt1stThicknessOffsetY.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dBaseZ);
	m_edt1stThicknessBaseZ.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dHeadZ);
	m_edt1stThicknessHeadZ.SetWindowText( (LPCTSTR)strData );

	// 1'st Powermeter Positon X, Y
	strData.Format(_T("%.3f"), m_sAutoSetting.dPowermeterPos[0].x);
	m_edt1stPowermeterX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dPowermeterPos[0].y);
	m_edt1stPowermeterY.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dAutoCalMinTablePosX);
	m_edtSCalMinX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dAutoCalMinTablePosY);
	m_edtSCalMinY.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dAutoCalMaxTablePosX);
	m_edtSCalMaxX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dAutoCalMaxTablePosY);
	m_edtSCalMaxY.SetWindowText( (LPCTSTR)strData );

	if( 1 < gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		// 2'nd Height Sensor
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[1].dManualX);
		m_edt2ndThicknessManualX.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[1].dManualY);
		m_edt2ndThicknessManualY.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[1].dAutoX);
		m_edt2ndThicknessAutoX.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[1].dAutoY);
		m_edt2ndThicknessAutoY.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[1].dOffsetX);
		m_edt2ndThicknessOffsetX.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[1].dOffsetY);
		m_edt2ndThicknessOffsetY.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[1].dBaseZ);
		m_edt2ndThicknessBaseZ.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[1].dHeadZ);
		m_edt2ndThicknessHeadZ.SetWindowText( (LPCTSTR)strData );
	}
	else
	{
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dManualX);
		m_edt2ndThicknessManualX.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dManualY);
		m_edt2ndThicknessManualY.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dAutoX);
		m_edt2ndThicknessAutoX.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dAutoY);
		m_edt2ndThicknessAutoY.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dOffsetX);
		m_edt2ndThicknessOffsetX.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dOffsetY);
		m_edt2ndThicknessOffsetY.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dBaseZ);
		m_edt2ndThicknessBaseZ.SetWindowText( (LPCTSTR)strData );
		strData.Format(_T("%.3f"), m_sAutoSetting.sHeightSensor[0].dHeadZ);
		m_edt2ndThicknessHeadZ.SetWindowText( (LPCTSTR)strData );
	}

	// 2'nd Powermeter Positon X, Y
	strData.Format(_T("%.3f"), m_sAutoSetting.dPowermeterPos[1].x);
	m_edt2ndPowermeterX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dPowermeterPos[1].y);
	m_edt2ndPowermeterY.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dIdleShotTablePosX);
	m_edtIdleShotX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dIdleShotTablePosY);
	m_edtIdleShotY.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sAutoSetting.dIdleShotTablePosZ1);
	m_edtIdleShotZ1.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dIdleShotTablePosZ2);
	m_edtIdleShotZ2.SetWindowText( (LPCTSTR)strData );

	SetToolComboBox();
	m_cmbTool.SetCurSel(m_sAutoSetting.nIdleShotBeamPathNo);

	// TC Cleaning Position
	strData.Format(_T("%.3f"), m_sAutoSetting.dTCCleanPosX);
	m_edtTCCleanX.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dTCCleanPosY);
	m_edtTCCleanY.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dTCCleanPosZ1);
	m_edtTCCleanZ1.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%.3f"), m_sAutoSetting.dTCCleanPosZ2);
	m_edtTCCleanZ2.SetWindowText( (LPCTSTR)strData );
}

BOOL CPaneProcessSetupProcessLarge::OnApply()
{
	CString strData;
	double dIdleX, dIdleY;
	m_edtIdleShotX.GetWindowText( strData );
	dIdleX= atof( (LPSTR)(LPCTSTR)strData );

	m_edtIdleShotY.GetWindowText( strData );
	dIdleY = atof( (LPSTR)(LPCTSTR)strData );
	
	if(dIdleX >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX - gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
		dIdleX <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + gSystemINI.m_sSystemDevice.dFieldSize.x/2 &&
		dIdleY >= gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY - gSystemINI.m_sSystemDevice.dFieldSize.y/2 &&
		dIdleY <= gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY + gSystemINI.m_sSystemDevice.dFieldSize.y/2 )
	{
		CString strM;
		strM.Format(_T("T Shot Position Setting Error : You Can't drill in Auto S. Cal. Area.\nCal. Area Min. X = %.3f, Area Min. Y = %.3f\nCal. Area Max. X = %.3f, Area Max. Y = %.3f"),
			gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY, 
			gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX, gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY);
		ErrMessage(strM);
		return FALSE;
	}
	m_sAutoSetting.dIdleShotTablePosX = dIdleX;
	m_sAutoSetting.dIdleShotTablePosY = dIdleY;

	m_edtIdleShotZ1.GetWindowText( strData );
	m_sAutoSetting.dIdleShotTablePosZ1 = atof( (LPSTR)(LPCTSTR)strData );

	m_edtIdleShotZ2.GetWindowText( strData );
	m_sAutoSetting.dIdleShotTablePosZ2 = atof( (LPSTR)(LPCTSTR)strData );


	m_sAutoSetting.nIdleShotBeamPathNo = m_cmbTool.GetCurSel();
	// Load Position #1 X, Y
	m_edtLoadX.GetWindowText( strData );
	m_sAutoSetting.dLoadPosX = atof( (LPSTR)(LPCTSTR)strData );
	m_edtLoadY.GetWindowText( strData );
	m_sAutoSetting.dLoadPosY = atof( (LPSTR)(LPCTSTR)strData );

	// Load Position #2 X, Y
	m_edtLoadX2.GetWindowText( strData );
	m_sAutoSetting.dLoadPosX2 = atof( (LPSTR)(LPCTSTR)strData );
	m_edtLoadY2.GetWindowText( strData );
	m_sAutoSetting.dLoadPosY2 = atof( (LPSTR)(LPCTSTR)strData );

	// Load Carrier Position
	m_edtLCCart.GetWindowText( strData );
	m_sAutoSetting.dLoaderCartPos = atof( (LPSTR)(LPCTSTR)strData );
	m_edtLCLoad.GetWindowText( strData );
	m_sAutoSetting.dLoaderLoadPos = atof( (LPSTR)(LPCTSTR)strData );
	m_edtLCLoad2.GetWindowText( strData );
	m_sAutoSetting.dLoaderLoadPos2 = atof( (LPSTR)(LPCTSTR)strData );
	m_edtLCAlign.GetWindowText( strData );
	m_sAutoSetting.dLoaderAlignPos = atof( (LPSTR)(LPCTSTR)strData );

	// Unload Position X, Y
	m_edtUnloadX.GetWindowText( strData );
	m_sAutoSetting.dUnloadPosX = atof( (LPSTR)(LPCTSTR)strData );
	m_edtUnloadY.GetWindowText( strData );
	m_sAutoSetting.dUnloadPosY = atof( (LPSTR)(LPCTSTR)strData );

	m_edtUnloadX2.GetWindowText( strData );
	m_sAutoSetting.dUnloadPosX2 = atof( (LPSTR)(LPCTSTR)strData );
	m_edtUnloadY2.GetWindowText( strData );
	m_sAutoSetting.dUnloadPosY2 = atof( (LPSTR)(LPCTSTR)strData );

	// Unload Carrier Position
	m_edtUCCart.GetWindowText( strData );
	m_sAutoSetting.dUnloaderCartPos = atof( (LPSTR)(LPCTSTR)strData );
	m_edtUCUnload.GetWindowText( strData );
	m_sAutoSetting.dUnloaderUnloadPos = atof( (LPSTR)(LPCTSTR)strData );
	m_edtUCUnload2.GetWindowText( strData );
	m_sAutoSetting.dUnloaderUnloadPos2 = atof( (LPSTR)(LPCTSTR)strData );
	m_edtUCAlign.GetWindowText( strData );
	m_sAutoSetting.dUnloaderAlignPos = atof( (LPSTR)(LPCTSTR)strData );

	// Table Unclamp Limit
	m_edtUnclampLimit.GetWindowText( strData );
	m_sAutoSetting.dUnclampLimitY = atof( (LPSTR)(LPCTSTR)strData );

	// 1'st Height Sensor
	m_edt1stThicknessManualX.GetWindowText( strData );
	m_sAutoSetting.sHeightSensor[0].dManualX = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edt1stThicknessManualY.GetWindowText( strData );
	m_sAutoSetting.sHeightSensor[0].dManualY = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edt1stThicknessAutoX.GetWindowText( strData );
	m_sAutoSetting.sHeightSensor[0].dAutoX = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edt1stThicknessAutoY.GetWindowText( strData );
	m_sAutoSetting.sHeightSensor[0].dAutoY = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edt1stThicknessOffsetX.GetWindowText( strData );
	m_sAutoSetting.sHeightSensor[0].dOffsetX = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edt1stThicknessOffsetY.GetWindowText( strData );
	m_sAutoSetting.sHeightSensor[0].dOffsetY = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edt1stThicknessBaseZ.GetWindowText( strData );
	m_sAutoSetting.sHeightSensor[0].dBaseZ = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edt1stThicknessHeadZ.GetWindowText( strData );
	m_sAutoSetting.sHeightSensor[0].dHeadZ = atof( (LPSTR)(LPCTSTR)strData );

	// 1'st Powermeter Positon X, Y
	m_edt1stPowermeterX.GetWindowText( strData );
	m_sAutoSetting.dPowermeterPos[0].x = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edt1stPowermeterY.GetWindowText( strData );
	m_sAutoSetting.dPowermeterPos[0].y = atof( (LPSTR)(LPCTSTR)strData );

	m_edtSCalMinX.GetWindowText( strData );
	m_sAutoSetting.dAutoCalMinTablePosX = atof( (LPSTR)(LPCTSTR)strData );
	m_edtSCalMinY.GetWindowText( strData );
	m_sAutoSetting.dAutoCalMinTablePosY = atof( (LPSTR)(LPCTSTR)strData );
	m_edtSCalMaxX.GetWindowText( strData );
	m_sAutoSetting.dAutoCalMaxTablePosX = atof( (LPSTR)(LPCTSTR)strData );
	m_edtSCalMaxY.GetWindowText( strData );
	m_sAutoSetting.dAutoCalMaxTablePosY = atof( (LPSTR)(LPCTSTR)strData );

	if( 1 < gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		// 2'nd Height Sensor
		m_edt2ndThicknessManualX.GetWindowText( strData );
		m_sAutoSetting.sHeightSensor[1].dManualX = atof( (LPSTR)(LPCTSTR)strData );
		
		m_edt2ndThicknessManualY.GetWindowText( strData );
		m_sAutoSetting.sHeightSensor[1].dManualY = atof( (LPSTR)(LPCTSTR)strData );
	
		m_edt2ndThicknessAutoX.GetWindowText( strData );
		m_sAutoSetting.sHeightSensor[1].dAutoX = atof( (LPSTR)(LPCTSTR)strData );
		
		m_edt2ndThicknessAutoY.GetWindowText( strData );
		m_sAutoSetting.sHeightSensor[1].dAutoY = atof( (LPSTR)(LPCTSTR)strData );
		
		m_edt2ndThicknessOffsetX.GetWindowText( strData );
		m_sAutoSetting.sHeightSensor[1].dOffsetX = atof( (LPSTR)(LPCTSTR)strData );	
		
		m_edt2ndThicknessOffsetY.GetWindowText( strData );
		m_sAutoSetting.sHeightSensor[1].dOffsetY = atof( (LPSTR)(LPCTSTR)strData );
		
		m_edt2ndThicknessBaseZ.GetWindowText( strData );
		m_sAutoSetting.sHeightSensor[1].dBaseZ = atof( (LPSTR)(LPCTSTR)strData );
		
		m_edt2ndThicknessHeadZ.GetWindowText( strData );
		m_sAutoSetting.sHeightSensor[1].dHeadZ = atof( (LPSTR)(LPCTSTR)strData );		
	}
	else
	{
		m_sAutoSetting.sHeightSensor[1].dManualX = m_sAutoSetting.sHeightSensor[0].dManualX;
		m_sAutoSetting.sHeightSensor[1].dManualY = m_sAutoSetting.sHeightSensor[0].dManualY;
		m_sAutoSetting.sHeightSensor[1].dAutoX = m_sAutoSetting.sHeightSensor[0].dAutoX;
		m_sAutoSetting.sHeightSensor[1].dAutoY = m_sAutoSetting.sHeightSensor[0].dAutoY;
		m_sAutoSetting.sHeightSensor[1].dOffsetX = m_sAutoSetting.sHeightSensor[0].dOffsetX;
		m_sAutoSetting.sHeightSensor[1].dOffsetY = m_sAutoSetting.sHeightSensor[0].dOffsetY;
		m_sAutoSetting.sHeightSensor[1].dBaseZ = m_sAutoSetting.sHeightSensor[0].dBaseZ;
		m_sAutoSetting.sHeightSensor[1].dHeadZ = m_sAutoSetting.sHeightSensor[0].dHeadZ;
	}

	

	// 2'nd Powermeter Positon X, Y
	m_edt2ndPowermeterX.GetWindowText( strData );
	m_sAutoSetting.dPowermeterPos[1].x = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edt2ndPowermeterY.GetWindowText( strData );
	m_sAutoSetting.dPowermeterPos[1].y = atof( (LPSTR)(LPCTSTR)strData );

	// TC Lens Cleaning Position
	m_edtTCCleanX.GetWindowText( strData );
	m_sAutoSetting.dTCCleanPosX = atof( (LPSTR)(LPCTSTR)strData );
	m_edtTCCleanY.GetWindowText( strData );
	m_sAutoSetting.dTCCleanPosY = atof( (LPSTR)(LPCTSTR)strData );
	m_edtTCCleanZ1.GetWindowText( strData );
	m_sAutoSetting.dTCCleanPosZ1 = atof( (LPSTR)(LPCTSTR)strData );
	m_edtTCCleanZ2.GetWindowText( strData );
	m_sAutoSetting.dTCCleanPosZ2 = atof( (LPSTR)(LPCTSTR)strData );

	return TRUE;

}

CString CPaneProcessSetupProcessLarge::GetChangeValueStr()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));

	if(m_sAutoSetting.dLoadPosX != gProcessINI.m_sProcessAutoSetting.dLoadPosX ||
		m_sAutoSetting.dLoadPosY != gProcessINI.m_sProcessAutoSetting.dLoadPosY)
	{
		strTemp.Format(_T("| Load Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dLoadPosX,
			m_sAutoSetting.dLoadPosY);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dLoadPosX2 != gProcessINI.m_sProcessAutoSetting.dLoadPosX2 ||
		m_sAutoSetting.dLoadPosY2 != gProcessINI.m_sProcessAutoSetting.dLoadPosY2)
	{
		strTemp.Format(_T("| Load Position 2 : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dLoadPosX2,
			m_sAutoSetting.dLoadPosY2);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dUnloadPosX != gProcessINI.m_sProcessAutoSetting.dUnloadPosX ||
		m_sAutoSetting.dUnloadPosY != gProcessINI.m_sProcessAutoSetting.dUnloadPosY)
	{
		strTemp.Format(_T("| Unload Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dUnloadPosX,
			m_sAutoSetting.dUnloadPosY);
		strMessage += strTemp;
	}

	if( 0 < gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		if(m_sAutoSetting.sHeightSensor[0].dManualX != gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dManualX ||
			m_sAutoSetting.sHeightSensor[0].dManualY != gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dManualY)
		{
			strTemp.Format(_T("| Manual H.S. : ( %.3f, %.3f)mm "), 
				m_sAutoSetting.sHeightSensor[0].dManualX,
				m_sAutoSetting.sHeightSensor[0].dManualY);
			strMessage += strTemp;
		}

		if(m_sAutoSetting.sHeightSensor[0].dAutoX != gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dAutoX ||
			m_sAutoSetting.sHeightSensor[0].dAutoY != gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dAutoY)
		{
			strTemp.Format(_T("| Auto H.S. : ( %.3f, %.3f)mm "), 
				m_sAutoSetting.sHeightSensor[0].dAutoX,
				m_sAutoSetting.sHeightSensor[0].dAutoY);
			strMessage += strTemp;
		}

		if(m_sAutoSetting.sHeightSensor[0].dBaseZ != gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dBaseZ)
		{
			strTemp.Format(_T("| H.S. Base Z : %.3f mm "), 
				m_sAutoSetting.sHeightSensor[0].dBaseZ);
			strMessage += strTemp;
		}

		if(m_sAutoSetting.sHeightSensor[0].dHeadZ != gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dHeadZ)
		{
			strTemp.Format(_T("| H.S. Head Z : %.3f mm "), 
				m_sAutoSetting.sHeightSensor[0].dHeadZ);
			strMessage += strTemp;
		}
	}

	if( 1 < gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		if(m_sAutoSetting.sHeightSensor[1].dManualX != gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dManualX ||
			m_sAutoSetting.sHeightSensor[1].dManualY != gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dManualY)
		{
			strTemp.Format(_T("| Manual H.S. 2 : ( %.3f, %.3f)mm "), 
				m_sAutoSetting.sHeightSensor[1].dManualX,
				m_sAutoSetting.sHeightSensor[1].dManualY);
			strMessage += strTemp;
		}
		
		if(m_sAutoSetting.sHeightSensor[1].dAutoX != gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dAutoX ||
			m_sAutoSetting.sHeightSensor[1].dAutoY != gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dAutoY)
		{
			strTemp.Format(_T("| Auto H.S. 2 : ( %.3f, %.3f)mm "), 
				m_sAutoSetting.sHeightSensor[1].dAutoX,
				m_sAutoSetting.sHeightSensor[1].dAutoY);
			strMessage += strTemp;
		}
		
		if(m_sAutoSetting.sHeightSensor[1].dBaseZ != gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dBaseZ)
		{
			strTemp.Format(_T("| H.S. Base Z 2 : %.3f mm "), 
				m_sAutoSetting.sHeightSensor[1].dBaseZ);
			strMessage += strTemp;
		}
		
		if(m_sAutoSetting.sHeightSensor[1].dHeadZ != gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dHeadZ)
		{
			strTemp.Format(_T("| H.S. Head Z 2 : %.3f mm "), 
				m_sAutoSetting.sHeightSensor[1].dHeadZ);
			strMessage += strTemp;
		}
	}

	if(m_sAutoSetting.dPowermeterPos[0].x != gProcessINI.m_sProcessAutoSetting.dPowermeterPos[0].x ||
		m_sAutoSetting.dPowermeterPos[0].y != gProcessINI.m_sProcessAutoSetting.dPowermeterPos[0].y)
	{
		strTemp.Format(_T("| Power M. Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dPowermeterPos[0].x,
			m_sAutoSetting.dPowermeterPos[0].y);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dPowermeterPos[1].x != gProcessINI.m_sProcessAutoSetting.dPowermeterPos[1].x ||
		m_sAutoSetting.dPowermeterPos[1].y != gProcessINI.m_sProcessAutoSetting.dPowermeterPos[1].y)
	{
		strTemp.Format(_T("| Power M. Position 2 : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dPowermeterPos[1].x,
			m_sAutoSetting.dPowermeterPos[1].y);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dIdleShotTablePosX != gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosX||
		m_sAutoSetting.dIdleShotTablePosY != gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosY)
	{
		strTemp.Format(_T("| Idle Position : ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dIdleShotTablePosX,
			m_sAutoSetting.dIdleShotTablePosY);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.dIdleShotTablePosZ1 != gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosZ1||
		m_sAutoSetting.dIdleShotTablePosZ2 != gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosZ2)
	{
		strTemp.Format(_T("| Idle Position Z: ( %.3f, %.3f)mm "), 
			m_sAutoSetting.dIdleShotTablePosZ1,
			m_sAutoSetting.dIdleShotTablePosZ2);
		strMessage += strTemp;
	}

	if(m_sAutoSetting.nIdleShotBeamPathNo != gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo)
	{
		strTemp.Format(_T("| Idle BeamPath : %d "), 
			m_sAutoSetting.nIdleShotBeamPathNo);
		strMessage += strTemp;
	}
	return strMessage;
}

void CPaneProcessSetupProcessLarge::EnableControl(BOOL bUse)
{
	m_edtLoadX.EnableWindow(bUse);
	m_edtLoadY.EnableWindow(bUse);
	m_edtLoadX2.EnableWindow(bUse);
	m_edtLoadY2.EnableWindow(bUse);
	m_edtLCCart.EnableWindow(bUse);
	m_edtLCLoad.EnableWindow(bUse);
	m_edtLCLoad2.EnableWindow(bUse);
	m_edtLCAlign.EnableWindow(bUse);

	m_edtUnloadX.EnableWindow(bUse);
	m_edtUnloadY.EnableWindow(bUse);
	m_edtUnloadX2.EnableWindow(bUse);
	m_edtUnloadY2.EnableWindow(bUse);
	m_edtUCCart.EnableWindow(bUse);
	m_edtUCUnload.EnableWindow(bUse);
	m_edtUCUnload2.EnableWindow(bUse);
	m_edtUCAlign.EnableWindow(bUse);
	if(gSystemINI.m_sHardWare.nManualMachine)
	{
//		m_edtLoadX.EnableWindow(FALSE);
//		m_edtLoadY.EnableWindow(FALSE);
		m_edtLoadX2.EnableWindow(FALSE);
		m_edtLoadY2.EnableWindow(FALSE);
//		m_edtUnloadX.EnableWindow(FALSE);
//		m_edtUnloadY.EnableWindow(FALSE);
	}


	if(gSystemINI.m_sHardWare.nTableClamp > 0)
		m_edtUnclampLimit.EnableWindow(bUse);

	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() != 0)
	{
		m_edt1stPowermeterX.EnableWindow(bUse);
		m_edt1stPowermeterY.EnableWindow(bUse);
		
		if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() != 1)
		{
			m_edt2ndPowermeterX.EnableWindow(bUse);
			m_edt2ndPowermeterY.EnableWindow(bUse);
		}
	}

	if( 0 < gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		m_edt1stThicknessManualX.EnableWindow(bUse);
		m_edt1stThicknessManualY.EnableWindow(bUse);
		
		m_edt1stThicknessAutoX.EnableWindow(bUse);
		m_edt1stThicknessAutoY.EnableWindow(bUse);
		
		m_edt1stThicknessBaseZ.EnableWindow(bUse);
		m_edt1stThicknessHeadZ.EnableWindow(bUse);
		
		m_edt1stThicknessOffsetX.EnableWindow(bUse);
		m_edt1stThicknessOffsetY.EnableWindow(bUse);
	}

	if( 1 < gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
	{
		m_edt2ndThicknessManualX.EnableWindow(bUse);
		m_edt2ndThicknessManualY.EnableWindow(bUse);

		m_edt2ndThicknessAutoX.EnableWindow(bUse);
		m_edt2ndThicknessAutoY.EnableWindow(bUse);

		m_edt2ndThicknessHeadZ.EnableWindow(bUse);
		m_edt2ndThicknessBaseZ.EnableWindow(bUse);

		m_edt2ndThicknessOffsetX.EnableWindow(bUse);
		m_edt2ndThicknessOffsetY.EnableWindow(bUse);
	}

	m_edtSuctionTableX.EnableWindow(bUse);
	m_edtSuctionTableY.EnableWindow(bUse);

	m_btnSuctionAdd.EnableWindow(bUse);
	m_btnSuctionDelete.EnableWindow(bUse);
	m_btnSuctionUpdate.EnableWindow(bUse);

	m_edtIdleShotX.EnableWindow(bUse);
	m_edtIdleShotY.EnableWindow(bUse);
	m_edtIdleShotZ2.EnableWindow(bUse);
	m_edtIdleShotZ1.EnableWindow(bUse);
	m_cmbTool.EnableWindow(bUse);

	m_listPosition.EnableWindow(bUse);

	m_edtSCalMinX.EnableWindow(bUse);
	m_edtSCalMinY.EnableWindow(bUse);
	m_edtSCalMaxX.EnableWindow(bUse);
	m_edtSCalMaxY.EnableWindow(bUse);
	
}

void CPaneProcessSetupProcessLarge::EnableBtnControl(BOOL bLevel)
{
	CRect rect;
	GetDlgItem(IDC_BUTTON_LDALIGN_POS)->EnableWindow(bLevel);
	GetDlgItem(IDC_BUTTON_LDCART_POS)->EnableWindow(bLevel);
	GetDlgItem(IDC_BUTTON_LDLOAD_POS)->EnableWindow(bLevel);
	GetDlgItem(IDC_BUTTON_UDALIGN_POS)->EnableWindow(bLevel);
	GetDlgItem(IDC_BUTTON_UDCART_POS)->EnableWindow(bLevel);
	GetDlgItem(IDC_BUTTON_UDUNLOAD_POS)->EnableWindow(bLevel);
	GetDlgItem(IDC_BUTTON_LOAD_POS)->EnableWindow(bLevel);
	GetDlgItem(IDC_BUTTON_LOAD_POS2)->EnableWindow(bLevel);
	GetDlgItem(IDC_BUTTON_UNLOAD_POS)->EnableWindow(bLevel);
	GetDlgItem(IDC_BUTTON_UNLOAD_POS2)->EnableWindow(bLevel);
	
/*	m_stcLoadPosition.GetWindowRect(rect);
	if(bLevel == TRUE && rect.right < 1045)
	{
		m_stcLoadPosition.SetWindowPos(NULL, rect.left, rect.top, rect.right-rect.left+80, rect.bottom-rect.top, SWP_NOMOVE);
		m_stcLoadPosition2.GetWindowRect(rect);
		m_stcLoadPosition2.SetWindowPos(NULL, rect.left, rect.top, rect.right-rect.left+80, rect.bottom-rect.top, SWP_NOMOVE);
		m_stcUnloadPosition.GetWindowRect(rect);
		m_stcUnloadPosition.SetWindowPos(NULL, rect.left, rect.top, rect.right-rect.left+80, rect.bottom-rect.top, SWP_NOMOVE);
		m_stcLoaderCarrierPosition.GetWindowRect(rect);
		m_stcLoaderCarrierPosition.SetWindowPos(NULL, rect.left, rect.top, rect.right-rect.left+80, rect.bottom-rect.top, SWP_NOMOVE);
		m_stcUnloadetCarrierPosition.GetWindowRect(rect);
		m_stcUnloadetCarrierPosition.SetWindowPos(NULL, rect.left, rect.top, rect.right-rect.left+80, rect.bottom-rect.top, SWP_NOMOVE);
	}
	else if(bLevel == FALSE && rect.right > 965)
	{
		m_stcLoadPosition.GetWindowRect(rect);
		m_stcLoadPosition.SetWindowPos(NULL, rect.left, rect.top, rect.right-rect.left-80, rect.bottom-rect.top, SWP_NOMOVE);
		m_stcLoadPosition2.GetWindowRect(rect);
		m_stcLoadPosition2.SetWindowPos(NULL, rect.left, rect.top, rect.right-rect.left-80, rect.bottom-rect.top, SWP_NOMOVE);
		m_stcUnloadPosition.GetWindowRect(rect);
		m_stcUnloadPosition.SetWindowPos(NULL, rect.left, rect.top, rect.right-rect.left-80, rect.bottom-rect.top, SWP_NOMOVE);
		m_stcLoaderCarrierPosition.GetWindowRect(rect);
		m_stcLoaderCarrierPosition.SetWindowPos(NULL, rect.left, rect.top, rect.right-rect.left-80, rect.bottom-rect.top, SWP_NOMOVE);
		m_stcUnloadetCarrierPosition.GetWindowRect(rect);
		m_stcUnloadetCarrierPosition.SetWindowPos(NULL, rect.left, rect.top, rect.right-rect.left-80, rect.bottom-rect.top, SWP_NOMOVE);
	}
*/
}

void CPaneProcessSetupProcessLarge::SetAuthorityByLevel(int nLevel)
{

#ifdef __KUNSAN_SAMSUNG_LARGE__
	switch(nLevel)
	{
	case 0:
		//EnableControl(FALSE);
		//EnableBtnControl(FALSE);
		//break;
	case 1:
		EnableControl(FALSE);
		EnableBtnControl(FALSE);
#ifndef __NANYA__
		m_edtLoadX.EnableWindow(TRUE);
		m_edtLoadY.EnableWindow(TRUE);
		m_edtLoadX2.EnableWindow(TRUE);
		m_edtLoadY2.EnableWindow(TRUE);
#endif
		break;
	case 2:
	case 3:
		EnableControl(TRUE);
		EnableBtnControl(TRUE);
		break;
	}	
#else
	switch(nLevel)
	{
	case 0:
		EnableControl(FALSE);
		EnableBtnControl(FALSE);
		m_edtLoadX.EnableWindow(TRUE);
		m_edtLoadY.EnableWindow(TRUE);
		m_edtLoadX2.EnableWindow(TRUE);
		m_edtLoadY2.EnableWindow(TRUE);
		break;
	case 1:
	case 2:
	case 3:
		EnableControl(TRUE);
		EnableBtnControl(TRUE);
		break;
	}	
#endif
}

void CPaneProcessSetupProcessLarge::OnButtonSuctionAdd()
{
	double dTempVal;
	CString str;
	
	POSITIONDATA posData;

	int nCount = 0;
	POSITION pos = m_pRefuse->m_RefuseData.GetHeadPosition();
	while(pos)
	{
		m_pRefuse->m_RefuseData.GetNext(pos);
		nCount++;
	}

	memset(&posData, 0, sizeof(posData));

	posData.nNo = nCount+1;
	str.Format(_T("%d"),posData.nNo);
	m_edtSuctionNo.SetWindowText(str);
	
	m_edtSuctionTableX.GetWindowText(str);
	dTempVal = atof(str);
	posData.dPosX = dTempVal;

	m_edtSuctionTableY.GetWindowText(str);
	dTempVal = atof(str);
	posData.dPosY = dTempVal;

	m_pRefuse->m_RefuseData.AddTail(posData);

	m_listPosition.SetItemState(nCount, LVIS_SELECTED, LVIS_SELECTED);
	m_listPosition.SetFocus();
	m_listPosition.EnsureVisible(nCount, TRUE );
	m_listPosition.SetSelectionMark(nCount);

	UpdateList();
}

void CPaneProcessSetupProcessLarge::OnButtonSuctionDelete()
{
	int sel = m_listPosition.GetSelectionMark();
	if(-1 == sel)
	{
		ErrMessage(_T("Please Select List first."));
		return;
	}
		
	int i = 0;
	POSITION pos = m_pRefuse->m_RefuseData.GetHeadPosition();
	while(pos)
	{
		if(i == sel) break;
		
		m_pRefuse->m_RefuseData.GetNext(pos);
		i++;
	}
	
	m_pRefuse->m_RefuseData.RemoveAt(pos);
	
	POSITIONDATA posData;
	
	pos = m_pRefuse->m_RefuseData.GetHeadPosition();
	while(pos)
	{
		posData = m_pRefuse->m_RefuseData.GetAt(pos);
		if(posData.nNo > sel + 1)
		{
			posData.nNo--;
			m_pRefuse->m_RefuseData.SetAt(pos, posData);
		}
		m_pRefuse->m_RefuseData.GetNext(pos);
	}
	UpdateList();
}

void CPaneProcessSetupProcessLarge::OnButtonSuctionUpdate()
{
	int sel = m_listPosition.GetSelectionMark();
	if(-1 == sel) 
	{
		ErrMessage(_T("Please Select List first."));
		return;
	}
	
	ChangeData(sel);
	UpdateList();
	
	m_listPosition.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
	m_listPosition.SetFocus();
	m_listPosition.EnsureVisible(sel, TRUE );
	m_listPosition.SetSelectionMark(sel);
}

void CPaneProcessSetupProcessLarge::OnClickListRefuse(NMHDR* pNMHDR, LRESULT* pResult) 
{
	int sel = m_listPosition.GetSelectionMark();
	if(-1 == sel) 
	{
		ErrMessage(_T("Please Select List first."));
		return;
	}
	
	ChangeDisplay(sel);
	
	m_listPosition.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
	m_listPosition.SetFocus();
	m_listPosition.EnsureVisible(sel, TRUE );
	m_listPosition.SetSelectionMark(sel);
	
	*pResult = 0;
}

void CPaneProcessSetupProcessLarge::ChangeDisplay(int nIndex)
{
	CString str;
	POSITIONDATA posData;

	if(nIndex == -1)
		return;

	int i= -1;
	POSITION pos = m_pRefuse->m_RefuseData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == nIndex) break;
		m_pRefuse->m_RefuseData.GetNext(pos);
	}

	if(i==-1)
		return;
	
	posData = m_pRefuse->m_RefuseData.GetAt(pos);

	str.Format(_T("%d"), posData.nNo);
	m_edtSuctionNo.SetWindowText(str);

	str.Format(_T("%.3f"), posData.dPosX);
	m_edtSuctionTableX.SetWindowText(str);

	str.Format(_T("%.3f"), posData.dPosY);
	m_edtSuctionTableY.SetWindowText(str);

	UpdateData(FALSE);
}

void CPaneProcessSetupProcessLarge::AddItems()
{
	LV_ITEM lvItem;
	CString strText;
	
	lvItem.mask = LVIF_TEXT|LVIF_PARAM;
	lvItem.iItem = m_listPosition.GetItemCount();
	lvItem.lParam = 1;
	lvItem.state = 0;
	lvItem.stateMask = LVIS_SELECTED;

	m_listPosition.DeleteAllItems();
	
	POSITIONDATA posData;

	int nIndex = 0;
	POSITION pos = m_pRefuse->m_RefuseData.GetHeadPosition();
	while(pos)
	{
		posData = m_pRefuse->m_RefuseData.GetAt(pos);

		lvItem.iSubItem = 0;
		strText.Format(_T("%d"), nIndex);
		lvItem.pszText = (LPSTR)(LPCSTR)strText;
		m_listPosition.InsertItem(&lvItem);

		strText.Format(_T("%d"), nIndex+1);
		m_listPosition.SetItemText(nIndex, 0, (LPSTR)(LPCSTR)strText);
	
		strText.Format(_T("%.3f"), posData.dPosX);
		m_listPosition.SetItemText(nIndex, 1, (LPSTR)(LPCSTR)strText);
		
		strText.Format(_T("%.3f"), posData.dPosY);
		m_listPosition.SetItemText(nIndex++, 2, (LPSTR)(LPCSTR)strText);

		m_pRefuse->m_RefuseData.GetNext(pos);
	}
}

void CPaneProcessSetupProcessLarge::ChangeData(int nIndex)
{
	int nTempVal;
	double dTempVal;
	CString str, strMessage, strInfo, strTemp;

	POSITIONDATA posData;

	int i= -1;
	POSITION pos = m_pRefuse->m_RefuseData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == nIndex) break;
		m_pRefuse->m_RefuseData.GetNext(pos);
	}
	
	if(i==-1)
		return;
	
	posData = m_pRefuse->m_RefuseData.GetAt(pos);
	
	m_edtSuctionNo.GetWindowText(str);
	nTempVal = atoi(str);
	posData.nNo = nTempVal;
		
	m_edtSuctionTableX.GetWindowText(str);
	dTempVal = atof(str);
	posData.dPosX = dTempVal;

	m_edtSuctionTableY.GetWindowText(str);
	dTempVal = atof(str);
	posData.dPosY = dTempVal;

	m_pRefuse->m_RefuseData.SetAt(pos, posData);

	UpdateList();
}

void CPaneProcessSetupProcessLarge::UpdateList()
{
	POSITIONDATA posData;
	
	CString strText;
	LVITEM lvItem;
	lvItem.iSubItem = 0;
	
	m_listPosition.DeleteAllItems();
	
	lvItem.mask = LVIF_TEXT|LVIF_PARAM;
	lvItem.lParam = 1;
	lvItem.state = 0;
	lvItem.stateMask = LVIS_SELECTED;
	
	int nIndex = 0;
	POSITION pos = m_pRefuse->m_RefuseData.GetHeadPosition();
	while(pos)
	{
		posData = m_pRefuse->m_RefuseData.GetNext(pos);
		
		//List No
		lvItem.iItem = m_listPosition.GetItemCount();
		lvItem.iSubItem = 0;
		strText.Format(_T("%d"), posData.nNo);
		lvItem.pszText = (LPSTR)(LPCSTR)strText;
		m_listPosition.InsertItem(&lvItem);		
		
		strText.Format(_T("%d"), nIndex+1);
		m_listPosition.SetItemText(nIndex, 0, (LPSTR)(LPCSTR)strText);
		
		strText.Format(_T("%.3f"), posData.dPosX);
		m_listPosition.SetItemText(nIndex, 1, (LPSTR)(LPCSTR)strText);
		
		strText.Format(_T("%.3f"), posData.dPosY);
		m_listPosition.SetItemText(nIndex++, 2, (LPSTR)(LPCSTR)strText);
	}
}

void CPaneProcessSetupProcessLarge::OnBnClickedButtonUdcartPos()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Unloader Carrier Cart Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_UL_CARRIER, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtUCCart.SetWindowText( (LPCTSTR)strData );
	}
}


void CPaneProcessSetupProcessLarge::OnBnClickedButtonUdunloadPos()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Unloader Carrier Load Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_UL_CARRIER, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtUCUnload.SetWindowText( (LPCTSTR)strData );
	}
}

void CPaneProcessSetupProcessLarge::OnBnClickedButtonUdalignPos()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Unloader Carrier Align Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_UL_CARRIER, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtUCAlign.SetWindowText( (LPCTSTR)strData );
	}
}


void CPaneProcessSetupProcessLarge::OnBnClickedButtonLdcartPos()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Loader Carrier Cart Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_L_CARRIER, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtLCCart.SetWindowText( (LPCTSTR)strData );
	}
}


void CPaneProcessSetupProcessLarge::OnBnClickedButtonLdloadPos()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Loader Carrier Load Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_L_CARRIER, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtLCLoad.SetWindowText( (LPCTSTR)strData );
	}
}


void CPaneProcessSetupProcessLarge::OnBnClickedButtonLdalignPos()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Loader Carrier Align Position"), MB_YESNO))
	{
		pMotor->GetRawPosition( AXIS_L_CARRIER, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtLCAlign.SetWindowText( (LPCTSTR)strData );
	}
}


void CPaneProcessSetupProcessLarge::OnBnClickedButtonLoadPos()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Load Position X, Y"), MB_YESNO))
	{	
		//X
		pMotor->GetRawPosition( AXIS_X, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtLoadX.SetWindowText( (LPCTSTR)strData );

		pMotor->GetRawPosition( AXIS_Y, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtLoadY.SetWindowText( (LPCTSTR)strData );
	}
}


void CPaneProcessSetupProcessLarge::OnBnClickedButtonUnloadPos()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Unload Position X, Y"), MB_YESNO))
	{	
		//X
		pMotor->GetRawPosition( AXIS_X, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtUnloadX.SetWindowText( (LPCTSTR)strData );

		pMotor->GetRawPosition( AXIS_Y, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtUnloadY.SetWindowText( (LPCTSTR)strData );
	}
}
void CPaneProcessSetupProcessLarge::OnBnClickedButtonUnloadPos2()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Unload Position X, Y"), MB_YESNO))
	{	
		//X
		pMotor->GetRawPosition( AXIS_X, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtUnloadX2.SetWindowText( (LPCTSTR)strData );

		pMotor->GetRawPosition( AXIS_Y, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtUnloadY2.SetWindowText( (LPCTSTR)strData );
	}
}

void CPaneProcessSetupProcessLarge::OnBnClickedButtonLoadPos2()
{
	// TODO: Add your control notification handler code here
	CString strData;
	#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
	#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
	#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("Load Position2 X, Y"),MB_YESNO))
	{	
		//X
		pMotor->GetPosition(AXIS_X, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtLoadX2.SetWindowText( (LPCTSTR)strData );

		pMotor->GetPosition( AXIS_Y, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtLoadY2.SetWindowText( (LPCTSTR)strData );
	}
}                                  

BOOL CPaneProcessSetupProcessLarge::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Process_Position) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}



void CPaneProcessSetupProcessLarge::OnBnClickedButtonTcCleanPos()
{
	CString strData;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	double dPos=0;


	if(IDYES == ErrMessage(_T("T/C Lens Cleaning Position X, Y, Z1, Z2"), MB_YESNO))
	{	
		pMotor->GetRawPosition( AXIS_X, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtTCCleanX.SetWindowText( (LPCTSTR)strData );

		pMotor->GetRawPosition( AXIS_Y, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtTCCleanY.SetWindowText( (LPCTSTR)strData );

		pMotor->GetRawPosition( AXIS_Z1, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtTCCleanZ1.SetWindowText( (LPCTSTR)strData );

		pMotor->GetRawPosition( AXIS_Z2, dPos );
		strData.Format(_T("%.3f"), dPos);
		m_edtTCCleanZ2.SetWindowText( (LPCTSTR)strData );
	}
}

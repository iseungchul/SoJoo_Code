#if !defined(AFX_PANESYSSETUPBEAMDUMPERPUSAN1_H__77E3488A_EF2F_4B06_A6B5_B756B08E9918__INCLUDED_)
#define AFX_PANESYSSETUPBEAMDUMPERPUSAN1_H__77E3488A_EF2F_4B06_A6B5_B756B08E9918__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupBeamDumperPusan1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupBeamDumperPusan1 form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButton.h"
#include "ColorEdit.h"

class CPaneSysSetupBeamDumperPusan1 : public CFormView
{
protected:
	CPaneSysSetupBeamDumperPusan1();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupBeamDumperPusan1)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupBeamDumperPusan1)
	enum { IDD = IDD_DLG_SYS_SETUP_BEAM_DUMPER_PUSAN1 };
	UEasyButton	m_btn2ndPanelMove;
	UEasyButton	m_btn1stPanelMove;
	CColorEdit	m_edt2ndPanelPosY;
	CColorEdit	m_edt2ndPanelPosX;
	CColorEdit	m_edt1stPanelPosY;
	CColorEdit	m_edt1stPanelPosX;
	CColorEdit	m_edtDummyShotNo;
	CColorEdit	m_edtDummyInterval;
	CColorEdit	m_edtDummyFreq;
	CColorEdit	m_edtDummyDuty;
	CColorEdit	m_edtDummyAOMDelay;
	CColorEdit	m_edtDummyAOMDuty;
	CColorEdit	m_edtStandbyTime;
	CColorEdit	m_edtStandbyMinFreq;
	CColorEdit	m_edtStandbyMaxFreq;
	CColorEdit	m_edtStandbyInterval;
	CColorEdit	m_edtStandbyDuty;
	CColorEdit	m_edtStandbyInpositionTime;
	CColorEdit	m_edtStandby1stV;
	CColorEdit	m_edtStandby2ndV;
	CColorEdit	m_edtTurnOffTime;
	CColorEdit	m_edtStandbyTime_2;
	CColorEdit	m_edtStandbyTime_Scal;
	CColorEdit	m_edtStandbyMinFreq_2;
	CColorEdit	m_edtStandbyMaxFreq_2;
	CColorEdit	m_edtStandbyInterval_2;
	CColorEdit	m_edtStandbyDuty_2;
	CColorEdit	m_edtStandbyInpositionTime_2;
	CColorEdit	m_edtStandby1stV_2;
	CColorEdit	m_edtStandby2ndV_2;
	CColorEdit	m_edtTurnOffTime_2;
	//}}AFX_DATA

// Attributes
public:
	int			m_nUseDummy;
// Attributes
protected :
	CFont		m_fntStatic;
	CFont		m_fntBtn;
	CFont		m_fntEdit;

// Operations
public:
	void GetSystemDevice(SSYSTEMDUMP* pSystemDump);
	CString GetChangeValueStr();
	void SetSystemDevice(SSYSTEMDUMP sSystemDump);
	SSYSTEMDUMP			m_sSystemDump;
	void			OnApply();
	void			SetBeamDumperData();
	void		InitBtnControl();
	void		InitEditControl();
	void		InitStaticControl();
	void OnRadioNoUse();
	void OnRadioDumperShot();
	void OnRadioDummyFree();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupBeamDumperPusan1)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupBeamDumperPusan1();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupBeamDumperPusan1)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnButton1stPanelPosMove();
	afx_msg void OnButton2ndPanelPosMove();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPBEAMDUMPERPUSAN1_H__77E3488A_EF2F_4B06_A6B5_B756B08E9918__INCLUDED_)

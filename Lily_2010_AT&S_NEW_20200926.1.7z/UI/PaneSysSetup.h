#if !defined(AFX_PANESYSSETUP_H__4EFA86A1_5F35_43F6_A7B4_132C5CD799F8__INCLUDED_)
#define AFX_PANESYSSETUP_H__4EFA86A1_5F35_43F6_A7B4_132C5CD799F8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetup.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetup form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "USimpleTab.h"

class CPaneSysSetupDir;
class CPaneSysSetupLaserScannerPusan1;
class CPaneSysSetupMotorPusan1;
class CPaneSysSetupBeamDumperPusan1;

class CPaneSysSetupTableCal;
class CPaneSysSetupCollimator;

class CPaneSysSetupZCal;
class CPaneSysSetupMGC;
class CPaneSysSetupMGC2;
class CPaneSysSetupThetaCal;
class CPaneSysSetupTophat;
class CPaneSysSetupComponentTime;	//201161
class CPaneSysSetupVacuum;

class CPaneSysSetup : public CFormView
{
protected:
	CPaneSysSetup();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetup)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetup)
	enum { IDD = IDD_DLG_SYS_SETUP };
	USimpleTab	m_tabSysSetup;
	//}}AFX_DATA

// Attributes
public:
	CPaneSysSetupDir*			m_pDir;
	CPaneSysSetupTableCal*		m_pTableCal;
	CPaneSysSetupCollimator*	m_pCollimator;
	CPaneSysSetupZCal*			m_pZCal;
	CPaneSysSetupMGC*			m_pMGC;
	CPaneSysSetupMGC2*			m_pMGC2;
	CPaneSysSetupThetaCal*		m_pThetaCal;
	CPaneSysSetupTophat*		m_pTophat;
	CPaneSysSetupComponentTime*	m_pComponent;	//201161
	CPaneSysSetupVacuum*		m_pVacuum;

	CPaneSysSetupMotorPusan1*		m_pMotor;

	CPaneSysSetupLaserScannerPusan1*	m_pLaserScanner;
	CPaneSysSetupBeamDumperPusan1*	m_pBeamDumper;


// Operations
public:
	void UpdateIniUI(int nVal);
	void CheckComponentPreAcq();
	int m_nBeamDumperNo;
	void ChangeTab();
	void InitTabControl();
	void OnApply();
	int GetTabCurSel();	

	void EnableTab(BOOL bEnable);

	void SetAuthorityByLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetup)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetup();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntTab;
	int			m_nSel;

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetup)
	afx_msg void OnDestroy();
	afx_msg void OnClickTabSysSetup(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUP_H__4EFA86A1_5F35_43F6_A7B4_132C5CD799F8__INCLUDED_)

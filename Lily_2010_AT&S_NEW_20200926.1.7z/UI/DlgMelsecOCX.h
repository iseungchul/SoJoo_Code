#pragma once

#include "actqj71e71tcp3.h"
#include "actsupport1.h"
#include "actqnudecputcp1.h"


// CDlgMelsecOCX dialog

class CDlgMelsecOCX : public CDialog
{
	DECLARE_DYNAMIC(CDlgMelsecOCX)

public:
	CDlgMelsecOCX(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgMelsecOCX();

// Dialog Data
	enum { IDD = IDD_DLG_MELSEC_OCX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

public:
	CActQJ71E71TCP3			m_MelsecQ;
	CActsupport1			m_ctrlMelsecSupport;

public:
	virtual BOOL			DestroyWindow();
	long					GetErrorFromMelsecQ(long lErrorCode);
	virtual BOOL Create(CWnd* pParentWnd);
	CActqnudecputcp1 m_MelsecQCPU;
};
#if !defined(AFX_PANEAUTORUNVIEWPREWORKSCANNER_H__E6E5FC5B_EC31_4C91_A20B_AC4F70F40203__INCLUDED_)
#define AFX_PANEAUTORUNVIEWPREWORKSCANNER_H__E6E5FC5B_EC31_4C91_A20B_AC4F70F40203__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneAutoRunViewPreworkScanner.h : header file
//
#define RESULT_MAX_NO		50
/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPreworkScanner form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CPaneAutoRunViewPreworkScanner : public CFormView
{
protected:
	CPaneAutoRunViewPreworkScanner();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneAutoRunViewPreworkScanner)

// Form Data
public:
	//{{AFX_DATA(CPaneAutoRunViewPreworkScanner)
	enum { IDD = IDD_DLG_AUTORUN_VIEW_PREWORK_SCANNER_CAL };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	CFont m_fntStatic;
	CFont m_fntList;
	CListCtrl m_listScannerTool;
	CListCtrl m_listScannerResult;
	double m_dResult[50][4]; //beampath , master + slave

	double m_dResultList[RESULT_MAX_NO][4];
	int		m_nScalToolNo[RESULT_MAX_NO];
	int		m_nResultCount;
// Operations
public:
	void SCalResultAdd();
	void InsertScalResult(double* pResult, int nTool);
	void ResetList();
	void ChangeDisplay(int nIndex = 1);
	void InitListControl();
	void InitStatic();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneAutoRunViewPreworkScanner)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneAutoRunViewPreworkScanner();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneAutoRunViewPreworkScanner)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnClickListPowerTool(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEAUTORUNVIEWPREWORKSCANNER_H__E6E5FC5B_EC31_4C91_A20B_AC4F70F40203__INCLUDED_)

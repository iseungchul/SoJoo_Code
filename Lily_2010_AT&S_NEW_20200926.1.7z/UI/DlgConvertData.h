#pragma once
#include "..\MODEL\DProject.h"
#include "afxwin.h"
#include "UEasyButtonEx.h"
#include "ColorStatic.h"

// CDlgConvertData dialog

#define MAX_CONV_TOOL 20

class CDlgConvertData : public CDialog
{
	DECLARE_DYNAMIC(CDlgConvertData)

	

public:
	CDlgConvertData(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgConvertData();

// Dialog Data
	enum { IDD = IDD_DLG_CONVERT_DATA };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnBnClickedButtonSave();
	afx_msg void OnBnClickedOk();

	virtual BOOL OnInitDialog();

public:
	void InitStaticControl();
	void InitBtnControl();
	void InitComboControl();
	void SetFilePath(CString strFilePath);
	void GetFilePath(CString &strFilePath);
	void CountHoleNumber();
	void ShowHoleCount(int nToolNo, int nHoleCount);
	void ReadCode(TCHAR *szBuffer);
	void SaveTCode();
	void SaveFiducialData();
	void SaveData();
	void SaveConvData(char *szBuf, BOOL bFidData = FALSE, int nFidType = FALSE);
	void SaveToolConfig();
	void SaveOriginalFiducial();
	void LoadToolConfig();
	
	CComboBox m_cmbTool[MAX_CONV_TOOL];
	CColorStatic m_stcTool[MAX_CONV_TOOL];
	CColorStatic m_stcFiducial;
	UEasyButtonEx m_chkTool[MAX_CONV_TOOL];
	UEasyButtonEx m_chkFiducial;
	UEasyButtonEx m_btnSaveToFile;
	UEasyButtonEx m_btnLoad;
	UEasyButtonEx m_btnClose;
	
	CFont m_fntStatic;
	CFont m_fntBtn;
	CFont m_fntCombo;

	CList<CPoint, CPoint> m_ToolData;
	CString m_strFilePath;
	CString m_strNewFilePath;
	BOOL m_bIsStartHeader;
	BOOL m_bIsHeader;
	int m_nCurToolCode;	
	int m_nPatternFlag;
	int m_nPatternCount;
	int m_nFiducialCount;
	enum PATTERN {emPatternBegin, emPatternEnd, emPatternRepeat, emPatternFiducial};
};

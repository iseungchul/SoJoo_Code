#if !defined(AFX_PANEMANUALCONTROL_H__6F420A72_BDF9_4F80_B9BB_E3AC25C7162C__INCLUDED_)
#define AFX_PANEMANUALCONTROL_H__6F420A72_BDF9_4F80_B9BB_E3AC25C7162C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControl form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "USimpleTab.h"

class	CPaneManualControlDevice;
class	CPaneManualControlLaser;
class   CPaneManualControlLaserUV;
class	CPaneManualControlPowerMeasurement;
class	CPaneManualControlScannerCalibration;
class	CPaneManualControlVision;

	class	CPaneManualControlOneHoleLarge;

class	CPaneManualControlIO;
//class	CPaneManualControlScannerCalibrationPos;
//class	CPaneManualControlParameter;
class	CPaneRecipeGenParameterNew;



 	class	CPaneManualControlMotorPusan1;

class CPaneManualControl : public CFormView
{
protected:
	CPaneManualControl();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControl)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControl)
	enum { IDD = IDD_DLG_MANUAL_CONTROL };
	USimpleTab	m_tabManualControl;
	//}}AFX_DATA

// Attributes
public:
	

	

	CPaneManualControlMotorPusan1*	m_pMotor;




	CPaneManualControlDevice*		m_pDevice;
	CPaneManualControlLaser*		m_pLaser;
	CPaneManualControlLaserUV*		m_pLaserUV;
	CPaneManualControlScannerCalibration* m_pScannerCalibration;
	CPaneManualControlVision*		m_pVision;

	CPaneManualControlOneHoleLarge*	m_pOneHole;

	CPaneManualControlPowerMeasurement*		m_pPowerMeasurement;
	CPaneManualControlIO*			m_pIO;
//	CPaneManualControlScannerCalibrationPos* m_pScannerCalibrationPos;
//	CPaneManualControlParameter*	m_pParameter;
	CPaneRecipeGenParameterNew*		m_pParameter;

// Operations
public:
	void EnableTab(BOOL bEnable);
	CPaneManualControlVision* GetVisionTab();
	void InitTabControl();
	void ShowTabPane(int nPaneNo, BOOL bSetFid = FALSE);
	int	GetShowPane() {return m_nPaneNo;};
	int	GetTabCurSel();
	BOOL GetLaserPower();
	void SetData(int nPane);

	void SetAuthorityByLevel(int nLevel);
	void ReDrawData_WhenTableChange();
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControl)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControl();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntTab;
	
	int			m_nPaneNo;

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControl)
	afx_msg void OnClickTabManualControl(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROL_H__6F420A72_BDF9_4F80_B9BB_E3AC25C7162C__INCLUDED_)

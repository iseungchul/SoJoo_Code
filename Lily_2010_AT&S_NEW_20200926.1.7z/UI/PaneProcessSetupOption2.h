#if !defined(AFX_PANEPROCESSSETUPOPTION2_H__E1D8104A_CC0D_455E_ABFD_1F98FA7A20E3__INCLUDED_)
#define AFX_PANEPROCESSSETUPOPTION2_H__E1D8104A_CC0D_455E_ABFD_1F98FA7A20E3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneProcessSetupOption2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupOption2 form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

class CPaneProcessSetupOption2 : public CFormView
{
protected:
	CPaneProcessSetupOption2();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneProcessSetupOption2)

// Form Data
public:
	//{{AFX_DATA(CPaneProcessSetupOption2)
	enum { IDD = IDD_DLG_PROCESS_SETUP_OPTION2 };
	UEasyButtonEx	m_chkCheckSuctionError;
	UEasyButtonEx	m_chkRejectSuctionOff;
	CColorEdit	m_edt2ndPCBHeightMin;
	CColorEdit	m_edt2ndPCBHeightMax;
	CColorEdit	m_edt1stPCBHeightMin;
	CColorEdit	m_edt1stPCBHeightMax;
	CColorEdit	m_edtAlignTime;
	CColorEdit	m_edtLoadTime;
	CColorEdit	m_edtUnloadTime;
	CColorEdit	m_edtAlignSingleTime;
	CColorEdit	m_edtAlignDualTime;
	CColorEdit	m_edtAlignSingleTimeOnlyPCB;
	CColorEdit	m_edtAlignDualTimeOnlyPCB;
	CColorEdit	m_edtAlignStartTime;

	CColorEdit	m_edtCCLSize;
	CColorEdit	m_edtPPGSize;
	CColorEdit	m_edtVerifySize;
CColorEdit	m_edtVacuumMotorOffTime;
	UEasyButtonEx m_btnResetTotalShots;
	CColorEdit	m_edtPCBHeihtAutoTol;

	//}}AFX_DATA

// Attributes
protected :
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	CFont			m_fntBtn;
	
	SPROCESSOPTION	m_sProcessOption;
	BOOL			m_bCheckSuctionError;
	BOOL			m_bRejectSuctionOff;

// Operations
public:
	CString GetChangeValueStr();
	void InitStaticControl();
	void InitEditControl();
	void InitBtnControl();
	
	void SetProcessOption(SPROCESSOPTION sProcessOption);
	void GetProcessOption(SPROCESSOPTION* pProcessOption);
	void DispProcessOption();
	void OnApply();
	void MakeReadableNumber(CString& strVal);
	
	void EnableControl(BOOL bUse);
	void SetAuthorityByLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneProcessSetupOption2)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneProcessSetupOption2();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneProcessSetupOption2)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	afx_msg void OnButtonResetTotalShots();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEPROCESSSETUPOPTION2_H__E1D8104A_CC0D_455E_ABFD_1F98FA7A20E3__INCLUDED_)

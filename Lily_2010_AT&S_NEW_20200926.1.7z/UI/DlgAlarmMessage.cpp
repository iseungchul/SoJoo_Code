// DlgAlarmMessage.cpp : implementation file
//

#include "stdafx.h"
#include "..\EasyDriller.h"
#include "DlgAlarmMessage.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// CDlgAlarmMessage dialog

IMPLEMENT_DYNAMIC(CDlgAlarmMessage, CDialog)

CDlgAlarmMessage::CDlgAlarmMessage(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgAlarmMessage::IDD, pParent)
{
	m_strErrMessage = _T("");
	m_nRrefreshTimer = 0;
	m_bEasyDrillerDlgStart = FALSE;
}

CDlgAlarmMessage::~CDlgAlarmMessage()
{
}

void CDlgAlarmMessage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_EDIT_ERROR_MESSAGE, m_strErrMessage);
	DDX_Control(pDX, IDC_EDIT_ERROR_MESSAGE, editctrl);
	

//	DDX_Control(pDX, IDC_STATIC_ICON, m_stcIcon);
//	DDX_Control(pDX, IDC_EDIT_ERROR_MESSAGE, m_edtErrMessage);
	DDX_Control(pDX, IDOK, m_btnOk);
	DDX_Control(pDX, IDYES, m_btnYes);
	DDX_Control(pDX, IDNO, m_btnNo);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
}


BEGIN_MESSAGE_MAP(CDlgAlarmMessage, CDialog)
	ON_BN_CLICKED(IDYES, &CDlgAlarmMessage::OnButtonYes)
	ON_BN_CLICKED(IDNO, &CDlgAlarmMessage::OnButtonNo)
	ON_BN_CLICKED(IDCANCEL, &CDlgAlarmMessage::OnButtonCancel)
	ON_BN_CLICKED(IDOK, &CDlgAlarmMessage::OnButtonOk)
	ON_WM_MOUSEWHEEL()
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CDlgAlarmMessage message handlers



BOOL CDlgAlarmMessage::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here
	InitBtnControl();
	InitEditControl();
	InitStaticControl();
	this->GetSystemMenu(NULL)->EnableMenuItem(SC_CLOSE, MF_DISABLED);
	::SetWindowPos(this->m_hWnd, HWND_TOPMOST, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOREDRAW);

	ResizeWindow();

	
	int len;

	len = editctrl.GetWindowTextLength();
	editctrl.SetSel(len/2, 1);



	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgAlarmMessage::InitBtnControl()
{
	// Set Button Font
	CRect rect;
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnOk.SetFont( &m_fntBtn );
	m_btnOk.SetFlat( FALSE );
//	m_btnOk.SetImageOrg( 8, 3 );
//	m_btnOk.SetIcon( IDI_OK );
	m_btnOk.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOk.EnableBallonToolTip();
	m_btnOk.SetToolTipText( _T("OK") );
	m_btnOk.SetBtnCursor(IDC_HAND_1);

	m_btnYes.SetFont( &m_fntBtn );
	m_btnYes.SetFlat( FALSE );
//	m_btnYes.SetImageOrg( 8, 3 );
//	m_btnYes.SetIcon( IDI_OK );
	m_btnYes.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnYes.EnableBallonToolTip();
	m_btnYes.SetToolTipText( _T("YES") );
	m_btnYes.SetBtnCursor(IDC_HAND_1);

	m_btnNo.SetFont( &m_fntBtn );
	m_btnNo.SetFlat( FALSE );
//	m_btnNo.SetImageOrg( 8, 3 );
//	m_btnNo.SetIcon(AfxGetApp()->LoadIcon(IDI_WARNING)  );
	m_btnNo.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnNo.EnableBallonToolTip();
	m_btnNo.SetToolTipText( _T("NO") );
	m_btnNo.SetBtnCursor(IDC_HAND_1);

	m_btnCancel.SetFont( &m_fntBtn );
	m_btnCancel.SetFlat( FALSE );
	//	m_btnCancel.SetImageOrg( 8, 3 );
//		m_btnCancel.SetIcon( IDI_WARNING );
	m_btnCancel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCancel.EnableBallonToolTip();
	m_btnCancel.SetToolTipText( _T("NO") );
	m_btnCancel.SetBtnCursor(IDC_HAND_1);

}

void CDlgAlarmMessage::InitEditControl()
{
	// Set Edit Font
	// Error Code
	m_edtFont.CreateFont(25, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDC_EDIT_ERROR_MESSAGE)->SetFont(&m_edtFont);
//	m_edtErrMessage.SetBackColor(RGB(255,250,205));//lemonchiffon color

}

void CDlgAlarmMessage::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	
//	m_stcIcon.Create(_T("zz"), WS_CHILD | WS_VISIBLE | SS_ICON | SS_CENTERIMAGE, CRect(0,0,50, 700), this, 0xffff);

//	CWinApp* pApp = AfxGetApp();

//	if(m_nType & MB_YESNO || m_nType & MB_ICONQUESTION || m_nType & MB_YESNOCANCEL)
//		m_stcIcon.SetIcon(AfxGetApp()->LoadIcon(IDI_QUESTION2));
//	else if (m_nType & MB_ICONSTOP || m_nType & MB_ICONERROR)
//		m_stcIcon.SetIcon(AfxGetApp()->LoadIcon(IDI_STOP2));
//	else
//		m_stcIcon.SetIcon(AfxGetApp()->LoadIcon(IDI_WARNING2));


}

void CDlgAlarmMessage::OnButtonYes()
{
	// TODO: Add your control notification handler code here
	m_nResult = IDYES;
	EndDialog(m_nResult);
}


void CDlgAlarmMessage::OnButtonNo()
{
	// TODO: Add your control notification handler code here
	m_nResult = IDNO;
	EndDialog(m_nResult);
}
void CDlgAlarmMessage::OnButtonCancel()
{
	// TODO: Add your control notification handler code here
	m_nResult = IDCANCEL;
	EndDialog(m_nResult);
}

int CDlgAlarmMessage::SetErrMsg(CString strErrMessage, UINT nType, BOOL bLog)
{
	CString strResult = _T("");
	CString strLog = _T("");
	m_strErrMessage.Format("%s", strErrMessage);
	strLog.Format(_T("(MSG_ON)%s"), m_strErrMessage);
	m_nType = nType;
	
	if( bLog && m_bEasyDrillerDlgStart)
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));

	m_strErrMessage.Replace(_T("\n"),_T("\r\n"));
	
	DoModal();
	if(m_nResult == IDOK)
		strResult.Format(_T("%s_OK"),strErrMessage);
	else if(m_nResult == IDNO)
		strResult.Format(_T("%s_NO"),strErrMessage);
	else if(m_nResult == IDYES)
		strResult.Format(_T("%s_YES"),strErrMessage);
	else
		strResult.Format(_T("%s_CANCEL"),strErrMessage);

	strResult.Replace(_T("\r\n"),_T(" "));
	
	strLog.Format("(MSG_OFF)%s", strResult);
	if( bLog && m_bEasyDrillerDlgStart )
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));
	
	return m_nResult;
}

BOOL CDlgAlarmMessage::DestroyWindow()
{
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	
	return CDialog::DestroyWindow();
}


void CDlgAlarmMessage::OnButtonOk()
{
	// TODO: Add your control notification handler code here
	m_nResult = IDOK;
	EndDialog(m_nResult);
}


BOOL CDlgAlarmMessage::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	// TODO: Add your message handler code here and/or call default
	return CDialog::OnMouseWheel(nFlags, zDelta, pt);
}


HBRUSH CDlgAlarmMessage::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	// TODO: Change any attributes of the DC here
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CDlgAlarmMessage::ResizeWindow()
{
	CRect rect, rectBtn,rectTest;
	this->GetWindowRect(&rect);
	
	char* pToken;
	CString strToken = _T("");
	int nMaxLength = -1;
	int nCount = 0;
	pToken = strtok((LPSTR)(LPCTSTR)m_strErrMessage, _T("\r\n"));
	while(pToken != NULL)
	{
		strToken = pToken;
		if(nMaxLength < strToken.GetLength())
			nMaxLength = strToken.GetLength();
		pToken = strtok(NULL, _T("\r\n"));
		nCount++;
	}

	::GetWindowRect(GetDesktopWindow()->m_hWnd, &rectTest);




	if(nCount*25 < rectTest.Height())

	{

		this->MoveWindow(rect.left, rect.top,15 * nMaxLength + 10, 150 + nCount*25);

		GetDlgItem(IDC_EDIT_ERROR_MESSAGE)->GetClientRect(&rectBtn);

		GetDlgItem(IDC_EDIT_ERROR_MESSAGE)->MoveWindow(rectBtn.left, rectBtn.top, 15 * nMaxLength, nCount*25);

	}

	else

	{

		this->MoveWindow(rect.left, rect.top,15 * nMaxLength + 10, rectTest.Height());

		GetDlgItem(IDC_EDIT_ERROR_MESSAGE)->GetClientRect(&rectBtn);

		GetDlgItem(IDC_EDIT_ERROR_MESSAGE)->MoveWindow(rectBtn.left, rectBtn.top, 15 * nMaxLength, rectTest.Height() - 150);

	}

	this->GetClientRect(&rect);
	if ((m_nType & MB_YESNO) == MB_YESNO)
	{
		m_btnOk.ShowWindow(SW_HIDE);
		m_btnYes.ShowWindow(SW_SHOW);
		m_btnNo.ShowWindow(SW_SHOW);
		m_btnCancel.ShowWindow(SW_HIDE);

		m_btnYes.GetClientRect(&rectBtn);
		m_btnYes.MoveWindow(rect.Width()/2 - rectBtn.Width(), rect.bottom - 80, rectBtn.Width(), rectBtn.Height(),TRUE);
		m_btnNo.GetClientRect(&rectBtn);
		m_btnNo.MoveWindow(rect.Width()/2, rect.bottom - 80, rectBtn.Width(), rectBtn.Height(),TRUE);
	}
	else if ((m_nType & MB_YESNOCANCEL) == MB_YESNOCANCEL)
	{
		m_btnOk.ShowWindow(SW_HIDE);
		m_btnYes.ShowWindow(SW_SHOW);
		m_btnNo.ShowWindow(SW_SHOW);
		m_btnCancel.ShowWindow(SW_SHOW);
		m_btnYes.GetClientRect(&rectBtn);
		m_btnYes.MoveWindow(rect.Width()/2 - rectBtn.Width()/2 - rectBtn.Width(), rect.bottom - 80, rectBtn.Width(), rectBtn.Height(),TRUE);
		m_btnNo.GetClientRect(&rectBtn);
		m_btnNo.MoveWindow(rect.Width()/2 - rectBtn.Width()/2, rect.bottom - 80, rectBtn.Width(), rectBtn.Height(),TRUE);
		m_btnCancel.GetClientRect(&rectBtn);
		m_btnCancel.MoveWindow(rect.Width()/2 - rectBtn.Width()/2 + rectBtn.Width(), rect.bottom - 80, rectBtn.Width(), rectBtn.Height(),TRUE);

	}
	else if(( m_nType & MB_OKCANCEL) == MB_OKCANCEL)
	{
		m_btnOk.ShowWindow(SW_SHOW);
		m_btnYes.ShowWindow(SW_HIDE);
		m_btnNo.ShowWindow(SW_HIDE);
		m_btnCancel.ShowWindow(SW_SHOW);
		m_btnOk.GetClientRect(&rectBtn);
		m_btnOk.MoveWindow(rect.Width()/2 - rectBtn.Width(), rect.bottom - 80, rectBtn.Width(), rectBtn.Height(),TRUE);
		m_btnCancel.GetClientRect(&rectBtn);
		m_btnCancel.MoveWindow(rect.Width()/2, rect.bottom - 80, rectBtn.Width(), rectBtn.Height(),TRUE);

	}
	else
	{
		m_btnOk.ShowWindow(SW_SHOW);
		m_btnYes.ShowWindow(SW_HIDE);
		m_btnNo.ShowWindow(SW_HIDE);
		m_btnCancel.ShowWindow(SW_HIDE);
		m_btnOk.GetClientRect(&rectBtn);
		m_btnOk.MoveWindow(rect.Width()/2 - rectBtn.Width()/2, rect.bottom - 80, rectBtn.Width(), rectBtn.Height(),TRUE);

	}
}

BOOL CDlgAlarmMessage::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN)
	{
		switch (pMsg->wParam)
		{
		case VK_ESCAPE:
			return TRUE;

		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}
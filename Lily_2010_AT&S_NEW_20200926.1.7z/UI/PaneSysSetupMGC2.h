#if !defined(AFX_PANESYSSETUPMGC2_H__8F6994BF_8665_4A1F_AD37_1C528FB95A37__INCLUDED_)
#define AFX_PANESYSSETUPMGC2_H__8F6994BF_8665_4A1F_AD37_1C528FB95A37__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupMGC2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupMGC2 form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
//#include "..\Device\FCalibration.h"

class CPaneSysSetupMGC2 : public CFormView
{
protected:
	CPaneSysSetupMGC2();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupMGC2)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupMGC2)
	enum { IDD = IDD_DLG_SYS_SETUP_MGC_2 };
		// NOTE: the ClassWizard will add data members here
	UEasyButtonEx	m_btnOpenASC;
	UEasyButtonEx	m_btnApply;
	UEasyButtonEx	m_btnSaveAs;
	CColorEdit m_edtX1;
	CColorEdit m_edtX2;
	CColorEdit m_edtX3;
	CColorEdit m_edtY1;
	CColorEdit m_edtY2;
	CColorEdit m_edtY3;
	CColorEdit m_edtScannerFieldX;
	CColorEdit m_edtASCFile;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	void DrawField();
	void InitData();
	BOOL SaveASC(CString strPath);
	void GetValueFromUI();
	void EnableControl(BOOL bUse);
	void SetAuthorityByLevel(int nLevel);
	void InitEditControl();
	void InitBtnControl();
	void InitStaticControl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupMGC2)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupMGC2();

	CFont			m_fntStatic;
	CFont			m_fntEdit;
	CFont			m_fntBtn;

	int				m_nX1;
	int				m_nX2;
	int				m_nX3;
	int				m_nY1;
	int				m_nY2;
	int				m_nY3;
	int				m_nScannerFieldX;
	double			m_dCalX[ASC_AXIS_SIZE][ASC_AXIS_SIZE];
	double			m_dCalY[ASC_AXIS_SIZE][ASC_AXIS_SIZE];

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupMGC2)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBtnOpen();
	afx_msg void OnBtnApply();
	afx_msg void OnBtnSave();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPMGC2_H__8F6994BF_8665_4A1F_AD37_1C528FB95A37__INCLUDED_)

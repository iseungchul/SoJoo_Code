// DlgLaserMeasurement.cpp : implementation file
//

#include "stdafx.h"
#include "easydriller.h"
#include "DlgLaserMeasurement.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgLaserMeasurement dialog


CDlgLaserMeasurement::CDlgLaserMeasurement(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgLaserMeasurement::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgLaserMeasurement)
		// NOTE: the ClassWizard will add member initialization here
	m_bOPC = FALSE;
	//}}AFX_DATA_INIT
}


void CDlgLaserMeasurement::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgLaserMeasurement)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_PROGRESS_MEASURE, m_progMeasure);
	DDX_Control(pDX, IDC_LIST_RESULT, m_lboxResult);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgLaserMeasurement, CDialog)
	//{{AFX_MSG_MAP(CDlgLaserMeasurement)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgLaserMeasurement message handlers

void CDlgLaserMeasurement::StartMeasurement(int nPos)
{
	m_progMeasure.SetRange32(0, nPos);
}

void CDlgLaserMeasurement::UpdateMeasurement(int nPos)
{
	
	m_progMeasure.SetPos(nPos);

	if(!m_bOPC)
	{
		int nStep = nPos % 18;

		if(nStep < 3)
			GetDlgItem(IDC_STATIC_PROGRESS)->SetWindowText("Power Measuring");
		else if(nStep >= 3 && nStep < 6)
			GetDlgItem(IDC_STATIC_PROGRESS)->SetWindowText("Power Measuring.");
		else if(nStep >= 6 && nStep < 9)
			GetDlgItem(IDC_STATIC_PROGRESS)->SetWindowText("Power Measuring..");
		else if(nStep >= 9 && nStep < 12)
			GetDlgItem(IDC_STATIC_PROGRESS)->SetWindowText("Power Measuring...");
		else if(nStep >= 12 && nStep < 15)
			GetDlgItem(IDC_STATIC_PROGRESS)->SetWindowText("Power Measuring....");
		else
			GetDlgItem(IDC_STATIC_PROGRESS)->SetWindowText("Power Measuring.....");
	}
	else
		GetDlgItem(IDC_STATIC_PROGRESS)->SetWindowText("Wait for the OPC result");	
}

BOOL CDlgLaserMeasurement::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	CFont fntStatic;
	fntStatic.CreatePointFont(130, "Arial Bold");
	GetDlgItem(IDC_STATIC_PROGRESS)->SetFont( &fntStatic );
	
	CFont m_fntListBox;
		m_fntListBox.CreatePointFont(130, "Arial Bold");
	
	m_lboxResult.SetFont( &m_fntListBox );

	CenterWindow();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
void CDlgLaserMeasurement::SetUseOnlyOPCWait(BOOL bUseOPC) 
{
	m_bOPC = bUseOPC;
	if(m_bOPC)
	{
		GetDlgItem(IDC_STATIC_PROGRESS)->SetWindowText("Wait for the OPC result");
		::SetWindowPos(this->m_hWnd, HWND_TOPMOST, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOREDRAW);
		UpdateData(FALSE);
	}
}
HBRUSH CDlgLaserMeasurement::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here

	if( CTLCOLOR_STATIC == nCtlColor )
	{
		if( GetDlgItem(IDC_STATIC_PROGRESS)->GetSafeHwnd() == pWnd->m_hWnd)
			pDC->SetTextColor( RGB(0, 0, 255 ) );
	}
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}


void CDlgLaserMeasurement::UpdateMeasureVlaue(BOOL b2nd,double dPowerValue,int nTool,int nMask)
{
	CString str;

	if(nTool == -1)
	{
		str.Format("Head %d  PreHeat",b2nd +1);
		GetDlgItem(IDC_STATIC_HEAD_AND_VALUE)->SetWindowText(str);
	return;
	}
	if(nTool == -100)
	{
		GetDlgItem(IDC_STATIC_HEAD_AND_VALUE)->SetWindowText("Make LPR Limit Table");
		return;
	}
	
	if(!b2nd)
		str.Format("Head 1  (Tool:%d , ToolTable:%d),  Measure : %.2f W",nTool,nMask,dPowerValue);
	else
		str.Format("Head 2  (Tool:%d , ToolTable:%d),  Measure : %.2f W",nTool,nMask,dPowerValue);

	GetDlgItem(IDC_STATIC_HEAD_AND_VALUE)->SetWindowText(str);


}


void CDlgLaserMeasurement::UpdateStrResult(CString strResult)
{

	if(strResult =="Clear")
	{
		m_lboxResult.ResetContent();
		return;
	}
	if(m_lboxResult.GetCount() > 400)
		m_lboxResult.DeleteString(0);

	m_lboxResult.AddString((LPCTSTR)strResult);
	m_lboxResult.SetCurSel(m_lboxResult.GetCount()-1);

}
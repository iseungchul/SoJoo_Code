// PaneManualControlScannerCalibrationPos.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlScannerCalibrationPos.h"
#include "DlgCalResult.h"
#include "..\EasyDrillerDlg.h"
#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "DlgMatroxVisionView.h"
#include "..\device\hdevicefactory.h"
#include "..\device\devicemotor.h"
#include "..\device\heocard.h"
#include "..\device\hvision.h"
#include "..\device\hvisionomi.h"
#include "..\model\deasydrillerini.h"
#include "..\model\dprocessini.h"
#include "..\model\dsystemini.h"
#include "..\model\GlobalVariable.h"
#include "..\alarmmsg.h"
#include "..\model\scannercompensation.h"
#include "math.h"
#include "float.h"
#include "..\Model\ToolCodeList.h"
#include "..\Model\DProject.h"
#include "..\device\HMotor.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const int SEL_HEAD_BOTH		= 0;
const int SEL_HEAD_MASTER	= 1;
const int SEL_HEAD_SLAVE	= 2;

const UINT	CALIBRATION_SLEEP	= 100;		// 100 ms

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlScannerCalibrationPos

IMPLEMENT_DYNCREATE(CPaneManualControlScannerCalibrationPos, CFormView)

CPaneManualControlScannerCalibrationPos::CPaneManualControlScannerCalibrationPos()
	: CFormView(CPaneManualControlScannerCalibrationPos::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlScannerCalibrationPos)
	for(int i=0; i<4; i++)
	{
		m_nCoaxial[i] = 0;
		m_nRing[i] = 0;
		m_dContrast[i] = 0.0;
		m_dBrightness[i] = 0.0;
	}
	//}}AFX_DATA_INIT
}

CPaneManualControlScannerCalibrationPos::~CPaneManualControlScannerCalibrationPos()
{
}

void CPaneManualControlScannerCalibrationPos::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlScannerCalibrationPos)
	DDX_Control(pDX, IDC_COMBO_USE_VISION, m_cmbUseVision);
	DDX_Control(pDX, IDC_EDIT_CONTRAST, m_edtContrast);
	DDX_Control(pDX, IDC_EDIT_BRIGHTNESS, m_edtBrightness);
	DDX_Control(pDX, IDC_EDIT_RING, m_edtRing);
	DDX_Control(pDX, IDC_EDIT_COAXIAL, m_edtCoaxial);
	DDX_Control(pDX, IDC_EDIT_VISION_SIZE, m_edtSize);
	DDX_Control(pDX, IDC_EDIT_VISION_ANGLE, m_edtAngle);
	DDX_Control(pDX, IDC_EDIT_VISION_ASPECT_RATIO, m_edtAspectRatio);
	DDX_Control(pDX, IDC_EDIT_MODEL_ORIENTATION, m_edtModelOrientation);
	DDX_Control(pDX, IDC_EDIT_MODEL_SIZE, m_edtModelSize);
	DDX_Control(pDX, IDC_EDIT_MANUAL_Y_POS, m_edtManualYPos);
	DDX_Control(pDX, IDC_EDIT_MANUAL_X_POS, m_edtManualXPos);
	DDX_Control(pDX, IDC_EDIT_MANUAL_2ND_THICKNESS, m_edtManual2ndThickness);
	DDX_Control(pDX, IDC_EDIT_MANUAL_1ST_THICKNESS, m_edtManual1stThickness);
	DDX_Control(pDX, IDC_EDIT_MANUAL_PULSE_WIDTH, m_edtManualPulseWidth);
	DDX_Control(pDX, IDC_EDIT_MANUAL_GRID_X, m_edtManualGridX);
	DDX_Control(pDX, IDC_EDIT_MANUAL_GRID_Y, m_edtManualGridY);
	DDX_Control(pDX, IDC_EDIT_MANUAL_GAP, m_edtManualGap);
	DDX_Control(pDX, IDC_CHECK_INSP_AREA, m_chkInspArea);
	DDX_Control(pDX, IDC_COMBO_MANUAL_MASK, m_cmbManualMask);
	DDX_Control(pDX, IDC_COMBO_MANUAL_HEAD, m_cmbManualHead);
	DDX_Control(pDX, IDC_COMBO_MANUAL_MODE, m_cmbManualMode);
	DDX_Control(pDX, IDC_LIST_RESULT, m_lboxResult);
	DDX_Control(pDX, IDC_BUTTON_CAL_STOP, m_btnCalStop);
	DDX_Control(pDX, IDC_BUTTON_CAL_START, m_btnCalStart);
	DDX_Control(pDX, IDC_STATIC_VISION_RESULT, m_stcVisionResult);
	DDX_Radio(pDX, IDC_RADIO_DARK, m_nPolarity);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlScannerCalibrationPos, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlScannerCalibrationPos)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_CAL_START, OnButtonCalStart)
	ON_BN_CLICKED(IDC_BUTTON_CAL_STOP, OnButtonCalStop)
	ON_CBN_SELCHANGE(IDC_COMBO_USE_VISION, OnSelchangeComboUseVision)
	ON_EN_KILLFOCUS(IDC_EDIT_COAXIAL, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDIT_RING, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDIT_CONTRAST, OnKillfocusEdit)
	ON_EN_KILLFOCUS(IDC_EDIT_BRIGHTNESS, OnKillfocusEdit)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHECK_INSP_AREA, OnInspectionArea)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlScannerCalibrationPos diagnostics

#ifdef _DEBUG
void CPaneManualControlScannerCalibrationPos::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlScannerCalibrationPos::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlScannerCalibrationPos message handlers

void CPaneManualControlScannerCalibrationPos::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitBtnControl();
	InitListBoxControl();
	InitEditControl();
	InitComboControl();
	
	if(!gSystemINI.m_sHardWare.nUseLampRS232)
	{
		GetDlgItem(IDC_STATIC_VISION_LIGHT)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_COAXIAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_COAXIAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_RING)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_RING)->EnableWindow(FALSE);
	}
}

BOOL CPaneManualControlScannerCalibrationPos::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneManualControlScannerCalibrationPos::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Calibration Start
	m_btnCalStart.SetFont( &m_fntBtn );
	m_btnCalStart.SetFlat( FALSE );
	m_btnCalStart.EnableBallonToolTip();
	m_btnCalStart.SetToolTipText( _T("Calibration Start") );
	m_btnCalStart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCalStart.SetBtnCursor(IDC_HAND_1);

	// Calibration Stop
	m_btnCalStop.SetFont( &m_fntBtn );
	m_btnCalStop.SetFlat( FALSE );
	m_btnCalStop.EnableBallonToolTip();
	m_btnCalStop.SetToolTipText( _T("Calibration Stop") );
	m_btnCalStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCalStop.SetBtnCursor(IDC_HAND_1);

	// Polarity
	GetDlgItem(IDC_RADIO_DARK)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_LIGHT)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_IGNORE)->SetFont( &m_fntBtn );

	// Inspection Area
	//GetDlgItem(IDC_CHECK_INSP_AREA)->SetFont( &m_fntBtn );
	m_chkInspArea.SetFont( &m_fntBtn );
	m_chkInspArea.SetImageOrg( 10, 3 );
	m_chkInspArea.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkInspArea.EnableBallonToolTip();
	m_chkInspArea.SetToolTipText( _T("Inspection Area") );
	m_chkInspArea.SetBtnCursor(IDC_HAND_1);
	m_chkInspArea.SetCheck(1);
}

void CPaneManualControlScannerCalibrationPos::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// Manual Calibration
	GetDlgItem(IDC_STATIC_MANUAL_MODE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MANUAL_CAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MANUAL_GRID_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MANUAL_GRID_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MANUAL_GAP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MANUAL_HEAD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MANUAL_PULSE_WIDTH)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1ST_THICKNESS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_2ND_THICKNESS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MANUAL_X_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MANUAL_Y_POS)->SetFont( &m_fntStatic );

	// Vision Model
	GetDlgItem(IDC_STATIC_MODEL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MODEL_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MODEL_ORIENTATION)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POLARITY)->SetFont( &m_fntStatic );

	// Accept Score
	GetDlgItem(IDC_STATIC_VISION_ACCEPT_SCORE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VISION_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VISION_ANGLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VISION_ASPECT_RATIO)->SetFont( &m_fntStatic );

	// Light
	GetDlgItem(IDC_STATIC_VISION_LIGHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_COAXIAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_RING)->SetFont( &m_fntStatic );

	// Contrast / Brightness
	GetDlgItem(IDC_STATIC_CONTRAST_BRIGHNESS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CONTRAST)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_BRIGHTNESS)->SetFont( &m_fntStatic );

	// Vision Result
	m_stcVisionResult.SetFont( &m_fntStatic );
	m_stcVisionResult.SetForeColor( VALUE_FORE_COLOR );
	m_stcVisionResult.SetBackColor( VALUE_BACK_COLOR );

	// Use Vision For Calibration
	GetDlgItem(IDC_STATIC_USE_VISION)->SetFont( &m_fntStatic );
	
//	if( 1 == gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
//		GetDlgItem(IDC_STATIC_2ND_THICKNESS)->EnableWindow(FALSE);
}

void CPaneManualControlScannerCalibrationPos::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	// Manual Calibration
	m_edtManualPulseWidth.SetFont( &m_fntEdit );
	m_edtManualPulseWidth.SetReceivedFlag( 3 );
	m_edtManualPulseWidth.SetWindowText( _T("0.1") );
	
	m_edtManual1stThickness.SetFont( &m_fntEdit );
	m_edtManual1stThickness.SetReceivedFlag( 3 );
	m_edtManual1stThickness.SetWindowText( _T("3.0") );

	m_edtManual2ndThickness.SetFont( &m_fntEdit );
	m_edtManual2ndThickness.SetReceivedFlag( 3 );
	m_edtManual2ndThickness.SetWindowText( _T("3.0") );

//	if( 1 == gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
//	{
//		m_edtManual2ndThickness.SetWindowText(_T("NO USE"));
//		m_edtManual2ndThickness.EnableWindow(FALSE);
//	}

	m_edtManualXPos.SetFont( &m_fntEdit );
	m_edtManualXPos.SetReceivedFlag( 3 );
	m_edtManualXPos.SetWindowText( _T("500.0") );

	m_edtManualYPos.SetFont( &m_fntEdit );
	m_edtManualYPos.SetReceivedFlag( 3 );
	m_edtManualYPos.SetWindowText( _T("400.0") );

	m_edtManualGridX.SetFont( &m_fntEdit );
	m_edtManualGridX.SetReceivedFlag( 1 );
	m_edtManualGridX.SetWindowText( _T("4") );

	m_edtManualGridY.SetFont( &m_fntEdit );
	m_edtManualGridY.SetReceivedFlag( 1 );
	m_edtManualGridY.SetWindowText( _T("4") );

	m_edtManualGap.SetFont( &m_fntEdit );
	m_edtManualGap.SetReceivedFlag( 3 );
	m_edtManualGap.SetWindowText( _T("50.0") );

	// Model
	m_edtModelSize.SetFont( &m_fntEdit );
	m_edtModelSize.SetReceivedFlag( 3 );
	m_edtModelSize.SetWindowText( _T("0.26") );
	
	m_edtModelOrientation.SetFont( &m_fntEdit );
	m_edtModelOrientation.SetReceivedFlag( 3 );
	m_edtModelOrientation.SetWindowText( _T("0.0") );

	// Accept Score
	m_edtSize.SetFont( &m_fntEdit );
	m_edtSize.SetReceivedFlag( 1 );
	m_edtSize.SetWindowText( _T("20") );
	
	m_edtAngle.SetFont( &m_fntEdit );
	m_edtAngle.SetReceivedFlag( 1 );
	m_edtAngle.SetWindowText( _T("20") );

	m_edtAspectRatio.SetFont( &m_fntEdit );
	m_edtAspectRatio.SetReceivedFlag( 1 );
	m_edtAspectRatio.SetWindowText( _T("1") );

	// Light
	m_edtCoaxial.SetFont( &m_fntEdit );
	m_edtCoaxial.SetReceivedFlag( 1 );
	m_edtCoaxial.SetWindowText( _T("150") );
	
	m_edtRing.SetFont( &m_fntEdit );
	m_edtRing.SetReceivedFlag( 1 );
	m_edtRing.SetWindowText( _T("150") );

	// Contrast / Brightness
	m_edtContrast.SetFont( &m_fntEdit );
	m_edtContrast.SetReceivedFlag( 3 );
	m_edtContrast.SetWindowText( _T("0.6") );
	
	m_edtBrightness.SetFont( &m_fntEdit );
	m_edtBrightness.SetReceivedFlag( 3 );
	m_edtBrightness.SetWindowText( _T("0.6") );
}

void CPaneManualControlScannerCalibrationPos::InitListBoxControl()
{
	// Set ListBox Font
	m_fntListBox.CreatePointFont(110, "Arial Bold");

	m_lboxResult.SetFont( &m_fntListBox );
}

void CPaneManualControlScannerCalibrationPos::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(130, "Arial Bold");

	m_cmbManualMode.SetFont( &m_fntCombo );
	m_cmbManualMode.SetCurSel( 0 );

	m_cmbManualMask.SetFont( &m_fntCombo );
	m_cmbManualMask.SetCurSel( 1 );

	m_cmbManualHead.SetFont( &m_fntCombo );
	m_cmbManualHead.SetCurSel( 0 );

	m_cmbUseVision.SetFont( &m_fntCombo );
	
	switch( gEasyDrillerINI.m_clsHwOption.GetCameraNum() )
	{
	case 1 :
		m_cmbUseVision.ResetContent();
		m_cmbUseVision.AddString("Vision");
		m_cmbUseVision.EnableWindow(FALSE);
		break;
	case 2 :
		m_cmbUseVision.ResetContent();
		m_cmbUseVision.AddString("High Vision");
		m_cmbUseVision.AddString("Low Vision");
		break;
	}

	m_cmbUseVision.SetCurSel( 0 );
	SetValue( 0 );
}

HBRUSH CPaneManualControlScannerCalibrationPos::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_MANUAL_CAL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MODEL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_POLARITY)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_VISION_ACCEPT_SCORE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_VISION_LIGHT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_CONTRAST_BRIGHNESS)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneManualControlScannerCalibrationPos::OnSelchangeComboUseVision()
{
	int nCamNo = m_cmbUseVision.GetCurSel();
	HVision* pVision = gDeviceFactory.GetVision();
	
	pVision->OnCamChange( nCamNo );
	
	SetValue( nCamNo );
}

void CPaneManualControlScannerCalibrationPos::SetValue(int nNumber)
{
	CString str;

	str.Format("%d", m_nCoaxial[nNumber]);
	m_edtCoaxial.SetWindowText(str);

	str.Format("%d", m_nRing[nNumber]);
	m_edtRing.SetWindowText(str);

	str.Format("%.1f", m_dContrast[nNumber]);
	m_edtContrast.SetWindowText(str);

	str.Format("%.1f", m_dBrightness[nNumber]);
	m_edtBrightness.SetWindowText(str);	
	
	UpdateData(FALSE);
}

void CPaneManualControlScannerCalibrationPos::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();
	m_fntListBox.DeleteObject();
	m_fntCombo.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneManualControlScannerCalibrationPos::ConnectView()
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->SetPanelNo(SCANNER_CAL_POS_VISION_VIEW);

		CRect rtPos;
		GetDlgItem(IDC_STATIC_SCANNER_CAL_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_SHOW );

		GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetPanelNo(SCANNER_CAL_POS_VISION_VIEW);

		CRect rtPos;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow( SW_SHOW );

		GetDlgItem(IDC_STATIC_SCANNER_CAL_VIEW)->ShowWindow(SW_HIDE);
	}

	int nCamNo = m_cmbUseVision.GetCurSel();
	OnCamChange( nCamNo );
}

void CPaneManualControlScannerCalibrationPos::OnCamChange(int nCamNo)
{
//	HVision* pVision = gDeviceFactory.GetVision();
//	pVision->OnCamChange( nCamNo );

	switch(nCamNo)
	{
	case 0:
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL);
		break;
	case 1:
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
		break;
	case 2:
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL);
		break;
	case 3:
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
		break;
	}

}

void CPaneManualControlScannerCalibrationPos::OnMoveVisionView()
{
	CRect rtPos;

	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		GetDlgItem(IDC_STATIC_SCANNER_CAL_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
	}
}

void CPaneManualControlScannerCalibrationPos::OnKillfocusEdit()
{
	UpdateData(TRUE);
	
	CString str;
	int nTempVal;
	double dTempVal;
	int nCam = m_cmbUseVision.GetCurSel();
	
	m_edtCoaxial.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > 255 || nTempVal < 0) 
		return;
	else
		m_nCoaxial[nCam] = nTempVal;
	
	m_edtRing.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > 255 || nTempVal < 0) 
		return;
	else
		m_nRing[nCam] = nTempVal;
	
	m_edtBrightness.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > 1.0 || dTempVal < 0.0) 
		return;
	else
		m_dBrightness[nCam] = dTempVal;
	
	m_edtContrast.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > 1.0 || dTempVal < 0.0) 
		return;
	else
		m_dContrast[nCam] = dTempVal;
}

void CPaneManualControlScannerCalibrationPos::SetProcessScannerCal(SPROCESSSCANNERCAL sProcessScannerCal)
{
	memcpy( &m_sProcessScannerCal, &sProcessScannerCal, sizeof(m_sProcessScannerCal) );
	
	DispProcessScannerCal();
}

void CPaneManualControlScannerCalibrationPos::DispProcessScannerCal()
{
	CString strData;
			
	// Manual Mask
	m_cmbManualMask.SetCurSel(m_sProcessScannerCal.nManualMask);

	// Manual Head
	m_cmbManualHead.SetCurSel(m_sProcessScannerCal.nManualHead);

	// Manual PulseWidth
	strData.Format("%.2f", m_sProcessScannerCal.dManualPulseWidth);
	m_edtManualPulseWidth.SetWindowText( (LPCTSTR)strData );

	// Manual 1st Thickness
	strData.Format("%.2f", m_sProcessScannerCal.dManual1stThickness);
	m_edtManual1stThickness.SetWindowText( (LPCTSTR)strData );

//	if( 1 != gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
//	{
		// Manual 2nd Thickness
		strData.Format("%.2f", m_sProcessScannerCal.dManual2ndThickness);
		m_edtManual2ndThickness.SetWindowText( (LPCTSTR)strData );
//	}

	// Model Size
	strData.Format("%.2f", m_sProcessScannerCal.dModelSize);
	m_edtModelSize.SetWindowText( (LPCTSTR)strData );

	// Model Orientation
	strData.Format("%.2f", m_sProcessScannerCal.dModelOrientation);
	m_edtModelOrientation.SetWindowText( (LPCTSTR)strData );

	// Model Polarity
	m_nPolarity = m_sProcessScannerCal.nModelPolarity;

	// Size Tolerance
	strData.Format("%.2f", m_sProcessScannerCal.dSizeTolerance);
	m_edtSize.SetWindowText( (LPCTSTR)strData );

	// Angle Tolerance
	strData.Format("%.2f", m_sProcessScannerCal.dAngleTolerance);
	m_edtAngle.SetWindowText( (LPCTSTR)strData );

	// Aspect Ratio
	strData.Format("%.2f", m_sProcessScannerCal.dAspectRatio);
	m_edtAspectRatio.SetWindowText( (LPCTSTR)strData );

	for(int i=0; i<4; i++)
	{
		m_nCoaxial[i] = m_sProcessScannerCal.nCoaxial[i];
		m_nRing[i] = m_sProcessScannerCal.nRing[i];
		m_dContrast[i] = m_sProcessScannerCal.dContrast[i];
		m_dBrightness[i] = m_sProcessScannerCal.dBrightness[i];
	}
	SetValue( 0 );

	UpdateData(FALSE);
}

void CPaneManualControlScannerCalibrationPos::SetControlToData()
{
	UpdateData(TRUE);
	
	CString strData;

	// Manual Division
	m_sProcessScannerCal.nManualDivision = m_cmbManualMode.GetCurSel();

	// Manual Mask
	m_sProcessScannerCal.nManualMask = m_cmbManualMask.GetCurSel();

	// Manual Head
	m_sProcessScannerCal.nManualHead = m_cmbManualHead.GetCurSel();

	// Manual PulseWidth
	m_edtManualPulseWidth.GetWindowText( strData );
	m_sProcessScannerCal.dManualPulseWidth = atof( (LPSTR)(LPCTSTR)strData );

	// Manual 1st Thickness
	m_edtManual1stThickness.GetWindowText( strData );
	m_sProcessScannerCal.dManual1stThickness = atof( (LPSTR)(LPCTSTR)strData );

//	if( 1 != gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() )
//	{
		// Manual 2nd Thickness
		m_edtManual2ndThickness.GetWindowText( strData );
		m_sProcessScannerCal.dManual2ndThickness = atof( (LPSTR)(LPCTSTR)strData );
//	}

	// Manaul Start X
	m_edtManualXPos.GetWindowText( strData );
	m_sProcessScannerCal.dManualStart.x = atof( (LPSTR)(LPCTSTR)strData );

	// Manual Start Y
	m_edtManualYPos.GetWindowText( strData );
	m_sProcessScannerCal.dManualStart.y = atof( (LPSTR)(LPCTSTR)strData );

	// Model Size
	m_edtModelSize.GetWindowText( strData );
	m_sProcessScannerCal.dModelSize = atof( (LPSTR)(LPCTSTR)strData );

	// Model Orientation
	m_edtModelOrientation.GetWindowText( strData );
	m_sProcessScannerCal.dModelOrientation = atof( (LPSTR)(LPCTSTR)strData );

	// Model Polarity
	m_sProcessScannerCal.nModelPolarity = m_nPolarity;

	// Size Tolerance
	m_edtSize.GetWindowText( strData );
	m_sProcessScannerCal.dSizeTolerance = atof( (LPSTR)(LPCTSTR)strData );

	// Angle Tolerance
	m_edtAngle.GetWindowText( strData );
	m_sProcessScannerCal.dAngleTolerance = atof( (LPSTR)(LPCTSTR)strData );

	// Aspect Ratio
	m_edtAspectRatio.GetWindowText( strData );
	m_sProcessScannerCal.dAspectRatio = atof( (LPSTR)(LPCTSTR)strData );

	int nNum = m_cmbUseVision.GetCurSel();

	// Coaxial
	m_edtCoaxial.GetWindowText( strData );
	m_nCoaxial[nNum] = atoi( (LPSTR)(LPCTSTR)strData );

	// Ring
	m_edtRing.GetWindowText( strData );
	m_nRing[nNum] = atoi( (LPSTR)(LPCTSTR)strData);

	// Contrast
	m_edtContrast.GetWindowText( strData );
	m_dContrast[nNum] = atof( (LPSTR)(LPCTSTR)strData);

	// Brightness
	m_edtBrightness.GetWindowText( strData );
	m_dBrightness[nNum] = atof( (LPSTR)(LPCTSTR)strData);

	for(int i=0; i<4; i++)
	{
		m_sProcessScannerCal.nCoaxial[i] = m_nCoaxial[i];
		m_sProcessScannerCal.nRing[i] = m_nRing[i];
		m_sProcessScannerCal.dContrast[i] = m_dContrast[i];
		m_sProcessScannerCal.dBrightness[i] = m_dBrightness[i];
	}
}

void CPaneManualControlScannerCalibrationPos::SetVisionInfo()
{
	SetControlToData();
	
	m_sVisionInfo.nModelType = 1;
	m_sVisionInfo.nPolarity = m_sProcessScannerCal.nModelPolarity;
	m_sVisionInfo.dSizeA = m_sProcessScannerCal.dModelSize;
	m_sVisionInfo.dSizeB = m_sProcessScannerCal.dModelSize;
	m_sVisionInfo.dSizeC = m_sProcessScannerCal.dModelSize;
//	m_sVisionInfo.dOrientation = m_sProcessScannerCal.dModelOrientation;
	
	for(int i=0; i<4; i++)
	{
		m_sVisionInfo.nCoaxial[i] = m_sProcessScannerCal.nCoaxial[i];
		m_sVisionInfo.nRing[i] = m_sProcessScannerCal.nRing[i];
		m_sVisionInfo.dContrast[i] = m_sProcessScannerCal.dContrast[i];
		m_sVisionInfo.dBrightness[i] = m_sProcessScannerCal.dBrightness[i];
	}
	
	m_sVisionInfo.dScoreAngle = m_sProcessScannerCal.dAngleTolerance;
	m_sVisionInfo.dScoreSize = m_sProcessScannerCal.dSizeTolerance;
	m_sVisionInfo.dAspectRatio = m_sProcessScannerCal.dAspectRatio;
	
	CString strData;
	int nCamNo = m_cmbUseVision.GetCurSel();
	
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnApplyVisionParam( MODEL_CIRCLE, nCamNo, m_sVisionInfo );
}

void CPaneManualControlScannerCalibrationPos::EnableCalibrationWindow(BOOL bIsEnable)
{
	GetDescendantWindow(IDC_BUTTON_CAL_START)->EnableWindow(bIsEnable);
}

void CPaneManualControlScannerCalibrationPos::WriteCalibrationStopEvent(BOOL bFinish)
{
	CString strEvent, strInfo, strTemp;
	
	if (bFinish)
		strEvent = _T("Finished automatic pos scanner calibration.");
	else
		strEvent = _T("Stopped automatic pos scanner calibration on account of system failure or user's stop event.");
	
	strInfo = _T("Manual Calibration | ");

	CString strGridX, strGridY, strGridGap, str1stThick, str2ndThick, strPulseWidth, strStartX, strStartY;
	m_edtManualGridX.GetWindowText(strGridX);
	m_edtManualGridY.GetWindowText(strGridY);
	m_edtManualGap.GetWindowText(strGridGap);
	m_edtManual1stThickness.GetWindowText(str1stThick);
	m_edtManual2ndThickness.GetWindowText(str2ndThick);
	m_edtManualPulseWidth.GetWindowText(strPulseWidth);
	m_edtManualXPos.GetWindowText(strStartX);
	m_edtManualYPos.GetWindowText(strStartY);

	int nMask = m_cmbManualMask.GetCurSel();
	int nMode = m_cmbManualMode.GetCurSel();
	
	strTemp.Format("Mode = %d | Grid size = %sx%s | Grid gap = %s | Mask No. = %d | PCB Thickness = %s, %s mm | Pulse Width = %s %% | Start Position ( X = %s mm, Y = %s mm )",
		nMode, strGridX, strGridY, strGridGap, nMask, str1stThick, str2ndThick, strPulseWidth, strStartX, strStartY);
	strInfo += strTemp;
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
}

void CPaneManualControlScannerCalibrationPos::EnableAutoCalibrationResource(BOOL bEnable)
{
	GetDescendantWindow(IDC_COMBO_MANUAL_MODE)				->EnableWindow(bEnable);
	GetDescendantWindow(IDC_COMBO_MANUAL_MASK)				->EnableWindow(bEnable);
	GetDescendantWindow(IDC_COMBO_MANUAL_HEAD)				->EnableWindow(bEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_PULSE_WIDTH)		->EnableWindow(bEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_1ST_THICKNESS)		->EnableWindow(bEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_2ND_THICKNESS)		->EnableWindow(bEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_X_POS)				->EnableWindow(!bEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_Y_POS)				->EnableWindow(!bEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_GRID_X)				->EnableWindow(!bEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_GRID_Y)				->EnableWindow(!bEnable);
	GetDescendantWindow(IDC_EDIT_MANUAL_GAP)				->EnableWindow(!bEnable);
}

BOOL CPaneManualControlScannerCalibrationPos::ChangeMask()
{
	int nMask, nHead;
	double dThick;

	nMask = m_cmbManualMask.GetCurSel();
	nHead = m_cmbManualHead.GetCurSel();

	CString strData;
	m_edtManual1stThickness.GetWindowText( strData );
	dThick = atof(strData);

#ifdef __TEST__
		return TRUE;
#endif
#ifndef __MP920_MOTOR__
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
		HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	double dTargetMask, dTargetCol;
	
	dTargetMask = gSystemINI.m_sSystemCollimator.dMaskPosition[nMask];
	dTargetCol = gSystemINI.m_sSystemCollimator.sCollimatorPos[nMask].dPositon;
	
	if (pMotor != NULL)
	{
		double dMaskPos;
		pMotor->GetPosition(AXIS_M, dMaskPos);
		double dCollPos;
		pMotor->GetPosition(AXIS_C, dCollPos);
		
		if (fabs(dMaskPos - dTargetMask) < 2.0 && fabs(dCollPos - dTargetCol) < 0.005)
			return TRUE;
		
		// Mask�� Z�� �̵�
		double dHeight1 = gSystemINI.m_sSystemDevice.d1stLaserHeight[nMask];
		double dHeight2 = gSystemINI.m_sSystemDevice.d2ndLaserHeight[nMask];
		
		dHeight1 -= dThick;
		dHeight2 -= dThick;
		
		::Sleep(20);
		return TRUE;
	}
	else
		return TRUE;		
}

BOOL CPaneManualControlScannerCalibrationPos::CheckAllMotorPositionValidity()
{
	CString strData;
	
	m_edtManualXPos.GetWindowText( strData );
	m_dStartX = atof(strData);

	m_edtManualYPos.GetWindowText( strData );
	m_dStartY = atof(strData);

	m_edtManual1stThickness.GetWindowText( strData );
	double dCalThick = atof(strData);

	int nSelHead = m_cmbManualHead.GetCurSel();
	
	const double dFieldSize = SCANNER_FIELD_SIZE;
	const double dHalfFieldSize = dFieldSize / 2.0;
	
	double dVisionZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - dCalThick;
	double dVisionZ1_2 = gSystemINI.m_sSystemDevice.d1stLowHeight - dCalThick;
	double dVisionZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - dCalThick;
	double dVisionZ2_2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - dCalThick;
	
	int nMask = m_cmbManualMask.GetCurSel();
	
	double dFireZ1 = gSystemINI.m_sSystemDevice.d1stLaserHeight[nMask] - dCalThick;
	double dFireZ2 = gSystemINI.m_sSystemDevice.d2ndLaserHeight[nMask] - dCalThick;

	m_edtManualGridX.GetWindowText( strData );
	m_nCalGridX = atoi(strData);

	m_edtManualGridY.GetWindowText( strData );
	m_nCalGridY = atoi(strData);

	m_edtManualGap.GetWindowText( strData );
	m_dCalGap = atof(strData);
	
	if (IsOutOfAxisValidity(AXIS_X, m_dStartX))
		return FALSE;
	if (IsOutOfAxisValidity(AXIS_Y, m_dStartY))
		return FALSE;
	
	double dHeadOffsetX, dHeadOffsetY;

	BOOL bUseLowCam;
	int nVision = m_cmbUseVision.GetCurSel();
	if(nVision == 0 || nVision == 2)
		bUseLowCam = FALSE;
	else
		bUseLowCam = TRUE;
	
	if(nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_MASTER)
	{
		if(bUseLowCam)
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		}
		else
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;	
		}

		if (IsOutOfAxisValidity(AXIS_X, m_dStartX + dHalfFieldSize + dHeadOffsetX))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_X, m_dStartX - dHalfFieldSize + dHeadOffsetX))
			return FALSE;	
		if (IsOutOfAxisValidity(AXIS_Y, m_dStartY + dHalfFieldSize + dHeadOffsetY))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Y, m_dStartY - dHalfFieldSize + dHeadOffsetY))
			return FALSE;	
		
		if (IsOutOfAxisValidity(AXIS_X, m_dStartX + dHalfFieldSize + dHeadOffsetX + ((m_nCalGridX - 1) * m_dCalGap)))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_X, m_dStartX - dHalfFieldSize + dHeadOffsetX + ((m_nCalGridX - 1) * m_dCalGap)))
			return FALSE;	
		if (IsOutOfAxisValidity(AXIS_Y, m_dStartY + dHalfFieldSize + dHeadOffsetY + ((m_nCalGridY - 1) * m_dCalGap)))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Y, m_dStartY - dHalfFieldSize + dHeadOffsetY + ((m_nCalGridY - 1) * m_dCalGap)))
			return FALSE;

		if (IsOutOfAxisValidity(AXIS_Z1, dVisionZ1))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Z1, dVisionZ1_2))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Z1, dFireZ1))
			return FALSE;
	}
	if (nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_SLAVE)
	{
		if(bUseLowCam)
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;	
		}
		else
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		}
		
		if (IsOutOfAxisValidity(AXIS_X, m_dStartX + dHalfFieldSize + dHeadOffsetX))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_X, m_dStartX - dHalfFieldSize + dHeadOffsetX))
			return FALSE;	
		if (IsOutOfAxisValidity(AXIS_Y, m_dStartY + dHalfFieldSize + dHeadOffsetY))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Y, m_dStartY - dHalfFieldSize + dHeadOffsetY))
			return FALSE;	
		
		if (IsOutOfAxisValidity(AXIS_X, m_dStartX + dHalfFieldSize + dHeadOffsetX + ((m_nCalGridX - 1) * m_dCalGap)))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_X, m_dStartX - dHalfFieldSize + dHeadOffsetX + ((m_nCalGridX - 1) * m_dCalGap)))
			return FALSE;	
		if (IsOutOfAxisValidity(AXIS_Y, m_dStartY + dHalfFieldSize + dHeadOffsetY + ((m_nCalGridY - 1) * m_dCalGap)))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Y, m_dStartY - dHalfFieldSize + dHeadOffsetY + ((m_nCalGridY - 1) * m_dCalGap)))
			return FALSE;

		if (IsOutOfAxisValidity(AXIS_Z2, dVisionZ2))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Z2, dVisionZ2_2))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Z2, dFireZ2))
			return FALSE;
	}
	return TRUE;
}

BOOL CPaneManualControlScannerCalibrationPos::IsOutOfAxisValidity(int nAxis, double dVal)
{
	if (dVal < gSystemINI.m_sAxisInfo[nAxis].dLimitMinus || dVal > gSystemINI.m_sAxisInfo[nAxis].dLimitPlus)
		return TRUE;
	else
		return FALSE;
}

void CPaneManualControlScannerCalibrationPos::CameraChange(int nCam)
{
	OnCamChange(nCam);

	m_cmbUseVision.SetCurSel(nCam);
}

void CPaneManualControlScannerCalibrationPos::ScannerMoveToCenter()
{
	gDeviceFactory.GetEocard()->jump(HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, TRUE);
}

void CPaneManualControlScannerCalibrationPos::ApplyVisionParam(int nCam)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnApplyVisionParam( MODEL_CIRCLE, nCam, m_sVisionInfo );
}

void CPaneManualControlScannerCalibrationPos::StopProcess()
{
	ScannerMoveToCenter();
	WriteCalibrationStopEvent();
	EnableCalibrationWindow(TRUE);
}

void CPaneManualControlScannerCalibrationPos::OnButtonCalStart() 
{
	EnableCalibrationWindow(FALSE);

	if (!UpdateData(TRUE))
	{
		EnableCalibrationWindow(TRUE);
		return;
	}

	gDeviceFactory.GetMotor()->MotorShutterAll(TRUE, TRUE);

#ifndef __TEST__
	::Sleep(CALIBRATION_SLEEP);
#endif

	if (!ChangeMask())
	{
		EnableCalibrationWindow(TRUE);
		return;
	}

	BOOL bUseLowCam;
	int nVision = m_cmbUseVision.GetCurSel();
	if(nVision == 0 || nVision == 2)
		bUseLowCam = FALSE;
	else
		bUseLowCam = TRUE;

	int nSelHead = m_cmbManualHead.GetCurSel();

	if(nSelHead != SEL_HEAD_SLAVE)
	{
		if(bUseLowCam)
		{
			CameraChange(1);
			gDeviceFactory.GetVision()->SetVisionZoom(1);
		}
		else
		{
			CameraChange(0);
			gDeviceFactory.GetVision()->SetVisionZoom(0);
		}
	}
	else
	{
		if(bUseLowCam)
		{
			CameraChange(3);
			gDeviceFactory.GetVision()->SetVisionZoom(3);
		}
		else
		{
			CameraChange(2);
			gDeviceFactory.GetVision()->SetVisionZoom(2);
		}
	}

	SetVisionInfo();

	if (!UpdateData(FALSE))
	{
		EnableCalibrationWindow(TRUE);
		return;
	}

	m_bStartCalPos = TRUE;
	
	// ��ü������ �˻�
	if (!CheckAllMotorPositionValidity())
	{
#ifndef __TEST__
		::AfxMessageBox("Motor position is invalid in Scanner calibration.");
		EnableCalibrationWindow(TRUE);
		m_bStartCalPos = FALSE;
		return;
#endif
	}

	// ���۸�� 1 or 2
	m_nProcessMode = m_cmbManualMode.GetCurSel();
	
	// ����
	if(!MoveAndFire())
	{
		EnableCalibrationWindow(TRUE);
		m_bStartCalPos = FALSE;
		return;
	}

//	if(m_nProcessMode==0)
	{
		// ����
		if(!Comparison())
		{
			EnableCalibrationWindow(TRUE);
			m_bStartCalPos = FALSE;
			return;
		}
	}

	// Ž��
	if(!SearchAndApply())
	{
		EnableCalibrationWindow(TRUE);
		m_bStartCalPos = FALSE;
		return;
	}

	CString strEvent = _T("Started automatic pos scanner calibration.");
	CString strInfo = _T("Manual Calibration| ");

	int nMask = m_cmbManualMask.GetCurSel();

	CString strData, strTemp;
	m_edtManual1stThickness.GetWindowText(strData);
	double d1st = atof(strData);
	m_edtManual2ndThickness.GetWindowText(strData);
	double d2nd = atof(strData);
	m_edtManualPulseWidth.GetWindowText(strData);
	double dPulseWidth = atof(strData);

	strTemp.Format("| PCB Thickness = %f, %f mm | Pulse Width = %f %% | Start Position ( X = %f mm, Y = %f mm )",
		d1st, d2nd, dPulseWidth, m_dStartX, m_dStartY);

	strInfo += strTemp;
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));

	::Sleep(CALIBRATION_SLEEP);
	EnableCalibrationWindow(TRUE);
}

void CPaneManualControlScannerCalibrationPos::OnButtonCalStop() 
{
	m_bStartCalPos = FALSE;
	
	EnableCalibrationWindow(TRUE);
}

BOOL CPaneManualControlScannerCalibrationPos::MoveAndFire()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(!m_bStartCalPos)
		return FALSE;

	int nMask = m_cmbManualMask.GetCurSel();

	CString strData;
	m_edtManual1stThickness.GetWindowText(strData);
	double d1stThick = atof(strData);
	m_edtManual2ndThickness.GetWindowText(strData);
	double d2ndThick = atof(strData);

	double dPosZ1 = gSystemINI.m_sSystemDevice.d1stLaserHeight[nMask] - d1stThick;
	double dPosZ2 = gSystemINI.m_sSystemDevice.d2ndLaserHeight[nMask] - d2ndThick;

	m_edtManualPulseWidth.GetWindowText(strData);
	double dPulseWidth = atof(strData);

	if(!pMotor->MoveZ(dPosZ1, dPosZ2))
	{
		TRACE("Motor out of position\n");
		return FALSE;
	}
	
	if (TRUE != pMotor->InPositionIO(IND_Z1 + IND_Z2))
	{
		TRACE("Motor does not stop\n");
		return FALSE;
	}

	HEocard* pEoCard = gDeviceFactory.GetEocard();

	FParameter Para;
	unsigned short usDelay;
	if (pEoCard->GetParameter(&Para))
	{
		Para.dDuty = dPulseWidth * 100 + 0.5;
		usDelay = Para.JumpDelay;
		Para.JumpDelay = Para.CornerDelay;
		pEoCard->SetParameter(&Para);
	}
	
	unsigned usFreq = static_cast<unsigned>(Para.Frequency);
	unsigned short usDuty = (USHORT)(dPulseWidth * 100 + 0.5);
	
	int nMaskDutyOffset = gSystemINI.m_sSystemCollimator.nDutyOffset[nMask];
	usDuty += nMaskDutyOffset;

	SUBTOOLDATA subTool;
	POSITION pos = gDProject.m_pToolCode[29]->m_SubToolData.GetHeadPosition();
	if(pos)
	{
		subTool = gDProject.m_pToolCode[29]->m_SubToolData.GetNext(pos);
		pEoCard->DownloadTCode(29, subTool.nFrequency, 1, 1, subTool.bUseAperture );
		for(int iShotIndex = 0 ; iShotIndex < MAX_BEAM_HOLE ; ++iShotIndex)
		{
			pEoCard->DownloadDutyAOM(29, iShotIndex, subTool.dShotDuty[iShotIndex]); // 5% usDuty);
		}
	}
	else
	{
		pEoCard->DownloadTCode(29, 90000, 1, 1, FALSE );
		for(int iShotIndex = 0 ; iShotIndex < MAX_BEAM_HOLE ; ++iShotIndex)
		{
			pEoCard->DownloadDutyAOM(29, iShotIndex, 5); // 5% usDuty);
		}
	}
	
	
	

	unsigned short usLaserPosX, usLaserPosY, usPosX, usPosY;
	double dPosX, dPosY;
	int nSelHead = m_cmbManualHead.GetCurSel();

	int nCount;
	if (nSelHead == SEL_HEAD_BOTH)
	{
		nCount = 2;
	}
	else if(nSelHead == SEL_HEAD_MASTER)
	{
		nCount = 1;
	}
	else
	{
		nCount = 1;
	}
	BOOL bIsMater;

	CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();

	for(int lee = 0; lee < nCount; lee++)
	{
		if(lee == 0)
		{
			if(nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_MASTER)
			{
				if(!pDlg->ShutterMove(TRUE, FALSE))
				{
					Para.JumpDelay = usDelay;
					pEoCard->SetParameter(&Para);
					return FALSE;
				}
				bIsMater = TRUE;
			}
			else
			{
				if(!pDlg->ShutterMove(FALSE, TRUE))
				{
					Para.JumpDelay = usDelay;
					pEoCard->SetParameter(&Para);
					return FALSE;
				}
				bIsMater = FALSE;
			}
		}
		else
		{
			if(!pDlg->ShutterMove(FALSE, TRUE))
			{
				Para.JumpDelay = usDelay;
				pEoCard->SetParameter(&Para);
				return FALSE;
			}
			bIsMater = FALSE;
		}
		BOOL bFirst = TRUE;
			
		for(int i=0; i<m_nCalGridY; i++)
		{
			for(int j=0; j<m_nCalGridX; j++)
			{
				pEoCard->ShotDataReset();

				dPosX = m_dStartX + (j * m_dCalGap);
				dPosY = m_dStartY + (i * m_dCalGap);

				if(!m_bStartCalPos)
					return FALSE;

	SECOND_SHOT:
					
				if(!pMotor->MoveXY(dPosX, dPosY, bIsMater))
				{
					TRACE("Motor out of position\n");
					return FALSE;
				}
	
				if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
				{
					TRACE("Motor does not stop\n");
					return FALSE;
				}

				if(!m_bStartCalPos)
					return FALSE;
	
#ifndef __TEST__
				::Sleep(CALIBRATION_SLEEP * 5);	
#endif

				if(m_nProcessMode == 0)
				{
					for(int k=0; k<4; k++)
					{
						if(k%4 == 0)
						{
							usLaserPosX = (USHORT)(HALFLSB - (HALFLSB * 0.98));
							usLaserPosY = (USHORT)(HALFLSB - (HALFLSB * 0.98));
						}
						else if(k%4 == 1)
						{
							usLaserPosX = (USHORT)(HALFLSB + (HALFLSB * 0.98));
							usLaserPosY = (USHORT)(HALFLSB - (HALFLSB * 0.98));
						}
						else if(k%4 == 2)
						{
							usLaserPosX = (USHORT)(HALFLSB + (HALFLSB * 0.98));
							usLaserPosY = (USHORT)(HALFLSB + (HALFLSB * 0.98));
						}
						else
						{
							usLaserPosX = (USHORT)(HALFLSB - (HALFLSB * 0.98));
							usLaserPosY = (USHORT)(HALFLSB + (HALFLSB * 0.98));
						}

						for(int l=0; l<4; l++)
						{
							if(l%4 == 0)
							{
								usPosX = (USHORT)(usLaserPosX - (HALFLSB * 0.01));
								usPosY = (USHORT)(usLaserPosY - (HALFLSB * 0.01));
							}
							else if(l%4 == 1)
							{
								usPosX = (USHORT)(usLaserPosX + (HALFLSB * 0.01));
								usPosY = (USHORT)(usLaserPosY - (HALFLSB * 0.01));
							}
							else if(l%4 == 2)
							{
								usPosX = (USHORT)(usLaserPosX + (HALFLSB * 0.01));
								usPosY = (USHORT)(usLaserPosY + (HALFLSB * 0.01));
							}
							else
							{
								usPosX = (USHORT)(usLaserPosX - (HALFLSB * 0.01));
								usPosY = (USHORT)(usLaserPosY + (HALFLSB * 0.01));
							}

							if(!m_bStartCalPos)
								return FALSE;
								
							if(nSelHead == SEL_HEAD_BOTH)
								pEoCard->DownloadShotData2(usPosX, usPosY, usPosX, usPosY, TRUE, TRUE, 29);
							else if(nSelHead == SEL_HEAD_MASTER)
								pEoCard->DownloadShotData2(usPosX, usPosY, usPosX, usPosY, TRUE,	FALSE, 29);
							else
								pEoCard->DownloadShotData2(usPosX, usPosY, usPosX, usPosY, FALSE, TRUE, 29);
						}
					}
				}
				else
				{
					for(int k=0; k<4; k++)
					{
						if(k%4 == 0)
						{
							usLaserPosX = (USHORT)(MAXLSB - (MAXLSB / 50.0 * 49.5));
							usLaserPosY = (USHORT)(MAXLSB - (MAXLSB / 50.0 * 49.5));
						}
						else if(k%4 == 1)
						{
							usLaserPosX = (USHORT)(MAXLSB / 50.0 * 49.5);
							usLaserPosY = (USHORT)(MAXLSB - (MAXLSB / 50.0 * 49.5));
						}
						else if(k%4 == 2)
						{
							usLaserPosX = (USHORT)(MAXLSB / 50.0 * 49.5);
							usLaserPosY = (USHORT)(MAXLSB / 50.0 * 49.5);
						}
						else
						{
							usLaserPosX = (USHORT)(MAXLSB - (MAXLSB / 50.0 * 49.5));
							usLaserPosY = (USHORT)(MAXLSB / 50.0 * 49.5);
						}
						
						for(int l=0; l<9; l++)
						{
							if(l==0 && k!=0)
								continue;

							if(k%4 == 0)
							{
								usPosX = (USHORT)(usLaserPosX + (MAXLSB * 6.125 / 50.0) * l);
								usPosY = usLaserPosY;
							}
							else if(k%4 == 1)
							{
								usPosX = usLaserPosX;
								usPosY = (USHORT)(usLaserPosY + (MAXLSB * 6.125 / 50.0) * l);
							}
							else if(k%4 == 2)
							{
								usPosX = (USHORT)(usLaserPosX - (MAXLSB * 6.125 / 50.0) * l);
								usPosY = usLaserPosY;
							}
							else
							{
								usPosX = usLaserPosX;
								usPosY = (USHORT)(usLaserPosY - (MAXLSB * 6.125 / 50.0) * l);
							}
							
							if(!m_bStartCalPos)
								return FALSE;

							TRACE("%d, %d\n", usPosX, usPosY);
							
							if(nSelHead == SEL_HEAD_BOTH)
								pEoCard->DownloadShotData2(usPosX, usPosY, usPosX, usPosY, TRUE, TRUE, 29);
							else if(nSelHead == SEL_HEAD_MASTER)
								pEoCard->DownloadShotData2(usPosX, usPosY, usPosX, usPosY, TRUE,	FALSE, 29);
							else
								pEoCard->DownloadShotData2(usPosX, usPosY, usPosX, usPosY, FALSE, TRUE, 29);
						}
					}
				}

				pEoCard->FieldStart(0);

#ifndef __TEST__				
				::Sleep(100);
#endif
				
				BOOL bResult = TRUE;
				do
				{
					::Sleep(1);

					if(!m_bStartCalPos)
					{
						pEoCard->EStop();
						return TRUE;
					}

					if(pEoCard->IsDrillTimeOut())
					{
						if(gSystemINI.m_sSystemDevice.nEStop == 1)
							pEoCard->EStop();
						return TRUE;
					}
					if(pEoCard->IsMotorFault())
					{
						if(gSystemINI.m_sSystemDevice.nEStop == 1)
							pEoCard->EStop();
						return TRUE;
					}
			
					bResult = pEoCard->IsDSPBusy();
				}while(bResult);

				if(bFirst && (i + 1 == m_nCalGridY) && (j + 1 == m_nCalGridX))
				{
					bFirst = FALSE;
					dPosX = m_dStartX;
					dPosY = m_dStartY - 1.0;
					goto SECOND_SHOT;
				}
			}
		}
	}
	Para.JumpDelay = usDelay;
	pEoCard->SetParameter(&Para);

	return TRUE;
}

BOOL CPaneManualControlScannerCalibrationPos::Comparison()
{
	if(!m_bStartCalPos)
		return FALSE;
	
	HEocard* pEoCard = gDeviceFactory.GetEocard();
	HVision* pVision = gDeviceFactory.GetVision();
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	double dVisionZ1, dVisionZ2;

	BOOL bUseLowCam;
	int nVision = m_cmbUseVision.GetCurSel();
	if(nVision == 0 || nVision == 2)
		bUseLowCam = FALSE;
	else
		bUseLowCam = TRUE;

	CString strData;
	m_edtManual1stThickness.GetWindowText(strData);
	double dCalThick = atof(strData);
	m_edtManual2ndThickness.GetWindowText(strData);
	double dCalThick2nd = atof(strData);

	if(bUseLowCam)
	{
		dVisionZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - dCalThick;
		dVisionZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - dCalThick2nd;
	}
	else
	{
		dVisionZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - dCalThick;
		dVisionZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - dCalThick2nd;
	}

	if(!m_bStartCalPos)
		return FALSE;

	if(!pMotor->MoveZ(dVisionZ1, dVisionZ2))
	{
		TRACE("Motor out of position\n");
		return FALSE;
	}

	if (TRUE != pMotor->InPositionIO(IND_Z1 + IND_Z2))
	{
		TRACE("Motor does not stop\n");
		return FALSE;
	}

	if(m_nProcessMode!=0)
		return TRUE;

	if(!m_bStartCalPos)
		return FALSE;

	DPOINT dpOffset1st[4][4];
	DPOINT dpoffset2nd[4][4];
	DPOINT dpRealPos = {0,};
	
	double dPosX, dPosY, dX, dY, dMoveX, dMoveY;	
	double dHalfField = SCANNER_FIELD_SIZE / 2.0;
	
	int nSelHead = m_cmbManualHead.GetCurSel();

	if(!m_bStartCalPos)
		return FALSE;

	BOOL bResult = FALSE;
	
	double dHeadOffset1x, dHeadOffset1y, dHeadOffset2x, dHeadOffset2y;

	if(bUseLowCam)
	{
		dHeadOffset1x = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dHeadOffset1y = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;

		dHeadOffset2x = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		dHeadOffset2y = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
	}
	else
	{
		dHeadOffset1x = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
		dHeadOffset1y = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		
		dHeadOffset2x = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
		dHeadOffset2y = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
	}

	int nCam = 0;

	if(nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_MASTER)
	{
		if(bUseLowCam)
			nCam = 1;
		else
			nCam = 0;

		for(int n=0; n<2; n++)
		{
			dPosX = m_dStartX + dHeadOffset1x;
			dPosY = m_dStartY + (n * -1.0) + dHeadOffset1y;

			for(int k=0; k<4; k++)
			{
				if(k%4 == 0)
				{
					dX = dPosX - (dHalfField * 0.98);
					dY = dPosY - (dHalfField * 0.98);
				}
				else if(k%4 == 1)
				{
					dX = dPosX + (dHalfField * 0.98);
					dY = dPosY - (dHalfField * 0.98);
				}
				else if(k%4 == 2)
				{
					dX = dPosX + (dHalfField * 0.98);
					dY = dPosY + (dHalfField * 0.98);
				}
				else
				{
					dX = dPosX - (dHalfField * 0.98);
					dY = dPosY + (dHalfField * 0.98);
				}
				
				for(int l=0; l<4; l++)
				{
					if(k==0 && l==0)
					{
						CameraChange(nCam);
						SetVisionInfo(); // lark 060709
					}

					if(l%4 == 0)
					{
						dMoveX = dX - (dHalfField * 0.01);
						dMoveY = dY - (dHalfField * 0.01);
					}
					else if(l%4 == 1)
					{
						dMoveX = dX + (dHalfField * 0.01);
						dMoveY = dY - (dHalfField * 0.01);
					}
					else if(l%4 == 2)
					{
						dMoveX = dX + (dHalfField * 0.01);
						dMoveY = dY + (dHalfField * 0.01);
					}
					else
					{
						dMoveX = dX - (dHalfField * 0.01);
						dMoveY = dY + (dHalfField * 0.01);
					}					

					if(!m_bStartCalPos)
						return FALSE;
					
					if(!pMotor->MoveXY(dMoveX, dMoveY, TRUE))
					{
						TRACE("Motor out of position\n");
						return FALSE;
					}

					if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
					{
						TRACE("Motor does not stop\n");
						return FALSE;
					}

#ifndef __TEST__
					::Sleep(CALIBRATION_SLEEP * 5);	
#endif
					
					for(int m=0; m<10; m++)
					{
//						bResult = pVision->GetRealPos(&dpRealPos, nCam, FALSE);
						if(bResult)
						{
							if(n%2)
								dpOffset1st[k][l] = dpRealPos;
							else
								dpoffset2nd[k][l] = dpRealPos;

							break;
						}
						else
						{
							if(m==9)
							{
								::AfxMessageBox("Ȧ �ν� �Ұ�. �ߴ��մϴ�.");
								return FALSE;
							}
						}
					}
				}
			}

			if(n==1)
			{
				for(int k=0; k<4; k++)
				{
					for(int l=0; l<4; l++)
					{
						if(fabs(dpOffset1st[k][l].x - dpoffset2nd[k][l].x) > 0.007)
						{
							::AfxMessageBox("������� ù��° �ʵ� X�ɼ��� ������ �̻����� ���� �ߴ��մϴ�.");
							return FALSE;
						}
						else if(fabs(dpOffset1st[k][l].y - dpoffset2nd[k][l].y) > 0.007)
						{
							::AfxMessageBox("������� ù��° �ʵ� Y�ɼ��� ������ �̻����� ���� �ߴ��մϴ�.");
							return FALSE;
						}
					}
				}
			}
		}
	}

	if(!m_bStartCalPos)
		return FALSE;

	if(nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_SLAVE)
	{
		if(bUseLowCam)
			nCam = 3;
		else
			nCam = 2;

		for(int n=0; n<2; n++)
		{
			dPosX = m_dStartX + dHeadOffset2x;
			dPosY = m_dStartY + (n * 5.0) + dHeadOffset2y;

			for(int k=0; k<4; k++)
			{
				if(k%4 == 0)
				{
					dX = dPosX - (dHalfField * 0.98);
					dY = dPosY - (dHalfField * 0.98);
				}
				else if(k%4 == 1)
				{
					dX = dPosX + (dHalfField * 0.98);
					dY = dPosY - (dHalfField * 0.98);
				}
				else if(k%4 == 2)
				{
					dX = dPosX + (dHalfField * 0.98);
					dY = dPosY + (dHalfField * 0.98);
				}
				else
				{
					dX = dPosX - (dHalfField * 0.98);
					dY = dPosY + (dHalfField * 0.98);
				}
				
				for(int l=0; l<4; l++)
				{
					if(k==0 && l==0)
					{
						CameraChange(nCam);
						SetVisionInfo(); // lark 060709
					}
					
					if(l%4 == 0)
					{
						dMoveX = dX - (dHalfField * 0.01);
						dMoveY = dY - (dHalfField * 0.01);
					}
					else if(l%4 == 1)
					{
						dMoveX = dX + (dHalfField * 0.01);
						dMoveY = dY - (dHalfField * 0.01);
					}
					else if(l%4 == 2)
					{
						dMoveX = dX + (dHalfField * 0.01);
						dMoveY = dY + (dHalfField * 0.01);
					}
					else
					{
						dMoveX = dX - (dHalfField * 0.01);
						dMoveY = dY + (dHalfField * 0.01);
					}					
					

					if(!m_bStartCalPos)
						return FALSE;
					
					if(!pMotor->MoveXY(dMoveX, dMoveY, FALSE))
					{
						TRACE("Motor out of position\n");
						return FALSE;
					}

					if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
					{
						TRACE("Motor does not stop\n");
						return FALSE;
					}

#ifndef __TEST__
					::Sleep(CALIBRATION_SLEEP * 5);	
#endif

					for(int m=0; m<10; m++)
					{
//						bResult = pVision->GetRealPos(&dpRealPos, nCam, FALSE);
						if(bResult)
						{
							if(n%2)
								dpOffset1st[k][l] = dpRealPos;
							else
								dpoffset2nd[k][l] = dpRealPos;

							break;
						}
						else
						{
							if(m==9)
							{
								::AfxMessageBox("Ȧ �ν� �Ұ�. �ߴ��մϴ�.");
								return FALSE;
							}
						}
					}
				}
			}
			
			if(n==1)
			{
				for(int k=0; k<4; k++)
				{
					for(int l=0; l<4; l++)
					{
						if(fabs(dpOffset1st[k][l].x - dpoffset2nd[k][l].x) > 0.004)
						{
							::AfxMessageBox("������� ù��° �ʵ� X�ɼ��� ������ �̻����� ���� �ߴ��մϴ�.");
							return FALSE;
						}
						else if(fabs(dpOffset1st[k][l].y - dpoffset2nd[k][l].y) > 0.004)
						{
							::AfxMessageBox("������� ù��° �ʵ� Y�ɼ��� ������ �̻����� ���� �ߴ��մϴ�.");
							return FALSE;
						}
					}
				}
			}
		}
	}
	return TRUE;
}

BOOL CPaneManualControlScannerCalibrationPos::SearchAndApply()
{
	if(!m_bStartCalPos)
		return FALSE;

	HVision* pVision = gDeviceFactory.GetVision();
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	double dPosX, dPosY, dX, dY, dMoveX, dMoveY;
	double dHalfField = SCANNER_FIELD_SIZE / 2.0;
	double dField = SCANNER_FIELD_SIZE - 1.0;

	DPOINT dpRealPos;
	DPOINT dOffset[4];
	DPOINT dMin, dMax;
	DPOINT dOffsetAvg;

	int nSelHead = m_cmbManualHead.GetCurSel();
	int nIndex, nIndexMid, nMS;

	if(nSelHead == SEL_HEAD_BOTH)
		nMS = 2;
	else if(nSelHead == SEL_HEAD_MASTER)
		nMS = 0;
	else
		nMS = 1;

	gScannerCompensation.SetInitData(m_dStartX, m_dStartY, m_dCalGap, m_nCalGridX, m_nCalGridY, nMS);

	BOOL bUseLowCam;
	int nVision = m_cmbUseVision.GetCurSel();
	if(nVision == 0 || nVision == 2)
		bUseLowCam = FALSE;
	else
		bUseLowCam = TRUE;

	if(!m_bStartCalPos)
		return FALSE;

	BOOL bResult = FALSE;

	double dHeadOffset1x, dHeadOffset1y, dHeadOffset2x, dHeadOffset2y;
	
	if(bUseLowCam)
	{
		dHeadOffset1x = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dHeadOffset1y = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		
		dHeadOffset2x = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		dHeadOffset2y = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
	}
	else
	{
		dHeadOffset1x = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
		dHeadOffset1y = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		
		dHeadOffset2x = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
		dHeadOffset2y = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
	}

	int nSideIndex = 0;

	int nCam = 0;

	if(nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_MASTER)
	{
		nIndex = 0;

		if(bUseLowCam)
			nCam = 1;
		else
			nCam = 0;
		
		for(int i=0; i<m_nCalGridY; i++)
		{
			for(int j=0; j<m_nCalGridX; j++)
			{
				dPosX = m_dStartX + (j * m_dCalGap) + dHeadOffset1x;
				dPosY = m_dStartY + (i * m_dCalGap) + dHeadOffset1y;

				if(m_nProcessMode==0)
				{
					for(int k=0; k<4; k++)
					{
						if(k%4 == 0)
						{
							dX = dPosX - (dHalfField * 0.98);
							dY = dPosY - (dHalfField * 0.98);
						}
						else if(k%4 == 1)
						{
							dX = dPosX + (dHalfField * 0.98);
							dY = dPosY - (dHalfField * 0.98);
						}
						else if(k%4 == 2)
						{
							dX = dPosX + (dHalfField * 0.98);
							dY = dPosY + (dHalfField * 0.98);
						}
						else
						{
							dX = dPosX - (dHalfField * 0.98);
							dY = dPosY + (dHalfField * 0.98);
						}

						dMin.x = dMin.y = DBL_MAX;
						dMax.x = dMax.y = -DBL_MAX;
																																		
						for(int l=0; l<4; l++)
						{
							if(k==0 && l==0)
							{
								CameraChange(nCam);
								SetVisionInfo(); // lark 060709
							}

							if(l%4 == 0)
							{
								dMoveX = dX - (dHalfField * 0.01);
								dMoveY = dY - (dHalfField * 0.01);
							}
							else if(l%4 == 1)
							{
								dMoveX = dX + (dHalfField * 0.01);
								dMoveY = dY - (dHalfField * 0.01);
							}
							else if(l%4 == 2)
							{
								dMoveX = dX + (dHalfField * 0.01);
								dMoveY = dY + (dHalfField * 0.01);
							}
							else
							{
								dMoveX = dX - (dHalfField * 0.01);
								dMoveY = dY + (dHalfField * 0.01);
							}
							
							if(!m_bStartCalPos)
								return FALSE;
																																			
							if(!pMotor->MoveXY(dMoveX, dMoveY))
							{
								TRACE("Motor out of position\n");
								return FALSE;
							}

							if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
							{
								TRACE("Motor does not stop\n");
								return FALSE;
							}

#ifndef __TEST__
							::Sleep(CALIBRATION_SLEEP * 5);	
#endif

							for(int m=0; m<10; m++)
							{
//								bResult = pVision->GetRealPos(&dpRealPos, nCam, FALSE);
								if(bResult)
								{
									dOffset[l] = dpRealPos;
									
									if(dMin.x > dpRealPos.x) dMin.x = dpRealPos.x;
									if(dMin.y > dpRealPos.y) dMin.y = dpRealPos.y;
									if(dMax.x < dpRealPos.x) dMax.x = dpRealPos.x;
									if(dMax.y < dpRealPos.y) dMax.y = dpRealPos.y;

									break;
								}
								else
								{
									if(m==9)
									{
										::AfxMessageBox("Hole Find Error. Stop Process.");
										return FALSE;
									}
								}
							}

							if(!m_bStartCalPos)
								return FALSE;
						}

						// X���
						for(l=0, nIndexMid=0, dOffsetAvg.x = 0.0; l<4; l++)
						{
							if(dOffset[l].x > dMin.x && dOffset[l].x < dMax.x)
							{
								dOffsetAvg.x += dOffset[l].x;
								nIndexMid++;
							}
						}
						if(nIndexMid == 0)
						{
							nIndexMid = 4;
							for(l=0; l<nIndexMid; l++)
								dOffsetAvg.x += dOffset[l].x;
						}
						dOffsetAvg.x = (double)(dOffsetAvg.x / nIndexMid);

						// Y���
						for(l=0, nIndexMid=0, dOffsetAvg.y = 0.0; l<4; l++)
						{
							if(dOffset[l].y > dMin.y && dOffset[l].x < dMax.y)
							{
								dOffsetAvg.y += dOffset[l].y;
								nIndexMid++;
							}
						}
						if(nIndexMid == 0)
						{
							nIndexMid = 4;
							for(l=0; l<nIndexMid; l++)
								dOffsetAvg.y += dOffset[l].y;
						}
						dOffsetAvg.y = (double)(dOffsetAvg.y / nIndexMid);

						if(k%4 == 0)
						{
							gScannerCompensation.m_pMScannerGrid[nIndex].dRTx = dOffsetAvg.x;
							gScannerCompensation.m_pMScannerGrid[nIndex].dRTy = dOffsetAvg.y;
						}
						else if(k%4 == 1)
						{
							gScannerCompensation.m_pMScannerGrid[nIndex].dLTx = dOffsetAvg.x;
							gScannerCompensation.m_pMScannerGrid[nIndex].dLTy = dOffsetAvg.y;
						}
						else if(k%4 == 2)
						{
							gScannerCompensation.m_pMScannerGrid[nIndex].dLBx = dOffsetAvg.x;
							gScannerCompensation.m_pMScannerGrid[nIndex].dLBy = dOffsetAvg.y;
						}
						else
						{
							gScannerCompensation.m_pMScannerGrid[nIndex].dRBx = dOffsetAvg.x;
							gScannerCompensation.m_pMScannerGrid[nIndex].dRBy = dOffsetAvg.y;
						}					
					}
				}
				else
				{
					nSideIndex = 0;
					for(int k=0; k<4; k++)
					{
						if(k%4 == 0)
						{
							dX = dPosX - (dField / 2.0);
							dY = dPosY - (dField / 2.0);
						}
						else if(k%4 == 1)
						{
							dX = dPosX + (dField / 2.0);
							dY = dPosY - (dField / 2.0);
						}
						else if(k%4 == 2)
						{
							dX = dPosX + (dField / 2.0);
							dY = dPosY + (dField / 2.0);
						}
						else
						{
							dX = dPosX - (dField / 2.0);
							dY = dPosY + (dField / 2.0);
						}
																																		
						for(int l=0; l<9; l++)
						{
							if(k==0 && l==0)
							{
								CameraChange(nCam);
								SetVisionInfo(); // lark 060709
							}
							if(l==0 && k!=0)
								continue;

							if(k%4 == 0)
							{
								dMoveX = dX + (dField / 8.0) * l;
								dMoveY = dY;
							}
							else if(k%4 == 1)
							{
								dMoveX = dX;
								dMoveY = dY + (dField / 8.0) * l;
							}
							else if(k%4 == 2)
							{
								dMoveX = dX - (dField / 8.0) * l;
								dMoveY = dY;
							}
							else
							{
								dMoveX = dX;
								dMoveY = dY - (dField / 8.0) * l;
							}
							
							if(!m_bStartCalPos)
								return FALSE;
																																			
							if(!pMotor->MoveXY(dMoveX, dMoveY))
							{
								TRACE("Motor out of position\n");
								return FALSE;
							}

							if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
							{
								TRACE("Motor does not stop\n");
								return FALSE;
							}

#ifndef __TEST__
							::Sleep(CALIBRATION_SLEEP * 5);	
#endif

							for(int m=0; m<10; m++)
							{
//								bResult = pVision->GetRealPos(&dpRealPos, nCam, FALSE);
								if(bResult)
									break;
								else
								{
									if(m==9)
									{
										::AfxMessageBox("Hole Find Error. Stop Process.");
										return FALSE;
									}
								}
							}

							if(!m_bStartCalPos)
								return FALSE;

							if(k%4 == 0)
							{
								dpRealPos.x = dpRealPos.x + SCANNER_FIELD_SIZE - ((SCANNER_FIELD_SIZE / 8.0) * l);
								dpRealPos.y = dpRealPos.y + SCANNER_FIELD_SIZE;
							}
							else if(k%4 == 1)
							{
								dpRealPos.x = dpRealPos.x;
								dpRealPos.y = dpRealPos.y + SCANNER_FIELD_SIZE - ((SCANNER_FIELD_SIZE / 8.0) * l);
							}
							else if(k%4 == 2)
							{
								dpRealPos.x = dpRealPos.x + ((SCANNER_FIELD_SIZE / 8.0) * l);
								dpRealPos.y = dpRealPos.y;
							}
							else
							{
								dpRealPos.x = dpRealPos.x + SCANNER_FIELD_SIZE;
								dpRealPos.y = dpRealPos.y + ((SCANNER_FIELD_SIZE / 8.0) * l);
							}

							gScannerCompensation.m_pMSideOffset[nIndex].dpOffset[nSideIndex].x = dpRealPos.x;
							gScannerCompensation.m_pMSideOffset[nIndex].dpOffset[nSideIndex++].y = dpRealPos.y;
						}
					}
				}
				nIndex++;
			}
		}
	}

	if(!m_bStartCalPos)
		return FALSE;

	if(nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_SLAVE)
	{
		if(bUseLowCam)
			nCam = 3;
		else
			nCam = 2;

		nIndex = 0;
		
		for(int i=0; i<m_nCalGridY; i++)
		{
			for(int j=0; j<m_nCalGridX; j++)
			{
				dPosX = m_dStartX + (j * m_dCalGap) + dHeadOffset2x;
				dPosY = m_dStartY + (i * m_dCalGap) + dHeadOffset2y;

				if(m_nProcessMode==0)
				{
					for(int k=0; k<4; k++)
					{
						if(k%4 == 0)
						{
							dX = dPosX - (dHalfField * 0.98);
							dY = dPosY - (dHalfField * 0.98);
						}
						else if(k%4 == 1)
						{
							dX = dPosX + (dHalfField * 0.98);
							dY = dPosY - (dHalfField * 0.98);
						}
						else if(k%4 == 2)
						{
							dX = dPosX + (dHalfField * 0.98);
							dY = dPosY + (dHalfField * 0.98);
						}
						else
						{
							dX = dPosX - (dHalfField * 0.98);
							dY = dPosY + (dHalfField * 0.98);
						}

						dMin.x = dMin.y = DBL_MAX;
						dMax.x = dMax.y = -DBL_MAX;
																																		
						for(int l=0; l<4; l++)
						{
							if(k==0 && l==0)
							{
								CameraChange(nCam);
								SetVisionInfo(); // lark 060709
							}

							if(l%4 == 0)
							{
								dMoveX = dX - (dHalfField * 0.01);
								dMoveY = dY - (dHalfField * 0.01);
							}
							else if(l%4 == 1)
							{
								dMoveX = dX + (dHalfField * 0.01);
								dMoveY = dY - (dHalfField * 0.01);
							}
							else if(l%4 == 2)
							{
								dMoveX = dX + (dHalfField * 0.01);
								dMoveY = dY + (dHalfField * 0.01);
							}
							else
							{
								dMoveX = dX - (dHalfField * 0.01);
								dMoveY = dY + (dHalfField * 0.01);
							}

							if(!m_bStartCalPos)
								return FALSE;
																																			
							if(!pMotor->MoveXY(dMoveX, dMoveY, FALSE))
							{
								TRACE("Motor out of position\n");
								return FALSE;
							}

							if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
							{
								TRACE("Motor does not stop\n");
								return FALSE;
							}

#ifndef __TEST__
							::Sleep(CALIBRATION_SLEEP * 5);		
#endif

							for(int m=0; m<10; m++)
							{
//								bResult = pVision->GetRealPos(&dpRealPos, nCam, FALSE);
								if(bResult)
								{
									dOffset[l] = dpRealPos;
									
									if(dMin.x > dpRealPos.x) dMin.x = dpRealPos.x;
									if(dMin.y > dpRealPos.y) dMin.y = dpRealPos.y;
									if(dMax.x < dpRealPos.x) dMax.x = dpRealPos.x;
									if(dMax.y < dpRealPos.y) dMax.y = dpRealPos.y;

									break;
								}
								else
								{
									if(m==9)
									{
										::AfxMessageBox("Hole Find Error. Stop Process.");
										return FALSE;
									}
								}
							}

							if(!m_bStartCalPos)
								return FALSE;
						}

						// X���
						for(l=0, nIndexMid=0, dOffsetAvg.x = 0.0; l<4; l++)
						{
							if(dOffset[l].x > dMin.x && dOffset[l].x < dMax.x)
							{
								dOffsetAvg.x += dOffset[l].x;
								nIndexMid++;
							}
						}
						if(nIndexMid == 0)
						{
							nIndexMid = 4;
							for(l=0; l<nIndexMid; l++)
								dOffsetAvg.x += dOffset[l].x;
						}
						dOffsetAvg.x = (double)(dOffsetAvg.x / nIndexMid);
						
						// Y���
						for(l=0, nIndexMid=0, dOffsetAvg.y = 0.0; l<4; l++)
						{
							if(dOffset[l].y > dMin.y && dOffset[l].x < dMax.y)
							{
								dOffsetAvg.y += dOffset[l].y;
								nIndexMid++;
							}
						}
						if(nIndexMid == 0)
						{
							nIndexMid = 4;
							for(l=0; l<nIndexMid; l++)
								dOffsetAvg.y += dOffset[l].y;
						}
						dOffsetAvg.y = (double)(dOffsetAvg.y / nIndexMid);

						if(k%4 == 0)
						{
							gScannerCompensation.m_pSScannerGrid[nIndex].dRTx = dOffsetAvg.x;
							gScannerCompensation.m_pSScannerGrid[nIndex].dRTy = dOffsetAvg.y;
						}
						else if(k%4 == 1)
						{
							gScannerCompensation.m_pSScannerGrid[nIndex].dLTx = dOffsetAvg.x;
							gScannerCompensation.m_pSScannerGrid[nIndex].dLTy = dOffsetAvg.y;
						}
						else if(k%4 == 2)
						{
							gScannerCompensation.m_pSScannerGrid[nIndex].dLBx = dOffsetAvg.x;
							gScannerCompensation.m_pSScannerGrid[nIndex].dLBy = dOffsetAvg.y;
						}
						else
						{
							gScannerCompensation.m_pSScannerGrid[nIndex].dRBx = dOffsetAvg.x;
							gScannerCompensation.m_pSScannerGrid[nIndex].dRBy = dOffsetAvg.y;
						}					
					}
				}
				else
				{
					nSideIndex = 0;
					for(int k=0; k<4; k++)
					{
						if(k%4 == 0)
						{
							dX = dPosX - (dField / 2.0);
							dY = dPosY - (dField / 2.0);
						}
						else if(k%4 == 1)
						{
							dX = dPosX + (dField / 2.0);
							dY = dPosY - (dField / 2.0);
						}
						else if(k%4 == 2)
						{
							dX = dPosX + (dField / 2.0);
							dY = dPosY + (dField / 2.0);
						}
						else
						{
							dX = dPosX - (dField / 2.0);
							dY = dPosY + (dField / 2.0);
						}
																																		
						for(int l=0; l<9; l++)
						{
							if(k==0 && l==0)
							{
								CameraChange(nCam);
								SetVisionInfo(); // lark 060709
							}
							if(l==0 && k!=0)
								continue;

							if(k%4 == 0)
							{
								dMoveX = dX + (dField / 8.0) * l;
								dMoveY = dY;
							}
							else if(k%4 == 1)
							{
								dMoveX = dX;
								dMoveY = dY + (dField / 8.0) * l;
							}
							else if(k%4 == 2)
							{
								dMoveX = dX - (dField / 8.0) * l;
								dMoveY = dY;
							}
							else
							{
								dMoveX = dX;
								dMoveY = dY - (dField / 8.0) * l;
							}
							
							if(!m_bStartCalPos)
								return FALSE;
																																			
							if(!pMotor->MoveXY(dMoveX, dMoveY, FALSE))
							{
								TRACE("Motor out of position\n");
								return FALSE;
							}

							if (TRUE != pMotor->InPositionIO(IND_X + IND_Y + IND_Z1))
							{
								TRACE("Motor does not stop\n");
								return FALSE;
							}

#ifndef __TEST__
							::Sleep(CALIBRATION_SLEEP * 5);	
#endif

							for(int m=0; m<10; m++)
							{
//								bResult = pVision->GetRealPos(&dpRealPos, nCam, FALSE);
								if(bResult)
									break;
								else
								{
									if(m==9)
									{
										::AfxMessageBox("Hole Find Error. Stop Process.");
										return FALSE;
									}
								}
							}

							if(!m_bStartCalPos)
								return FALSE;

							if(k%4 == 0)
							{
								dpRealPos.x = dpRealPos.x + SCANNER_FIELD_SIZE - ((SCANNER_FIELD_SIZE / 8.0) * l);
								dpRealPos.y = dpRealPos.y + SCANNER_FIELD_SIZE;
							}
							else if(k%4 == 1)
							{
								dpRealPos.x = dpRealPos.x;
								dpRealPos.y = dpRealPos.y + SCANNER_FIELD_SIZE - ((SCANNER_FIELD_SIZE / 8.0) * l);
							}
							else if(k%4 == 2)
							{
								dpRealPos.x = dpRealPos.x + ((SCANNER_FIELD_SIZE / 8.0) * l);
								dpRealPos.y = dpRealPos.y;
							}
							else
							{
								dpRealPos.x = dpRealPos.x + SCANNER_FIELD_SIZE;
								dpRealPos.y = dpRealPos.y + ((SCANNER_FIELD_SIZE / 8.0) * l);
							}

							gScannerCompensation.m_pSSideOffset[nIndex].dpOffset[nSideIndex].x = dpRealPos.x;
							gScannerCompensation.m_pSSideOffset[nIndex].dpOffset[nSideIndex++].y = dpRealPos.y;
						}				
					}
				}
				nIndex++;
			}
		}
	}

	if(!m_bStartCalPos)
		return FALSE;

	gScannerCompensation.SaveData(m_nProcessMode);

	return TRUE;
}

void CPaneManualControlScannerCalibrationPos::OnInspectionArea()
{
	UpdateData(TRUE);
	
	BOOL bCheck = m_chkInspArea.GetCheck();
	int nCam = m_cmbUseVision.GetCurSel();
	if(bCheck)
		gDeviceFactory.GetVision()->ShowArea(2,MODEL_CIRCLE, nCam);
	else
		gDeviceFactory.GetVision()->ShowArea(0, MODEL_CIRCLE, nCam);
}
#if !defined(AFX_DLGSCHEDULEINFO_H__49567A39_03E0_4843_AFEB_730CEE4E0B12__INCLUDED_)
#define AFX_DLGSCHEDULEINFO_H__49567A39_03E0_4843_AFEB_730CEE4E0B12__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgScheduleInfo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgScheduleInfo dialog

#include "..\model\ToolCodeList.h"
#include "..\model\DProject.h"
#include "DlgLaserMeasurement.h"
class CDlgScheduleInfo : public CDialog
{
// Construction
public:
	void MessageLoop();
	~CDlgScheduleInfo();
	CString FindProjectName(CString strLotID, CString strManager, CString strLayer, BOOL bComSol);
	CString FindProjectNameNew(CString strFileName, CString strManagementCode);
	CString FindProjectNameNew2(CString strLotID, CString strManager, int nComSol, CString strProcessCode, CString strBackwardLevel);

	void SetCurrentFiredCount(int nCount);
	BOOL WaitOPCRecvMessage();
	void ResetOPCRecvMessage();
	void SetOnlyDisplay(BOOL bOnly);
	void EnableControl(BOOL bEnable, BOOL bOnlyDisplay = FALSE);
	void EnableControlForMES(BOOL bEnable, BOOL bOnlyDisplay = FALSE);
	CString GetProjectFile(CString strLot);
	BOOL IsSameSubTool(SUBTOOLDATA subTool1, SUBTOOLDATA subTool2);
	BOOL OpenPrj();
	BOOL InputToolInfo(int nIndex, DProject &mDproject);
	BOOL CompareTool(int nPrjIndex);
	int m_nBarType;
	CDlgScheduleInfo(CWnd* pParent = NULL);   // standard constructor
	BOOL MesDataCheck(CString strLotID1, int nIndex, BOOL bNoDoMo = FALSE);
	BOOL RMSDataCheck(CString strLotID1, CString&strLotCount, CString& strFilmNo, CString& strProcessCode);
	BOOL m_bUseMES;
	void DisplayMES();
	void SaveLotInfo();
	void EnableComSolBoth(int* nComSol);
	void SetAutoMES(int nIndex, BOOL bAuto = FALSE); 
	void AutoMES();
// Dialog Data
	//{{AFX_DATA(CDlgScheduleInfo)
	enum { IDD = IDD_DLG_SCHEDULE_INFO };
	CComboBox	m_cmbBarType;
	
	CString	m_strLotInfo;
	CString	m_strLotInfo2;
	CString	m_strLotInfo3;
	CString	m_strLotInfo4;
	CString	m_strLotInfo5;
	CString	m_strLotInfo6;
	CString	m_strLotInfo7;
	CString	m_strLotInfo8;
	CString	m_strLotInfo9;
	CString	m_strLotInfo10;
	UINT	m_nNo;
	UINT	m_nNo2;
	UINT	m_nNo3;
	UINT	m_nNo4;
	UINT	m_nNo5;
	UINT	m_nNo6;
	UINT	m_nNo7;
	UINT	m_nNo8;
	UINT	m_nNo9;
	UINT	m_nNo10;
	BOOL	m_bMes;
	BOOL	m_bMes2;
	BOOL	m_bMes3;
	BOOL	m_bMes4;
	BOOL	m_bMes5;
	BOOL	m_bMes6;
	BOOL	m_bMes7;
	BOOL	m_bMes8;
	BOOL	m_bMes9;
	BOOL	m_bMes10;
	BOOL	m_bUseOpenTool;
	BOOL	m_bUseOpenTool2;
	BOOL	m_bUseOpenTool3;
	BOOL	m_bUseOpenTool4;
	BOOL	m_bUseOpenTool5;
	BOOL	m_bUseOpenTool6;
	BOOL	m_bUseOpenTool7;
	BOOL	m_bUseOpenTool8;
	BOOL	m_bUseOpenTool9;
	BOOL	m_bUseOpenTool10;
	BOOL	m_bSetFocusLot;
	BOOL	m_bSetFocusLot2;
	BOOL	m_bSetFocusLot3;
	BOOL	m_bSetFocusLot4;
	BOOL	m_bSetFocusLot5;

	int		m_nComSol;
	int		m_nComSol2;
	int		m_nComSol3;
	int		m_nComSol4;
	int		m_nComSol5;
	int		m_nComSol6;
	int		m_nComSol7;
	int		m_nComSol8;
	int		m_nComSol9;
	int		m_nComSol10;
	int		m_nFireType;
	int		m_nFireType2;
	int		m_nFireType3;
	int		m_nFireType4;
	int		m_nFireType5;
	int		m_nFireType6;
	int		m_nFireType7;
	int		m_nFireType8;
	int		m_nFireType9;
	int		m_nFireType10;
	int m_nStatus;
	int m_nStatus2;
	int m_nStatus3;
	int m_nStatus4;
	int m_nStatus5;
	int m_nStatus6;
	int m_nStatus7;
	int m_nStatus8;
	int m_nStatus9;
	int m_nStatus10;

	CString m_strFilmNo;
	CString m_strFilmNo2;
	CString m_strFilmNo3;
	CString m_strFilmNo4;
	CString m_strFilmNo5;
	CString m_strFilmNo6;
	CString m_strFilmNo7;
	CString m_strFilmNo8;
	CString m_strFilmNo9;
	CString m_strFilmNo10;
	
	CString m_strProcessCode;
	CString m_strProcessCode2;
	CString m_strProcessCode3;
	CString m_strProcessCode4;
	CString m_strProcessCode5;
	CString m_strProcessCode6;
	CString m_strProcessCode7;
	CString m_strProcessCode8;
	CString m_strProcessCode9;
	CString m_strProcessCode10;

	CString	m_strPrj1;
	CString	m_strPrj2;
	CString	m_strPrj3;
	CString	m_strPrj4;
	CString	m_strPrj5;
	CString	m_strPrj6;
	CString	m_strPrj7;
	CString	m_strPrj8;
	CString	m_strPrj9;
	CString	m_strPrj10;
	int m_nAutoIndex;
	BOOL m_bAutoMes;
	//}}AFX_DATA

	CDlgLaserMeasurement m_dlgOPCWait;

	CToolCodeList* m_pToolCode[10][MAX_TOOL_NO];
	BOOL	m_bCompareOK;
	int		m_nDiffTool;
	int		m_nLastIndex;
	BOOL	m_bOnlyDisplay;
	UINT		m_nFiredCount;
	BOOL	m_bMESChecking;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgScheduleInfo)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnButtonMES();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgScheduleInfo)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
//	afx_msg void OnButtonMES();
	afx_msg void OnButtonMES2();
	afx_msg void OnButtonMES3();
	afx_msg void OnButtonMES4();
	afx_msg void OnButtonMES5();
	afx_msg void OnButtonMES6();
	afx_msg void OnButtonMES7();
	afx_msg void OnButtonMES8();
	afx_msg void OnButtonMES9();
	afx_msg void OnButtonMES10();
	afx_msg void OnButtonMESCancel();
	afx_msg void OnButtonMESCancel2();
	afx_msg void OnButtonMESCancel3();
	afx_msg void OnButtonMESCancel4();
	afx_msg void OnButtonMESCancel5();
	afx_msg void OnButtonMESCancel6();
	afx_msg void OnButtonMESCancel7();
	afx_msg void OnButtonMESCancel8();
	afx_msg void OnButtonMESCancel9();
	afx_msg void OnButtonMESCancel10();
	afx_msg void OnButtonGetInfo();
	afx_msg void OnButtonGetInfo2();
	afx_msg void OnButtonGetInfo3();
	afx_msg void OnButtonGetInfo4();
	afx_msg void OnButtonGetInfo5();
	afx_msg void OnButtonGetInfo6();
	afx_msg void OnButtonGetInfo7();
	afx_msg void OnButtonGetInfo8();
	afx_msg void OnButtonGetInfo9();
	afx_msg void OnButtonGetInfo10();

	afx_msg void OnButtonPrjOpen();
	afx_msg void OnButtonPrjOpen2();
	afx_msg void OnButtonPrjOpen3();
	afx_msg void OnButtonPrjOpen4();
	afx_msg void OnButtonPrjOpen5();
	afx_msg void OnButtonPrjOpen6();
	afx_msg void OnButtonPrjOpen7();
	afx_msg void OnButtonPrjOpen8();
	afx_msg void OnButtonPrjOpen9();
	afx_msg void OnButtonPrjOpen10();

	afx_msg void OnCheckUseMES();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	CComboBox m_cmbCS;
	CComboBox m_cmbCS10;
	CComboBox m_cmbCS2;
	CComboBox m_cmbCS3;
	CComboBox m_cmbCS4;
	CComboBox m_cmbCS5;
	CComboBox m_cmbCS6;
	CComboBox m_cmbCS7;
	CComboBox m_cmbCS8;
	CComboBox m_cmbCS9;
	afx_msg void OnBnClickedBtnDelete();
	afx_msg void OnBnClickedBtnDelete2();
	afx_msg void OnBnClickedBtnDelete3();
	afx_msg void OnBnClickedBtnDelete4();
	afx_msg void OnBnClickedBtnDelete5();
	virtual BOOL DestroyWindow();
	afx_msg void OnBnClickedRadioCom();
	afx_msg void OnBnClickedRadioSol();
	afx_msg void OnBnClickedRadioBoth();
	afx_msg void OnBnClickedRadioCom2();
	afx_msg void OnBnClickedRadioSol2();
	afx_msg void OnBnClickedRadioBoth2();
	afx_msg void OnBnClickedRadioCom3();
	afx_msg void OnBnClickedRadioSol3();
	afx_msg void OnBnClickedRadioBoth3();
	afx_msg void OnBnClickedRadioCom4();
	afx_msg void OnBnClickedRadioSol4();
	afx_msg void OnBnClickedRadioBoth4();
	afx_msg void OnBnClickedRadioCom5();
	afx_msg void OnBnClickedRadioSol5();
	afx_msg void OnBnClickedRadioBoth5();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnSetfocusEdtLotinfo();
	afx_msg void OnEnSetfocusEdtLotinfo3();
	afx_msg void OnEnSetfocusEdtLotinfo5();
	afx_msg void OnEnSetfocusEdtLotinfo7();
	afx_msg void OnEnSetfocusEdtLotinfo9();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSCHEDULEINFO_H__49567A39_03E0_4843_AFEB_730CEE4E0B12__INCLUDED_)

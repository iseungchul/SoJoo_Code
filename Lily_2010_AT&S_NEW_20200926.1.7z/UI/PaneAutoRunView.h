#if !defined(AFX_PANEAUTORUNVIEW_H__AB00F5DC_04CB_4CF3_AFC1_AB0CC77869D5__INCLUDED_)
#define AFX_PANEAUTORUNVIEW_H__AB00F5DC_04CB_4CF3_AFC1_AB0CC77869D5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneAutoRunView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunView form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "USimpleTab.h"

class CPaneAutoRunViewData;
class CPaneAutoRunViewFiducial;

class CPaneAutoRunView : public CFormView
{
protected:
	CPaneAutoRunView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneAutoRunView)

// Form Data
public:
	//{{AFX_DATA(CPaneAutoRunView)
	enum { IDD = IDD_DLG_AUTORUN_VIEW };
	USimpleTab	m_tabAutoRunView;



		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	CPaneAutoRunViewData* m_pData;
	CPaneAutoRunViewFiducial* m_pFiducial;
		

	CFont	m_fntTab;
// Operations
public:
	void InitTabControl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneAutoRunView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneAutoRunView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneAutoRunView)
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEAUTORUNVIEW_H__AB00F5DC_04CB_4CF3_AFC1_AB0CC77869D5__INCLUDED_)

// PaneRecipeGenDataEasy.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneRecipeGenDataEasy.h"
#include "..\model\DEasyDrillerINI.h"
#include "DlgOpenExcellon.h"
#include "DlgOpenPlt.h"
#include "..\model\ExcellonReader.h"
#include "..\model\PltReader.h"
#include "..\Model\DUodoRedo.h"
#include "paneRecipeGen.h"
#include "paneREcipeGenLayOutEasy.h"
#include "paneREcipeGenParameter.h"
#include "paneREcipeGenParameterNewEasy.h"
#include "paneREcipeGenFiducialNew.h"
#include "PaneAutoRun.h"
#include "PaneAutoRunViewData.h"
#include "..\MODEL\GerberReader.h"
#include "..\alarmmsg.h"
#include "CDlgBarcodeManager.h"
#include "dlgtableoffset.h"
#include "DlgArrayCopy.h"
#include "DlgAddFiducial.h"
#include "..\model\DSystemINI.h"
#include "..\model\DProcessINI.h"
#include "..\EasyDrillerDlg.h"
#include "ProgressWnd.h"
#include "DlgOPCResult.h"
#include "..\DEVICE\HDeviceFactory.h"
#include "..\device\HVision.h"
#include "PaneManualControl.h"
#include "PaneManualControlVision.h"
#include "PaneRecipeGenSub.h"
#include "DlgSchedualeInfo.h"
#include "..\MODEL\OneClickOdbc.h"
#include <direct.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define CAD_DATA_LOADING_FAIL  -1;
#define PEN_DATA_LOADING_FAIL  -2;
#define PRJ_DATA_LOADING_FAIL  -3;
/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenDataEasy

IMPLEMENT_DYNCREATE(CPaneRecipeGenDataEasy, CFormView)

CPaneRecipeGenDataEasy::CPaneRecipeGenDataEasy()
	: CFormView(CPaneRecipeGenDataEasy::IDD)
{
	//{{AFX_DATA_INIT(CPaneRecipeGenDataEasy)
	m_pProject = NULL;
	m_pParent = NULL;
	m_bDrawMoveStart = FALSE;
	m_bUnitMoveStart = FALSE;
	m_dX = 0;
	m_dY = 0;
	m_bViewerMoveMode = TRUE;
	m_ptDrawRectBack1.x = m_ptDrawRectBack1.y = 0;
	m_ptDrawRectBack2.x = m_ptDrawRectBack2.y = 0;
	m_nUserLevel = 0;
	m_bShowSortIndex = FALSE;
	m_nStartFidIndex = -1;
	m_bDisunifyMode = FALSE;
	m_bAddSubFidMode = FALSE;
	m_ptFidPosition.x = INT_MAX;
	m_bOriginalInspection = FALSE;

	m_bSetMainFidMode = FALSE;
	m_bResetOneMainFidMode = FALSE;
	m_bSetSubFidMode = FALSE;
	m_bResetOneSubFidMode = FALSE;
	m_bExcellonChange = FALSE;
	m_bHeaderReadComplete =TRUE;
	for(int i = 0; i < MAX_FID_BLOCK; i++)
	{
		m_bSelectFidBlock[i] = FALSE;
	}
	m_strFile = _T("");
	m_strFilmName = _T("");
	m_bShowStripNo =FALSE;
	m_strProcessCode = _T("");
	m_strBackwardLevel = _T("");
	m_bSelectFire		= FALSE;
	m_bNoFindFid = FALSE;
	m_bNoUsePreWork = FALSE;
	m_nG821Count = 0;
	//}}AFX_DATA_INIT
}

CPaneRecipeGenDataEasy::~CPaneRecipeGenDataEasy()
{
}

void CPaneRecipeGenDataEasy::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneRecipeGenDataEasy)
	DDX_Control(pDX, IDC_BUTTON_ZOOM_ALL, m_btnZoomField);
	DDX_Control(pDX, IDC_BUTTON_CLEAR, m_btnSelectClear);
	DDX_Control(pDX, IDC_BUTTON_EXCELLON, m_btnExcellonLoad);
	DDX_Control(pDX, IDC_BUTTON_EASYMARKER, m_btnEasymarker);
	DDX_Control(pDX, IDC_BUTTON_FLIPX, m_btnFlipX);
	DDX_Control(pDX, IDC_BUTTON_FLIPY, m_btnFlipY);
	DDX_Control(pDX, IDC_BUTTON_ROTATE, m_btnRotate);
	DDX_Control(pDX, IDC_BUTTON_MOVE, m_btnMove);
	DDX_Control(pDX, IDC_BUTTON_PLT, m_btnRemoveAlldata);
	DDX_Control(pDX, IDC_BUTTON_SAVE_SELECTION, m_btnExcellonSave);
	DDX_Control(pDX, IDC_EDT_LOTID_COMP, m_edtLotIDComp);
	DDX_Text(pDX, IDC_EDT_LOTID_COMP, m_strLotIDComp);
	DDV_MaxChars(pDX, m_strLotIDComp, 42);
	DDX_Text(pDX, IDC_EDT_X, m_dX);
	DDX_Text(pDX, IDC_EDT_Y, m_dY);
	DDX_Control(pDX, IDC_COMBO_SELECT_COMP_SOLD, m_cmbSelectComSol);
	DDX_Control(pDX, IDC_CHECK_ORIGINAL_INSPECTION, m_ledOriginalInspection);
	DDX_Control(pDX, IDC_CHECK_DATA_HEADER, m_ledDataHeader);

	DDX_Control(pDX, IDC_CHECK_SHOW_STRIPNO, m_ledShowStripNo);
	DDX_Control(pDX, IDC_CHECK_SELECT_RUN2, m_ledSelectFire);
	DDX_Control(pDX, IDC_CHECK_NO_FIND_FID, m_ledNoFindFid);
	DDX_Control(pDX, IDC_CHECK_NO_USE_PREWORK, m_ledNoPreWork);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneRecipeGenDataEasy, CFormView)
	//{{AFX_MSG_MAP(CPaneRecipeGenDataEasy)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_EXCELLON, OnButtonExcellon)
	ON_BN_CLICKED(IDC_BUTTON_EASYMARKER, OnButtonEasymarker)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_SELECTION, OnButtonSaveExcellon)
	ON_WM_PAINT()
	ON_WM_MOUSEWHEEL()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_BN_CLICKED(IDC_BUTTON_PLT, OnButtonPlt)
	ON_BN_CLICKED(IDC_BUTTON_FLIPX, OnButtonFlipx)
	ON_BN_CLICKED(IDC_BUTTON_FLIPY, OnButtonFlipy)
	ON_BN_CLICKED(IDC_BUTTON_ROTATE, OnButtonRotate)
	ON_BN_CLICKED(IDC_BUTTON_MOVE, OnButtonMove)
	ON_WM_RBUTTONUP()
	ON_COMMAND(IDM_SELECT_FIELD_ONE, OnSelectFieldOne)
	ON_COMMAND(IDM_SELECT_FIELD, OnSelectField)
	ON_COMMAND(IDM_AREA_OFFSET, OnSetTableOffset)
	ON_COMMAND(IDM_SET_FIDUCIAL_START, OnStartFiducialSet)
	ON_COMMAND(IDM_SET_FIDUCIAL_CLEAR, OnClearFiducialSet)
	ON_COMMAND(IDM_FIDUCIAL_ADD, OnFiducialAdd)
	ON_COMMAND(IDM_FIDUCIAL_MOVE, OnFiducialMove)
	ON_COMMAND(IDM_FIDUCIAL_DEL, OnFiducialDel)
	ON_COMMAND(IDM_SET_REF_FID, OnSetRefFid)
	ON_COMMAND(IMD_ARRAY_COPY, OnArrayCopy) //unit copy
	ON_COMMAND(IMD_ADD_SUBFID, OnAddSubFid)
	ON_COMMAND(IMD_DEL_SUBFIDALL, OnDelSubFidAll)
	ON_COMMAND(IMD_MERGE_UNIT, OnMergeUnit)
	ON_COMMAND(IMD_DISUNIFY_UNIT, OnDisunifyUnit)
	ON_COMMAND(IDM_COPY_FIELD, OnCopyField) // field copy
	ON_BN_CLICKED(IDC_BUTTON_ZOOM_ALL, OnButtonZoomAll)
	ON_BN_CLICKED(IDC_BUTTON_CLEAR, OnButtonClear)

	ON_BN_CLICKED(IDC_CHECK_SHOW_STRIPNO, OnCheckShowStripNo)

	ON_WM_SETCURSOR()
	ON_WM_CANCELMODE()
	ON_COMMAND_RANGE(IDM_SELECT_FIDBLOCK_0, IDM_SELECT_FIDBLOCK_0 + MAX_FID_BLOCK, OnSelectFidBlock)
//	ON_COMMAND(IDM_SET_FIDUCIAL_MAIN, OnFiducialSetMain)
//	ON_COMMAND(IDM_RESET_FIDUCIAL_MAIN_ONE, OnFiducialResetOneMain)
//	ON_COMMAND(IDM_RESET_FIDUCIAL_MAIN_ALL, OnFiducialResetAllMain)
//	ON_COMMAND(IDM_SET_FIDUCIAL_SUB, OnFiducialSetSub)
//	ON_COMMAND(IDM_RESET_FIDUCIAL_SUB_ONE, OnFiducialResetOneSub)
//	ON_COMMAND(IDM_RESET_FIDUCIAL_SUB_ALL, OnFiducialResetAllSub)
	//}}AFX_MSG_MAP
	ON_STN_CLICKED(IDC_STATIC_VIEW, &CPaneRecipeGenDataEasy::OnStnClickedStaticView)
	ON_BN_CLICKED(IDC_CHECK_ORIGINAL_INSPECTION, OnCheckOriginalInspection)
	ON_BN_CLICKED(IDC_CHECK_DATA_HEADER, OnCheckDataHeader)
	ON_BN_CLICKED(IDC_CHECK_SELECT_RUN2, &CPaneRecipeGenDataEasy::OnBnClickedCheckSelectRun2)
	ON_BN_CLICKED(IDC_CHECK_NO_FIND_FID, &CPaneRecipeGenDataEasy::OnBnClickedCheckNoFindFid)
	ON_BN_CLICKED(IDC_CHECK_NO_USE_PREWORK, &CPaneRecipeGenDataEasy::OnBnClickedCheckNoUsePreWork)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenDataEasy diagnostics

#ifdef _DEBUG
void CPaneRecipeGenDataEasy::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneRecipeGenDataEasy::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenDataEasy message handlers

BOOL CPaneRecipeGenDataEasy::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	BOOL bResult = CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	
	return (bResult);
}

void CPaneRecipeGenDataEasy::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	CRect rtView;
	
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect( rtView );
	ScreenToClient( rtView );

	InitBtnControl();
	InitStaticControl();
	
//	m_clsDrillDataView.SetViewSize( rtView );
//	if( FALSE == m_clsDrillDataView.CreateView( this ) )
//		ErrMessage(_T("Can not create drill data view"), MB_ICONERROR);
}

HBRUSH CPaneRecipeGenDataEasy::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneRecipeGenDataEasy::OnDestroy() 
{
	CFormView::OnDestroy();
	
	// TODO: Add your message handler code here
	
}

void CPaneRecipeGenDataEasy::OnButtonExcellon() 
{
	// TODO: Add your control notification handler code here

	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}

	CString strFilePath;
	if(gSystemINI.m_sHardWare.nUseBarcodeReader)
	{	
		CDlgBarcodeManager dlg;
		dlg.SetOpenType(FALSE);
		if(IDOK != dlg.DoModal())
		{
			return;
		}
		strFilePath = dlg.m_OpenProjectFile;
	}
	else
	{
		TCHAR BASED_CODE szFilter[] = _T("Project Files (*.txt, *.dat, *.drl, *.gbr)|*.txt;*.dat;*.gbr;*.drl|All Files (*.*)|*.*||");
		
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
		
		CFileDialog dlg(TRUE, _T("*.txt"), NULL, dwFlags, szFilter);
		
		dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetDataDir();
				
		if(IDOK != dlg.DoModal())
		{
			SetFocus();
			return;
		}
		strFilePath.Format(_T("%s"), dlg.GetPathName());
	}

	BOOL bGerber = FALSE;
	CString strExt, strTemp; 

	strTemp.Format("%s",strFilePath);
	strExt = strTemp.Right(3);

	if(strExt == "gbr")
		bGerber = TRUE;

	ClearFiducialIndex();

	CDlgOpenExcellon dlgExcellon;
	if(bGerber)
	{
		if(IDOK != dlgExcellon.DoModal())
		{
			SetFocus();
			return;
		}
		
	}
		// ����Recipe���� 1st Fiducial�� Parameter�� �⺻������ �̿��ϱ� ���� ���� ����
		int nCount = m_pProject->m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);
		if(nCount > 0)
		{
			m_pProject->m_bSaveRefFidData = TRUE;
			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, 0);

			memset( m_pProject->m_pRefFidData, 0, sizeof(FID_DATA) );

			m_pProject->m_nMaxFidBlock = 0; // 20111124 bskim default fid block = 0
			m_pProject->m_pRefFidData->nCam = pFidData->nCam;
			m_pProject->m_pRefFidData->dOffsetZ = pFidData->dOffsetZ;
			m_pProject->m_pRefFidData->nFidType = pFidData->nFidType;
			m_pProject->m_pRefFidData->nToolNo = pFidData->nToolNo;
			m_pProject->m_pRefFidData->sVisInfo.dAspectRatio = pFidData->sVisInfo.dAspectRatio;
			m_pProject->m_pRefFidData->sVisInfo.dScoreAngle = pFidData->sVisInfo.dScoreAngle;
			m_pProject->m_pRefFidData->sVisInfo.dScoreSize = pFidData->sVisInfo.dScoreSize;
			m_pProject->m_pRefFidData->sVisInfo.dSizeA = pFidData->sVisInfo.dSizeA;
			m_pProject->m_pRefFidData->sVisInfo.dSizeB = pFidData->sVisInfo.dSizeB;
			m_pProject->m_pRefFidData->sVisInfo.dSizeC = pFidData->sVisInfo.dSizeC;
			m_pProject->m_pRefFidData->sVisInfo.nModelType = pFidData->sVisInfo.nModelType;
			m_pProject->m_pRefFidData->sVisInfo.nPolarity = pFidData->sVisInfo.nPolarity;
		
			for(int i=0; i<4; i++)
			{
				m_pProject->m_pRefFidData->sVisInfo.dBrightness[i] = pFidData->sVisInfo.dBrightness[i];
				m_pProject->m_pRefFidData->sVisInfo.dContrast[i] = pFidData->sVisInfo.dContrast[i];
				m_pProject->m_pRefFidData->sVisInfo.nCoaxial[i] = pFidData->sVisInfo.nCoaxial[i];
				m_pProject->m_pRefFidData->sVisInfo.nRing[i] = pFidData->sVisInfo.nRing[i];
			}
		}
		else
			m_pProject->m_bSaveRefFidData = FALSE;
		
	

	CString strPath, strMessage;
	GerberReader gerberReader;
	ExcellonReader excelReader;
//	GlyphExcellon myExcellon;
	m_nG821Count = 0;
	if(bGerber)
	{
		OnButtonPlt(); // ���� ������ ��� ����
		CProgressWnd wndProgress(NULL, _T("Data Loading"), TRUE);
		wndProgress.SetRange(0, 0);
		wndProgress.SetText(_T("Data Loading"));
		gerberReader.Read(strFilePath, dlgExcellon.m_nTZS, dlgExcellon.m_nUnit, &m_pProject->m_Glyphs, m_pProject,1 /*dlgExcellon.m_nDivide*/);
	}
	else
	{
		if(m_bHeaderReadComplete)
		{
			excelReader.HeaderRead(strFilePath, &m_pProject->m_Glyphs, m_pProject, m_bHeaderReadComplete, m_nG821Count);
		}

		if(gDProject.m_bDataHeader)
		{
			if(IDOK != excelReader.m_dlgExcellon.DoModal())
			{
				SetFocus();
				m_bHeaderReadComplete = TRUE;
				return;
			}
		}
		
		if(!m_bHeaderReadComplete)
		{
			OnButtonPlt(); // ���� ������ ��� ����
			CProgressWnd wndProgress(NULL, _T("Data Loading"), TRUE);
			wndProgress.SetRange(0, 0);
			wndProgress.SetText(_T("Data Loading "));
			excelReader.Read(strFilePath, excelReader.m_dlgExcellon.m_nTZS, excelReader.m_dlgExcellon.m_nUnit,
				&m_pProject->m_Glyphs, m_pProject, excelReader.m_dlgExcellon.m_nLineNo, excelReader.m_dlgExcellon.m_nLineDistance,
				excelReader.m_dlgExcellon.m_bZigZag, excelReader.m_dlgExcellon.m_nLineExtend, m_bHeaderReadComplete, m_nG821Count);
			
		}
		
	}
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nCurrentLotCount = 0;
	

	{
		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER + DO_SCANNER));
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (Excellon Change) : P + S"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}

	strcpy_s(m_pProject->m_szTempFileName, strFilePath);
	strcpy_s(gDProject.m_szTempFileName, strFilePath);

	::AfxGetMainWnd()->SendMessage(UM_CHANGE_DATAFILE, FALSE, reinterpret_cast<WPARAM>(&strFilePath));
	m_pProject->RemoveAreaList();
	
	CPoint nptRefFid; // 20091029
	int nSetOrigin = (m_pProject->m_nDataLoadStep & SET_FID_ORIGIN);
	int nX, nY;
	if(FALSE == m_pProject->m_Glyphs.GetRefFidPos(nX, nY))
	{
		nptRefFid.x = nptRefFid.y =INT_MAX;
	}
	else
	{
		nptRefFid.x = nX;
		nptRefFid.y = nY;
	}
	
	if(nptRefFid.x == INT_MAX || nptRefFid != m_pProject->m_nptRefFidPos)
		nSetOrigin = 0;
	
	m_pProject->m_nDataLoadStep = LOAD_EXCELLON + nSetOrigin;

	// for samsung HDI
	CString strFile = (CString)gDProject.m_szFileName;
	int nIndex = strFile.ReverseFind(_T('_')); // �ִ����� ��� LOT123A_123.txt�� LOT123A.txt�� �ü��� ����
	if(nIndex > 0) 
	{
		strTemp = strFile.Left(nIndex);
	}
	else
	{
		nIndex = strFile.ReverseFind(_T('.')); // �ִ��� LOT123A.txt�� ��ǰ�� LOT1234.txt�� ����
		strTemp = strFile.Left(nIndex);
	}

	//TCHAR chChar[2] = {0,};
	//strcpy_s(chChar, strTemp.Right(1));

	//if(gSystemINI.m_sHardWare.nExcellonOpenAxis < PX_PY || gSystemINI.m_sHardWare.nExcellonOpenAxis > NY_NX)
	//{
	//	if(chChar[0] >= 48 && chChar[0] <= 57) // ���ڴ� ��ǰ��
	//	{
	//		m_pProject->m_nAxisMode = MX_Y;
	//		m_pProject->m_nRotateInfo = MX_Y;
	//	}
	//	else if( (chChar[0] >= 65 && chChar[0] <= 90) || (chChar[0] >= 97 && chChar[0] <= 122) ) // �����ڴ� �ִ���
	//	{
	//		m_pProject->m_nAxisMode = Y_X;
	//		m_pProject->m_nRotateInfo = Y_X;
	//	}
	//	else
	//	{
	//		m_pProject->m_nAxisMode = X_Y;
	//		m_pProject->m_nRotateInfo = X_Y;
	//	}
	//}
	//else
	//{
	//	m_pProject->m_nAxisMode = gSystemINI.m_sHardWare.nExcellonOpenAxis;
	//	m_pProject->m_nRotateInfo = gSystemINI.m_sHardWare.nExcellonOpenAxis;
	//}

	// for Kunsan Lavia

					int nIndex2 = strFilePath.ReverseFind(_T('\\')); 
					strTemp = strFilePath.Right(strFilePath.GetLength() - nIndex2 - 1);
	
				//	nIndex = strFile.ReverseFind(_T('.'));
				//	strTemp = strFile.Left(nIndex);
	

					TCHAR chChar[10] = {0,};
					strcpy_s(chChar, strTemp.Left(9));

		//			if(gSystemINI.m_sHardWare.nExcellonOpenAxis < PX_PY || gSystemINI.m_sHardWare.nExcellonOpenAxis > NY_NX)
					{
						if(chChar[7] != '_')
						{
							if(chChar[7] >= 48 && chChar[7] <= 57) // ���ڴ� ��ǰ��
							{
								m_pProject->m_nAxisMode = X_Y;
								m_pProject->m_nRotateInfo = X_Y;
							}
							else if( (chChar[7] >= 65 && chChar[7] <= 90) || (chChar[7] >= 97 && chChar[7] <= 122) ) // �����ڴ� �ִ���
							{
								m_pProject->m_nAxisMode = MX_Y;
								m_pProject->m_nRotateInfo = MX_Y;
							}
							else
							{
								m_pProject->m_nAxisMode = X_Y;
								m_pProject->m_nRotateInfo = X_Y;
							}
						}
						else
						{
							if(chChar[8] >= 48 && chChar[8] <= 57) // ���ڴ� ��ǰ��
							{
								m_pProject->m_nAxisMode = X_Y;
								m_pProject->m_nRotateInfo = X_Y;
							}
							else if( (chChar[8] >= 65 && chChar[8] <= 90) || (chChar[8] >= 97 && chChar[8] <= 122) ) // �����ڴ� �ִ���
							{
								m_pProject->m_nAxisMode = MX_Y;
								m_pProject->m_nRotateInfo = MX_Y;
							}
							else
							{
								m_pProject->m_nAxisMode = X_Y;
								m_pProject->m_nRotateInfo = X_Y;
							}
						}
		
					}
					/*else
					{
						m_pProject->m_nAxisMode = gSystemINI.m_sHardWare.nExcellonOpenAxis;
						m_pProject->m_nRotateInfo = gSystemINI.m_sHardWare.nExcellonOpenAxis;
					}*/
	
	// for LG
//	m_pProject->m_nAxisMode = X_Y;
//	m_pProject->m_nRotateInfo = X_Y;

	// �����ϴ�Fid�� RefFid ����
	SetRefFidLeftBottom(m_pProject->m_nAxisMode);

	DisplayRotateInfo();
	m_pParent->m_pParamNew->SetData(*m_pProject);// >m_pParam->SetData(FALSE, *m_pProject);
	
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->SetData(*m_pProject);
	m_pParent->SetWindowForSkiving(TRUE);
	m_pProject->SetMinMaxRect();
	
	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
	m_pProject->InitialDrawRatio(cRect);
	SetFocus();

	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->ResetScale();

	if(m_pParent && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->InitialDrawRatio();
	}
	strMessage.Format(_T("Data file ( %s ) is opend"), strFilePath);
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), NULL);

	gDProject.m_dScaleTolerance2 = gProcessINI.m_sProcessFidFind.dRefScale; //������ ���� 0.02�� ������ �ʱ�ȭ
	m_pParent->m_pLayout->SetData();
	gProcessINI.m_sProcessFidFind.dPCBLenTolOperatorRunLimit = gProcessINI.m_sProcessFidFind.dRefLengthTol;
	gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 = gProcessINI.m_sProcessFidFind.dRefLengthTol2;
	m_bExcellonChange = TRUE;

	Invalidate(FALSE);
}

void CPaneRecipeGenDataEasy::OnButtonSaveExcellon()
{
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}

	TCHAR BASED_CODE szFilter[] = _T("Project Files (*.txt)|*.txt|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(FALSE, _T("*.txt"), NULL, dwFlags, szFilter);
	
	dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetDataDir();
	
	if(IDOK != dlg.DoModal())
	{
		return;
	}
	ExcellonReader excelReader;
	
	excelReader.Save(dlg.GetPathName(), &m_pProject->m_Glyphs, m_pProject);
	//	excelReader.Save(dlg.GetPathName(), &gDProject.m_Glyphs, &gDProject);
	
	CString strMessage;
	strMessage.Format(_T("Data file ( %s ) is saved"), dlg.GetPathName());
	
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), NULL);
}


void CPaneRecipeGenDataEasy::OnButtonPlt() 
{
//	if(IDYES != ErrMessage(_T("�ε��� ��� �����͸� �����Ͻðڽ��ϱ�?"), MB_YESNO))
//		return;

	m_pProject->ResetUseToolFlag();
	m_pProject->ResetMinMaxData();
	m_pProject->ReMoveExcellon();
	m_pProject->RemoveAreaList();
	m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].RemoveFidData();
	m_pProject->m_Glyphs.m_FiducialData[ADDED_FID_INDEX].RemoveFidData();
	ClearFiducialIndex();
	gDUndoRedo.Clear();

//	Invalidate(FALSE);
	// TODO: Add your control notification handler code here
/*	TCHAR BASED_CODE szFilter[] = _T("Project Files (*.plt)|*.plt|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.plt"), NULL, dwFlags, szFilter);
	
	dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetDataDir();
	
	if(IDOK != dlg.DoModal())
	{
		return;
	}
	
	CDlgOpenPlt dlgPlt;
	if(IDOK != dlgPlt.DoModal())
	{
		return;
	}
	
	CString strPath;
	
	PltReader pltReader;
	GlyphPlt* pPlt;
	pPlt = new GlyphPlt();
	
	pltReader.ReadFile(dlg.GetPathName(), pPlt, dlgPlt.m_nFieldSize);
	
	m_pProject->m_Glyphs = pPlt;
	m_pProject->SetMinMaxRect();
	m_pParent->m_pParam->SetData(FALSE, *m_pProject);
	
	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
	m_pProject->InitialDrawRatio(cRect);
	Invalidate(FALSE);
*/
}

void CPaneRecipeGenDataEasy::SetProject(DProject *pProject)
{
	m_pProject = pProject;

	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
	m_pProject->InitialDrawRatio(cRect);
	DisplayRotateInfo();

	if(m_pParent && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew)
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->InitialDrawRatio();
	
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pData->InitialDrawRatio();


	m_bSelectFire = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bSelectFire;
	m_ledSelectFire.Depress(!m_bSelectFire);
	m_pProject->m_bSelectDrawMode = m_bSelectFire;

	m_bNoFindFid = gProcessINI.m_sProcessSystem.bNoUseFiducialFind;
	m_ledNoFindFid.Depress(!m_bNoFindFid);

	m_bNoUsePreWork = gProcessINI.m_sProcessSystem.bNoUsePrework;
	m_ledNoPreWork.Depress(!m_bNoUsePreWork);

	DrawData();


	Invalidate(FALSE);
}

void CPaneRecipeGenDataEasy::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	// TODO: Add your message handler code here
	DrawData();
}

void CPaneRecipeGenDataEasy::DrawData()
{
	CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
	CDC BufferDC;
	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
	
	BufferDC.CreateCompatibleDC(&dc);
	CBitmap bmpBuffer;
	bmpBuffer.CreateCompatibleBitmap(&dc,cRect.Width(), cRect.Height());
	
	CBitmap *pOldBitmap = (CBitmap*)BufferDC.SelectObject(&bmpBuffer);
	
	CBrush cBr(RGB(0, 0, 0));
	BufferDC.FrameRect(&cRect, &cBr);
	BufferDC.FillSolidRect(&cRect, RGB(255, 255, 255));
	
	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	BufferDC.SelectClipRgn(&cRgn);
	
	//	SetDCCoord(&BufferDC);
	
	int nPenSize;
	nPenSize = 3;
	
	CPen pen;
	CPen* pOldPen;
	CBrush cBr2;
	CBrush* pOldBrush;
	
	pen.CreatePen(PS_SOLID, nPenSize, RGB(0, 0, 200));
	pOldPen = BufferDC.SelectObject(&pen);
	
	cBr2.CreateSolidBrush(RGB(0, 0, 200));
	pOldBrush = BufferDC.SelectObject(&cBr2);
	
	// draw
	if(m_pProject)
	{
		m_pProject->Draw(&BufferDC, cRect);
		m_pProject->DrawToolInfo(&BufferDC, cRect);
	}
	
	BufferDC.SelectObject(pOldBrush);
	BufferDC.SelectObject(pOldPen);
	
	//	GetDlgItem(IDC_STATIC_DRAW)->GetWindowRect(&cRect);
	dc.BitBlt(0,0,cRect.Width(),cRect.Height(),&BufferDC,0,0,SRCCOPY);
	
	BufferDC.SelectObject(pOldBitmap);
	

	//((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->DrawData();
}

BOOL CPaneRecipeGenDataEasy::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	CRect cRect;
	if(pMsg->message == WM_LBUTTONDOWN)
	{
		if( ::GetDlgCtrlID(pMsg->hwnd) == m_edtLotIDComp.GetDlgCtrlID())
		{
			m_edtLotIDComp.SetFocus();
			m_edtLotIDComp.SetSel(0, -1);
			return TRUE;
		}
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Recipe_Data) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}

	if (pMsg->message == WM_KEYDOWN)
	{
		if( ::GetDlgCtrlID(pMsg->hwnd) == m_edtLotIDComp.GetDlgCtrlID())
		{
			switch (pMsg->wParam)
			{
			case VK_RETURN:
				if(m_cmbSelectComSol.GetCurSel() == 0)
				{
					MesDataFileCheck(0);
					return TRUE;
				}
				else if(m_cmbSelectComSol.GetCurSel() == 1)
				{
					MesDataFileCheck(1);
					return TRUE;
				}
				else if(m_cmbSelectComSol.GetCurSel() == 2)
				{
					MesDataFileCheck(2);
					return TRUE;
				}
				return TRUE;
			}
		}
		else
		{
			switch (pMsg->wParam)
 			{
//			case 16: // Shift
//				m_pProject->m_Glyphs.m_bSelectionPlus = TRUE;
//				break;
//			case 17: // Ctrl
//				m_pProject->m_Glyphs.m_bSelectionPlus = TRUE;
//				break;
			
			case VK_DELETE:
					if(m_pProject == NULL)
						return TRUE;
					m_pProject->DeleteSelectUnit();
					m_pProject->ReCalRect();
					m_pProject->SetProjectStatusToExcellOpen();
					Invalidate(FALSE);
				return TRUE;
				
			case VK_ESCAPE:
				if(m_bDrawMoveStart)
				{
					m_bDrawMoveStart = FALSE;
					CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
					DrawSelectionRect(&dc);
				}
				m_bDisunifyMode = FALSE;

				return TRUE;
			case 65: // A
			case 97: // a : window all view
				if(m_pProject == NULL)
					return TRUE;
				GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
				m_pProject->InitialDrawRatio(cRect);
				Invalidate(FALSE);
				return TRUE;
			case 77:	// M
			case 109:	// m : mode change : select mode <-> viwer move mode
//				if(m_nUserLevel < 1) // Operator Level������ ��� ���Ѵ�
//					return TRUE;

//				if(m_pProject->m_nDataLoadStep < FIELD_DIVIED) // FieldDivide �������� flag ��ȭ ���Ѵ�
//					return TRUE;

				if(m_bDrawMoveStart || m_bUnitMoveStart) // select or move ���߿��� flag ��ȭ ���Ѵ�
					return TRUE;

				if(m_bViewerMoveMode)
					m_bViewerMoveMode = FALSE;
				else
					m_bViewerMoveMode = TRUE;
				return TRUE;
			case 70 :	// F
			case 102 :  // f : show sort index

				if((m_pProject->m_nDataLoadStep & 0x0b) < FIELD_DIVIED) // FieldDivide �������� flag ��ȭ ���Ѵ� // 20091029
				{
					m_bShowSortIndex = FALSE;
					m_pProject->ChangeViewIndex(m_bShowSortIndex);
					return TRUE;
				}

				if(m_bDrawMoveStart || m_bUnitMoveStart) // select or move ���߿��� flag ��ȭ ���Ѵ�
				{
					m_bShowSortIndex = FALSE;
					m_pProject->ChangeViewIndex(m_bShowSortIndex);
					return TRUE;
				}
				
				if(m_pProject == NULL)
				{
					m_bShowSortIndex = FALSE;
					m_pProject->ChangeViewIndex(m_bShowSortIndex);
					return TRUE;
				}

				m_bShowSortIndex = !m_bShowSortIndex;
				ClearFiducialIndex();
				
				m_pProject->ChangeViewIndex(m_bShowSortIndex);
				Invalidate(FALSE);

				return TRUE;
/*			case 37: // �·� <-
				if(m_pProject->MoveUnit(MOVE_LEFT))
					Invalidate(FALSE);
				return TRUE;
			case 39: // ��� ->
				if(m_pProject->MoveUnit(MOVE_RIGHT))
					Invalidate(FALSE);
				return TRUE;
			case 38: // ����^
				if(m_pProject->MoveUnit(MOVE_UP))
					Invalidate(FALSE);	
				return TRUE;
			case 40: // ȭ��ǥ �Ʒ� v
				if(m_pProject->MoveUnit(MOVE_DOWN))
					Invalidate(FALSE);
				return TRUE;
*/			case 88: // 'x'  : undo
				gDUndoRedo.Undo();
				if(m_pProject == NULL)
					return TRUE;
				m_pProject->ReCalRect();
				m_pProject->SetProjectStatusToExcellOpen();
				Invalidate(FALSE);
				return TRUE;
			case 89: // 'y'  : redo
				gDUndoRedo.Redo();
				if(m_pProject == NULL)
					return TRUE;
				m_pProject->ReCalRect();
				m_pProject->SetProjectStatusToExcellOpen();
				Invalidate(FALSE);
				return TRUE;

			case 73: // 'i'  : zoom in
			case 105: // 'I'  : zoom out
				OnMouseWheel(0, -WHEEL_DELTA, pMsg->pt);
				return TRUE;
			case 79: // 'o'  : zoom in
			case 111: // 'O'  : zoom out
				OnMouseWheel(0, WHEEL_DELTA, pMsg->pt);
				return TRUE;
		}
		}
	}
/*	
	if (pMsg->message == WM_KEYUP)
	{
		switch (pMsg->wParam)
		{
		case 16: // Shift
			m_pProject->m_Glyphs.m_bSelectionPlus = FALSE;
			break;
		case 17: // Ctrl
			m_pProject->m_Glyphs.m_bSelectionPlus = FALSE;
			break;
		}
	}
*/
	return CFormView::PreTranslateMessage(pMsg);
}

BOOL CPaneRecipeGenDataEasy::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_pProject == NULL)
		return TRUE;

	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
	if(rect.PtInRect(pt))
	{
		tempP.x = pt.x - rect.left;
		tempP.y = pt.y - rect.top;
		if(zDelta >= WHEEL_DELTA)
			m_pProject->SetDrawRect(tempP, 1);
		else
			m_pProject->SetDrawRect(tempP, -1);
		
		Invalidate(FALSE);
	}
	if(nFlags == 0)
		return TRUE;
	
	return CFormView::OnMouseWheel(nFlags, zDelta, pt);
}

void CPaneRecipeGenDataEasy::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CRect rect, rectEdt;
	CPoint tempP;
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
	m_edtLotIDComp.GetWindowRect(&rectEdt);
	ClientToScreen(&point);
	CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));

	if(rect.PtInRect(point))
	{
		GetDlgItem(IDC_STATIC_VIEW)->SetFocus();
		tempP.x = point.x - rect.left;
		tempP.y = point.y - rect.top;
		if(IsPickToolVisible(tempP))
			return;
		if(IsCheckSelectViewMode(tempP))
			return;
		if(IsCheckPathViewMode(tempP))
			return;
	}
	else
		return;
	
	if(IsPickUnit(tempP)) // ���õ� unit�� �̵���ų��
	{
		m_bDrawMoveStart = FALSE;
		m_bUnitMoveStart = TRUE;
		m_ptMoveStart = tempP;
		m_ptTotalMove.x = m_ptTotalMove.y = 0;
	}
	else
	{
		m_bDrawMoveStart = TRUE;
		m_bUnitMoveStart = FALSE;
		m_ptMoveStart = tempP;
		m_ptDrawStart = tempP;
		
		if(!m_bViewerMoveMode)
		{
			DrawSelectionRect(&dc, m_ptDrawStart, m_ptDrawStart);
		}
	}

	
	CFormView::OnLButtonDown(nFlags, point);
}

void CPaneRecipeGenDataEasy::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
/*
	if(m_bSetMainFidMode)
	{
		if(m_pProject == NULL)
			return;
		
		CRect rect;
		CPoint tempP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		
		CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
		
		if(rect.PtInRect(point))
		{
			tempP.x = point.x - rect.left;
			tempP.y = point.y - rect.top;
			
			int nIndex = m_pProject->IsThereFid(tempP);
			if(nIndex >= 0)
			{
				m_pProject->SetFiducial(nIndex, FALSE); // MainFid
				Invalidate(FALSE);
			}
		}
		m_bAddSubFidMode = FALSE;
		m_bDrawMoveStart = FALSE;
		
		m_bSetMainFidMode = FALSE;
		m_bResetOneMainFidMode = FALSE;
		m_bSetSubFidMode = FALSE;
		m_bResetOneSubFidMode = FALSE;

		return;
	}
*/

	if(m_bResetOneMainFidMode)
	{
		if(m_pProject == NULL)
			return;
		
		CRect rect;
		CPoint tempP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		
		CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
		
		if(rect.PtInRect(point))
		{
			tempP.x = point.x - rect.left;
			tempP.y = point.y - rect.top;
			
			int nIndex = m_pProject->IsThereFid(tempP);
			if(nIndex >= 0)
			{
				m_pProject->ResetOneFiducial(nIndex, FALSE); // MainFid
				Invalidate(FALSE);
			}
		}
		m_bAddSubFidMode = FALSE;
		m_bDrawMoveStart = FALSE;
		
		m_bSetMainFidMode = FALSE;
		m_bResetOneMainFidMode = FALSE;
		m_bSetSubFidMode = FALSE;
		m_bResetOneSubFidMode = FALSE;

		return;
	}

/*
	if(m_bSetSubFidMode)
	{
		if(m_pProject == NULL)
			return;
		
		CRect rect;
		CPoint tempP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		
		CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
		
		if(rect.PtInRect(point))
		{
			tempP.x = point.x - rect.left;
			tempP.y = point.y - rect.top;
			
			int nIndex = m_pProject->IsThereFid(tempP);
			if(nIndex >= 0)
			{
				m_pProject->SetFiducial(nIndex, TRUE); // SubFid
				Invalidate(FALSE);
			}
		}
		m_bAddSubFidMode = FALSE;
		m_bDrawMoveStart = FALSE;
		
		m_bSetMainFidMode = FALSE;
		m_bResetOneMainFidMode = FALSE;
		m_bSetSubFidMode = FALSE;
		m_bResetOneSubFidMode = FALSE;

		return;
	}
*/

	if(m_bResetOneSubFidMode)
	{
		if(m_pProject == NULL)
			return;
		
		CRect rect;
		CPoint tempP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		
		CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
		
		if(rect.PtInRect(point))
		{
			tempP.x = point.x - rect.left;
			tempP.y = point.y - rect.top;
			
			int nIndex = m_pProject->IsThereFid(tempP);
			if(nIndex >= 0)
			{
				m_pProject->ResetOneFiducial(nIndex, TRUE); // SubFid
				Invalidate(FALSE);
			}
		}
		m_bAddSubFidMode = FALSE;
		m_bDrawMoveStart = FALSE;
		
		m_bSetMainFidMode = FALSE;
		m_bResetOneMainFidMode = FALSE;
		m_bSetSubFidMode = FALSE;
		m_bResetOneSubFidMode = FALSE;

		return;
	}

	if(m_bAddSubFidMode)
	{
		if(m_pProject == NULL)
			return;
		
		CRect rect;
		CPoint tempP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		
		CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
		
		if(rect.PtInRect(point))
		{
			tempP.x = point.x - rect.left;
			tempP.y = point.y - rect.top;
			
			int nIndex = m_pProject->IsThereFid(tempP);
			if(nIndex >= 0)
			{
				m_pProject->AddSubFiducial(nIndex); 
				m_pProject->ReCalRect();
				Invalidate(FALSE);
			}
			else
			{
				CDlgAddFiducial dlg;
				if(nIndex != -1) // do not find in hole data
				{
					tempP = m_pProject->GetFilePos(tempP);
				}
				dlg.SetData(tempP.x, tempP.y);
				if(dlg.DoModal() == IDOK)
				{
					tempP.x = (LONG)((dlg.m_dX + 0.0002) * 1000);
					tempP.y = (LONG)((dlg.m_dY + 0.0002) * 1000);
					
					// 091230
					CPoint ptTrans;
					ptTrans = m_pProject->GetNoAxisChangePos(tempP);
					//
					
					m_pProject->AddSubFiducial(tempP);
				}
				else
				{
					m_bAddSubFidMode = FALSE;
					m_bDrawMoveStart = FALSE;

					m_bSetMainFidMode = FALSE;
					m_bResetOneMainFidMode = FALSE;
					m_bSetSubFidMode = FALSE;
					m_bResetOneSubFidMode = FALSE;
					return;
				}
				
				m_pProject->ReCalRect();
				Invalidate(FALSE);
			}
		}
		m_bAddSubFidMode = FALSE;
		m_bDrawMoveStart = FALSE;

		m_bSetMainFidMode = FALSE;
		m_bResetOneMainFidMode = FALSE;
		m_bSetSubFidMode = FALSE;
		m_bResetOneSubFidMode = FALSE;
		return;
	}

	if(m_bDrawMoveStart)
	{
		m_bDrawMoveStart = FALSE;

		if(m_pProject == NULL)
			return;

		CRect rect;
		CPoint tempP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);

		CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
		
		if(rect.PtInRect(point))
		{
			tempP.x = point.x - rect.left;
			tempP.y = point.y - rect.top;
			ChangePosInfo(tempP); // display current file position

			if(!m_bViewerMoveMode)
			{
				if(tempP == m_ptDrawStart)
					m_pProject->SelectGlyph(tempP);
				else
				{
					if(m_bDisunifyMode)
					{
						if(m_pProject->DisunifyUnit(m_ptDrawStart, tempP))
						{
							Invalidate(FALSE);
							gDUndoRedo.Clear();
							return;
						}
					}
					else
					{
						BOOL bSelectUnit = FALSE;
						if(m_ptDrawStart.x > tempP.x)
							bSelectUnit = TRUE;

						m_pProject->SelectGlyphWithRect(m_ptDrawStart, tempP, bSelectUnit);
					}
				}

				DrawSelectionRect(&dc, m_ptDrawStart, tempP);
			}

			Invalidate(FALSE);
		}
		else
			return;
	}
	if(m_bUnitMoveStart)
	{
		if(m_pProject == NULL)
			return;
		
		CRect rect;
		CPoint tempP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		
		CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
		
		if(rect.PtInRect(point))
		{
			tempP.x = point.x - rect.left;
			tempP.y = point.y - rect.top;
			ChangePosInfo(tempP); // display current file position
		}
		m_pProject->AddMoveUnitsToUndoList();
		gDUndoRedo.MoveGlyphs(m_ptTotalMove);
		m_pProject->ReCalRect();
		m_pProject->SetProjectStatusToExcellOpen();
		m_bUnitMoveStart = FALSE;
		Invalidate(FALSE);
	}

	CFormView::OnLButtonUp(nFlags, point);
}

void CPaneRecipeGenDataEasy::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	if(m_pProject == NULL)
		return;

	CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));

	if(m_bDrawMoveStart)
	{
		CRect rect;
		CPoint tempP, endP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		if(rect.PtInRect(point))
		{
			endP.x = point.x - rect.left;
			endP.y = point.y - rect.top;
			tempP.x = endP.x - m_ptMoveStart.x;
			tempP.y = endP.y - m_ptMoveStart.y;

			ChangePosInfo(endP); // display current file position
			
			if(m_ptMoveStart != tempP)
			{
				if(m_bViewerMoveMode)
				{
					m_ptMoveStart = endP;
					m_pProject->SetDrawRect(tempP, 0);
					Invalidate(FALSE);
				}
				else
				{
					DrawSelectionRect(&dc, m_ptDrawStart, m_ptMoveStart);
					m_ptMoveStart = endP;
					DrawSelectionRect(&dc, m_ptDrawStart, m_ptMoveStart);
				}

			}
		}
	}
	else if(m_bUnitMoveStart)
	{
		CRect rect;
		CPoint tempP, endP, ptMove;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		if(rect.PtInRect(point))
		{
			endP.x = point.x - rect.left;
			endP.y = point.y - rect.top;
			tempP.x = endP.x - m_ptMoveStart.x;
			tempP.y = endP.y - m_ptMoveStart.y;

			if(m_pProject == NULL)
				return;
			ptMove = m_pProject->MoveUnitDP(tempP.x, -tempP.y);
			m_ptTotalMove += ptMove;

			if(tempP.x != 0 || tempP.y != 0)
				Invalidate(FALSE);

			m_ptMoveStart = endP;
		}
	}
	else
	{
		CRect rect;
		CPoint endP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		if(rect.PtInRect(point))
		{
			endP.x = point.x - rect.left;
			endP.y = point.y - rect.top;
			ChangePosInfo(endP); // display current file position
		}
	}
	return;
	
	CFormView::OnMouseMove(nFlags, point);
}

void CPaneRecipeGenDataEasy::CalRefFidFlipPos(BOOL bX)
{
	double dRefX, dRefY;
	m_pProject->m_Glyphs.GetRefPosition(dRefX, dRefY); // mm ����.
	CPoint nFilePos[3];
	for(int i = 0; i<3; i++)
	{
		nFilePos[i] = m_pProject->m_Glyphs.GetUseFidIntPoint(DEFAULT_FID_INDEX, i+1); 
	}
	
	double dMinDisX = 0, dMinDisY = 0;
	double dTemp = 0;
	double dTempOld = 0;
	int nMinIndex = 0;
	if(bX)
	{
		for(int i = 0; i<3; i++)
		{
			dTemp = ((double)nFilePos[i].y / 1000.) - dRefY;
			if(dTemp <= dTempOld|| i == 0) 
			{
				nMinIndex = i;
				dTempOld = dTemp;
			}
		}
		dMinDisX = ((double)nFilePos[nMinIndex].x/1000.) - dRefX; 
	}
	else
	{
		for(int i = 0; i<3; i++)
		{
			dTemp = ((double)nFilePos[i].x / 1000.) - dRefX;
			if(dTemp < dMinDisY || i == 0) 
			{
				nMinIndex = i;
				dTempOld = dTemp;
			}
		}
		dMinDisY = ((double)nFilePos[nMinIndex].y/1000.) - dRefY;
	}
	
	m_pProject->m_dRefPosX += dMinDisX; 
	m_pProject->m_dRefPosY += dMinDisY;

	m_pProject->m_nDataLoadStep = FIELD_DIVIED + SET_FID_ORIGIN;
}

void CPaneRecipeGenDataEasy::OnButtonFlipx() 
{
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}

	if(m_pProject == NULL)
		return;
	m_pProject->FlipMode(TRUE);
	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);

	DisplayRotateInfo();


	// if(m_pProject->m_nDataLoadStep & FIELD_DIVIED) //Set Ref Fid�� �Ǿ� �ִ� ��츸 
	{
		// bhlee �ּ� 2012 03 29 : puzzleuot �������� �ڵ� : �Ʒ� ����� �ٸ� ������� �����ؾ� ��
		//  if(ErrMessage(_T("Do you want to reset Ref.fiducial that flip position?"), MB_YESNO) == IDYES) 
		{
			if((m_pProject->m_nDataLoadStep & FIELD_DIVIED))
			{
				m_pProject->PuzzleOutOnlyAxisTrans();
				gDProject = *m_pProject;
			}

			m_pProject->InitialDrawRatio(cRect);

			if(m_pParent && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->InitialDrawRatio();

			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pData->InitialDrawRatio();

			//   CalRefFidFlipPos(TRUE);
		}
	}

	Invalidate(FALSE);

}

void CPaneRecipeGenDataEasy::OnButtonFlipy() 
{

	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}

	if(m_pProject == NULL)
		return;
	m_pProject->FlipMode(FALSE);
	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);

	DisplayRotateInfo();


	// if(m_pProject->m_nDataLoadStep & FIELD_DIVIED) //Set Ref Fid�� �Ǿ� �ִ� ��츸 
	{
		// bhlee �ּ� 2012 03 29 : puzzleuot �������� �ڵ� : �Ʒ� ����� �ٸ� ������� �����ؾ� ��
		//  if(ErrMessage(_T("Do you want to reset Ref.fiducial that flip position?"), MB_YESNO) == IDYES) 
		{
			if((m_pProject->m_nDataLoadStep & FIELD_DIVIED))
			{
				m_pProject->PuzzleOutOnlyAxisTrans();
				gDProject = *m_pProject;
			}

			m_pProject->InitialDrawRatio(cRect);

			if(m_pParent && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->InitialDrawRatio();

			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pData->InitialDrawRatio();

			//   CalRefFidFlipPos(TRUE);
		}
	}

	Invalidate(FALSE);
}

void CPaneRecipeGenDataEasy::OnButtonRotate() 
{
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}

	// TODO: Add your control notification handler code here
	if(m_pProject == NULL)
		return;
	m_pProject->RotateMode();
	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
	m_pProject->InitialDrawRatio(cRect);

	if(m_pParent && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew)
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->InitialDrawRatio();

	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pData->InitialDrawRatio();

	DisplayRotateInfo();
	Invalidate(FALSE);
}

void CPaneRecipeGenDataEasy::OnButtonMove() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	int nX, nY;

	nX = (int)((m_dX + 0.0001) * 1000);
	nY = (int)((m_dY + 0.0001) * 1000);

	if(m_pProject == NULL)
		return;

	CPoint umPoint;
	if(m_pProject->GetUnitPos(umPoint))
	{
		umPoint.x = nX - umPoint.x;
		umPoint.y = nY - umPoint.y;
		m_pProject->MoveUnit(umPoint.x, umPoint.y);
		m_pProject->AddMoveUnitsToUndoList();
		gDUndoRedo.MoveGlyphs(umPoint);
		m_pProject->ReCalRect();
		m_pProject->SetProjectStatusToExcellOpen();
		Invalidate(FALSE);
	}
}

void CPaneRecipeGenDataEasy::ChangePosInfo(CPoint ptPick)
{
	if(m_pProject == NULL)
		return;

	CPoint umPoint;
	umPoint = m_pProject->GetFilePos(ptPick);

	CString str;
	str.Format(_T("X : %.3f, Y : %.3f"), umPoint.x / 1000.0, umPoint.y / 1000.0);
	GetDlgItem(IDC_STC_POS)->SetWindowText(str);

	if(m_pProject->GetUnitPos(umPoint))
	{
		str.Format(_T("X : %.3f, Y : %.3f"), umPoint.x / 1000.0, umPoint.y / 1000.0);
		GetDlgItem(IDC_STC_UNIT_POS)->SetWindowText(str);
	}
	else
	{
		GetDlgItem(IDC_STC_UNIT_POS)->SetWindowText("-");
	}
}

void CPaneRecipeGenDataEasy::OnRButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_pProject == NULL)
		return;

	m_ptFidPosition.x = INT_MAX;
	
	CRect rect;
	BOOL bFidList, bSkiving;
	CPoint tempP;
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
	ClientToScreen(&point);

	BOOL bSelectField = FALSE;
	BOOL bSelectUnit = FALSE;
	BOOL bNoPoint = FALSE;
	m_nFieldIndex = -1;
	
	if(rect.PtInRect(point))
	{
		tempP.x = point.x - rect.left;
		tempP.y = point.y - rect.top;

		m_ptFidPos = tempP;

		if(IsPickUnit(tempP)) // ���õ� unit�� ������ ���콺 ��ư 
		{
			bSelectUnit = TRUE;
			bSelectField = TRUE;
		}
		else
		{
			if(m_bShowSortIndex)
			{
				if(m_pProject->IsFieldNumber(tempP, rect, m_nFieldIndex))
					bSelectField = TRUE;
				else
					bSelectField = FALSE;
			}
			else
			{
				if(!m_pProject->IsFidHoleGet(bFidList, tempP, bSkiving, FALSE))
					bNoPoint = TRUE;
				else
					m_ptFidPosition = tempP;
			}
		}
	}
	else
		return;
	
	CMenu pMenu, *pSubMenu;
	pMenu.LoadMenu(IDR_MENU_CONTEXT);

	if(!bSelectField)
	{
		pSubMenu = pMenu.GetSubMenu(1);

		// ���ÿ����� ���� Fid���� ��Ȱ��ȭ
//		pSubMenu->EnableMenuItem(IDM_SET_FIDUCIAL_MAIN, MF_GRAYED);
//		pSubMenu->EnableMenuItem(IDM_RESET_FIDUCIAL_MAIN_ONE, MF_GRAYED);
//		pSubMenu->EnableMenuItem(IDM_RESET_FIDUCIAL_MAIN_ALL, MF_GRAYED);
//		pSubMenu->EnableMenuItem(IDM_SET_FIDUCIAL_SUB, MF_GRAYED);
//		pSubMenu->EnableMenuItem(IDM_RESET_FIDUCIAL_SUB_ONE, MF_GRAYED);
//		pSubMenu->EnableMenuItem(IDM_RESET_FIDUCIAL_SUB_ALL, MF_GRAYED);
		
		if(m_bShowSortIndex)
		{
			pSubMenu->EnableMenuItem(IDM_FIDUCIAL_ADD, MF_GRAYED);
			pSubMenu->EnableMenuItem(IDM_FIDUCIAL_MOVE, MF_GRAYED);
			pSubMenu->EnableMenuItem(IDM_FIDUCIAL_DEL, MF_GRAYED);
			pSubMenu->EnableMenuItem(IDM_SET_REF_FID, MF_GRAYED);
		}
		else
		{
			if(bNoPoint)
			{
				if(m_pProject->m_bShowSelectionFid)
				{
					pSubMenu->EnableMenuItem(IDM_FIDUCIAL_ADD, MF_GRAYED);
					pSubMenu->EnableMenuItem(IDM_FIDUCIAL_MOVE, MF_GRAYED);
					pSubMenu->EnableMenuItem(IDM_FIDUCIAL_DEL, MF_GRAYED);
					pSubMenu->EnableMenuItem(IDM_SET_REF_FID, MF_GRAYED);

					// ���ÿ����� ���� Fid���� Ȱ��ȭ
//					pSubMenu->EnableMenuItem(IDM_SET_FIDUCIAL_MAIN, MF_ENABLED);
//					pSubMenu->EnableMenuItem(IDM_RESET_FIDUCIAL_MAIN_ONE, MF_ENABLED);
//					pSubMenu->EnableMenuItem(IDM_RESET_FIDUCIAL_MAIN_ALL, MF_ENABLED);
//					pSubMenu->EnableMenuItem(IDM_SET_FIDUCIAL_SUB, MF_ENABLED);
//					pSubMenu->EnableMenuItem(IDM_RESET_FIDUCIAL_SUB_ONE, MF_ENABLED);
//					pSubMenu->EnableMenuItem(IDM_RESET_FIDUCIAL_SUB_ALL, MF_ENABLED);
				}
				else
				{
					pSubMenu->EnableMenuItem(IDM_FIDUCIAL_ADD, MF_ENABLED);
					pSubMenu->EnableMenuItem(IDM_FIDUCIAL_MOVE, MF_GRAYED);
					pSubMenu->EnableMenuItem(IDM_FIDUCIAL_DEL, MF_GRAYED);
					pSubMenu->EnableMenuItem(IDM_SET_REF_FID, MF_GRAYED);	
				}
			}
			else
			{
				if(bFidList)
				{
					if(bSkiving)
					{
						pSubMenu->EnableMenuItem(IDM_FIDUCIAL_ADD, MF_GRAYED);
						pSubMenu->EnableMenuItem(IDM_FIDUCIAL_MOVE, MF_GRAYED);
						pSubMenu->EnableMenuItem(IDM_FIDUCIAL_DEL, MF_GRAYED);
						pSubMenu->EnableMenuItem(IDM_SET_REF_FID, MF_GRAYED);
					}
					else
					{
						pSubMenu->EnableMenuItem(IDM_FIDUCIAL_ADD, MF_GRAYED);
						pSubMenu->EnableMenuItem(IDM_FIDUCIAL_MOVE, MF_ENABLED);
						if(m_nUserLevel >= 2)
							pSubMenu->EnableMenuItem(IDM_FIDUCIAL_DEL, MF_ENABLED); //20140820 ejpark 
						else
							pSubMenu->EnableMenuItem(IDM_FIDUCIAL_DEL, MF_GRAYED); //20140820 ejpark 
						pSubMenu->EnableMenuItem(IDM_SET_REF_FID, MF_ENABLED);
					}
				}
				else
				{
					if(m_pProject->m_bShowSelectionFid)
					{
						pSubMenu->EnableMenuItem(IDM_FIDUCIAL_ADD, MF_GRAYED);
						pSubMenu->EnableMenuItem(IDM_FIDUCIAL_MOVE, MF_GRAYED);
						pSubMenu->EnableMenuItem(IDM_FIDUCIAL_DEL, MF_GRAYED);
						pSubMenu->EnableMenuItem(IDM_SET_REF_FID, MF_GRAYED);

						// ���ÿ����� ���� Fid���� Ȱ��ȭ
//						pSubMenu->EnableMenuItem(IDM_SET_FIDUCIAL_MAIN, MF_ENABLED);
//						pSubMenu->EnableMenuItem(IDM_RESET_FIDUCIAL_MAIN_ONE, MF_ENABLED);
//						pSubMenu->EnableMenuItem(IDM_RESET_FIDUCIAL_MAIN_ALL, MF_ENABLED);
//						pSubMenu->EnableMenuItem(IDM_SET_FIDUCIAL_SUB, MF_ENABLED);
//						pSubMenu->EnableMenuItem(IDM_RESET_FIDUCIAL_SUB_ONE, MF_ENABLED);
//						pSubMenu->EnableMenuItem(IDM_RESET_FIDUCIAL_SUB_ALL, MF_ENABLED);
					}
					else
					{
						if(bSkiving)
						{
							pSubMenu->EnableMenuItem(IDM_FIDUCIAL_ADD, MF_GRAYED);
							pSubMenu->EnableMenuItem(IDM_FIDUCIAL_MOVE, MF_GRAYED);
							pSubMenu->EnableMenuItem(IDM_FIDUCIAL_DEL, MF_GRAYED);
							pSubMenu->EnableMenuItem(IDM_SET_REF_FID, MF_GRAYED);
						}
						else
						{
							pSubMenu->EnableMenuItem(IDM_FIDUCIAL_ADD, MF_ENABLED);
							pSubMenu->EnableMenuItem(IDM_FIDUCIAL_MOVE, MF_GRAYED);
							pSubMenu->EnableMenuItem(IDM_FIDUCIAL_DEL, MF_GRAYED);
							pSubMenu->EnableMenuItem(IDM_SET_REF_FID, MF_GRAYED);
						}						
					}
				}
			}
		}
	}
	else if(bSelectUnit)
	{
		pSubMenu = pMenu.GetSubMenu(3);
		pSubMenu->EnableMenuItem(IMD_ARRAY_COPY, MF_ENABLED);
		pSubMenu->EnableMenuItem(IMD_ADD_SUBFID, MF_ENABLED);
		pSubMenu->EnableMenuItem(IMD_DEL_SUBFIDALL, MF_ENABLED);
		pSubMenu->EnableMenuItem(IMD_DISUNIFY_UNIT, MF_ENABLED);

		if(m_pProject->m_Glyphs.IsMultiSelected())
		{
			pSubMenu->EnableMenuItem(IMD_MERGE_UNIT, MF_ENABLED);
		}
		else
		{
			pSubMenu->EnableMenuItem(IMD_MERGE_UNIT, MF_GRAYED);
		}
	}
	else
	{
		if(m_bShowSortIndex)
		{
			pSubMenu = pMenu.GetSubMenu(2);
			pSubMenu->EnableMenuItem(IDM_SELECT_FIELD_ONE, MF_ENABLED);
			pSubMenu->EnableMenuItem(IDM_SELECT_FIDBLOCK, MF_ENABLED);
			pSubMenu->EnableMenuItem(IDM_SELECT_FIELD, MF_ENABLED);
			pSubMenu->EnableMenuItem(IDM_AREA_OFFSET, MF_ENABLED);
			pSubMenu->EnableMenuItem(IDM_COPY_FIELD, MF_ENABLED);

			if(m_pProject->m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX) > 4)
			{
				pSubMenu->EnableMenuItem(IDM_SET_FIDUCIAL_START, MF_ENABLED);
				pSubMenu->EnableMenuItem(IDM_SET_FIDUCIAL_CLEAR, MF_ENABLED);
			}
			else
			{
				pSubMenu->EnableMenuItem(IDM_SET_FIDUCIAL_START, MF_GRAYED);
				pSubMenu->EnableMenuItem(IDM_SET_FIDUCIAL_CLEAR, MF_GRAYED);
			}

			CString strSubMenu =_T("");
			CMenu* pPopup = pSubMenu->GetSubMenu(3);
			for(int i = 1; i <= gDProject.m_nMaxFidBlock; i++)
			{
				strSubMenu.Format("Fiducial Block %d", i);
				pPopup->InsertMenu(i,MF_POPUP, IDM_SELECT_FIDBLOCK_0 + i, (LPCTSTR)strSubMenu);
			}
			for(int i = 0; i <= gDProject.m_nMaxFidBlock; i++)
			{
				if(m_bSelectFidBlock[i])
					pPopup->CheckMenuItem(IDM_SELECT_FIDBLOCK_0 + i, MF_CHECKED);
				else
					pPopup->CheckMenuItem(IDM_SELECT_FIDBLOCK_0 + i, MF_UNCHECKED);
			}
		}
		else
			return;
	}
	pSubMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point.x, point.y, this);

	CFormView::OnRButtonUp(nFlags, point);
}

void CPaneRecipeGenDataEasy::OnSelectFieldOne()
{
	if(m_pProject == NULL)
		return;
	m_pProject->SetSelectData(m_nFieldIndex, TRUE);
	Invalidate(FALSE);
}

void CPaneRecipeGenDataEasy::OnSelectField()
{
	if(m_pProject == NULL)
		return;
	m_pProject->SetSelectData(m_nFieldIndex, FALSE);
	Invalidate(FALSE);
}

void CPaneRecipeGenDataEasy::OnSelectFidBlock(UINT nParm_control_id)
{
	if(m_pProject == NULL)
		return;
	int nFidBlock = nParm_control_id - IDM_SELECT_FIDBLOCK_0;
	m_bSelectFidBlock[nFidBlock] = !m_bSelectFidBlock[nFidBlock];
	m_pProject->SetSelectFidBlock(nFidBlock, m_bSelectFidBlock[nFidBlock]);
	Invalidate(FALSE);
}


void CPaneRecipeGenDataEasy::OnSetTableOffset()
{
	if(m_pProject == NULL)
		return;
	
	double dX, dY;
	m_pProject->GetTableOffset(m_nFieldIndex, dX, dY);
	
	CDlgTableOffset dlg;
	dlg.SetTableOffset(m_nFieldIndex, dX, dY);
	if(dlg.DoModal() == IDOK)
	{
		dlg.GetTableOffset(dX, dY);
		m_pProject->SetTableOffset(m_nFieldIndex, dX, dY);
	}
}

void CPaneRecipeGenDataEasy::OnStartFiducialSet()
{
	if(m_pProject == NULL)
		return;
	m_nStartFidIndex = m_nFieldIndex;
	
	m_pProject->DisplayUseFiducial(m_nFieldIndex);
	Invalidate(FALSE);
}

void CPaneRecipeGenDataEasy::OnClearFiducialSet()
{
	if(m_pProject == NULL)
		return;
	
	m_pProject->ClearFiducialIndex(m_nFieldIndex);
	
	ClearFiducialIndex();
	
	Invalidate(FALSE);
}

void CPaneRecipeGenDataEasy::ClearFiducialIndex()
{
	m_nStartFidIndex = -1;
	m_pProject->DisplayUseFiducial(m_nStartFidIndex);

	for(int i = 0; i < MAX_FID_BLOCK; i++)
	{
		m_bSelectFidBlock[i] = FALSE;
	}
}
/*
void CPaneRecipeGenDataEasy::OnFiducialSetMain() 
{
//	m_bSetMainFidMode = TRUE;
	m_pProject->SetFiducial(0, FALSE); // MainFid
}

void CPaneRecipeGenDataEasy::OnFiducialResetOneMain() 
{
	m_bResetOneMainFidMode = TRUE;
}

void CPaneRecipeGenDataEasy::OnFiducialResetAllMain() 
{
	if(m_pProject == NULL)
		return;
	m_pProject->ResetAllFiducial(FALSE);
	Invalidate(FALSE);
}

void CPaneRecipeGenDataEasy::OnFiducialSetSub() 
{
//	m_bSetSubFidMode = TRUE;
	m_pProject->SetFiducial(0, TRUE); // SubFid
}

void CPaneRecipeGenDataEasy::OnFiducialResetOneSub() 
{
	m_bResetOneSubFidMode = TRUE;
}

void CPaneRecipeGenDataEasy::OnFiducialResetAllSub() 
{
	if(m_pProject == NULL)
		return;
	m_pProject->ResetAllFiducial(TRUE);
	Invalidate(FALSE);
}	
*/
void CPaneRecipeGenDataEasy::OnFiducialAdd() 
{
	// TODO: Add your command handler code here
	if(m_pProject == NULL)
		return;
	if(!m_pProject->AddFiducial(m_ptFidPos, DEFAULT_FID_INDEX))
	{
		CDlgAddFiducial dlg;
		CPoint pPoint = m_pProject->GetFilePos(m_ptFidPos, TRUE); // 091230
		dlg.SetData(pPoint.x, pPoint.y);
		if(dlg.DoModal() == IDOK)
		{
			pPoint.x = (LONG)((dlg.m_dX + 0.0002) * 1000);
			pPoint.y = (LONG)((dlg.m_dY + 0.0002) * 1000);
			m_pProject->AddRandomFiducial(pPoint);
		}
		else
		{
			m_pParent->SetFocusViewer();
			return;
		}
	}

	m_pProject->ReCalRect();
	m_pProject->SetProjectStatusToExcellOpen();
	::AfxGetMainWnd()->SendMessage(UM_RESORT_AREA);
	Invalidate(FALSE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->SetData(*m_pProject);
	m_pParent->SetFocusViewer();

}

void CPaneRecipeGenDataEasy::OnFiducialDel() 
{
	// TODO: Add your command handler code here
	if(m_pProject == NULL)
		return;
	m_pProject->DelFiducial(m_ptFidPos);
	::AfxGetMainWnd()->SendMessage(UM_RESORT_AREA);
	Invalidate(FALSE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->SetData(*m_pProject);
	m_pParent->SetFocusViewer();

}

void CPaneRecipeGenDataEasy::OnFiducialMove()
{
	CDlgAddFiducial dlg;
	CPoint ptPoint = m_pProject->GetFilePos(m_ptFidPos);
	if(m_ptFidPosition.x != INT_MAX)
		ptPoint = m_ptFidPosition;
	CPoint ptMove;
	dlg.SetData(ptPoint.x, ptPoint.y);
	if(dlg.DoModal() == IDOK)
	{
		ptMove.x = (LONG)((dlg.m_dX + 0.0002) * 1000);
		ptMove.y = (LONG)((dlg.m_dY + 0.0002) * 1000);

		// 091230
		ptPoint = m_pProject->GetFilePos(m_ptFidPos, TRUE);
		CPoint ptTrans;
		ptTrans = m_pProject->GetNoAxisChangePos(ptMove);
		//
		
		m_pProject->MoveFiducial(ptPoint, ptMove);
		m_pParent->SetFocusViewer();
	}
	else
		return;

	m_pProject->ReCalRect();
	m_pProject->SetProjectStatusToExcellOpen();
	
	::AfxGetMainWnd()->SendMessage(UM_RESORT_AREA);

	Invalidate(FALSE);
}

void CPaneRecipeGenDataEasy::OnSetRefFid() 
{
	// TODO: Add your command handler code here
	if(m_pProject == NULL)
		return;
	m_pProject->OnSetRefFid(m_ptFidPos);
	::AfxGetMainWnd()->SendMessage(UM_RESORT_AREA);
	Invalidate(FALSE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->SetData(*m_pProject);
	m_pParent->SetFocusViewer();

}

BOOL CPaneRecipeGenDataEasy::IsPickToolVisible(CPoint ptPick)
{
	if(m_pProject == NULL)
		return FALSE;

	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);

	int nYstart = 5, nEndY;
	int nStartX, nEndX;
	nStartX = cRect.right - 60;
	nEndX = cRect.right - 5;
	CString strMessage;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(m_pProject->m_pToolCode[i]->m_bUseTool)
		{
			nEndY = nYstart + 18;
			if(ptPick.x <= nEndX && ptPick.x >= nStartX &&
				ptPick.y <=nEndY && ptPick.y >= nYstart)
			{
				if(m_pProject->m_pToolCode[i]->m_bVisible && i != 0)
				{
					strMessage.Format(_T("Will you deactivate tool no.%d? "),i);
					if(ErrMessage(strMessage,MB_YESNO) != IDYES)
						return TRUE;
					m_pProject->m_pToolCode[i]->m_bVisible = FALSE;
					gDProject.m_pToolCode[i]->m_bVisible = FALSE; // apply click ���� ����
				}
				else
				{
					strMessage.Format(_T("Will you activate tool no.%d? "),i);
					if(ErrMessage(strMessage,MB_YESNO) != IDYES)
						return TRUE;
					m_pProject->m_pToolCode[i]->m_bVisible = TRUE;
					gDProject.m_pToolCode[i]->m_bVisible = TRUE; // apply click ���� ����
				}
				Invalidate(FALSE);
				return TRUE;
			}

			nYstart += 20;
		}
	}

	return FALSE;
}

BOOL CPaneRecipeGenDataEasy::IsCheckPathViewMode(CPoint ptPick)
{
	if(m_pProject == NULL)
		return FALSE;
	
	if(ptPick.x <= 130 && ptPick.x >= 5 &&
		ptPick.y <=63 && ptPick.y >= 45)
	{
		m_pProject->ChangePathDrawMode();
		Invalidate(FALSE);
		return TRUE;
	}
	
	return FALSE;
}
BOOL CPaneRecipeGenDataEasy::IsCheckSelectViewMode(CPoint ptPick)
{
	if(m_pProject == NULL)
		return FALSE;

	if(ptPick.x <= 130 && ptPick.x >= 5 &&
		ptPick.y <=43 && ptPick.y >= 25)
	{
		if((m_pProject->m_nDataLoadStep & 0x0b) < FIELD_DIVIED) // 20091029
		{
			ErrMessage(IDS_DATA_FIELD_DIVIDE);
		}
		else
		{
			m_pProject->ChangeDrawMode();
			Invalidate(FALSE);
		}
		return TRUE;
	}
	
	return FALSE;
}

void CPaneRecipeGenDataEasy::DrawSelectionRect(CDC *pDC, CPoint ptPoint1, CPoint ptPoint2)
{
	CPoint ptStart;
	CPoint ptEnd;
	
	if(ptPoint1.x < ptPoint2.x)
	{
		ptStart.x = ptPoint1.x;
		ptEnd.x = ptPoint2.x;
	}
	else
	{
		ptStart.x = ptPoint2.x;
		ptEnd.x = ptPoint1.x;
	}
	
	if(ptPoint1.y < ptPoint2.y)
	{
		ptStart.y = ptPoint1.y;
		ptEnd.y = ptPoint2.y;
	}
	else
	{
		ptStart.y = ptPoint2.y;
		ptEnd.y = ptPoint1.y;
	}
	
	CRect rectRect(ptStart, ptEnd);

	m_ptDrawRectBack1 = ptStart;
	m_ptDrawRectBack2 = ptEnd;
	
	int iRopOld = pDC->SetROP2(R2_NOT);
	CBrush *pBrushOld = (CBrush *)pDC->SelectStockObject(NULL_BRUSH);
	
	pDC->Rectangle(rectRect);
	
	pDC->SetROP2(iRopOld);
	pDC->SelectObject(pBrushOld);
}

void CPaneRecipeGenDataEasy::DrawSelectionRect(CDC *pDC)
{
	CRect rectRect(m_ptDrawRectBack1, m_ptDrawRectBack2);
	
	int iRopOld = pDC->SetROP2(R2_NOT);
	CBrush *pBrushOld = (CBrush *)pDC->SelectStockObject(NULL_BRUSH);
	
	pDC->Rectangle(rectRect);
	
	pDC->SetROP2(iRopOld);
	pDC->SelectObject(pBrushOld);
}

void CPaneRecipeGenDataEasy::InitBtnControl()
{
	m_fntBtn.CreatePointFont(100, "Arial Bold");
	
	// Zoom Field
	m_btnZoomField.SetFont( &m_fntBtn );
	m_btnZoomField.SetFlat( FALSE );
	m_btnZoomField.EnableBallonToolTip();
	m_btnZoomField.SetToolTipText( _T("View All Data on the Board") );
	m_btnZoomField.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnZoomField.SetBtnCursor(IDC_HAND_1);

	// Clear select
	m_btnSelectClear.SetFont( &m_fntBtn );
	m_btnSelectClear.SetFlat( FALSE );
	m_btnSelectClear.EnableBallonToolTip();
	m_btnSelectClear.SetToolTipText( _T("Clear Selected Data") );
	m_btnSelectClear.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSelectClear.SetBtnCursor(IDC_HAND_1);

	// excellon Load
	m_btnExcellonLoad.SetFont( &m_fntBtn );
	m_btnExcellonLoad.SetFlat( FALSE );
	m_btnExcellonLoad.EnableBallonToolTip();
	m_btnExcellonLoad.SetToolTipText( _T("Open an Excellon File") );
	m_btnExcellonLoad.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnExcellonLoad.SetBtnCursor(IDC_HAND_1);

	// easymarker Load
	m_btnEasymarker.SetFont( &m_fntBtn );
	m_btnEasymarker.SetFlat( FALSE );
	m_btnEasymarker.EnableBallonToolTip();
	m_btnEasymarker.SetToolTipText( _T("Show Excellon data editor") );
	m_btnEasymarker.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnEasymarker.SetBtnCursor(IDC_HAND_1);

	// Save Selectied Excellon Data
	m_btnExcellonSave.SetFont( &m_fntBtn );
	m_btnExcellonSave.SetFlat( FALSE );
	m_btnExcellonSave.EnableBallonToolTip();
	m_btnExcellonSave.SetToolTipText( _T("Save Selected Excellon Data") );
	m_btnExcellonSave.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnExcellonSave.SetBtnCursor(IDC_HAND_1);

	// Flip X
	m_btnFlipX.SetFont( &m_fntBtn );
	m_btnFlipX.SetFlat( FALSE );
	m_btnFlipX.EnableBallonToolTip();
	m_btnFlipX.SetToolTipText( _T("Flip X") );
	m_btnFlipX.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFlipX.SetBtnCursor(IDC_HAND_1);

	// Flip Y
	m_btnFlipY.SetFont( &m_fntBtn );
	m_btnFlipY.SetFlat( FALSE );
	m_btnFlipY.EnableBallonToolTip();
	m_btnFlipY.SetToolTipText( _T("Flip Y") );
	m_btnFlipY.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFlipY.SetBtnCursor(IDC_HAND_1);

	// Rotate
	m_btnRotate.SetFont( &m_fntBtn );
	m_btnRotate.SetFlat( FALSE );
	m_btnRotate.EnableBallonToolTip();
	m_btnRotate.SetToolTipText( _T("Rotate 90 degree") );
	m_btnRotate.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRotate.SetBtnCursor(IDC_HAND_1);

	// Move to
	m_btnMove.SetFont( &m_fntBtn );
	m_btnMove.SetFlat( FALSE );
	m_btnMove.EnableBallonToolTip();
	m_btnMove.SetToolTipText( _T("Move to") );
	m_btnMove.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMove.SetBtnCursor(IDC_HAND_1);

	// Remove all data
	m_btnRemoveAlldata.SetFont( &m_fntBtn );
	m_btnRemoveAlldata.SetFlat( FALSE );
	m_btnRemoveAlldata.EnableBallonToolTip();
	m_btnRemoveAlldata.SetToolTipText( _T("Remove All Data") );
	m_btnRemoveAlldata.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRemoveAlldata.SetBtnCursor(IDC_HAND_1);

	m_edtLotIDComp.SetFont( &m_fntBtn );
	m_edtLotIDComp.SetForeColor( BLACK_COLOR );
	m_edtLotIDComp.SetBackColor( WHITE_COLOR );
//	m_edtLotIDComp.SetReceivedFlag( 1 );
	m_edtLotIDComp.SetWindowText( _T("") );

	m_ledOriginalInspection.SetFont( &m_fntBtn );
	m_ledOriginalInspection.SetImageOrg( 10, 3 );
	m_ledOriginalInspection.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ledOriginalInspection.EnableBallonToolTip();
	m_ledOriginalInspection.SetToolTipText( _T("Origin") );
	m_ledOriginalInspection.SetBtnCursor(IDC_HAND_1);

	m_ledDataHeader.SetFont( &m_fntBtn );
	m_ledDataHeader.SetImageOrg( 10, 3 );
	m_ledDataHeader.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ledDataHeader.EnableBallonToolTip();
	m_ledDataHeader.SetToolTipText( _T("Set Data Header") );
	m_ledDataHeader.SetBtnCursor(IDC_HAND_1);
	m_ledDataHeader.SetCheck(FALSE);
	
	// Show StripNo
	m_ledShowStripNo.SetFont( &m_fntBtn );
	m_ledShowStripNo.SetImage( IDB_LEDCOLOR, 15 );
	m_ledShowStripNo.Depress( m_bShowStripNo );


	m_cmbSelectComSol.SetFont( &m_fntBtn );
	m_cmbSelectComSol.SetCurSel(2);

	m_ledSelectFire.SetFont( &m_fntBtn );
	m_ledSelectFire.SetImage( IDB_LEDCOLOR, 15 );
	m_ledSelectFire.Depress( !m_bSelectFire );

	m_ledNoFindFid.SetFont( &m_fntBtn );
	m_ledNoFindFid.SetImage( IDB_LEDCOLOR, 15 );
	m_ledNoFindFid.Depress( !m_bNoFindFid );

	m_ledNoPreWork.SetFont( &m_fntBtn );
	m_ledNoPreWork.SetImage( IDB_LEDCOLOR, 15 );
	m_ledNoPreWork.Depress( !m_bNoUsePreWork );
}

void CPaneRecipeGenDataEasy::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(90, "Arial Bold");
	
	// Current Pos.
	GetDlgItem(IDC_STC_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_UNIT_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_ROTATE_INFO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_DATA_NAME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_FILM_NAME)->SetFont( &m_fntStatic );
	m_edtLotIDComp.SetFont( &m_fntStatic );

}

void CPaneRecipeGenDataEasy::OnButtonZoomAll() 
{
	// TODO: Add your control notification handler code here
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}

	if(m_pProject == NULL)
		return;

	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
	m_pProject->InitialDrawRatio(cRect);
	Invalidate(FALSE);
}

void CPaneRecipeGenDataEasy::OnButtonClear() 
{
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}
	// TODO: Add your control notification handler code here
	if(m_pProject == NULL)
		return;
	
	m_pProject->UnSelectAll();
	ClearFiducialIndex();


	Invalidate(FALSE);
}

void CPaneRecipeGenDataEasy::SetDrawRect()
{
	if(m_pProject == NULL)
		return;
	
	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
	m_pProject->InitialDrawRatio(cRect);

	if(m_pParent && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew)
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->InitialDrawRatio();
	
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pData->InitialDrawRatio();		
}

void CPaneRecipeGenDataEasy::EnableControl(BOOL bUse)
{
	m_btnSelectClear.EnableWindow(bUse);
	m_btnExcellonLoad.EnableWindow(bUse);
	m_btnEasymarker.EnableWindow(bUse);
	m_btnFlipX.EnableWindow(bUse);
	m_btnFlipY.EnableWindow(bUse);
	m_btnRotate.EnableWindow(bUse);
}

void CPaneRecipeGenDataEasy::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;
	switch(nLevel)
	{
	case 0: // Operator
//		EnableControl(FALSE);
		break;
	case 1: // Engineer
	case 2: // EO Engineer
	case 3: // Super Engineer
		EnableControl(TRUE);
		break;
	}
}

BOOL CPaneRecipeGenDataEasy::IsPickUnit(CPoint ptPoint)
{
	if(m_pProject == NULL)
		return FALSE;
	if(m_pProject->IsPickUnit(ptPoint))
		return TRUE;
	else
		return FALSE;
}

void CPaneRecipeGenDataEasy::OnArrayCopy()
{
	CDlgArrayCopy dlg;
	if(IDOK ==dlg.DoModal())
	{
		if(m_pProject == NULL)
			return;
		if(dlg.m_nCopyType == 0) // circle type
		{
			m_pProject->ArrayCopy(	dlg.m_nCopyType,
									dlg.m_nShapeType,
									(int)((dlg.m_dRadius + 0.0005) * 1000),
									(int)((dlg.m_dCenterOffsetX + 0.0005) * 1000),
									(int)((dlg.m_dCenterOffsetY + 0.0005) * 1000),
									(int)((dlg.m_dOffsetX + 0.0005) * 1000),
									(int)((dlg.m_dOffsetY + 0.0005) * 1000));
		}
		else
		{
			m_pProject->ArrayCopy(	dlg.m_nCopyType,
									dlg.m_nShapeType,
									(int)((dlg.m_dRadius + 0.0005) * 1000),
									(int)((dlg.m_dCenterOffsetX + 0.0005)),
									(int)((dlg.m_dCenterOffsetY + 0.0005)),
									(int)((dlg.m_dOffsetX + 0.0005) * 1000),
									(int)((dlg.m_dOffsetY + 0.0005) * 1000));
		}
		m_pProject->ReCalRect();
		m_pProject->SetProjectStatusToExcellOpen();
		Invalidate(FALSE);
	}
}

void CPaneRecipeGenDataEasy::OnAddSubFid()
{
	m_bAddSubFidMode = TRUE;
}

void CPaneRecipeGenDataEasy::OnDelSubFidAll()
{
	if(m_pProject == NULL)
		return;
	
	if(m_pProject->m_Glyphs.RemoveSelectUnitAllSubFiducial())
		Invalidate(FALSE);
}

void CPaneRecipeGenDataEasy::OnMergeUnit()
{
	if(m_pProject == NULL)
			return;

	if(IDYES == ErrMessage(IDS_DATA_MERGE, MB_YESNO))
	{
		gDUndoRedo.Clear();
		m_pProject->m_Glyphs.MergeUnit();
		Invalidate(FALSE);
	}
}

void CPaneRecipeGenDataEasy::OnDisunifyUnit()
{
	if(m_pProject == NULL)
			return;

	if(IDYES == ErrMessage(IDS_DATA_DISUNIFY, MB_YESNO))
	{
		m_bDisunifyMode = TRUE;
	}
}

BOOL CPaneRecipeGenDataEasy::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	if(pWnd->m_hWnd == m_edtLotIDComp.m_hWnd)
	{
		::SetCursor(::AfxGetApp()->LoadCursor(IDC_CURSOR_HRESIZE));
		return TRUE;
	}
	if(m_bDisunifyMode)
	{
		::SetCursor(::AfxGetApp()->LoadCursor(IDC_CURSOR_HRESIZE));
		return TRUE;
	}
	if(m_bViewerMoveMode)
	{
		::SetCursor(::AfxGetApp()->LoadCursor(IDC_CURSOR_HAND_RELEASE));
		return TRUE;
	}
	return CFormView::OnSetCursor(pWnd, nHitTest, message);
}

void CPaneRecipeGenDataEasy::OnButtonEasymarker()
{
	
	CString cmd = _T("c:\\EasyMarker\\easymarker");
				////////////////////////////////////////////////////////////////////////////////////////////
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	
	ZeroMemory( &si, sizeof(si) );
	si.cb = sizeof(si);
	ZeroMemory( &pi, sizeof(pi) );
	
	// Start the child process. 
	if( !CreateProcess( NULL,	// No module name (use command line). 
		(TCHAR *)(const TCHAR*) cmd,					// Command line. 
		NULL,					// Process handle not inheritable. 
		NULL,					// Thread handle not inheritable. 
		FALSE,					// Set handle inheritance to FALSE. 
		CREATE_NO_WINDOW,						// No creation flags. 
		NULL,					// Use parent's environment block. 
		NULL,					// Use parent's starting directory. 
		&si,					// Pointer to STARTUPINFO structure.
		&pi )					// Pointer to PROCESS_INFORMATION structure.
		) 
	{
	}
}

void CPaneRecipeGenDataEasy::DisplayRotateInfo()
{
	if(m_pProject == NULL)
		return;

	if(m_pProject->m_nRotateInfo == X_Y)
		GetDlgItem(IDC_STC_ROTATE_INFO)->SetWindowText("X : Y");
	else if(m_pProject->m_nRotateInfo == MX_Y)
		GetDlgItem(IDC_STC_ROTATE_INFO)->SetWindowText("-X : Y");
	else if(m_pProject->m_nRotateInfo == X_MY)
		GetDlgItem(IDC_STC_ROTATE_INFO)->SetWindowText("X : -Y");
	else if(m_pProject->m_nRotateInfo == MX_MY)
		GetDlgItem(IDC_STC_ROTATE_INFO)->SetWindowText("-X : -Y");
	else if(m_pProject->m_nRotateInfo == Y_X)
		GetDlgItem(IDC_STC_ROTATE_INFO)->SetWindowText("Y : X");
	else if(m_pProject->m_nRotateInfo == MY_X)
		GetDlgItem(IDC_STC_ROTATE_INFO)->SetWindowText("-Y : X");
	else if(m_pProject->m_nRotateInfo == Y_MX)
		GetDlgItem(IDC_STC_ROTATE_INFO)->SetWindowText("Y : -X");
	else
		GetDlgItem(IDC_STC_ROTATE_INFO)->SetWindowText("-Y : -X");
}

void CPaneRecipeGenDataEasy::SetRefFidLeftBottom(int nAxisMode)
{
	m_pProject->m_Glyphs.SetRefFidLeftBottom(nAxisMode);
}

void CPaneRecipeGenDataEasy::ResetProject()
{
	OnButtonPlt();
}
void CPaneRecipeGenDataEasy::OnCopyField()
{
	CDlgArrayCopy dlg;
	dlg.SetCopyMode(TRUE);
	if(IDOK !=dlg.DoModal())
		return;
	//copy array 
	int nRepeatX = (int)dlg.m_dCenterOffsetX;
	int nRepeatY = (int)dlg.m_dCenterOffsetY;
	
	double dX = dlg.m_dOffsetX;
	double dY = dlg.m_dOffsetY;
	
	m_pProject->FieldCopy(m_nFieldIndex, nRepeatX, nRepeatY, dX, dY);
	
	m_pProject->PuzzleOut(); //�ٵ� �ð��� �� ���� �ɸ��� �����? �̤� 
//	m_pProject->m_bArrayCopy = TRUE;

}

void CPaneRecipeGenDataEasy::MesDataFileCheck(int nCompSold)  //0 Comp, 1 Sold
{
 	UpdateData(TRUE);

 	m_strLotIDComp.Replace(_T(" "), _T(""));
  	if(0 == m_strLotIDComp.CompareNoCase(_T("")))
  	{
  		ErrMessage(_T("Please Input Lot ID"));
  		return;
  	}
	int nRet = MesDataCheck(m_strLotIDComp, nCompSold);
 	if(nRet != TRUE)
 	{
		if(nRet == 0)
			ErrMessage(_T("Data Loading Fail"));
		else if(nRet == -1)
			ErrMessage(_T("Cad Data Loading Fail"));
		else if(nRet == -2)
			ErrMessage(_T("Pen Data Loading Fail"));
		else if(nRet == -3)
			ErrMessage(_T("Project Data Loading Fail"));
			
		GetDlgItem(IDC_STC_FILM_NAME)->SetWindowText(m_strFilmName );
		GetDlgItem(IDC_STC_DATA_NAME)->SetWindowText(m_strFile );
		return;
	}
	GetDlgItem(IDC_STC_FILM_NAME)->SetWindowText(m_strFilmName );
	GetDlgItem(IDC_STC_DATA_NAME)->SetWindowText(m_strFile );
}

BOOL CPaneRecipeGenDataEasy::MesDataCheck(CString strLotID1, int nComSol)
{
	int nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();
	CString strGetManage, strGetCount, strGetLotID, strGetStatus, strGetMessage, strGetResult, strLayer, strLaserComp, strLaserSold;
	if( strcmp(strLotID1.Left(5), "Dummy") != 0 &&													   
		strcmp(strLotID1.Left(6), "Pdummy") != 0 && strcmp(strLotID1.Left(6), "Rdummy") != 0 &&
		strcmp(strLotID1.Left(6), "Bdummy") != 0 && strcmp(strLotID1.Left(6), "Tdummy") != 0 &&
		strcmp(strLotID1.Left(6), "Cdummy") != 0 && strcmp(strLotID1.Left(9), "E-M-P-T-Y") != 0)
	{


		COneClickOdbc Odbc;
		if(!Odbc.GetManageNo((LPSTR)(LPCTSTR)strLotID1))
		{
			ErrMessage(_T("Can not open DB."));
			return FALSE;
		}

		m_strProcessCode = Odbc.m_strProcessCode;
		m_strBackwardLevel = Odbc.m_strBackwardLevel;

		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCopperThick = Odbc.m_strCopperThick;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strProcessCode = Odbc.m_strProcessCode;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCustomerCode = Odbc.m_strCustomerCode;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strBackwardLevel = Odbc.m_strBackwardLevel;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strPrevProcessCode = Odbc.m_strPrevProcessCode;


		m_strFilmName = strGetManage = Odbc.m_strGetManage;
		strGetLotID = Odbc.m_strLotID;
 		strLayer = Odbc.m_strRecipeLayer;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCopperThick = Odbc.m_strCopperThick;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strProcessCode = Odbc.m_strProcessCode;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCustomerCode = Odbc.m_strCustomerCode;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strBackwardLevel = Odbc.m_strBackwardLevel;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialGroup = Odbc.m_strMaterialGroup;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialThick = Odbc.m_strMaterialThick;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strTrimFinalThick = Odbc.m_strTrimFinalThick;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLayUpCode = Odbc.m_strLayUpCode;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialMaker = Odbc.m_strMeterialMaker;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialKind = Odbc.m_strMeterialKind;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeParam = Odbc.m_strProductCount;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeID = strLotID1;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeLayer = strLayer;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipePrj = Odbc.m_strGetManage;
		//strGetManage = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipePrj;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCurrentProcess = Odbc.m_strCurrentProcess;

		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeLayer;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialThick;
		

		/*
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strFiducialSize = Odbc.m_strFiducialSize;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strProductCount = Odbc.m_strProductCount;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strHoleSize = Odbc.m_strHoleSize;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCopperThick = Odbc.m_strCopperThick;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCustomerCode = Odbc.m_strCustomerCode;
		int nProductCount = atoi(m_strProductCount);
		if( nProductCount == 0)
			nProductCount = 36;
			*/
 		if(strcmp(strGetManage, "") == 0)
 		{
 //			ErrMessage(strGetMessage);
 			return FALSE;
 		}



 		CString strFind1, strFind2,strErr;
 		
		if(nComSol == 2 || nComSol == 3)
		{

				strFind2 = FindDataNameNew2(strGetLotID, strGetManage, FALSE, m_strProcessCode, m_strBackwardLevel ); //com
				strFind1 = FindDataNameNew2(strGetLotID, strGetManage, TRUE, m_strProcessCode, m_strBackwardLevel ); //sol
	
			#ifndef __TEST__
 				if(strFind1 == "NOEXIST" || strFind1 == "")
 				{
					strErr.Format(_T("%s & %s"),strGetManage,strGetLotID  );
 					ErrMsgDlg(STDGNALM251,strErr );
 					return FALSE; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
 				}
				if(strFind2 == "NOEXIST" || strFind2 == "")
 				{
					strErr.Format(_T("%s & %s"),strGetManage,strGetLotID  );
 					ErrMsgDlg(STDGNALM251,strErr );
 					return FALSE; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
 				}
			#endif
		}
		else
		{

				strFind1 = FindDataNameNew2(strGetLotID, strGetManage, nComSol, m_strProcessCode, m_strBackwardLevel );

			#ifndef __TEST__
 				if(strFind1 == "NOEXIST" || strFind1 == "")
 				{
					strErr.Format(_T("%s & %s"),strGetManage,strGetLotID  );
 					ErrMsgDlg(STDGNALM251,strErr );
 					return FALSE; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
 				}
			#endif
		}



		BOOL bContinue = TRUE;


		CString strCompFileName = _T("");
		CString strSoldFileName = _T("");
		int nTempIndex = 0;

		nTempIndex = strFind2.ReverseFind(_T('\\'));
		strCompFileName = strFind2.Right(strFind2.GetLength() - nTempIndex - 1);
		nTempIndex = strCompFileName.ReverseFind(_T('.'));
		strCompFileName = strCompFileName.Left(nTempIndex);

		nTempIndex = strFind1.ReverseFind(_T('\\'));
		strSoldFileName = strFind1.Right(strFind2.GetLength() - nTempIndex - 1);
		nTempIndex = strSoldFileName.ReverseFind(_T('.'));
		strSoldFileName = strSoldFileName.Left(nTempIndex);



		if(gVariable.m_strBackupLaserComp.CompareNoCase(strCompFileName) !=0 ||
			gVariable.m_strBackupLaserSold.CompareNoCase(strSoldFileName) !=0 ||
			!ParameterNameCheck())
			bContinue = FALSE;

		gVariable.m_strBackupLaserComp = strCompFileName;
		gVariable.m_strBackupLaserSold = strSoldFileName;

		int nMaxIndex;
		if(nComSol == 2)
		{
			nMaxIndex = 2;
		}
		else
		{
			nMaxIndex = 1;
		}
		for(int j = 0; j < nMaxIndex; j++)
		{
//			if(bContinue)
//				break;		

			if( j == 0)
			{
		#ifdef __TEST__
				strFind1.Format(_T("%stest2.prj"), gEasyDrillerINI.m_clsDirPath.GetDataDir());
		#endif
				CString strTempFind = strFind1.Right(3);
				if(0 == strTempFind.CompareNoCase(_T("txt") ))
				{
					int nToken = strFind1.ReverseFind(_T('\\'));
					if(nToken == -1)
					{
						m_strFile = strFind1;
					}
					else
					{
						m_strFile = strFind1.Mid(nToken+1);
					}

					int nIndex = m_strFile.ReverseFind(_T('.'));
					if(nIndex == -1)
					{
						m_strFile = m_strFile;
					}
					else
					{
						m_strFile = m_strFile.Left(nIndex);
					}

					GetDlgItem(IDC_STC_FILM_NAME)->SetWindowText(m_strFilmName );
					GetDlgItem(IDC_STC_DATA_NAME)->SetWindowText(m_strFile );

					BOOL bGerber = FALSE;
					CString strExt, strTemp; 

					strTemp.Format("%s",strFind1);
					strExt = strTemp.Right(3);

					if(strExt == "gbr")
						bGerber = TRUE;

					ClearFiducialIndex();

					CDlgOpenExcellon dlgExcellon;
					if(bGerber)
					{
						if(IDOK != dlgExcellon.DoModal())
						{
							SetFocus();
							return CAD_DATA_LOADING_FAIL;
						}

					}
					// ����Recipe���� 1st Fiducial�� Parameter�� �⺻������ �̿��ϱ� ���� ���� ����
					int nCount = m_pProject->m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);
					if(nCount > 0)
					{
						m_pProject->m_bSaveRefFidData = TRUE;
						LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, 0);

						memset( m_pProject->m_pRefFidData, 0, sizeof(FID_DATA) );

						m_pProject->m_nMaxFidBlock = 0; // 20111124 bskim default fid block = 0
						m_pProject->m_pRefFidData->nCam = pFidData->nCam;
						m_pProject->m_pRefFidData->dOffsetZ = pFidData->dOffsetZ;
						m_pProject->m_pRefFidData->nFidType = pFidData->nFidType;
						m_pProject->m_pRefFidData->nToolNo = pFidData->nToolNo;
						m_pProject->m_pRefFidData->sVisInfo.dAspectRatio = pFidData->sVisInfo.dAspectRatio;
						m_pProject->m_pRefFidData->sVisInfo.dScoreAngle = pFidData->sVisInfo.dScoreAngle;
						m_pProject->m_pRefFidData->sVisInfo.dScoreSize = pFidData->sVisInfo.dScoreSize;
						m_pProject->m_pRefFidData->sVisInfo.dSizeA = pFidData->sVisInfo.dSizeA;
						m_pProject->m_pRefFidData->sVisInfo.dSizeB = pFidData->sVisInfo.dSizeB;
						m_pProject->m_pRefFidData->sVisInfo.dSizeC = pFidData->sVisInfo.dSizeC;
						m_pProject->m_pRefFidData->sVisInfo.nModelType = pFidData->sVisInfo.nModelType;
						m_pProject->m_pRefFidData->sVisInfo.nPolarity = pFidData->sVisInfo.nPolarity;

						for(int i=0; i<4; i++)
						{
							m_pProject->m_pRefFidData->sVisInfo.dBrightness[i] = pFidData->sVisInfo.dBrightness[i];
							m_pProject->m_pRefFidData->sVisInfo.dContrast[i] = pFidData->sVisInfo.dContrast[i];
							m_pProject->m_pRefFidData->sVisInfo.nCoaxial[i] = pFidData->sVisInfo.nCoaxial[i];
							m_pProject->m_pRefFidData->sVisInfo.nRing[i] = pFidData->sVisInfo.nRing[i];
						}
					}
					else
						m_pProject->m_bSaveRefFidData = FALSE;



					CString strPath, strMessage;
					GerberReader gerberReader;
					ExcellonReader excelReader;
					//	GlyphExcellon myExcellon;
					m_nG821Count =0;
					if(bGerber)
					{
						OnButtonPlt(); // ���� ������ ��� ����
						CProgressWnd wndProgress(NULL, _T("Data Loading"), TRUE);
						wndProgress.SetRange(0, 0);
						wndProgress.SetText(_T("Data Loading"));
						gerberReader.Read(strFind1, dlgExcellon.m_nTZS, dlgExcellon.m_nUnit, &m_pProject->m_Glyphs, m_pProject,1 /*dlgExcellon.m_nDivide*/);
					}
					else
					{
						if(m_bHeaderReadComplete)
						{
							excelReader.HeaderRead(strFind1, &m_pProject->m_Glyphs, m_pProject, m_bHeaderReadComplete, m_nG821Count);
						}

						if(gDProject.m_bDataHeader)
						{
							if(IDOK != excelReader.m_dlgExcellon.DoModal())
							{
								SetFocus();
								m_bHeaderReadComplete = TRUE;
								return CAD_DATA_LOADING_FAIL;
							}
						}

						if(!m_bHeaderReadComplete)
						{
							OnButtonPlt(); // ���� ������ ��� ����
							CProgressWnd wndProgress(NULL, _T("Data Loading"), TRUE);
							wndProgress.SetRange(0, 0);
							wndProgress.SetText(_T("Data Loading "));
							excelReader.Read(strFind1, excelReader.m_dlgExcellon.m_nTZS, excelReader.m_dlgExcellon.m_nUnit,
								&m_pProject->m_Glyphs, m_pProject, excelReader.m_dlgExcellon.m_nLineNo, excelReader.m_dlgExcellon.m_nLineDistance,
								excelReader.m_dlgExcellon.m_bZigZag, excelReader.m_dlgExcellon.m_nLineExtend, m_bHeaderReadComplete, m_nG821Count);
						}

					}
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nCurrentLotCount = 0;


					{
						::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER + DO_SCANNER));
						CString strFile, strLog;
						strFile.Format(_T("PreWork"));
						strLog.Format(_T("AnyDo (Excellon Change) : P + S"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					}

					strcpy_s(m_pProject->m_szTempFileName, strFind1);
					strcpy_s(gDProject.m_szTempFileName, strFind1);

					::AfxGetMainWnd()->SendMessage(UM_CHANGE_DATAFILE, FALSE, reinterpret_cast<WPARAM>(&strFind1));
					m_pProject->RemoveAreaList();

					CPoint nptRefFid; // 20091029
					int nSetOrigin = (m_pProject->m_nDataLoadStep & SET_FID_ORIGIN);
					int nX, nY;
					if(FALSE == m_pProject->m_Glyphs.GetRefFidPos(nX, nY))
					{
						nptRefFid.x = nptRefFid.y =INT_MAX;
					}
					else
					{
						nptRefFid.x = nX;
						nptRefFid.y = nY;
					}

					if(nptRefFid.x == INT_MAX || nptRefFid != m_pProject->m_nptRefFidPos)
						nSetOrigin = 0;

					m_pProject->m_nDataLoadStep = LOAD_EXCELLON + nSetOrigin;

					// for samsung HDI
					CString strFile = (CString)gDProject.m_szFileName;
					nIndex = strFile.ReverseFind(_T('_')); // �ִ����� ��� LOT123A_123.txt�� LOT123A.txt�� �ü��� ����
					if(nIndex > 0) 
					{
						strTemp = strFile.Left(nIndex);
					}
					else
					{
						nIndex = strFile.ReverseFind(_T('.')); // �ִ��� LOT123A.txt�� ��ǰ�� LOT1234.txt�� ����
						strTemp = strFile.Left(nIndex);
					}

					//TCHAR chChar[2] = {0,};
					//strcpy_s(chChar, strTemp.Right(1));

					//if(gSystemINI.m_sHardWare.nExcellonOpenAxis < PX_PY || gSystemINI.m_sHardWare.nExcellonOpenAxis > NY_NX)
					//{
					//	if(chChar[0] >= 48 && chChar[0] <= 57) // ���ڴ� ��ǰ��
					//	{
					//		m_pProject->m_nAxisMode = MY_X;
					//		m_pProject->m_nRotateInfo = MY_X;
					//	}
					//	else if( (chChar[0] >= 65 && chChar[0] <= 90) || (chChar[0] >= 97 && chChar[0] <= 122) ) // �����ڴ� �ִ���
					//	{
					//		m_pProject->m_nAxisMode = Y_X;
					//		m_pProject->m_nRotateInfo = Y_X;
					//	}
					//	else
					//	{
					//		m_pProject->m_nAxisMode = X_Y;
					//		m_pProject->m_nRotateInfo = X_Y;
					//	}
					//}
					//else
					//{
					//	m_pProject->m_nAxisMode = gSystemINI.m_sHardWare.nExcellonOpenAxis;
					//	m_pProject->m_nRotateInfo = gSystemINI.m_sHardWare.nExcellonOpenAxis;
					//}

					// for Kunsan Lavia

					int nIndex2 = strFind1.ReverseFind(_T('\\')); 
					strTemp = strFind1.Right(strFind1.GetLength() - nIndex2 - 1);
	
				//	nIndex = strFile.ReverseFind(_T('.'));
				//	strTemp = strFile.Left(nIndex);
	

					TCHAR chChar[10] = {0,};
					strcpy_s(chChar, strTemp.Left(9));

					//if(gSystemINI.m_sHardWare.nExcellonOpenAxis < PX_PY || gSystemINI.m_sHardWare.nExcellonOpenAxis > NY_NX)
					{
						if(chChar[7] != '_')
						{
							if(chChar[7] >= 48 && chChar[7] <= 57) // ���ڴ� ��ǰ��
							{
								m_pProject->m_nAxisMode = X_Y;
								m_pProject->m_nRotateInfo = X_Y;
							}
							else if( (chChar[7] >= 65 && chChar[7] <= 90) || (chChar[7] >= 97 && chChar[7] <= 122) ) // �����ڴ� �ִ���
							{
								m_pProject->m_nAxisMode = MX_Y;
								m_pProject->m_nRotateInfo = MX_Y;
							}
							else
							{
								m_pProject->m_nAxisMode = X_Y;
								m_pProject->m_nRotateInfo = X_Y;
							}
						}
						else
						{
							if(chChar[8] >= 48 && chChar[8] <= 57) // ���ڴ� ��ǰ��
							{
								m_pProject->m_nAxisMode = X_Y;
								m_pProject->m_nRotateInfo = X_Y;
							}
							else if( (chChar[8] >= 65 && chChar[8] <= 90) || (chChar[8] >= 97 && chChar[8] <= 122) ) // �����ڴ� �ִ���
							{
								m_pProject->m_nAxisMode = MX_Y;
								m_pProject->m_nRotateInfo = MX_Y;
							}
							else
							{
								m_pProject->m_nAxisMode = X_Y;
								m_pProject->m_nRotateInfo = X_Y;
							}
						}
		
					}
					/*else
					{
						m_pProject->m_nAxisMode = gSystemINI.m_sHardWare.nExcellonOpenAxis;
						m_pProject->m_nRotateInfo = gSystemINI.m_sHardWare.nExcellonOpenAxis;
					}*/

					// for LG
					//	m_pProject->m_nAxisMode = X_Y;
					//	m_pProject->m_nRotateInfo = X_Y;

					// �����ϴ�Fid�� RefFid ����
					SetRefFidLeftBottom(m_pProject->m_nAxisMode);

					DisplayRotateInfo();
					m_pParent->m_pParamNew->SetData(*m_pProject);// >m_pParam->SetData(FALSE, *m_pProject);

					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->SetData(*m_pProject);
					m_pParent->SetWindowForSkiving(TRUE);
					m_pProject->SetMinMaxRect();

					CRect cRect;
					GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
					m_pProject->InitialDrawRatio(cRect);
					SetFocus();

					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->ResetScale();

					if(m_pParent && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew)
					{
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->InitialDrawRatio();
					}
					strMessage.Format(_T("Data file ( %s ) is opend"), strFind1);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), NULL);
					m_bExcellonChange = TRUE;

					Invalidate(FALSE);
				}
				else
				{
					CString strTemp, str, strMessage;
					theDlg->SetFileOpen(FALSE);

					{
						::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER + DO_SCANNER));
						CString strFile, strLog;
						strFile.Format(_T("PreWork"));
						strLog.Format(_T("AnyDo (OnButtonPrjOpen 2) : P + S"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					}

					if(FALSE == theDlg->OpenProject(strFind1))
					{
						ErrMsgDlg(STDGNALM113, strFind1);
						return PRJ_DATA_LOADING_FAIL; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
					}

					theDlg->SetPrjName( strFind1 );
		
					::AfxGetMainWnd()->SendMessage(UM_CHANGE_DATAFILE, TRUE);
				
					strcpy_s(gDProject.m_szProjectName, strFind1);
					strcpy_s(gDProject.m_szTempFileName, gDProject.m_szFileName);

					strMessage.Format(_T("Project ( %s ) is opend "), strFind1);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), NULL);
		
					::AfxGetApp()->WriteProfileString(_T("Files"), _T("Recent File"), strFind1);
		
					theDlg->SetFileOpen(TRUE);

					HVision* pVision =gDeviceFactory.GetVision();
					str.Format(_T("%s"),gDProject.m_szVisionProjectName);
					int nlen, n = str.Find("D:");
					nlen = strlen(str);
					if(n != -1) //char finding ���ϸ� return = -1
					{
						strTemp = str.Mid(n, nlen-n);
 						memset(gDProject.m_szVisionProjectName, 0 , sizeof(gDProject.m_szVisionProjectName));
						strcpy_s(gDProject.m_szVisionProjectName, strTemp);

						nlen = strlen(gDProject.m_szVisionProjectName);
						if(nlen > 0)
						{
							if(pVision->LoadProject(strTemp))
							{
								theDlg->m_pManualControl->m_pVision->m_edtProjectPath.SetWindowText((LPCTSTR)strTemp);
								theDlg->m_pRecipeGen->m_pFiducialNew->m_edtPath.SetWindowText((LPCTSTR)strTemp);
							}
						}
					}
					else
					{
						memset(&gDProject.m_szVisionProjectName, 0 , sizeof(gDProject.m_szVisionProjectName));
						theDlg->m_pManualControl->m_pVision->m_edtProjectPath.SetWindowText("");
						theDlg->m_pRecipeGen->m_pFiducialNew->m_edtPath.SetWindowText("");
					}

					theDlg->m_pAutoRun->CalculateAvgScale();

					theDlg->m_pAutoRun->SetPreworkInfo();

					time_t	timeEnd;
					time(&timeEnd);
					gOPCParam.nSwitchUpdateTime[N_SWITCH_PRJ] = (int)timeEnd;
					((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_OPC_STATUS, N_SWITCH, N_SWITCH_PRJ);
				}
			}
			else
			{
		#ifdef __TEST__
				strFind2.Format(_T("%stest.prj"), gEasyDrillerINI.m_clsDirPath.GetDataDir());
		#endif
				CString strTempFind = strFind2.Right(3);
				if(0 == strTempFind.CompareNoCase(_T("txt") ))
				{
					int nToken = strFind2.ReverseFind(_T('\\'));
					if(nToken == -1)
					{
						m_strFile = strFind2;
					}
					else
					{
						m_strFile = strFind2.Mid(nToken+1);
					}

					int nIndex = m_strFile.ReverseFind(_T('.'));
					if(nIndex == -1)
					{
						m_strFile = m_strFile;
					}
					else
					{
						m_strFile = m_strFile.Left(nIndex);
					}

					GetDlgItem(IDC_STC_FILM_NAME)->SetWindowText(m_strFilmName );
					GetDlgItem(IDC_STC_DATA_NAME)->SetWindowText(m_strFile );

					BOOL bGerber = FALSE;
					CString strExt, strTemp; 

					strTemp.Format("%s",strFind2);
					strExt = strTemp.Right(3);

					if(strExt == "gbr")
						bGerber = TRUE;

					ClearFiducialIndex();

					CDlgOpenExcellon dlgExcellon;
					if(bGerber)
					{
						if(IDOK != dlgExcellon.DoModal())
						{
							SetFocus();
							return CAD_DATA_LOADING_FAIL;
						}

					}
					// ����Recipe���� 1st Fiducial�� Parameter�� �⺻������ �̿��ϱ� ���� ���� ����
					int nCount = m_pProject->m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);
					if(nCount > 0)
					{
						m_pProject->m_bSaveRefFidData = TRUE;
						LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, 0);

						memset( m_pProject->m_pRefFidData, 0, sizeof(FID_DATA) );

						m_pProject->m_nMaxFidBlock = 0; // 20111124 bskim default fid block = 0
						m_pProject->m_pRefFidData->nCam = pFidData->nCam;
						m_pProject->m_pRefFidData->dOffsetZ = pFidData->dOffsetZ;
						m_pProject->m_pRefFidData->nFidType = pFidData->nFidType;
						m_pProject->m_pRefFidData->nToolNo = pFidData->nToolNo;
						m_pProject->m_pRefFidData->sVisInfo.dAspectRatio = pFidData->sVisInfo.dAspectRatio;
						m_pProject->m_pRefFidData->sVisInfo.dScoreAngle = pFidData->sVisInfo.dScoreAngle;
						m_pProject->m_pRefFidData->sVisInfo.dScoreSize = pFidData->sVisInfo.dScoreSize;
						m_pProject->m_pRefFidData->sVisInfo.dSizeA = pFidData->sVisInfo.dSizeA;
						m_pProject->m_pRefFidData->sVisInfo.dSizeB = pFidData->sVisInfo.dSizeB;
						m_pProject->m_pRefFidData->sVisInfo.dSizeC = pFidData->sVisInfo.dSizeC;
						m_pProject->m_pRefFidData->sVisInfo.nModelType = pFidData->sVisInfo.nModelType;
						m_pProject->m_pRefFidData->sVisInfo.nPolarity = pFidData->sVisInfo.nPolarity;

						for(int i=0; i<4; i++)
						{
							m_pProject->m_pRefFidData->sVisInfo.dBrightness[i] = pFidData->sVisInfo.dBrightness[i];
							m_pProject->m_pRefFidData->sVisInfo.dContrast[i] = pFidData->sVisInfo.dContrast[i];
							m_pProject->m_pRefFidData->sVisInfo.nCoaxial[i] = pFidData->sVisInfo.nCoaxial[i];
							m_pProject->m_pRefFidData->sVisInfo.nRing[i] = pFidData->sVisInfo.nRing[i];
						}
					}
					else
						m_pProject->m_bSaveRefFidData = FALSE;



					CString strPath, strMessage;
					GerberReader gerberReader;
					ExcellonReader excelReader;
					//	GlyphExcellon myExcellon;
					m_nG821Count = 0;
					if(bGerber)
					{
						OnButtonPlt(); // ���� ������ ��� ����
						CProgressWnd wndProgress(NULL, _T("Data Loading"), TRUE);
						wndProgress.SetRange(0, 0);
						wndProgress.SetText(_T("Data Loading"));
						gerberReader.Read(strFind2, dlgExcellon.m_nTZS, dlgExcellon.m_nUnit, &m_pProject->m_Glyphs, m_pProject,1 /*dlgExcellon.m_nDivide*/);
					}
					else
					{
						if(m_bHeaderReadComplete)
						{
							excelReader.HeaderRead(strFind2, &m_pProject->m_Glyphs, m_pProject, m_bHeaderReadComplete, m_nG821Count);
						}

						if(gDProject.m_bDataHeader)
						{
							if(IDOK != excelReader.m_dlgExcellon.DoModal())
							{
								SetFocus();
								m_bHeaderReadComplete = TRUE;
								return CAD_DATA_LOADING_FAIL;
							}
						}

						if(!m_bHeaderReadComplete)
						{
							OnButtonPlt(); // ���� ������ ��� ����
							CProgressWnd wndProgress(NULL, _T("Data Loading"), TRUE);
							wndProgress.SetRange(0, 0);
							wndProgress.SetText(_T("Data Loading "));
							excelReader.Read(strFind2, excelReader.m_dlgExcellon.m_nTZS, excelReader.m_dlgExcellon.m_nUnit,
								&m_pProject->m_Glyphs, m_pProject, excelReader.m_dlgExcellon.m_nLineNo, excelReader.m_dlgExcellon.m_nLineDistance,
								excelReader.m_dlgExcellon.m_bZigZag, excelReader.m_dlgExcellon.m_nLineExtend, m_bHeaderReadComplete, m_nG821Count);
						}

					}
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nCurrentLotCount = 0;


					{
						::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER + DO_SCANNER));
						CString strFile, strLog;
						strFile.Format(_T("PreWork"));
						strLog.Format(_T("AnyDo (Excellon Change) : P + S"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					}

					strcpy_s(m_pProject->m_szTempFileName, strFind2);
					strcpy_s(gDProject.m_szTempFileName, strFind2);

					::AfxGetMainWnd()->SendMessage(UM_CHANGE_DATAFILE, FALSE, reinterpret_cast<WPARAM>(&strFind2));
					m_pProject->RemoveAreaList();

					CPoint nptRefFid; // 20091029
					int nSetOrigin = (m_pProject->m_nDataLoadStep & SET_FID_ORIGIN);
					int nX, nY;
					if(FALSE == m_pProject->m_Glyphs.GetRefFidPos(nX, nY))
					{
						nptRefFid.x = nptRefFid.y =INT_MAX;
					}
					else
					{
						nptRefFid.x = nX;
						nptRefFid.y = nY;
					}

					if(nptRefFid.x == INT_MAX || nptRefFid != m_pProject->m_nptRefFidPos)
						nSetOrigin = 0;

					m_pProject->m_nDataLoadStep = LOAD_EXCELLON + nSetOrigin;

					// for samsung HDI
					CString strFile = (CString)gDProject.m_szFileName;
					nIndex = strFile.ReverseFind(_T('_')); // �ִ����� ��� LOT123A_123.txt�� LOT123A.txt�� �ü��� ����
					if(nIndex > 0) 
					{
						strTemp = strFile.Left(nIndex);
					}
					else
					{
						nIndex = strFile.ReverseFind(_T('.')); // �ִ��� LOT123A.txt�� ��ǰ�� LOT1234.txt�� ����
						strTemp = strFile.Left(nIndex);
					}

					//TCHAR chChar[2] = {0,};
					//strcpy_s(chChar, strTemp.Right(1));

					//if(gSystemINI.m_sHardWare.nExcellonOpenAxis < PX_PY || gSystemINI.m_sHardWare.nExcellonOpenAxis > NY_NX)
					//{
					//	if(chChar[0] >= 48 && chChar[0] <= 57) // ���ڴ� ��ǰ��
					//	{
					//		m_pProject->m_nAxisMode = MY_X;
					//		m_pProject->m_nRotateInfo = MY_X;
					//	}
					//	else if( (chChar[0] >= 65 && chChar[0] <= 90) || (chChar[0] >= 97 && chChar[0] <= 122) ) // �����ڴ� �ִ���
					//	{
					//		m_pProject->m_nAxisMode = Y_X;
					//		m_pProject->m_nRotateInfo = Y_X;
					//	}
					//	else
					//	{
					//		m_pProject->m_nAxisMode = X_Y;
					//		m_pProject->m_nRotateInfo = X_Y;
					//	}
					//}
					//else
					//{
					//	m_pProject->m_nAxisMode = gSystemINI.m_sHardWare.nExcellonOpenAxis;
					//	m_pProject->m_nRotateInfo = gSystemINI.m_sHardWare.nExcellonOpenAxis;
					//}

					// for Kunsan Lavia

					int nIndex2 = strFind2.ReverseFind(_T('\\')); 
					strTemp = strFind2.Right(strFind2.GetLength() - nIndex2 - 1);
	
				//	nIndex = strFile.ReverseFind(_T('.'));
				//	strTemp = strFile.Left(nIndex);
	

					TCHAR chChar[10] = {0,};
					strcpy_s(chChar, strTemp.Left(9));

					//if(gSystemINI.m_sHardWare.nExcellonOpenAxis < PX_PY || gSystemINI.m_sHardWare.nExcellonOpenAxis > NY_NX)
					{
						if(chChar[7] != '_')
						{
							if(chChar[7] >= 48 && chChar[7] <= 57) // ���ڴ� ��ǰ��
							{
								m_pProject->m_nAxisMode = X_Y;
								m_pProject->m_nRotateInfo = X_Y;
							}
							else if( (chChar[7] >= 65 && chChar[7] <= 90) || (chChar[7] >= 97 && chChar[7] <= 122) ) // �����ڴ� �ִ���
							{
								m_pProject->m_nAxisMode = MX_Y;
								m_pProject->m_nRotateInfo = MX_Y;
							}
							else
							{
								m_pProject->m_nAxisMode = X_Y;
								m_pProject->m_nRotateInfo = X_Y;
							}
						}
						else
						{
							if(chChar[8] >= 48 && chChar[8] <= 57) // ���ڴ� ��ǰ��
							{
								m_pProject->m_nAxisMode = X_Y;
								m_pProject->m_nRotateInfo = X_Y;
							}
							else if( (chChar[8] >= 65 && chChar[8] <= 90) || (chChar[8] >= 97 && chChar[8] <= 122) ) // �����ڴ� �ִ���
							{
								m_pProject->m_nAxisMode = MX_Y;
								m_pProject->m_nRotateInfo = MX_Y;
							}
							else
							{
								m_pProject->m_nAxisMode = X_Y;
								m_pProject->m_nRotateInfo = X_Y;
							}
						}
		
					}
					/*else
					{
						m_pProject->m_nAxisMode = gSystemINI.m_sHardWare.nExcellonOpenAxis;
						m_pProject->m_nRotateInfo = gSystemINI.m_sHardWare.nExcellonOpenAxis;
					}*/

					// for LG
					//	m_pProject->m_nAxisMode = X_Y;
					//	m_pProject->m_nRotateInfo = X_Y;

					// �����ϴ�Fid�� RefFid ����
					SetRefFidLeftBottom(m_pProject->m_nAxisMode);

					DisplayRotateInfo();
					m_pParent->m_pParamNew->SetData(*m_pProject);// >m_pParam->SetData(FALSE, *m_pProject);

					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->SetData(*m_pProject);
					m_pParent->SetWindowForSkiving(TRUE);
					m_pProject->SetMinMaxRect();

					CRect cRect;
					GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
					m_pProject->InitialDrawRatio(cRect);
					SetFocus();

					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->ResetScale();

					if(m_pParent && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew)
					{
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->InitialDrawRatio();
					}
					strMessage.Format(_T("Data file ( %s ) is opend"), strFind2);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), NULL);
					m_bExcellonChange = TRUE;

					Invalidate(FALSE);
				}
				else
				{
					CString strTemp, str, strMessage;
					theDlg->SetFileOpen(FALSE);

					{
						::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER + DO_SCANNER));
						CString strFile, strLog;
						strFile.Format(_T("PreWork"));
						strLog.Format(_T("AnyDo (OnButtonPrjOpen 2) : P + S"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					}

					if(FALSE == theDlg->OpenProject(strFind2))
					{
						ErrMsgDlg(STDGNALM113, strFind2);
						return PRJ_DATA_LOADING_FAIL; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
					}

					theDlg->SetPrjName( strFind2 );
		
					::AfxGetMainWnd()->SendMessage(UM_CHANGE_DATAFILE, TRUE);
				
					strcpy_s(gDProject.m_szProjectName, strFind2);
					strcpy_s(gDProject.m_szTempFileName, gDProject.m_szFileName);

					strMessage.Format(_T("Project ( %s ) is opend "), strFind2);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), NULL);
		
					::AfxGetApp()->WriteProfileString(_T("Files"), _T("Recent File"), strFind2);
		
					theDlg->SetFileOpen(TRUE);

					HVision* pVision =gDeviceFactory.GetVision();
					str.Format(_T("%s"),gDProject.m_szVisionProjectName);
					int nlen, n = str.Find("D:");
					nlen = strlen(str);
					if(n != -1) //char finding ���ϸ� return = -1
					{
						strTemp = str.Mid(n, nlen-n);
 						memset(gDProject.m_szVisionProjectName, 0 , sizeof(gDProject.m_szVisionProjectName));
						strcpy_s(gDProject.m_szVisionProjectName, strTemp);

						nlen = strlen(gDProject.m_szVisionProjectName);
						if(nlen > 0)
						{
							if(pVision->LoadProject(strTemp))
							{
								theDlg->m_pManualControl->m_pVision->m_edtProjectPath.SetWindowText((LPCTSTR)strTemp);
								theDlg->m_pRecipeGen->m_pFiducialNew->m_edtPath.SetWindowText((LPCTSTR)strTemp);
							}
						}
					}
					else
					{
						memset(&gDProject.m_szVisionProjectName, 0 , sizeof(gDProject.m_szVisionProjectName));
						theDlg->m_pManualControl->m_pVision->m_edtProjectPath.SetWindowText("");
						theDlg->m_pRecipeGen->m_pFiducialNew->m_edtPath.SetWindowText("");
					}

					theDlg->m_pAutoRun->CalculateAvgScale();

					theDlg->m_pAutoRun->SetPreworkInfo();

					time_t	timeEnd;
					time(&timeEnd);
					gOPCParam.nSwitchUpdateTime[N_SWITCH_PRJ] = (int)timeEnd;
					((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_OPC_STATUS, N_SWITCH, N_SWITCH_PRJ);
				}
			}
			if(nComSol == 2)
			{
				if( j ==0)
				{
					CString strTempFind = strFind1.Right(3);
					if(	SetValue(1, strTempFind) == FALSE)
					{
						return PEN_DATA_LOADING_FAIL;
					}
				}
				else
				{
					CString strTempFind = strFind2.Right(3);
					if(	SetValue(0, strTempFind) == FALSE)
					{
						return PEN_DATA_LOADING_FAIL;
					}
				}
			}
			else
			{
				CString strTempFind = strFind1.Right(3);
				if(	SetValue(nComSol, strTempFind) == FALSE)
				{
					return PEN_DATA_LOADING_FAIL;
				}
			}
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGenSub->OnButtonPrjSave2();
		}
 	}
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGenSub->OnButtonPrjApply();

	strcpy_s(gDProject.m_szLotId , strGetLotID);
	strcpy_s(m_pProject->m_szLotId , strGetLotID);

	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->ResetLotCountAndData();

//	if(!m_bOriginalInspection)
	InputScheduleInfo(nComSol);

	SetOriginalInspection();

	return TRUE;
}

CString CPaneRecipeGenDataEasy::FindDataName(CString strLotID, CString strManager, CString strProductLayer, int nComSol)
{
	CString strResult;
	int nIndex = strManager.Find(_T('-'));
	
	if(nIndex == -1)
	{
		ErrMessage(_T("DB Admin numbers are not correct..\r\n( correct is : XXX-XX... )"));
		return "NOEXIST";
	}
	
	// m_strLot2�� 133-877-9T�̶�� �Ѵٸ�,
	// m_strManage = 1X8779T�� �ȴ�
	// "133"���� �ڿ� 2�ڸ� "33"�� "X"�� ��ȯ�ϸ� ��
	
	CString strTemp = strManager.Left(nIndex).Mid(1);
	int nNum = atoi(strTemp);
	
	if(nNum < 10)
		strTemp.Format(_T("%d"), nNum);
	else
		strTemp.Format(_T("%c"), nNum+55);
	
	strResult = strManager.Left(1) + strTemp;
	
	CString strTemp2= strManager.Mid(nIndex+1);
	
	int nIndexCount = 0;
	while(TRUE)
	{
		if(nIndexCount == 2)
			break;
		nIndex = strTemp2.Find(_T('-'));
		if(nIndex < 1)
		{
			strResult += strTemp2;
			break;
		}
		strResult += strTemp2.Left(nIndex);
		strTemp2 = strTemp2.Mid(nIndex+1);
		nIndexCount++;
	}
	
	CString strLayer = strManager.Right(2);
	int nLayer = atoi(strLayer);

	CString  strFilePath = _T("");
	CString  strFilePathSecond = _T("");
	char szFilter[9][50];
	char szFilterSecond[9][50];
	memset(szFilter, 0, sizeof(szFilter));
	memset(szFilterSecond, 0, sizeof(szFilterSecond));
	CFileFind find;
	int nFind=0;
	BOOL bExist = FALSE;
	BOOL bExistSecond = FALSE;
	strFilePath.Empty();
	int nLen = strManager.GetLength();

	CString strTempLotID = strLotID.Right(6);

	if(nLen == 10) // ����1�ڸ�+����8�ڸ� ����
	{
		sprintf(szFilter[0],_T("%s_1_%s"), strResult, strTempLotID); 
		sprintf(szFilter[1],_T("%s_A_%s"), strResult, strTempLotID);

		sprintf(szFilterSecond[0],_T("%s1_%s"), strResult, strTempLotID); 
		sprintf(szFilterSecond[1],_T("%sA_%s"), strResult, strTempLotID);
		
		sprintf(szFilter[2],_T("%s_1"), strResult); 
		sprintf(szFilter[3],_T("%s_A"), strResult);

		sprintf(szFilterSecond[2],_T("%s1"), strResult); 
		sprintf(szFilterSecond[3],_T("%sA"), strResult);
		
		if(nComSol == 0) // com 
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
					strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
					{
						strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						bExist = find.FindFile((LPCTSTR)strFilePath);
						bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
						if(bExist)
							return strFilePath;
						else if(bExistSecond)
							return strFilePathSecond;
						else
							return "NOEXIST";
					}
				}
			}
			
				
		}
		else
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
					strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
					{
						strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						bExist = find.FindFile((LPCTSTR)strFilePath);
						bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
						if(bExist)
							return strFilePath;
						else if(bExistSecond)
							return strFilePathSecond;
						else
							return "NOEXIST";
					}
				}
			}
		}
	}
	else if(nLen == 13) // ����1�ڸ�+����10�ڸ� ����
	{
		int nProductLayer = atoi(strProductLayer);
		if(nComSol == 0) // com 
		{
			sprintf(szFilter[0],_T("%s_3"), strResult); 
			sprintf(szFilter[1],_T("%s_5"), strResult);
			sprintf(szFilter[2],_T("%s_7"), strResult); 
			sprintf(szFilter[3],_T("%s_9"), strResult);
			sprintf(szFilter[4],_T("%s_11"), strResult);
			sprintf(szFilter[5],_T("%s_13"), strResult);
			sprintf(szFilter[6],_T("%s_15"), strResult);
			sprintf(szFilter[7],_T("%s_17"), strResult);

			sprintf(szFilterSecond[0],_T("%s3"), strResult); 
			sprintf(szFilterSecond[1],_T("%s5"), strResult);
			sprintf(szFilterSecond[2],_T("%s7"), strResult); 
			sprintf(szFilterSecond[3],_T("%s9"), strResult);
			sprintf(szFilterSecond[4],_T("%s11"), strResult);
			sprintf(szFilterSecond[5],_T("%s13"), strResult);
			sprintf(szFilterSecond[6],_T("%s15"), strResult);
			sprintf(szFilterSecond[7],_T("%s17"), strResult);
			
/*			for(int i = 0; i< 4; i++)
			{
				strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[i]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				if(bExist)
					nFind++;
			}
			if(nFind == 0)
				return "NOEXIST";

			else
*/
			{
				if(nProductLayer == 4)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				else if(nProductLayer == 6)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
					}
					else if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				else if(nProductLayer == 8)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				else if(nProductLayer == 10)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				else if(nProductLayer == 12)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[4]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[4]);
					}
					else if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				else if(nProductLayer == 14)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[5]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[5]);
					}
					else if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[4]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[4]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 6)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				else if(nProductLayer == 16)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[6]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[6]);
					}
					else if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[5]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[5]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[4]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[4]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 6)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 7)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				else if(nProductLayer == 18)
				{
					if(nLayer == 1)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[7]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[7]);
					}
					else if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[6]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[6]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[5]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[5]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[4]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[4]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 6)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 7)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 8)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
				}
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					if(nProductLayer == 4)
					{
						if(nLayer == 1)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
					}
					else if(nProductLayer == 6)
					{
						if(nLayer == 1)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
						}
						else if(nLayer == 2)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
					}
					else if(nProductLayer == 8)
					{
						if(nLayer == 1)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						}
						else if(nLayer == 2)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
						}
						else if(nLayer == 3)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
					}
					else if(nProductLayer == 10)
					{
						if(nLayer == 1)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						}
						else if(nLayer == 2)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						}
						else if(nLayer == 3)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
						}
						else if(nLayer == 4)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
					}
					else if(nProductLayer == 12)
					{
						if(nLayer == 1)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[4]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[4]);
						}
						else if(nLayer == 2)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						}
						else if(nLayer == 3)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						}
						else if(nLayer == 4)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
						}
						else if(nLayer == 5)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
					}
					else if(nProductLayer == 14)
					{
						if(nLayer == 1)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[5]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[5]);
						}
						else if(nLayer == 2)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[4]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[4]);
						}
						else if(nLayer == 3)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						}
						else if(nLayer == 4)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						}
						else if(nLayer == 5)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
						}
						else if(nLayer == 6)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
					}
					else if(nProductLayer == 16)
					{
						if(nLayer == 1)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[6]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[6]);
						}
						else if(nLayer == 2)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[5]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[5]);
						}
						else if(nLayer == 3)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[4]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[4]);
						}
						else if(nLayer == 4)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						}
						else if(nLayer == 5)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						}
						else if(nLayer == 6)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
						}
						else if(nLayer == 7)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
					}
					else if(nProductLayer == 18)
					{
						if(nLayer == 1)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[7]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[7]);
						}
						else if(nLayer == 2)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[6]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[6]);
						}
						else if(nLayer == 3)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[5]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[5]);
						}
						else if(nLayer == 4)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[4]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[4]);
						}
						else if(nLayer == 5)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						}
						else if(nLayer == 6)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						}
						else if(nLayer == 7)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
						}
						else if(nLayer == 8)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
					}
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
						return "NOEXIST";
				}
			}
		}
		else // sol
		{
			sprintf(szFilter[0],_T("%s_C"), strResult); 
			sprintf(szFilter[1],_T("%s_E"), strResult);
			sprintf(szFilter[2],_T("%s_G"), strResult); 
			sprintf(szFilter[3],_T("%s_I"), strResult); 
			sprintf(szFilter[4],_T("%s_KK"), strResult); 
			sprintf(szFilter[5],_T("%s_MM"), strResult); 
			sprintf(szFilter[6],_T("%s_OO"), strResult); 

			sprintf(szFilterSecond[0],_T("%sC"), strResult); 
			sprintf(szFilterSecond[1],_T("%sE"), strResult);
			sprintf(szFilterSecond[2],_T("%sG"), strResult); 
			sprintf(szFilterSecond[3],_T("%sI"), strResult); 
			sprintf(szFilterSecond[4],_T("%sKK"), strResult); 
			sprintf(szFilterSecond[5],_T("%sMM"), strResult); 
			sprintf(szFilterSecond[6],_T("%sOO"), strResult); 

/*			for(int i = 0; i< 3; i++)
			{
				strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[i]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				if(bExist)
					nFind++;
			}
			nFind += 1;
			if(nFind == 0)
				return "NOEXIST";
			else
*/
			{
				if(nProductLayer == 6)
				{
					if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
					else if(nLayer == 1)
						return "NOEXIST";
				}
				else if(nProductLayer == 8)
				{
					if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
					else if(nLayer == 1)
						return "NOEXIST";
				}
				else if(nProductLayer == 10)
				{
					if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
					else if(nLayer == 1)
						return "NOEXIST";
				}
				else if(nProductLayer == 12)
				{
					if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
					else if(nLayer == 1)
						return "NOEXIST";
				}
				else if(nProductLayer == 14)
				{
					if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[4]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[4]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 6)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
					else if(nLayer == 1)
						return "NOEXIST";
				}
				else if(nProductLayer == 16)
				{
					if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[5]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[5]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[4]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[4]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 6)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 7)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
					else if(nLayer == 1)
						return "NOEXIST";
				}
				else if(nProductLayer == 18)
				{
					if(nLayer == 2)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[6]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[6]);
					}
					else if(nLayer == 3)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[5]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[5]);
					}
					else if(nLayer == 4)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[4]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[4]);
					}
					else if(nLayer == 5)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
					}
					else if(nLayer == 6)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
					}
					else if(nLayer == 7)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
					}
					else if(nLayer == 8)
					{
						strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
						strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
					}
					else if(nLayer == 1)
						return "NOEXIST";
				}
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					if(nProductLayer == 6)
					{
						if(nLayer == 2)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
						else if(nLayer == 1)
							return "NOEXIST";
					}
					else if(nProductLayer == 8)
					{
						if(nLayer == 2)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
						}
						else if(nLayer == 3)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
						else if(nLayer == 1)
							return "NOEXIST";
					}
					else if(nProductLayer == 10)
					{
						if(nLayer == 2)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						}
						else if(nLayer == 3)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
						}
						else if(nLayer == 4)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
						else if(nLayer == 1)
							return "NOEXIST";
					}
					else if(nProductLayer == 12)
					{
						if(nLayer == 2)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						}
						else if(nLayer == 3)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						}
						else if(nLayer == 4)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
						}
						else if(nLayer == 5)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
						else if(nLayer == 1)
							return "NOEXIST";
					}
					else if(nProductLayer == 14)
					{
						if(nLayer == 2)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[4]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[4]);
						}
						else if(nLayer == 3)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						}
						else if(nLayer == 4)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						}
						else if(nLayer == 5)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
						}
						else if(nLayer == 6)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
						else if(nLayer == 1)
							return "NOEXIST";
					}
					else if(nProductLayer == 16)
					{
						if(nLayer == 2)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[5]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[5]);
						}
						else if(nLayer == 3)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[4]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[4]);
						}
						else if(nLayer == 4)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						}
						else if(nLayer == 5)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						}
						else if(nLayer == 6)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
						}
						else if(nLayer == 7)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
						else if(nLayer == 1)
							return "NOEXIST";
					}
					else if(nProductLayer == 18)
					{
						if(nLayer == 2)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[6]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[6]);
						}
						else if(nLayer == 3)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[5]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[5]);
						}
						else if(nLayer == 4)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[4]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[4]);
						}
						else if(nLayer == 5)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						}
						else if(nLayer == 6)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						}
						else if(nLayer == 7)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
						}
						else if(nLayer == 8)
						{
							strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
							strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
						}
						else if(nLayer == 1)
							return "NOEXIST";
					}
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
						return "NOEXIST";
				}
			}
		}
	}
	return strFilePath;
}


void CPaneRecipeGenDataEasy::OnStnClickedStaticView()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	GetDlgItem(IDC_STATIC_VIEW)->SetFocus();
}

BOOL CPaneRecipeGenDataEasy::SetValue(int nComSol, CString strTXT)
{
#ifndef __TEST__
	m_pProject->m_dPcbThick =  atof(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strTrimFinalThick);
	m_pProject->m_dPcbThick2 =  atof(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strTrimFinalThick);

	gDProject.m_dPcbThick =  atof(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strTrimFinalThick);
	gDProject.m_dPcbThick2 =  atof(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strTrimFinalThick);
#endif
	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, 0);

	gDProject.m_nSeparation = USE_DUAL;
	m_pProject->m_nSeparation = USE_DUAL;

	if( m_pParent->m_pParamNew->ParameterOpen(nComSol) == FALSE)
	{
		return FALSE;
	}

	LPFIDDATA pFidData2;
	POSITION pos = m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while (pos)
	{
		pFidData2 = m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		
		pFidData2->nCam = LOW_CAM;

	}
	CString strMaterialGroup;
	strMaterialGroup = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialGroup; 	// CCL/PPG

	if( nComSol == 0 )
	{
		if( strMaterialGroup.CompareNoCase("CCL") == 0)
		{
			if(0 == strTXT.CompareNoCase(_T("txt") ))
			{
				m_pProject->m_dRefPosX = gProcessINI.m_sProcessFidFind.dRefPosX3 - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
				m_pProject->m_dRefPosY = gProcessINI.m_sProcessFidFind.dRefPosY3 - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
				gDProject.m_dRefPosX = gProcessINI.m_sProcessFidFind.dRefPosX - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
				gDProject.m_dRefPosY = gProcessINI.m_sProcessFidFind.dRefPosY - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
			}
			if(pFidData->nFidType & FID_VERIFY)
			{
				pFidData->sVisInfo.dSizeA = gProcessINI.m_sProcessOption.dVerifySize;
			}
			else
			{
				pFidData->sVisInfo.dSizeA = gProcessINI.m_sProcessOption.dCCLSize;
			}

			gDProject.m_bUseTurn = FALSE;
			m_pProject->m_bUseTurn = FALSE;
		}
		else
		{	
			if(0 == strTXT.CompareNoCase(_T("txt") ))
			{
				m_pProject->m_dRefPosX = gProcessINI.m_sProcessFidFind.dRefPosX - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
				m_pProject->m_dRefPosY = gProcessINI.m_sProcessFidFind.dRefPosY - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
				gDProject.m_dRefPosX = gProcessINI.m_sProcessFidFind.dRefPosX - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
				gDProject.m_dRefPosY = gProcessINI.m_sProcessFidFind.dRefPosY - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
			}
			if(pFidData->nFidType & FID_VERIFY)
			{
				pFidData->sVisInfo.dSizeA = gProcessINI.m_sProcessOption.dVerifySize;
			}
			else
			{
				pFidData->sVisInfo.dSizeA = gProcessINI.m_sProcessOption.dPPGSize;
			}
			
			gDProject.m_bUseTurn = TRUE;
			m_pProject->m_bUseTurn = TRUE;
		}
	}
	else
	{
		if(0 == strTXT.CompareNoCase(_T("txt") ))
		{
			m_pProject->m_dRefPosX = gProcessINI.m_sProcessFidFind.dRefPosX2 - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			m_pProject->m_dRefPosY = gProcessINI.m_sProcessFidFind.dRefPosY2 - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
			gDProject.m_dRefPosX = gProcessINI.m_sProcessFidFind.dRefPosX2 - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			gDProject.m_dRefPosY = gProcessINI.m_sProcessFidFind.dRefPosY2 - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		}

		pFidData->sVisInfo.dSizeA = 1.8;
		gDProject.m_bUseTurn = TRUE;
		m_pProject->m_bUseTurn = TRUE;
	}
	m_pParent->m_pLayout->SetData();
	if(!(m_pProject->m_nDataLoadStep & SET_FID_ORIGIN))
		m_pProject->m_nDataLoadStep += SET_FID_ORIGIN; // 091117

	strcpy_s(gDProject.m_szLotId , ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipeID);
	return TRUE;
}

void CPaneRecipeGenDataEasy::InputScheduleInfo(int nComSol)
{
	CDlgScheduleInfo dlg;
	dlg.m_strLotInfo = m_strLotIDComp;
	int nLen = 0;
	int i = 0;
	for(i = 0; i < 10 ; i = i+2)
	{
//		nLen = 	strlen(gLotInfo.szLotID[i]);
//		if(nLen <= 0)
		if(gLotInfo.nLotCount[i] == 0)
		{
			strcpy_s(gLotInfo.szLotID[i], m_strLotIDComp);
			if(nComSol == 2)
			{
				gLotInfo.nComSol[i] = 2;
				gLotInfo.nComSol[i+1] = 3;
			}
			else
			{
				gLotInfo.nComSol[i] = nComSol;
				gLotInfo.nComSol[i+1] = nComSol;
			}
			break;
		}
	}
	dlg.SetAutoMES(i, TRUE);
	dlg.DoModal();
//	dlg.OnButtonMES();
}

void CPaneRecipeGenDataEasy::OnCheckOriginalInspection() 
{
	m_bOriginalInspection = !m_bOriginalInspection;
//	m_ledOriginalInspection.Depress(!m_bOriginalInspection);
	m_ledOriginalInspection.SetCheck(m_bOriginalInspection);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bOriginalInspection = m_bOriginalInspection;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_ledOriginalInspection.Depress(!m_bOriginalInspection);

}


void CPaneRecipeGenDataEasy::OnCheckDataHeader() 
{
	gDProject.m_bDataHeader = !gDProject.m_bDataHeader;
	m_ledDataHeader.SetCheck(gDProject.m_bDataHeader);
}

void CPaneRecipeGenDataEasy::SetOriginalInspection() 
{
	m_bOriginalInspection = TRUE;
//	m_ledOriginalInspection.Depress(!m_bOriginalInspection);
	m_ledOriginalInspection.SetCheck(m_bOriginalInspection);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bOriginalInspection = m_bOriginalInspection;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_ledOriginalInspection.Depress(!m_bOriginalInspection);

}

CString CPaneRecipeGenDataEasy::FindDataNameNew(CString strFileName, CString strManagementCode)
{
	
	CFileFind find;
	int nFind=0;
	BOOL bExist = FALSE;
	BOOL bExistSecond = FALSE;
	CString strFilePath = _T("");
	CString strCopyFilePath = _T("");
	CString strProjectPath = _T("");

	//strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(),strFileName);
	strFilePath.Format(_T("%s%s\\%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(),strManagementCode,strFileName);
	bExist = find.FindFile((LPCTSTR)strFilePath);
	if(bExist)
		return strFilePath;
	else
	{
		strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), strFileName);
		bExist = find.FindFile((LPCTSTR)strFilePath);
		if(bExist)
		{
			strProjectPath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), strManagementCode);
			if( 0 != _chdir( (LPSTR)(LPCTSTR)strProjectPath ) )
				_mkdir( (LPSTR)(LPCTSTR)strProjectPath );

			strCopyFilePath.Format(_T("%s%s\\%s.txt"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(),strManagementCode, strFileName);
			CopyFile(strFilePath, strCopyFilePath,FALSE);
			return strFilePath;
		}
		else
			return "NOEXIST";
	}

	return strFilePath;
}
//20170405 MES 3.0 Update
CString CPaneRecipeGenDataEasy::FindDataNameNew2(CString strLotID, CString strManager, int nComSol, CString strProcessCode, CString strBackwardLevel)
{
	CString strResult;
	int nIndex = strManager.Find(_T('-'));
	
	if(nIndex == -1)
	{
		ErrMessage(_T("DB Admin numbers are not correct..\r\n( correct is : XXX-XX... )"));
		return "NOEXIST";
	}
	
	// m_strLot2�� 133-877-9T�̶�� �Ѵٸ�,
	// m_strManage = 1X8779T�� �ȴ�
	// "133"���� �ڿ� 2�ڸ� "33"�� "X"�� ��ȯ�ϸ� ��
	
	CString strTemp = strManager.Left(nIndex).Mid(1);
	int nNum = atoi(strTemp);
	
	if(nNum < 10)
		strTemp.Format(_T("%d"), nNum);
	else
		strTemp.Format(_T("%c"), nNum+55);
	
	strResult = strManager.Left(1) + strTemp;
	
	CString strTemp2= strManager.Mid(nIndex+1);
	
	int nIndexCount = 0;
	while(TRUE)
	{
		if(nIndexCount == 2)
			break;
		nIndex = strTemp2.Find(_T('-'));
		if(nIndex < 1)
		{
			strResult += strTemp2;
			break;
		}
		strResult += strTemp2.Left(nIndex);
		strTemp2 = strTemp2.Mid(nIndex+1);
		nIndexCount++;
	}
	
	CString strLayer = strManager.Right(2);
	int nLayer = atoi(strLayer);

	CString  strFilePath = _T("");
	CString  strFilePathSecond = _T("");
	char szFilter[9][50];
	char szFilterSecond[9][50];
	memset(szFilter, 0, sizeof(szFilter));
	memset(szFilterSecond, 0, sizeof(szFilterSecond));
	CFileFind find;
	int nFind=0;
	BOOL bExist = FALSE;
	BOOL bExistSecond = FALSE;
	strFilePath.Empty();
	int nLen = strManager.GetLength();

	CString strTempLotID = strLotID.Right(6);
	if(strBackwardLevel.CompareNoCase("1") == 0) // ����1�ڸ�+����8�ڸ� ����
	{
		sprintf(szFilter[0],_T("%s_1_%s"), strResult, strTempLotID); 
		sprintf(szFilter[1],_T("%s_A_%s"), strResult, strTempLotID);

		sprintf(szFilterSecond[0],_T("%s1_%s"), strResult, strTempLotID); 
		sprintf(szFilterSecond[1],_T("%sA_%s"), strResult, strTempLotID);
		
		sprintf(szFilter[2],_T("%s_1"), strResult); 
		sprintf(szFilter[3],_T("%s_A"), strResult);

		sprintf(szFilterSecond[2],_T("%s1"), strResult); 
		sprintf(szFilterSecond[3],_T("%sA"), strResult);
		
		if(nComSol == 0) // com 
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
					strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
					{
						strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						bExist = find.FindFile((LPCTSTR)strFilePath);
						bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
						if(bExist)
							return strFilePath;
						else if(bExistSecond)
							return strFilePathSecond;
						else
							return "NOEXIST";
					}
				}
			}			
		}
		else
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
					strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
					{
						strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						bExist = find.FindFile((LPCTSTR)strFilePath);
						bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
						if(bExist)
							return strFilePath;
						else if(bExistSecond)
							return strFilePathSecond;
						else
							return "NOEXIST";
					}
				}
			}
		}
	}
	else if(strBackwardLevel.CompareNoCase("2") == 0) // ����1�ڸ�+����10�ڸ� ����
	{
		sprintf(szFilter[0],_T("%s_3_%s"), strResult, strTempLotID); 
		sprintf(szFilter[1],_T("%s_C_%s"), strResult, strTempLotID);

		sprintf(szFilterSecond[0],_T("%s3_%s"), strResult, strTempLotID); 
		sprintf(szFilterSecond[1],_T("%sC_%s"), strResult, strTempLotID);
		
		sprintf(szFilter[2],_T("%s_3"), strResult); 
		sprintf(szFilter[3],_T("%s_C"), strResult);

		sprintf(szFilterSecond[2],_T("%s3"), strResult); 
		sprintf(szFilterSecond[3],_T("%sC"), strResult);
		
		if(nComSol == 0) // com 
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
					strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
					{
						strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						bExist = find.FindFile((LPCTSTR)strFilePath);
						bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
						if(bExist)
							return strFilePath;
						else if(bExistSecond)
							return strFilePathSecond;
						else
							return "NOEXIST";
					}
				}
			}
			
				
		}
		else
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
					strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
					{
						strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						bExist = find.FindFile((LPCTSTR)strFilePath);
						bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
						if(bExist)
							return strFilePath;
						else if(bExistSecond)
							return strFilePathSecond;
						else
							return "NOEXIST";
					}
				}
			}
		}
	}
	else if(strBackwardLevel.CompareNoCase("3") == 0) // ����1�ڸ�+����10�ڸ� ����
	{
		sprintf(szFilter[0],_T("%s_5_%s"), strResult, strTempLotID); 
		sprintf(szFilter[1],_T("%s_E_%s"), strResult, strTempLotID);

		sprintf(szFilterSecond[0],_T("%s5_%s"), strResult, strTempLotID); 
		sprintf(szFilterSecond[1],_T("%sE_%s"), strResult, strTempLotID);
		
		sprintf(szFilter[2],_T("%s_5"), strResult); 
		sprintf(szFilter[3],_T("%s_E"), strResult);

		sprintf(szFilterSecond[2],_T("%s5"), strResult); 
		sprintf(szFilterSecond[3],_T("%sE"), strResult);
		
		if(nComSol == 0) // com 
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
					strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
					{
						strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						bExist = find.FindFile((LPCTSTR)strFilePath);
						bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
						if(bExist)
							return strFilePath;
						else if(bExistSecond)
							return strFilePathSecond;
						else
							return "NOEXIST";
					}
				}
			}
			
				
		}
		else
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
					strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
					{
						strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						bExist = find.FindFile((LPCTSTR)strFilePath);
						bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
						if(bExist)
							return strFilePath;
						else if(bExistSecond)
							return strFilePathSecond;
						else
							return "NOEXIST";
					}
				}
			}
		}
	}
	else if(strBackwardLevel.CompareNoCase("4") == 0) // ����1�ڸ�+����10�ڸ� ����
	{
		sprintf(szFilter[0],_T("%s_7_%s"), strResult, strTempLotID); 
		sprintf(szFilter[1],_T("%s_G_%s"), strResult, strTempLotID);

		sprintf(szFilterSecond[0],_T("%s7_%s"), strResult, strTempLotID); 
		sprintf(szFilterSecond[1],_T("%sG_%s"), strResult, strTempLotID);
		
		sprintf(szFilter[2],_T("%s_7"), strResult); 
		sprintf(szFilter[3],_T("%s_G"), strResult);

		sprintf(szFilterSecond[2],_T("%s7"), strResult); 
		sprintf(szFilterSecond[3],_T("%sG"), strResult);
		
		if(nComSol == 0) // com 
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
					strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
					{
						strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						bExist = find.FindFile((LPCTSTR)strFilePath);
						bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
						if(bExist)
							return strFilePath;
						else if(bExistSecond)
							return strFilePathSecond;
						else
							return "NOEXIST";
					}
				}
			}
			
				
		}
		else
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
					strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
					{
						strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						bExist = find.FindFile((LPCTSTR)strFilePath);
						bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
						if(bExist)
							return strFilePath;
						else if(bExistSecond)
							return strFilePathSecond;
						else
							return "NOEXIST";
					}
				}
			}
		}
	}
	else if(strBackwardLevel.CompareNoCase("5") == 0) // ����1�ڸ�+����10�ڸ� ����
	{
		sprintf(szFilter[0],_T("%s_9_%s"), strResult, strTempLotID); 
		sprintf(szFilter[1],_T("%s_I_%s"), strResult, strTempLotID);

		sprintf(szFilterSecond[0],_T("%s9_%s"), strResult, strTempLotID); 
		sprintf(szFilterSecond[1],_T("%sI_%s"), strResult, strTempLotID);
		
		sprintf(szFilter[2],_T("%s_9"), strResult); 
		sprintf(szFilter[3],_T("%s_I"), strResult);

		sprintf(szFilterSecond[2],_T("%s9"), strResult); 
		sprintf(szFilterSecond[3],_T("%sI"), strResult);
		
		if(nComSol == 0) // com 
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
					strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
					{
						strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						bExist = find.FindFile((LPCTSTR)strFilePath);
						bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
						if(bExist)
							return strFilePath;
						else if(bExistSecond)
							return strFilePathSecond;
						else
							return "NOEXIST";
					}
				}
			}		
		}
		else
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
					strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
					{
						strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						bExist = find.FindFile((LPCTSTR)strFilePath);
						bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
						if(bExist)
							return strFilePath;
						else if(bExistSecond)
							return strFilePathSecond;
						else
							return "NOEXIST";
					}
				}
			}
		}
	}
	else if(strBackwardLevel.CompareNoCase("6") == 0) // ����1�ڸ�+����10�ڸ� ����
	{
		sprintf(szFilter[0],_T("%s_11_%s"), strResult, strTempLotID); 
		sprintf(szFilter[1],_T("%s_K_%s"), strResult, strTempLotID);

		sprintf(szFilterSecond[0],_T("%s11_%s"), strResult, strTempLotID); 
		sprintf(szFilterSecond[1],_T("%sK_%s"), strResult, strTempLotID);
		
		sprintf(szFilter[2],_T("%s_11"), strResult); 
		sprintf(szFilter[3],_T("%s_K"), strResult);

		sprintf(szFilterSecond[2],_T("%s11"), strResult); 
		sprintf(szFilterSecond[3],_T("%sK"), strResult);
		
		if(nComSol == 0) // com 
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[0]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[0]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[2]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[2]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[0]);
					strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[0]);
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
					{
						strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[2]);
						strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[2]);
						bExist = find.FindFile((LPCTSTR)strFilePath);
						bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
						if(bExist)
							return strFilePath;
						else if(bExistSecond)
							return strFilePathSecond;
						else
							return "NOEXIST";
					}
				}
			}	
		}
		else
		{
			strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[1]);
			strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[1]);
			bExist = find.FindFile((LPCTSTR)strFilePath);
			bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
			if(bExist)
				return strFilePath;
			else if(bExistSecond)
				return strFilePathSecond;
			else
			{
				strFilePath.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilter[3]);
				strFilePathSecond.Format(_T("%s%s.prj"), gEasyDrillerINI.m_clsDirPath.GetProjectDir(), szFilterSecond[3]);
				bExist = find.FindFile((LPCTSTR)strFilePath);
				bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
				if(bExist)
					return strFilePath;
				else if(bExistSecond)
					return strFilePathSecond;
				else
				{
					strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[1]);
					strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[1]);
					bExist = find.FindFile((LPCTSTR)strFilePath);
					bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
					if(bExist)
						return strFilePath;
					else if(bExistSecond)
						return strFilePathSecond;
					else
					{
						strFilePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilter[3]);
						strFilePathSecond.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetDataDir(), szFilterSecond[3]);
						bExist = find.FindFile((LPCTSTR)strFilePath);
						bExistSecond = find.FindFile((LPCTSTR)strFilePathSecond);
						if(bExist)
							return strFilePath;
						else if(bExistSecond)
							return strFilePathSecond;
						else
							return "NOEXIST";
					}
				}
			}
		}
	}
	else
		return "NOEXIST";
	return strFilePath;
}

BOOL CPaneRecipeGenDataEasy::ParameterNameCheck()
{
	CString strLayUpCode, strMaterialGroup, strMaterialMaker, strMaterialKind, strMaterialThick, strLayer, strPPGThick, strDongbakThick, strCompRecipeFile, strSoldRecipeFile, strRecipePrj;
	CString strFile;

	CString strProcessCode, strBackwardLevel, strCopperThick, strCustomerCode, strPrevProcessCode;

	strFile.Format(_T("%s"),gEasyDrillerINI.m_clsDirPath.GetParameterDir());

	strLayer = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCurrentProcess;
	strLayUpCode = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strLayUpCode;      // Type
	strMaterialGroup = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialGroup; 	// CCL/PPG
	strMaterialMaker = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialMaker;  // ��ü��
	strMaterialKind = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialKind; 	// ��������
	strMaterialThick = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strMaterialThick; 	// ����β�
	strPPGThick = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strPPGThick; 	// ppg�β�
	strDongbakThick = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDongbakThick; 	// ���ڵβ�
	
	strCompRecipeFile = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCompRecipeFile; 	// Comp Recipe Name
	strSoldRecipeFile = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strSoldRecipeFile; // Sold Recipe Name
	
	strRecipePrj = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strRecipePrj; // Sold Recipe Name
	

	strProcessCode = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strProcessCode; // Process Code
	strBackwardLevel = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strBackwardLevel; // backward Level
	strCopperThick = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCopperThick; // copper Thick
	strCustomerCode = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strCustomerCode; // Customer Code
	strPrevProcessCode = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strPrevProcessCode; // Customer Code


	int nLength = strRecipePrj.GetLength();
#ifdef __TEST__
	strLayUpCode = _T("00FN");
	strMaterialGroup = _T("PREPREG");
	strMaterialMaker = _T("EMC");
	strMaterialKind = _T("GR(FR4)");
	strMaterialThick = _T("0.06");
#endif

	strFile += strProcessCode + _T("_");
	strFile += strBackwardLevel + _T("_");
	strFile += strMaterialMaker + _T("_");
	strFile += strMaterialThick + _T("_");
	strFile += strMaterialGroup + _T("_");

	strFile += strLayUpCode + _T("_");
	strFile += strCopperThick + _T("_");
	strFile += strMaterialKind + _T("_");
	strFile += strCustomerCode + _T("_");
	strFile += strPrevProcessCode + _T("_");
	/*
	if(bComSol == 0)
		strFile += _T("COMP.pen");
	else
		strFile += _T("SOLDER.pen");
	*/
	strFile.Replace(_T("__"),_T("_"));
	


	if(gVariable.m_strBackupRecipeComp.CompareNoCase(strFile += _T("COMP")) != 0 ||
		gVariable.m_strBackupRecipeSold.CompareNoCase(strFile += _T("SOLDER")) != 0) 
		return FALSE;


	gVariable.m_strBackupRecipeComp = strFile + _T("COMP");
	gVariable.m_strBackupRecipeSold = strFile + _T("SOLDER");

	return TRUE;
}

void CPaneRecipeGenDataEasy::OnCheckShowStripNo() //jjh 2013.10.15
{
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}
	m_bShowStripNo = !m_bShowStripNo;
	
	m_ledShowStripNo.Depress(!m_bShowStripNo);
	gDProject.m_bShowStripNo = m_bShowStripNo;

	CRect cRect;
	
	
	if(m_pParent && ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew)
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->InitialDrawRatio();
	
	
	m_pProject->ReCalRect();//jjh ȭ�鿡 ��Ī �ȵǴ� ���� ���� 
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
	m_pProject->InitialDrawRatio(cRect);
	
	SetFocus();
	
	Invalidate(FALSE);
}


void CPaneRecipeGenDataEasy::OnBnClickedCheckSelectRun2()
{

	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}

	m_bSelectFire = !m_bSelectFire;
	m_ledSelectFire.Depress(!m_bSelectFire);
	gDProject.m_bSelectDrawMode = m_bSelectFire;
	m_pProject->m_bSelectDrawMode = m_bSelectFire;
	DrawData();

	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bSelectFire = m_bSelectFire;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_ledSelectFire.Depress(!m_bSelectFire);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->ChangeProjectInfo(TRUE);

	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->DrawData();
}

void CPaneRecipeGenDataEasy::OnBnClickedCheckNoFindFid()
{

	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}

	m_bNoFindFid = !m_bNoFindFid;
	m_ledNoFindFid.Depress(!m_bNoFindFid);
	gProcessINI.m_sProcessSystem.bNoUseFiducialFind = m_bNoFindFid;

}
void CPaneRecipeGenDataEasy::OnBnClickedCheckNoUsePreWork()
{


	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}

	m_bNoUsePreWork = !m_bNoUsePreWork;
	m_ledNoPreWork.Depress(!m_bNoUsePreWork);
	 gProcessINI.m_sProcessSystem.bNoUsePrework = m_bNoUsePreWork;
}
#if !defined(AFX_DLGSIDEVISION_H__D89D2D96_CEA8_4521_8A1D_541F75384695__INCLUDED_)
#define AFX_DLGSIDEVISION_H__D89D2D96_CEA8_4521_8A1D_541F75384695__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgSideVision.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgSideVision dialog

class CDlgSideVision : public CDialog
{
// Construction
public:
	void SetTopMost(BOOL bTopmost);
	void SetShow(BOOL bShow);
	void GetDlgSize(CRect &rc);
	CDlgSideVision(CWnd* pParent = NULL);   // standard constructor
	BOOL m_bInit;
// Dialog Data
	//{{AFX_DATA(CDlgSideVision)
	enum { IDD = IDD_DLG_SIDE_VISION };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgSideVision)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgSideVision)
	afx_msg void OnMove(int x, int y);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSIDEVISION_H__D89D2D96_CEA8_4521_8A1D_541F75384695__INCLUDED_)

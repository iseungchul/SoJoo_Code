#if !defined(AFX_DLGVISIONONLY_H__33A8BEB3_EDE7_4E38_A494_BB3FFCBC6D0D__INCLUDED_)
#define AFX_DLGVISIONONLY_H__33A8BEB3_EDE7_4E38_A494_BB3FFCBC6D0D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgVisionOnly.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgVisionOnly dialog

#include "UEasyButtonEx.h"

class CDlgVisionOnly : public CDialog
{
// Construction
public:
	CDlgVisionOnly(CWnd* pParent = NULL);   // standard constructor

	void		InitBtnControl();

// Dialog Data
	//{{AFX_DATA(CDlgVisionOnly)
	enum { IDD = IDD_DLG_VISION_ONLY };
	UEasyButtonEx	m_btnClose;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgVisionOnly)
	public:
	virtual BOOL Create(CWnd* pParentWnd);
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CFont		m_fntBtn;

	// Generated message map functions
	//{{AFX_MSG(CDlgVisionOnly)
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGVISIONONLY_H__33A8BEB3_EDE7_4E38_A494_BB3FFCBC6D0D__INCLUDED_)

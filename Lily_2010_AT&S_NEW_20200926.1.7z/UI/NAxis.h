#ifndef __NAxis
#define __NAxis
namespace NAxis
{
	enum enumAxis { axis_0, axis_90, axis_180, axis_270,
	axis_left_0, axis_left_90, axis_left_180, axis_left_270};
};
#endif // __NAxis

// DlgAutoLoaderInterface.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "DlgAutoLoaderInterface.h"
#include "afxdialogex.h"
#include "..\DEVICE\HDeviceFactory.h"
#include "..\DEVICE\DeviceMotor.h"

#include "..\model\GlobalVariable.h"
#include "paneautorun.h"
#include "..\Model\DProcessINI.h"
// CDlgAutoLoaderInterface ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgAutoLoaderInterface, CDialog)

CDlgAutoLoaderInterface::CDlgAutoLoaderInterface(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgAutoLoaderInterface::IDD, pParent)
{
	for(int i = 0; i < AUTOLOADER_OPTION_STATUS; i++)
	{
		m_nOption[i] = 0;
		m_nOption_Old[i] = 0;
	}

	for(int i = 0; i < AUTOLOADER_PCB_STATUS; i++)
	{
		m_nPcb[i] = 0;
		m_nPcb_Old[i] = 0;
	}

	for(int i = 0; i < AUTOLOADER_INPUT_STATUS; i++)
	{
		m_nInput[i] = 0;
		m_nInput_Old[i] = 0;
	}

	for(int i = 0; i < AUTOLOADER_OUTPUT_STATUS; i++)
	{
		m_nOutput[i] = 0;
		m_nOutput_Old[i] = 0;
	}

	m_strOptionText[0] = _T("Set Reverse [R1000]");
	m_strOptionText[1] = _T("Set Turn Panel [R1001]");
	m_strOptionText[2] = _T("Set PCB Size [R1013]");

	m_strPcbText[0] = _T("Load Elevator PCB Exist");
	m_strPcbText[1] = _T("LP1 Down OK");
	m_strPcbText[2] = _T("LP1 Down OK");
	m_strPcbText[3] = _T("LP1 PCB Exist");
	m_strPcbText[4] = _T("LP2 PCB Exist");
	m_strPcbText[5] = _T("UP1 PCB Exist");
	m_strPcbText[6] = _T("UP2 PCB Exist");

	m_strInputText[0] = _T("Aligning");
	m_strInputText[1] = _T("Align End");
	m_strInputText[2] = _T("Loading");
	m_strInputText[3] = _T("Load End");
	m_strInputText[4] = _T("Unloading");
	m_strInputText[5] = _T("Unload End");
	m_strInputText[6] = _T("Load Request Ready");

	m_strOutputText[0] = _T("Set Align");
	m_strOutputText[1] = _T("Set Load");
	m_strOutputText[2] = _T("Set Unload");
	m_strOutputText[3] = _T("Set Table 1 PCB Exist");
	m_strOutputText[4] = _T("Set Table 2 PCB Exist");
	m_strOutputText[5] = _T("Set Table 1 Load Picker Down OK");
	m_strOutputText[6] = _T("Set Table 2 Load Picker Down OK");
	m_strOutputText[7] = _T("Set Table 1 Unload Picker Down OK");
	m_strOutputText[8] = _T("Set Table 2 Unload Picker Down OK");

	m_nTimerID = 0;
	m_bOldReverse = FALSE;
}

CDlgAutoLoaderInterface::~CDlgAutoLoaderInterface()
{
}

void CDlgAutoLoaderInterface::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_LED_OPTION_REVERSE, m_ledOptionReverse);

	DDX_Control(pDX, IDC_LED_OPTION_01, m_ledOption[0]);
	DDX_Control(pDX, IDC_LED_OPTION_02, m_ledOption[1]);
	DDX_Control(pDX, IDC_LED_OPTION_03, m_ledOption[2]);

	DDX_Control(pDX, IDC_LED_PCB_01, m_ledPcb[0]);
	DDX_Control(pDX, IDC_LED_PCB_02, m_ledPcb[1]);
	DDX_Control(pDX, IDC_LED_PCB_03, m_ledPcb[2]);
	DDX_Control(pDX, IDC_LED_PCB_04, m_ledPcb[3]);
	DDX_Control(pDX, IDC_LED_PCB_05, m_ledPcb[4]);
	DDX_Control(pDX, IDC_LED_PCB_06, m_ledPcb[5]);
	DDX_Control(pDX, IDC_LED_PCB_07, m_ledPcb[6]);
	DDX_Control(pDX, IDC_LIST_RESULT, m_lboxResult);
	DDX_Control(pDX, IDC_LED_INPUT_01, m_ledInput[0]);
	DDX_Control(pDX, IDC_LED_INPUT_02, m_ledInput[1]);
	DDX_Control(pDX, IDC_LED_INPUT_03, m_ledInput[2]);
	DDX_Control(pDX, IDC_LED_INPUT_04, m_ledInput[3]);
	DDX_Control(pDX, IDC_LED_INPUT_05, m_ledInput[4]);
	DDX_Control(pDX, IDC_LED_INPUT_06, m_ledInput[5]);
	DDX_Control(pDX, IDC_LED_INPUT_07, m_ledInput[6]);

	DDX_Control(pDX, IDC_LED_OUTPUT_01, m_ledOutput[0]);
	DDX_Control(pDX, IDC_LED_OUTPUT_02, m_ledOutput[1]);
	DDX_Control(pDX, IDC_LED_OUTPUT_03, m_ledOutput[2]);
	DDX_Control(pDX, IDC_LED_OUTPUT_04, m_ledOutput[3]);
	DDX_Control(pDX, IDC_LED_OUTPUT_05, m_ledOutput[4]);
	DDX_Control(pDX, IDC_LED_OUTPUT_06, m_ledOutput[5]);
	DDX_Control(pDX, IDC_LED_OUTPUT_07, m_ledOutput[6]);
	DDX_Control(pDX, IDC_LED_OUTPUT_08, m_ledOutput[7]);
	DDX_Control(pDX, IDC_LED_OUTPUT_09, m_ledOutput[8]);

}

BEGIN_MESSAGE_MAP(CDlgAutoLoaderInterface, CDialog)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_CLEAR, &CDlgAutoLoaderInterface::OnBnClickedButtonClear)
	ON_BN_CLICKED(IDC_BUTTON_CHANGE_LOG, &CDlgAutoLoaderInterface::OnBnClickedButtonChangeLog)
	ON_STN_CLICKED(IDC_LED_OPTION_02, &CDlgAutoLoaderInterface::OnStnClickedLedOption02)
END_MESSAGE_MAP()

// CDlgAutoLoaderInterface �޽��� ó�����Դϴ�.

BOOL CDlgAutoLoaderInterface::OnInitDialog()
{
	CDialog::OnInitDialog();


	m_fntList.CreatePointFont(90, "Arial Bold");
	m_lboxResult.SetFont( &m_fntList );


	


	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	InitTimer();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CDlgAutoLoaderInterface::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_nTimerID = SetTimer(9974, 300, NULL);
	}
}

void CDlgAutoLoaderInterface::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

void CDlgAutoLoaderInterface::OnDestroy()
{
	CDialog::OnDestroy();
	m_fntList.DeleteObject();
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	DestroyTimer();
}

void CDlgAutoLoaderInterface::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	
	int nLevel = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetUserLevel();
	BOOL bUse = TRUE;
	if(!gProcessINI.m_sProcessSystem.bUseAutoMonitoring || nLevel < 2)
		bUse = FALSE;

	if(bUse)
	{
		UpdateStatus();//MCMC
	}
	

	CDialog::OnTimer(nIDEvent);
}

void CDlgAutoLoaderInterface::DisplayStatus(CString strStatus)
{

	if(strStatus.Find("USER_CLICK") != -1)
		return;

	CString str, strTemp;

	if(m_lboxResult.m_hWnd == NULL)
		return;

	m_lboxResult.AddString((LPCTSTR)strStatus);

	m_lboxResult.SetCurSel(m_lboxResult.GetCount()-1);

}

void CDlgAutoLoaderInterface::UpdateStatus()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	int nRedColor = CLed::LED_COLOR_RED;
	int nGreenColor = CLed::LED_COLOR_GREEN;
	int nOnMode = CLed::LED_ON;

	// Option
	m_nOption[0] = pMotor->m_nSetReverse;
	m_nOption[1] = pMotor->m_nSetTurnPanel;
	m_nOption[2] = pMotor->m_nSetPcbSize;

	for(int i = 0; i < AUTOLOADER_OPTION_STATUS; i++)
	{
		if(m_nOption[i] != m_nOption_Old[i])
		{
			m_nOption_Old[i] = m_nOption[i];

			CString strFile, strLog;
			strFile.Format(_T("AutoLoader_IF"));
			strLog.Format("[Option] %s - [%d]", m_strOptionText[i], m_nOption[i]);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

			if(m_nOption[i])
				m_ledOption[i].SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
			else
				m_ledOption[i].SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
		}
	}

	BOOL bReverse = pMotor->GetReverseDirection();

	if(m_bOldReverse != bReverse)
	{
		if(bReverse)
			m_ledOptionReverse.SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
		else
			m_ledOptionReverse.SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
	}
	m_bOldReverse = bReverse;

	// PCB Status
	m_nPcb[0] = !pMotor->IsLoadCartNoPCB();//Melsec
	m_nPcb[1] = pMotor->IsHandlerOperation(HANDLER_LOAD_PICKER_DOWN, FALSE, FALSE); //Melsec
	m_nPcb[2] = pMotor->IsHandlerOperation(HANDLER_UNLOAD_PICKER_DOWN, FALSE, FALSE);//Melsec

	m_nPcb[3] = pMotor->IsLoaderPicker1PCBExist();//PLC
	m_nPcb[4] = pMotor->IsLoaderPicker2PCBExist();//PLC
	m_nPcb[5] = pMotor->IsUnloaderPicker1PCBExist();//PLC
	m_nPcb[6] = pMotor->IsUnloaderPicker2PCBExist();//PLC

	for(int i = 0; i < AUTOLOADER_PCB_STATUS; i++)
	{
		if(m_nPcb[i] != m_nPcb_Old[i])
		{
			m_nPcb_Old[i] = m_nPcb[i];

			CString strFile, strLog;
			strFile.Format(_T("AutoLoader_IF"));
			strLog.Format("[PCB Status] %s - [%d]", m_strPcbText[i], m_nPcb[i]);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

			if(m_nPcb[i])
				m_ledPcb[i].SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
			else
				m_ledPcb[i].SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
		}
	}

	// Input
	m_nInput[0] = pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, FALSE, FALSE);
	m_nInput[1] = pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, TRUE, FALSE);
	m_nInput[2] = pMotor->IsHandlerOperation(HANDLER_LOADER_LOAD, FALSE, FALSE);
	m_nInput[3] = pMotor->IsHandlerOperation(HANDLER_LOADER_LOAD, TRUE, FALSE);
	m_nInput[4] = pMotor->IsHandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE, FALSE);
	m_nInput[5] = pMotor->IsHandlerOperation(HANDLER_UNLOADER_UNLOAD, TRUE, FALSE);
	m_nInput[6] = pMotor->IsHandlerOperation(HANDLER_UNLOADER_TO_LOAD_START, TRUE);



	for(int i = 0; i < AUTOLOADER_INPUT_STATUS; i++)
	{
		if(m_nInput[i] != m_nInput_Old[i])
		{
			m_nInput_Old[i] = m_nInput[i];

			CString strFile, strLog;
			strFile.Format(_T("AutoLoader_IF"));
			strLog.Format("[Input] %s - [%d]", m_strInputText[i], m_nInput[i]);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	
			if(m_nInput[i])
				m_ledInput[i].SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
			else
				m_ledInput[i].SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
		}
	}

	// Output
	m_nOutput[0] = pMotor->m_nSetAlign;
	m_nOutput[1] = pMotor->m_nSetLoad;
	m_nOutput[2] = pMotor->m_nSetUnload;
	m_nOutput[3] = pMotor->m_nSetTable1PcbExist;
	m_nOutput[4] = pMotor->m_nSetTable2PcbExist;
	m_nOutput[5] = pMotor->m_nSetTable1LoadPickerDown;
	m_nOutput[6] = pMotor->m_nSetTable2LoadPickerDown;
	m_nOutput[7] = pMotor->m_nSetTable1UnloadPickerDown;
	m_nOutput[8] = pMotor->m_nSetTable2UnloadPickerDown;

	for(int i = 0; i < AUTOLOADER_OUTPUT_STATUS; i++)
	{
		if(m_nOutput[i] != m_nOutput_Old[i])
		{
			m_nOutput_Old[i] = m_nOutput[i];

			CString strFile, strLog;
			strFile.Format(_T("AutoLoader_IF"));
			strLog.Format("[Output] %s - [%d]", m_strOutputText[i], m_nOutput[i]);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

			if(m_nOutput[i])
				m_ledOutput[i].SetLed(nGreenColor, nOnMode, CLed::LED_ROUND);
			else
				m_ledOutput[i].SetLed(nRedColor, nOnMode, CLed::LED_ROUND);
		}
	}

	CString strUseTable = "Dual";

	if(gVariable.m_nUseTable == USE_1ST)
		strUseTable = "1ST";
	else if(gVariable.m_nUseTable == USE_2ND)
		strUseTable = "2ND";

	GetDlgItem(IDC_STATIC_USE_TABLE)->SetWindowText(strUseTable);


	CString strTemp = "None";

	if(gVariable.m_nChangeDisplayLogMode == 1)
		strTemp = "AutoTrace";
	else if(gVariable.m_nChangeDisplayLogMode == 2)
		strTemp = "Log";

	GetDlgItem(IDC_STATIC_CHANGE_LOG)->SetWindowText(strTemp);

		GetDlgItem(IDC_STATIC_PROCESS_STATUS)->SetWindowText(gVariable.m_strProcessStatus);
	/*
	BOOL bOn = pMotor->GetTalbeMoveEnableFlag();

	strTemp = "On";
	if(!bOn)
		strTemp = "Off";
	GetDlgItem(IDC_STATIC_TABLE_MOVE_ENALBE)->SetWindowText(strTemp);

	int nFired = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nTotalCurrentLotCount;
	int nTotal = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_nTotalInputLot;
	strTemp.Format(" %d / %d ",nFired,nTotal);
	GetDlgItem(IDC_STATIC_PANEL_COUNT)->SetWindowText(strTemp);



	bOn = pMotor->IsMelsecConnect();

	strTemp = "Connect";
	if(!bOn)
		strTemp = "Disconnect";
	GetDlgItem(IDC_STATIC_MELSEC_CONNECT)->SetWindowText(strTemp);
	*/
}

void CDlgAutoLoaderInterface::OnBnClickedButtonClear()
{
	m_lboxResult.ResetContent();
}


void CDlgAutoLoaderInterface::OnBnClickedButtonChangeLog()
{
	

	if(gVariable.m_nChangeDisplayLogMode == 2)
	{
		gVariable.m_nChangeDisplayLogMode = 0;
	}
	else
		gVariable.m_nChangeDisplayLogMode++;
}


void CDlgAutoLoaderInterface::OnStnClickedLedOption02()
{
		DeviceMotor* pMotor = gDeviceFactory.GetMotor();


	// Option

	pMotor->m_nSetTurnPanel = !pMotor->m_nSetTurnPanel;

	gDeviceFactory.GetMotor()->SetTrunPanel(pMotor->m_nSetTurnPanel);
}

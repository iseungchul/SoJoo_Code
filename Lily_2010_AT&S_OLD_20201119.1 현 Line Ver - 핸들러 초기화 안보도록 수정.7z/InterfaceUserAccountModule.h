
#define DLLAPI extern "C"	__declspec( dllexport )

namespace USERACCOUNT
{
	DLLAPI HWND CreateUserAccount(HWND hParent);
	DLLAPI void	ShowUserAccount(int nCmdShow);
	DLLAPI void ShowControlLevel(int nLevel);
	DLLAPI BOOL LoginUserAccount(CString strName, CString strPwd, int* pLevel);
	DLLAPI BOOL ChangeDir(CString strDir);
}

using namespace USERACCOUNT;
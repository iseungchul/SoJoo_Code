#if !defined(AFX_PANEMANUALCONTROL_H__6F420A72_BDF9_4F80_B9BB_E3AC25C7162C__INCLUDED_)
#define AFX_PANEMANUALCONTROL_H__6F420A72_BDF9_4F80_B9BB_E3AC25C7162C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControl form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "USimpleTab.h"

class	CPaneManualControlDevice;
class	CPaneManualControlLaser;
class   CPaneManualControlLaserUV;
class	CPaneManualControlPowerMeasurement;
class	CPaneManualControlScannerCalibration;
class	CPaneManualControlVision;
#ifdef __KUNSAN_SAMSUNG_LARGE__
	class	CPaneManualControlOneHoleLarge;
#else
	class	CPaneManualControlOneHole;
#endif
class	CPaneManualControlIO;
//class	CPaneManualControlScannerCalibrationPos;
//class	CPaneManualControlParameter;
class	CPaneRecipeGenParameterNew;

#ifdef __PUSAN1__	
	class	CPaneManualControlMotorPusan1;
#endif
	
#ifdef __PUSAN2__ 
	class	CPaneManualControlMotorPusan1;
#endif

#ifdef __OSAN_LG__ 
	class	CPaneManualControlMotorPusan1;
#endif

#ifdef __KUNSAN_6__	
	class	CPaneManualControlMotorKunsan6;
#endif
	
#ifdef __KUNSAN_8__	
	class	CPaneManualControlMotorKunsan6;
#endif
	
#ifdef __PUSAN_OLD_17__
	class	CPaneManualControlMotorPusan1;
//	class	CPaneManualControlMotor;
#endif
	
#ifdef __PUSAN_OLD_32__
	class	CPaneManualControlMotor;
#endif

#ifdef __PUSAN_LDD__
	class	CPaneManualControlMotorLDD;
#endif

#ifdef __KUNSAN_1__	
	class	CPaneManualControlMotorKunsan1;
#endif

#ifdef __KUNSAN_SAMSUNG_LARGE__ 
	class	CPaneManualControlMotorLarge;
#endif
class CPaneManualControl : public CFormView
{
protected:
	CPaneManualControl();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControl)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControl)
	enum { IDD = IDD_DLG_MANUAL_CONTROL };
	USimpleTab	m_tabManualControl;
	//}}AFX_DATA

// Attributes
public:
	
#ifdef __PUSAN1__	
	CPaneManualControlMotorPusan1*	m_pMotor;
#endif
	
#ifdef __PUSAN2__ 
	CPaneManualControlMotorPusan1*	m_pMotor;
#endif

#ifdef __OSAN_LG__
	CPaneManualControlMotorPusan1*	m_pMotor;
#endif

#ifdef __KUNSAN_6__	
	CPaneManualControlMotorKunsan6*	m_pMotor;
#endif

#ifdef __KUNSAN_8__	
	CPaneManualControlMotorKunsan6*	m_pMotor;
#endif
	
#ifdef __PUSAN_OLD_17__
//	CPaneManualControlMotor*	m_pMotor;
	CPaneManualControlMotorPusan1*	m_pMotor;
#endif

#ifdef __PUSAN_OLD_32__
	CPaneManualControlMotor*	m_pMotor;
#endif

#ifdef __PUSAN_LDD__
	CPaneManualControlMotorLDD*	m_pMotor;
#endif

#ifdef __KUNSAN_1__	
	CPaneManualControlMotorKunsan1*	m_pMotor;
#endif
#ifdef __KUNSAN_SAMSUNG_LARGE__ 
	CPaneManualControlMotorLarge*	m_pMotor;
#endif


	CPaneManualControlDevice*		m_pDevice;
	CPaneManualControlLaser*		m_pLaser;
	CPaneManualControlLaserUV*		m_pLaserUV;
	CPaneManualControlScannerCalibration* m_pScannerCalibration;
	CPaneManualControlVision*		m_pVision;
#ifdef __KUNSAN_SAMSUNG_LARGE__
	CPaneManualControlOneHoleLarge*	m_pOneHole;
#else
	CPaneManualControlOneHole*		m_pOneHole;
#endif
	CPaneManualControlPowerMeasurement*		m_pPowerMeasurement;
	CPaneManualControlIO*			m_pIO;
//	CPaneManualControlScannerCalibrationPos* m_pScannerCalibrationPos;
//	CPaneManualControlParameter*	m_pParameter;
	CPaneRecipeGenParameterNew*		m_pParameter;

// Operations
public:
	void EnableTab(BOOL bEnable);
	CPaneManualControlVision* GetVisionTab();
	void InitTabControl();
	void ShowTabPane(int nPaneNo, BOOL bSetFid = FALSE);
	int	GetShowPane() {return m_nPaneNo;};
	int	GetTabCurSel();
	BOOL GetLaserPower();
	void SetData(int nPane);

	void SetAuthorityByLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControl)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControl();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntTab;
	
	int			m_nPaneNo;

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControl)
	afx_msg void OnClickTabManualControl(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROL_H__6F420A72_BDF9_4F80_B9BB_E3AC25C7162C__INCLUDED_)

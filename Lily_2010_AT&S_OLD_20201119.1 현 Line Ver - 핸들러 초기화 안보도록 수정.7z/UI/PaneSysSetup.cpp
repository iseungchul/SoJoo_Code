// PaneSysSetup.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetup.h"

#include "PaneSysSetupDir.h"

#ifdef __PUSAN1__	
	#include "PaneSysSetupLaserScannerPusan1.h"
	#include "PaneSysSetupMotorPusan1.h"
	#include "PaneSysSetupBeamDumperPusan1.h"
	#ifdef __3RDAOD__
		#include "PaneSysSetupBeamPath3RDAOD.h"
	#else
		#include "PaneSysSetupBeamPathPusan1.h"
	#endif
#endif

#ifdef __PUSAN2__ 
	#include "PaneSysSetupLaserScannerPusan1.h"
	#include "PaneSysSetupMotorPusan1.h"
	#include "PaneSysSetupBeamDumperPusan1.h"
	#ifdef __3RDAOD__
		#include "PaneSysSetupBeamPath3RDAOD.h"
	#else
		#include "PaneSysSetupBeamPathPusan1.h"
	#endif
#endif

#ifdef __OSAN_LG__ 
	#include "PaneSysSetupLaserScannerPusan1.h"
	#include "PaneSysSetupMotorPusan1.h"
	#include "PaneSysSetupBeamDumperPusan1.h"
	#ifdef __3RDAOD__
		#include "PaneSysSetupBeamPath3RDAOD.h"
	#else
		#include "PaneSysSetupBeamPathPusan1.h"
	#endif
#endif

#ifdef __PUSAN_OLD_17__
	#include "PaneSysSetupLaserScannerPusan1.h"
	#include "PaneSysSetupMotorPusan1.h"
//	#include "PaneSysSetupBeamPath.h"
//	#include "PaneSysSetupBeamDumper.h"
	#include "PaneSysSetupBeamDumperPusan1.h"
	#ifdef __3RDAOD__
		#include "PaneSysSetupBeamPath3RDAOD.h"
	#else
		#include "PaneSysSetupBeamPathPusan1.h"
	#endif
#endif

#ifdef __PUSAN_OLD_32__
	#include "PaneSysSetupLaserScannerPusan1.h"
	#include "PaneSysSetupMotor.h"
	#include "PaneSysSetupBeamDumperPusan1.h"
	#ifdef __3RDAOD__
		#include "PaneSysSetupBeamPath3RDAOD.h"
	#else
		#include "PaneSysSetupBeamPath.h"
	#endif
#endif

#ifdef __KUNSAN_6__	
	#include "PaneSysSetupLaserScannerPusan1.h"
	#include "PaneSysSetupMotorPusan1.h"
	#include "PaneSysSetupBeamDumperPusan1.h"
	#ifdef __3RDAOD__
		#include "PaneSysSetupBeamPath3RDAOD.h"
	#else
		#include "PaneSysSetupBeamPathPusan1.h"
	#endif
#endif

#ifdef __KUNSAN_8__	
	#include "PaneSysSetupLaserScanner.h"
	#include "PaneSysSetupMotor.h"
	#include "PaneSysSetupBeamDumperKunsan8.h"
	#include "PaneSysSetupBeamPathKunsan8.h"
#endif

#ifdef __PUSAN_LDD__	
	#include "PaneSysSetupLaserScannerPusan1.h"
	#include "PaneSysSetupMotorPusan1.h"
	#include "PaneSysSetupBeamDumperPusan1.h"
	#ifdef __3RDAOD__
		#include "PaneSysSetupBeamPath3RDAOD.h"
	#else
		#include "PaneSysSetupBeamPathLDD.h"
	#endif
#endif

#ifdef __KUNSAN_1__	
	#include "PaneSysSetupLaserScannerPusan1.h"
	#include "PaneSysSetupMotor.h"
	
	#include "PaneSysSetupBeamDumperPusan1.h"
	#ifdef __3RDAOD__
		#include "PaneSysSetupBeamPath3RDAOD.h"
	#else
		#include "PaneSysSetupBeamPathKunsan1.h"
	#endif
#endif
#ifdef __KUNSAN_SAMSUNG_LARGE__ 
	#include "PaneSysSetupLaserScannerLarge.h"
	#include "PaneSysSetupMotorPusan1.h"
	#include "PaneSysSetupBeamDumperPusan1.h"
	#include "PaneSysSetupBeamPathLarge.h"
#endif
#include "PaneSysSetupTableCal.h"
#include "PaneSysSetupCollimator.h"
#include "PaneSysSetupBeamDumper.h"
#include "PaneSysSetupMGC.h"
#include "PaneSysSetupMGC2.h"
#include "PaneSysSetupZCal.h"
#include "PaneSysSetupTophat.h"
#include "..\model\DSystemINI.h"
#include "..\model\deasydrillerini.h"
#include "..\EasyDrillerDlg.h"
#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "DlgMatroxVisionView.h"
#include "..\alarmmsg.h"
#include "..\device\hdevicefactory.h"
#include "..\device\devicemotor.h"
#include "..\device\heocard.h"
#include "..\device\hvision.h"
#include "..\device\hvisionomi.h"
#include "PaneSysSetupThetaCal.h"
#include "PaneSysSetupComponentTime.h"
#include "PaneSysSetupVacuum.h"
#include "PaneSysSetupAttenTable.h"

#include "PaneAutoRun.h"
#include "PaneAutoRunViewSystem.h"
#include "model\BeamPathINIFile.h"
#include "model\DBeampathINI.h"
#include "..\model\DTextData.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetup

IMPLEMENT_DYNCREATE(CPaneSysSetup, CFormView)

CPaneSysSetup::CPaneSysSetup()
	: CFormView(CPaneSysSetup::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetup)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pDir					= NULL;
	m_pLaserScanner			= NULL;
	m_pMotor				= NULL;
	m_pTableCal				= NULL;
	m_pCollimator			= NULL;
	m_pBeamDumper			= NULL;
	m_pMGC					= NULL;
	m_pMGC2					= NULL;
	m_pThetaCal				= NULL;
	m_pComponent			= NULL;
	m_pVacuum				= NULL;
	m_pBeamPath				= NULL;
	m_pTophat				= NULL;
	m_pAtt					= NULL;	
	m_nSel					= 0;
}

CPaneSysSetup::~CPaneSysSetup()
{

}

void CPaneSysSetup::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetup)
	DDX_Control(pDX, IDC_TAB_SYS_SETUP, m_tabSysSetup);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetup, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetup)
	ON_WM_DESTROY()
	ON_NOTIFY(NM_CLICK, IDC_TAB_SYS_SETUP, OnClickTabSysSetup)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetup diagnostics

#ifdef _DEBUG
void CPaneSysSetup::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetup::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetup message handlers

void CPaneSysSetup::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitTabControl();
}

void CPaneSysSetup::InitTabControl()
{
	// Set Button Font
	m_fntTab.CreatePointFont(150, "Arial Bold");

	BOOL bRet = 0;

	m_tabSysSetup.SetFont( &m_fntTab );

	// Directory Setting
	bRet = m_tabSysSetup.AddPane( _T(" Path "), RUNTIME_CLASS(CPaneSysSetupDir) );
	if( FALSE != bRet )
	{
		m_pDir = static_cast<CPaneSysSetupDir*>(m_tabSysSetup.GetPane(0));
		m_pDir->OnInitialUpdate();
	}

	// Laser Beam Hole
#ifdef __PUSAN1__	
	bRet = m_tabSysSetup.AddPane( _T(" Align "), RUNTIME_CLASS(CPaneSysSetupLaserScannerPusan1) );
	if( FALSE != bRet )
	{
		m_pLaserScanner = static_cast<CPaneSysSetupLaserScannerPusan1*>(m_tabSysSetup.GetPane(1));
		m_pLaserScanner->OnInitialUpdate();
	}
	// Motor Setting
	bRet = m_tabSysSetup.AddPane( _T(" Device "), RUNTIME_CLASS(CPaneSysSetupMotorPusan1) );
	if( FALSE != bRet )
	{
		m_pMotor = static_cast<CPaneSysSetupMotorPusan1*>(m_tabSysSetup.GetPane(2));
		m_pMotor->OnInitialUpdate();
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}
#endif
	
#ifdef __PUSAN2__ 
	bRet = m_tabSysSetup.AddPane( _T(" Align "), RUNTIME_CLASS(CPaneSysSetupLaserScannerPusan1) );
	if( FALSE != bRet )
	{
		m_pLaserScanner = static_cast<CPaneSysSetupLaserScannerPusan1*>(m_tabSysSetup.GetPane(1));
		m_pLaserScanner->OnInitialUpdate();
	}
	// Motor Setting
	bRet = m_tabSysSetup.AddPane( _T(" Device "), RUNTIME_CLASS(CPaneSysSetupMotorPusan1) );
	if( FALSE != bRet )
	{
		m_pMotor = static_cast<CPaneSysSetupMotorPusan1*>(m_tabSysSetup.GetPane(2));
		m_pMotor->OnInitialUpdate();
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}
#endif

#ifdef __OSAN_LG__ 
	bRet = m_tabSysSetup.AddPane( _T(" Align "), RUNTIME_CLASS(CPaneSysSetupLaserScannerPusan1) );
	if( FALSE != bRet )
	{
		m_pLaserScanner = static_cast<CPaneSysSetupLaserScannerPusan1*>(m_tabSysSetup.GetPane(1));
		m_pLaserScanner->OnInitialUpdate();
	}
	// Motor Setting
	bRet = m_tabSysSetup.AddPane( _T(" Device "), RUNTIME_CLASS(CPaneSysSetupMotorPusan1) );
	if( FALSE != bRet )
	{
		m_pMotor = static_cast<CPaneSysSetupMotorPusan1*>(m_tabSysSetup.GetPane(2));
		m_pMotor->OnInitialUpdate();
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}
#endif

#ifdef __KUNSAN_6__	
	bRet = m_tabSysSetup.AddPane( _T(" Align "), RUNTIME_CLASS(CPaneSysSetupLaserScannerPusan1) );
	if( FALSE != bRet )
	{
		m_pLaserScanner = static_cast<CPaneSysSetupLaserScannerPusan1*>(m_tabSysSetup.GetPane(1));
		m_pLaserScanner->OnInitialUpdate();
	}
	// Motor Setting
	bRet = m_tabSysSetup.AddPane( _T(" Device "), RUNTIME_CLASS(CPaneSysSetupMotorPusan1) );
	if( FALSE != bRet )
	{
		m_pMotor = static_cast<CPaneSysSetupMotorPusan1*>(m_tabSysSetup.GetPane(2));
		m_pMotor->OnInitialUpdate();
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}
#endif

#ifdef __KUNSAN_8__	
	bRet = m_tabSysSetup.AddPane( _T(" Align "), RUNTIME_CLASS(CPaneSysSetupLaserScanner) );
	if( FALSE != bRet )
	{
		m_pLaserScanner = static_cast<CPaneSysSetupLaserScanner*>(m_tabSysSetup.GetPane(1));
		m_pLaserScanner->OnInitialUpdate();
	}
	// Motor Setting
	bRet = m_tabSysSetup.AddPane( _T(" Device "), RUNTIME_CLASS(CPaneSysSetupMotor) );
	if( FALSE != bRet )
	{
		m_pMotor = static_cast<CPaneSysSetupMotor*>(m_tabSysSetup.GetPane(2));
		m_pMotor->OnInitialUpdate();
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}
#endif
	
#ifdef __PUSAN_OLD_17__
	bRet = m_tabSysSetup.AddPane( _T(" Align "), RUNTIME_CLASS(CPaneSysSetupLaserScannerPusan1) );
	if( FALSE != bRet )
	{
		m_pLaserScanner = static_cast<CPaneSysSetupLaserScannerPusan1*>(m_tabSysSetup.GetPane(1));
		m_pLaserScanner->OnInitialUpdate();
	}
		// Motor Setting
	bRet = m_tabSysSetup.AddPane( _T(" Device "), RUNTIME_CLASS(CPaneSysSetupMotorPusan1) );
	if( FALSE != bRet )
	{
		m_pMotor = static_cast<CPaneSysSetupMotorPusan1*>(m_tabSysSetup.GetPane(2));
		m_pMotor->OnInitialUpdate();
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}
/*	// Motor Setting
	bRet = m_tabSysSetup.AddPane( _T(" Device "), RUNTIME_CLASS(CPaneSysSetupMotor) );
	if(FALSE != bRet )
	{
		m_pMotor = static_cast<CPaneSysSetupMotor*>(m_tabSysSetup.GetPane(2));
		m_pMotor->OnInitialUpdate();
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}
	*/
#endif

#ifdef __PUSAN_OLD_32__
	bRet = m_tabSysSetup.AddPane( _T(" Align "), RUNTIME_CLASS(CPaneSysSetupLaserScannerPusan1) );
	if( FALSE != bRet )
	{
		m_pLaserScanner = static_cast<CPaneSysSetupLaserScannerPusan1*>(m_tabSysSetup.GetPane(1));
		m_pLaserScanner->OnInitialUpdate();
	}
	// Motor Setting
	bRet = m_tabSysSetup.AddPane( _T(" Device "), RUNTIME_CLASS(CPaneSysSetupMotor) );
	if( FALSE != bRet )
	{
		m_pMotor = static_cast<CPaneSysSetupMotor*>(m_tabSysSetup.GetPane(2));
		m_pMotor->OnInitialUpdate();
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}
#endif

#ifdef __PUSAN_LDD__
	bRet = m_tabSysSetup.AddPane( _T(" Align "), RUNTIME_CLASS(CPaneSysSetupLaserScannerPusan1) );
	if( FALSE != bRet )
	{
		m_pLaserScanner = static_cast<CPaneSysSetupLaserScannerPusan1*>(m_tabSysSetup.GetPane(1));
		m_pLaserScanner->OnInitialUpdate();
	}
	// Motor Setting
	bRet = m_tabSysSetup.AddPane( _T(" Device "), RUNTIME_CLASS(CPaneSysSetupMotorPusan1) );
	if( FALSE != bRet )
	{
		m_pMotor = static_cast<CPaneSysSetupMotorPusan1*>(m_tabSysSetup.GetPane(2));
		m_pMotor->OnInitialUpdate();
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}
#endif

#ifdef __KUNSAN_1__	
	bRet = m_tabSysSetup.AddPane( _T(" Align "), RUNTIME_CLASS(CPaneSysSetupLaserScannerPusan1) );
	if( FALSE != bRet )
	{
		m_pLaserScanner = static_cast<CPaneSysSetupLaserScannerPusan1*>(m_tabSysSetup.GetPane(1));
		m_pLaserScanner->OnInitialUpdate();
	}
	// Motor Setting
	bRet = m_tabSysSetup.AddPane( _T(" Device "), RUNTIME_CLASS(CPaneSysSetupMotor) );
	if( FALSE != bRet )
	{
		m_pMotor = static_cast<CPaneSysSetupMotor*>(m_tabSysSetup.GetPane(2));
		m_pMotor->OnInitialUpdate();
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}
#endif
	
#ifdef __KUNSAN_SAMSUNG_LARGE__ 
	bRet = m_tabSysSetup.AddPane( _T(" Align "), RUNTIME_CLASS(CPaneSysSetupLaserScannerLarge) );
	if( FALSE != bRet )
	{
		m_pLaserScanner = static_cast<CPaneSysSetupLaserScannerLarge*>(m_tabSysSetup.GetPane(1));
		m_pLaserScanner->OnInitialUpdate();
	}
	// Motor Setting
	bRet = m_tabSysSetup.AddPane( _T(" Device "), RUNTIME_CLASS(CPaneSysSetupMotorPusan1) );
	if( FALSE != bRet )
	{
		m_pMotor = static_cast<CPaneSysSetupMotorPusan1*>(m_tabSysSetup.GetPane(2));
		m_pMotor->OnInitialUpdate();
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}
#endif

	int nPanel = 3;
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_COMIZOA &&
		gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_PMAC)
	{
		// Table Calibration
		bRet = m_tabSysSetup.AddPane( _T(" TableCal "), RUNTIME_CLASS(CPaneSysSetupTableCal) );
		if( FALSE != bRet )
		{
			m_pTableCal = static_cast<CPaneSysSetupTableCal*>(m_tabSysSetup.GetPane(nPanel++));
			m_pTableCal->OnInitialUpdate();
		}

		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
		{
			#ifdef __3RDAOD__
				#ifdef __KUNSAN_SAMSUNG_LARGE__
					bRet = m_tabSysSetup.AddPane( _T(" BeamPath "), RUNTIME_CLASS(CPaneSysSetupBeamPathLarge) );
					if( FALSE != bRet )
					{
						m_pBeamPath = static_cast<CPaneSysSetupBeamPathLarge*>(m_tabSysSetup.GetPane(nPanel++));
						m_pBeamPath->OnInitialUpdate();
						m_pBeamPath->SetBeamPath(gBeamPathINI.m_sBeampath);
						m_pBeamPath->InitListControl();
					}
				#elif defined __KUNSAN_8__	
					bRet = m_tabSysSetup.AddPane( _T(" BeamPath "), RUNTIME_CLASS(CPaneSysSetupBeamPathKunsan8) );
					if( FALSE != bRet )
					{
						m_pBeamPath = static_cast<CPaneSysSetupBeamPathKunsan8*>(m_tabSysSetup.GetPane(nPanel++));
						m_pBeamPath->OnInitialUpdate();
						m_pBeamPath->SetBeamPath(gBeamPathINI.m_sBeampath);
						m_pBeamPath->InitListControl();
					}
				#else
					bRet = m_tabSysSetup.AddPane( _T(" BeamPath "), RUNTIME_CLASS(CPaneSysSetupBeamPath3RDAOD) );
					if( FALSE != bRet )
					{
						m_pBeamPath = static_cast<CPaneSysSetupBeamPath3RDAOD*>(m_tabSysSetup.GetPane(nPanel++));
						m_pBeamPath->OnInitialUpdate();
						m_pBeamPath->SetBeamPath(gBeamPathINI.m_sBeampath);
						m_pBeamPath->InitListControl();
					}
				#endif
			#else
				#ifdef __PUSAN1__	
				
						bRet = m_tabSysSetup.AddPane( _T(" BeamPath "), RUNTIME_CLASS(CPaneSysSetupBeamPathPusan1) );
						if( FALSE != bRet )
						{
							m_pBeamPath = static_cast<CPaneSysSetupBeamPathPusan1*>(m_tabSysSetup.GetPane(nPanel++));
							m_pBeamPath->OnInitialUpdate();
							m_pBeamPath->SetBeamPath(gBeamPathINI.m_sBeampath);
							m_pBeamPath->InitListControl();
						}
				#endif
				
				#ifdef __PUSAN2__ 
					bRet = m_tabSysSetup.AddPane( _T(" BeamPath "), RUNTIME_CLASS(CPaneSysSetupBeamPathPusan1) );
					if( FALSE != bRet )
					{
						m_pBeamPath = static_cast<CPaneSysSetupBeamPathPusan1*>(m_tabSysSetup.GetPane(nPanel++));
						m_pBeamPath->OnInitialUpdate();
						m_pBeamPath->SetBeamPath(gBeamPathINI.m_sBeampath);
						m_pBeamPath->InitListControl();
					}
				#endif

				
				#ifdef __OSAN_LG__ 
					bRet = m_tabSysSetup.AddPane( _T(" BeamPath "), RUNTIME_CLASS(CPaneSysSetupBeamPathPusan1) );
					if( FALSE != bRet )
					{
						m_pBeamPath = static_cast<CPaneSysSetupBeamPathPusan1*>(m_tabSysSetup.GetPane(nPanel++));
						m_pBeamPath->OnInitialUpdate();
						m_pBeamPath->SetBeamPath(gBeamPathINI.m_sBeampath);
						m_pBeamPath->InitListControl();
					}
				#endif

				#ifdef __KUNSAN_6__	
					bRet = m_tabSysSetup.AddPane( _T(" BeamPath "), RUNTIME_CLASS(CPaneSysSetupBeamPathPusan1) );
					if( FALSE != bRet )
					{
						m_pBeamPath = static_cast<CPaneSysSetupBeamPathPusan1*>(m_tabSysSetup.GetPane(nPanel++));
						m_pBeamPath->OnInitialUpdate();
						m_pBeamPath->SetBeamPath(gBeamPathINI.m_sBeampath);
						m_pBeamPath->InitListControl();
					}
				#endif
							
				#ifdef __PUSAN_OLD_17__
					bRet = m_tabSysSetup.AddPane( _T(" BeamPath "), RUNTIME_CLASS(CPaneSysSetupBeamPathPusan1) );
					if( FALSE != bRet )
					{
						m_pBeamPath = static_cast<CPaneSysSetupBeamPathPusan1*>(m_tabSysSetup.GetPane(nPanel++));
						m_pBeamPath->OnInitialUpdate();
						m_pBeamPath->SetBeamPath(gBeamPathINI.m_sBeampath);
						m_pBeamPath->InitListControl();
					}
				#endif

				#ifdef __PUSAN_OLD_32__
					bRet = m_tabSysSetup.AddPane( _T(" BeamPath "), RUNTIME_CLASS(CPaneSysSetupBeamPath) );
					if( FALSE != bRet )
					{
						m_pBeamPath = static_cast<CPaneSysSetupBeamPath*>(m_tabSysSetup.GetPane(nPanel++));
						m_pBeamPath->OnInitialUpdate();
						m_pBeamPath->SetBeamPath(gBeamPathINI.m_sBeampath);
						m_pBeamPath->InitListControl();
					}
				#endif

				#ifdef __PUSAN_LDD__	
					bRet = m_tabSysSetup.AddPane( _T(" BeamPath "), RUNTIME_CLASS(CPaneSysSetupBeamPathLDD) );
					if( FALSE != bRet )
					{
						m_pBeamPath = static_cast<CPaneSysSetupBeamPathLDD*>(m_tabSysSetup.GetPane(nPanel++));
						m_pBeamPath->OnInitialUpdate();
						m_pBeamPath->SetBeamPath(gBeamPathINI.m_sBeampath);
						m_pBeamPath->InitListControl();
					}
				#endif

				#ifdef __KUNSAN_1__	
					bRet = m_tabSysSetup.AddPane( _T(" BeamPath "), RUNTIME_CLASS(CPaneSysSetupBeamPathKunsan1) );
					if( FALSE != bRet )
					{
						m_pBeamPath = static_cast<CPaneSysSetupBeamPathKunsan1*>(m_tabSysSetup.GetPane(nPanel++));
						m_pBeamPath->OnInitialUpdate();
						m_pBeamPath->SetBeamPath(gBeamPathINI.m_sBeampath);
						m_pBeamPath->InitListControl();
					}
				#endif

				
			#endif
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
		{
			// Collimator Setting
			bRet = m_tabSysSetup.AddPane( _T(" Attenuator "), RUNTIME_CLASS(CPaneSysSetupCollimator) );
			if( FALSE != bRet )
			{
				m_pCollimator = static_cast<CPaneSysSetupCollimator*>(m_tabSysSetup.GetPane(nPanel++));
				m_pCollimator->OnInitialUpdate();
				m_pCollimator->SetSystemCollimator( gSystemINI.m_sSystemCollimator );
			}
		}

		// Z Calibration
		if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() != 0)
		{
			bRet = m_tabSysSetup.AddPane( _T(" Z Cal "), RUNTIME_CLASS(CPaneSysSetupZCal) );
			if( FALSE != bRet )
			{
				m_pZCal = static_cast<CPaneSysSetupZCal*>(m_tabSysSetup.GetPane(nPanel++));
				m_pZCal->OnInitialUpdate();

			}
		}

	}

	// MGC
	if(gEasyDrillerINI.m_clsHwOption.m_nMGCMode == 0)
	{
		bRet = m_tabSysSetup.AddPane( _T(" MGC "), RUNTIME_CLASS(CPaneSysSetupMGC) );
		if( FALSE != bRet )
		{
			m_pMGC = static_cast<CPaneSysSetupMGC*>(m_tabSysSetup.GetPane(nPanel++));
			m_pMGC->OnInitialUpdate();
		}
	}
	else
	{
		bRet = m_tabSysSetup.AddPane( _T(" MGC "), RUNTIME_CLASS(CPaneSysSetupMGC2) );
		if( FALSE != bRet )
		{
			m_pMGC2 = static_cast<CPaneSysSetupMGC2*>(m_tabSysSetup.GetPane(nPanel++));
			m_pMGC2->OnInitialUpdate();
		}
	}
	
	// Beam Dumper 20070730
#ifdef __PUSAN1__	
	if(gSystemINI.m_sHardWare.nUseBeamDumper)
	{
		bRet = m_tabSysSetup.AddPane( _T(" Dummy Free"), RUNTIME_CLASS(CPaneSysSetupBeamDumperPusan1) );
		if( FALSE != bRet )
		{
			m_pBeamDumper = static_cast<CPaneSysSetupBeamDumperPusan1*>(m_tabSysSetup.GetPane(nPanel++));
			m_pBeamDumper->OnInitialUpdate();
			m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
		}
		m_nBeamDumperNo = nPanel - 1;
	}
#endif
	
#ifdef __PUSAN2__ 
	if(gSystemINI.m_sHardWare.nUseBeamDumper)
	{
		bRet = m_tabSysSetup.AddPane( _T(" Dummy Free"), RUNTIME_CLASS(CPaneSysSetupBeamDumperPusan1) );
		if( FALSE != bRet )
		{
			m_pBeamDumper = static_cast<CPaneSysSetupBeamDumperPusan1*>(m_tabSysSetup.GetPane(nPanel++));
			m_pBeamDumper->OnInitialUpdate();
			m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
		}
		m_nBeamDumperNo = nPanel - 1;
	}
#endif

#ifdef __OSAN_LG__ 
	if(gSystemINI.m_sHardWare.nUseBeamDumper)
	{
		bRet = m_tabSysSetup.AddPane( _T(" Dummy Free"), RUNTIME_CLASS(CPaneSysSetupBeamDumperPusan1) );
		if( FALSE != bRet )
		{
			m_pBeamDumper = static_cast<CPaneSysSetupBeamDumperPusan1*>(m_tabSysSetup.GetPane(nPanel++));
			m_pBeamDumper->OnInitialUpdate();
			m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
		}
		m_nBeamDumperNo = nPanel - 1;
	}
#endif

#ifdef __KUNSAN_6__	
	if(gSystemINI.m_sHardWare.nUseBeamDumper)
	{
		bRet = m_tabSysSetup.AddPane( _T(" Dummy Free"), RUNTIME_CLASS(CPaneSysSetupBeamDumperPusan1) );
		if( FALSE != bRet )
		{
			m_pBeamDumper = static_cast<CPaneSysSetupBeamDumperPusan1*>(m_tabSysSetup.GetPane(nPanel++));
			m_pBeamDumper->OnInitialUpdate();
			m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
		}
		m_nBeamDumperNo = nPanel - 1;
	}
#endif

#ifdef __KUNSAN_8__	
	if(gSystemINI.m_sHardWare.nUseBeamDumper)
	{
		bRet = m_tabSysSetup.AddPane( _T(" Dummy Free"), RUNTIME_CLASS(CPaneSysSetupBeamDumperKunsan8) );
		if( FALSE != bRet )
		{
			m_pBeamDumper = static_cast<CPaneSysSetupBeamDumperKunsan8*>(m_tabSysSetup.GetPane(nPanel++));
			m_pBeamDumper->OnInitialUpdate();
			m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
		}
		m_nBeamDumperNo = nPanel - 1;
	}
#endif
	
#ifdef __PUSAN_OLD_17__
	if(gSystemINI.m_sHardWare.nUseBeamDumper)
	{
		bRet = m_tabSysSetup.AddPane( _T(" Dummy Free"), RUNTIME_CLASS(CPaneSysSetupBeamDumperPusan1) );
		if( FALSE != bRet )
		{
			m_pBeamDumper = static_cast<CPaneSysSetupBeamDumperPusan1*>(m_tabSysSetup.GetPane(nPanel++));
			m_pBeamDumper->OnInitialUpdate();
			m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
		}
		m_nBeamDumperNo = nPanel - 1;
	}
#endif

#ifdef __PUSAN_OLD_32__
	if(gSystemINI.m_sHardWare.nUseBeamDumper)
	{
		bRet = m_tabSysSetup.AddPane( _T(" Dummy Free"), RUNTIME_CLASS(CPaneSysSetupBeamDumperPusan1) );
		if( FALSE != bRet )
		{
			m_pBeamDumper = static_cast<CPaneSysSetupBeamDumperPusan1*>(m_tabSysSetup.GetPane(nPanel++));
			m_pBeamDumper->OnInitialUpdate();
			m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
		}
		m_nBeamDumperNo = nPanel - 1;
	}
#endif
	
#ifdef __PUSAN_LDD__	
	if(gSystemINI.m_sHardWare.nUseBeamDumper)
	{
		bRet = m_tabSysSetup.AddPane( _T(" Dummy Free"), RUNTIME_CLASS(CPaneSysSetupBeamDumperPusan1) );
		if( FALSE != bRet )
		{
			m_pBeamDumper = static_cast<CPaneSysSetupBeamDumperPusan1*>(m_tabSysSetup.GetPane(nPanel++));
			m_pBeamDumper->OnInitialUpdate();
			m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
		}
		m_nBeamDumperNo = nPanel - 1;
	}
#endif

#ifdef __KUNSAN_1__	
	if(gSystemINI.m_sHardWare.nUseBeamDumper)
	{
		bRet = m_tabSysSetup.AddPane( _T(" Dummy Free"), RUNTIME_CLASS(CPaneSysSetupBeamDumperPusan1) );
		if( FALSE != bRet )
		{
			m_pBeamDumper = static_cast<CPaneSysSetupBeamDumperPusan1*>(m_tabSysSetup.GetPane(nPanel++));
			m_pBeamDumper->OnInitialUpdate();
			m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
		}
		m_nBeamDumperNo = nPanel - 1;
	}
#endif
#ifdef __KUNSAN_SAMSUNG_LARGE__ 
	if(gSystemINI.m_sHardWare.nUseBeamDumper)
	{
		bRet = m_tabSysSetup.AddPane( _T(" Dummy Free"), RUNTIME_CLASS(CPaneSysSetupBeamDumperPusan1) );
		if( FALSE != bRet )
		{
			m_pBeamDumper = static_cast<CPaneSysSetupBeamDumperPusan1*>(m_tabSysSetup.GetPane(nPanel++));
			m_pBeamDumper->OnInitialUpdate();
			m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
		}
		m_nBeamDumperNo = nPanel - 1;
	}
#endif
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		bRet = m_tabSysSetup.AddPane( _T(" Theta Calibration "), RUNTIME_CLASS(CPaneSysSetupThetaCal) );
		if( FALSE != bRet )
		{
			m_pThetaCal = static_cast<CPaneSysSetupThetaCal*>(m_tabSysSetup.GetPane(nPanel++));
			m_pThetaCal->OnInitialUpdate();
		}
	}

/*	// Vacuum
	bRet = m_tabSysSetup.AddPane( _T(" Vacuum "), RUNTIME_CLASS(CPaneSysSetupVacuum) );
	if( FALSE != bRet )
	{
		m_pVacuum = static_cast<CPaneSysSetupVacuum*>(m_tabSysSetup.GetPane(nPanel++));
		m_pVacuum->OnInitialUpdate();
		m_pVacuum->SetSystemVacuum( gSystemINI.m_sSystemVacuum );
	}
*/
	// component date npanel =9		//������� ���� �ȳ���.  ���Ƴ����� 
	/*bRet = m_tabSysSetup.AddPane( _T(" Component "), RUNTIME_CLASS(CPaneSysSetupComponentTime) );
	if( FALSE != bRet )
	{
		m_pComponent = static_cast<CPaneSysSetupComponentTime*>(m_tabSysSetup.GetPane(nPanel++));
		m_pComponent->OnInitialUpdate();
		m_pComponent->SetSystemComponent(gSystemINI.m_sSystemComponent);
		m_pComponent->SetComponentData();
		m_pComponent->DBConnect();
		m_pComponent->SelectComponentList();
		m_pComponent->UpdateUsingTime();
		m_pComponent->CheckComponentOverDate();	
	}*/

	if(gSystemINI.m_sSystemDevice.nPowerCompenAttenMode != NO_USE_ATTEN)
	{
		bRet = m_tabSysSetup.AddPane( _T(" Att. "), RUNTIME_CLASS(CPaneSysSetupAttenTable) );
		if( FALSE != bRet )
		{
			m_pAtt = static_cast<CPaneSysSetupAttenTable*>(m_tabSysSetup.GetPane(nPanel++));
			m_pAtt->OnInitialUpdate();
		}
	}

	m_tabSysSetup.ShowPane( m_nSel );
}

void CPaneSysSetup::OnDestroy() 
{
	m_fntTab.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneSysSetup::OnApply()
{
	CString strMessage, strDir, strMotor, strCollimator, strDumper, strTophat, strComponent,strBeamPath;
	if( NULL != m_pDir )
	{
		strDir = m_pDir->GetChangeValueStr();
		if(0 != strDir.CompareNoCase(""))
		{
			strMessage.Format(_T("Directory Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strDir));
			m_pDir->GetDirData();
		}
		

/*		TCHAR sz1stFile[255], sz2ndFile[255];
		lstrcpy(sz1stFile, gEasyDrillerINI.m_clsDirPath.Get1stMasterCalFilePath());
		lstrcpy(sz2ndFile, gEasyDrillerINI.m_clsDirPath.Get2ndMasterCalFilePath());
		
		if(!gDeviceFactory.GetEocard()->LoadCalibrationFile(sz1stFile, sz2ndFile))
		{
#ifndef __TEST__
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
			strMsg.Format(strString, _T("ASC"));
			ErrMessage(strMsg);

			CString strTemp;
			strTemp.Format(_T("%s or %s"), gEasyDrillerINI.m_clsDirPath.Get1stMasterCalFilePath(), gEasyDrillerINI.m_clsDirPath.Get2ndMasterCalFilePath());
			strMsg.Format(strString, strTemp);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
			return;
#endif
		}
*/	}

	if( NULL != m_pMotor )
	{
		m_pMotor->OnApply();
		strMotor = m_pMotor->GetChangeValueStr();
		m_pMotor->GetSystemDevice( &gSystemINI.m_sSystemDevice );

		gDeviceFactory.GetMotor()->SetAxisInfo( gSystemINI.m_sAxisInfo );
		gDeviceFactory.GetMotor()->DownloadAxisInfo();
		gDeviceFactory.GetEocard()->SetFieldSizeToEocard();
		gDeviceFactory.GetMotor()->SetWaterFlow1Value(gSystemINI.m_sSystemDevice.dWaterFlowSetting1);
		gDeviceFactory.GetMotor()->SetWaterFlow2Value(gSystemINI.m_sSystemDevice.dWaterFlowSetting2);
		gDeviceFactory.GetMotor()->SetMainAirValue(gSystemINI.m_sSystemDevice.dMainAirSetting);
		gDeviceFactory.GetMotor()->SetDustSuctionValue(gSystemINI.m_sSystemDevice.dDustSuctionSetting);
		gDeviceFactory.GetMotor()->SetTableVauumValue(TRUE, gSystemINI.m_sSystemDevice.dTableVacuumSetting1);
		gDeviceFactory.GetMotor()->SetTableVauumValue(FALSE, gSystemINI.m_sSystemDevice.dTableVacuumSetting2);
//		gDeviceFactory.GetVision()->SetPixel( 0, gSystemINI.m_sSystemDevice.d1stHighPixel );
//		gDeviceFactory.GetVision()->SetPixel( 1, gSystemINI.m_sSystemDevice.d1stLowPixel );
//		gDeviceFactory.GetVision()->SetPixel( 2, gSystemINI.m_sSystemDevice.d2ndHighPixel );
//		gDeviceFactory.GetVision()->SetPixel( 3, gSystemINI.m_sSystemDevice.d2ndLowPixel );

		gDeviceFactory.GetVision()->TransformPixel();
		if(0 != strMotor.CompareNoCase(""))
		{
			strMessage.Format(_T("Device Setting Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strMotor));
		}
	}

	if( NULL != m_pCollimator )
	{
		m_pCollimator->OnApply();
		strCollimator = m_pCollimator->GetChangeValueStr();
		m_pCollimator->GetSystemCollimator( &gSystemINI.m_sSystemCollimator );

//		gDeviceFactory.GetMotor()->SetFixedMaskPos( gBeamPathINI.m_sBeampath.nFixedMask);

		if(0 != strCollimator.CompareNoCase(""))
		{
			strMessage.Format(_T("Collimator Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strCollimator));
		}
	}

	if( NULL != m_pTophat )
	{
		m_pTophat->OnApply();
		strTophat = m_pTophat->GetChangeValueStr();
		m_pTophat->GetSystemTophat( &gSystemINI.m_sSystemTophat );
		
		
		if(0 != strTophat.CompareNoCase(""))
		{
			strMessage.Format(_T("Tophat Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strTophat));
		}
	}

	//2011604
	if( NULL != m_pComponent )
	{
		m_pComponent->OnApply();
		strComponent = m_pComponent->GetChangeValueStr();
		m_pComponent->GetSystemComponent( &gSystemINI.m_sSystemComponent );
 		
 		
 		if(0 != strComponent.CompareNoCase(""))
 		{
 			strMessage.Format(_T("Component Save "));
 			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strComponent));
 		}
	}


	if( NULL != m_pBeamDumper) // 20070730
	{
		m_pBeamDumper->OnApply();
		strDumper = m_pBeamDumper->GetChangeValueStr();
		m_pBeamDumper->GetSystemDevice( &gSystemINI.m_sSystemDump );

		if(!gDeviceFactory.GetEocard()->DummyParamSet())
		{
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("Dump Parameter Set Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			ErrMessage(_T("Error : Dummy shot parameter download Failure"));
		}

		if(!gDeviceFactory.GetEocard()->StandbyParamSet())
		{
#ifndef __TEST__
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("Standby Parameter Set Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			ErrMessage(_T("Error : Standby shot parameter download Failure"));
#endif
		}
		
		if(0 != strDumper.CompareNoCase(""))
		{
			strMessage.Format(_T("Beam Dumper Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strDumper));
		}

//		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pSystem->SetSystemData(gSystemINI.m_sSystemDump);
	}

	if( NULL != m_pVacuum )
	{
		m_pVacuum->OnApply();
		strMotor = m_pVacuum->GetChangeValueStr();
		m_pVacuum->GetSystemVacuum( &gSystemINI.m_sSystemVacuum );
		
//		gDeviceFactory.GetMotor()->SetTableVacuumLimit(gSystemINI.m_sSystemVacuum.dTable1Vacuum, gSystemINI.m_sSystemVacuum.dTable2Vacuum);
		
		if(0 != strMotor.CompareNoCase(""))
		{
			strMessage.Format(_T("Vacuum Setting Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strMotor));
		}
	}

	if(NULL !=m_pBeamPath)
	{
		if(!m_pBeamPath->CheckASCValidation())
			return;
		if(!m_pBeamPath->IsValidChangeValue())
			return;

		m_pBeamPath->SaveChangeValue();

		strBeamPath = m_pBeamPath->GetChangeValueStr();
		m_pBeamPath->CheckAnyDoPrework();
		m_pBeamPath->GetBeamPath( &gBeamPathINI.m_sBeampath );
		gDeviceFactory.GetMotor()->SetFixedMaskPos( gBeamPathINI.m_sBeampath.nFixedMask);

		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_DO_CHAGNE_SCAL_PREWORK);
		if(0 != strBeamPath.CompareNoCase(""))
		{
			strMessage.Format(_T("BeamPath Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strDumper));
		}
	}

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, EASYDRILL_INI))
	{
		ErrMsgDlg(STDGNALM109);
	}
	else
	{
		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, SYSTEM_INI))
		{
			ErrMsgDlg(STDGNALM110);
		}
		else
		{
			ErrMessage(IDS_DATA_CHANGED);
			
			gTextData.RemoveAllCharInfo();
			gTextData.RemoveResultData();
			gTextData.InitCharData();
		}

		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, BEAMPATH_INI))
		{
			ErrMsgDlg(STDGNALM114);
		}
	}
}

int CPaneSysSetup::GetTabCurSel()
{
	return m_tabSysSetup.GetCurSel();
}

void CPaneSysSetup::EnableTab(BOOL bEnable)
{
//	m_tabSysSetup.EnableWindow(bEnable);
	m_tabSysSetup.TabChangeEnable(bEnable);
}

void CPaneSysSetup::OnClickTabSysSetup(NMHDR* pNMHDR, LRESULT* pResult) 
{
	((CEasyDrillerDlg*)::AfxGetMainWnd())->ActiveStaticForKeyboardError();
	int nSel = m_tabSysSetup.GetCurSel();
	BOOL bSideVision = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetSideStatus();
	::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_TABLE, FALSE);
	if( nSel == m_nSel )
		return;
	
	if( 1 == nSel )
	{
		m_pLaserScanner->SetShutterStatus();
		if(!bSideVision)
		{
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
		}
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_TABLE, TRUE);
		::AfxGetMainWnd()->SendMessage(UM_TABLE_MODE, TABLE_ELSE);
	}
	else if( 3 == nSel )
	{
		if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA ||
			gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		{
			m_pLaserScanner->StopExternalLaser();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
		}
		else
		{
			m_pLaserScanner->StopExternalLaser();
			if(!bSideVision)
				m_pTableCal->ConnectView();
		}
	}
	else if( 4 == nSel)
	{
		if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM && gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G &&
			gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() != 0 && gSystemINI.m_sHardWare.nUseBeamDumper != 0)
		{
			m_pLaserScanner->StopExternalLaser();
			if(!bSideVision)
				m_pThetaCal->ConnectView();
		}
		else
		{
			m_pLaserScanner->StopExternalLaser();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
		}
		
		m_pBeamPath->SetBeamPath(gBeamPathINI.m_sBeampath);
		m_pBeamPath->InitListControl();		
	}
	else if( 6 == nSel)
	{
		if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM && gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G &&
			gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() == 0 && gSystemINI.m_sHardWare.nUseBeamDumper == 0)
		{
			m_pLaserScanner->StopExternalLaser();
			if(!bSideVision)
				m_pThetaCal->ConnectView();
		}
		else
		{
			m_pLaserScanner->StopExternalLaser();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
		}
	}
	else if( 7 == nSel)
	{
		if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM && gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G &&
			((gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() == 0 && gSystemINI.m_sHardWare.nUseBeamDumper != 0) ||
			(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() != 0 && gSystemINI.m_sHardWare.nUseBeamDumper == 0)))
		{
			m_pLaserScanner->StopExternalLaser();
			if(!bSideVision)
				m_pThetaCal->ConnectView();
		}
		else
		{
			m_pLaserScanner->StopExternalLaser();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
		}
	}
	else if( 8 == nSel)
	{
		if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM && gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G &&
			gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() != 0 && gSystemINI.m_sHardWare.nUseBeamDumper != 0)
		{
			m_pLaserScanner->StopExternalLaser();
			if(!bSideVision)
				m_pThetaCal->ConnectView();
		}
		else
		{
			m_pLaserScanner->StopExternalLaser();
			
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
		}
	}
	else
	{
		m_pLaserScanner->StopExternalLaser();
		
		if(!bSideVision)
		{
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
		}
	}

	m_nSel = nSel;
	ChangeTab();
	
	*pResult = 0;
}

void CPaneSysSetup::ChangeTab()
{
	gDeviceFactory.GetEocard()->SetApplyCalibrationFile(0, TRUE);
	gDeviceFactory.GetEocard()->SetApplyCalibrationFile(1, TRUE);

	if( 0 == m_nSel )
	{
		m_pDir->SetDirData();
	}
	else if( 1 == m_nSel )
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);
		gDeviceFactory.GetEocard()->SetApplyCalibrationFile(0, FALSE);
		gDeviceFactory.GetEocard()->SetApplyCalibrationFile(1, FALSE);
		m_pLaserScanner->m_chkApplyAsc.SetCheck(FALSE);
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_TABLE, TRUE);
		::AfxGetMainWnd()->SendMessage(UM_TABLE_MODE, TABLE_ELSE);
		
	}
	else if( 2 == m_nSel )
	{
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}
//	else if( 4 == m_nSel )
//	{
//		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
//			m_pCollimator->SetSystemCollimator( gSystemINI.m_sSystemCollimator );
//	}
//	else if( 5 == m_nSel )
//	{
//		if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
//			m_pTophat->SetSystemTophat( gSystemINI.m_sSystemTophat );
//	}
//	else if( 8 == m_nSel )
//	{
//		m_pVacuum->SetSystemVacuum( gSystemINI.m_sSystemVacuum );
//	}
	else if( 8 == m_nSel)
	{
		m_pComponent->SetSystemComponent(gSystemINI.m_sSystemComponent);
	}
	else if( 9 == m_nSel)
	{
		if(m_pAtt)
			m_pAtt->SetToolComboBox();
	}
	else if (4 == m_nSel)
	{
		m_pBeamPath->SetBeamPath(gBeamPathINI.m_sBeampath);
	}

	if( m_nBeamDumperNo == m_nSel ) //20070730
	{
		if(m_pBeamDumper)
		{
			m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
//			m_pBeamDumper->SetBeamDumperData();
		}
	}
	else
	{

	}
	::AfxGetMainWnd()->SendMessage( UM_SYSTEMSUB_UI_CHANGE, m_nSel, 0 );
}

void CPaneSysSetup::SetAuthorityByLevel(int nLevel)
{
	if(m_pLaserScanner != NULL)
		m_pLaserScanner->SetAuthorityByLevel(nLevel);

	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 && m_pCollimator != NULL)
		m_pCollimator->SetAuthorityByLevel(nLevel);

	if(m_pDir != NULL)
		m_pDir->SetAuthorityByLevel(nLevel);

	if(m_pMGC != NULL)
		m_pMGC->SetAuthorityByLevel(nLevel);

	if(m_pMGC2 != NULL)
		m_pMGC2->SetAuthorityByLevel(nLevel);

	if(m_pMotor != NULL)
		m_pMotor->SetAuthorityByLevel(nLevel);

	if(m_pTableCal != NULL)
		m_pTableCal->SetAuthorityByLevel(nLevel);

	if(m_pThetaCal != NULL)
		m_pThetaCal->SetAuthorityByLevel(nLevel);

	//201161 ������ �ֱ� 
	//	if(m_pComponent != NULL)	
//		m_pComponent->SetAuthorityByLevel(nLevel);
}

void CPaneSysSetup::CheckComponentPreAcq()
{
	//m_pComponent->ShowComponentOverDate();
	m_pComponent->CheckComponentOverDate();
}

void CPaneSysSetup::UpdateIniUI(int nVal)
{
	if(UI_ALL == nVal || (nVal & SYSTEM_PATH))
		m_pDir->SetDirData();
	if(UI_ALL == nVal || (nVal & SYSTEM_DEVICE))
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	if(UI_ALL == nVal || (nVal & SYSTEM_BEAMPATH))
		m_pBeamPath->SetBeamPath(gBeamPathINI.m_sBeampath);
	if(UI_ALL == nVal || (nVal & SYSTEM_DUMPER))
	{
		m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
	}
}

#if !defined(AFX_PANEMANUALCONTROLPARAMETER_H__9E89DC7A_2E46_46A7_A797_04ABE9F0D656__INCLUDED_)
#define AFX_PANEMANUALCONTROLPARAMETER_H__9E89DC7A_2E46_46A7_A797_04ABE9F0D656__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlParameter.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlParameter form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "ColorComboEx.h"
#include "..\model\GlobalVariable.h"
#include "..\model\ToolCodeList.h"

class CPaneManualControlParameter : public CFormView
{
protected:
	CPaneManualControlParameter();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlParameter)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlParameter)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_PARAMETER_NEW };
	CListCtrl		m_listMainTool;
	CListCtrl		m_listSubTool;
	CColorComboEx	m_cmbColor;
	CComboBox		m_cmbDrillMethod;
	CComboBox		m_cmbToolType;
	CComboBox		m_cmbMask;
	UEasyButtonEx	m_chkUseTool;
	UEasyButtonEx	m_chkUseToolOrder;
	UEasyButtonEx	m_chkUseAperture;
	UEasyButtonEx	m_btnUpdateMain;
	UEasyButtonEx	m_btnUpdate;
	UEasyButtonEx	m_btnAdd;
	UEasyButtonEx	m_btnDelete;
	UEasyButtonEx	m_btnSetting;
	UEasyButtonEx	m_btnFileOpen;
	UEasyButtonEx	m_btnScannerProfileOpen;
	CColorEdit		m_edtMainTcode;
	CColorEdit		m_edtToolSize;
	CColorEdit		m_edtSubNo;
	CColorEdit		m_edtDrawStep;
	CColorEdit		m_edtJumpStep;
	CColorEdit		m_edtDrawStepPeriod;
	CColorEdit		m_edtJumpStepPeriod;
	CColorEdit		m_edtCornerDelay;
	CColorEdit		m_edtJumpDelay;
	CColorEdit		m_edtLineDelay;
	CColorEdit		m_edtLaserOnDelay;
	CColorEdit		m_edtLaserOffDelay;
	CColorEdit		m_edtFrequency;
	CColorEdit		m_edtFPS;
	CColorEdit		m_edtCurrent;
	CColorEdit		m_edtTotalShot;
	CColorEdit		m_edtBurstShot;
	CColorEdit		m_edtLeadIn;
	CColorEdit		m_edtLeadOut;
	CColorEdit		m_edtTableSpeed;
	CColorEdit		m_edtAperturePath;
	CColorEdit		m_edtScannerProfilePath;
	CColorEdit		m_edtApertureBurst;
	CColorEdit		m_edtThermalTrack;
	CColorEdit		m_edtZOffset;
	//}}AFX_DATA

// Attributes
public:
	CToolCodeList* m_pToolCode[MAX_PARAM_TOOL];

	double			m_dDuty[MAX_BEAM_HOLE];
	
	BOOL			m_bUseTool;
	BOOL			m_bToolOrder;
	BOOL			m_bUseAperture;

// Operations
public:
	BOOL CheckSubTool(SUBTOOLDATA subData);
	int GetUseToolIndex(int nIndex);
	void UpdateList(int nMainIndex);
	void ChangeDataMain(int nMainIndex);
	void ChangeData(int nMainIndex, int nSubIndex);
	void ChangeDisplay(int nMainIndex, int nSubIndex);
	void AddParameter(int nMainIndex);
	BOOL SetData(GlobalVariable& mGlobal);
	BOOL GetData(GlobalVariable& tempGlobal);
	void InitListControl();
	void InitStaticControl();
	void InitBtnControl();
	void InitComboControl();
	void InitEditControl();
	
	void GetColor(int nIndex, CString& strText);
	
	void EnableControl(BOOL bUse);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlParameter)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlParameter();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntList;
	CFont		m_fntCombo;
	CFont		m_fntStatic;
	CFont		m_fntEdit;
	CFont		m_fntEdit2;
	CFont		m_fntBtn;

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlParameter)
	afx_msg void OnClickListMainToolCode(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickListSubToolCode(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelChangeComboColor();
	afx_msg void OnSelChangeComboDrillMethod();
	afx_msg void OnSelChangeComboToolType();
	afx_msg void OnSelChangeComboMask();
	afx_msg void OnButtonApertureOpen();
	afx_msg void OnButtonSetting();
	afx_msg void OnButtonParamAdd();
	afx_msg void OnButtonParamDelete();
	afx_msg void OnButtonParamUpdate();
	afx_msg void OnButtonParamUpdateMain();
	afx_msg void OnCheckUseTool();
	afx_msg void OnCheckUseToolOrder();
	afx_msg void OnCheckUseAperture();
	afx_msg void OnDestroy();
	afx_msg void OnButtonSubProfileOpen();
	afx_msg void OnChangeEditSubTotalShot();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLPARAMETER_H__9E89DC7A_2E46_46A7_A797_04ABE9F0D656__INCLUDED_)

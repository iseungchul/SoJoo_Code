// PaneRecipeGenFiducialNew.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneRecipeGenFiducialNew.h"
#include "..\easydrillerdlg.h"

#include "..\model\DProject.h"
#include "..\Model\DSystemINI.h"
#include "..\model\DProcessINI.h"
#include "..\model\deasydrillerini.h"
#include "..\alarmmsg.h"
#include "math.h"
#include "..\device\hdevicefactory.h"
#include "..\device\hvision.h"
#include "..\device\DeviceMotor.h"
#include "..\device\HEocard.h"
#include "PaneManualControl.h"
#include "PaneManualControlVision.h"
#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "DlgMatroxVisionView.h"
#include "..\device\HMotor.h"
#include "DlgMotorMove.h"
#include "DlgLpcView.h"

#include "DlgRecipeGen.h"
#include "PaneAutoRun.h"
#include "PaneRecipeGenSub.h"
#include "PaneAutoRunViewData.h"
#include "..\MODEL\GlobalVariable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const UINT UM_CHANGE_VISION_PARAM	= WM_APP + 51;
const UINT UM_VISION_FIND			= WM_APP + 52;
const UINT UM_VISION_ROI_SET		= WM_APP + 53;
const UINT UM_VISION_FIND_NOGRAP	= WM_APP + 56;
const UINT UM_VISION_ROI_SET_UM		= WM_APP + 57;
const UINT UM_VISION_LAMP			= WM_APP + 58;
const UINT UM_VISION_BARCODE		= WM_APP + 59;

UINT HoleFindThread(LPVOID pParam)
{
	CPaneRecipeGenFiducialNew* pRun = (CPaneRecipeGenFiducialNew*)pParam;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HVision* pVision = gDeviceFactory.GetVision();
	BOOL bSelectMode = FALSE;
	int nTool;
	if(gDProject.IsThereSelectData() && gDProject.m_bSelectDrawMode)
		bSelectMode = TRUE;
	
	BOOL b1stPanel = TRUE;
	double dX, dY;

	if(pRun->m_nCameraNo == LOW_1ST_CAM)
	{
		dX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
	}
	else if(pRun->m_nCameraNo == HIGH_1ST_CAM)
	{
		dX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
		dY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
	}
	else if(pRun->m_nCameraNo == LOW_2ND_CAM)
	{
		dX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		dY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
		b1stPanel = FALSE;
	}
	else
	{
		dX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
		dY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		b1stPanel = FALSE;
	}

	CString strFile, strLog;
	strFile.Format(_T("HoleFindOffset2"));
	strLog.Format("---Hole Find Start-----");
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));






	double dMoveX, dMoveY;
	DAreaInfo* pAreaInfo;
	LPFIREHOLE pHole;
	LPFIRELINE pLine;
	POSITION pos, posData;
	CString strResult;
	double dPanelOffsetX = 0, dPanelOffsetY = 0;
	double dLaserOffsetX, dLaserOffsetY;

	BOOL bNoSearch = TRUE;

	int nToolStart, nToolEnd;
	nToolStart = ADDED_FID_TOOL + 1;
	nToolEnd = MAX_TOOL_NO;




		CString szPath;
		szPath.Format(_T("%sHoleFindOffset_Cycle.txt"), gEasyDrillerINI.m_clsDirPath.GetConvertedDir());
		FILE* fileStream;
		errno_t err;
		err = fopen_s(&fileStream, szPath, "w+");

		if(err != NULL)
		{
			ErrMessage(IDS_ERR_HOLE_FIND);	
		}

		for(int i = nToolStart; i < nToolEnd; i++)
		{
			pos = pRun->m_pProject->m_Areas[i].GetHeadPosition();
			while (pos) 
			{
				pAreaInfo = pRun->m_pProject->m_Areas[i].GetNext(pos);
				if(pRun->m_pProject->m_nSeparation == USE_DUAL)
				{
					pMotor->GetAxisMoveOffset(pAreaInfo->m_dTableX/1000., pAreaInfo->m_dTableY/1000., dPanelOffsetX, dPanelOffsetY, DELTA_PANEL_OFFSET);
					dPanelOffsetX = (dPanelOffsetX ) * 1000.;
					dPanelOffsetY = (dPanelOffsetY ) * 1000.;
				}
				else
				{
					dPanelOffsetX = 0;
					dPanelOffsetY = 0;
				}
				if(b1stPanel)
					gDeviceFactory.GetEocard()->GetLaserOffset(pAreaInfo->m_dTableX/1000., pAreaInfo->m_dTableY/1000., dLaserOffsetX, dLaserOffsetY, FIRST_PANEL_OFFSET);
				else
					gDeviceFactory.GetEocard()->GetLaserOffset(pAreaInfo->m_dTableX/1000., pAreaInfo->m_dTableY/1000., dLaserOffsetX, dLaserOffsetY, SECOND_PANEL_OFFSET);
				//------


				BLOCK_FIDPOS* pholeFidData;
				CDPoint ptTempLSB;

				for(int j = ADDED_FID_TOOL; j < MAX_TOOL_NO; j++)
				{
					posData = pAreaInfo->m_FireHoles[j].GetHeadPosition();
					int oldFidBlock = 999;
					while(posData)
					{

						pHole = pAreaInfo->m_FireHoles[j].GetNext(posData);
						nTool = pRun->m_pProject->m_ToolSumInfo[pHole->pOrigin->nToolNo].nRealToolNo;

						if( (pRun->m_pProject->m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable() &&
							(!bSelectMode || (bSelectMode && pHole->bSelect))) )
						{
							if(oldFidBlock != pHole->pOrigin->nFidBlock)
							{
								oldFidBlock = pHole->pOrigin->nFidBlock;
/*
								if(!pRun->FindFiducialInCenter(DEFAULT_FID_INDEX, FIND_ALL_FID, pHole->pOrigin->nFidBlock))//20171120
								{
									int nCamNo = pRun->m_nCameraNo;
									if(nCamNo == HIGH_1ST_CAM)
										::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL);
									if(nCamNo == LOW_1ST_CAM)
										::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
									if(nCamNo == HIGH_2ND_CAM)
										::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL);
									if(nCamNo == LOW_2ND_CAM)
										::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
									ErrMessage(_T("Fail to Find Fiducial"));
									gFidFindExposure = FALSE;
									if(err == NULL)
										fclose(fileStream);
									return FALSE; // Message add
								}
								else
*/
								{
									pVision->OnApplyVisionParameter(pRun->m_sHoleVisInfo.nModelType ,pRun->m_nCameraNo, pRun->m_sHoleVisInfo );
									double dModelX, dModelY;
									//���� double nROISize, nROIAllow = 200;
									double nROISize, nROIAllow = 80;
									if(pRun->m_sHoleVisInfo.nModelType < 2) // annulus, circle
									{
										dModelX = dModelY = pRun->m_sHoleVisInfo.dSizeA;
										nROISize = (int)(dModelX * 1000 + nROIAllow);
										//nROISize = (dModelX * 1000)*1.5; // + nROIAllow);
									}
									else if(pRun->m_sHoleVisInfo.nModelType < MODEL_PATTERN) // other geometery
									{
										dModelX = pRun->m_sHoleVisInfo.dSizeA;
										dModelY = pRun->m_sHoleVisInfo.dSizeB;
										nROISize = (int)(max(dModelX, dModelY) * 1000 + nROIAllow);
									}
									else
									{
										nROISize = (int)(gSystemINI.m_sSystemDevice.dLowFOVX * 1000);
									}

									if( pRun->m_nCameraNo == LOW_1ST_CAM || pRun->m_nCameraNo == LOW_2ND_CAM )
									{	// Low
										pRun->SendMessage(UM_VISION_ROI_SET_UM, nROISize, LOW_1ST_CAM);
									}
									else
									{	// High
										pRun->SendMessage(UM_VISION_ROI_SET_UM, nROISize, HIGH_1ST_CAM);
									}
								}
							}

							bNoSearch = FALSE;

							int nBlockStart = 0, nBlockEnd = 1;

							if(pHole->pOrigin->nBlockName2 != 0 && pHole->m_pblockPosList)
								nBlockEnd = pRun->m_pProject->m_Glyphs.GetHoleDataBlockCount(pHole->pOrigin->nBlockName2);





							for(int nBlockHoleCount = nBlockStart; nBlockHoleCount < nBlockEnd; nBlockHoleCount++)
							{



								if(pHole->pOrigin->nBlockName2 != 0 && pHole->m_pblockPosList)
								{	
									pholeFidData = pHole->m_pblockPosList->GetNext(nBlockHoleCount);
									if(b1stPanel)
										ptTempLSB = pholeFidData->dpBlockPos1;
									else
										ptTempLSB = pholeFidData->dpBlockPos2;

								}
								else
								{
									if(b1stPanel)
										ptTempLSB = pHole->dpLSBPos1;
									else
										ptTempLSB = pHole->dpLSBPos2;
								}


								if(b1stPanel)
								{
									double dTemp = (pAreaInfo->m_dTableX - (pHole->dpLSBPos1.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000. / static_cast<double>(MAXLSB));

									dMoveX = (pAreaInfo->m_dTableX - (ptTempLSB.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000. / static_cast<double>(MAXLSB))/1000. + dX - dLaserOffsetX;
									dMoveY = (pAreaInfo->m_dTableY - (ptTempLSB.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000. / static_cast<double>(MAXLSB))/1000. + dY - dLaserOffsetY;
								}
								else
								{
									dMoveX = (pAreaInfo->m_dTableX - dPanelOffsetX - (ptTempLSB.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000. / static_cast<double>(MAXLSB))/ 1000. + dX - dLaserOffsetX;
									dMoveY = (pAreaInfo->m_dTableY - dPanelOffsetY - (ptTempLSB.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000. / static_cast<double>(MAXLSB))/ 1000. + dY - dLaserOffsetY;
								}

								if(!pMotor->MotorMoveXYZ(dMoveX, dMoveY, pRun->m_dZPos, pRun->m_dZPos, b1stPanel))
								{
									pRun->m_pHoleFindThread = NULL;
									CString strString, strMsg;
									strString.LoadString(IDS_ERR_MOVE_MOTOR);
									strMsg.Format(strString, "X,Y,Z");
									ErrMessage(strMsg);
									if(err == NULL)
										fclose(fileStream);
									pRun->ButtonEnable(TRUE);
									return 1U;
								}
								if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
								{
									pRun->m_pHoleFindThread = NULL;
									ErrMessage(_T("Inposition Error"));
									if(err == NULL)
										fclose(fileStream);
									pRun->ButtonEnable(TRUE);
									return 1U;
								}

								//	if(pRun->m_nCameraNo % 2 == 0)
								//	::Sleep(100);



								::Sleep(500);

								if(!pRun->SendMessage(UM_VISION_FIND, pRun->m_nCameraNo,  MODEL_CIRCLE))
								{
									pRun->m_visionResult.x = 0;
									pRun->m_visionResult.y = 0;
								}

								strResult.Format(_T("%s"), pRun->m_ResultChar);
								pRun->DPHoleInfo(strResult);

								double dCurrentPosX;
								double dCurrentPosY;
								gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dCurrentPosX, b1stPanel); // low vision pos 
								gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dCurrentPosY, b1stPanel);

								CString strHoleFind;
								strHoleFind.Format("Table Cmd (%.4f, %.4f),Inpos (%.4f, %.4f), Offset (%.4f, %.4f)\n", dMoveX, dMoveY,dCurrentPosX,dCurrentPosY, pRun->m_visionResult.x, pRun->m_visionResult.y);

								if(err == NULL)
								{
									fprintf(fileStream, strHoleFind);
								}

								strLog.Format(_T("File Pos (%d, %d), Offset (%.3f, %.3f)"), pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, pRun->m_visionResult.x, pRun->m_visionResult.y);
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

								CString strFile2;
								strFile2.Format("HoleFindResult");

								CString strHoleFind2;
								strHoleFind2.Format("Table Cmd \t %.4f \t %.4f \t Inpos \t %.4f \t  %.4f \t  Offset %.4f \t  %.4f \t ", dMoveX, dMoveY,dCurrentPosX,dCurrentPosY, pRun->m_visionResult.x, pRun->m_visionResult.y);
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strHoleFind2));
							}
						}
						if(pRun->m_bStop)
						{
							pRun->m_pHoleFindThread = NULL;
							if(err == NULL)
								fclose(fileStream);
							pRun->ButtonEnable(TRUE);
							return 1U;
						}
					}

					posData = pAreaInfo->m_FireLines[j].GetHeadPosition();

					while(posData)
					{
						pLine = pAreaInfo->m_FireLines[j].GetNext(posData);

						if(	(pRun->m_pProject->m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable() &&
							(!bSelectMode || (bSelectMode && pLine->bSelect))) )
						{
							bNoSearch = FALSE;

							if(b1stPanel)
							{
								dMoveX = (pAreaInfo->m_dTableX - (pLine->dpFidSPos1.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000. / static_cast<double>(MAXLSB)) / 1000. + dX;
								dMoveY = (pAreaInfo->m_dTableY - (pLine->dpFidSPos1.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000. / static_cast<double>(MAXLSB)) / 1000. + dY;
							}
							else
							{
								dMoveX = (pAreaInfo->m_dTableX - (pLine->dpFidSPos2.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000. / static_cast<double>(MAXLSB)) / 1000. + dX;
								dMoveY = (pAreaInfo->m_dTableY - (pLine->dpFidSPos2.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000. / static_cast<double>(MAXLSB)) / 1000. + dY;
							}

							if(!pMotor->MotorMoveXYZ(dMoveX, dMoveY, pRun->m_dZPos, pRun->m_dZPos, b1stPanel))
							{
								pRun->m_pHoleFindThread = NULL;
								CString strString, strMsg;
								strString.LoadString(IDS_ERR_MOVE_MOTOR);
								strMsg.Format(strString, "X,Y,Z");
								ErrMessage(strMsg);
								if(err == NULL)
									fclose(fileStream);
								pRun->ButtonEnable(TRUE);
								return 1U;
							}
							if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
							{
								pRun->m_pHoleFindThread = NULL;
								ErrMessage(_T("Inposition Error"));
								if(err == NULL)
									fclose(fileStream);
								pRun->ButtonEnable(TRUE);
								return 1U;
							}

							if(pRun->m_nCameraNo % 2 == 0)
								::Sleep(100);

							int nIndexNo = 6;
							if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
								nIndexNo = 4;

							if(!pRun->SendMessage(UM_VISION_FIND, pRun->m_nCameraNo, MODEL_CIRCLE))
							{
								pRun->m_visionResult.x = 0;
								pRun->m_visionResult.y = 0;
							}

							if(b1stPanel)
							{
								dMoveX = (pAreaInfo->m_dTableX - (pLine->dpFidEPos1.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB)) / 1000.0 + dX;
								dMoveY = (pAreaInfo->m_dTableY - (pLine->dpFidEPos1.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB)) / 1000.0 + dY;
							}
							else
							{
								dMoveX = (pAreaInfo->m_dTableX - (pLine->dpFidEPos2.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB)) / 1000.0 + dX;
								dMoveY = (pAreaInfo->m_dTableY - (pLine->dpFidEPos2.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB)) / 1000.0 + dY;
							}

							if(!pMotor->MotorMoveXYZ(dMoveX, dMoveY, pRun->m_dZPos, pRun->m_dZPos, b1stPanel))
							{
								pRun->m_pHoleFindThread = NULL;
								CString strString, strMsg;
								strString.LoadString(IDS_ERR_MOVE_MOTOR);
								strMsg.Format(strString, "X,Y,Z");
								ErrMessage(strMsg);
								if(err == NULL)
									fclose(fileStream);
								pRun->ButtonEnable(TRUE);
								return 1U;
							}
							if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
							{
								pRun->m_pHoleFindThread = NULL;
								ErrMessage(_T("Inposition Error"));
								if(err == NULL)
									fclose(fileStream);
								pRun->ButtonEnable(TRUE);
								return 1U;
							}

							if(pRun->m_nCameraNo % 2 == 0)
								::Sleep(100);

							nIndexNo = 6;
							if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
								nIndexNo = 4;

							if(!pRun->SendMessage(UM_VISION_FIND, pRun->m_nCameraNo, MODEL_CIRCLE))
							{
								pRun->m_visionResult.x = 0;
								pRun->m_visionResult.y = 0;
							}
						}

						if(pRun->m_bStop)
						{
							pRun->m_pHoleFindThread = NULL;
							if(err == NULL)
								fclose(fileStream);
							pRun->ButtonEnable(TRUE);
							return 1U;
						}

						
					}
				}
			}
		}



	if(bNoSearch)
		ErrMessage(_T("There are no holes"));
	
	if(err == NULL)
		fclose(fileStream);
	
	pRun->m_pHoleFindThread = NULL;
	pRun->ButtonEnable(TRUE);

	gDProject.CalculateDataCount();
	/*
	for(int ii = 0; ii  < gDProject.m_nTotalHole; ii++)
	{
		if(ii < MAX_TEMP_HOLE)	
		{
		double dGapX = gVariable.m_dgTempPos2[ii].x - gVariable.m_dgTempPos3[ii].x;
		double dGapY = gVariable.m_dgTempPos2[ii].y - gVariable.m_dgTempPos3[ii].y;

		strFidInfo.Format("Hole Find Gap \t %.8f \t %.8f ", dGapX,dGapY);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFidFile), reinterpret_cast<LPARAM>(&strFidInfo));
		TRACE("%s \n",strFidInfo);
		}
	}
	*/
	return 1U;
}

UINT FidFindThread(LPVOID pParam)
{
	CPaneRecipeGenFiducialNew* pRun = (CPaneRecipeGenFiducialNew*)pParam;
	
	pRun->FindFiducial();
	
	pRun->m_pFindFidThread = NULL;
	pRun->ButtonEnable(TRUE);
	return 1U;
}
/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenFiducialNew

IMPLEMENT_DYNCREATE(CPaneRecipeGenFiducialNew, CFormView)

CPaneRecipeGenFiducialNew::CPaneRecipeGenFiducialNew()
	: CFormView(CPaneRecipeGenFiducialNew::IDD)
{
	//{{AFX_DATA_INIT(CPaneRecipeGenFiducialNew)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_nFidIndex = -1;
	m_nPolarity	= 1;
	m_nModelType = 1;

	for(int i=0; i<4; i++)
	{
		m_nCoaxial[i] = 100;
		m_nRing[i] = 100;
		m_dContrast[i] = 0.6;
		m_dBrightness[i] = 0.6;

		m_sHoleVisInfo.nCoaxial[i] = 100;
		m_sHoleVisInfo.nRing[i] = 100;
		m_sHoleVisInfo.dContrast[i] = 0.6;
		m_sHoleVisInfo.dBrightness[i] = 0.6;
	}

	m_strPath = _T("");
	m_pProject = NULL;
	m_bDrawMoveStart = FALSE;
	m_bIsLive		= FALSE;

	m_pFindFidThread = NULL;
	m_pHoleFindThread = NULL;
	m_pLPCView = NULL;

	m_sHoleVisInfo.nModelType = 1;
	m_sHoleVisInfo.nPolarity = 0;
	m_sHoleVisInfo.dSizeA = 0.1;
	m_sHoleVisInfo.dSizeB = 0;
	m_sHoleVisInfo.dSizeC = 0;
	
	m_sHoleVisInfo.dScoreAngle = 10;
	m_sHoleVisInfo.dScoreSize = 10;
	m_sHoleVisInfo.dAspectRatio = 20;
	m_sHoleVisInfo.nThreshold = 0;

	m_bNoUIAutoChange = FALSE;
	m_nTimerID = 0;

	memset(m_ResultChar, NULL, sizeof(m_ResultChar));
	m_bTableSuction = FALSE;
	m_bTableSuction2 = FALSE;
	m_bDrawMode = TRUE;
	m_nUserLevel = 0;
}

CPaneRecipeGenFiducialNew::~CPaneRecipeGenFiducialNew()
{
}

void CPaneRecipeGenFiducialNew::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneRecipeGenFiducialNew)
	DDX_Control(pDX, IDC_TREE_TOOL, m_ctrTreeTool);
	DDX_Control(pDX, IDC_COMBO_FID_TYPE, m_cmbFidType);
	DDX_Control(pDX, IDC_COMBO_TOOL_NUMBER, m_cmbToolNo);
	DDX_Control(pDX, IDC_CHECK_FID_DRILL, m_chkUseDrill);
	DDX_Control(pDX, IDC_CHECK_FID_VERIFY, m_chkUseVerify);
	DDX_Control(pDX, IDC_BUTTON_APPLY_TO_ALL_FID, m_btnApplyParam);
	DDX_Control(pDX, IDC_BUTTON_APPLY_TO_SAMETYPE_FID, m_btnApplySameFidParam);
	DDX_Control(pDX, IDC_BUTTON_UPDATE, m_btnDataUpdate);
	DDX_Control(pDX, IDC_EDIT_NUMBER, m_edtFidIndex);
	DDX_Control(pDX, IDC_EDIT_Z_OFFSET, m_edtFidOffsetZ);
	DDX_Control(pDX, IDC_BUTTON_APPLY_TO_ALL, m_btnApplyCam);
	DDX_Control(pDX, IDC_BUTTON_APPLY_TO_ALL_CAM, m_btnApplyParamCam);
	DDX_Control(pDX, IDC_EDIT_VISION_ORIENTATION, m_edtOrientation);
	DDX_Control(pDX, IDC_STATIC_PIC, m_stcPic);
	DDX_Control(pDX, IDC_EDIT_JOB_FILE, m_edtPath);
	DDX_Control(pDX, IDC_EDIT_SIZE_C, m_edtSizeC);
	DDX_Control(pDX, IDC_EDIT_SIZE_B, m_edtSizeB);
	DDX_Control(pDX, IDC_EDIT_SIZE_A, m_edtSizeA);
	DDX_Control(pDX, IDC_EDIT_SIZE, m_edtSize);
	DDX_Control(pDX, IDC_EDIT_RING, m_edtRing);
	DDX_Control(pDX, IDC_EDIT_CONTRAST, m_edtContrast);
	DDX_Control(pDX, IDC_EDIT_COAXIAL, m_edtCoaxial);
	DDX_Control(pDX, IDC_EDIT_BRIGHTNESS, m_edtBrightness);
	DDX_Control(pDX, IDC_EDIT_ASPECTRATIO, m_edtAspectRatio);
	DDX_Control(pDX, IDC_EDIT_ANGLE, m_edtAngle);
	DDX_Control(pDX, IDC_EDIT_ROI_X2, m_edtRoiX2);
	DDX_Control(pDX, IDC_EDIT_SET_REFPOS_X, m_edtRefPosX);
	DDX_Control(pDX, IDC_EDIT_SET_REFPOS_Y, m_edtRefPosY);

	DDX_Control(pDX, IDC_EDIT_ROI_X, m_edtRoiX);
	DDX_Control(pDX, IDC_EDIT_ROI_Y, m_edtRoiY);
	DDX_Control(pDX, IDC_EDIT_THRESHOLD1, m_edtThreshold);
	DDX_Control(pDX, IDC_COMBO_TYPE, m_cmbType);
	DDX_Radio(pDX, IDC_RADIO_DARK, m_nPolarity);
	DDX_Control(pDX, IDC_COMBO_CAMERA, m_cmbCamera);
	DDX_Control(pDX, IDC_COMBO_CAMERA_NO, m_cmbCameraNo);
	DDX_Control(pDX, IDC_BUTTON_JOB_FILE_OPEN, m_btnJobFile);
	DDX_Control(pDX, IDC_CHECK_FID_FIND_ORDER, m_chkFindFidOrder);
	DDX_Control(pDX, IDC_CHECK_USE_ROI_SIZE, m_chkRoiSize);
	DDX_Control(pDX, IDC_CHECK_USE_ROI_SIZE2, m_chkRoiSize2);
	DDX_Control(pDX, IDC_CHECK_USE_SCALE_LIMIT, m_chkUseScaleLimit);
	DDX_Control(pDX, IDC_STATIC_INSP_RESULT2, m_stcInspResult);
	DDX_Control(pDX, IDC_BUTTON_MOVE, m_btnMove);
	DDX_Control(pDX, IDC_BUTTON_MOVE_NEAR_POS1, m_btnMoveNearPos1);
	DDX_Control(pDX, IDC_BUTTON_MOVE_NEAR_POS2, m_btnMoveNearPos2);
	DDX_Control(pDX, IDC_BUTTON_SETREF, m_btnSetRef);

	DDX_Control(pDX, IDC_BUTTON_SHOW_TEST, m_btnShowTest);
	DDX_Control(pDX, IDC_BUTTON_MARK_START, m_btnMarkStart);
	DDX_Control(pDX, IDC_BUTTON_MARK_STOP, m_btnMarkStop);
	DDX_Control(pDX, IDC_BUTTON_APPLY_REFPOS, m_btnApplyRefPos);
	DDX_Control(pDX, IDC_BUTTON_FIND_FID, m_btnFindFid);
	DDX_Control(pDX, IDC_BUTTON_FIND_HOLE, m_btnFindHole);
	DDX_Control(pDX, IDC_CHECK_INSP_AREA, m_chkSetROI);
	DDX_Control(pDX, IDC_BUTTON_LIVE2, m_btnSetLive);
	DDX_Control(pDX, IDC_BUTTON_TEST2, m_btnTrainTest);
	DDX_Control(pDX, IDC_COMBO_CAM_NO2, m_cmbCameraSelect);
	DDX_Control(pDX, IDC_LIST_RESULT2, m_lboxResult);
	DDX_Control(pDX, IDC_BUTTON_SET_OFFSET, m_btnSetPos);
	DDX_Control(pDX, IDC_BUTTON_MOVE_LOADING_POS, m_btnMoveLoadPos);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_btnStop);
	DDX_Control(pDX, IDC_CHECK_TABLE_SUCTION, m_ledTableSuction);
	DDX_Control(pDX, IDC_CHECK_TABLE_SUCTION2, m_ledTableSuction2);
	DDX_Control(pDX, IDC_BUTTON_MOTOR_MOVE, m_btnMotor);
	DDX_Control(pDX, IDC_BUTTON_LPC_VIEW, m_btnLpcView);
	DDX_Control(pDX, IDC_BUTTON_SAVE, m_btnSave);
	DDX_Control(pDX, IDC_SLIDER_COAXIAL, m_SliderCoaxial);
	DDX_Control(pDX, IDC_SLIDER_RING, m_SliderRing);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPaneRecipeGenFiducialNew, CFormView)
	//{{AFX_MSG_MAP(CPaneRecipeGenFiducialNew)
	ON_CBN_SELCHANGE(IDC_COMBO_FID_TYPE, OnSelChangeComboFidType)
	ON_CBN_SELCHANGE(IDC_COMBO_TOOL_NUMBER, OnSelChangeComboToolNo)
	ON_BN_CLICKED(IDC_BUTTON_APPLY_TO_ALL, OnButtonApplyCam)
	ON_BN_CLICKED(IDC_BUTTON_APPLY_TO_ALL_FID, OnButtonApplyParam)
	ON_BN_CLICKED(IDC_BUTTON_APPLY_TO_SAMETYPE_FID, OnButtonApplySameFidParam)
	ON_BN_CLICKED(IDC_BUTTON_APPLY_TO_ALL_CAM, OnButtonApplyParamCam)
	ON_BN_CLICKED(IDC_BUTTON_UPDATE, OnButtonDataUpdate)
	ON_BN_CLICKED(IDC_CHECK_FID_DRILL, OnCheckUseDrill)
	ON_BN_CLICKED(IDC_CHECK_FID_VERIFY, OnCheckUseVerify)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE_TOOL, OnSelchangedTree)
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_CTLCOLOR()
	ON_CBN_SELCHANGE(IDC_COMBO_TYPE, OnSelchangeComboType)
	ON_CBN_SELCHANGE(IDC_COMBO_CAMERA, OnSelchangeComboCamera)
	ON_CBN_SELCHANGE(IDC_COMBO_CAMERA_NO, OnSelchangeComboCameraNo)
	ON_BN_CLICKED(IDC_BUTTON_JOB_FILE_OPEN, OnButtonJobFileOpen)
	ON_WM_MOUSEWHEEL()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_EN_CHANGE(IDC_EDIT_SIZE_A, OnChangeEditSizeA)
	ON_EN_CHANGE(IDC_EDIT_SIZE_B, OnChangeEditSizeB)
	ON_EN_CHANGE(IDC_EDIT_SIZE_C, OnChangeEditSizeC)
	ON_BN_CLICKED(IDC_RADIO_DARK, OnRadioPolarity)
	ON_EN_UPDATE(IDC_EDIT_CONTRAST, OnUpdateEditContrast)
	ON_EN_UPDATE(IDC_EDIT_BRIGHTNESS, OnUpdateEditBrightness)
	ON_EN_CHANGE(IDC_EDIT_Z_OFFSET, OnChangeEditZOffset)
	ON_EN_CHANGE(IDC_EDIT_SIZE, OnChangeAcceptSize)
	ON_EN_CHANGE(IDC_EDIT_ASPECTRATIO, OnChangeEditAspectratio)
	ON_EN_CHANGE(IDC_EDIT_THRESHOLD1, OnChangeEditThreashold)
	ON_BN_CLICKED(IDC_CHECK_FID_FIND_ORDER, OnCheckFidFindOrder)
	ON_BN_CLICKED(IDC_CHECK_USE_ROI_SIZE, OnCheckUseRoiSize)
	ON_BN_CLICKED(IDC_CHECK_USE_ROI_SIZE2, OnCheckUseRoiSize2)
	ON_EN_CHANGE(IDC_EDIT_ROI_X2, OnChangeEditRoiX2)
	ON_EN_CHANGE(IDC_EDIT_ROI_X, OnChangeEditRoiX)
	ON_EN_CHANGE(IDC_EDIT_ROI_Y, OnChangeEditRoiY)
	ON_BN_CLICKED(IDC_BUTTON_MOVE, OnButtonMove)
	ON_BN_CLICKED(IDC_BUTTON_MOVE_NEAR_POS1, OnButtonMoveNearPos1)
	ON_BN_CLICKED(IDC_BUTTON_MOVE_NEAR_POS2, OnButtonMoveNearPos2)
	ON_BN_CLICKED(IDC_BUTTON_SETREF, OnButtonSetref)
	ON_BN_CLICKED(IDC_BUTTON_FIND_FID, OnButtonFindFid)
	ON_BN_CLICKED(IDC_BUTTON_FIND_HOLE, OnButtonFindHole)
	ON_BN_CLICKED(IDC_BUTTON_MOTOR_MOVE, OnButtonMotor)
	ON_BN_CLICKED(IDC_BUTTON_LPC_VIEW, OnButtonLpcView)
	ON_CBN_SELCHANGE(IDC_COMBO_CAM_NO2, OnEditchangeComboCamNo2)
	ON_BN_CLICKED(IDC_CHECK_INSP_AREA, OnCheckInspArea)
	ON_BN_CLICKED(IDC_BUTTON_LIVE2, OnButtonLive2)
	ON_BN_CLICKED(IDC_BUTTON_TEST2, OnButtonTest2)
	ON_BN_CLICKED(IDC_BUTTON_SET_OFFSET, OnButtonSetOffset)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_MESSAGE(UM_VISION_FIND, GetVisionResult)
	ON_MESSAGE(UM_VISION_ROI_SET, SetROI)
	ON_MESSAGE(UM_VISION_ROI_SET_UM, SetROIUM)
	ON_MESSAGE(UM_CHANGE_VISION_PARAM, ChangeVisionParameter)
	ON_MESSAGE(UM_VISION_FIND_NOGRAP, GetVisionResultNoGrab)
	ON_MESSAGE(UM_VISION_LAMP, SetVisionLamp)
	
	ON_MESSAGE(UM_VISION_BARCODE, GetVisionResultBarcode)

	ON_EN_UPDATE(IDC_EDIT_COAXIAL, OnUpdateEditCoaxial)
	ON_EN_UPDATE(IDC_EDIT_RING, OnUpdateEditRing)
	ON_WM_RBUTTONUP()
	ON_BN_CLICKED(IDC_RADIO_LIGHT, OnRadioPolarity)
	ON_BN_CLICKED(IDC_RADIO_NONE, OnRadioPolarity)
	ON_WM_TIMER()
	ON_COMMAND(IMD_FID_MOVE, OnMoveToFiducial)
	ON_BN_CLICKED(IDC_CHECK_TABLE_SUCTION, OnCheckTableSuction)
	ON_BN_CLICKED(IDC_CHECK_TABLE_SUCTION2, OnCheckTableSuction2)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, OnButtonSave)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_MOVE_LOADING_POS, &CPaneRecipeGenFiducialNew::OnBnClickedButtonMoveLoadingPos)
	ON_BN_CLICKED(IDC_CHECK_USE_SCALE_LIMIT, &CPaneRecipeGenFiducialNew::OnBnClickedCheckUseScaleLimit)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_COAXIAL, &CPaneRecipeGenFiducialNew::OnNMReleasedcaptureSliderCoaxial)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_RING, &CPaneRecipeGenFiducialNew::OnNMReleasedcaptureSliderRing)
	ON_BN_CLICKED(IDC_BUTTON_SHOW_TEST, &CPaneRecipeGenFiducialNew::OnBnClickedButtonShowTest)
	ON_BN_CLICKED(IDC_BUTTON_MARK_START, &CPaneRecipeGenFiducialNew::OnBnClickedButtonMarkStart)
	ON_BN_CLICKED(IDC_BUTTON_MARK_STOP, &CPaneRecipeGenFiducialNew::OnBnClickedButtonMarkStop)
	ON_BN_CLICKED(IDC_BUTTON_SHOW_MOTOR_MOVE, &CPaneRecipeGenFiducialNew::OnBnClickedButtonShowMotorMove)
	ON_BN_CLICKED(IDC_BUTTON_CLEAR_FIND_HOLE, &CPaneRecipeGenFiducialNew::OnBnClickedButtonClearFindHole)
	ON_BN_CLICKED(IDC_BUTTON_APPLY_REFPOS, &CPaneRecipeGenFiducialNew::OnBnClickedButtonApplyRefpos)
	ON_BN_CLICKED(IDC_BUTTON_FID_INFO_BLOCK_COPY_INCLUDE, &CPaneRecipeGenFiducialNew::OnBnClickedButtonFidInfoBlockCopyInclude)
	ON_BN_CLICKED(IDC_BUTTON_FID_INFO_BLOCK_COPY_EXCLUDE, &CPaneRecipeGenFiducialNew::OnBnClickedButtonFidInfoBlockCopyExclude)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenFiducialNew diagnostics

#ifdef _DEBUG
void CPaneRecipeGenFiducialNew::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneRecipeGenFiducialNew::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenFiducialNew message handlers
void CPaneRecipeGenFiducialNew::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class

	CRect rtView;
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect( rtView );
	ScreenToClient( rtView );

	InitBitmap();
	InitListControl();
	InitStaticControl();
	InitBtnControl();
	InitComboControl();
	InitEditControl();
	InitSlideControl();
	
	m_bUseDrillFid = FALSE;
	m_bUseVerifyFid = FALSE;
	

	ChangeControl(TRUE);

	if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION || gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
		ChangeControl(FALSE);
	else
	{
		if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
		{
//			GetDlgItem(IDC_STATIC_ASPECT_RATIO)->EnableWindow(FALSE);
//			GetDlgItem(IDC_EDIT_ASPECTRATIO)->EnableWindow(FALSE);
		}
	}

	if(!gSystemINI.m_sHardWare.nUseLampRS232)
	{
		GetDlgItem(IDC_STATIC_LIGHT)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_COAXIAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_COAXIAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_STATIC_RING)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_RING)->EnableWindow(FALSE);
	}

	EnableControl(gProcessINI.m_sProcessFidFind.bUseAllControl);

	if(!gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		m_cmbCamera.SetCurSel(1);
		m_cmbType.SetCurSel(1);
	}
#ifdef USE_VISION_PRO
	gDeviceFactory.GetVision()->ConnectPatternUI(DISPLAYA, GetDlgItem(IDC_VISION_PATTERN_FID));
#endif
	m_cmbType.SetCurSel(1);
}

BOOL CPaneRecipeGenFiducialNew::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

void CPaneRecipeGenFiducialNew::InitBitmap()
{
	m_imgAnnulus.LoadBitmap(IDB_ANNULUS);
	m_imgCircle.LoadBitmap(IDB_CIRCLE);
	m_imgCross.LoadBitmap(IDB_CROSS);
	m_imgDiamond.LoadBitmap(IDB_DIAMOND);
	m_imgDouble.LoadBitmap(IDB_DOUBLERECT);
	m_imgRect.LoadBitmap(IDB_RECT);
	m_imgTriangle.LoadBitmap(IDB_TRIANGLE);
	m_imgUserImage.LoadBitmap(IDB_USER_IMAGE);
}

void CPaneRecipeGenFiducialNew::InitListControl()
{
	// Set List Font
	m_fntList.CreatePointFont(130, "Arial Bold");
	m_ctrTreeTool.SetFont( &m_fntList );
}

void CPaneRecipeGenFiducialNew::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Apply Cam info to selected fiducial
	m_btnApplyParamCam.SetFont( &m_fntBtn );
	m_btnApplyParamCam.SetFlat( FALSE );
	m_btnApplyParamCam.EnableBallonToolTip();
	m_btnApplyParamCam.SetToolTipText( _T("Update this parameter to all camera") );
	m_btnApplyParamCam.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApplyParamCam.SetBtnCursor(IDC_HAND_1);
//	m_btnApplyParamCam.SetColorType(1); // Blue & Bold Line

	// Data Update to selected fiducial
	m_btnDataUpdate.SetFont( &m_fntBtn );
	m_btnDataUpdate.SetFlat( FALSE );
	m_btnDataUpdate.EnableBallonToolTip();
	m_btnDataUpdate.SetToolTipText( _T("Update this parameter") );
	m_btnDataUpdate.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDataUpdate.SetBtnCursor(IDC_HAND_1);
	
	// Apply fiducial info to all fiducial
	m_btnApplyParam.SetFont( &m_fntBtn );
	m_btnApplyParam.SetFlat( FALSE );
	m_btnApplyParam.EnableBallonToolTip();
	m_btnApplyParam.SetToolTipText( _T("Update this fiducial parameter to other fiducial") );
	m_btnApplyParam.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApplyParam.SetBtnCursor(IDC_HAND_1);
	m_btnApplyParam.SetColorType(1); // Blue & Bold Line

	// Apply fiducial info to SameFidType fiducial
	m_btnApplySameFidParam.SetFont( &m_fntBtn );
	m_btnApplySameFidParam.SetFlat( FALSE );
	m_btnApplySameFidParam.EnableBallonToolTip();
	m_btnApplySameFidParam.SetToolTipText( _T("Update this fiducial parameter to other same type fiducial") );
	m_btnApplySameFidParam.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApplySameFidParam.SetBtnCursor(IDC_HAND_1);
//	m_btnApplySameFidParam.SetColorType(1);
	
	// Use drill type
	m_chkUseDrill.SetFont( &m_fntBtn );
	m_chkUseDrill.SetImageOrg( 10, 3 );
	m_chkUseDrill.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseDrill.EnableBallonToolTip();
	m_chkUseDrill.SetToolTipText( _T("Use for drill") );
	m_chkUseDrill.SetBtnCursor(IDC_HAND_1);

	// Use verify type
	m_chkUseVerify.SetFont( &m_fntBtn );
	m_chkUseVerify.SetImageOrg( 10, 3 );
	m_chkUseVerify.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseVerify.EnableBallonToolTip();
	m_chkUseVerify.SetToolTipText( _T("Use for verify") );
	m_chkUseVerify.SetBtnCursor(IDC_HAND_1);

	GetDlgItem(IDC_RADIO_DARK)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_LIGHT)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_NONE)->SetFont( &m_fntBtn );
	
	m_fntBtn2.CreatePointFont(110, "Arial Bold");
	
	m_btnJobFile.SetFont( &m_fntBtn2 );
	m_btnJobFile.SetFlat( FALSE );
	m_btnJobFile.EnableBallonToolTip();
	m_btnJobFile.SetToolTipText( _T("Job FilePath Selection") );
	m_btnJobFile.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnJobFile.SetBtnCursor(IDC_HAND_1);

	// Apply CamNo to all fiducial
	m_btnApplyCam.SetFont( &m_fntBtn2 );
	m_btnApplyCam.SetFlat( FALSE );
	m_btnApplyCam.EnableBallonToolTip();
	m_btnApplyCam.SetToolTipText( _T("Apply camera number to all fiducial") );
	m_btnApplyCam.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApplyCam.SetBtnCursor(IDC_HAND_1);
//	m_btnApplyCam.SetColorType(1); // Blue & Bold Line

	m_chkFindFidOrder.SetFont( &m_fntBtn );
	m_chkFindFidOrder.SetImageOrg( 10, 3 );
	m_chkFindFidOrder.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkFindFidOrder.EnableBallonToolTip();
	m_chkFindFidOrder.SetToolTipText( _T("Find Multi-Fiducial at one time") );
	m_chkFindFidOrder.SetBtnCursor(IDC_HAND_1);
	m_chkFindFidOrder.EnableWindow(TRUE);

	m_chkRoiSize.SetFont( &m_fntBtn );
	m_chkRoiSize.SetImageOrg( 10, 3 );
	m_chkRoiSize.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkRoiSize.EnableBallonToolTip();
	m_chkRoiSize.SetToolTipText( _T("Use Roi Size") );
	m_chkRoiSize.SetBtnCursor(IDC_HAND_1);
	m_chkRoiSize.EnableWindow(TRUE);
	
	m_chkRoiSize2.SetFont( &m_fntBtn );
	m_chkRoiSize2.SetImageOrg( 10, 3 );
	m_chkRoiSize2.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkRoiSize2.EnableBallonToolTip();
	m_chkRoiSize2.SetToolTipText( _T("Use Roi Size") );
	m_chkRoiSize2.SetBtnCursor(IDC_HAND_1);
	m_chkRoiSize2.EnableWindow(TRUE);

	m_chkUseScaleLimit.SetFont( &m_fntBtn );
	m_chkUseScaleLimit.SetImageOrg( 10, 3 );
	m_chkUseScaleLimit.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseScaleLimit.EnableBallonToolTip();
	m_chkUseScaleLimit.SetToolTipText( _T("Check Scale Limit") );
	m_chkUseScaleLimit.SetBtnCursor(IDC_HAND_1);
	m_chkUseScaleLimit.EnableWindow(TRUE);

#ifndef __KUNSAN_SAMSUNG_LARGE__
	m_chkUseScaleLimit.ShowWindow(SW_HIDE);
#endif

	//
	m_btnMove.SetFont( &m_fntBtn2 );
	m_btnMove.SetFlat( FALSE );
	m_btnMove.EnableBallonToolTip();
	m_btnMove.SetToolTipText( _T("Move Table to Selected Fiducial") );
	m_btnMove.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMove.SetBtnCursor(IDC_HAND_1);

	m_btnMoveNearPos1.SetFont( &m_fntBtn2 );
	m_btnMoveNearPos1.SetFlat( FALSE );
	m_btnMoveNearPos1.EnableBallonToolTip();
	m_btnMoveNearPos1.SetToolTipText( _T("Move Table to Selected Fiducial") );
	m_btnMoveNearPos1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMoveNearPos1.SetBtnCursor(IDC_HAND_1);

	m_btnMoveNearPos2.SetFont( &m_fntBtn2 );
	m_btnMoveNearPos2.SetFlat( FALSE );
	m_btnMoveNearPos2.EnableBallonToolTip();
	m_btnMoveNearPos2.SetToolTipText( _T("Move Table to Selected Fiducial") );
	m_btnMoveNearPos2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMoveNearPos2.SetBtnCursor(IDC_HAND_1);
	
	m_btnSetRef.SetFont( &m_fntBtn2 );
	m_btnSetRef.SetFlat( FALSE );
	m_btnSetRef.EnableBallonToolTip();
	m_btnSetRef.SetToolTipText( _T("Set Ref. Fiducial Table Position") );
	m_btnSetRef.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSetRef.SetBtnCursor(IDC_HAND_1);

	GetDlgItem(IDC_BUTTON_SHOW_MOTOR_MOVE)->SetFont( &m_fntBtn2 );
		GetDlgItem(IDC_BUTTON_APPLY_REFPOS)->SetFont( &m_fntBtn2 );
	m_btnShowTest.SetFont( &m_fntBtn2 );
	m_btnShowTest.SetFlat( FALSE );
	m_btnShowTest.EnableBallonToolTip();
	m_btnShowTest.SetToolTipText( _T("Show Test") );
	m_btnShowTest.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShowTest.SetBtnCursor(IDC_HAND_1);

	m_btnApplyRefPos.SetFont( &m_fntBtn2 );
	m_btnApplyRefPos.SetFlat( FALSE );
	m_btnApplyRefPos.EnableBallonToolTip();
	m_btnApplyRefPos.SetToolTipText( _T("Apply Fid") );
	m_btnApplyRefPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApplyRefPos.SetBtnCursor(IDC_HAND_1);


	m_btnMarkStart.SetFont( &m_fntBtn2 );
	m_btnMarkStart.SetFlat( FALSE );
	m_btnMarkStart.EnableBallonToolTip();
	m_btnMarkStart.SetToolTipText( _T("Mark Start") );
	m_btnMarkStart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMarkStart.SetBtnCursor(IDC_HAND_1);

	m_btnMarkStop.SetFont( &m_fntBtn2 );
	m_btnMarkStop.SetFlat( FALSE );
	m_btnMarkStop.EnableBallonToolTip();
	m_btnMarkStop.SetToolTipText( _T("Set Ref. Fiducial Table Position") );
	m_btnMarkStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMarkStop.SetBtnCursor(IDC_HAND_1);

	GetDlgItem(IDC_BUTTON_CLEAR_FIND_HOLE)->SetFont( &m_fntBtn2 );

	m_btnFindFid.SetFont( &m_fntBtn2 );
	m_btnFindFid.SetFlat( FALSE );
	m_btnFindFid.EnableBallonToolTip();
	m_btnFindFid.SetToolTipText( _T("Find Fiducial") );
	m_btnFindFid.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFindFid.SetBtnCursor(IDC_HAND_1);

	m_btnFindHole.SetFont( &m_fntBtn2 );
	m_btnFindHole.SetFlat( FALSE );
	m_btnFindHole.EnableBallonToolTip();
	m_btnFindHole.SetToolTipText( _T("Find Hole") );
	m_btnFindHole.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFindHole.SetBtnCursor(IDC_HAND_1);

	m_btnSetLive.SetFont( &m_fntBtn );
	m_btnSetLive.SetRectAlign( 1 );
	m_btnSetLive.SetToolTipText( _T("Vision Live Start/Stop") );
	m_btnSetLive.SetBtnCursor( IDC_HAND_1 );

	m_btnTrainTest.SetFont( &m_fntBtn2 );
	m_btnTrainTest.SetFlat( FALSE );
	m_btnTrainTest.EnableBallonToolTip();
	m_btnTrainTest.SetToolTipText( _T("Train and Find") );
	m_btnTrainTest.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTrainTest.SetBtnCursor(IDC_HAND_1);

	m_chkSetROI.SetFont( &m_fntBtn );
	m_chkSetROI.SetImageOrg( 10, 3 );
	m_chkSetROI.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkSetROI.EnableBallonToolTip();
	m_chkSetROI.SetToolTipText( _T("Inspection Area") );
	m_chkSetROI.SetBtnCursor(IDC_HAND_1);
	m_chkSetROI.SetCheck(0);

	m_btnSetPos.SetFont( &m_fntBtn2 );
	m_btnSetPos.SetFlat( FALSE );
	m_btnSetPos.EnableBallonToolTip();
	m_btnSetPos.SetToolTipText( _T("Set Current to Selected Fiducial Position") );
	m_btnSetPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSetPos.SetBtnCursor(IDC_HAND_1);

	
	m_btnMoveLoadPos.SetFont( &m_fntBtn2 );
	m_btnMoveLoadPos.SetFlat( FALSE );
	m_btnMoveLoadPos.EnableBallonToolTip();
	m_btnMoveLoadPos.SetToolTipText( _T("Move To Loading Position") );
	m_btnMoveLoadPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMoveLoadPos.SetBtnCursor(IDC_HAND_1);

	m_btnStop.SetFont( &m_fntBtn2 );
	m_btnStop.SetFlat( FALSE );
	m_btnStop.EnableBallonToolTip();
	m_btnStop.SetToolTipText( _T("Stop") );
	m_btnStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStop.SetBtnCursor(IDC_HAND_1);

	m_btnMotor.SetFont( &m_fntBtn2 );
	m_btnMotor.SetFlat( FALSE );
	m_btnMotor.EnableBallonToolTip();
	m_btnMotor.SetToolTipText( _T("Motor Control Dialog") );
	m_btnMotor.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMotor.SetBtnCursor(IDC_HAND_1);

	m_btnLpcView.SetFont( &m_fntBtn2 );
	m_btnLpcView.SetFlat( FALSE );
	m_btnLpcView.EnableBallonToolTip();
	m_btnLpcView.SetToolTipText( _T("LPC  Dialog") );
	m_btnLpcView.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLpcView.SetBtnCursor(IDC_HAND_1);
	
	m_btnSave.SetFont( &m_fntBtn2 );
	m_btnSave.SetFlat( FALSE );
	m_btnSave.EnableBallonToolTip();
	m_btnSave.SetToolTipText( _T("Save Hole Info when Find Hole") );
	m_btnSave.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSave.SetBtnCursor(IDC_HAND_1);

#ifdef __LPC_FOR_3RD_AOD__
	m_btnLpcView.ShowWindow(SW_SHOW);
#else
	m_btnLpcView.ShowWindow(SW_HIDE);
#endif

	m_fntBtn3.CreatePointFont(90, "Arial Bold");
	// Table Suction1
	m_ledTableSuction.SetFont( &m_fntBtn3 );
	m_ledTableSuction.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTableSuction.Depress( TRUE );
//	m_ledTableSuction.SetCursor(IDC_HAND_1);
	
	// Table Suction2
	m_ledTableSuction2.SetFont( &m_fntBtn3 );
	m_ledTableSuction2.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTableSuction2.Depress( TRUE );
//	m_ledTableSuction2.SetBtnCursor(IDC_HAND_1);

	GetDlgItem(IDC_BUTTON_FID_INFO_BLOCK_COPY_INCLUDE)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_BUTTON_FID_INFO_BLOCK_COPY_EXCLUDE)->SetFont( &m_fntBtn );
}

void CPaneRecipeGenFiducialNew::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(130, "Arial Bold");
	m_fntEdit2.CreatePointFont(100, "Arial Bold");
	
	// Fiducial Index
	m_edtFidIndex.SetFont( &m_fntEdit );
	m_edtFidIndex.SetForeColor( BLACK_COLOR );
	m_edtFidIndex.SetBackColor( WHITE_COLOR );
	m_edtFidIndex.SetReceivedFlag( 1 ); // 1:Integer, 3:float
	m_edtFidIndex.SetWindowText( _T("0") );

	// Fiducial Z Offset
	m_edtFidOffsetZ.SetFont( &m_fntEdit );
	m_edtFidOffsetZ.SetForeColor( BLACK_COLOR );
	m_edtFidOffsetZ.SetBackColor( WHITE_COLOR );
	m_edtFidOffsetZ.SetReceivedFlag( 3 ); // 1:Integer, 3:float
	m_edtFidOffsetZ.SetWindowText( _T("0.0") );

	// Size A
	m_edtSizeA.SetFont( &m_fntEdit );
	m_edtSizeA.SetForeColor( BLACK_COLOR );
	m_edtSizeA.SetBackColor( WHITE_COLOR );
	m_edtSizeA.SetReceivedFlag( 3 ); // Floating-Point
	m_edtSizeA.SetWindowText( _T("0.5") );
	
	// Size B
	m_edtSizeB.SetFont( &m_fntEdit );
	m_edtSizeB.SetForeColor( BLACK_COLOR );
	m_edtSizeB.SetBackColor( WHITE_COLOR );
	m_edtSizeB.SetReceivedFlag( 3 ); // Floating-Point
	m_edtSizeB.SetWindowText( _T("0.0") );
	
	// Size C
	m_edtSizeC.SetFont( &m_fntEdit );
	m_edtSizeC.SetForeColor( BLACK_COLOR );
	m_edtSizeC.SetBackColor( WHITE_COLOR );
	m_edtSizeC.SetReceivedFlag( 3 ); // Floating-Point
	m_edtSizeC.SetWindowText( _T("0.0") );
	
	// Size
	m_edtSize.SetFont( &m_fntEdit );
	m_edtSize.SetForeColor( BLACK_COLOR );
	m_edtSize.SetBackColor( WHITE_COLOR );
	m_edtSize.SetReceivedFlag( 3 ); // Floating-Point
	m_edtSize.SetWindowText( _T("10") );
	
	m_edtOrientation.SetFont( &m_fntEdit );
	m_edtOrientation.SetReceivedFlag( 1 );
	m_edtOrientation.SetWindowText( _T("0") );
	
	// Angle
	m_edtAngle.SetFont( &m_fntEdit );
	m_edtAngle.SetForeColor( BLACK_COLOR );
	m_edtAngle.SetBackColor( WHITE_COLOR );
	m_edtAngle.SetReceivedFlag( 3 ); // Floating-Point
	m_edtAngle.SetWindowText( _T("10") );


	// roi x2
	m_edtRoiX2.SetFont( &m_fntEdit );
	m_edtRoiX2.SetForeColor( BLACK_COLOR );
	m_edtRoiX2.SetBackColor( WHITE_COLOR );
	m_edtRoiX2.SetReceivedFlag( 1 ); // int
	m_edtRoiX2.SetWindowText( _T("800") );

	m_edtRefPosX.SetFont( &m_fntEdit );
	m_edtRefPosX.SetForeColor( BLACK_COLOR );
	m_edtRefPosX.SetBackColor( WHITE_COLOR );
	m_edtRefPosX.SetReceivedFlag( 1 ); // int
	m_edtRefPosX.SetWindowText( _T("500") );

	m_edtRefPosY.SetFont( &m_fntEdit );
	m_edtRefPosY.SetForeColor( BLACK_COLOR );
	m_edtRefPosY.SetBackColor( WHITE_COLOR );
	m_edtRefPosY.SetReceivedFlag( 1 ); // int
	m_edtRefPosY.SetWindowText( _T("600") );

	// roi x
	m_edtRoiX.SetFont( &m_fntEdit );
	m_edtRoiX.SetForeColor( BLACK_COLOR );
	m_edtRoiX.SetBackColor( WHITE_COLOR );
	m_edtRoiX.SetReceivedFlag( 1 ); // int
	m_edtRoiX.SetWindowText( _T("800") );

	// roi y
	m_edtRoiY.SetFont( &m_fntEdit );
	m_edtRoiY.SetForeColor( BLACK_COLOR );
	m_edtRoiY.SetBackColor( WHITE_COLOR );
	m_edtRoiY.SetReceivedFlag( 1 ); // int
	m_edtRoiY.SetWindowText( _T("600") );
	m_edtRoiY.ShowWindow(SW_HIDE);

	// Aspect Ratio
	m_edtAspectRatio.SetFont( &m_fntEdit );
	m_edtAspectRatio.SetForeColor( BLACK_COLOR );
	m_edtAspectRatio.SetBackColor( WHITE_COLOR );
	m_edtAspectRatio.SetReceivedFlag( 3 ); // Floating-Point
	m_edtAspectRatio.SetWindowText( _T("10") );
	
	//Threshold
	m_edtThreshold.SetFont( &m_fntEdit );
	m_edtThreshold.SetForeColor( BLACK_COLOR );
	m_edtThreshold.SetBackColor( WHITE_COLOR );
	m_edtThreshold.SetReceivedFlag( 1 ); // Floating-Point
	m_edtThreshold.SetWindowText( _T("0") );

	// Coaxial
	m_edtCoaxial.SetFont( &m_fntEdit );
	m_edtCoaxial.SetForeColor( BLACK_COLOR );
	m_edtCoaxial.SetBackColor( WHITE_COLOR );
	m_edtCoaxial.SetReceivedFlag( 1 ); // Floating-Point
	m_edtCoaxial.SetWindowText( _T("100") );
	
	// Ring
	m_edtRing.SetFont( &m_fntEdit );
	m_edtRing.SetForeColor( BLACK_COLOR );
	m_edtRing.SetBackColor( WHITE_COLOR );
	m_edtRing.SetReceivedFlag( 1 ); // Floating-Point
	m_edtRing.SetWindowText( _T("100") );
	
	// Contrast
	m_edtContrast.SetFont( &m_fntEdit );
	m_edtContrast.SetForeColor( BLACK_COLOR );
	m_edtContrast.SetBackColor( WHITE_COLOR );
	m_edtContrast.SetReceivedFlag( 3 ); // Floating-Point
	m_edtContrast.SetWindowText( _T("0.5") );
	
	// Brightness
	m_edtBrightness.SetFont( &m_fntEdit );
	m_edtBrightness.SetForeColor( BLACK_COLOR );
	m_edtBrightness.SetBackColor( WHITE_COLOR );
	m_edtBrightness.SetReceivedFlag( 3 ); // Floating-Point
	m_edtBrightness.SetWindowText( _T("0.5") );
	
	// Job File Path
	m_edtPath.SetFont( &m_fntEdit2 );
	m_edtPath.SetForeColor( BLACK_COLOR );
	m_edtPath.SetBackColor( WHITE_COLOR );
	m_edtPath.SetWindowText( (LPCTSTR)m_strPath );

	GetDlgItem(IDC_EDIT_CURRENT_FID_BLOCK)->SetFont( &m_fntEdit );
}

void CPaneRecipeGenFiducialNew::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	
	GetDlgItem(IDC_STATIC_INFO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_NUMBER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FID_TYPE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_Z_OFFSET)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TOOL_NUMBER)->SetFont( &m_fntStatic );
	
	// Camera No
	GetDlgItem(IDC_STATIC_CAMERA)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CAMERA_NO)->SetFont( &m_fntStatic );
	
	// Model
	GetDlgItem(IDC_STATIC_MODEL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TYPE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE_A)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE_B)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE_C)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POLARITY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VISION_ORIENTATION)->SetFont( &m_fntStatic );
	
	// Accept Score
	GetDlgItem(IDC_STATIC_ACCEPT_SCORE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ANGLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ASPECT_RATIO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_THRESHOLD1)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_SET_REFPOS_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SET_REFPOS_Y)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_CAM)->SetFont( &m_fntStatic );
	// Light
	GetDlgItem(IDC_STATIC_LIGHT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_COAXIAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_RING)->SetFont( &m_fntStatic );
	
	// Contrast & Brightness
	GetDlgItem(IDC_STATIC_CONTRASTBRIGHTNESS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CONTRAST)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_BRIGHTNESS)->SetFont( &m_fntStatic );
	
	// JobFile
	GetDlgItem(IDC_STATIC_JOB_FILE)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_CAMERA2)->SetFont( &m_fntStatic );
	// Inpsection Result
	m_stcInspResult.SetFont( &m_fntStatic );
	m_stcInspResult.SetForeColor( VALUE_FORE_COLOR );
	m_stcInspResult.SetBackColor( VALUE_BACK_COLOR );

	m_lboxResult.SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_ROI_SIZE)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_CURRENT_FID_BLOCK)->SetFont( &m_fntStatic );
}

void CPaneRecipeGenFiducialNew::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(130, "Arial Bold");
	
	m_cmbFidType.SetFont( &m_fntCombo );
	m_cmbFidType.SetCurSel( 0 );

	m_cmbToolNo.SetFont( &m_fntCombo );
	m_cmbToolNo.SetCurSel( 0 );

	m_cmbCamera.SetFont( &m_fntCombo );
	m_cmbCamera.SetCurSel( 1 );

	m_cmbCameraNo.SetFont( &m_fntCombo );
	m_cmbCameraNo.SetCurSel( 1 );
	
	m_cmbType.SetFont( &m_fntCombo );
	m_cmbType.SetCurSel( m_nModelType );

	m_cmbCameraSelect.SetFont( &m_fntCombo );
	m_cmbCameraSelect.SetCurSel( 1 );
	
	SelectPic( m_nModelType );
}

void CPaneRecipeGenFiducialNew::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntBtn2.DeleteObject();
	m_fntBtn3.DeleteObject();
	m_fntCombo.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntEdit2.DeleteObject();
	m_fntList.DeleteObject();
	m_fntStatic.DeleteObject();
	
	CFormView::OnDestroy();
}

HBRUSH CPaneRecipeGenFiducialNew::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_INFO)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MODEL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_POLARITY)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_ACCEPT_SCORE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_LIGHT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_CAM)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_CONTRASTBRIGHTNESS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_JOB_FILE)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneRecipeGenFiducialNew::SelectPic(int nType)
{
	if(nType < MODEL_PATTERN)
	{
		GetDlgItem(IDC_STATIC_PIC)->ShowWindow(SW_SHOW);
#ifdef USE_VISION_PRO
		GetDlgItem(IDC_VISION_PATTERN_FID)->ShowWindow(SW_HIDE);
#endif
	}
	else
	{
		GetDlgItem(IDC_STATIC_PIC)->ShowWindow(SW_HIDE);
#ifdef USE_VISION_PRO
		GetDlgItem(IDC_VISION_PATTERN_FID)->ShowWindow(SW_SHOW);
#endif
		BOOL bRes = gDeviceFactory.GetVision()->GetTrained(nType);

		if(bRes) 
			gDeviceFactory.GetVision()->DisplayTrainedImage(nType);
//		else
//			gDeviceFactory.GetVision()->ClearInteractiveGraphics(DISPLAYA);

	}
	switch( nType )
	{
	case 0 : // Annulus
		m_stcPic.SetBitmap( m_imgAnnulus );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( FALSE );
		break;
	case 1 : // Circle
		m_stcPic.SetBitmap( m_imgCircle );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( FALSE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( FALSE );
		break;
	case 2 : // Cross
		m_stcPic.SetBitmap( m_imgCross );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( TRUE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	case 3 : // Diamond
		m_stcPic.SetBitmap( m_imgDiamond );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	case 4 : // Double Rectangle
		m_stcPic.SetBitmap( m_imgDouble );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	case 5 : // Rectangle
		m_stcPic.SetBitmap( m_imgRect );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	case 6 : // Triangle
		m_stcPic.SetBitmap( m_imgTriangle );
		m_edtSizeA.EnableWindow( TRUE );
		m_edtSizeB.EnableWindow( TRUE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	default : // User Image
//		m_stcPic.SetBitmap( m_imgUserImage );
		m_edtSizeA.EnableWindow( FALSE );
		m_edtSizeB.EnableWindow( FALSE );
		m_edtSizeC.EnableWindow( FALSE );
		m_edtOrientation.EnableWindow( TRUE );
		break;
	}


}

void CPaneRecipeGenFiducialNew::OnSelChangeComboFidType() 
{
	int nType = m_cmbFidType.GetCurSel(); //Mechanical, Course, Skiving, Verify 
// Primary, Secondary

/*	m_chkUseDrill.EnableWindow(nType);
	m_cmbToolNo.EnableWindow(nType);

	if(nType == 0)
	{
		m_chkUseDrill.SetCheck(FALSE);
		m_chkUseVerify.EnableWindow(TRUE);
	}

  */
	if(m_nFidIndex == -1)
		return;
	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
	
	if(pFidData == NULL)
		return;

	switch (nType)
	{
	case 0 : //mechanical 
		pFidData->nFidType = FID_PRIMARY + FID_FIND;
		break;
	case 1 : // course
		pFidData->nFidType = FID_SECONDARY + FID_FIND;
		break;
	case 2 : // skiving
		pFidData->nFidType = FID_SECONDARY + FID_DRILL;
		break;
	case 3 : // verify	
		pFidData->nFidType = FID_PRIMARY + FID_FIND + FID_VERIFY;
		break;
	}
	SkivingCheck(); 
}

void CPaneRecipeGenFiducialNew::OnSelChangeComboToolNo() 
{
	return;
}

void CPaneRecipeGenFiducialNew::OnSelchangeComboCamera() 
{
	// ���ֳ� -> re : ������ ������ ! 
	int nSel;
	nSel = m_cmbCamera.GetCurSel();

	if(nSel == 0) // High
	{
		m_cmbCameraNo.SetCurSel(0);
		m_cmbCameraSelect.SetCurSel(0);
	}
	else if(nSel == 1) // Low
	{
		m_cmbCameraNo.SetCurSel(1);
		m_cmbCameraSelect.SetCurSel(1);
	}
	else // Low To High
	{
		m_cmbCameraNo.SetCurSel(1);
		m_cmbCameraSelect.SetCurSel(1);
	}
	
	int nCamNo = m_cmbCameraSelect.GetCurSel();
	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
	if( pFidData != NULL)
		this->SendMessage(UM_VISION_LAMP, nCamNo, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
	OnSelchangeComboCameraNo(); 
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnCamChange( nCamNo );

	int nCount = m_pProject->m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);
	if(!gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		if(pFidData == NULL)
		{
			m_nHoleFindCam = nSel;
			UpdateUIToHoleInfo();
			return;
		}

		for(int i=0;i<nCount; i++)
		{
			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			if(pFidData == NULL)
				return;

			int nFidType = GetCurrentFidType();
			if(nFidType != pFidData->nFidType)
				continue;
			pFidData->nCam = nSel;
		}
	}
	else
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		if(pFidData == NULL)
		{
			m_nHoleFindCam = nSel;
			UpdateUIToHoleInfo();
			return;
		}
		
		pFidData->nCam = nSel;
	}	SetValue( nSel );
}

void CPaneRecipeGenFiducialNew::OnSelchangeComboCameraNo() 
{
	if(gProcessINI.m_sProcessFidFind.bUseAllControl)
		SetValue( m_cmbCameraNo.GetCurSel() );
	else
		SetValue( m_cmbCameraNo.GetCurSel() );

	int nCamNo = m_cmbCameraNo.GetCurSel();
	
}

void CPaneRecipeGenFiducialNew::SetValue(int nNumber)
{
	CString str1 = _T(""), str2 = _T(""), str3 = _T(""), str4 = _T("");
	str1.Format(_T("%d"), m_nCoaxial[nNumber]);
	str2.Format(_T("%d"), m_nRing[nNumber]);
	str3.Format(_T("%.1f"), m_dContrast[nNumber]);
	str4.Format(_T("%.1f"), m_dBrightness[nNumber]);
	
	m_edtCoaxial.SetWindowText(str1);
	m_edtRing.SetWindowText(str2);
	m_edtContrast.SetWindowText(str3);
	m_edtBrightness.SetWindowText(str4);	

	m_SliderCoaxial.SetPos(m_nCoaxial[nNumber]);
	m_SliderRing.SetPos(m_nRing[nNumber]);

	UpdateData(FALSE);
}

void CPaneRecipeGenFiducialNew::OnSelchangeComboType() 
{
	int nType = m_cmbType.GetCurSel();
	
	if(m_nModelType == nType)
		return;
	else
		m_nModelType = nType;
	
	SelectPic( m_nModelType );

	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);

	if(!gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		if(pFidData == NULL)
		{
			m_sHoleVisInfo.nModelType = nType;
			return;
		}
		
//		for(int i = 0; i<nCount; i++)
//		{
//			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
//			if(pFidData == NULL)
//				return;

			pFidData->sVisInfo.nModelType = nType;
//		}
	}
	else
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		if(pFidData == NULL)
		{
			m_sHoleVisInfo.nModelType = nType;
			return;
		}

		pFidData->sVisInfo.nModelType = nType;
	}
}

void CPaneRecipeGenFiducialNew::OnButtonApplySameFidParam()
{
	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
	if(pFidData == NULL)
		return;

	if(IDNO == ErrMessage(_T("Do you want to apply data to other same type fiducial?"), MB_YESNO))
		return;
	
	CString str;
	double dTempVal;
	int	nTempVal;
	int nFidType;
	
	UpdateData(TRUE);

	// �Է°� ��������
	
	m_edtSizeA.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeA.IsWindowEnabled()) 
	{
		m_edtSizeA.SetFocus();
		ErrMessage(_T("0 < SizeA <= 5(mm)"));
		return;
	}
	
	m_edtSizeB.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeB.IsWindowEnabled()) 
	{
		m_edtSizeB.SetFocus();
		ErrMessage(_T("0 < SizeB <= 5(mm)"));
		return;
	}
	
	m_edtSizeC.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeC.IsWindowEnabled()) 
	{
		m_edtSizeC.SetFocus();
		ErrMessage(_T("0 < SizeC <= 5(mm)"));
		return;
	}
	
	m_edtSize.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_PERCENT || nTempVal < 0) 
	{
		m_edtSize.SetFocus();
		ErrMessage(_T("0 <= Size <= 100(%)"));
		return;
	}
	
	m_edtAngle.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_ANGLE || nTempVal < 0) 
	{
		m_edtAngle.SetFocus();
		ErrMessage(_T("0 <= Angle <= 360"));
		return;
	}
	
	m_edtAspectRatio.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_PERCENT || nTempVal < 0) 
	{
		m_edtAspectRatio.SetFocus();
		ErrMessage(_T("0 <= Aspect Ratio <= 100(%)"));
		return;
	}

	m_edtThreshold.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_PERCENT || nTempVal < 0) 
	{
		m_edtAspectRatio.SetFocus();
		ErrMessage(_T("0 <= Threshold <= 255"));
		return;
	}
	// �Է°� �����Ϸ�

	m_edtPath.GetWindowText(str);
	lstrcpy(m_pProject->m_szJobFilePath, (LPCSTR)str);

	nFidType = GetCurrentFidType();

	POSITION pos = m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while (pos)
	{
		pFidData = m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);

		if(nFidType != pFidData->nFidType)
			continue;

		if(gProcessINI.m_sProcessFidFind.bUseAllControl)
			pFidData->nCam = m_cmbCamera.GetCurSel();
		else
			pFidData->nCam = 1;

		m_edtFidOffsetZ.GetWindowText(str);
		dTempVal = atof(str);
		pFidData->dOffsetZ = dTempVal;
	
		pFidData->nFidType = nFidType;
		
		pFidData->sVisInfo.nModelType = (long)m_nModelType;
		
		m_edtSizeA.GetWindowText(str);
		dTempVal = atof(str);
		pFidData->sVisInfo.dSizeA = (float)dTempVal;
		
		m_edtSizeB.GetWindowText(str);
		dTempVal = atof(str);
		pFidData->sVisInfo.dSizeB = (float)dTempVal;
		
		m_edtSizeC.GetWindowText(str);
		dTempVal = atof(str);
		pFidData->sVisInfo.dSizeC = (float)dTempVal;
		
		pFidData->sVisInfo.nPolarity = (long)m_nPolarity;
		
		m_edtSize.GetWindowText(str);
		nTempVal = atoi(str);
		pFidData->sVisInfo.dScoreSize = nTempVal;
		
		m_edtAngle.GetWindowText(str);
		nTempVal = atoi(str);
		pFidData->sVisInfo.dScoreAngle = nTempVal;
		
		m_edtAspectRatio.GetWindowText(str);
		nTempVal = atoi(str);
		pFidData->sVisInfo.dAspectRatio = nTempVal;
		
		m_edtThreshold.GetWindowText(str);
		nTempVal = atoi(str);
		pFidData->sVisInfo.nThreshold = nTempVal;

		for(int i=0; i<4; i++)
		{
			pFidData->sVisInfo.nCoaxial[i] = m_nCoaxial[i];
			pFidData->sVisInfo.nRing[i] = m_nRing[i];
			pFidData->sVisInfo.dBrightness[i] = m_dBrightness[i];
			pFidData->sVisInfo.dContrast[i] = m_dContrast[i];
		}
	}
}

void CPaneRecipeGenFiducialNew::OnButtonApplyParamCam() 
{
	if(IDNO == ErrMessage(_T("Do you want to apply camera parameter to all camera in this fiducial?"), MB_YESNO))
		return;
	
	UpdateData(TRUE);

	int nCam = m_cmbCameraNo.GetCurSel();
	CString str;
	m_edtCoaxial.GetWindowText(str);
	int nTempVal = atoi(str);
	if(nTempVal > 255 || nTempVal < 0) 
		return;
	else
		m_nCoaxial[nCam] = nTempVal;
	
	m_edtRing.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > 255 || nTempVal < 0) 
		return;
	else
		m_nRing[nCam] = nTempVal;
	
	m_edtBrightness.GetWindowText(str);
	double dTempVal = atof(str);
	if(dTempVal > 1.0 || dTempVal < 0.0) 
		return;
	else
		m_dBrightness[nCam] = dTempVal;
	
	m_edtContrast.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > 1.0 || dTempVal < 0.0) 
		return;
	else
		m_dContrast[nCam] = dTempVal;

	for(int i=0; i<4; i++)
	{
		m_nCoaxial[i] = m_nCoaxial[nCam];
		m_nRing[i] = m_nRing[nCam];
		m_dContrast[i] = m_dContrast[nCam];
		m_dBrightness[i] = m_dBrightness[nCam];
	}
	
	UpdateData(FALSE);
}

void CPaneRecipeGenFiducialNew::OnButtonApplyCam()
{
	if(IDNO == ErrMessage(_T("Do you want to apply camera number to all fiducial?"), MB_YESNO))
		return;

	UpdateData(TRUE);

	LPFIDDATA pFidData;
	POSITION pos = m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while (pos)
	{
		pFidData = m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		
		pFidData->nCam = m_cmbCamera.GetCurSel();
	}
}

void CPaneRecipeGenFiducialNew::OnButtonApplyParam() 
{
	if(IDNO == ErrMessage(_T("Do you want to apply data to all fiducial?"), MB_YESNO))
		return;
	
	CString str;
	double dTempVal;
	int	nTempVal;
	int nFidType;
	
	UpdateData(TRUE);

	SkivingCheck();

	// �Է°� ��������
	
	m_edtSizeA.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeA.IsWindowEnabled()) 
	{
		m_edtSizeA.SetFocus();
		ErrMessage(_T("0 < SizeA <= 5(mm)"));
		return;
	}
	
	m_edtSizeB.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeB.IsWindowEnabled()) 
	{
		m_edtSizeB.SetFocus();
		ErrMessage(_T("0 < SizeB <= 5(mm)"));
		return;
	}
	
	m_edtSizeC.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeC.IsWindowEnabled()) 
	{
		m_edtSizeC.SetFocus();
		ErrMessage(_T("0 < SizeC <= 5(mm)"));
		return;
	}

	m_edtSize.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_PERCENT || nTempVal < 0) 
	{
		m_edtSize.SetFocus();
		ErrMessage(_T("0 <= Size <= 100(%)"));
		return;
	}
	
	m_edtAngle.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_ANGLE || nTempVal < 0) 
	{
		m_edtAngle.SetFocus();
		ErrMessage(_T("0 <= Angle <= 360"));
		return;
	}
	
	m_edtAspectRatio.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_PERCENT || nTempVal < 0) 
	{
		m_edtAspectRatio.SetFocus();
		ErrMessage(_T("0 <= Aspect Ratio <= 100(%)"));
		return;
	}

	m_edtThreshold.GetWindowText(str);
	nTempVal = atoi(str);
	if( nTempVal < 0 || nTempVal > 255)
	{
		m_edtThreshold.SetFocus();
		ErrMessage(_T("0 <= Threshold <= 255"));
		return;
	}
	
	// �Է°� �����Ϸ�

	m_edtPath.GetWindowText(str);
	lstrcpy(m_pProject->m_szJobFilePath, (LPCSTR)str);

	LPFIDDATA pFidData;
	POSITION pos = m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while (pos)
	{
		pFidData = m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);

		pFidData->nCam = m_cmbCamera.GetCurSel();

		m_edtFidOffsetZ.GetWindowText(str);
		dTempVal = atof(str);
		pFidData->dOffsetZ = dTempVal;
	
		nFidType = m_cmbFidType.GetCurSel();
		switch (nFidType)
		{
		case 0 : //mechanical 
			pFidData->nFidType = FID_PRIMARY + FID_FIND;
			break;
		case 1 : // course
			pFidData->nFidType = FID_SECONDARY + FID_FIND;
			break;
		case 2 : // skiving
			pFidData->nFidType = FID_SECONDARY + FID_DRILL;
			break;
		case 3 : // verify	
			pFidData->nFidType = FID_FIND + FID_VERIFY + FID_PRIMARY;
			break;
		}

		pFidData->sVisInfo.nModelType = (long)m_nModelType;
		
		m_edtSizeA.GetWindowText(str);
		dTempVal = atof(str);
		pFidData->sVisInfo.dSizeA = (float)dTempVal;
		
		m_edtSizeB.GetWindowText(str);
		dTempVal = atof(str);
		pFidData->sVisInfo.dSizeB = (float)dTempVal;
		
		m_edtSizeC.GetWindowText(str);
		dTempVal = atof(str);
		pFidData->sVisInfo.dSizeC = (float)dTempVal;
		
		pFidData->sVisInfo.nPolarity = (long)m_nPolarity;
		
		m_edtSize.GetWindowText(str);
		nTempVal = atoi(str);
		pFidData->sVisInfo.dScoreSize = nTempVal;
		
		m_edtAngle.GetWindowText(str);
		nTempVal = atoi(str);
		pFidData->sVisInfo.dScoreAngle = nTempVal;
		
		m_edtAspectRatio.GetWindowText(str);
		nTempVal = atoi(str);
		pFidData->sVisInfo.dAspectRatio = nTempVal;
		
		m_edtThreshold.GetWindowText(str);
		nTempVal = atoi(str);
		pFidData->sVisInfo.nThreshold = nTempVal;

		for(int i=0; i<4; i++)
		{
			pFidData->sVisInfo.nCoaxial[i] = m_nCoaxial[i];
			pFidData->sVisInfo.nRing[i] = m_nRing[i];
			pFidData->sVisInfo.dBrightness[i] = m_dBrightness[i];
			pFidData->sVisInfo.dContrast[i] = m_dContrast[i];
		}
	}
}

void CPaneRecipeGenFiducialNew::OnButtonDataUpdate() 
{
	CString strVal;
	m_edtFidIndex.GetWindowText(strVal);

	int nIndex = atoi(strVal) - 1;

	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, nIndex);

	if(pFidData == NULL)
	{
		ErrMessage(_T("There is no fiducial data"));
		return;
	}

	UpdateData(TRUE);

	CString str;
	double dTempVal;
	int	nTempVal;
	
	// �Է°� ��������

	m_edtSizeA.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeA.IsWindowEnabled()) 
	{
		m_edtSizeA.SetFocus();
		ErrMessage(_T("0 < SizeA <= 5(mm)"));
		return;
	}
	
	m_edtSizeB.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeB.IsWindowEnabled()) 
	{
		m_edtSizeB.SetFocus();
		ErrMessage(_T("0 < SizeB <= 5(mm)"));
		return;
	}
	
	m_edtSizeC.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeC.IsWindowEnabled()) 
	{
		m_edtSizeC.SetFocus();
		ErrMessage(_T("0 < SizeC <= 5(mm)"));
		return;
	}

	m_edtSize.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_PERCENT || nTempVal < 0) 
	{
		m_edtSize.SetFocus();
		ErrMessage(_T("0 <= Size <= 100(%)"));
		return;
	}

	m_edtAngle.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_ANGLE || nTempVal < 0) 
	{
		m_edtAngle.SetFocus();
		ErrMessage(_T("0 <= Angle <= 360"));
		return;
	}
	
	m_edtAspectRatio.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_PERCENT || nTempVal < 0) 
	{
		m_edtAspectRatio.SetFocus();
		ErrMessage(_T("0 <= Aspect Ratio <= 100(%)"));
		return;
	}

	m_edtThreshold.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > MAX_PERCENT || nTempVal < 0) 
	{
		m_edtThreshold.SetFocus();
		ErrMessage(_T("0 <= Threshold <= 255"));
		return;
	}

	// �Է°� �����Ϸ�

	m_edtPath.GetWindowText(str);
	lstrcpy(m_pProject->m_szJobFilePath, (LPCSTR)str);
	
	pFidData->nCam = m_cmbCamera.GetCurSel();

	m_edtFidOffsetZ.GetWindowText(str);
	dTempVal = atof(str);
	pFidData->dOffsetZ = dTempVal;


	m_edtRoiX2.GetWindowText(str);
	dTempVal = atoi(str);
	m_pProject->m_nRoiX2 = dTempVal;

	m_edtRoiX.GetWindowText(str);
	dTempVal = atoi(str);
	m_pProject->m_nRoiX = dTempVal;

	m_edtRoiY.GetWindowText(str);
	dTempVal = atoi(str);
	m_pProject->m_nRoiY = dTempVal;
	
	int nFidType = m_cmbFidType.GetCurSel();

	switch (nFidType)
	{
	case 0 : //mechanical 
		pFidData->nFidType = FID_PRIMARY + FID_FIND;
		break;
	case 1 : // course
		pFidData->nFidType = FID_SECONDARY + FID_FIND;
		break;
	case 2 : // skiving
		pFidData->nFidType = FID_SECONDARY + FID_DRILL;
		break;
	case 3 : // verify	
		pFidData->nFidType = FID_FIND + FID_VERIFY+ FID_PRIMARY;
		break;
	}

	pFidData->sVisInfo.nModelType = (long)m_nModelType;
	
	m_edtSizeA.GetWindowText(str);
	dTempVal = atof(str);
	pFidData->sVisInfo.dSizeA = (float)dTempVal;
	
	m_edtSizeB.GetWindowText(str);
	dTempVal = atof(str);
	pFidData->sVisInfo.dSizeB = (float)dTempVal;
	
	m_edtSizeC.GetWindowText(str);
	dTempVal = atof(str);
	pFidData->sVisInfo.dSizeC = (float)dTempVal;
	
	pFidData->sVisInfo.nPolarity = (long)m_nPolarity;
	 
	m_edtSize.GetWindowText(str);
	nTempVal = atoi(str);
	pFidData->sVisInfo.dScoreSize = nTempVal;
	
	m_edtAngle.GetWindowText(str);
	nTempVal = atoi(str);
	pFidData->sVisInfo.dScoreAngle = nTempVal;
	
	m_edtAspectRatio.GetWindowText(str);
	nTempVal = atoi(str);
	pFidData->sVisInfo.dAspectRatio = nTempVal;
	
	m_edtThreshold.GetWindowText(str);
	nTempVal = atoi(str);
	pFidData->sVisInfo.nThreshold = nTempVal;

	for(int i=0; i<4; i++)
	{
		pFidData->sVisInfo.nCoaxial[i] = m_nCoaxial[i];
		pFidData->sVisInfo.nRing[i] = m_nRing[i];
		pFidData->sVisInfo.dBrightness[i] = m_dBrightness[i];
		pFidData->sVisInfo.dContrast[i] = m_dContrast[i];
	}
}

void CPaneRecipeGenFiducialNew::OnCheckUseDrill() 
{
	return;
}

void CPaneRecipeGenFiducialNew::OnCheckUseVerify() 
{
	return;
}

void CPaneRecipeGenFiducialNew::EnableControl(BOOL bUse)
{
	if(bUse)
	{
		GetDlgItem(IDC_COMBO_FID_TYPE)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BUTTON_APPLY_TO_ALL)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_CHECK_FID_DRILL)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_COMBO_TOOL_NUMBER)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_CHECK_FID_VERIFY)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_COMBO_CAMERA_NO)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BUTTON_APPLY_TO_ALL_CAM)->ShowWindow(SW_SHOW);
		if(!gSystemINI.m_sHardWare.nUseLampRS232)
		{
			GetDlgItem(IDC_STATIC_LIGHT)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_COAXIAL)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDIT_COAXIAL)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_RING)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDIT_RING)->EnableWindow(FALSE);
		}
		else
		{
			GetDlgItem(IDC_STATIC_LIGHT)->EnableWindow(TRUE);
			GetDlgItem(IDC_STATIC_COAXIAL)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDIT_COAXIAL)->EnableWindow(TRUE);
			GetDlgItem(IDC_STATIC_RING)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDIT_RING)->EnableWindow(TRUE);
			GetDlgItem(IDC_STATIC_LIGHT)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_STATIC_COAXIAL)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_EDIT_COAXIAL)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_STATIC_RING)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_EDIT_RING)->ShowWindow(SW_SHOW);
		}
		GetDlgItem(IDC_STATIC_FID_TYPE)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_STATIC_TOOL_NUMBER)->ShowWindow(SW_SHOW);	
		GetDlgItem(IDC_STATIC_CAMERA_NO)->ShowWindow(SW_SHOW);
		
		//
//		GetDlgItem(IDC_STATIC_Z_OFFSET)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_STATIC_OFFSET_MM)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_EDIT_Z_OFFSET)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BUTTON_APPLY_TO_ALL)->ShowWindow(SW_SHOW);

		GetDlgItem(IDC_BUTTON_APPLY_TO_ALL_FID)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BUTTON_APPLY_TO_SAMETYPE_FID)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_CHECK_FID_FIND_ORDER)->ShowWindow(SW_SHOW);
		//

//		GetDlgItem(IDC_STATIC_INFO)->ShowWindow(SW_SHOW);	
//		GetDlgItem(IDC_STATIC_CAM)->ShowWindow(SW_SHOW);	
//		GetDlgItem(IDC_CHECK_FID_VERIFY)->ShowWindow(SW_SHOW);
//		GetDlgItem(IDC_CHECK_FID_DRILL)->ShowWindow(SW_SHOW);
	}
	else
	{
//		GetDlgItem(IDC_COMBO_FID_TYPE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_APPLY_TO_ALL)->ShowWindow(SW_HIDE);
//		GetDlgItem(IDC_CHECK_FID_DRILL)->ShowWindow(SW_HIDE);
//		GetDlgItem(IDC_COMBO_TOOL_NUMBER)->ShowWindow(SW_HIDE);
//		GetDlgItem(IDC_CHECK_FID_VERIFY)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_COMBO_CAMERA_NO)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_APPLY_TO_ALL_CAM)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_CAMERA_NO)->ShowWindow(SW_HIDE);	
		if(!gSystemINI.m_sHardWare.nUseLampRS232)
		{
			GetDlgItem(IDC_STATIC_LIGHT)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_COAXIAL)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDIT_COAXIAL)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_RING)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDIT_RING)->EnableWindow(FALSE);
		}
		else
		{
			GetDlgItem(IDC_STATIC_LIGHT)->EnableWindow(TRUE);
			GetDlgItem(IDC_STATIC_COAXIAL)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDIT_COAXIAL)->EnableWindow(TRUE);
			GetDlgItem(IDC_STATIC_RING)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDIT_RING)->EnableWindow(TRUE);
			GetDlgItem(IDC_STATIC_LIGHT)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_STATIC_COAXIAL)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_EDIT_COAXIAL)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_STATIC_RING)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_EDIT_RING)->ShowWindow(SW_SHOW);
		}
//		GetDlgItem(IDC_STATIC_FID_TYPE)->ShowWindow(SW_HIDE);
//		GetDlgItem(IDC_STATIC_TOOL_NUMBER)->ShowWindow(SW_HIDE);	
		
		
//		GetDlgItem(IDC_STATIC_INFO)->ShowWindow(SW_HIDE);	
//		GetDlgItem(IDC_STATIC_CAM)->ShowWindow(SW_HIDE);	
//		GetDlgItem(IDC_CHECK_FID_VERIFY)->ShowWindow(SW_HIDE);
//		GetDlgItem(IDC_CHECK_FID_DRILL)->ShowWindow(SW_HIDE);
		//
//		GetDlgItem(IDC_STATIC_Z_OFFSET)->ShowWindow(SW_HIDE);
//		GetDlgItem(IDC_STATIC_OFFSET_MM)->ShowWindow(SW_HIDE);
//		GetDlgItem(IDC_EDIT_Z_OFFSET)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_APPLY_TO_ALL)->ShowWindow(SW_HIDE);
		
		GetDlgItem(IDC_BUTTON_APPLY_TO_ALL_FID)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_APPLY_TO_SAMETYPE_FID)->ShowWindow(SW_HIDE);
//		GetDlgItem(IDC_CHECK_FID_FIND_ORDER)->ShowWindow(SW_HIDE);
		//
	}
}

void CPaneRecipeGenFiducialNew::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;

	switch(nLevel)
	{
	case 0: // Operator
		m_edtAspectRatio.EnableWindow(FALSE);
		m_edtSize.EnableWindow(FALSE);
		break;
	case 1: // Engineer
	case 2: // EO Engineer
	case 3: // Super Engineer
		m_edtAspectRatio.EnableWindow(TRUE);
		m_edtSize.EnableWindow(TRUE);
		break;
	}
}

void CPaneRecipeGenFiducialNew::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	DrawData();
	// Do not call CFormView::OnPaint() for painting messages
}

void CPaneRecipeGenFiducialNew::DrawData()
{
	if(m_pProject == NULL)
		return;

	CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
	CDC BufferDC;
	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
	
	BufferDC.CreateCompatibleDC(&dc);
	CBitmap bmpBuffer;
	bmpBuffer.CreateCompatibleBitmap(&dc,cRect.Width(), cRect.Height());
	
	CBitmap *pOldBitmap = (CBitmap*)BufferDC.SelectObject(&bmpBuffer);
	
	CBrush cBr(RGB(0, 0, 0));
	BufferDC.FrameRect(&cRect, &cBr);
	BufferDC.FillSolidRect(&cRect, RGB(255, 255, 255));
	
	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	BufferDC.SelectClipRgn(&cRgn);
	
//	SetDCCoord(&BufferDC);
	
	int nPenSize;
	nPenSize = 3;
	
	CPen pen;
	CPen* pOldPen;
	CBrush cBr2;
	CBrush* pOldBrush;
	
	pen.CreatePen(PS_SOLID, nPenSize, RGB(0, 0, 200));
	pOldPen = BufferDC.SelectObject(&pen);
	
	cBr2.CreateSolidBrush(RGB(0, 0, 200));
	pOldBrush = BufferDC.SelectObject(&cBr2);
	
	// draw
	if(m_pProject)
	{
		m_pProject->Draw(&BufferDC, cRect, FALSE, TRUE, m_nFidIndex);
	}
	
	BufferDC.SelectObject(pOldBrush);
	BufferDC.SelectObject(pOldPen);
	
//	GetDlgItem(IDC_STATIC_DRAW)->GetWindowRect(&cRect);
	dc.BitBlt(0,0,cRect.Width(),cRect.Height(),&BufferDC,0,0,SRCCOPY);
	
	BufferDC.SelectObject(pOldBitmap);
	// Do not call CFormView::OnPaint() for painting messages
}

void CPaneRecipeGenFiducialNew::OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	HTREEITEM hItem = pNMTreeView->itemNew.hItem;
	int nIndex = m_ctrTreeTool.GetItemData(hItem);
	
	m_nFidIndex = nIndex/100;
	
	ChangeDisplay(m_nFidIndex);
	
	*pResult = 0;
}

BOOL CPaneRecipeGenFiducialNew::GetData(DProject &tempDProject)
{
	CString strData;
	m_edtPath.GetWindowText(strData);
	int n = strData.GetLength();
	if(n <= 0)
	{
// 110604 yhchung pattern�� �ƴѰ�� vpp�� �ʿ���� ���� ����
//		CString strString;
//		strString.LoadString(IDS_VISION_PROJECT);
//		ErrMessage(strString);
//		return FALSE;
	}
	int nCount = m_pProject->m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);
	LPFIDDATA pTemp, pTemp2;
	for(int i=0; i< nCount; i++)
	{
		pTemp = tempDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
		pTemp2 = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);

		pTemp = pTemp2;
	}
	
//	memcpy(tempDProject.m_Glyphs.m_HoleData, m_sHoleVisInfo, sizeof(VISION_INFO));
	tempDProject.m_Glyphs.m_HoleFindData.sVisInfo = m_sHoleVisInfo;
	tempDProject.m_Glyphs.m_HoleFindData.nCam = m_nHoleFindCam;


	tempDProject.m_bUseRoiSize2 = m_chkRoiSize2.GetCheck();//20170808
	m_edtRoiX2.GetWindowText(strData);
	tempDProject.m_nRoiX2 = atoi(strData);

	BOOL bEasyTestShow = ::AfxGetMainWnd()->SendMessage(UM_IS_SHOW_EASY_TEST_WINDOW);//��������
	if(bEasyTestShow)
	   tempDProject.m_nDataLoadStep = m_pProject->m_nDataLoadStep;

	return TRUE;
}

BOOL CPaneRecipeGenFiducialNew::SetData(DProject& mDproject)
{
	m_pProject = &mDproject;
	
	m_pProject->InitFidTolData();
//	memcpy(m_sHoleVisInfo, mDproject.m_Glyphs.m_HoleData, sizeof(VISION_INFO));

	m_sHoleVisInfo = mDproject.m_Glyphs.m_HoleFindData.sVisInfo;
	m_nHoleFindCam = mDproject.m_Glyphs.m_HoleFindData.nCam;
	EnableControl(gProcessINI.m_sProcessFidFind.bUseAllControl);

	m_bDrawMode = FALSE;
	m_ctrTreeTool.DeleteAllItems();
	m_bDrawMode = TRUE;

	CString strText;
	int nCount = -1;
	HTREEITEM hRoot;
	BOOL bAdd = FALSE;

//	LPFIDDATA pFidData;
//	POSITION pos = m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
//	while(pos)
//	{
//		pFidData = m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);

	int nFidCount;
#ifndef __PUSAN_LDD__
	nFidCount = m_pProject->m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);
#else
	nFidCount = 4;
#endif
	for(int i=0; i<nFidCount; i++) //m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetCount(); i++)
	{
		nCount++;
		bAdd = TRUE;
		strText.Format(_T("Fiducial %d"), nCount+1);
		hRoot = m_ctrTreeTool.InsertItem(strText, 0, 1);
		if (hRoot != NULL)
		{
			m_ctrTreeTool.SetItemData(hRoot, nCount * 100);
		}
		m_ctrTreeTool.Expand(hRoot, TVE_EXPAND);
	}

	// hole
	nCount++;
	bAdd = TRUE;
	strText.Format(_T("Hole"), nCount+1);
	hRoot = m_ctrTreeTool.InsertItem(strText, 0, 1);
	if (hRoot != NULL)
	{
		m_ctrTreeTool.SetItemData(hRoot, nCount * 100);
	}
	m_ctrTreeTool.Expand(hRoot, TVE_EXPAND);

	if(nCount == -1)
		return FALSE;
	
	int nToolCount = 0;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(m_pProject->m_pToolCode[i]->m_bUseTool)
		{
			nToolCount++;
		}
	}
	m_cmbToolNo.ResetContent();

	for(int i = 0; i<nToolCount; i++)
	{
		strText.Format(_T("Tool %d"), i);
		m_cmbToolNo.AddString(strText);
	}
	
	if(bAdd)
		m_nFidIndex = 0;
	

	CString str;
	str.Format(_T("%s"), mDproject.m_szVisionProjectName);
//	strcpy_s((LPSTR)(LPCTSTR)str, mDproject.m_szVisionProjectName);
	m_edtPath.SetWindowText(str);

	CString strData;
	strData.Format("%.3f",mDproject.m_dRefPosX);
	m_edtRefPosX.SetWindowText( strData );

	strData.Format("%.3f",mDproject.m_dRefPosY);
	m_edtRefPosY.SetWindowText( strData );


	ChangeDisplay(m_nFidIndex);

	return TRUE;
}

void CPaneRecipeGenFiducialNew::OnButtonJobFileOpen()
{
	if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION ||
		gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
	{
		TCHAR BASED_CODE szFilter[] = _T("Job Files (*.Job)|*.job|All Files (*.*)|*.*||");
		
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
		
		CFileDialog dlg(TRUE, _T("*.Job"), NULL, dwFlags, szFilter);
		
		CString strPath;
		strPath.Format(_T("%s\\JobFile\\"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
		dlg.m_ofn.lpstrInitialDir = strPath;
		
		if(IDOK != dlg.DoModal())
			return;
		
		m_strPath = dlg.GetPathName();
	}
	else
	{
		TCHAR BASED_CODE szFilter[] = _T("VisionPro Project Files (*.vpp)|*.vpp|All Files (*.*)|*.*||");
		
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
		
		CFileDialog dlg(TRUE, _T("*.vpp"), NULL, dwFlags, szFilter);
		
		dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetVisionProjectPath();
		
		if(IDOK != dlg.DoModal())
			return;
		
		CString str;
		HVision* pVision = gDeviceFactory.GetVision();
		pVision->LoadProject(dlg.GetPathName());
		str.Format(_T("%s"), dlg.GetPathName());
		strcpy_s(m_pProject->m_szVisionProjectName, str);

		m_strPath = dlg.GetPathName();
	}
	
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pVision->m_edtProjectPath.SetWindowText(m_strPath);
	m_edtPath.SetWindowText(m_strPath);
	strcpy_s(m_pProject->m_szVisionProjectName, m_strPath);


}

void CPaneRecipeGenFiducialNew::ChangeControl(BOOL bUse)
{
	GetDlgItem(IDC_COMBO_TYPE)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_SIZE_A)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_SIZE_B)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_SIZE_C)->ShowWindow(bUse);
	GetDlgItem(IDC_RADIO_DARK)->ShowWindow(bUse);
	GetDlgItem(IDC_RADIO_LIGHT)->ShowWindow(bUse);
	GetDlgItem(IDC_RADIO_NONE)->ShowWindow(bUse);
//	GetDlgItem(IDC_EDIT_SIZE)->ShowWindow(bUse);
//	GetDlgItem(IDC_EDIT_ANGLE)->ShowWindow(bUse);
//	GetDlgItem(IDC_EDIT_ASPECTRATIO)->ShowWindow(bUse);
//	GetDlgItem(IDC_COMBO_CAMERA)->ShowWindow(bUse);
//	GetDlgItem(IDC_COMBO_CAMERA_NO)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_CONTRAST)->ShowWindow(bUse);
	GetDlgItem(IDC_EDIT_BRIGHTNESS)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_TYPE)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_A)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_B)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_C)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_VISION_ORIENTATION)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_A_MM)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_B_MM)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE_C_MM)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_VISION_ORIENTATION_MM)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_PIC)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_SIZE)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_ANGLE)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_ASPECT_RATIO)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_SIZE_PER)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_ANGLE_DEG)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_ASPECT_RATIO_PER)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_CAMERA)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_CAMERA_NO)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_CONTRAST)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_BRIGHTNESS)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_CONTRAST_PER)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_BRIGHTNESS_PER)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_INFO)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_MODEL)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_POLARITY)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_ACCEPT_SCORE)->ShowWindow(bUse);
//	GetDlgItem(IDC_STATIC_CAM)->ShowWindow(bUse);
	GetDlgItem(IDC_STATIC_CONTRASTBRIGHTNESS)->ShowWindow(bUse);
	
//	GetDlgItem(IDC_STATIC_JOB_FILE)->ShowWindow(bUse);
//	GetDlgItem(IDC_EDIT_JOB_FILE)->ShowWindow(bUse);
//	GetDlgItem(IDC_BUTTON_JOB_FILE_OPEN)->ShowWindow(bUse);
/*
	if(!bUse)
	{
		CRect rtPos1, rtPos2;
		GetDlgItem(IDC_STATIC_LIGHT)->GetWindowRect( rtPos1 );
		GetDlgItem(IDC_STATIC_MODEL)->GetWindowRect( rtPos2 );
		rtPos2.top = rtPos2.top - 29;
		GetDlgItem(IDC_STATIC_LIGHT)->MoveWindow( rtPos2.left - 32, rtPos2.top, rtPos2.Width(), rtPos1.Height(), TRUE );
		
		GetDlgItem(IDC_STATIC_COAXIAL)->GetWindowRect( rtPos1 );
		GetDlgItem(IDC_STATIC_TYPE)->GetWindowRect( rtPos2 );
		rtPos2.left = rtPos2.left - 32;
		rtPos2.top = rtPos2.top - 29;
		GetDlgItem(IDC_STATIC_COAXIAL)->MoveWindow( rtPos2.left, rtPos2.top, rtPos1.Width(), rtPos1.Height(), TRUE);
		int nWidth = rtPos1.Width() + 15;
		GetDlgItem(IDC_EDIT_COAXIAL)->MoveWindow( rtPos2.left + nWidth, rtPos2.top, rtPos1.Width(), rtPos1.Height(), TRUE);
		GetDlgItem(IDC_STATIC_RING)->MoveWindow( rtPos2.left + nWidth * 2, rtPos2.top, rtPos1.Width(), rtPos1.Height(), TRUE);
		GetDlgItem(IDC_EDIT_COAXIAL)->GetWindowRect( rtPos1 );
		GetDlgItem(IDC_EDIT_RING)->MoveWindow( rtPos2.left + nWidth * 3, rtPos2.top, rtPos1.Width(), rtPos1.Height(), TRUE);
	}
*/
}

void CPaneRecipeGenFiducialNew::ChangeDisplay(int nFidIndex)
{
	UpdateData(TRUE);
	BOOL bAllControl = gProcessINI.m_sProcessFidFind.bUseAllControl;

	if(bAllControl)
		EnableControl(TRUE);
	else
		EnableControl(FALSE);

	if(nFidIndex == -1)
		return;

	CString str;
 	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, nFidIndex);

	if(pFidData == NULL)
	{
		UpdateUIToHoleInfo();
		return;
	}
	m_cmbType.EnableWindow(TRUE);

	int nType = pFidData->nFidType;
	if(nType == FID_PRIMARY + FID_FIND ) // Mechanical
	{
		nType = 0;
	}
	else if(nType == FID_SECONDARY + FID_FIND ) // Course
	{
		nType = 1;
	}
	else if(nType == FID_SECONDARY + FID_DRILL ) // Skiving
	{
		nType = 2;
	}
	else // Verify
	{
		nType = 3;
	}

	m_cmbFidType.SetCurSel(nType);

	str.Format(_T("%d"), nFidIndex+1);
	m_edtFidIndex.SetWindowText(str);


/*
	if(bAllControl)
	{
		if(nType == 0)
		{
			m_chkUseDrill.SetCheck(FALSE);
//			m_chkUseVerify.EnableWindow(TRUE);
		}
	

		if(pFidData->nFidType & FID_FIND)
		{
			m_chkUseDrill.SetCheck(FALSE);
//			m_chkUseDrill.EnableWindow(TRUE);
	//		m_cmbToolNo.EnableWindow(TRUE);
//			m_chkUseVerify.EnableWindow(TRUE);
		}
		else if(pFidData->nFidType & FID_DRILL)
		{
			m_chkUseDrill.SetCheck(TRUE);
//			m_chkUseVerify.EnableWindow(FALSE);
			m_chkUseVerify.SetCheck(FALSE);
		}

		if(pFidData->nFidType & FID_VERIFY)
		{
			m_chkUseVerify.SetCheck(TRUE);
//			m_chkUseDrill.EnableWindow(FALSE);
			m_chkUseDrill.SetCheck(FALSE);
		}
		else
		{
			m_chkUseVerify.SetCheck(FALSE);
//			if(nType == 1)
//				m_chkUseDrill.EnableWindow(TRUE);
		}
	}

  */
	str.Format(_T("%.2f"), pFidData->dOffsetZ);
	m_edtFidOffsetZ.SetWindowText(str);

	m_cmbCamera.SetCurSel(pFidData->nCam);

	m_cmbToolNo.SetCurSel(pFidData->nToolNo);

	m_edtPath.SetWindowText((CString)m_pProject->m_szVisionProjectName);
	
	m_nModelType = (int)pFidData->sVisInfo.nModelType;
	m_cmbType.SetCurSel(m_nModelType);
	SelectPic( m_nModelType );
	
	str.Format(_T("%.2f"), pFidData->sVisInfo.dSizeA);
	m_edtSizeA.SetWindowText(str);
	
	str.Format(_T("%.2f"), pFidData->sVisInfo.dSizeB);
	m_edtSizeB.SetWindowText(str);
	
	str.Format(_T("%.2f"), pFidData->sVisInfo.dSizeC);
	m_edtSizeC.SetWindowText(str);
	
	str.Format(_T("%.0f"), pFidData->sVisInfo.dScoreSize);
	m_edtSize.SetWindowText(str);
	
	str.Format(_T("%.0f"), pFidData->sVisInfo.dScoreAngle);
	m_edtAngle.SetWindowText(str);
	
	str.Format(_T("%.0f"), pFidData->sVisInfo.dAspectRatio);
	m_edtAspectRatio.SetWindowText(str);
	
	str.Format(_T("%d"), pFidData->sVisInfo.nThreshold);
	m_edtThreshold.SetWindowText(str);
	
	for(int i=0; i<4; i++)
	{
		m_nCoaxial[i] = pFidData->sVisInfo.nCoaxial[i];
		m_nRing[i] = pFidData->sVisInfo.nRing[i];
		m_dBrightness[i] = pFidData->sVisInfo.dBrightness[i];
		m_dContrast[i] = pFidData->sVisInfo.dContrast[i];
	}
	
	int nSel = m_cmbCamera.GetCurSel();
	if(nSel == 0) // High
	{
		m_cmbCameraNo.SetCurSel(0);
	}
	else if(nSel == 1) // Low
	{
		m_cmbCameraNo.SetCurSel(1);
	}
	else // Low To High
	{
		m_cmbCameraNo.SetCurSel(1);
	}
	int nCamNo = m_cmbCameraSelect.GetCurSel();
	this->SendMessage(UM_VISION_LAMP, nCamNo, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
	SetValue( nSel );

	m_nPolarity = (int)pFidData->sVisInfo.nPolarity;
	UpdateData(FALSE);
	m_chkFindFidOrder.SetCheck(!m_pProject->m_bMultiFidAscentOrder);
	m_chkUseScaleLimit.SetCheck( pFidData->bCheckScaleLimit);

	m_chkRoiSize2.SetCheck(m_pProject->m_bUseRoiSize2);
	m_chkRoiSize.SetCheck(m_pProject->m_bUseRoiSize);

	str.Format(_T("%d"), m_pProject->m_nRoiX2);
	m_edtRoiX2.SetWindowText(str);

	str.Format(_T("%d"), m_pProject->m_nRoiX);
	m_edtRoiX.SetWindowText(str);

	str.Format(_T("%d"), m_pProject->m_nRoiY);
	m_edtRoiY.SetWindowText(str);

	str.Format(_T("%d"), pFidData->nFidBlock);
	GetDlgItem(IDC_EDIT_CURRENT_FID_BLOCK)->SetWindowText(str);

	UpdateData(FALSE);

	if(m_bDrawMode)
		DrawData();
//	Invalidate();
}

void CPaneRecipeGenFiducialNew::InitialDrawRatio()
{
	if(m_pProject)
	{
		CRect cRect;
		GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
		m_pProject->InitialDrawRatio(cRect, TRUE);
	}
}

BOOL CPaneRecipeGenFiducialNew::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_pProject == NULL)
		return TRUE;
	
	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
	if(rect.PtInRect(pt))
	{
		tempP.x = pt.x - rect.left;
		tempP.y = pt.y - rect.top;
		if(zDelta >= WHEEL_DELTA)
			m_pProject->SetDrawRect(tempP, 1, TRUE);
		else
			m_pProject->SetDrawRect(tempP, -1, TRUE);
		
		DrawData();
//		Invalidate(FALSE);
	}
	
	return CFormView::OnMouseWheel(nFlags, zDelta, pt);
}

void CPaneRecipeGenFiducialNew::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
	ClientToScreen(&point);
	CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
	
	if(rect.PtInRect(point))
	{
		tempP.x = point.x - rect.left;
		tempP.y = point.y - rect.top;

		GetDlgItem(IDC_STATIC_VIEW)->SetFocus();
	}

	m_ptMoveStart = tempP;
	m_bDrawMoveStart = TRUE;

	CFormView::OnLButtonDown(nFlags, point);
}

void CPaneRecipeGenFiducialNew::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	m_bDrawMoveStart = FALSE;
	
	if(m_pProject == NULL)
		return;
	
	CRect rect;
	CPoint tempP;
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
	ClientToScreen(&point);
	
	CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
	
	if(rect.PtInRect(point))
	{
		tempP.x = point.x - rect.left;
		tempP.y = point.y - rect.top;
//		ChangePosInfo(tempP); // display current file position
		
		DrawData();
//		Invalidate(FALSE);
	}
	
	CFormView::OnLButtonUp(nFlags, point);
}

void CPaneRecipeGenFiducialNew::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	if(m_pProject == NULL)
		return;
	
	CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
	
	if(m_bDrawMoveStart)
	{
		CRect rect;
		CPoint tempP, endP;
		GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
		ClientToScreen(&point);
		if(rect.PtInRect(point))
		{
			endP.x = point.x - rect.left;
			endP.y = point.y - rect.top;
			tempP.x = endP.x - m_ptMoveStart.x;
			tempP.y = endP.y - m_ptMoveStart.y;
			
//			ChangePosInfo(endP); // display current file position
			
			if(m_ptMoveStart != tempP)
			{
				m_ptMoveStart = endP;
				m_pProject->SetDrawRect(tempP, 0, TRUE);
				DrawData();
//				Invalidate(FALSE);
			}
		}
	}

	CFormView::OnMouseMove(nFlags, point);
}

void CPaneRecipeGenFiducialNew::OnChangeEditSizeA() 
{
//	if(m_bNoUIAutoChange)
//		return;
	
	UpdateData(FALSE);
	double dSize;
	CString strVal;

	m_edtSizeA.GetWindowText(strVal);
	dSize = atof(strVal);

	if(m_pProject == NULL)
		return; 

	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);

	if(gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if(pFidData == NULL)
		{
			m_sHoleVisInfo.dSizeA = dSize;
			return;
		}
		
		pFidData->sVisInfo.dSizeA = dSize;
	}
	else
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		if(pFidData == NULL)
		{
			m_sHoleVisInfo.dSizeA = dSize;
			return;
		}

		for(int i =0; i<nCount; i++)
		{
			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);

			if(pFidData == NULL)
			{
//				ErrMessage(_T("There is no fiducial data"));
				return;
			}

			int nFidType = GetCurrentFidType();
			if(nFidType != pFidData->nFidType)
				continue;
			
			pFidData->sVisInfo.dSizeA = dSize;
		}
	}
}

void CPaneRecipeGenFiducialNew::OnChangeEditSizeB() 
{
	UpdateData(FALSE);
	double dSize;
	CString strVal;
	
	m_edtSizeB.GetWindowText(strVal);
	dSize = atof(strVal);

	if(m_pProject == NULL)
		return; 

	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	if(gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if(pFidData == NULL)
		{
			m_sHoleVisInfo.dSizeB = dSize;
			return;
		}
		
		pFidData->sVisInfo.dSizeB = dSize;
	}
	else
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if(pFidData == NULL)
		{
			m_sHoleVisInfo.dSizeB = dSize;
			return;
		}
		for(int i =0; i<nCount; i++)
		{
			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			
			if(pFidData == NULL)
			{
//				ErrMessage(_T("There is no fiducial data"));
				return;
			}

			int nFidType = GetCurrentFidType();
			if(nFidType != pFidData->nFidType)
				continue;
			
			pFidData->sVisInfo.dSizeB = dSize;
		}
	}
	
}

void CPaneRecipeGenFiducialNew::OnChangeEditSizeC() 
{
	UpdateData(FALSE);
	double dSize;
	CString strVal;
	
	m_edtSizeC.GetWindowText(strVal);
	dSize = atof(strVal);

	if(m_pProject == NULL)
		return; 

	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	if(gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if(pFidData == NULL)
		{
			m_sHoleVisInfo.dSizeC = dSize;
			return;
		}
		
		pFidData->sVisInfo.dSizeC = dSize;
	}
	else
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if(pFidData == NULL)
		{
			m_sHoleVisInfo.dSizeC = dSize;
			return;
		}
		for(int i =0; i<nCount; i++)
		{
			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			
			if(pFidData == NULL)
			{
//				ErrMessage(_T("There is no fiducial data"));
				return;
			}

			int nFidType = GetCurrentFidType();
			if(nFidType != pFidData->nFidType)
				continue;
			
			pFidData->sVisInfo.dSizeC = dSize;
		}
	}
}

void CPaneRecipeGenFiducialNew::OnRadioPolarity() 
{
	UpdateData(TRUE);
	CString strVal;
	
	if(m_pProject == NULL)
		return; 

	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	if(!gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		if(!pFidData)
		{
			m_sHoleVisInfo.nPolarity = (long)m_nPolarity;
			return;
		}
		for(int i =0; i<nCount; i++)
		{
			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			
			if(pFidData == NULL)
			{
//				ErrMessage(_T("There is no fiducial data"));
				return;
			}

			int nFidType = GetCurrentFidType();
			if(nFidType != pFidData->nFidType)
				continue;
			
			pFidData->sVisInfo.nPolarity = (long)m_nPolarity;
		}
//		m_sHoleVisInfo.nPolarity = (long)m_nPolarity;
	}
	else
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		if(!pFidData)
		{
			m_sHoleVisInfo.nPolarity = (long)m_nPolarity;
			return;
		}
		pFidData->sVisInfo.nPolarity = m_nPolarity;
	}
}

BOOL CPaneRecipeGenFiducialNew::CheckFidData()
{
	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	CString str;
	
	if(m_pProject == NULL)
		return FALSE; 

	for(int i =0; i<nCount; i++)
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);

		if(pFidData == NULL)
		{
			ErrMessage(_T("There is no fiducial data"));
			return FALSE;
		}

		if(pFidData->sVisInfo.dSizeA > MAX_FID_SIZE || (pFidData->sVisInfo.dSizeA <= 0 && m_edtSizeA.IsWindowEnabled()) ) 
		{
			m_edtSizeA.SetFocus();
			ErrMessage(_T("0 < SizeA <= 5(mm)"));
			return FALSE;
		}
		
		if(pFidData->sVisInfo.dSizeB > MAX_FID_SIZE || (pFidData->sVisInfo.dSizeB <= 0 && m_edtSizeB.IsWindowEnabled()) ) 
		{
			m_edtSizeB.SetFocus();
			ErrMessage(_T("0 < SizeB <= 5(mm)"));
			return FALSE;
		}
		
		if(pFidData->sVisInfo.dSizeC > MAX_FID_SIZE || (pFidData->sVisInfo.dSizeC <= 0 && m_edtSizeC.IsWindowEnabled()) ) 
		{
			m_edtSizeC.SetFocus();
			ErrMessage(_T("0 < SizeC <= 5(mm)"));
			return FALSE;
		}	
		if(pFidData->sVisInfo.dScoreSize > MAX_PERCENT || pFidData->sVisInfo.dScoreSize < 0) 
		{
			m_edtSize.SetFocus();
			ErrMessage(_T("0 <= Size <= 100(%)"));
			return FALSE;
		}
		if(pFidData->sVisInfo.dAspectRatio > MAX_PERCENT || pFidData->sVisInfo.dAspectRatio < 0) 
		{
			m_edtAspectRatio.SetFocus();
			ErrMessage(_T("0 <= Aspect Ratio <= 100(%)"));
			return FALSE;
		}
		if(pFidData->sVisInfo.nThreshold > 255 || pFidData->sVisInfo.nThreshold < 0) 
		{
			m_edtThreshold.SetFocus();
			ErrMessage(_T("0 <= Threshold <= 255"));
			return FALSE;
		}

		for(int e = 0; e < 4; e++)
		{
			if(pFidData->sVisInfo.dContrast[e] > 1.0 || pFidData->sVisInfo.dContrast[e] < 0.0)
			{
				ErrMessage(_T("0.0 <= Contrast <= 1.0"));
				return FALSE;
			}
			if(pFidData->sVisInfo.dBrightness[e] > 1.0 || pFidData->sVisInfo.dBrightness[e] < 0.0)
			{
				ErrMessage(_T("0.0 <= Contrast <= 1.0"));
				return FALSE;
			}
		}
	}

	return TRUE;
}

void CPaneRecipeGenFiducialNew::OnUpdateEditContrast() 
{
	UpdateData(TRUE);
	
	CString str;
	double dTempVal;
	int nCam = m_cmbCameraNo.GetCurSel();


	if(m_pProject == NULL)
		return; 

	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	
	m_edtContrast.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > 1.0 || dTempVal < 0.0)
	{
		ErrMessage(_T("0.0 < Contrast <1.0"));
		return;
	}
	else
		m_dContrast[nCam] = dTempVal;
	

	if(gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if(pFidData == NULL)
		{
			for(int i=0; i<4; i++)
			{
				if(i == nCam)
					m_sHoleVisInfo.dContrast[i] = m_dContrast[nCam];
			}
			return;
		}
		
		for(int i=0; i<4; i++)
		{
			if(i == nCam)
				pFidData->sVisInfo.dContrast[i] = m_dContrast[nCam];
		}
	}
	else
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if(pFidData == NULL)
		{
			for(int i=0; i<4; i++)
			{
				if(i == nCam)
					m_sHoleVisInfo.dContrast[i] = m_dContrast[nCam];
			}
			return;
		}

		for(int i=0;i<nCount; i++)
		{
			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			
			if(pFidData == NULL)
			{
//				ErrMessage(_T("There is no fiducial data"));
				return;
			}

			int nFidType = GetCurrentFidType();
			if(nFidType != pFidData->nFidType)
				continue;

			for(int j=0; j<4; j++)
			{
				pFidData->sVisInfo.dContrast[j] = m_dContrast[nCam];
			}	
		}

	}
	
}

void CPaneRecipeGenFiducialNew::OnUpdateEditBrightness() 
{
	UpdateData(TRUE);
	
	CString str;
	double dTempVal;
	int nCam = m_cmbCameraNo.GetCurSel();

	
	if(m_pProject == NULL)
		return; 

	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	
	m_edtBrightness.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > 1.0 || dTempVal < 0.0) 
	{
		ErrMessage(_T("0.0 < Brightness <1.0"));
		return;
	}
	else
		m_dBrightness[nCam] = dTempVal;
	
	if(gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if(pFidData == NULL)
		{
			for(int i=0; i<4; i++)
			{
				if(i == nCam)
					m_sHoleVisInfo.dBrightness[i] = m_dBrightness[nCam];
			}
			return;
		}
		
		for(int i=0; i<4; i++)
		{
			if(i == nCam)
				pFidData->sVisInfo.dBrightness[i] = m_dBrightness[nCam];
		}
	}
	else
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if(pFidData == NULL)
		{
			for(int i=0; i<4; i++)
			{
				if(i == nCam)
					m_sHoleVisInfo.dBrightness[i] = m_dBrightness[nCam];
			}
			return;
		}

		for(int i=0;i<nCount; i++)
		{
			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			
			if(pFidData == NULL)
			{
//				ErrMessage(_T("There is no fiducial data"));
				return;
			}

			int nFidType = GetCurrentFidType();
			if(nFidType != pFidData->nFidType)
				continue;
			
			for(int j=0; j<4; j++)
			{
				pFidData->sVisInfo.dBrightness[j] = m_dBrightness[nCam];
			}	
		}

	}
}

void CPaneRecipeGenFiducialNew::OnUpdateEditCoaxial() 
{
	UpdateData(TRUE);
	
	CString str;
	int nTempVal;
	int nCam = m_cmbCameraNo.GetCurSel();
	
	
	if(m_pProject == NULL)
		return; 
	
	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	
	m_edtCoaxial.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > 255 || nTempVal < 0) 
	{
		ErrMessage(_T("0 < Coaxial <255"));
		return;
	}
	else
		m_nCoaxial[nCam] = nTempVal;
	
	if(gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if(pFidData == NULL)
		{
			for(int i=0; i<4; i++)
			{
				if(i == nCam)
					m_sHoleVisInfo.nCoaxial[i] = m_nCoaxial[nCam];
			}
			return;
		}
		
		for(int i=0; i<4; i++)
		{
			if(i == nCam)
				pFidData->sVisInfo.nCoaxial[i] = m_nCoaxial[nCam];
		}
	}
	else
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if(pFidData == NULL)
		{
			for(int i=0; i<4; i++)
			{
				if(i == nCam)
					m_sHoleVisInfo.nCoaxial[i] = m_nCoaxial[nCam];
			}
			return;
		}
		
		for(int i=0;i<nCount; i++)
		{
			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			
			if(pFidData == NULL)
			{
				//				ErrMessage(_T("There is no fiducial data"));
				return;
			}

			int nFidType = GetCurrentFidType();
			if(nFidType != pFidData->nFidType)
				continue;
			
			for(int j=0; j<4; j++)
			{
				if(j == nCam)
					pFidData->sVisInfo.nCoaxial[j] = m_nCoaxial[nCam];
			}	
		}
	}
}

void CPaneRecipeGenFiducialNew::OnUpdateEditRing() 
{
	UpdateData(TRUE);
	
	CString str;
	int nTempVal;
	int nCam = m_cmbCameraNo.GetCurSel();
	
	
	if(m_pProject == NULL)
		return; 
	
	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	
	m_edtRing.GetWindowText(str);
	nTempVal = atoi(str);
	if(nTempVal > 255 || nTempVal < 0) 
	{
		ErrMessage(_T("0 < Ring <255"));
		return;
	}
	else
		m_nRing[nCam] = nTempVal;
	
	if(gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if(pFidData == NULL)
		{
			for(int i=0; i<4; i++)
			{
				if(i == nCam)
					m_sHoleVisInfo.nRing[i] = m_nRing[nCam];
			}
			return;
		}
		
		for(int i=0; i<4; i++)
		{
			if(i == nCam)
				pFidData->sVisInfo.nRing[i] = m_nRing[nCam];
		}
	}
	else
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		
		if(pFidData == NULL)
		{
			for(int i=0; i<4; i++)
			{
				if(i == nCam)
					m_sHoleVisInfo.nRing[i] = m_nRing[nCam];
			}
			return;
		}
		
		for(int i=0;i<nCount; i++)
		{
			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			
			if(pFidData == NULL)
			{
				return;
			}

			int nFidType = GetCurrentFidType();
			if(nFidType != pFidData->nFidType)
				continue;
			
			for(int j=0; j<4; j++)
			{
				if(j == nCam)	
					pFidData->sVisInfo.nRing[j] = m_nRing[nCam];
			}	
		}
	}
}

void CPaneRecipeGenFiducialNew::OnChangeEditZOffset() 
{
	UpdateData(TRUE);
	
	CString str;
	double dTempVal;
	int nCam = m_cmbCameraNo.GetCurSel();
	
	if(m_pProject == NULL)
		return; 
	
	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	
	m_edtFidOffsetZ.GetWindowText(str);
	dTempVal = atof(str);

	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
	if(pFidData == NULL)
	{
		return;
	}
	
	if(!gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		for(int i=0;i<nCount; i++)
		{
			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			
			if(pFidData == NULL)
			{
//				ErrMessage(_T("There is no fiducial data"));
				return;
			}

			int nFidType = GetCurrentFidType();
			if(nFidType != pFidData->nFidType)
				continue;
			
			pFidData->dOffsetZ = dTempVal;
		}
	}
	else
	{
		pFidData->dOffsetZ = dTempVal;
	}
	
}
void CPaneRecipeGenFiducialNew::OnChangeAcceptSize()
{
	UpdateData(TRUE);
	
	CString str;
	double dTempVal;
		
	if(m_pProject == NULL)
		return; 
	
	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	
	m_edtSize.GetWindowText(str);
	dTempVal = atof(str);
	
	if(!gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		if(pFidData == NULL)
		{
			m_sHoleVisInfo.dScoreSize = dTempVal;
			return;
		}
		
		for(int i=0;i<nCount; i++)
		{
			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			
			if(pFidData == NULL)
			{
//				ErrMessage(_T("There is no fiducial data"));
				return;
			}

			int nFidType = GetCurrentFidType();
			if(nFidType != pFidData->nFidType)
				continue;
			
			pFidData->sVisInfo.dScoreSize = dTempVal;
		}
	}
	else
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		if(pFidData == NULL)
		{
			m_sHoleVisInfo.dScoreSize = dTempVal;
			return;
		}
		
		pFidData->sVisInfo.dScoreSize = dTempVal;
	}
}

void CPaneRecipeGenFiducialNew::OnChangeEditAspectratio() 
{
	UpdateData(TRUE);
	
	CString str;
	double dTempVal;
	
	if(m_pProject == NULL)
		return; 
	
	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	
	m_edtAspectRatio.GetWindowText(str);
	dTempVal = atof(str);
	
	if(!gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		if(pFidData == NULL)
		{
			m_sHoleVisInfo.dAspectRatio = dTempVal;
			return;
		}

		for(int i=0;i<nCount; i++)
		{
			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			
			if(pFidData == NULL)
			{
//				ErrMessage(_T("There is no fiducial data"));
				return;
			}

			int nFidType = GetCurrentFidType();
			if(nFidType != pFidData->nFidType)
				continue;
			
			pFidData->sVisInfo.dAspectRatio = dTempVal;
		}
	}
	else
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		if(pFidData == NULL)
		{
			m_sHoleVisInfo.dAspectRatio = dTempVal;
			return;
		}
		
		pFidData->sVisInfo.dAspectRatio = dTempVal;
	}
	
}

void CPaneRecipeGenFiducialNew::OnChangeEditThreashold()
{
	UpdateData(TRUE);
	
	CString str;
	int nTempVal;
		
	if(m_pProject == NULL)
		return; 
	
	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	
	m_edtThreshold.GetWindowText(str);
	nTempVal = atoi(str);
	
	if(!gProcessINI.m_sProcessFidFind.bUseAllControl)
	{
		for(int i=0;i<nCount; i++)
		{
			LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			
			if(pFidData == NULL)
			{
//				ErrMessage(_T("There is no fiducial data"));
				return;
			}

			int nFidType = GetCurrentFidType();
			if(nFidType != pFidData->nFidType)
				continue;
			
			pFidData->sVisInfo.nThreshold = nTempVal;
		}
		m_sHoleVisInfo.nThreshold = nTempVal;
	}
	else
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
		if(pFidData == NULL)
		{
			m_sHoleVisInfo.nThreshold = nTempVal;
			return;
		}
		
		pFidData->sVisInfo.nThreshold = nTempVal;
	}
}

BOOL CPaneRecipeGenFiducialNew::SkivingCheck()
{
	BOOL bSkivingTool = FALSE;
	int nCount;
	if(m_pProject != NULL)
		nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	else
		nCount = 0;
	for(int i=0;i<nCount; i++)
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
		
		if(pFidData == NULL)
		{
			ErrMessage(_T("There is no fiducial data"));
			return FALSE;
		}
		
		if(pFidData->nFidType == FID_SECONDARY + FID_DRILL)
		{
			bSkivingTool = TRUE;
			break;
		}
	}
	
	if(m_pProject != NULL)
	{
		m_pProject->m_bSkivingMode = bSkivingTool;
		if(bSkivingTool)
			m_pProject->m_pToolCode[0]->m_bUseTool = TRUE;
		else
			m_pProject->m_pToolCode[0]->m_bUseTool = FALSE;
	}

	return bSkivingTool;

}

void CPaneRecipeGenFiducialNew::OnCheckFidFindOrder() 
{
	// TODO: Add your control notification handler code here
	if(m_pProject != NULL)
		m_pProject->m_bMultiFidAscentOrder = !m_chkFindFidOrder.GetCheck();
}

void CPaneRecipeGenFiducialNew::OnButtonMove() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(pMotor->GetCurrentMode() == MODE_MPG || pMotor->GetCurrentMode() == MODE_OFF ||pMotor->GetCurrentMode() == MODE_HOME)
	{
		// MPG Off
		ErrMsgDlg(STDGNALM209);
		return;
	}
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Error Reset")); // 110603
		return;
	}

	int nCamNo = m_cmbCameraSelect.GetCurSel();
	int nPattern = m_cmbType.GetCurSel();

	if(!m_pProject)
		return;
	BOOL b1stPanel = TRUE;
	if(m_pProject->m_nSeparation == USE_1ST)
	{
		if(nCamNo == LOW_2ND_CAM || nCamNo == HIGH_2ND_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	if(m_pProject->m_nSeparation == USE_2ND)
	{
		b1stPanel = FALSE;
		if(nCamNo == LOW_1ST_CAM || nCamNo == HIGH_1ST_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	// set train param
	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
	if(pFidData == NULL)
	{
		ErrMessage(_T("Please select fiducial data"));
		return;
	}
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnApplyVisionParameter(nPattern ,nCamNo, pFidData->sVisInfo );

	CString strResult;
	TCHAR myResultChar[512] = {0,};

	double dZ1 = 0, dZ2 = 0, dX, dY, dHeadOffsetX, dHeadOffsetY, dOldPosX, dOldPosY, dRefX, dRefY;
	m_pProject->m_Glyphs.GetRefPosition(dRefX, dRefY);
	if(nCamNo == LOW_1ST_CAM)
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - m_pProject->m_dPcbThick2;
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		dOldPosX = pFidData->dpTransPosition1.x/1000.;
		dOldPosY = pFidData->dpTransPosition1.y/1000.;
	}
	else if(nCamNo == HIGH_1ST_CAM)
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - m_pProject->m_dPcbThick2;
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		dOldPosX = pFidData->dpTransPosition1.x/1000.;
		dOldPosY = pFidData->dpTransPosition1.y/1000.;
	}
	else if(nCamNo == LOW_2ND_CAM)
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - m_pProject->m_dPcbThick2;
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
		dOldPosX = pFidData->dpTransPosition2.x/1000.;
		dOldPosY = pFidData->dpTransPosition2.y/1000.;
	}
	else
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - m_pProject->m_dPcbThick2;
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		dOldPosX = pFidData->dpTransPosition2.x/1000.;
		dOldPosY = pFidData->dpTransPosition2.y/1000.;
	}

	dX = m_pProject->m_dRefPosX					// ������ ���� ��ǥ (table motor ��ǥ : scanner center ����)
		- (pFidData->npPosition.x / 1000.0 - dRefX)	// ������������ ����� ���� ��ǥ ���� : table ��ǥ��� file ��ǥ�谡 �ݴ�� �����ӷ� - ��.
		- dOldPosX							// ���� ã�Ҵ� offset
		+ dHeadOffsetX;
	dY = m_pProject->m_dRefPosY 
		- (pFidData->npPosition.y / 1000.0 - dRefY) 	
		- dOldPosY 						
		+ dHeadOffsetY;

	if(!pMotor->MotorMoveXYZ(dX, dY, dZ1, dZ2, b1stPanel))
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_MOVE_MOTOR);
		strMsg.Format(strString, "X,Y,Z");
		ErrMessage(strMsg);
		return;
	}

	pVision->SetInspectionArea(-1, nCamNo);
	if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
	{
		ErrMessage(_T("Inposition Error"));
		return;
	}
	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nHighFidArea, HIGH_1ST_CAM);
	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nLowFidArea, LOW_1ST_CAM);
	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nHighFidArea, HIGH_2ND_CAM);
	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nLowFidArea, LOW_2ND_CAM);

	DPOINT visionResult;
	if(!pVision->GetRealPos(&visionResult, nCamNo, pFidData->sVisInfo.nModelType, TRUE, myResultChar))
	{
		visionResult.x = 0;
		visionResult.y = 0;
	}
	else
	{
		pFidData->bAcquire[!b1stPanel] = TRUE;
		if(b1stPanel)
		{
			pFidData->dpTransPosition1.x += (int)(visionResult.x * 1000); pFidData->dpTransPosition1.y += (int)(visionResult.y * 1000);
		}
		else
		{
			pFidData->dpTransPosition2.x += (int)(visionResult.x * 1000); pFidData->dpTransPosition2.y += (int)(visionResult.y * 1000);
		}
		SetRealPos(b1stPanel);
	}
	strResult.Format(_T("%s"), myResultChar);
	DPHoleInfo(strResult);

//	pVision->OnAcquire(m_nCameraNo);
}

void CPaneRecipeGenFiducialNew::OnButtonSetref() 
{
	// TODO: Add your control notification handler code here
	if(m_chkSetROI.GetCheck())
		OnCheckInspArea();

	int nCamNo = m_cmbCameraSelect.GetCurSel();
	int nPattern = m_cmbType.GetCurSel();
	CString strMsg;

	if(!m_pProject)
		return;

	if(!m_pProject->m_Glyphs.IsValidFiducial())
	{
		ErrMessage(IDS_DATA_UNIT_FID2);
		return;
	}
	
	// set train param
	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, 0);
	if(pFidData == NULL)
	{
		ErrMessage(_T("Please select fiducial data"));
		return;
	}
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnApplyVisionParameter(nPattern ,nCamNo, pFidData->sVisInfo );
	this->SendMessage(UM_VISION_LAMP, nCamNo, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Error Reset")); // 110603
		return;
	}

	BOOL b1stPanel = TRUE;
	if(m_pProject->m_nSeparation == USE_1ST)
	{
		if(nCamNo == LOW_2ND_CAM || nCamNo == HIGH_2ND_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	if(m_pProject->m_nSeparation == USE_2ND)
	{
		b1stPanel = FALSE;
		if(nCamNo == LOW_1ST_CAM || nCamNo == HIGH_1ST_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	
	double dX, dY;
	pMotor->GetPosition(AXIS_X, dX, b1stPanel);
	pMotor->GetPosition(AXIS_Y, dY, b1stPanel);
	
#ifdef __TEST__
	dX = gProcessINI.m_sProcessFidFind.dRefPosX;
	dY = gProcessINI.m_sProcessFidFind.dRefPosY;
#endif

	m_pProject->ResetFidOffset();
	m_pProject->m_Glyphs.ResetFidAcquireRet(DEFAULT_FID_INDEX, TRUE);

	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nHighFidArea, HIGH_1ST_CAM);
	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nLowFidArea, LOW_1ST_CAM);
	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nHighFidArea, HIGH_2ND_CAM);
	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nLowFidArea, LOW_2ND_CAM);

	DPOINT visionResult;
	TCHAR myResultChar[255] = {0,};
	if(!pVision->GetRealPos(&visionResult, nCamNo, pFidData->sVisInfo.nModelType, TRUE, myResultChar))
	{
		visionResult.x = 0;
		visionResult.y = 0;
	}
	else
	{
		pFidData->bAcquire[!b1stPanel] = TRUE;
//		if(b1stPanel)
		//		{
		//			pFidData->npTransPosition.x += (int)(visionResult.x * 1000); pFidData->npTransPosition.y += (int)(visionResult.y * 1000);
		//		}
		//		else
		//		{
		//			pFidData->npTransPosition2.x += (int)(visionResult.x * 1000); pFidData->npTransPosition2.y += (int)(visionResult.y * 1000);
		//		}
		
		SetRealPos(b1stPanel);
	}
	CString strResult;
	strResult.Format(_T("%s"), myResultChar);
	
	if(nCamNo == LOW_1ST_CAM)
	{
		m_pProject->m_dRefPosX = dX - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - visionResult.x;
		m_pProject->m_dRefPosY = dY - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y - visionResult.y;
	}
	else if(nCamNo == HIGH_1ST_CAM)
	{
		m_pProject->m_dRefPosX = dX - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - visionResult.x;
		m_pProject->m_dRefPosY = dY - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y - visionResult.y;
	}
	else if(nCamNo == LOW_2ND_CAM)
	{
		m_pProject->m_dRefPosX = dX - gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - visionResult.x;
		m_pProject->m_dRefPosY = dY - gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - visionResult.y;
	}
	else
	{
		m_pProject->m_dRefPosX = dX - gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - visionResult.x;
		m_pProject->m_dRefPosY = dY - gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y - visionResult.y;
	}
	int nDualMode = USE_1ST;
	if(nCamNo == LOW_2ND_CAM || nCamNo == HIGH_2ND_CAM)
		nDualMode = USE_2ND;

	ApplyFidDataToShot(DEFAULT_FID_INDEX, FIND_ALL_FID, FALSE, -1, nDualMode);
	if(!(m_pProject->m_nDataLoadStep & SET_FID_ORIGIN))
		m_pProject->m_nDataLoadStep += SET_FID_ORIGIN; // 091117
	m_pProject->m_Glyphs.ResetFidAcquireRet(DEFAULT_FID_INDEX, FALSE);
	CString strData;
	strData.Format("%.3f",m_pProject->m_dRefPosX);
	m_edtRefPosX.SetWindowText( strData );

	strData.Format("%.3f",m_pProject->m_dRefPosY);
	m_edtRefPosY.SetWindowText( strData );
	DPHoleInfo(strResult);
}

void CPaneRecipeGenFiducialNew::OnButtonFindFid() 
{
	// TODO: Add your control notification handler code here
	if(m_chkSetROI.GetCheck())
		OnCheckInspArea();


	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->SetPanelNo(TEACHING_VISION_VIEW);
	CRect rtPos;
	GetDlgItem(IDC_STATIC_TEACHING_VIEW)->GetWindowRect( rtPos );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_SHOW );

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(pMotor->GetCurrentMode() == MODE_MPG || pMotor->GetCurrentMode() == MODE_OFF ||pMotor->GetCurrentMode() == MODE_HOME)
	{
		// MPG Off
		ErrMsgDlg(STDGNALM209);
		return;
	}
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Error Reset")); // 110603
		return;
	}
	
	if(!m_pProject)
		return;

	if(!m_pProject->m_Glyphs.IsValidFiducial())
	{
		ErrMessage(IDS_DATA_UNIT_FID2);
		return;
	}
	
	// set train param
	int nCamNo = m_cmbCameraSelect.GetCurSel();
	BOOL b1stPanel = TRUE;
	if(m_pProject->m_nSeparation == USE_1ST)
	{
		if(nCamNo == LOW_2ND_CAM || nCamNo == HIGH_2ND_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	if(m_pProject->m_nSeparation == USE_2ND)
	{
		b1stPanel = FALSE;
		if(nCamNo == LOW_1ST_CAM || nCamNo == HIGH_1ST_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	
	if(!(m_pProject->m_nDataLoadStep & SET_FID_ORIGIN)) // 20091029
	{
		ErrMessage(IDS_SET_ORIGIN);
		return;
	}
	
	m_b1stPanel = TRUE;
	if(nCamNo == LOW_2ND_CAM || nCamNo == HIGH_2ND_CAM)
		m_b1stPanel = FALSE;
	
	m_nCameraNo = nCamNo;
	
	ButtonEnable(FALSE);
	m_bStop = FALSE;
	m_pFindFidThread = ::AfxBeginThread(FidFindThread, this, THREAD_PRIORITY_NORMAL);
}

void CPaneRecipeGenFiducialNew::OnButtonFindHole() 
{
	// TODO: Add your control notification handler code here


	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->SetPanelNo(TEACHING_VISION_VIEW);
	CRect rtPos;
	GetDlgItem(IDC_STATIC_TEACHING_VIEW)->GetWindowRect( rtPos );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_SHOW );



	if(m_chkSetROI.GetCheck())
		OnCheckInspArea();

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(pMotor->GetCurrentMode() == MODE_MPG || pMotor->GetCurrentMode() == MODE_OFF ||pMotor->GetCurrentMode() == MODE_HOME)
	{
		// MPG Off
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Error Reset")); // 110603
		return;
	}

	if(!m_pProject)
		return;
	
	// set train param
	int nCamNo = m_cmbCameraSelect.GetCurSel();
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnApplyVisionParameter(m_sHoleVisInfo.nModelType ,nCamNo, m_sHoleVisInfo );
	double dModelX, dModelY;
	double nROISize, nROIAllow = 200;
	this->SendMessage(UM_VISION_LAMP, nCamNo, reinterpret_cast<LPARAM>(&m_sHoleVisInfo));
	if(m_sHoleVisInfo.nModelType < 2) // annulus, circle
	{
		dModelX = dModelY = m_sHoleVisInfo.dSizeA;
		// ���� nROISize = (int)(dModelX * 1000 + nROIAllow);
		nROISize = (dModelX * 1000) * 1.2; //
	}
	else if(m_sHoleVisInfo.nModelType < MODEL_PATTERN) // other geometery
	{
		dModelX = m_sHoleVisInfo.dSizeA;
		dModelY = m_sHoleVisInfo.dSizeB;
		nROISize = (int)(max(dModelX, dModelY) * 1000 + nROIAllow);
	}
	else
	{
		nROISize = (int)(gSystemINI.m_sSystemDevice.dLowFOVX * 1000);
	}
	
	if(m_pProject->m_bUseRoiSize2)
	{
		CString str;//20170808
		m_edtRoiX2.GetWindowText(str);
		m_pProject->m_nRoiX2 = atoi(str);
		nROISize = m_pProject->m_nRoiX2;
	}




	if( nCamNo == LOW_1ST_CAM || nCamNo == LOW_2ND_CAM )
	{	// Low
		this->SendMessage(UM_VISION_ROI_SET_UM, nROISize, LOW_1ST_CAM);
	}
	else
	{	// High
		this->SendMessage(UM_VISION_ROI_SET_UM, nROISize, HIGH_1ST_CAM);
	}
	
	BOOL b1stPanel = TRUE;
	if(m_pProject->m_nSeparation == USE_1ST)
	{
		if(nCamNo == LOW_2ND_CAM || nCamNo == HIGH_2ND_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	if(m_pProject->m_nSeparation == USE_2ND)
	{
		b1stPanel = FALSE;
		if(nCamNo == LOW_1ST_CAM || nCamNo == HIGH_1ST_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}

	if(!(m_pProject->m_nDataLoadStep & SET_FID_ORIGIN)) // 20091029
	{
		ErrMessage(IDS_SET_ORIGIN);
		return;
	}
	if(!(m_pProject->m_nDataLoadStep & FIELD_DIVIED))
	{
		ErrMessage(_T("Please Divide Field First"));
		return;
	}
	

	double dZ;
	if(nCamNo == LOW_1ST_CAM)
		dZ = gSystemINI.m_sSystemDevice.d1stLowHeight - m_pProject->m_dPcbThick;
	else if(nCamNo == HIGH_1ST_CAM)
		dZ = gSystemINI.m_sSystemDevice.d1stHighHeight - m_pProject->m_dPcbThick;
	else if(nCamNo == LOW_2ND_CAM)
		dZ = gSystemINI.m_sSystemDevice.d2ndLowHeight - m_pProject->m_dPcbThick2;
	else
		dZ = gSystemINI.m_sSystemDevice.d2ndHighHeight - m_pProject->m_dPcbThick2;
	
	m_dZPos = dZ;
	m_nCameraNo = nCamNo;
	
	ButtonEnable(FALSE);
	
	m_pHoleFindThread = ::AfxBeginThread(HoleFindThread, this, THREAD_PRIORITY_NORMAL);
	m_bStop = FALSE;
}

void CPaneRecipeGenFiducialNew::OnEditchangeComboCamNo2() 
{
	// TODO: Add your control notification handler code here
	int nCamNo = m_cmbCameraSelect.GetCurSel();
	HVision* pVision = gDeviceFactory.GetVision();
	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
	if( pFidData != NULL)
		this->SendMessage(UM_VISION_LAMP, nCamNo, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
	m_cmbCameraNo.SetCurSel(nCamNo);
	OnSelchangeComboCameraNo(); 
	
	pVision->OnCamChange( nCamNo );
	
	SetValue( nCamNo );
}

void CPaneRecipeGenFiducialNew::OnCheckInspArea() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	
	BOOL bCheck = m_chkSetROI.GetCheck();
	int nPattern = m_cmbType.GetCurSel();
	int nCam = m_cmbCameraSelect.GetCurSel();
	
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		if(bCheck)
		{
			gDeviceFactory.GetVision()->ShowArea(2, nPattern, nCam);
			m_chkSetROI.SetWindowText(_T("Apply ROI"));
			m_btnTrainTest.EnableWindow(FALSE);
			m_btnMove.EnableWindow(FALSE);
			m_btnMoveNearPos1.EnableWindow(FALSE);
			m_btnMoveNearPos2.EnableWindow(FALSE);
			m_btnSetRef.EnableWindow(FALSE);
			m_btnFindFid.EnableWindow(FALSE);
			m_btnFindHole.EnableWindow(FALSE);
			m_btnStop.EnableWindow(FALSE);
			m_btnTrainTest.EnableWindow(FALSE);
			m_btnSetLive.EnableWindow(FALSE);
			m_btnSetPos.EnableWindow(FALSE);
			m_btnMoveLoadPos.EnableWindow(FALSE);
		}
		else
		{
			gDeviceFactory.GetVision()->ShowArea(0, nPattern, nCam);
			m_chkSetROI.SetWindowText(_T("Show ROI"));
			m_btnTrainTest.EnableWindow(TRUE);
			m_btnMove.EnableWindow(TRUE);
			m_btnMoveNearPos1.EnableWindow(TRUE);
			m_btnMoveNearPos2.EnableWindow(TRUE);
			m_btnSetRef.EnableWindow(TRUE);
			m_btnFindFid.EnableWindow(TRUE);
			m_btnFindHole.EnableWindow(TRUE);
			m_btnStop.EnableWindow(TRUE);
			m_btnTrainTest.EnableWindow(TRUE);
			m_btnSetLive.EnableWindow(TRUE);
			m_btnSetPos.EnableWindow(TRUE);
			m_btnMoveLoadPos.EnableWindow(TRUE);
		}
	}
}

void CPaneRecipeGenFiducialNew::OnButtonLive2() 
{
	// TODO: Add your control notification handler code here
	if(m_chkSetROI.GetCheck())
		OnCheckInspArea();

	m_bIsLive = !m_bIsLive;
	
	m_btnSetLive.SetClick( m_bIsLive );
	
	if( m_bIsLive )
	{
		m_btnSetLive.SetWindowText( _T("Stop\nLive") );
		m_btnMove.EnableWindow(FALSE);
		m_btnMoveNearPos1.EnableWindow(FALSE);
		m_btnMoveNearPos2.EnableWindow(FALSE);
		m_btnSetRef.EnableWindow(FALSE);
		m_btnFindFid.EnableWindow(FALSE);
		m_btnFindHole.EnableWindow(FALSE);
		m_chkSetROI.EnableWindow(FALSE);
		m_btnTrainTest.EnableWindow(FALSE);
		m_btnSetPos.EnableWindow(FALSE);
		m_cmbCameraSelect.EnableWindow(FALSE);
		m_btnMoveLoadPos.EnableWindow(FALSE);
	}
	else
	{
		m_btnSetLive.SetWindowText( _T("Start\nLive") );
		m_btnMove.EnableWindow(TRUE);
		m_btnMoveNearPos1.EnableWindow(TRUE);
		m_btnMoveNearPos2.EnableWindow(TRUE);
		m_btnSetRef.EnableWindow(TRUE);
		m_btnFindFid.EnableWindow(TRUE);
		m_btnFindHole.EnableWindow(TRUE);
		m_chkSetROI.EnableWindow(TRUE);
		m_btnTrainTest.EnableWindow(TRUE);
		m_cmbCameraSelect.EnableWindow(TRUE);
		m_btnSetPos.EnableWindow(TRUE);
		m_btnMoveLoadPos.EnableWindow(TRUE);
	}
	
	int nCamNo = m_cmbCameraSelect.GetCurSel();
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnLive(nCamNo, m_bIsLive);
}

void CPaneRecipeGenFiducialNew::OnButtonTest2() 
{
	// TODO: Add your control notification handler code here
	if(m_chkSetROI.GetCheck())
		OnCheckInspArea();

	int nCamNo = m_cmbCameraSelect.GetCurSel();
	int nPattern = m_cmbType.GetCurSel();
	CString strMsg;
	
	// set train param
	HVision* pVision = gDeviceFactory.GetVision();
	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
	if(pFidData == NULL)
	{
		pVision->OnApplyVisionParameter(nPattern ,nCamNo, m_sHoleVisInfo );
		this->SendMessage(UM_VISION_LAMP, nCamNo, reinterpret_cast<LPARAM>(&m_sHoleVisInfo));
	}
	else
	{
	//	pVision->OnApplyVisionParam(nPattern, nCamNo, pFidData->sVisInfo);
		pVision->OnApplyVisionParameter(nPattern ,nCamNo, pFidData->sVisInfo );
		this->SendMessage(UM_VISION_LAMP, nCamNo, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
	}
	
	if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
		pVision->OnFindFiducial( nCamNo, 4, strMsg );
	else
		pVision->OnFindFiducial( nCamNo, nPattern, strMsg );
	
	DPHoleInfo(strMsg);
}

void CPaneRecipeGenFiducialNew::ConnectView()
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
//		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->SetPanelNo(TEACHING_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_TEACHING_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_SHOW );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetPanelNo(TEACHING_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow( SW_SHOW );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		BOOL bSideVision = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetSideStatus();
		if(bSideVision == TRUE)
			return; 
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->SetPanelNo(TEACHING_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_TEACHING_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_SHOW );
	}
	
	int nCamNo = m_cmbCameraSelect.GetCurSel();
	OnEditchangeComboCamNo2();
	if(m_bIsLive)
		OnButtonLive2();
}

void CPaneRecipeGenFiducialNew::OnMoveVisionView()
{
	CRect rtPos;
	
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		GetDlgItem(IDC_STATIC_TEACHING_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		GetDlgItem(IDC_STATIC_TEACHING_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
	}
}

void CPaneRecipeGenFiducialNew::DPHoleInfo(CString strMsg)
{
	int nCamNo = m_cmbCameraSelect.GetCurSel();
	m_stcInspResult.SetWindowText( strMsg );
	
	CString strPos;
	double dPosX, dPosY;
	BOOL b1st = TRUE;
	
	CString strData;
	
	switch( nCamNo )
	{
	case HIGH_1ST_CAM :
	case LOW_1ST_CAM :
		b1st = TRUE;
		gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
		gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);
		strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
		strData.Format(_T("1st %s %s"), strPos, strMsg);
		break;
	case HIGH_2ND_CAM :
	case LOW_2ND_CAM :
		b1st = FALSE;
		gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, b1st);
		gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, b1st);
		strPos.Format(_T("[%.3f, %.3f]"), dPosX, dPosY);
		strData.Format(_T("2nd %s %s"), strPos, strMsg);
		break;
	}
	
	m_lboxResult.InsertString( 0, (LPCTSTR)strData );
	m_lboxResult.SetCurSel( 0 );
}

BOOL CPaneRecipeGenFiducialNew::ApplyFidDataToShot(int nFidKind, int nFindMethod, int nFindFiducialType, int nFidBlock, int nDualMode)
{
	if(!m_pProject)
		return FALSE;
	
	BOOL b1stOK, b2ndOK;
	TRACE("ApplyFidDataToShot Start....\r\n");
	int nError;
	if(nFindFiducialType || nFidKind == ADDED_FID_INDEX) // corse fid or skiving
		nError = m_pProject->ApplyFidDataToShot_Coarse(FID_SECONDARY, nFindMethod, nDualMode, b1stOK, b2ndOK);
	else
	{
		if(gSystemINI.m_sSystemDevice.nFiducialFindType == 0)
			nError = m_pProject->ApplyFidDataToShot(nFidKind, nFindMethod, nDualMode, b1stOK, b2ndOK);
		else
			nError = m_pProject->ApplyFidDataToShot_MultiFiducial(nFidKind, nFindMethod, FALSE, nFidBlock, nDualMode, b1stOK, b2ndOK);
	}
	
	TRACE("ApplyFidDataToShot End!!!!\r\n");

	if(nError == TABLE_MOVE_ERROR)
	{
		ErrMessage(IDS_ERR_APPLY_FID1);
	}
	else if(nError == MISSHOT_ERROR)
	{
		ErrMessage(IDS_ERR_APPLY_FID2);
	}
	else if(nError == FIDUCIAL_TRANS_ERROR)
	{
		ErrMessage(IDS_ERR_APPLY_FID3);	
	}
	else if(nError == OUT_TABLE_FIRE)
	{
		ErrMessage(IDS_ERR_APPLY_FID4);
	}
	else
		return TRUE;

	return FALSE;
}

void CPaneRecipeGenFiducialNew::SetRealPos(BOOL b1stPanel)
{
	if(!m_pProject)
		return;
	
	C2DTransform myTrans;
	myTrans.SetNumPoint(2);
	LPFIDDATA pFidData;
	int nFoundCount = 0;
	for(int i = 0; i < m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX); i++)
	{
		pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
		if(pFidData->bAcquire[!b1stPanel])
		{
			myTrans.SetReferencePoint(pFidData->npPosition.x, pFidData->npPosition.y, nFoundCount);
			if(nFoundCount < 2)
			{
				if(b1stPanel)
					myTrans.SetTransformedPoint(pFidData->npPosition.x + pFidData->dpTransPosition1.x, 
						pFidData->npPosition.y + pFidData->dpTransPosition1.y, nFoundCount++);
				else
					myTrans.SetTransformedPoint(pFidData->npPosition.x + pFidData->dpTransPosition2.x, 
						pFidData->npPosition.y + pFidData->dpTransPosition2.y, nFoundCount++);
			}
		}
	}
	if(nFoundCount != 2)
		return;

	double dx, dy;
	myTrans.Transform();
	for(int i = 0; i < m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX); i++)
	{
		pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
		if(!pFidData->bAcquire[!b1stPanel])
		{
			myTrans.TransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dx, dy);
			if(b1stPanel)
			{
				pFidData->dpTransPosition1.x = (int)(dx - pFidData->npPosition.x); 
				pFidData->dpTransPosition1.y = (int)(dy - pFidData->npPosition.y);

			}
			else
			{
				pFidData->dpTransPosition2.x = (int)(dx - pFidData->npPosition.x); 
				pFidData->dpTransPosition2.y = (int)(dy - pFidData->npPosition.y);

			}
		}
	}
	
}

void CPaneRecipeGenFiducialNew::OnButtonSetOffset() 
{
	// TODO: Add your control notification handler code here
	if(m_chkSetROI.GetCheck())
		OnCheckInspArea();
	
	int nCamNo = m_cmbCameraSelect.GetCurSel();
	int nPattern = m_cmbType.GetCurSel();
	CString strMsg;
	
	if(!m_pProject)
		return;
	
	// set train param
	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
	if(pFidData == NULL)
	{
		ErrMessage(_T("Please select fiducial data"));
		return;
	}
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnApplyVisionParameter(nPattern ,nCamNo, pFidData->sVisInfo );
	
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	BOOL b1stPanel = TRUE;
	if(m_pProject->m_nSeparation == USE_1ST)
	{
		if(nCamNo == LOW_2ND_CAM || nCamNo == HIGH_2ND_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	if(m_pProject->m_nSeparation == USE_2ND)
	{
		b1stPanel = FALSE;
		if(nCamNo == LOW_1ST_CAM || nCamNo == HIGH_1ST_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	
	double dRealX, dRealY;
	pMotor->GetPosition(AXIS_X, dRealX, b1stPanel);
	pMotor->GetPosition(AXIS_Y, dRealY, b1stPanel);

	double dHeadOffsetX, dHeadOffsetY;
	if(nCamNo == LOW_1ST_CAM)
	{
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
	}
	else if(nCamNo == HIGH_1ST_CAM)
	{
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
	}
	else if(nCamNo == LOW_2ND_CAM)
	{
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
	}
	else
	{
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
	}

	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nHighFidArea, HIGH_1ST_CAM);
	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nLowFidArea, LOW_1ST_CAM);
	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nHighFidArea, HIGH_2ND_CAM);
	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nLowFidArea, LOW_2ND_CAM);

	DPOINT visionResult;
	TCHAR myResultChar[255] = {0,};
	if(!pVision->GetRealPos(&visionResult, nCamNo, pFidData->sVisInfo.nModelType, TRUE, myResultChar))
	{
		visionResult.x = 0;
		visionResult.y = 0;
	}
	else
	{
		double dX, dY, dRefX, dRefY, dOffsetX, dOffsetY;
		m_pProject->m_Glyphs.GetRefPosition(dRefX, dRefY);
		dX = m_pProject->m_dRefPosX					// ������ ���� ��ǥ (table motor ��ǥ : scanner center ����)
			- (pFidData->npPosition.x / 1000.0 - dRefX)	// ������������ ����� ���� ��ǥ ���� : table ��ǥ��� file ��ǥ�谡 �ݴ�� �����ӷ� - ��.
			+ dHeadOffsetX;
		dY = m_pProject->m_dRefPosY 
			- (pFidData->npPosition.y / 1000.0 - dRefY)
			+ dHeadOffsetY;
		
		dOffsetX = ((dX - dRealX) + visionResult.x) * 1000;
		dOffsetY = ((dY - dRealY) + visionResult.y) * 1000;
		
		pFidData->bAcquire[!b1stPanel] = TRUE;
		if(b1stPanel)
		{
			pFidData->dpTransPosition1.x = (int)dOffsetX; pFidData->dpTransPosition1.y = (int)dOffsetY;

		}
		else
		{
			pFidData->dpTransPosition2.x = (int)dOffsetX; pFidData->dpTransPosition2.y = (int)dOffsetY;

		}
		SetRealPos(b1stPanel);
	}
	CString strResult;
	strResult.Format(_T("%s"), myResultChar);
	DPHoleInfo(strResult);
}

void CPaneRecipeGenFiducialNew::OnButtonStop() 
{
	// TODO: Add your control notification handler code here
	m_bStop = TRUE;
	if(m_pHoleFindThread)
	{
		WaitForSingleObject(m_pHoleFindThread, INFINITE);
		m_pHoleFindThread = NULL;
	}
	if(m_pFindFidThread)
	{
		WaitForSingleObject(m_pFindFidThread, INFINITE);
		m_pFindFidThread = NULL;
	}
	ButtonEnable(TRUE);
}

void CPaneRecipeGenFiducialNew::ButtonEnable(BOOL bEnable)
{
	GetDlgItem(IDC_TREE_TOOL)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_APPLY_TO_ALL)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_APPLY_TO_ALL_CAM)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_APPLY_TO_ALL_FID)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_APPLY_TO_SAMETYPE_FID)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_SHOW_TEST)->EnableWindow(bEnable);

	GetDlgItem(IDC_CHECK_FID_FIND_ORDER)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_MOVE)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_MOVE_NEAR_POS1)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_MOVE_NEAR_POS2)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_SET_OFFSET)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_SETREF)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_FIND_FID)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_FIND_HOLE)->EnableWindow(bEnable);
	GetDlgItem(IDC_CHECK_INSP_AREA)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_LIVE2)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_TEST2)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_MOVE_LOADING_POS)->EnableWindow(bEnable);
	GetDlgItem(IDC_CHECK_USE_SCALE_LIMIT)->EnableWindow(bEnable);
	GetDlgItem(IDC_CHECK_USE_ROI_SIZE)->EnableWindow(bEnable);
	GetDlgItem(IDC_CHECK_USE_ROI_SIZE2)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_SAVE)->EnableWindow(bEnable);

	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, bEnable);
		GetDlgItem(IDC_BUTTON_APPLY_REFPOS)->EnableWindow(bEnable);
	GetDlgItem(IDC_BUTTON_SHOW_MOTOR_MOVE)->EnableWindow(bEnable);

	m_btnMarkStart.EnableWindow(bEnable);

	::AfxGetMainWnd()->SendMessage(UM_ENABLE_EASY_TEST_WINDOW,bEnable);

}

LRESULT CPaneRecipeGenFiducialNew::GetVisionResult(WPARAM wParam, LPARAM lParam)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		memset(m_ResultChar, NULL, sizeof(m_ResultChar));
		HVision* pVision = gDeviceFactory.GetVision();
		return pVision->GetRealPos(&m_visionResult, wParam, lParam, TRUE, m_ResultChar);
	}
	return 1L;
}

LRESULT CPaneRecipeGenFiducialNew::GetVisionResultBarcode(WPARAM wParam, LPARAM lParam)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		memset(m_ResultChar, NULL, sizeof(m_ResultChar));
		HVision* pVision = gDeviceFactory.GetVision();

		return pVision->On2DRead(wParam,lParam,m_strMsg,m_strBarcode);
	}
	return 1L;
}

void CPaneRecipeGenFiducialNew::FindFiducial()
{
	m_bCalFidPosWithFirst2Point = TRUE;
	if(!FindFiducialInCenter(DEFAULT_FID_INDEX, FIND_ALL_FID, -1))
	{
		int nCamNo = m_cmbCameraSelect.GetCurSel();
		if(nCamNo == HIGH_1ST_CAM)
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL);
		if(nCamNo == LOW_1ST_CAM)
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
		if(nCamNo == HIGH_2ND_CAM)
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL);
		if(nCamNo == LOW_2ND_CAM)
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
		ErrMessage(_T("Fail to Find Fiducial"));
		return; // Message add
	}

	if(m_pProject->m_bSkivingMode)
	{
		if(!FindFiducialInCenter(ADDED_FID_INDEX, FIND_ALL_FID, -1))
		{
			int nCamNo = m_cmbCameraSelect.GetCurSel();
			if(nCamNo == HIGH_1ST_CAM)
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL);
			if(nCamNo == LOW_1ST_CAM)
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
			if(nCamNo == HIGH_2ND_CAM)
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL);
			if(nCamNo == LOW_2ND_CAM)
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
			ErrMessage(_T("Fail to Find Fiducial"));
			return; // Message add
		}
	}
	int nCamNo = m_cmbCameraSelect.GetCurSel();
	if(nCamNo == HIGH_1ST_CAM)
		::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL);
	if(nCamNo == LOW_1ST_CAM)
		::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
	if(nCamNo == HIGH_2ND_CAM)
		::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL);
	if(nCamNo == LOW_2ND_CAM)
		::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
}

BOOL CPaneRecipeGenFiducialNew::FindFiducialInCenter(int nFidKind, int nFindMethod, int nFidBlock)
{
	m_pProject->m_Glyphs.ResetFidAcquireRet(DEFAULT_FID_INDEX);

	HVision* pVision = gDeviceFactory.GetVision();
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	CPoint nFidFilePos;
	CDPoint dIndexP, dOffsetP, dOffsetP2;
	double  dZOffset = 0;
	BOOL	bCoaseFid = FALSE;
	int nFindCount = 0;
	BOOL bMasterOK = TRUE, bSlaveOK = TRUE;
	
	C2DTransform myTrans, myTrans2; //myTrans2 --> Coarse Fiducial ������ ����

	if( !m_pProject->m_bUseRoiSize )
	{
		this->SendMessage(UM_VISION_ROI_SET, 0, HIGH_1ST_CAM);
		this->SendMessage(UM_VISION_ROI_SET, 0, LOW_1ST_CAM);
		this->SendMessage(UM_VISION_ROI_SET, 0, HIGH_2ND_CAM);
		this->SendMessage(UM_VISION_ROI_SET, 0, LOW_2ND_CAM);
	}
	else
	{
		this->SendMessage(UM_VISION_ROI_SET, m_pProject->m_nRoiX, HIGH_1ST_CAM);
		this->SendMessage(UM_VISION_ROI_SET, m_pProject->m_nRoiX, LOW_1ST_CAM);
		this->SendMessage(UM_VISION_ROI_SET, m_pProject->m_nRoiX, HIGH_2ND_CAM);
		this->SendMessage(UM_VISION_ROI_SET, m_pProject->m_nRoiX, LOW_2ND_CAM);
	}
#ifdef __KUNSAN_LAVIA__
	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nHighFidArea, HIGH_1ST_CAM);
	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nLowFidArea, LOW_1ST_CAM);
	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nHighFidArea, HIGH_2ND_CAM);
	this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nLowFidArea, LOW_2ND_CAM);
#endif
	double dManualX = 0.0, dManualY = 0.0;
	LPFIDDATA pFidData, pFidFirstData;

	int nAddProperty = 0, nDelProperty = 0;
	if(nFidKind == DEFAULT_FID_INDEX)
	{
		nAddProperty = FID_FIND;
		nDelProperty = FID_VERIFY;
	}
	else
	{
		nAddProperty = FID_DRILL;
	}
	int nCnt = m_pProject->m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, nAddProperty, nDelProperty, nFidBlock);
	int nCntPrimary = m_pProject->m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, FID_PRIMARY, nDelProperty, nFidBlock);
	int nCntSecondary = m_pProject->m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, FID_SECONDARY, nDelProperty, nFidBlock);

	double dx, dy;
	CPoint tempOffset;
	myTrans.SetNumPoint(2);
	if(nCntPrimary <= 4)
		myTrans2.SetNumPoint(nCntPrimary);
	else
		myTrans2.SetNumPoint(4);

	for(int i = 0; i < nCnt; i++) // fid ������ŭ ã��
	{
		pFidData = m_pProject->m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, i, nAddProperty, nDelProperty, nFidBlock);
		if(nFindCount == 0)
			pFidFirstData = pFidData; // 3 ��° �̻� ������ ��ȯ�� ���Ͽ�
		if(nFindCount == 1 && pFidData->dpTransPosition1.x == 0 && pFidData->dpTransPosition1.y == 0 &&
					 pFidData->dpTransPosition2.x == 0 && pFidData->dpTransPosition2.y == 0 ) // ù���� 2��° �ǵ���� ���ǹ��� ȸ���� �����Ϸ���
		{
			pFidData->dpTransPosition1 = pFidFirstData->dpTransPosition1;
			pFidData->dpTransPosition2 = pFidFirstData->dpTransPosition2;
		}
		if(nFindCount > 1 && pFidData->nFidType & FID_PRIMARY)
		{
			if(m_b1stPanel)
			{
				myTrans.TransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dx, dy);
				pFidData->dpTransPosition1.x = (int)(dx - pFidData->npPosition.x); pFidData->dpTransPosition1.y = (int)(dy - pFidData->npPosition.y);
			}
			else
			{
				myTrans.TransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dx, dy);
				pFidData->dpTransPosition2.x = (int)(dx - pFidData->npPosition.x); pFidData->dpTransPosition2.y = (int)(dy - pFidData->npPosition.y);
			}
		}
		else if((pFidData->nFidType & FID_SECONDARY)  && !(pFidData->nFidType & FID_DRILL))
		{
			if(m_b1stPanel)
			{
				myTrans2.TransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dx, dy);
				pFidData->dpTransPosition1.x = (int)(dx - pFidData->npPosition.x); pFidData->dpTransPosition1.y = (int)(dy - pFidData->npPosition.y);
			}
			else
			{
				myTrans2.TransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dx, dy);
				pFidData->dpTransPosition2.x = (int)(dx - pFidData->npPosition.x); pFidData->dpTransPosition2.y = (int)(dy - pFidData->npPosition.y);
			}
		}

		if((pFidData->nFidType & FID_SECONDARY) && !(pFidData->nFidType & FID_DRILL)) // coase fid
			bCoaseFid = TRUE;

		BOOL bFoundOK;
		if((pFidData->nFidType & FID_SECONDARY) && !(pFidData->nFidType & FID_DRILL))
			bFoundOK = FindOneVerifyFiducial(pFidData, FALSE, i);
		else
			bFoundOK = FindOneFiducial(pFidData, i);

		if(!bFoundOK)
			return FALSE;

		if(nFindCount < 2)
		{
			if(m_b1stPanel)
			{
				myTrans.SetReferencePoint(pFidData->npPosition.x, pFidData->npPosition.y, i);
				myTrans.SetTransformedPoint(pFidData->npPosition.x + pFidData->dpTransPosition1.x, 
											pFidData->npPosition.y + pFidData->dpTransPosition1.y, i);
			}
			else
			{
				myTrans.SetReferencePoint(pFidData->npPosition.x, pFidData->npPosition.y, i);
				myTrans.SetTransformedPoint(pFidData->npPosition.x + pFidData->dpTransPosition2.x, 
											 pFidData->npPosition.y + pFidData->dpTransPosition2.y, i);
			}
		}
		if(nFindCount == 1)
		{
			myTrans.Transform();
			CalFidPosWithFirst2Point(&myTrans);
		}

		if(nFindCount < nCntPrimary && nCntSecondary > 0)
		{
			if(m_b1stPanel)
			{
				myTrans2.SetReferencePoint(pFidData->npPosition.x, pFidData->npPosition.y, i);
				myTrans2.SetTransformedPoint(pFidData->npPosition.x + pFidData->dpTransPosition1.x, 
											pFidData->npPosition.y + pFidData->dpTransPosition1.y, i);
			}
			else
			{
				myTrans2.SetReferencePoint(pFidData->npPosition.x, pFidData->npPosition.y, i);
				myTrans2.SetTransformedPoint(pFidData->npPosition.x + pFidData->dpTransPosition2.x, 
											pFidData->npPosition.y + pFidData->dpTransPosition2.y, i);
			}
		}
		if( nFindCount == nCntPrimary - 1 && nCntSecondary > 0)
			myTrans2.Transform();

		nFindCount++;
	}
	
	int nDualMode = USE_1ST;
	if(m_nCameraNo == LOW_2ND_CAM || m_nCameraNo == HIGH_2ND_CAM)
		nDualMode = USE_2ND;

	if(nFindCount) // ���ǿ� �¾� ���� ���� �ִٸ� 
	{
		if(!ApplyFidDataToShot(nFidKind, nFindMethod, bCoaseFid, nFidBlock, nDualMode)) // gSystemINI.m_sSystemDevice.nFiducialFindType))
			return FALSE;
	}
	
	if(!(m_pProject->m_nDataLoadStep & APPLY_FID))
		m_pProject->m_nDataLoadStep += APPLY_FID;
	return TRUE;
}

LRESULT CPaneRecipeGenFiducialNew::SetROI(WPARAM wParam, LPARAM lParam)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->SetInspectionArea((int)wParam, (int)lParam);
	return 1L;
}

LRESULT CPaneRecipeGenFiducialNew::SetROIUM(WPARAM wParam, LPARAM lParam)
{
	HVision* pVision = gDeviceFactory.GetVision();
	int nCam = lParam;
	double nPercent;
	double nLowFOVX = (gSystemINI.m_sSystemDevice.dLowFOVX * 1000), nHighFOVX = (gSystemINI.m_sSystemDevice.dHighFOVX * 1000); // um
	if(nCam == HIGH_1ST_CAM || nCam == HIGH_2ND_CAM)
		nPercent = wParam * 100 / nHighFOVX;
	else
		nPercent = wParam * 100 / nLowFOVX;
	pVision->SetInspectionAreaPercent(nPercent, (int)lParam);
	return 1L;
}

LRESULT CPaneRecipeGenFiducialNew::ChangeVisionParameter(WPARAM wParam, LPARAM lParam)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		HVision* pVision = gDeviceFactory.GetVision();
		VISION_INFO* pVisInfo = reinterpret_cast<VISION_INFO*>(lParam);
		pVision->OnApplyVisionParameter(pVisInfo->nModelType, wParam, *pVisInfo );
	}
	return 1L;
}

LRESULT CPaneRecipeGenFiducialNew::GetVisionResultNoGrab(WPARAM wParam, LPARAM lParam)
{
	HVision* pVision = gDeviceFactory.GetVision();
	double dTemp;
	BOOL bResult = pVision->GetNoGrabRealPos(&m_visionResult, wParam, lParam, TRUE, m_ResultChar, dTemp );
	
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		m_visionResult.x = gProcess.m_ResultData[wParam].dx;
		m_visionResult.y = gProcess.m_ResultData[wParam].dy;
#endif
	}

	return bResult;
}

BOOL CPaneRecipeGenFiducialNew::FindOneVerifyFiducial(LPFIDDATA pFidData, BOOL bAfterFire, int nFidNo)
{
	double dZ1, dZ2, dHeadOffsetX1, dHeadOffsetY1, dHeadOffsetX2, dHeadOffsetY2;
	double dModelX = 0, dModelY = 0;
	double dLowFOVX = gSystemINI.m_sSystemDevice.dLowFOVX, dLowFOVY = gSystemINI.m_sSystemDevice.dLowFOVY, 
			dHighFOVX = gSystemINI.m_sSystemDevice.dHighFOVX, dHighFOVY = gSystemINI.m_sSystemDevice.dHighFOVY;
	BOOL bHighCam;
	double dFinalMoveX, dFinalMoveY;
	double dRefX, dRefY;
	int nROISize, nROIAllow = 100; // um

	m_pProject->m_Glyphs.GetRefPosition(dRefX, dRefY);

	if(pFidData->sVisInfo.nModelType < 2) // annulus, circle
	{
		dModelX = dModelY = pFidData->sVisInfo.dSizeA;
		nROISize = (int)(dModelX * 1000 + nROIAllow);
	}
	else if(pFidData->sVisInfo.nModelType < MODEL_PATTERN) // other geometery
	{
		dModelX = pFidData->sVisInfo.dSizeA;
		dModelY = pFidData->sVisInfo.dSizeB;
		nROISize = (int)(max(dModelX, dModelY) * 1000 + nROIAllow);
	}
	else
	{
		nROISize = (int)(dLowFOVX * 1000);
	}

	if( (pFidData->nCam == LOW_CAM) || (pFidData->nCam == LOW_TO_HIGH_CAM) )
	{	// Low
		this->SendMessage(UM_VISION_ROI_SET_UM, nROISize, LOW_1ST_CAM);
		this->SendMessage(UM_CHANGE_VISION_PARAM, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));

		dHeadOffsetX1 = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dHeadOffsetY1 = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		dHeadOffsetX2 = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		dHeadOffsetY2 = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;

		bHighCam = FALSE;
		dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - m_pProject->m_dPcbThick + pFidData->dOffsetZ;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - m_pProject->m_dPcbThick2 + pFidData->dOffsetZ;
	}
	else
	{	// High
		this->SendMessage(UM_VISION_ROI_SET_UM, nROISize, HIGH_1ST_CAM);
		this->SendMessage(UM_CHANGE_VISION_PARAM, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));


		dHeadOffsetX1 = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
		dHeadOffsetY1 = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		dHeadOffsetX2 = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
		dHeadOffsetY2 = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		
		bHighCam = TRUE;
		dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - m_pProject->m_dPcbThick + pFidData->dOffsetZ;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - m_pProject->m_dPcbThick2 + pFidData->dOffsetZ;
	}

	if(m_b1stPanel)
	{									// 1st �������� ���̺� �̵�
		dFinalMoveX = m_pProject->m_dRefPosX					// ������ ���� ��ǥ (table motor ��ǥ : scanner center ����)
			- (pFidData->npPosition.x / 1000.0 - dRefX)	// ������������ ����� ���� ��ǥ ���� : table ��ǥ��� file ��ǥ�谡 �ݴ�� �����ӷ� - ��.
			- pFidData->dpTransPosition1.x/1000. 							// ���� ã�Ҵ� offset
			+ dHeadOffsetX1;
		dFinalMoveY = m_pProject->m_dRefPosY 
			- (pFidData->npPosition.y / 1000.0 - dRefY) 	
			- pFidData->dpTransPosition1.y/1000. 						
			+ dHeadOffsetY1;
		
		if(!gDeviceFactory.GetMotor()->MotorMoveXYZ(dFinalMoveX, dFinalMoveY, dZ1, dZ2, TRUE, AUTORUN_MOVE))
		{
//			m_nErrMsgID = STDGNALM438;
			return FALSE;
		}
		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
		{
//			m_nErrMsgID = STDGNALM441;
			return FALSE;
		}

		if(!bHighCam)
		{
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL); //ChangeVisionAllParam(LOW_1ST_CAM, pFidData);
			if(!this->SendMessage(UM_VISION_FIND_NOGRAP, LOW_1ST_CAM, pFidData->sVisInfo.nModelType))
				return FALSE;
		}
		else
		{
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL); //ChangeVisionAllParam(HIGH_1ST_CAM, pFidData);
			if(!this->SendMessage(UM_VISION_FIND_NOGRAP, HIGH_1ST_CAM, pFidData->sVisInfo.nModelType))
				return FALSE;
		}
		if(!bAfterFire) // ��ġ�� ��ȭ�� ����� �Ѵ�. //10um
		{
			pFidData->dpTransPosition1.x += (int)(m_visionResult.x * 1000);
			pFidData->dpTransPosition1.y += (int)(m_visionResult.y * 1000);
			pFidData->bAcquire[0] = TRUE;
		}

	}
	else
	{
		dFinalMoveX = m_pProject->m_dRefPosX					// ������ ���� ��ǥ (table motor ��ǥ : scanner center ����)
			- (pFidData->npPosition.x / 1000.0 - dRefX)	// ������������ ����� ���� ��ǥ ���� : table ��ǥ��� file ��ǥ�谡 �ݴ�� �����ӷ� - ��.
			- pFidData->dpTransPosition2.x/1000. 							// ���� ã�Ҵ� offset
			+ dHeadOffsetX2;
		dFinalMoveY = m_pProject->m_dRefPosY 
			- (pFidData->npPosition.y / 1000.0 - dRefY) 	
			- pFidData->dpTransPosition2.y/1000. 						
			+ dHeadOffsetY2;
		
		if(!gDeviceFactory.GetMotor()->MotorMoveXYZ(dFinalMoveX, dFinalMoveY, dZ1, dZ2, FALSE, AUTORUN_MOVE))
		{
			return FALSE;
		}
		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
		{
			return FALSE;
		}
		if(!bHighCam)
		{
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL); //ChangeVisionAllParam(LOW_2ND_CAM, pFidData);
			if(!this->SendMessage(UM_VISION_FIND_NOGRAP, LOW_2ND_CAM, pFidData->sVisInfo.nModelType))
				return FALSE;
		}
		else
		{
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL); //ChangeVisionAllParam(HIGH_2ND_CAM, pFidData);
			if(!this->SendMessage(UM_VISION_FIND_NOGRAP, HIGH_2ND_CAM, pFidData->sVisInfo.nModelType))
				return FALSE;
		}
		if(!bAfterFire) // ��ġ�� ��ȭ�� ����� �Ѵ�. //10um
		{
			pFidData->dpTransPosition2.x += (int)(m_visionResult.x * 1000);
			pFidData->dpTransPosition2.y += (int)(m_visionResult.y * 1000);
			pFidData->bAcquire[1] = TRUE;
		}
	}
	return TRUE;
}

BOOL CPaneRecipeGenFiducialNew::FindOneFiducial(LPFIDDATA pFidData, int nFidNo)
{
	double dZ1 = 0.0, dZ2 = 0.0, dHeadOffsetX = 0.0, dHeadOffsetY = 0.0, dHeadOffsetX1 = 0.0, dHeadOffsetY1 = 0.0, dHeadOffsetX2 = 0.0, dHeadOffsetY2 = 0.0;
	double dStepX = 0.0, dStepY = 0.0, dReTryOffX = 0.0, dReTryOffY = 0.0, dModelX = 0, dModelY = 0;
	double dLowFOVX = gSystemINI.m_sSystemDevice.dLowFOVX, dLowFOVY = gSystemINI.m_sSystemDevice.dLowFOVY, 
			dHighFOVX = gSystemINI.m_sSystemDevice.dHighFOVX, dHighFOVY = gSystemINI.m_sSystemDevice.dHighFOVY;
	BOOL bHighCam, bFidUserImage = TRUE;
	CPoint nIndexP;
	double dFinalMoveX = 0.0, dFinalMoveY = 0.0;
	double dCurrentMove1stPX = 0.0, dCurrentMove1stPY = 0.0, dCurrentMove2ndPX = 0.0, dCurrentMove2ndPY = 0.0, dOffsetZero1stPX = 0.0, dOffsetZero1stPY = 0.0, dOffsetZero2ndPX = 0.0, dOffsetZero2ndPY = 0.0; // 
	double dRefX = 0.0, dRefY = 0.0;
	CDPoint dptResult1st, dptResult2nd, dptTemp;
	CDPoint dOffsetP;
	CDPoint dCoarseOffset;
	BOOL	b1stFound, b2ndFound, bFoundTemp;
	BOOL	b1stSkip, b2ndSkip;

	pFidData->bAcquire[!m_b1stPanel] = FALSE; // default : not found

	m_pProject->m_Glyphs.GetRefPosition(dRefX, dRefY);
	if(pFidData->sVisInfo.nModelType < 2) // annulus, circle
	{
		dModelX = dModelY = pFidData->sVisInfo.dSizeA;
		bFidUserImage = FALSE;
	}
	else if(pFidData->sVisInfo.nModelType < MODEL_PATTERN) // other geometery
	{
		dModelX = pFidData->sVisInfo.dSizeA;
		dModelY = pFidData->sVisInfo.dSizeB;
		bFidUserImage = FALSE;
	}

	if( (pFidData->nCam == LOW_CAM) || (pFidData->nCam == LOW_TO_HIGH_CAM) )
	{	// Low
		this->SendMessage(UM_CHANGE_VISION_PARAM, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));

		dHeadOffsetX1 = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dHeadOffsetY1 = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		dHeadOffsetX2 = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		dHeadOffsetY2 = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;

		if(!bFidUserImage)
		{
			dReTryOffX = max((dLowFOVX - dModelX)/2 - 0.1, 0.1); // 0.1 ����
			dReTryOffY = max((dLowFOVY - dModelY)/2 - 0.1, 0.1); // 0.1 ����
			dStepX = dLowFOVX - dModelX;
			dStepY = dLowFOVY - dModelY;
		}
		else
		{
			dReTryOffX = dLowFOVX; // retry ����
			dReTryOffY = dLowFOVY; // retry ����
			dStepX = gProcessINI.m_sProcessFidFind.dMoveLowVision.x;
			dStepY = gProcessINI.m_sProcessFidFind.dMoveLowVision.y;
		}
		bHighCam = FALSE;
		dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - m_pProject->m_dPcbThick + pFidData->dOffsetZ;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - m_pProject->m_dPcbThick2 + pFidData->dOffsetZ;
	}
	else
	{	// High
		this->SendMessage(UM_CHANGE_VISION_PARAM, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));


		dHeadOffsetX1 = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
		dHeadOffsetY1 = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		dHeadOffsetX2 = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
		dHeadOffsetY2 = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		
		if(!bFidUserImage)
		{
			dReTryOffX = max((dHighFOVX - dModelX)/2 - 0.01, 0.01); // 0.01 ����
			dReTryOffY = max((dHighFOVY - dModelY)/2 - 0.01, 0.01); // 0.01 ����
			dStepX = dHighFOVX - dModelX;
			dStepY = dHighFOVY - dModelY;
		}
		else
		{
			dReTryOffX = dHighFOVX; // retry ����
			dReTryOffY = dHighFOVY; // retry ����
			dStepX = gProcessINI.m_sProcessFidFind.dMoveHighVision.x;
			dStepY = gProcessINI.m_sProcessFidFind.dMoveHighVision.y;
		}
		bHighCam = TRUE;
		dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - m_pProject->m_dPcbThick + pFidData->dOffsetZ;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - m_pProject->m_dPcbThick2 + pFidData->dOffsetZ;
	}

	dCurrentMove1stPX = dOffsetZero1stPX = m_pProject->m_dRefPosX	- (pFidData->npPosition.x / 1000.0 - dRefX) + dHeadOffsetX1;
	dCurrentMove1stPY = dOffsetZero1stPY = m_pProject->m_dRefPosY	- (pFidData->npPosition.y / 1000.0 - dRefY) + dHeadOffsetY1;
	dCurrentMove2ndPX = dOffsetZero2ndPX = m_pProject->m_dRefPosX	- (pFidData->npPosition.x / 1000.0 - dRefX) + dHeadOffsetX2;
	dCurrentMove2ndPY = dOffsetZero2ndPY = m_pProject->m_dRefPosY	- (pFidData->npPosition.y / 1000.0 - dRefY) + dHeadOffsetY2;

	if(!m_b1stPanel)
	{
		dHeadOffsetX = dHeadOffsetX2;
		dHeadOffsetY = dHeadOffsetY2;
		dOffsetP.x = pFidData->dpTransPosition2.x/1000.; dOffsetP.y = pFidData->dpTransPosition2.y/1000.;
	}
	else
	{									// 1st �������� ���̺� �̵�
		dHeadOffsetX = dHeadOffsetX1;
		dHeadOffsetY = dHeadOffsetY1;
		dOffsetP.x = pFidData->dpTransPosition1.x/1000.; dOffsetP.y = pFidData->dpTransPosition1.y/1000.;
	}

	b1stFound = b2ndFound = FALSE;					// ���� fiducial�� ã�Ҵ��� �Ǵ� --> false : return false.
	b1stSkip = !m_b1stPanel;
	b2ndSkip = m_b1stPanel;					// �Ʒ� retry���� ã�� ���� skip�Ϸ���
	dptResult1st.x = dptResult1st.y = dptResult2nd.x = dptResult2nd.y = 0; // 
	for(int k = 0; k < gProcessINI.m_sProcessFidFind.nFidTotalRetrial; k++)
	{
		if(m_bStop)
			return FALSE;

		nIndexP = GetNextStepIndex(k);

		// Table move

		dFinalMoveX = m_pProject->m_dRefPosX					// ������ ���� ��ǥ (table motor ��ǥ : scanner center ����)
			- (pFidData->npPosition.x / 1000.0 - dRefX)	// ������������ ����� ���� ��ǥ ���� : table ��ǥ��� file ��ǥ�谡 �ݴ�� �����ӷ� - ��.
			- nIndexP.x * dStepX 					// retry fid x step
			- dOffsetP.x 							// ���� ã�Ҵ� offset
			+ dHeadOffsetX;
		dFinalMoveY = m_pProject->m_dRefPosY 
			- (pFidData->npPosition.y / 1000.0 - dRefY) 	
			- nIndexP.y * dStepY 					
			- dOffsetP.y 						
			+ dHeadOffsetY;
		
		if(!gDeviceFactory.GetMotor()->MotorMoveXYZ(dFinalMoveX, dFinalMoveY, dZ1, dZ2, TRUE))
			return FALSE;
		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
			return FALSE;
		
		SendFindTrigger(b1stFound, b2ndFound, bHighCam, b1stSkip, b2ndSkip, pFidData, dFinalMoveX, dFinalMoveY, dptResult1st, dptResult2nd, TRUE);

		if(b1stFound) // found 1st
		{
			gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptScore);
			if(pFidData->nCam == LOW_TO_HIGH_CAM)
			{
				pFidData->dpTransPosition1.x = (int)((dOffsetZero1stPX - dFinalMoveX + dptResult1st.x) * 1000); //dIndexP.x * dStepX + dOffsetP.x + visionResult.x
				pFidData->dpTransPosition1.y = (int)((dOffsetZero1stPY - dFinalMoveY + dptResult1st.y) * 1000); //dIndexP.y * dStepY + dOffsetP.y + visionResult.y

				if(GetFidPosHighCamInCenter(TRUE, pFidData))
				{
					b1stSkip = TRUE; b1stFound = FALSE;
				}
			}
			else
			{
				gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptScore);
				SendFindTrigger(b1stFound, bFoundTemp, bHighCam, b1stSkip, TRUE, pFidData, dFinalMoveX, dFinalMoveY, dptResult1st, dptTemp);
				gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				if(b1stFound)
				{
					dCurrentMove1stPX = dFinalMoveX; dCurrentMove1stPY = dFinalMoveY;
					b1stSkip = TRUE; b1stFound = FALSE;
				}
			}
			gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
		}
		if(b2ndFound) // found 2nd
		{
			gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptScore);
			if(pFidData->nCam == LOW_TO_HIGH_CAM)
			{
				gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dCurrentMove2ndPX, FALSE);
				gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dCurrentMove2ndPY, FALSE);
				pFidData->dpTransPosition2.x = (int)((dOffsetZero2ndPX - dCurrentMove2ndPX + dptResult2nd.x) * 1000); //dIndexP.x * dStepX + dOffsetP.x + visionResult.x
				pFidData->dpTransPosition2.y = (int)((dOffsetZero2ndPY - dCurrentMove2ndPY + dptResult2nd.y) * 1000); //dIndexP.y * dStepY + dOffsetP.y + visionResult.y

				if(GetFidPosHighCamInCenter(FALSE, pFidData))
				{
					b1stSkip = TRUE; b1stFound = FALSE;
				}
			}
			else
			{
				gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptScore);
				SendFindTrigger(bFoundTemp, b2ndFound, bHighCam, TRUE, b2ndSkip, pFidData, dFinalMoveX, dFinalMoveY, dptTemp, dptResult2nd);
				gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);

				if(b2ndFound)
				{
					gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dCurrentMove2ndPX, FALSE);
					gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dCurrentMove2ndPY, FALSE);
#ifdef __TEST__
					dCurrentMove2ndPX = dOffsetZero2ndPX; dCurrentMove2ndPY = dOffsetZero2ndPY;
#endif
					b2ndSkip = TRUE; b2ndFound = FALSE;
				}
			}
			gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
		}
		if(!( (m_b1stPanel && !b1stSkip) ||
			  (!m_b1stPanel && !b2ndSkip)  ) )// all found, so no more find
		{
			if(b1stSkip && pFidData->nCam != LOW_TO_HIGH_CAM)
			{
				pFidData->dpTransPosition1.x = (int)((dOffsetZero1stPX - dCurrentMove1stPX + dptResult1st.x) * 1000); //dIndexP.x * dStepX + dOffsetP.x + visionResult.x
				pFidData->dpTransPosition1.y = (int)((dOffsetZero1stPY - dCurrentMove1stPY + dptResult1st.y) * 1000); //dIndexP.y * dStepY + dOffsetP.y + visionResult.y
	
				pFidData->bAcquire[USE_1ST - 1] = TRUE;
			}
			if(b2ndSkip && pFidData->nCam != LOW_TO_HIGH_CAM)
			{
				pFidData->dpTransPosition2.x = (int)((dOffsetZero2ndPX - dCurrentMove2ndPX + dptResult2nd.x) * 1000); //dIndexP.x * dStepX + dOffsetP.x + visionResult.x
				pFidData->dpTransPosition2.y = (int)((dOffsetZero2ndPY - dCurrentMove2ndPY + dptResult2nd.y) * 1000); //dIndexP.y * dStepY + dOffsetP.y + visionResult.y

				pFidData->bAcquire[USE_2ND - 1] = TRUE;
			}
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CPaneRecipeGenFiducialNew::CalFidPosWithFirst2Point(C2DTransform *pTrans)
{
	LPFIDDATA pFidData;
	if(m_bCalFidPosWithFirst2Point)
	{
		double dx, dy;
		for(int i = 0; i < m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX); i++)
		{
			pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			
			if(m_b1stPanel)
			{
				pTrans->TransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dx, dy);
				pFidData->dpTransPosition1.x = (int)(dx - pFidData->npPosition.x); pFidData->dpTransPosition1.y = (int)(dy - pFidData->npPosition.y);
			}
			else
			{
				pTrans->TransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dx, dy);
				pFidData->dpTransPosition2.x = (int)(dx - pFidData->npPosition.x); pFidData->dpTransPosition2.y = (int)(dy - pFidData->npPosition.y);
			}
		}
		m_bCalFidPosWithFirst2Point = FALSE;
	}
	return TRUE;
}

CPoint CPaneRecipeGenFiducialNew::GetNextStepIndex(int nStepNo)
{
	CPoint pos(0,0);
	if(nStepNo == 0)
		return pos;
	int num = (int)sqrt((double)nStepNo) + 2;
	
	for(int j = 1; j< num; j++)
	{
		for(int i = 0; i<j; i++)
		{
			nStepNo--;
			if(j%2 == 1) pos.x++;
			else pos.x--;
			if(nStepNo == 0) return pos;
		}
		for(int i = 0; i<j; i++)
		{
			nStepNo--;
			if(j%2 == 1) pos.y++;
			else pos.y--;
			if(nStepNo == 0) return pos;
		}
	}
	return pos;
}

void CPaneRecipeGenFiducialNew::SendFindTrigger(BOOL &b1stFound, BOOL &b2ndFound, BOOL bHighCam, BOOL b1stSkip, BOOL b2ndSkip, LPFIDDATA pFidData, double dFinalMoveX, double dFinalMoveY, CDPoint &dptResult1st, CDPoint &dptResult2nd, BOOL bDisp)
{
	if(m_b1stPanel)
	{
		if(!bHighCam)
		{
			if(!b1stSkip)
			{
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL); //ChangeVisionAllParam(LOW_1ST_CAM, pFidData);
				if(b1stFound = this->SendMessage(UM_VISION_FIND_NOGRAP, LOW_1ST_CAM, pFidData->sVisInfo.nModelType))
				{
					dptResult1st = m_visionResult;
				}
			}
		}
		else
		{
			if(!b1stSkip)
			{
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL); //ChangeVisionAllParam(HIGH_1ST_CAM, pFidData);
				if(b1stFound = this->SendMessage(UM_VISION_FIND_NOGRAP, HIGH_1ST_CAM, pFidData->sVisInfo.nModelType))
				{
					dptResult1st = m_visionResult;
				}
			}
		}
	}
	else
	{
		if(!bHighCam)
		{
			if(!b2ndSkip)
			{
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL); //ChangeVisionAllParam(LOW_2ND_CAM, pFidData);
				if(b2ndFound = this->SendMessage(UM_VISION_FIND_NOGRAP, LOW_2ND_CAM, pFidData->sVisInfo.nModelType))
				{
					dptResult2nd = m_visionResult;
				}
			}
		}
		else
		{
			if(!b2ndSkip)
			{
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL); //ChangeVisionAllParam(HIGH_2ND_CAM, pFidData);
				if(b2ndFound = this->SendMessage(UM_VISION_FIND_NOGRAP, HIGH_2ND_CAM, pFidData->sVisInfo.nModelType))
				{
					dptResult2nd = m_visionResult;
				}
			}
		}
	}

	if(bDisp)
	{
		CString strResult;
		strResult.Format(_T("%s"), m_ResultChar);
		DPHoleInfo(strResult);
	}
}

BOOL CPaneRecipeGenFiducialNew::GetFidPosHighCamInCenter(BOOL b1stPanel, LPFIDDATA pFidData)
{
	double dZ1, dZ2, dHeadOffsetX, dHeadOffsetY, dHeadOffsetX1, dHeadOffsetY1, dHeadOffsetX2, dHeadOffsetY2;
	double dModelX = 0, dModelY = 0;
	double dLowFOVX = gSystemINI.m_sSystemDevice.dLowFOVX, dLowFOVY = gSystemINI.m_sSystemDevice.dLowFOVY, 
			dHighFOVX = gSystemINI.m_sSystemDevice.dHighFOVX, dHighFOVY = gSystemINI.m_sSystemDevice.dHighFOVY;
	double dFinalMoveX, dFinalMoveY;
	double dOffsetZero1stPX, dOffsetZero1stPY, dOffsetZero2ndPX, dOffsetZero2ndPY; // 
	double dRefX, dRefY;
	CDPoint dptResult1st, dptResult2nd;
	CDPoint dOffsetP;
	BOOL	b1stFound, b2ndFound;

	m_pProject->m_Glyphs.GetRefPosition(dRefX, dRefY);

	if(pFidData->sVisInfo.nModelType < 2) // annulus, circle
	{
		dModelX = dModelY = pFidData->sVisInfo.dSizeA;
	}
	else if(pFidData->sVisInfo.nModelType < MODEL_PATTERN) // other geometery
	{
		dModelX = pFidData->sVisInfo.dSizeA;
		dModelY = pFidData->sVisInfo.dSizeB;
	}
	
	this->SendMessage(UM_CHANGE_VISION_PARAM, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
	this->SendMessage(UM_VISION_LAMP, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));

	dHeadOffsetX1 = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
	dHeadOffsetY1 = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
	dHeadOffsetX2 = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
	dHeadOffsetY2 = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
	
	dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - m_pProject->m_dPcbThick + pFidData->dOffsetZ;
	dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - m_pProject->m_dPcbThick2 + pFidData->dOffsetZ;

	dOffsetZero1stPX = m_pProject->m_dRefPosX	- (pFidData->npPosition.x / 1000.0 - dRefX) + dHeadOffsetX1;
	dOffsetZero1stPY = m_pProject->m_dRefPosY	- (pFidData->npPosition.y / 1000.0 - dRefY) + dHeadOffsetY1;
	dOffsetZero2ndPX = m_pProject->m_dRefPosX	- (pFidData->npPosition.x / 1000.0 - dRefX) + dHeadOffsetX2;
	dOffsetZero2ndPY = m_pProject->m_dRefPosY	- (pFidData->npPosition.y / 1000.0 - dRefY) + dHeadOffsetY2;

	if(!b1stPanel)
	{
		dHeadOffsetX = dHeadOffsetX2;
		dHeadOffsetY = dHeadOffsetY2;
		dOffsetP.x = pFidData->dpTransPosition2.x/1000.; dOffsetP.y = pFidData->dpTransPosition2.y/1000.;
	}
	else
	{									// 1st �������� ���̺� �̵�
		dHeadOffsetX = dHeadOffsetX1;
		dHeadOffsetY = dHeadOffsetY1;
		dOffsetP.x = pFidData->dpTransPosition1.x/1000.; dOffsetP.y = pFidData->dpTransPosition1.y/1000.;
	}

	dptResult1st.x = dptResult1st.y = dptResult2nd.x = dptResult2nd.y = 0; // 

	if(m_bStop)
	{
		this->SendMessage(UM_CHANGE_VISION_PARAM, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));

		return FALSE;
	}
	
	// Table move
	dFinalMoveX = m_pProject->m_dRefPosX					// ������ ���� ��ǥ (table motor ��ǥ : scanner center ����)
		- (pFidData->npPosition.x / 1000.0 - dRefX)	// ������������ ����� ���� ��ǥ ���� : table ��ǥ��� file ��ǥ�谡 �ݴ�� �����ӷ� - ��.
		- dOffsetP.x 							// ���� ã�Ҵ� offset
		+ dHeadOffsetX;
	dFinalMoveY = m_pProject->m_dRefPosY 
		- (pFidData->npPosition.y / 1000.0 - dRefY) 	
		- dOffsetP.y 						
		+ dHeadOffsetY;
	
	if(!gDeviceFactory.GetMotor()->MotorMoveXYZ(dFinalMoveX, dFinalMoveY, dZ1, dZ2, b1stPanel))
	{
		this->SendMessage(UM_CHANGE_VISION_PARAM, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));

		return FALSE;
	}
	if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
	{
		this->SendMessage(UM_CHANGE_VISION_PARAM, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));

		return FALSE;
	}
	
	if(b1stPanel)
	{
		::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL); //ChangeVisionAllParam(HIGH_1ST_CAM, pFidData);
		if(b1stFound = this->SendMessage(UM_VISION_FIND_NOGRAP, HIGH_1ST_CAM, pFidData->sVisInfo.nModelType))
		{
			pFidData->dpTransPosition1.x = (int)((dOffsetZero1stPX - dFinalMoveX + m_visionResult.x) * 1000); //dIndexP.x * dStepX + dOffsetP.x + visionResult.x
			pFidData->dpTransPosition1.y = (int)((dOffsetZero1stPY - dFinalMoveY + m_visionResult.y) * 1000); //dIndexP.y * dStepY + dOffsetP.y + visionResult.y
			pFidData->bAcquire[USE_1ST - 1] = TRUE;
			this->SendMessage(UM_CHANGE_VISION_PARAM, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
			this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));

			return TRUE;
		}
	}
	else
	{
		::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL); //ChangeVisionAllParam(HIGH_2ND_CAM, pFidData);
		if(b2ndFound = this->SendMessage(UM_VISION_FIND_NOGRAP, HIGH_2ND_CAM, pFidData->sVisInfo.nModelType))
		{
			pFidData->dpTransPosition2.x = (int)((dOffsetZero2ndPX - dFinalMoveX + m_visionResult.x) * 1000); //dIndexP.x * dStepX + dOffsetP.x + visionResult.x
			pFidData->dpTransPosition2.y = (int)((dOffsetZero2ndPY - dFinalMoveY + m_visionResult.y) * 1000); //dIndexP.y * dStepY + dOffsetP.y + visionResult.y
			pFidData->bAcquire[USE_2ND - 1] = TRUE;
			this->SendMessage(UM_CHANGE_VISION_PARAM, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
			this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));

			return TRUE;
		}
	}
	this->SendMessage(UM_CHANGE_VISION_PARAM, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
	this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));

	return FALSE;
}

void CPaneRecipeGenFiducialNew::UpdateUIToHoleInfo()
{
	m_bNoUIAutoChange = TRUE;
	m_nModelType = 1; // hole�� circle�� ���� 
	m_cmbType.SetCurSel(m_nModelType);
	m_cmbType.EnableWindow(FALSE);
	SelectPic( m_nModelType );
	
	m_cmbCamera.SetCurSel(m_nHoleFindCam);

	CString str;
	str.Format(_T("%.2f"), m_sHoleVisInfo.dSizeA);
	m_edtSizeA.SetWindowText(str);
	
	str.Format(_T("%.2f"), m_sHoleVisInfo.dSizeB);
	m_edtSizeB.SetWindowText(str);
	
	str.Format(_T("%.2f"), m_sHoleVisInfo.dSizeC);
	m_edtSizeC.SetWindowText(str);
	
	str.Format(_T("%.0f"), m_sHoleVisInfo.dScoreSize);
	m_edtSize.SetWindowText(str);
	
	str.Format(_T("%.0f"), m_sHoleVisInfo.dScoreAngle);
	m_edtAngle.SetWindowText(str);
	
	str.Format(_T("%.0f"), m_sHoleVisInfo.dAspectRatio);
	m_edtAspectRatio.SetWindowText(str);
	
	str.Format(_T("%d"), m_sHoleVisInfo.nThreshold);
	m_edtThreshold.SetWindowText(str);
	
	for(int i=0; i<4; i++)
	{
		m_nCoaxial[i] = m_sHoleVisInfo.nCoaxial[i];
		m_nRing[i] = m_sHoleVisInfo.nRing[i];
		m_dBrightness[i] = m_sHoleVisInfo.dBrightness[i];
		m_dContrast[i] = m_sHoleVisInfo.dContrast[i];
	}
	int nSel = m_cmbCamera.GetCurSel();
	if(nSel == 0) // High
	{
		m_cmbCameraNo.SetCurSel(0);
	}
	else if(nSel == 1) // Low
	{
		m_cmbCameraNo.SetCurSel(1);
	}
	else // Low To High
	{
		m_cmbCameraNo.SetCurSel(1);
	}
	SetValue( nSel );
	m_nPolarity = (int)m_sHoleVisInfo.nPolarity;
	UpdateData(FALSE);

	DrawData();
//	Invalidate();

	m_pProject->m_Glyphs.m_HoleFindData.sVisInfo = m_sHoleVisInfo;
	m_bNoUIAutoChange = FALSE;
}

int CPaneRecipeGenFiducialNew::GetCurrentFidType()
{
	int nFidType = m_cmbFidType.GetCurSel();

	switch (nFidType)
	{
	case 0 : //mechanical 
		return FID_PRIMARY + FID_FIND;
		break;
	case 1 : // course
		return FID_SECONDARY + FID_FIND;
		break;
	case 2 : // skiving
		return FID_SECONDARY + FID_DRILL;
		break;
	case 3 : // verify	
		return FID_PRIMARY + FID_FIND + FID_VERIFY;
		break;
	}
	return -1;
}

void CPaneRecipeGenFiducialNew::OnRButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_pProject == NULL)
		return;

	CRect rect;
	BOOL bFidList = FALSE, bSkiving;
	CPoint tempP;
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(&rect);
	ClientToScreen(&point);

	if(rect.PtInRect(point))
	{
		tempP.x = point.x - rect.left;
		tempP.y = point.y - rect.top;
		m_pProject->IsFidHoleGet(bFidList, tempP, bSkiving, TRUE);
		m_ptFidPos = tempP;
	}
	
	CMenu pMenu, *pSubMenu;
	pMenu.LoadMenu(IDR_MENU_CONTEXT);

	if(bFidList)
	{
		pSubMenu = pMenu.GetSubMenu(4);
		pSubMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point.x, point.y, this);
	}
	
	CFormView::OnRButtonUp(nFlags, point);
}

void CPaneRecipeGenFiducialNew::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

#ifdef __PUSAN_LDD__
	if( m_bIsLive )
	{
		int nCamNo = m_cmbCameraNo.GetCurSel();
		HVision* pVision = gDeviceFactory.GetVision();
		pVision->OnCamChange( nCamNo );
		pVision->OnAcquire(nCamNo);
	}
#endif

	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		if(!m_bIsLive)
		{
			m_bIsLive = FALSE;
			OnButtonLive2();
		}
	}
	else
	{
		if(m_bIsLive)
		{
			m_bIsLive = TRUE;
			OnButtonLive2();
		}
	}

	// Table Suction
	BOOL bMotor, b1st = TRUE, b2nd = TRUE;
	int nSuction1;
	nSuction1 = pMotor->GetCurrentSuction();

	bMotor = pMotor->GetCurrentSuctionMotor();

	if((nSuction1 & 0x01) && bMotor)
		b1st = TRUE;
	else
		b1st = FALSE;
			
	if((nSuction1 & 0x02) &&bMotor)
		b2nd = TRUE;
	else
		b2nd = FALSE;


	m_bTableSuction = b1st;
	m_ledTableSuction.Depress( !m_bTableSuction );

	m_bTableSuction2 = b2nd;
	m_ledTableSuction2.Depress( !m_bTableSuction2 );



	if(m_nUserLevel > 1) // super
	{
		BOOL bAuto = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_bAutoRun;

		if(bAuto)
		{
			m_btnMarkStart.ShowWindow(FALSE);
			m_btnMarkStop.ShowWindow(FALSE);
			m_btnShowTest.ShowWindow(FALSE);

			GetDlgItem(IDC_BUTTON_SHOW_MOTOR_MOVE)->ShowWindow(FALSE);
			m_btnApplyRefPos.ShowWindow(FALSE);
			GetDlgItem(IDC_BUTTON_SHOW_MOTOR_MOVE)->ShowWindow(FALSE);
		}
		else
		{
			BOOL bShow = ((CEasyDrillerDlg*)::AfxGetMainWnd())->IsShowEasyTestDlg();
			m_btnMarkStart.ShowWindow(bShow);
			m_btnMarkStop.ShowWindow(bShow);
			//m_btnShowTest.ShowWindow(TRUE)
			m_btnShowTest.ShowWindow(FALSE);
			m_btnApplyRefPos.ShowWindow(TRUE);
			GetDlgItem(IDC_BUTTON_SHOW_MOTOR_MOVE)->ShowWindow(TRUE);
		}
	}
	else
	{
		BOOL bShow = ((CEasyDrillerDlg*)::AfxGetMainWnd())->IsShowEasyTestDlg();

		if(bShow)
		{
			::AfxGetMainWnd()->SendMessage(UM_EASY_TEST_WINDOW, FALSE);
		}
		m_btnMarkStart.ShowWindow(FALSE);
		m_btnMarkStop.ShowWindow(FALSE);
		m_btnShowTest.ShowWindow(FALSE);
		m_btnApplyRefPos.ShowWindow(FALSE);
		GetDlgItem(IDC_BUTTON_SHOW_MOTOR_MOVE)->ShowWindow(FALSE);
	}




	CFormView::OnTimer(nIDEvent);
}

void CPaneRecipeGenFiducialNew::OnMoveToFiducial()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(pMotor->GetCurrentMode() == MODE_MPG || pMotor->GetCurrentMode() == MODE_OFF ||pMotor->GetCurrentMode() == MODE_HOME)
	{
		// MPG Off
		ErrMsgDlg(STDGNALM209);
		return;
	}
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	int nCamNo = m_cmbCameraSelect.GetCurSel();
	int nPattern = m_cmbType.GetCurSel();

	if(!m_pProject)
		return;
	BOOL b1stPanel = TRUE;
	if(m_pProject->m_nSeparation == USE_1ST)
	{
		if(nCamNo == LOW_2ND_CAM || nCamNo == HIGH_2ND_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	if(m_pProject->m_nSeparation == USE_2ND)
	{
		b1stPanel = FALSE;
		if(nCamNo == LOW_1ST_CAM || nCamNo == HIGH_1ST_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	// set train param
	LPFIDDATA pFidData = NULL;
	for(int i = 0; i < m_pProject->m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX); i++)
	{
		pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
		if(pFidData->npPosition == m_ptFidPos)
			break;
		pFidData = NULL;
	}

	if(pFidData == NULL)
	{
		ErrMessage(_T("Please select fiducial data"));
		return;
	}
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnApplyVisionParameter(nPattern ,nCamNo, pFidData->sVisInfo );

	CString strResult;
	TCHAR myResultChar[512] = {0,};

	double dZ1 = 0, dZ2 = 0, dX, dY, dHeadOffsetX, dHeadOffsetY, dRefX, dRefY;
//	m_pProject->m_Glyphs.GetRefPosition(dRefX, dRefY); // 
	dRefX = m_pProject->m_nMinX / 1000.;
	dRefY = m_pProject->m_nMinY / 1000.;

	if(nCamNo == LOW_1ST_CAM)
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - m_pProject->m_dPcbThick2;
		dHeadOffsetX = 0;
		dHeadOffsetY = 0;
	}
	else if(nCamNo == HIGH_1ST_CAM)
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - m_pProject->m_dPcbThick2;
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y; 
	}
	else if(nCamNo == LOW_2ND_CAM)
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - m_pProject->m_dPcbThick2;
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
	}
	else
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - m_pProject->m_dPcbThick2;
		dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y; 
	}

	dX = gProcessINI.m_sProcessFidFind.dRefPosX					// ������ ���� ��ǥ (table motor ��ǥ : scanner center ����)
		- (pFidData->npPosition.x / 1000.0 - dRefX)	// ������������ ����� ���� ��ǥ ���� : table ��ǥ��� file ��ǥ�谡 �ݴ�� �����ӷ� - ��.
		+ dHeadOffsetX;
	dY = gProcessINI.m_sProcessFidFind.dRefPosY 
		- (pFidData->npPosition.y / 1000.0 - dRefY) 	
		+ dHeadOffsetY;

	if(!pMotor->MotorMoveXYZ(dX, dY, dZ1, dZ2, b1stPanel))
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_MOVE_MOTOR);
		strMsg.Format(strString, "X,Y,Z");
		ErrMessage(strMsg);
		return;
	}

	pVision->SetInspectionArea(-1, nCamNo);
	if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
	{
		ErrMessage(_T("Inposition Error"));
		return;
	}

	DPOINT visionResult;
	if(!pVision->GetRealPos(&visionResult, nCamNo, pFidData->sVisInfo.nModelType, TRUE, myResultChar))
	{
		visionResult.x = 0;
		visionResult.y = 0;
	}
	else
	{
		pFidData->bAcquire[!b1stPanel] = TRUE;
		if(b1stPanel)
		{
			pFidData->dpTransPosition1.x += (int)(visionResult.x * 1000); pFidData->dpTransPosition1.y += (int)(visionResult.y * 1000);
		}
		else
		{
			pFidData->dpTransPosition2.x += (int)(visionResult.x * 1000); pFidData->dpTransPosition2.y += (int)(visionResult.y * 1000);
		}
		SetRealPos(b1stPanel);
	}
	strResult.Format(_T("%s"), myResultChar);
	DPHoleInfo(strResult);
	
}

void CPaneRecipeGenFiducialNew::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

void CPaneRecipeGenFiducialNew::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_nTimerID = SetTimer(1202, 500, NULL);
	}
}

void CPaneRecipeGenFiducialNew::OnCheckTableSuction() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	int nSuction = pMotor->GetCurrentSuction();
	
	if(nSuction & 0x01)
	{
		pMotor->WriteOutputIOBIt(2, 1, TRUE);
		pMotor->WriteOutputIOBIt(2, 0, FALSE);
#ifdef __CUNGJU__
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ACRYL_TABLE_SUCTION, FALSE);
#endif
	}
	else
	{
		pMotor->WriteOutputIOBIt(2, 0, TRUE);
		pMotor->WriteOutputIOBIt(2, 1, FALSE);
#ifdef __CUNGJU__
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ACRYL_TABLE_SUCTION, TRUE);
#endif
	}
}

void CPaneRecipeGenFiducialNew::OnCheckTableSuction2() 
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	BOOL bMotor = pMotor->GetCurrentSuctionMotor();
	int nSuction = pMotor->GetCurrentSuction();
	
	if(nSuction & 0x02)
	{
		pMotor->WriteOutputIOBIt(2, 2, FALSE);
		pMotor->WriteOutputIOBIt(2, 3, TRUE);
#ifdef __CUNGJU__
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ACRYL_TABLE_SUCTION2, FALSE);
#endif
	}
	else
	{	
		pMotor->WriteOutputIOBIt(2, 2, TRUE);
		pMotor->WriteOutputIOBIt(2, 3, FALSE);
#ifdef __CUNGJU__
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ACRYL_TABLE_SUCTION2, TRUE);
#endif
	}
}


void CPaneRecipeGenFiducialNew::OnBnClickedButtonMoveLoadingPos()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	ButtonEnable(FALSE);
	//	pMotor->TableLoadPos();
	if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX, gProcessINI.m_sProcessAutoSetting.dLoadPosY, TRUE))
	{
		ErrMsgDlg(STDGNALM438);
		ButtonEnable(TRUE);
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		ButtonEnable(TRUE);
	}
	ButtonEnable(TRUE);
}
void CPaneRecipeGenFiducialNew::CheckInpositionError(int nAxis, BOOL bShow)
{
	switch(nAxis)
	{
	case IND_X : ErrMsgDlg(STDGNALM404); break;
	case IND_Y : ErrMsgDlg(STDGNALM405); break;
	case IND_Z1 : ErrMsgDlg(STDGNALM406); break;
	case IND_Z2 : ErrMsgDlg(STDGNALM407); break;
	case IND_M1 : ErrMsgDlg(STDGNALM408); break;
	case IND_M2 : ErrMsgDlg(STDGNALM409); break;
	case IND_M3 : ErrMsgDlg(STDGNALM990); break;
	case IND_C1 : ErrMsgDlg(STDGNALM410); break;
	case IND_C2 : ErrMsgDlg(STDGNALM411); break;
	}
}

void CPaneRecipeGenFiducialNew::OnButtonMoveNearPos1() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(pMotor->GetCurrentMode() == MODE_MPG || pMotor->GetCurrentMode() == MODE_OFF ||pMotor->GetCurrentMode() == MODE_HOME)
	{
		// MPG Off
		ErrMsgDlg(STDGNALM209);
		return;
	}
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Error Reset")); // 110603
		return;
	}

	int nCamNo = m_cmbCameraSelect.GetCurSel();
	int nPattern = m_cmbType.GetCurSel();

	if(!m_pProject)
		return;
	BOOL b1stPanel = TRUE;
	if(m_pProject->m_nSeparation == USE_1ST)
	{
		if(nCamNo == LOW_2ND_CAM || nCamNo == HIGH_2ND_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	if(m_pProject->m_nSeparation == USE_2ND)
	{
		b1stPanel = FALSE;
		if(nCamNo == LOW_1ST_CAM || nCamNo == HIGH_1ST_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	// set train param
	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
	if(pFidData == NULL)
	{
		ErrMessage(_T("Please select fiducial data"));
		return;
	}
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnApplyVisionParameter(nPattern ,nCamNo, pFidData->sVisInfo );

	CString strResult;
	TCHAR myResultChar[512] = {0,};

	double dZ1 = 0, dZ2 = 0, dX, dY;
	
	if(nCamNo == LOW_1ST_CAM)
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - m_pProject->m_dPcbThick2;
	}
	else if(nCamNo == HIGH_1ST_CAM)
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - m_pProject->m_dPcbThick2;
	}
	else if(nCamNo == LOW_2ND_CAM)
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - m_pProject->m_dPcbThick2;
	}
	else
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - m_pProject->m_dPcbThick2;
	}

	dX = gProcessINI.m_sProcessFidFind.dNearPosX;
	dY = gProcessINI.m_sProcessFidFind.dNearPosY;

	if(!pMotor->MotorMoveXYZ(dX, dY, dZ1, dZ2, b1stPanel))
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_MOVE_MOTOR);
		strMsg.Format(strString, "X,Y,Z");
		ErrMessage(strMsg);
		return;
	}

	pVision->SetInspectionArea(-1, nCamNo);
	if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
	{
		ErrMessage(_T("Inposition Error"));
		return;
	}

	DPOINT visionResult;
	if(!pVision->GetRealPos(&visionResult, nCamNo, pFidData->sVisInfo.nModelType, TRUE, myResultChar))
	{
		visionResult.x = 0;
		visionResult.y = 0;
	}
	else
	{
		pFidData->bAcquire[!b1stPanel] = TRUE;
		if(b1stPanel)
		{
			pFidData->dpTransPosition1.x += (int)(visionResult.x * 1000); pFidData->dpTransPosition1.y += (int)(visionResult.y * 1000);
		}
		else
		{
			pFidData->dpTransPosition2.x += (int)(visionResult.x * 1000); pFidData->dpTransPosition2.y += (int)(visionResult.y * 1000);
		}
		SetRealPos(b1stPanel);
	}
	strResult.Format(_T("%s"), myResultChar);
	DPHoleInfo(strResult);

	//	pVision->OnAcquire(m_nCameraNo);
}

void CPaneRecipeGenFiducialNew::OnButtonMoveNearPos2() 
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(pMotor->GetCurrentMode() == MODE_MPG || pMotor->GetCurrentMode() == MODE_OFF ||pMotor->GetCurrentMode() == MODE_HOME)
	{
		// MPG Off
		ErrMsgDlg(STDGNALM209);
		return;
	}
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Error Reset")); // 110603
		return;
	}

	int nCamNo = m_cmbCameraSelect.GetCurSel();
	int nPattern = m_cmbType.GetCurSel();

	if(!m_pProject)
		return;
	BOOL b1stPanel = TRUE;
	if(m_pProject->m_nSeparation == USE_1ST)
	{
		if(nCamNo == LOW_2ND_CAM || nCamNo == HIGH_2ND_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	if(m_pProject->m_nSeparation == USE_2ND)
	{
		b1stPanel = FALSE;
		if(nCamNo == LOW_1ST_CAM || nCamNo == HIGH_1ST_CAM)
		{
			ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
			return;
		}
	}
	// set train param
	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
	if(pFidData == NULL)
	{
		ErrMessage(_T("Please select fiducial data"));
		return;
	}
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnApplyVisionParameter(nPattern ,nCamNo, pFidData->sVisInfo );

	CString strResult;
	TCHAR myResultChar[512] = {0,};

	double dZ1 = 0, dZ2 = 0, dX, dY;

	if(nCamNo == LOW_1ST_CAM)
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - m_pProject->m_dPcbThick2;
	}
	else if(nCamNo == HIGH_1ST_CAM)
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - m_pProject->m_dPcbThick2;
	}
	else if(nCamNo == LOW_2ND_CAM)
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - m_pProject->m_dPcbThick2;
	}
	else
	{
		dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - m_pProject->m_dPcbThick;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - m_pProject->m_dPcbThick2;
	}

	dX = gProcessINI.m_sProcessFidFind.dNearPosX2;
	dY = gProcessINI.m_sProcessFidFind.dNearPosY2;

	if(!pMotor->MotorMoveXYZ(dX, dY, dZ1, dZ2, b1stPanel))
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_MOVE_MOTOR);
		strMsg.Format(strString, "X,Y,Z");
		ErrMessage(strMsg);
		return;
	}

	pVision->SetInspectionArea(-1, nCamNo);
	if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
	{
		ErrMessage(_T("Inposition Error"));
		return;
	}

	DPOINT visionResult;
	if(!pVision->GetRealPos(&visionResult, nCamNo, pFidData->sVisInfo.nModelType, TRUE, myResultChar))
	{
		visionResult.x = 0;
		visionResult.y = 0;
	}
	else
	{
		pFidData->bAcquire[!b1stPanel] = TRUE;
		if(b1stPanel)
		{
			pFidData->dpTransPosition1.x += (int)(visionResult.x * 1000); pFidData->dpTransPosition1.y += (int)(visionResult.y * 1000);
		}
		else
		{
			pFidData->dpTransPosition2.x += (int)(visionResult.x * 1000); pFidData->dpTransPosition2.y += (int)(visionResult.y * 1000);
		}
		SetRealPos(b1stPanel);
	}
	strResult.Format(_T("%s"), myResultChar);
	DPHoleInfo(strResult);

	//	pVision->OnAcquire(m_nCameraNo);
}
 
void CPaneRecipeGenFiducialNew::OnButtonMotor()
{
//	::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_MOTOR, TRUE);
	CDlgMotorMove dlg;
	dlg.SetDisplayOn(TRUE);
	dlg.DoModal();
}

void CPaneRecipeGenFiducialNew::OnButtonLpcView()
{
//	CDlgLpcView* pLpcView = (CDlgLpcView*)AfxGetMainWnd();
//	pLpcView->InitialDrawRatio();
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_dlgLpc.SetProject(m_pProject);
	::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_LPC, TRUE);
}


BOOL CPaneRecipeGenFiducialNew::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Recipe_Fiducial) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneRecipeGenFiducialNew::OnBnClickedCheckUseScaleLimit()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(TRUE);
	
	CString str;
	BOOL bCheckUseScale = m_chkUseScaleLimit.GetCheck();
	
	if(m_pProject == NULL)
		return; 
	
	int nCount = m_pProject->m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	
	LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_nFidIndex);
	if(pFidData == NULL)
	{
		return;
	}

	for(int i=0;i<nCount; i++)
	{
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			
		if(pFidData == NULL)
		{
//				ErrMessage(_T("There is no fiducial data"));
			return;
		}

		int nFidType = GetCurrentFidType();
		if(nFidType != pFidData->nFidType)
			continue;
			
		pFidData->bCheckScaleLimit = bCheckUseScale;
	}
}
LRESULT CPaneRecipeGenFiducialNew::SetVisionLamp(WPARAM wParam, LPARAM lParam)
{
	if(!gSystemINI.m_sHardWare.nUseLampRS232)
		return FALSE;
	HVision* pVision = gDeviceFactory.GetVision();
	int nCam = (int)wParam;
	VISION_INFO* pVisInfo = reinterpret_cast<VISION_INFO*>(lParam);

	pVision->OnLightAll(nCam, pVisInfo->nCoaxial[nCam], pVisInfo->nRing[nCam]);
	return TRUE;
}
void CPaneRecipeGenFiducialNew::OnButtonSave()
{
	if(m_pProject->m_nDataLoadStep <=  SET_FID_ORIGIN)
	{
		ErrMessage(_T("First do Set Ref."));
		return;
	}

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	double dMoveX, dMoveY, dMoveX2, dMoveY2;
	DAreaInfo* pAreaInfo;
	LPFIREHOLE pHole;
	POSITION pos, posData;
	double dPanelOffsetX = 0, dPanelOffsetY = 0;
	double dLaserOffsetX, dLaserOffsetY, dLaserOffsetX2, dLaserOffsetY2;
	int nToolStart, nToolEnd, nTool;

	nToolStart = ADDED_FID_TOOL + 1;
	nToolEnd = MAX_TOOL_NO;

	CString strPathName, strFile, strBuffer;
	strFile.Format(_T("%s"), m_pProject->m_szFileName);
	int nIndex = strFile.ReverseFind('\\');
	strFile = strFile.Mid(nIndex+1);
	strPathName.Format(_T("%sHoleInfo_%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(),strFile);

	BOOL bSelectMode = FALSE;
	if(m_pProject->IsThereSelectData())
		bSelectMode = TRUE;

	CStdioFile file;
	if (FALSE == file.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;
	//file.SeekToEnd();
	

	for(int i = nToolStart; i < nToolEnd; i++)
	{
		pos = m_pProject->m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_pProject->m_Areas[i].GetNext(pos);
			if(m_pProject->m_nSeparation == USE_DUAL)
			{
				pMotor->GetAxisMoveOffset(pAreaInfo->m_dTableX/1000., pAreaInfo->m_dTableY/1000., dPanelOffsetX, dPanelOffsetY, DELTA_PANEL_OFFSET);
				dPanelOffsetX = (dPanelOffsetX + 0.0005) * 1000;
				dPanelOffsetY = (dPanelOffsetY + 0.0005) * 1000;
			}
			else
			{
				dPanelOffsetX = 0;
				dPanelOffsetY = 0;
			}
			gDeviceFactory.GetEocard()->GetLaserOffset(pAreaInfo->m_dTableX/1000, pAreaInfo->m_dTableY/1000, dLaserOffsetX, dLaserOffsetY, FIRST_PANEL_OFFSET);
			gDeviceFactory.GetEocard()->GetLaserOffset(pAreaInfo->m_dTableX/1000, pAreaInfo->m_dTableY/1000, dLaserOffsetX2, dLaserOffsetY2, SECOND_PANEL_OFFSET);

			for(int j = ADDED_FID_TOOL; j < MAX_TOOL_NO; j++)
			{
				posData = pAreaInfo->m_FireHoles[j].GetHeadPosition();
				
				while(posData)
				{
					pHole = pAreaInfo->m_FireHoles[j].GetNext(posData);
					nTool = m_pProject->m_ToolSumInfo[pHole->pOrigin->nToolNo].nRealToolNo;
					if( (m_pProject->m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable() &&
						(!bSelectMode || (bSelectMode && pHole->bSelect))) )
					{
						dMoveX = (pAreaInfo->m_dTableX - (pHole->dpLSBPos1.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/1000.0 - dLaserOffsetX;
						dMoveY = (pAreaInfo->m_dTableY - (pHole->dpLSBPos1.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/1000.0 - dLaserOffsetY;
						
						dMoveX2 = (pAreaInfo->m_dTableX - dPanelOffsetX - (pHole->dpLSBPos2.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/ 1000.0 - dLaserOffsetX;
						dMoveY2 = (pAreaInfo->m_dTableY - dPanelOffsetY - (pHole->dpLSBPos2.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/ 1000.0 - dLaserOffsetY;
				
						strBuffer.Format(_T("Tool : %d\tArea : %d\tArea Table : %d, %d\tOrigin : %d, %d\tTrans 1st : %d, %d\tTrans 2nd : %d, %d\tFire 1st : %.3f, %.3f\tFire 2nd : %.3f, %.3f\n"), 
							nTool, pAreaInfo->m_nSortIndex,
							pAreaInfo->m_dTableX, pAreaInfo->m_dTableY,
							pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y,
							pHole->dpLSBPos1.x, pHole->dpLSBPos1.y, 
							pHole->dpLSBPos2.x, pHole->dpLSBPos2.y,
							dMoveX, dMoveY, dMoveX2, dMoveY2); 

						file.Write(strBuffer, strBuffer.GetLength());
					}
				}
			}
		}
	}
	file.Close();
}


void CPaneRecipeGenFiducialNew::InitSlideControl()
{
	m_SliderCoaxial.SetRange(0, 255);
	m_SliderRing.SetRange(0, 255);

	// ��ġ ����.
	m_SliderCoaxial.SetPos(50);
	m_SliderRing.SetPos(50);

	// ���� ������ �����Ѵ�.
	// �Ӽ��� Tick Marks�� Auto Ticks�� True�� �Ǿ� �־�� �Ѵ�.
	m_SliderCoaxial.SetTicFreq(10);
	m_SliderRing.SetTicFreq(10);

	// Ű���� Ŀ��Ű�� �����̴��� �����϶��� ���� ũ�⸦ ����
	m_SliderCoaxial.SetLineSize(1);
	m_SliderRing.SetLineSize(1);

	// Ű������ PgUp, PgDnŰ�� �����ų� ���콺�� �����̴��� ������ Ŭ���� ������ ũ�� 
	m_SliderCoaxial.SetPageSize(10);
	m_SliderRing.SetPageSize(10);
}

void CPaneRecipeGenFiducialNew::OnNMReleasedcaptureSliderCoaxial(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
	int nCoaxial = 0;
	CString strData;
	nCoaxial= m_SliderCoaxial.GetPos();
	strData.Format(_T("%d"), nCoaxial);
	m_edtCoaxial.SetWindowText( strData );
	*pResult = 0;
}


void CPaneRecipeGenFiducialNew::OnNMReleasedcaptureSliderRing(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
	int nRing = 0;
	CString strData;
	nRing = m_SliderRing.GetPos();
	strData.Format(_T("%d"), nRing);
	m_edtRing.SetWindowText( strData );
	*pResult = 0;
}

void CPaneRecipeGenFiducialNew::OnCheckUseRoiSize() 
{
	// TODO: Add your control notification handler code here
	if(m_pProject != NULL)
		m_pProject->m_bUseRoiSize = m_chkRoiSize.GetCheck();
}
void CPaneRecipeGenFiducialNew::OnCheckUseRoiSize2() 
{
	// TODO: Add your control notification handler code here
	if(m_pProject != NULL)
		m_pProject->m_bUseRoiSize2 = m_chkRoiSize2.GetCheck();
}
void CPaneRecipeGenFiducialNew::OnChangeEditRoiX2() 
{
	UpdateData(TRUE);

	CString str;
	double dTempVal;

	if(m_pProject == NULL)
		return; 

	m_edtRoiX2.GetWindowText(str);
	dTempVal = atoi(str);
	m_pProject->m_nRoiX2 = dTempVal;
}
void CPaneRecipeGenFiducialNew::OnChangeEditRoiX() 
{
	UpdateData(TRUE);
	
	CString str;
	double dTempVal;
	
	if(m_pProject == NULL)
		return; 
	
	m_edtRoiX.GetWindowText(str);
	dTempVal = atoi(str);
	m_pProject->m_nRoiX = dTempVal;
}

void CPaneRecipeGenFiducialNew::OnChangeEditRoiY() 
{
	UpdateData(TRUE);
	
	CString str;
	double dTempVal;
	
	if(m_pProject == NULL)
		return; 
	
	m_edtRoiY.GetWindowText(str);
	dTempVal = atoi(str);
	m_pProject->m_nRoiY = dTempVal;
}
	void CPaneRecipeGenFiducialNew::OnBnClickedButtonShowTest()
{
	::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_MOTOR, FALSE);
	::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_LPC, FALSE);

	BOOL bShow = ((CEasyDrillerDlg*)::AfxGetMainWnd())->IsShowEasyTestDlg();

	::AfxGetMainWnd()->SendMessage(UM_EASY_TEST_WINDOW, !bShow);

}


	void CPaneRecipeGenFiducialNew::OnBnClickedButtonMarkStart()
	{
			
		if( gDeviceFactory.GetMotor()->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}

	::AfxGetMainWnd()->SendMessage( DRILL_START );
	}


	void CPaneRecipeGenFiducialNew::OnBnClickedButtonMarkStop()
	{
		if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
		{
		    ::AfxGetMainWnd()->SendMessage( DRILL_STOP, TRUE );
		}
	}


	void CPaneRecipeGenFiducialNew::EnableButton(BOOL bStart,BOOL bStop)
	{
		BOOL bShow = ((CEasyDrillerDlg*)::AfxGetMainWnd())->IsShowEasyTestDlg();

		if(!bShow)
			return;

		ButtonEnable(bStart);
		
		m_btnStop.EnableWindow(bStart);
		m_btnSave.EnableWindow(bStart);
		m_btnShowTest.EnableWindow(bStart);
		m_btnApplyRefPos.EnableWindow(bStart);
	}


	void CPaneRecipeGenFiducialNew::OnBnClickedButtonShowMotorMove()
	{
		CDlgMotorMove dlg;
		dlg.SetDisplayOn(TRUE);
		dlg.DoModal();
	}




	void CPaneRecipeGenFiducialNew::OnBnClickedButtonClearFindHole()
	{
		m_pProject->ClearHoleFindInfo();
		DrawData();
		 ::AfxGetMainWnd()->SendMessage(UM_EASY_TEST_DRAW2);
	}
	void CPaneRecipeGenFiducialNew::OnBnClickedButtonApplyRefpos()
	{
		// TODO: Add your control notification handler code here
		if(m_chkSetROI.GetCheck())
			OnCheckInspArea();

		int nCamNo = m_cmbCameraSelect.GetCurSel();
		int nPattern = m_cmbType.GetCurSel();
		CString strMsg;

		if(!m_pProject)
			return;

		if(!m_pProject->m_Glyphs.IsValidFiducial())
		{
			ErrMessage(IDS_DATA_UNIT_FID2);
			return;
		}

		// set train param
		LPFIDDATA pFidData = m_pProject->m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, 0);
		if(pFidData == NULL)
		{
			ErrMessage(_T("Please select fiducial data"));
			return;
		}


		BOOL b1stPanel = TRUE;
		if(m_pProject->m_nSeparation == USE_1ST)
		{
			if(nCamNo == LOW_2ND_CAM || nCamNo == HIGH_2ND_CAM)
			{
				ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
				return;
			}
		}
		if(m_pProject->m_nSeparation == USE_2ND)
		{
			b1stPanel = FALSE;
			if(nCamNo == LOW_1ST_CAM || nCamNo == HIGH_1ST_CAM)
			{
				ErrMessage(IDS_ERR_SELECT_CAMERA_PANEL);
				return;
			}
		}

		

		double dOldPosX = m_pProject->m_dRefPosX;
		double dOldPosY = m_pProject->m_dRefPosY;

		CString strData;
		m_edtRefPosX.GetWindowText( strData );
		m_pProject->m_dRefPosX = atof( (LPSTR)(LPCTSTR)strData );

		m_edtRefPosY.GetWindowText( strData );
		m_pProject->m_dRefPosY = atof( (LPSTR)(LPCTSTR)strData );


		m_pProject->ResetFidOffset();
		m_pProject->m_Glyphs.ResetFidAcquireRet(DEFAULT_FID_INDEX, TRUE);


		int nDualMode = USE_1ST;
		if(nCamNo == LOW_2ND_CAM || nCamNo == HIGH_2ND_CAM)
			nDualMode = USE_2ND;

		ApplyFidDataToShot(DEFAULT_FID_INDEX, FIND_ALL_FID, FALSE, -1, nDualMode);
		if(!(m_pProject->m_nDataLoadStep & SET_FID_ORIGIN))
			m_pProject->m_nDataLoadStep += SET_FID_ORIGIN; // 091117
		m_pProject->m_Glyphs.ResetFidAcquireRet(DEFAULT_FID_INDEX, FALSE);
		
	}

	void CPaneRecipeGenFiducialNew::OnBnClickedButtonFidInfoBlockCopyInclude()
	{
		CString strBlock = "";
		int  dCurrentBlock;

		GetDlgItem(IDC_EDIT_CURRENT_FID_BLOCK)->GetWindowText(strBlock);

		dCurrentBlock = atoi(strBlock);

		if(dCurrentBlock < 0 || strBlock == "")
			return;

		CString strMsg;

		strMsg.Format("Do you want to copy %d Block Fid Info to same Block ",dCurrentBlock);


		if(IDNO == ErrMessage(strMsg, MB_YESNO))
			return;

		CString str;
		double dTempVal;
		int	nTempVal;
		int nFidType;

		UpdateData(TRUE);

		SkivingCheck();

		// �Է°� ��������

		m_edtSizeA.GetWindowText(str);
		dTempVal = atof(str);
		if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeA.IsWindowEnabled()) 
		{
			m_edtSizeA.SetFocus();
			ErrMessage(_T("0 < SizeA <= 5(mm)"));
			return;
		}

		m_edtSizeB.GetWindowText(str);
		dTempVal = atof(str);
		if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeB.IsWindowEnabled()) 
		{
			m_edtSizeB.SetFocus();
			ErrMessage(_T("0 < SizeB <= 5(mm)"));
			return;
		}

		m_edtSizeC.GetWindowText(str);
		dTempVal = atof(str);
		if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeC.IsWindowEnabled()) 
		{
			m_edtSizeC.SetFocus();
			ErrMessage(_T("0 < SizeC <= 5(mm)"));
			return;
		}

		m_edtSize.GetWindowText(str);
		nTempVal = atoi(str);
		if(nTempVal > MAX_PERCENT || nTempVal < 0) 
		{
			m_edtSize.SetFocus();
			ErrMessage(_T("0 <= Size <= 100(%)"));
			return;
		}

		m_edtAngle.GetWindowText(str);
		nTempVal = atoi(str);
		if(nTempVal > MAX_ANGLE || nTempVal < 0) 
		{
			m_edtAngle.SetFocus();
			ErrMessage(_T("0 <= Angle <= 360"));
			return;
		}

		m_edtAspectRatio.GetWindowText(str);
		nTempVal = atoi(str);
		if(nTempVal > MAX_PERCENT || nTempVal < 0) 
		{
			m_edtAspectRatio.SetFocus();
			ErrMessage(_T("0 <= Aspect Ratio <= 100(%)"));
			return;
		}

		m_edtThreshold.GetWindowText(str);
		nTempVal = atoi(str);
		if( nTempVal < 0 || nTempVal > 255)
		{
			m_edtThreshold.SetFocus();
			ErrMessage(_T("0 <= Threshold <= 255"));
			return;
		}

		// �Է°� �����Ϸ�

		m_edtPath.GetWindowText(str);
		lstrcpy(m_pProject->m_szJobFilePath, (LPCSTR)str);

		LPFIDDATA pFidData;
		POSITION pos = m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
		while (pos)
		{
			pFidData = m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);

			if(pFidData->nFidBlock != dCurrentBlock)
				continue;

			if(gProcessINI.m_sProcessFidFind.bUseAllControl)
				pFidData->nCam = m_cmbCamera.GetCurSel();
			else
				pFidData->nCam = 1;

			m_edtFidOffsetZ.GetWindowText(str);
			dTempVal = atof(str);
			pFidData->dOffsetZ = dTempVal;

			nFidType = m_cmbFidType.GetCurSel();
			switch (nFidType)
			{
			case 0 : //mechanical 
				pFidData->nFidType = FID_PRIMARY + FID_FIND;
				break;
			case 1 : // course
				pFidData->nFidType = FID_SECONDARY + FID_FIND;
				break;
			case 2 : // skiving
				pFidData->nFidType = FID_SECONDARY + FID_DRILL;
				break;
			case 3 : // verify	
				pFidData->nFidType = FID_FIND + FID_VERIFY + FID_PRIMARY;
				break;
			}

			pFidData->sVisInfo.nModelType = (long)m_nModelType;

			m_edtSizeA.GetWindowText(str);
			dTempVal = atof(str);
			pFidData->sVisInfo.dSizeA = (float)dTempVal;

			m_edtSizeB.GetWindowText(str);
			dTempVal = atof(str);
			pFidData->sVisInfo.dSizeB = (float)dTempVal;

			m_edtSizeC.GetWindowText(str);
			dTempVal = atof(str);
			pFidData->sVisInfo.dSizeC = (float)dTempVal;

			pFidData->sVisInfo.nPolarity = (long)m_nPolarity;

			m_edtSize.GetWindowText(str);
			nTempVal = atoi(str);
			pFidData->sVisInfo.dScoreSize = nTempVal;

			m_edtAngle.GetWindowText(str);
			nTempVal = atoi(str);
			pFidData->sVisInfo.dScoreAngle = nTempVal;

			m_edtAspectRatio.GetWindowText(str);
			nTempVal = atoi(str);
			pFidData->sVisInfo.dAspectRatio = nTempVal;

			m_edtThreshold.GetWindowText(str);
			nTempVal = atoi(str);
			pFidData->sVisInfo.nThreshold = nTempVal;

			for(int i=0; i<4; i++)
			{
				pFidData->sVisInfo.nCoaxial[i] = m_nCoaxial[i];
				pFidData->sVisInfo.nRing[i] = m_nRing[i];
				pFidData->sVisInfo.dBrightness[i] = m_dBrightness[i];
				pFidData->sVisInfo.dContrast[i] = m_dContrast[i];
			}
		}
	}


	void CPaneRecipeGenFiducialNew::OnBnClickedButtonFidInfoBlockCopyExclude()
	{
		CString strBlock = "";
		double  dCurrentBlock;

		GetDlgItem(IDC_EDIT_CURRENT_FID_BLOCK)->GetWindowText(strBlock);

		dCurrentBlock = atoi(strBlock);

		if(dCurrentBlock < 0 || strBlock == "")
			return;

		CString strMsg;

		strMsg.Format("Do you want to copy Fid Info exclude 0 Block ",dCurrentBlock);


		if(IDNO == ErrMessage(strMsg, MB_YESNO))
			return;

		CString str;
		double dTempVal;
		int	nTempVal;
		int nFidType;

		UpdateData(TRUE);

		SkivingCheck();

		// �Է°� ��������

		m_edtSizeA.GetWindowText(str);
		dTempVal = atof(str);
		if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeA.IsWindowEnabled()) 
		{
			m_edtSizeA.SetFocus();
			ErrMessage(_T("0 < SizeA <= 5(mm)"));
			return;
		}

		m_edtSizeB.GetWindowText(str);
		dTempVal = atof(str);
		if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeB.IsWindowEnabled()) 
		{
			m_edtSizeB.SetFocus();
			ErrMessage(_T("0 < SizeB <= 5(mm)"));
			return;
		}

		m_edtSizeC.GetWindowText(str);
		dTempVal = atof(str);
		if(dTempVal > MAX_FID_SIZE || dTempVal <= 0 && m_edtSizeC.IsWindowEnabled()) 
		{
			m_edtSizeC.SetFocus();
			ErrMessage(_T("0 < SizeC <= 5(mm)"));
			return;
		}

		m_edtSize.GetWindowText(str);
		nTempVal = atoi(str);
		if(nTempVal > MAX_PERCENT || nTempVal < 0) 
		{
			m_edtSize.SetFocus();
			ErrMessage(_T("0 <= Size <= 100(%)"));
			return;
		}

		m_edtAngle.GetWindowText(str);
		nTempVal = atoi(str);
		if(nTempVal > MAX_ANGLE || nTempVal < 0) 
		{
			m_edtAngle.SetFocus();
			ErrMessage(_T("0 <= Angle <= 360"));
			return;
		}

		m_edtAspectRatio.GetWindowText(str);
		nTempVal = atoi(str);
		if(nTempVal > MAX_PERCENT || nTempVal < 0) 
		{
			m_edtAspectRatio.SetFocus();
			ErrMessage(_T("0 <= Aspect Ratio <= 100(%)"));
			return;
		}

		m_edtThreshold.GetWindowText(str);
		nTempVal = atoi(str);
		if( nTempVal < 0 || nTempVal > 255)
		{
			m_edtThreshold.SetFocus();
			ErrMessage(_T("0 <= Threshold <= 255"));
			return;
		}

		// �Է°� �����Ϸ�

		m_edtPath.GetWindowText(str);
		lstrcpy(m_pProject->m_szJobFilePath, (LPCSTR)str);

		LPFIDDATA pFidData;
		POSITION pos = m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
		while (pos)
		{
			pFidData = m_pProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);

			if(pFidData->nFidBlock == 0)
				continue;

			if(gProcessINI.m_sProcessFidFind.bUseAllControl)
				pFidData->nCam = m_cmbCamera.GetCurSel();
			else
				pFidData->nCam = 1;

			m_edtFidOffsetZ.GetWindowText(str);
			dTempVal = atof(str);
			pFidData->dOffsetZ = dTempVal;

			nFidType = m_cmbFidType.GetCurSel();
			switch (nFidType)
			{
			case 0 : //mechanical 
				pFidData->nFidType = FID_PRIMARY + FID_FIND;
				break;
			case 1 : // course
				pFidData->nFidType = FID_SECONDARY + FID_FIND;
				break;
			case 2 : // skiving
				pFidData->nFidType = FID_SECONDARY + FID_DRILL;
				break;
			case 3 : // verify	
				pFidData->nFidType = FID_FIND + FID_VERIFY + FID_PRIMARY;
				break;
			}

			pFidData->sVisInfo.nModelType = (long)m_nModelType;

			m_edtSizeA.GetWindowText(str);
			dTempVal = atof(str);
			pFidData->sVisInfo.dSizeA = (float)dTempVal;

			m_edtSizeB.GetWindowText(str);
			dTempVal = atof(str);
			pFidData->sVisInfo.dSizeB = (float)dTempVal;

			m_edtSizeC.GetWindowText(str);
			dTempVal = atof(str);
			pFidData->sVisInfo.dSizeC = (float)dTempVal;

			pFidData->sVisInfo.nPolarity = (long)m_nPolarity;

			m_edtSize.GetWindowText(str);
			nTempVal = atoi(str);
			pFidData->sVisInfo.dScoreSize = nTempVal;

			m_edtAngle.GetWindowText(str);
			nTempVal = atoi(str);
			pFidData->sVisInfo.dScoreAngle = nTempVal;

			m_edtAspectRatio.GetWindowText(str);
			nTempVal = atoi(str);
			pFidData->sVisInfo.dAspectRatio = nTempVal;

			m_edtThreshold.GetWindowText(str);
			nTempVal = atoi(str);
			pFidData->sVisInfo.nThreshold = nTempVal;

			for(int i=0; i<4; i++)
			{
				pFidData->sVisInfo.nCoaxial[i] = m_nCoaxial[i];
				pFidData->sVisInfo.nRing[i] = m_nRing[i];
				pFidData->sVisInfo.dBrightness[i] = m_dBrightness[i];
				pFidData->sVisInfo.dContrast[i] = m_dContrast[i];
			}
		}
	}

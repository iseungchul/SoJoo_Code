// PaneSysSetupBeamPathPusan1.h: interface for the CPaneSysSetupBeamPath class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PANESYSSETUPBEAMPATHLDD_H__B58A0180_747E_45EE_8DB9_68EF4F48D6E2__INCLUDED_)
#define AFX_PANESYSSETUPBEAMPATHLDD_H__B58A0180_747E_45EE_8DB9_68EF4F48D6E2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "resource.h"
#include "easydriller.h"
#include "..\model\BeamPathINIFile.h"
#include "..\model\DBeampathINI.h"
#include "GridCtrl.h"



#define		TABLE0  0
#define		TABLE1  1
#define		TABLE2  2
#define		TABLE3  3
#define		TABLE4  4


#define		TABLE0_COLUMN_COUNT 3
#define		TABLE1_COLUMN_COUNT 7
#define		TABLE2_COLUMN_COUNT 7
#define		TABLE3_COLUMN_COUNT 7
#define		TABLE4_COLUMN_COUNT 11

#define		COLUMNWIDTH  13	// �÷��� �ѱ��ڴ� �Ҵ�Ǵ� ������ ���� 


#define		TABLETEXT_COLOR		RGB(0,0,0)
#define		TABLE1_COLOR		RGB(255,255,255)
#define		TABLE2_COLOR		RGB(230,230,230)
#define		TABLE3_COLOR		RGB(220,220,220)
#define		TABLE4_COLOR		RGB(210,210,210)
#define		TABLE5_COLOR		RGB(200,200,200) 


class CPaneSysSetupBeamPathLDD : public CFormView
{
protected:
	CPaneSysSetupBeamPathLDD();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupBeamPathLDD)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupBeamPathPusan1)
	enum { IDD = IDD_DLG_SYS_SETUP_BEAMPATH_LDD };
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	//}}AFX_DATA

// Attributes
public:
	UEasyButtonEx	m_chkInfo;
	UEasyButtonEx	m_chkBeamPath;
	UEasyButtonEx	m_chkPowerOffset;
	UEasyButtonEx	m_chkPowerCompensation;
	UEasyButtonEx	m_chkScannerFact;
	UEasyButtonEx   m_ChkSubBox[5];
	UEasyButtonEx	m_btnRefresh;
	UEasyButtonEx   m_btnAdd;
	UEasyButtonEx	m_btnDel;
	UEasyButtonEx   m_btnUp;
	UEasyButtonEx	m_btnDown;

	BOOL			m_bInfoCheck;
	BOOL			m_bBeamPathCheck;
	BOOL			m_bPowerOffsetCheck;
	BOOL			m_bpowerCompensationCheck;
	BOOL			m_bScannerFactCheck;

	BOOL			m_bCheckBox[5];
	CListCtrl		m_list;

	CEdit			m_editwnd;
	CPoint			m_posClicked;		// ����Ʈ �� Ŭ���� �� ��� 
	CColorEdit		m_edtFixMask;


	int				m_nRepeatCount;


	BOOL			m_bClickList;
	BOOL			m_ClickID;


	SBEAMPATH		m_sBeamPath;
	SBEAMPATH		m_sTempBeamPath;

	int				 m_IdNoToAddDel;

	int m_nPolarityMode;
	BOOL m_bUseTopHatMode;
	CGridCtrl m_Grid;
	int				m_nColumnCount;
	
	CString strTable0[TABLE0_COLUMN_COUNT];// = {"No", "Name", "MSize"};
	CString strTable1[TABLE1_COLUMN_COUNT];//= {"B1","B2","M1","Z1","Z2","UseTopHat","LaserPath","Voltage1(%)","Voltage2(%)","Asc File"};
	CString strTable2[TABLE2_COLUMN_COUNT];// = {"Duty","Aom Delay","Aom Duty", "DualAom1","DualAom2", "VolOffset(%)","VolOffset(%)" };
	CString strTable3[TABLE3_COLUMN_COUNT];// = {"Frequency","Duty","Aom Delay","Aom Duty","Target Min","Target Max","Duty Offset"};
	CString strTable4[TABLE4_COLUMN_COUNT];// ={"Duty","Aom Delay","Aom Duty","Shot","Vision","Size","Tol.","Ratio","Polarity","Contrast","Brightness"};

// Attributes
protected :
	CFont		m_fntStatic;
	CFont		m_fntEdit;
	CFont		m_fntBtn;
// Operations
public:
	void GetCurrentASC();
	BOOL CheckApply();

	int m_nVisionMode;
	int GetVisionMode();
	void SetVisionMode(int nMode);
	void CheckAnyDoPrework();

	void SetPolarityMode(int nMode);
	int GetPolarityMode();
	BOOL GetUseTopHatMode();
	void SetUseTopHatMode(BOOL bMode);
	int GetShowBoxMode(int nXPos);
	void SetCurrentScrollPos(int xPos, int yPos);
	void OnCheckDown();
	void OnCheckUp();
	void CopyFromTempToOriginal();
	void CopyFromOriginaltoTemp(int nSelectNo, int RepeatNo);
	void InitDataStruct();

	int GetIdNoToAddDel();
	void SetIdNoToAddDel(int nIdYPos);

	int GetListRowIndexCount();
	BOOL MoveFocus(int nXpos, int nYpos,int nMoveType);
	int GetColumnSize(int nStrlen);
	void OnCheckDel();
	void OnCheckAdd();
	
	void GetBeamPath(SBEAMPATH* pBeamPath);
	CString GetChangeValueStr();
	void FillTable4Data(int x, int y, CString str);
	void FillTable0Data(int x, int y, CString str);
	void FillTable3Data(int x, int y, CString str);
	void FillTable2Data(int x, int y, CString str);
	void FillTable1Data(int x, int y, CString str);
	void ListUpdate(CPoint ClickedPos, CString str);
	void OnKillfocusEditGrid();
	void InsertListValue(LV_ITEM lvitem,int startNo, int TableNo, int ColCount);
	void InsertGridValue(GV_ITEM Gvitem,int startNo, int TableNo, int ColCount);
	void SetBeamPath(SBEAMPATH sBeamPath);
	void InsertListComumn(int startNo, int TableNo);
	void DeleteList();
	void SetDrawMember(int listcount);
	int  GetListIndex();
	void InitListControl();
	void OnCheckRefresh();
	void OnCheckScannerFact();
	void OnCheckPowerCompensation();
	void OnCheckPowerOffset();
	void OnCheckBeamPath();
	void InitBtnControl();
	void InitStaticControl();
	void InitEditControl();
	void InitGrid();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupBeamPathPusan1)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupBeamPathLDD();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupBeamPath)

	afx_msg void OnClickList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//afx_msg void OnCustomdrawList(NMHDR* pNMHDR, LRESULT * pResult);
	afx_msg void OnNMCustomdrawListTest(NMHDR *pNMHDR, LRESULT *pResult);
		//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_PANESYSSETUPBEAMPATHLDD_H__B58A0180_747E_45EE_8DB9_68EF4F48D6E2__INCLUDED_)

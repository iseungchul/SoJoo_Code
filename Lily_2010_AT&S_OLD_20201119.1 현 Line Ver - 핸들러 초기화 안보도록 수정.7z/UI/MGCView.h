#if !defined(AFX_MGCVIEW_H__1076D730_C841_4EAA_9810_58D0F8AC498A__INCLUDED_)
#define AFX_MGCVIEW_H__1076D730_C841_4EAA_9810_58D0F8AC498A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MGCView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMGCView view

class CMGCView : public CScrollView
{
protected:
	CMGCView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMGCView)

// Attributes
public:

// Operations
public:
	BOOL SaveTestFile(const CString &strTestFilePath);
	void getSelectedNodeInAxis(int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide);
	void ReadTempFile(const CString &strTempFilePath);
	void CombineAscFileDataAndDeltaValue();
	void SaveTempFile(const CString &strTempFilePath);
	void PointZoomAll();
	int getNumberOfSelectedNode();
	void ClearNodeChanged();
	void ClearAscFileData();
	BOOL getModified();
	void setModified(BOOL bIsModified);
	BOOL SaveAscFile(const CString &strAscFilePath);
	BOOL CheckDeltaLimit(int dXDeltaInLsb, int dYDeltaInLsb);
	BOOL ReadAscFile(const CString &strAscFilePath);
	void ClearDeltaValue();
	void CalculateDelta(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY);
	void SetDrawDelta(BOOL bDrawDelta);
	void PointZoomOut();
	void PointZoomIn();
	void SetField(double dFieldSizeX, double dFieldSizeY);
	void Invert();
	void UnselectAll();
	void SelectAll();
	void ClearNodeSelected();
	void SetGrid(int nGrid);
	void ChangeSelectedNode(RECT rectSelectedInField, RECT rectSelectedInAxis);
	void SetAxis(int nAxis);
	static BOOL RegisterMGCViewClass(HINSTANCE hInstance);
	static LRESULT CALLBACK WindowProcedure(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam);

	int m_nYAscFileData[65][65];
	int m_nXAscFileData[65][65];
	int m_nXMin;
	int m_nXMax;
	int m_nYMin;
	int m_nYMax;
	int m_nDistanceMax;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMGCView)
	public:
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual void OnInitialUpdate();     // first time after construct
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMGCView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CMGCView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void DrawDelta_Left_270(CDC *pDC);
	void DrawDelta_Left_180(CDC *pDC);
	void DrawDelta_Left_90(CDC *pDC);
	void DrawDelta_Left_0(CDC *pDC);
	void CalculateDelta_Left_270(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY);
	void CalculateDelta_Left_180(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY);
	void CalculateDelta_Left_90(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY);
	void CalculateDelta_Left_0(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY);
	BOOL CheckDeltaLimit_Left_270(int dXDeltaInLsb, int dYDeltaInLsb);
	BOOL CheckDeltaLimit_Left_180(int dXDeltaInLsb, int dYDeltaInLsb);
	BOOL CheckDeltaLimit_Left_90(int dXDeltaInLsb, int dYDeltaInLsb);
	BOOL CheckDeltaLimit_Left_0(int dXDeltaInLsb, int dYDeltaInLsb);
	void SelectPointNode_Left_270();
	void SelectPointNode_Left_180();
	void SelectPointNode_Left_90();
	void SelectPointNode_Left_0();
	void SelectNode_Left_270();
	void SelectNode_Left_180();
	void SelectNode_Left_90();
	void SelectNode_Left_0();
	void DrawBox_Left_270(CDC *pDC);
	void DrawBox_Left_180(CDC *pDC);
	void DrawBox_Left_90(CDC *pDC);
	void FindField_Left_270(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide);
	void FindField_Left_180(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide);
	void FindField_Left_90(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide);
	void DrawBox_Left_0(CDC *pDC);
	void FindField_Left_0(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide);
	void DrawNode_Left_270(CDC *pDC);
	void DrawNode_Left_180(CDC *pDC);
	void DrawNode_Left_90(CDC *pDC);
	void DrawNode_Left_0(CDC *pDC);
	void BilinearInterpolation(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY, int nXIndexStart, int nXIndexEnd, int nYIndexStart, int nYIndexEnd);
	void SelectPointNode_270();
	void SelectPointNode_180();
	void SelectPointNode_90();
	void SelectPointNode_0();
	void SelectPointNode();
	BOOL m_bIsModified;
	BOOL CheckDeltaLimitY(int nIndexX, int nIndexY, int dXDeltaInLsb, int dYDeltaInLsb, int nGridIterY);
	BOOL CheckDeltaLimitX(int nIndexX, int nIndexY, int dXDeltaInLsb, int dYDeltaInLsb, int nGridIterX);
	BOOL CheckDeltaLimit_270(int dXDeltaInLsb, int dYDeltaInLsb);
	BOOL CheckDeltaLimit_180(int dXDeltaInLsb, int dYDeltaInLsb);
	BOOL CheckDeltaLimit_90(int dXDeltaInLsb, int dYDeltaInLsb);
	BOOL CheckDeltaLimit_0(int dXDeltaInLsb, int dYDeltaInLsb);
	void FindDivideAndRemainder(int &nDivideX,int &nRemainderX, int &nDivideY, int &nRemainderY, int nXStart, int nXEnd, int nYStart, int nYEnd);
	void CalculateDelta_270(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY);
	void CalculateDelta_180(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY);
	void CalculateDelta_90(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY);
	void CalculateDelta_0(int nMaxDeltaInLsbX, int nMaxDeltaInLsbY);
	void DrawDelta_270(CDC *pDC);
	void DrawDelta_180(CDC *pDC);
	void DrawDelta_90(CDC *pDC);
	void DrawDelta_0(CDC *pDC);
	SIZE m_sizeDelta[65][65];
	void DrawDelta(CDC *pDC);
	BOOL m_bDrawDelta;
	void FindField_270(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide);
	void FindField_180(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide);
	void FindField_90(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide);
	void FindField_0(CDC *pDC, CRect &rectField, int &nXStart, int &nYStart, int &nXEnd, int &nYEnd, int &nGrid, int &nGridIterX, int &nGridIterY, int &nDivide);
	POINT m_ptZoomPoint;
	double m_dFieldSizeX;
	double m_dFieldSizeY;
	void SelectNode_270();
	void SelectNode_180();
	void SelectNode_90();
	void SelectNode_0();
	BOOL m_bNodeChanged[65][65]; // Axis ��ǥ�� �������� �Ѵ�. ��: X Index ��: Y Index
	BOOL m_bNodeSelected[65][65]; // Axis ��ǥ�� �������� �Ѵ�. ��: X Index ��: Y Index
	void SelectNode();
	POINT m_ptDragEnd;
	POINT m_ptDragStart;
	void DrawSelectionRect(POINT ptLeftTop, POINT ptRightBottom);
	BOOL m_bZoomMode;
	BOOL m_bPointSelectionMode;
	BOOL m_bSelectionMode;
	COLORREF m_clrDeltaColor;
	COLORREF m_clrBoxColorChanged;
	COLORREF m_clrBoxColorSelected;
	COLORREF m_clrBoxColorNormal;
	COLORREF m_clrNodeColor;
	void DrawBox_270(CDC *pDC);
	void DrawBox_180(CDC *pDC);
	void DrawBox_90(CDC *pDC);
	void DrawBox_0(CDC *pDC);
	int m_nGrid;
	double m_dZoomFactor;
	void DrawNode_270(CDC *pDC);
	void DrawNode_180(CDC *pDC);
	void DrawNode_90(CDC *pDC);
	void DrawNode_0(CDC *pDC);
	const int c_nOffset;
	void DrawNode(CDC *pDC);
	CRect m_rectSelectedInAxis;
	CRect m_rectSelectedInField;
	int m_nAxis;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MGCVIEW_H__1076D730_C841_4EAA_9810_58D0F8AC498A__INCLUDED_)

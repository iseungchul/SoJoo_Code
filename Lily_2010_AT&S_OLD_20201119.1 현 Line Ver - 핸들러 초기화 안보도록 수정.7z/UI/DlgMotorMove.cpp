// DlgMotorMove.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgMotorMove.h"
#include "..\device\HDeviceFactory.h"
#include "..\device\DeviceMotor.h"
#include "..\device\HMotor.h"
#include "..\alarmmsg.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\model\DSystemINI.h"
#include "..\MODEL\DProcessINI.h"
#include "..\EasyDrillerDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgMotorMove dialog


CDlgMotorMove::CDlgMotorMove(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgMotorMove::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgMotorMove)
		// NOTE: the ClassWizard will add member initialization here
	m_bTargetX = FALSE;
	m_bTargetY = FALSE;
	m_bTargetZ1 = FALSE;
	m_bTargetZ2 = FALSE;
	m_bTargetC = FALSE;
	m_bTargetC2 = FALSE;
	m_bTargetM = FALSE;
	m_bTargetM2 = FALSE;
	m_bTargetM3 = FALSE;
	m_bTargetA1 = FALSE;
	m_bTargetA2 = FALSE;
	m_bMotor = FALSE;
	m_bSuction1 = FALSE;
	m_bSuction2 = FALSE;
	m_bClamp1 = FALSE;
	m_bClamp2 = FALSE;
	m_bExtend = TRUE;
	m_nAbs = 0;
	m_nTimer1 = -1;

	//}}AFX_DATA_INIT
}


void CDlgMotorMove::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgMotorMove)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_STATIC_POS_Y_VAL, m_stcPosY);
	DDX_Control(pDX, IDC_STATIC_POS_X_VAL, m_stcPosX);
	DDX_Control(pDX, IDC_STATIC_POS_A_VAL1, m_stcPosA1);
	DDX_Control(pDX, IDC_STATIC_POS_A_VAL2, m_stcPosA2);
	DDX_Control(pDX, IDC_STATIC_POS_COLLIMATOR_VAL, m_stcPosC);
	DDX_Control(pDX, IDC_STATIC_POS_COLLIMATOR_VAL2, m_stcPosC2);
	DDX_Control(pDX, IDC_STATIC_POS_MASK_VAL, m_stcPosM);
	DDX_Control(pDX, IDC_STATIC_POS_MASK_VAL2, m_stcPosM2);
	DDX_Control(pDX, IDC_STATIC_POS_MASK_VAL3, m_stcPosM3);
	DDX_Control(pDX, IDC_STATIC_POS_Z2_VAL, m_stcPosZ2);
	DDX_Control(pDX, IDC_STATIC_POS_Z1_VAL, m_stcPosZ1);
	DDX_Control(pDX, IDC_STATIC_POS_Y_VAL, m_stcPosY);
	DDX_Control(pDX, IDC_STATIC_POS_X_VAL, m_stcPosX);
	DDX_Control(pDX, IDC_EDIT_TARGET_A1, m_edtTargetA1);
	DDX_Control(pDX, IDC_EDIT_TARGET_A2, m_edtTargetA2);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z2, m_edtTargetZ2);
	DDX_Control(pDX, IDC_EDIT_TARGET_Z1, m_edtTargetZ1);
	DDX_Control(pDX, IDC_EDIT_TARGET_Y, m_edtTargetY);
	DDX_Control(pDX, IDC_EDIT_TARGET_M, m_edtTargetM);
	DDX_Control(pDX, IDC_EDIT_TARGET_C, m_edtTargetC);
	DDX_Control(pDX, IDC_EDIT_TARGET_X, m_edtTargetX);
	DDX_Control(pDX, IDC_EDIT_TARGET_M2, m_edtTargetM2);
	DDX_Control(pDX, IDC_EDIT_TARGET_M3, m_edtTargetM3);
	DDX_Control(pDX, IDC_EDIT_TARGET_C3, m_edtTargetC2);
	DDX_Check(pDX, IDC_CHECK_TARGET_X, m_bTargetX);
	DDX_Check(pDX, IDC_CHECK_TARGET_Y, m_bTargetY);
	DDX_Check(pDX, IDC_CHECK_TARGET_Z1, m_bTargetZ1);
	DDX_Check(pDX, IDC_CHECK_TARGET_Z2, m_bTargetZ2);
	DDX_Check(pDX, IDC_CHECK_TARGET_C, m_bTargetC);
	DDX_Check(pDX, IDC_CHECK_TARGET_C2, m_bTargetC2);
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK, m_bTargetM);
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK2, m_bTargetM2);
	DDX_Check(pDX, IDC_CHECK_TARGET_MASK3, m_bTargetM3);
	DDX_Check(pDX, IDC_CHECK_TARGET_A1, m_bTargetA1);
	DDX_Check(pDX, IDC_CHECK_TARGET_A2, m_bTargetA2);
	DDX_Control(pDX, IDC_BUTTON_MOTOR_HOMING, m_btnMotorHoming);
	DDX_Control(pDX, IDC_BUTTON_MOVE, m_btnMove);
	DDX_Radio(pDX, IDC_RADIO_ABS, m_nAbs);
	DDX_Control(pDX, IDC_CHECK_MOTOR, m_chkVacuumMotorOn);
	DDX_Control(pDX, IDC_CHECK_MASTER_ON, m_chkVacuum1);
	DDX_Control(pDX, IDC_CHECK_SLAVE_ON, m_chkVacuum2);
	DDX_Control(pDX, IDC_CHECK_TABLE_CLAMP1, m_chkClamp1);
	DDX_Control(pDX, IDC_CHECK_TABLE_CLAMP2, m_chkClamp2);
	DDX_Control(pDX, IDC_BUTTON_POS_LOADING, m_btnLoad);
	DDX_Control(pDX, IDC_BUTTON_POS_UNLOADING, m_btnUnload);
	DDX_Control(pDX, IDC_BUTTON_MANUAL_SCAL_POSITION_MOVE, m_btnManualPos);
	DDX_Control(pDX, IDC_BUTTON_ALL_REJECT, m_btnReject);
	DDX_Control(pDX, IDC_BUTTON_EXTEND, m_btnExtend);
	DDX_Control(pDX, IDC_BUTTON_FID_NEAR1, m_btnNear1);
	DDX_Control(pDX, IDC_BUTTON_FID_NEAR2, m_btnNear2);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgMotorMove, CDialog)
	//{{AFX_MSG_MAP(CDlgMotorMove)
	ON_BN_CLICKED(IDC_BUTTON_MOVE, OnButtonMove)
	ON_BN_CLICKED(IDC_BUTTON_MOTOR_HOMING, OnButtonHoming)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CHECK_MOTOR, &CDlgMotorMove::OnBnClickedCheckMotor)
	ON_BN_CLICKED(IDC_CHECK_MASTER_ON, &CDlgMotorMove::OnBnClickedCheckMasterOn)
	ON_BN_CLICKED(IDC_CHECK_SLAVE_ON, &CDlgMotorMove::OnBnClickedCheckSlaveOn)
	ON_BN_CLICKED(IDC_CHECK_TABLE_CLAMP1, &CDlgMotorMove::OnBnClickedCheckTableClamp1)
	ON_BN_CLICKED(IDC_CHECK_TABLE_CLAMP2, &CDlgMotorMove::OnBnClickedCheckTableClamp2)
	ON_BN_CLICKED(IDC_BUTTON_POS_LOADING, &CDlgMotorMove::OnBnClickedButtonPosLoading)
	ON_BN_CLICKED(IDC_BUTTON_POS_UNLOADING, &CDlgMotorMove::OnBnClickedButtonPosUnloading)
	ON_BN_CLICKED(IDC_BUTTON_MANUAL_SCAL_POSITION_MOVE, &CDlgMotorMove::OnBnClickedButtonManualScalPositionMove)
	ON_BN_CLICKED(IDC_BUTTON_ALL_REJECT, &CDlgMotorMove::OnBnClickedButtonAllReject)
	ON_BN_CLICKED(IDC_BUTTON_EXTEND, &CDlgMotorMove::OnBnClickedButtonExtend)
	ON_BN_CLICKED(IDC_BUTTON_FID_NEAR1, &CDlgMotorMove::OnBnClickedButtonNear1)
	ON_BN_CLICKED(IDC_BUTTON_FID_NEAR2, &CDlgMotorMove::OnBnClickedButtonNear2)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgMotorMove message handlers

BOOL CDlgMotorMove::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitEditControl();
	InitBtnControl();
	InitStaticControl();


   BOOL bShow = ::AfxGetMainWnd()->SendMessage(UM_IS_SHOW_EASY_TEST_WINDOW);

   if(!bShow)
   {
	CRect rect;
	GetWindowRect(rect);
	m_siExtendSize = rect.Size();

	GetDlgItem(IDC_STATIC_NORMAL)->GetWindowRect(rect);
	m_siNormalSize.cx = rect.right + 10;
	m_siNormalSize.cy = m_siExtendSize.cy;
	OnBnClickedButtonExtend();

   }

	m_bDisplayOn = FALSE;
	m_nTimer1 = SetTimer(100, 500, NULL);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CDlgMotorMove::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(130, "Arial Bold");

	// Target X
	m_edtTargetX.SetFont( &m_fntEdit );
	m_edtTargetX.SetReceivedFlag( 3 );
	m_edtTargetX.SetWindowText( _T("0.0") );
	
	// Target Y
	m_edtTargetY.SetFont( &m_fntEdit );
	m_edtTargetY.SetReceivedFlag( 3 );
	m_edtTargetY.SetWindowText( _T("0.0") );
	
	// Target Z1
	m_edtTargetZ1.SetFont( &m_fntEdit );
	m_edtTargetZ1.SetReceivedFlag( 3 );
	m_edtTargetZ1.SetWindowText( _T("0.0") );
	
	// Target Z2
	m_edtTargetZ2.SetFont( &m_fntEdit );
	m_edtTargetZ2.SetReceivedFlag( 3 );
	m_edtTargetZ2.SetWindowText( _T("0.0") );
	
	// Target M
	m_edtTargetM.SetFont( &m_fntEdit );
	m_edtTargetM.SetReceivedFlag( 3 );
	m_edtTargetM.SetWindowText( _T("0.0") );
	

	// Target A
	m_edtTargetA1.SetFont( &m_fntEdit );
	m_edtTargetA1.SetReceivedFlag( 3 );
	m_edtTargetA1.SetWindowText( _T("0.0") );

	// Target C
	m_edtTargetC.SetFont( &m_fntEdit );
	m_edtTargetC.SetReceivedFlag( 3 );
	m_edtTargetC.SetWindowText( _T("0.0") );
	
	// Target M'2
	m_edtTargetM2.SetFont( &m_fntEdit );
	m_edtTargetM2.SetReceivedFlag( 3 );
	m_edtTargetM2.SetWindowText( _T("0.0") );

	// Target M'3
	m_edtTargetM3.SetFont( &m_fntEdit );
	m_edtTargetM3.SetReceivedFlag( 3 );
	m_edtTargetM3.SetWindowText( _T("0.0") );

	// Target C'2
	m_edtTargetC2.SetFont( &m_fntEdit );
	m_edtTargetC2.SetReceivedFlag( 3 );
	m_edtTargetC2.SetWindowText( _T("0.0") );

	// Target A'2
	m_edtTargetA2.SetFont( &m_fntEdit );
	m_edtTargetA2.SetReceivedFlag( 3 );
	m_edtTargetA2.SetWindowText( _T("0.0") );


#ifdef __SERVO_MOTOR__
	m_edtTargetM2.ShowWindow(SW_SHOW);
	m_edtTargetM3.ShowWindow(SW_SHOW);
#else
	m_edtTargetM2.ShowWindow(SW_HIDE);
	m_edtTargetM3.ShowWindow(SW_HIDE);
#endif

#ifdef __KUNSAN_SAMSUNG_LARGE__
	m_edtTargetA2.ShowWindow(SW_SHOW);
	m_edtTargetA1.ShowWindow(SW_SHOW);
#else
	m_edtTargetA2.ShowWindow(SW_HIDE);
	m_edtTargetA1.ShowWindow(SW_HIDE);
#endif

}

void CDlgMotorMove::InitStaticControl()
{
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	// Position
	GetDlgItem(IDC_STATIC_TARGET_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOTOR_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOTOR_CONTROL)->SetFont( &m_fntStatic );

	m_stcPosX.SetFont( &m_fntStatic );
	m_stcPosX.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosX.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_Y)->SetFont( &m_fntStatic );
	m_stcPosY.SetFont( &m_fntStatic );
	m_stcPosY.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosY.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_Z1)->SetFont( &m_fntStatic );
	m_stcPosZ1.SetFont( &m_fntStatic );
	m_stcPosZ1.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosZ1.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_Z2)->SetFont( &m_fntStatic );
	m_stcPosZ2.SetFont( &m_fntStatic );
	m_stcPosZ2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosZ2.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_MASK)->SetFont( &m_fntStatic );
	m_stcPosM.SetFont( &m_fntStatic );
	m_stcPosM.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_COLLIMATOR)->SetFont( &m_fntStatic );
	m_stcPosM2.SetFont( &m_fntStatic );
	m_stcPosM2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM2.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_MASK2)->SetFont( &m_fntStatic );
	m_stcPosM3.SetFont( &m_fntStatic );
	m_stcPosM3.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM3.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_MASK3)->SetFont( &m_fntStatic );
	m_stcPosC.SetFont( &m_fntStatic );
	m_stcPosC.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosC.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_COLLIMATOR2)->SetFont( &m_fntStatic );
	m_stcPosC2.SetFont( &m_fntStatic );
	m_stcPosC2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosC2.SetBackColor( VALUE_BACK_COLOR );

	GetDlgItem(IDC_STATIC_POS_A1)->SetFont( &m_fntStatic );
	m_stcPosA1.SetFont( &m_fntStatic );
	m_stcPosA1.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosA1.SetBackColor( VALUE_BACK_COLOR );
	GetDlgItem(IDC_STATIC_POS_A3)->SetFont( &m_fntStatic );
	m_stcPosA2.SetFont( &m_fntStatic );
	m_stcPosA2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosA2.SetBackColor( VALUE_BACK_COLOR );

#ifdef __SERVO_MOTOR__
	m_stcPosM2.ShowWindow(SW_SHOW);
	m_stcPosM3.ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_POS_MASK2)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_POS_MASK3)->ShowWindow(SW_SHOW);
#else
	m_stcPosM2.ShowWindow(SW_HIDE);
	m_stcPosM3.ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_MASK2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_MASK3)->ShowWindow(SW_HIDE);
#endif
#ifdef __KUNSAN_SAMSUNG_LARGE__
	m_stcPosA1.ShowWindow(SW_SHOW);
	m_stcPosA2.ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_POS_A1)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_STATIC_POS_A3)->ShowWindow(SW_SHOW);
#else
	m_stcPosA1.ShowWindow(SW_HIDE);
	m_stcPosA2.ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_A1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_POS_A3)->ShowWindow(SW_HIDE);
#endif
}

void CDlgMotorMove::InitBtnControl()
{
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnMove.SetFont( &m_fntBtn );
	m_btnMove.SetFlat( FALSE );
	m_btnMove.EnableBallonToolTip();
	m_btnMove.SetToolTipText( _T("Move Tagerget Position") );
	m_btnMove.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMove.SetBtnCursor(IDC_HAND_1);

	m_btnMotorHoming.SetFont( &m_fntBtn );
	m_btnMotorHoming.SetFlat( FALSE );
	m_btnMotorHoming.EnableBallonToolTip();
	m_btnMotorHoming.SetToolTipText( _T("Move Homing Position") );
	m_btnMotorHoming.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMotorHoming.SetBtnCursor(IDC_HAND_1);

	m_btnLoad.SetFont( &m_fntBtn );
	m_btnLoad.SetFlat( FALSE );
	m_btnLoad.EnableBallonToolTip();
	m_btnLoad.SetToolTipText( _T("Move Load Pos") );
	m_btnLoad.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoad.SetBtnCursor(IDC_HAND_1);

	m_btnUnload.SetFont( &m_fntBtn );
	m_btnUnload.SetFlat( FALSE );
	m_btnUnload.EnableBallonToolTip();
	m_btnUnload.SetToolTipText( _T("Move Unload Pos") );
	m_btnUnload.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnload.SetBtnCursor(IDC_HAND_1);

	m_btnManualPos.SetFont( &m_fntBtn );
	m_btnManualPos.SetFlat( FALSE );
	m_btnManualPos.EnableBallonToolTip();
	m_btnManualPos.SetToolTipText( _T("Move Manual S.Cal Pos") );
	m_btnManualPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnManualPos.SetBtnCursor(IDC_HAND_1);

	m_btnReject.SetFont( &m_fntBtn );
	m_btnReject.SetFlat( FALSE );
	m_btnReject.EnableBallonToolTip();
	m_btnReject.SetToolTipText( _T("Reject All Motor") );
	m_btnReject.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnReject.SetBtnCursor(IDC_HAND_1);

	m_btnNear1.SetFont( &m_fntBtn );
	m_btnNear1.SetFlat( FALSE );
	m_btnNear1.EnableBallonToolTip();
	m_btnNear1.SetToolTipText( _T("Move to Fid Near Pos1") );
	m_btnNear1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnNear1.SetBtnCursor(IDC_HAND_1);

	m_btnNear2.SetFont( &m_fntBtn );
	m_btnNear2.SetFlat( FALSE );
	m_btnNear2.EnableBallonToolTip();
	m_btnNear2.SetToolTipText( _T("Move to Fid Near Pos2") );
	m_btnNear2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnNear2.SetBtnCursor(IDC_HAND_1);

	m_chkVacuumMotorOn.SetFont( &m_fntBtn );
	m_chkVacuumMotorOn.SetImageOrg( 10, 3 );
	m_chkVacuumMotorOn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkVacuumMotorOn.EnableBallonToolTip();
	m_chkVacuumMotorOn.SetToolTipText( _T("Vacuum Motor On/Off") );
	m_chkVacuumMotorOn.SetBtnCursor(IDC_HAND_1);

	m_chkVacuum1.SetFont( &m_fntBtn );
	m_chkVacuum1.SetImageOrg( 10, 3 );
	m_chkVacuum1.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkVacuum1.EnableBallonToolTip();
	m_chkVacuum1.SetToolTipText( _T("Master Vacuum On/Off") );
	m_chkVacuum1.SetBtnCursor(IDC_HAND_1);

	m_chkVacuum2.SetFont( &m_fntBtn );
	m_chkVacuum2.SetImageOrg( 10, 3 );
	m_chkVacuum2.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkVacuum2.EnableBallonToolTip();
	m_chkVacuum2.SetToolTipText( _T("Slave Vacuum On/Off") );
	m_chkVacuum2.SetBtnCursor(IDC_HAND_1);

	m_chkClamp1.SetFont( &m_fntBtn );
	m_chkClamp1.SetImageOrg( 10, 3 );
	m_chkClamp1.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkClamp1.EnableBallonToolTip();
	m_chkClamp1.SetToolTipText( _T("Master Clamp") );
	m_chkClamp1.SetBtnCursor(IDC_HAND_1);

	m_chkClamp2.SetFont( &m_fntBtn );
	m_chkClamp2.SetImageOrg( 10, 3 );
	m_chkClamp2.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkClamp2.EnableBallonToolTip();
	m_chkClamp2.SetToolTipText( _T("Master Clamp") );
	m_chkClamp2.SetBtnCursor(IDC_HAND_1);

#ifdef __SERVO_MOTOR__
	GetDlgItem(IDC_CHECK_TARGET_MASK2)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_CHECK_TARGET_MASK3)->ShowWindow(SW_SHOW);
#else
	GetDlgItem(IDC_CHECK_TARGET_MASK2)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_TARGET_MASK3)->ShowWindow(SW_HIDE);
#endif

#ifdef __KUNSAN_SAMSUNG_LARGE__
	GetDlgItem(IDC_CHECK_TARGET_A1)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_CHECK_TARGET_A2)->ShowWindow(SW_SHOW);
#else
	GetDlgItem(IDC_CHECK_TARGET_A1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_CHECK_TARGET_A2)->ShowWindow(SW_HIDE);
#endif

}
void CDlgMotorMove::OnButtonMove()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); // 110603
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	UpdateData(TRUE);
	BOOL bAbs = !m_nAbs;
#ifndef __SERVO_MOTOR__
	if(!m_bTargetX && !m_bTargetY && !m_bTargetZ1 && !m_bTargetZ2 && !m_bTargetM && !m_bTargetM2 && !m_bTargetC && !m_bTargetC2)		//2011519
		return;
#else
	if(!m_bTargetX && !m_bTargetY && !m_bTargetZ1 && !m_bTargetZ2 && !m_bTargetM && !m_bTargetM2 && !m_bTargetM3 && !m_bTargetC && !m_bTargetC2&& !m_bTargetA1 && !m_bTargetA2)		//2011519
		return;
#endif

	EnableAllBtn( FALSE );

	CString strData;
	double dTemp = 0;


	// X
	m_edtTargetX.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosX = GetMovePos( AXIS_X, dTemp, bAbs, m_bTargetX );

	// Y
	m_edtTargetY.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosY = GetMovePos( AXIS_Y, dTemp, bAbs, m_bTargetY );

	// Z1
	m_edtTargetZ1.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ1 = GetMovePos( AXIS_Z1, dTemp, bAbs, m_bTargetZ1 );

	// Z2
	m_edtTargetZ2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosZ2 = GetMovePos( AXIS_Z2, dTemp, bAbs, m_bTargetZ2 );

	// M
	m_edtTargetM.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM = GetMovePos( AXIS_M, dTemp, bAbs, m_bTargetM );

	// M2
	m_edtTargetM2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM2 = GetMovePos( AXIS_M2, dTemp, bAbs, m_bTargetM2 );

	// M3
	m_edtTargetM3.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosM3 = GetMovePos( AXIS_M2, dTemp, bAbs, m_bTargetM3 );

	// C
	m_edtTargetC.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC = GetMovePos( AXIS_C, dTemp, bAbs, m_bTargetC );
	
	// C2
	m_edtTargetC2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosC2 = GetMovePos( AXIS_C2, dTemp, bAbs, m_bTargetC2 );

	// A
	m_edtTargetA1.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosA = GetMovePos( AXIS_A1, dTemp, bAbs, m_bTargetA1 );

	// A2
	m_edtTargetA2.GetWindowText( strData );
	dTemp = atof( (LPSTR)(LPCTSTR)strData );
	double dPosA2 = GetMovePos( AXIS_A2, dTemp, bAbs, m_bTargetA2 );


	BOOL bRet = pMotor->MotorMoveXYZMCA3(dPosX, dPosY, dPosZ1, dPosZ2, dPosM, dPosM2, dPosM3, dPosC, dPosC2, dPosA, dPosA2, TRUE, FALSE, FALSE,TRUE);

	if(bRet)
	{
		bRet = pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_M2 + IND_M3 + IND_C1 + IND_C2 + IND_A2 + IND_A1);

	}

	if(!bRet)
	{
		ErrMessage(_T("Move Fail"));
	}
	EnableAllBtn(TRUE);

}

void CDlgMotorMove::EnableAllBtn(BOOL bUse)
{
	m_edtTargetZ2.EnableWindow(bUse);
	m_edtTargetZ1.EnableWindow(bUse);
	m_edtTargetY.EnableWindow(bUse);
	m_edtTargetM.EnableWindow(bUse);
	m_edtTargetC.EnableWindow(bUse);
	m_edtTargetX.EnableWindow(bUse);
	m_edtTargetM2.EnableWindow(bUse);
	m_edtTargetM3.EnableWindow(bUse);
	m_edtTargetC2.EnableWindow(bUse);

	GetDlgItem(IDC_CHECK_TARGET_X)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_Y)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_Z1)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_Z2)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_MASK)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_MASK2)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_MASK3)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_C)->EnableWindow( bUse );
	GetDlgItem(IDC_CHECK_TARGET_C2)->EnableWindow( bUse );

	m_chkVacuumMotorOn.EnableWindow(bUse);
	m_chkVacuum1.EnableWindow(bUse);
	m_chkVacuum2.EnableWindow(bUse);
	m_chkClamp1.EnableWindow(bUse);
	m_chkClamp2.EnableWindow(bUse);

	m_btnLoad.EnableWindow(bUse);
	m_btnUnload.EnableWindow(bUse);
	m_btnManualPos.EnableWindow(bUse);
	m_btnReject.EnableWindow(bUse);

}

double CDlgMotorMove::GetMovePos(int nAxisNo, double dMovePos, BOOL bAbs, BOOL bUse)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( FALSE == bUse )
		return pMotor->GetPosition( nAxisNo );
	
	double dPos = 0.;
	
	if( FALSE == bAbs ) // Relative Movement
	{
		dPos = dMovePos + pMotor->GetPosition( nAxisNo );
	}
	else // ABS Movement
		dPos = dMovePos;
	
	return dPos;
}
void CDlgMotorMove::OnButtonHoming()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error")); 
		return;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	pMotor->SetOrigin();

	BOOL bInOrigin = FALSE;
	BOOL bInPosition = FALSE;
	
	for( int i = 0 ; i < 600 ; i++ )
	{
#ifndef __NOUSE_MP920__
		::Sleep(100);
#endif
		
		bInOrigin = pMotor->IsInOrigin( -1, FALSE );
		
		if( bInOrigin ) 
			break;
		
		if( 599 == i )
		{
			pMotor->IsInOrigin(-1);
		}
	}
}

BOOL CDlgMotorMove::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_nTimer1 != -1)
	{
		KillTimer(100);
		m_nTimer1 = -1;
	}

	return CDialog::DestroyWindow();
}

void CDlgMotorMove::SetDisplayOn(BOOL bOn)
{
	m_bDisplayOn = bOn;
}
void CDlgMotorMove::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent == m_nTimer1)
	{
		if(m_bDisplayOn)
			DispStatus();
	}

	CDialog::OnTimer(nIDEvent);
}

void CDlgMotorMove::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	
}

void CDlgMotorMove::DispStatus()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	double dPos = 0;
	CString strData;

	// X
	dPos = pMotor->GetPosition( AXIS_X );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosX.SetWindowText( (LPCTSTR)strData );

	// Y
	dPos = pMotor->GetPosition( AXIS_Y );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosY.SetWindowText( (LPCTSTR)strData );

	// Z1
	dPos = pMotor->GetPosition( AXIS_Z1 );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosZ1.SetWindowText( (LPCTSTR)strData );

	// Z2
	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G) // theta
	{
		dPos = pMotor->GetPosition( AXIS_Z2 );
	}
	else
	{
		if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1 ||
			gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
			dPos = 0.0;
		else
			dPos = pMotor->GetPosition( AXIS_Z2 );
	}
		
	strData.Format(_T("%.3f"), dPos);
	m_stcPosZ2.SetWindowText( (LPCTSTR)strData );

	// M
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		dPos = pMotor->GetPosition( AXIS_M );
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		strData.Format(_T("%.3f"), dPos);
	else
		strData.Format(_T("%.1f"), dPos);
	m_stcPosM.SetWindowText( (LPCTSTR)strData );
	
	// M2
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		dPos = pMotor->GetPosition( AXIS_M2 );
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		strData.Format(_T("%.3f"), dPos);
	else
		strData.Format(_T("%.1f"), dPos);
	m_stcPosM2.SetWindowText( (LPCTSTR)strData );

	// M2
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		dPos = pMotor->GetPosition( AXIS_M3 );

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		strData.Format(_T("%.3f"), dPos);
	else
		strData.Format(_T("%.1f"), dPos); 
	m_stcPosM3.SetWindowText( (LPCTSTR)strData );


	// C
	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G) // no use
	{
		strData.Format(_T("0.0"), dPos);
		m_stcPosC.SetWindowText( (LPCTSTR)strData );

		strData.Format(_T("0.0"), dPos);
		m_stcPosC2.SetWindowText( (LPCTSTR)strData );
	}
	else
	{
		if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		{
			dPos = 0.0;
			strData.Format(_T("%.3f"), dPos);
			m_stcPosC.SetWindowText( (LPCTSTR)strData );
			m_stcPosC2.SetWindowText( (LPCTSTR)strData );
		}
		else
		{
			dPos = pMotor->GetPosition( AXIS_C );
			strData.Format(_T("%.3f"), dPos);
			m_stcPosC.SetWindowText( (LPCTSTR)strData );

			dPos = pMotor->GetPosition( AXIS_C2 );
			strData.Format(_T("%.3f"), dPos);
			m_stcPosC2.SetWindowText( (LPCTSTR)strData );
		}
	}
	// A1
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		dPos = pMotor->GetPosition( AXIS_A1 );

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		strData.Format(_T("%.3f"), dPos);
	else
		strData.Format(_T("%.1f"), dPos); 
	m_stcPosA1.SetWindowText( (LPCTSTR)strData );

	// A2
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() > 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		dPos = pMotor->GetPosition( AXIS_A2 );

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		strData.Format(_T("%.3f"), dPos);
	else
		strData.Format(_T("%.1f"), dPos); 
	m_stcPosA2.SetWindowText( (LPCTSTR)strData );

	//UpdateLed
	m_bMotor = pMotor->GetCurrentSuctionMotor();
	int nSuction1 = pMotor->GetCurrentSuction();

	if(nSuction1 & 0x01)
		m_bSuction1 = TRUE;
	else
		m_bSuction1 = FALSE;

	if(nSuction1 & 0x02)
		m_bSuction2 = TRUE;
	else
		m_bSuction2 = FALSE;


	m_bClamp1 = pMotor->GetCurrentTableClamp(TRUE, TRUE);
	m_bClamp2 = pMotor->GetCurrentTableClamp(FALSE, TRUE);

	m_chkVacuumMotorOn.SetCheck(m_bMotor);
	m_chkVacuum1.SetCheck(m_bSuction1);
	m_chkVacuum2.SetCheck(m_bSuction2);
	m_chkClamp1.SetCheck(m_bClamp1);
	m_chkClamp2.SetCheck(m_bClamp2);
}

HBRUSH CDlgMotorMove::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( CTLCOLOR_STATIC == nCtlColor )
	{
		if( GetDlgItem(IDC_STATIC_TARGET_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_MOTOR_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_MOTOR_CONTROL)->GetSafeHwnd() == pWnd->m_hWnd )
			pDC->SetTextColor( RGB(0, 0, 255 ) );
		
	}
	// TODO: Return a different brush if the default is not desired
	return hbr;
}


void CDlgMotorMove::OnBnClickedCheckMotor()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	if(m_bMotor)
		pMotor->Table1VacuumMotor(FALSE);
	else
		pMotor->Table1VacuumMotor(TRUE);

}


void CDlgMotorMove::OnBnClickedCheckMasterOn()
{
	int nBaseAdd = 0;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
	nBaseAdd = ADD0B_WRITE_OUTPORT;
#endif
	
#ifdef __KUNSAN_1__
	m_bSuction1 = !m_bSuction1;
	SetTableSuction();
#else
	if(m_bSuction1)
		pMotor->SetOutPort(nBaseAdd + PORT_TABLE_SUCTION1, FALSE);
	else
		pMotor->SetOutPort(nBaseAdd + PORT_TABLE_SUCTION1, TRUE);
#endif
}


void CDlgMotorMove::OnBnClickedCheckSlaveOn()
{
	int nBaseAdd = 0;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
	nBaseAdd = ADD0B_WRITE_OUTPORT;
#endif
	
#ifdef __KUNSAN_1__
	m_bSuction2 = !m_bSuction2;
	SetTableSuction();
#else
	if(m_bSuction2)
		pMotor->SetOutPort(nBaseAdd + PORT_TABLE_SUCTION2, FALSE);
	else
		pMotor->SetOutPort(nBaseAdd + PORT_TABLE_SUCTION2, TRUE);
#endif
}

void CDlgMotorMove::SetTableSuction()
{
	
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if( FALSE == m_bSuction1 && FALSE == m_bSuction2 )
		pMotor->SetOutPort( PORT_TABLE_SUCTION, 0 );
	else if( TRUE == m_bSuction1 && FALSE == m_bSuction2 )
		pMotor->SetOutPort( PORT_TABLE_SUCTION, 1 );
	else if( FALSE == m_bSuction1 && TRUE == m_bSuction2 )
		pMotor->SetOutPort( PORT_TABLE_SUCTION, 2 );
	else // TRUE, TRUE
		pMotor->SetOutPort( PORT_TABLE_SUCTION, 3 );
}
void CDlgMotorMove::OnBnClickedCheckTableClamp1()
{

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(m_bClamp1)
		pMotor->TableClamp(FALSE, TRUE);
	else
		pMotor->TableClamp(TRUE, TRUE);
}


void CDlgMotorMove::OnBnClickedCheckTableClamp2()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(m_bClamp2)
		pMotor->TableClamp(FALSE, FALSE);
	else
		pMotor->TableClamp(TRUE, FALSE);
}


void CDlgMotorMove::OnBnClickedButtonPosLoading()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	EnableAllBtn(FALSE);

	if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX, gProcessINI.m_sProcessAutoSetting.dLoadPosY, TRUE))
	{
		ErrMsgDlg(STDGNALM438);
		EnableAllBtn(TRUE);
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		EnableAllBtn(TRUE);
	}
	EnableAllBtn(TRUE);
}


void CDlgMotorMove::OnBnClickedButtonPosUnloading()
{

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	EnableAllBtn(FALSE);

	if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dUnloadPosX, gProcessINI.m_sProcessAutoSetting.dUnloadPosY, TRUE))
	{
		ErrMsgDlg(STDGNALM438);
		EnableAllBtn(TRUE);
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{

		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		EnableAllBtn(TRUE);
	}
	EnableAllBtn(TRUE);
}


void CDlgMotorMove::OnBnClickedButtonManualScalPositionMove()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
		
	EnableAllBtn( FALSE );

	// X, Y
	double dPosX, dPosY;
	dPosX = gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + gSystemINI.m_sSystemDevice.dFieldSize.x/2 ;
	dPosY = gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY + gSystemINI.m_sSystemDevice.dFieldSize.y/2 ;

	pMotor->MotorMoveXY(dPosX,dPosY,TRUE);

	int nRet;
	// Check InPosition
	nRet = pMotor->InPositionIO(IND_X + IND_Y);

	EnableAllBtn(TRUE);

}


void CDlgMotorMove::OnBnClickedButtonAllReject()
{
	// 110610
	gDeviceFactory.GetMotor()->TablePCBReset();
	::Sleep(100);
#ifdef __PUSAN2__
	gDeviceFactory.GetMotor()->LoaderPCBReset();
	gDeviceFactory.GetMotor()->UnLoaderPCBReset();
#endif
}


void CDlgMotorMove::OnBnClickedButtonExtend()
{
	m_bExtend = !m_bExtend;
	if( m_bExtend ) // Extend
	{
		this->SetWindowPos( NULL, 0, 0, m_siExtendSize.cx, m_siExtendSize.cy, SWP_NOMOVE|SWP_NOZORDER );
		m_btnExtend.SetWindowTextA(_T("<<"));
	}
	else // Normal
	{
		this->SetWindowPos( NULL, 0, 0, m_siNormalSize.cx, m_siNormalSize.cy, SWP_NOMOVE|SWP_NOZORDER );
		m_btnExtend.SetWindowTextA(_T(">>"));
	}
}
void CDlgMotorMove::OnBnClickedButtonNear1()
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		// MPG Off
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	EnableAllBtn(FALSE);

	if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessFidFind.dNearPosX, gProcessINI.m_sProcessFidFind.dNearPosY, TRUE))
	{
		ErrMsgDlg(STDGNALM438);
		EnableAllBtn(TRUE);
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{

		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		EnableAllBtn(TRUE);
	}
	EnableAllBtn(TRUE);
}
void CDlgMotorMove::OnBnClickedButtonNear2()
{
	// TODO: Add your control notification handler code here
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		// MPG Off
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	EnableAllBtn(FALSE);

	if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessFidFind.dNearPosX2, gProcessINI.m_sProcessFidFind.dNearPosY2, TRUE))
	{
		ErrMsgDlg(STDGNALM438);
		EnableAllBtn(TRUE);
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{

		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		EnableAllBtn(TRUE);
	}
	EnableAllBtn(TRUE);
}
void CDlgMotorMove::CheckInpositionError(int nAxis, BOOL bShow)
{
	switch(nAxis)
	{
	case IND_X : ErrMsgDlg(STDGNALM404); break;
	case IND_Y : ErrMsgDlg(STDGNALM405); break;
	case IND_Z1 : ErrMsgDlg(STDGNALM406); break;
	case IND_Z2 : ErrMsgDlg(STDGNALM407); break;
	case IND_M1 : ErrMsgDlg(STDGNALM408); break;
	case IND_M2 : ErrMsgDlg(STDGNALM409); break;
	case IND_M3 : ErrMsgDlg(STDGNALM990); break;
	case IND_C1 : ErrMsgDlg(STDGNALM410); break;
	case IND_C2 : ErrMsgDlg(STDGNALM411); break;
	}
}

BOOL CDlgMotorMove::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN  || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CDialog::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CDialog::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(MotorMove) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}

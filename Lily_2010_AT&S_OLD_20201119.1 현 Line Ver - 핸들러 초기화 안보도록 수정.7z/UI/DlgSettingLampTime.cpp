// DlgSettingLampTime.cpp : implementation file
//

#include "stdafx.h"
#include "..\EasyDriller.h"
//#include "EasyMarkerError.h"
#include "DlgSettingLampTime.h"
//#include "PlugIn\PlugInManager.h"
#include "..\device\HLaserQuanta.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define SZ_HOURS	_T("Hours")

/////////////////////////////////////////////////////////////////////////////
// CDlgSettingLampTime dialog


CDlgSettingLampTime::CDlgSettingLampTime(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSettingLampTime::IDD, pParent)
{
	m_bEnableEditUseTime = true;
	//{{AFX_DATA_INIT(CDlgSettingLampTime)
	m_dAlarmTime = 0;
	m_dErrorTime = 0;
	m_dSetTime = 0;
	m_pPowerSupply = NULL;
	//}}AFX_DATA_INIT
}


void CDlgSettingLampTime::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgSettingLampTime)
	DDX_Text(pDX, IDC_EDIT_ALARM_TIME, m_dAlarmTime);
	DDX_Text(pDX, IDC_EDIT_ERROR_TIME, m_dErrorTime);
	DDX_Text(pDX, IDC_EDIT_SET_TIME, m_dSetTime);
	DDX_Control(pDX, IDC_EDIT_ALARM_TIME, m_edtAlarmTime);
	DDX_Control(pDX, IDC_EDIT_ERROR_TIME, m_edtErrorTime);
	DDX_Control(pDX, IDC_EDIT_SET_TIME, m_edtSetTime);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgSettingLampTime, CDialog)
	//{{AFX_MSG_MAP(CDlgSettingLampTime)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgSettingLampTime message handlers

void CDlgSettingLampTime::OnOK() 
{	
	//hhwang 090116
	CString str;
	str.Format(_T("Erase data on the setting time?"));
	int nRet = ErrMessage(str, MB_YESNO);
	if(nRet == 7)
		return;
	//end hhwang
	UpdateData(true);
	m_pPowerSupply->setAlarmTime((int)(m_dAlarmTime * 3600));
	m_pPowerSupply->setErrorTime((int)(m_dErrorTime * 3600));
	m_pPowerSupply->setLampTime((int)(m_dSetTime * 3600));

	// Set LaserError
	BOOL bLaserError = (m_pPowerSupply->getLampTime() >= m_pPowerSupply->getErrorTime());
	ErrMessage(_T("Time Over"));
//	CPlugInManager* pManager = ((CEasyMarkerApp*)AfxGetApp())->getPlugInManager();
//	ASSERT(NULL != pManager);
//	pManager->PostMessageToDescendants(EPM_LASERERROR, bLaserError, ERROR_POWER_LAMP_ERROR_TIME, MWS_TYPE_IOINTERFACE);

	CDialog::OnOK();
}

void CDlgSettingLampTime::OnCancel() 
{	
	CDialog::OnCancel();
}

BOOL CDlgSettingLampTime::OnInitDialog() 
{
	CDialog::OnInitDialog();
	initControls();
//	m_nErrorTime = getPowerDevice()->getContext()->getCommPort();
	m_dAlarmTime = int(m_pPowerSupply->getAlarmTime() / 3600);
	m_dErrorTime = int(m_pPowerSupply->getErrorTime() / 3600);
	m_dSetTime = int(m_pPowerSupply->getLampTime() / 3600);

	UpdateData(FALSE);
	return TRUE;
}


void CDlgSettingLampTime::initControls()
{	
/*	m_edtAlarmTime.SetFont(::GetAppFont(APPFNT_NUMBER));
	m_edtAlarmTime.SetUnitFont(::GetAppFont(APPFNT_UNIT));
	m_edtAlarmTime.SetUnitText(SZ_HOURS);
	m_edtErrorTime.SetFont(::GetAppFont(APPFNT_NUMBER));
	m_edtErrorTime.SetUnitFont(::GetAppFont(APPFNT_UNIT));
	m_edtErrorTime.SetUnitText(SZ_HOURS);
	m_edtSetTime.SetFont(::GetAppFont(APPFNT_NUMBER));
	m_edtSetTime.SetUnitFont(::GetAppFont(APPFNT_UNIT));
	m_edtSetTime.SetUnitText(SZ_HOURS);
*/
	if(m_bEnableEditUseTime == false)
	{
		m_edtSetTime.EnableWindow(FALSE);
	}
}

void CDlgSettingLampTime::setPowerDevice(HLaserQuanta* pPowerSupply)
{
	m_pPowerSupply = pPowerSupply;
}

HLaserQuanta* CDlgSettingLampTime::getPowerDevice()
{
	return m_pPowerSupply;
}

void CDlgSettingLampTime::EnableEditUseTime(bool bEnable)
{
	m_bEnableEditUseTime = bEnable;	
}
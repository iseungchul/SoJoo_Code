// DlgJobMode.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "DlgJobMode.h"
#include "afxdialogex.h"


// DlgJobMode ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(DlgJobMode, CDialog)

DlgJobMode::DlgJobMode(CWnd* pParent /*=NULL*/)
	: CDialog(DlgJobMode::IDD, pParent)
{
	m_nMode = 0;
}

DlgJobMode::~DlgJobMode()
{
}

void DlgJobMode::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_RADIO_IDLE, m_nMode);
}


BEGIN_MESSAGE_MAP(DlgJobMode, CDialog)
END_MESSAGE_MAP()


// DlgJobMode �޽��� ó�����Դϴ�.

int DlgJobMode::GetMode()
{
	return m_nMode;
}

void DlgJobMode::SetMode(int nMode)
{
	m_nMode = nMode;
}

void DlgJobMode::InitControl()
{
	m_fntBtn.CreatePointFont(100, "Arial Bold");

	GetDlgItem(IDC_RADIO_IDLE)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_JOB_PM)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_JOB_PNL_CHECK)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_JOB_TEST)->SetFont(&m_fntBtn);
	GetDlgItem(IDC_RADIO_JOB_FAILURE)->SetFont(&m_fntBtn);
	GetDlgItem(IDC_RADIO_JOB_OTHER)->SetFont(&m_fntBtn);
}

BOOL DlgJobMode::OnInitDialog()
{
	CDialog::OnInitDialog();

	InitControl();

	return TRUE;  // return TRUE unless you set the focus to a control
}

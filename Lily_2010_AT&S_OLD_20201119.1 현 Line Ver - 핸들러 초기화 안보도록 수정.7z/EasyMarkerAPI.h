// EasyMarkerAPI.h : main header file for the EASYMARKER DLL
//

#ifndef __EASYMARKER_API_H__
#define __EASYMARKER_API_H__

//////////////////////////////////////////////////////////////////////////
// definitions

#ifndef EASYMARKER_API
#define EASYMARKER_API	extern "C" __declspec(dllexport)
#endif

//////////////////////////////////////////////////////////////////////////
// EasyMarker Path

#define APPDIR_EASYMARKER	0
#define APPDIR_FONT			1
#define APPDIR_DEVICE		2
#define APPDIR_CALIBRATION	3
#define APPDIR_LOG			4
#define APPDIR_LANGUAGE		5
#define APPDIR_TEMP			6
#define APPDIR_MDF			7
#define APPDIR_LOGO			8
#define APPDIR_PEN			9
#define APPDIR_PLUGIN       10
#define APPDIR_HELP			11

//////////////////////////////////////////////////////////////////////////
// initialization

EASYMARKER_API int ShowEasyMarker(int nCmdShow);

EASYMARKER_API bool IsEasyMarkerVisible();

EASYMARKER_API bool SendMessageToEasyMarker(unsigned int message, unsigned int wParam = 0, unsigned int lParam = 0);

EASYMARKER_API bool GetEasyMarkerPath(int nIndex, char* lpBuffer, DWORD nBufferLength);

EASYMARKER_API bool LoadCalibrationFile(const char* lpszMaster, const char* lpszSlave);

EASYMARKER_API void ShowPowerSupplyDlg();

EASYMARKER_API void ShowScannerSetupDlg();

EASYMARKER_API void ShowMarkingParameterDlg();

EASYMARKER_API void ShowAPCDlg();

EASYMARKER_API bool MoveScanner(int xMaster, int yMaster, int xSlave = 0, int ySlave = 0, bool bMark = FALSE);

EASYMARKER_API bool BeamOn(bool bOn);

// line align
#define ALIGN_LEFT    PFA_LEFT
#define ALIGN_CENTER  PFA_CENTER
#define ALIGN_RIGHT   PFA_RIGHT

EASYMARKER_API bool InsertGlyphText(const char* lpszContents, const char* lpszFontName, double dSize, double x, double y, double q, DWORD dwMarkingParameterKey, int iLineAlign, double dCharWidth, double dCharRatio);

EASYMARKER_API bool InsertGlyphTextPage(int Page, const char* lpszContents, const char* lpszFontName, double dSize, double x, double y, double q, DWORD dwMarkingParameterKey, int iLineAlign, double dCharWidth, double dCharRatio);

EASYMARKER_API bool InsertGlyphPLT(const char* lpszPathName, double dCenterX, double dCenterY);

EASYMARKER_API bool InsertGlyphPLTPage(int Page, const char* lpszPathName, double dCenterX, double dCenterY);

EASYMARKER_API void UpdateEasyMarkerViews();

EASYMARKER_API bool RemoveAllGlyphs();

EASYMARKER_API bool QuickMarking();

EASYMARKER_API int GetMarkingParameterCount();

EASYMARKER_API int GetDefaultMarkingParameter();

EASYMARKER_API bool GetMarkingParameter(int nIndex, LPTSTR lpszName, int nMaxCount, COLORREF& clr, DWORD& dwKey);

EASYMARKER_API bool CloseEasyMarker();

EASYMARKER_API bool LoadMDFFile(const char* lpszPathName);

EASYMARKER_API bool SaveMDFFile(const char* lpszPathName);

//////////////////////////////////////////////////////////////////////////

#endif // __EASYMARKER_API_H__

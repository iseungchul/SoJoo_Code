// DProject.cpp: implementation of the DProject class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DProject.h"
#include "GlyphExcellon.h"
#include "..\EasyDriller.h"
//#include "..\sysdef.h"
#include "..\Device\DeviceMotor.h"
#include "..\Device\HDeviceFactory.h"
#include "..\Device\HEocard.h"
#include "DSystemIni.h"
#include "DEasyDrillerIni.h"
#include "..\UI\ColorComboEx.h"
#include "math.h"
#include "dprocessini.h"
#include "..\resource.h"
#include "dprocessini.h"
#include "..\device\HMotor.h"
#include "TSP.h"
#include "..\ui\ProgressWnd.h"


#define MID_FIDUCIAL 0 
#define COARSE_FIDUCIAL 1
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
DProject	gDProject;

DProject::DProject() 
{
	m_nVersion			= 10000;

	m_szProjectName[0] = _T('\0');
	m_szLotId[0] = _T('\0');
	m_szToolName[0] = _T('\0');

	m_nRangeXDisp		= 800; 
	m_nRangeYDisp		= 800;	
#ifdef __PUSAN_LDD__
	m_nDivRangeXDisp	= 40; 
	m_nDivRangeYDisp	= 40; 
#else
	m_nDivRangeXDisp	= 58; 
	m_nDivRangeYDisp	= 58; 
#endif

	m_nTextRangeXDisp	= 1;
	m_nTextRangeYDisp	= 1;
	
	m_dScaleManual		= 100.0;
	m_nScaleMode		= 0;

	m_dRefFidOffsetX	= 0.0;
	m_dRefFidOffsetY	= 0.0;

//	m_nInputUnit		= 0; 
//	m_nTZS				= 0; 
//	m_nABS				= 0;
	
//	m_nCheckR90			= 0; 
//	m_bCheckXMir		= 0;
//	m_bCheckYMir		= 0;
	m_dPcbThick			= 1;
	m_dPcbThick2		= 1;
	m_dSkivingThickOffset = 0;
	m_bUseCuDirect		= TRUE;
//	m_cToolOrder		= 0;
//	m_AxisPref			= 0; 
//	m_ScanPref			= 1; 
	m_nSeparation		= 0; 
	m_bUnitDivide		= FALSE;
	m_nMaxFidBlock      = 0; 

	InitFidTolData();

	m_szJobFilePath[0]	= _T('\0');

	for(int i = 0; i < MAX_FID_KIND_NO; i++)
	{
		m_FidInfo[i].nModelType			= 1;
		m_FidInfo[i].dSizeA				= 0.5;
		m_FidInfo[i].dSizeB				= 0;
		m_FidInfo[i].dSizeC				= 0;
		m_FidInfo[i].nPolarity			= 0;
		m_FidInfo[i].dScoreSize			= 10;
		m_FidInfo[i].dScoreAngle		= 10;
		m_FidInfo[i].dAspectRatio		= 10;
		
		for(int j = 0; j < 4; j++)
		{
			m_FidInfo[i].nCoaxial[j]		= 150;
			m_FidInfo[i].nRing[j]			= 150;
			m_FidInfo[i].dBrightness[j]		= 0.5;
			m_FidInfo[i].dContrast[j]		= 0.5;
		}
	}

	m_nDataLoadStep = NON_EXCELLON;

	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;

	m_nptRefFidPos.x = INT_MAX; // 20091029
	m_nptRefFidPos.y = INT_MAX;

	for(int i=0; i<3; i++)
	{
		m_dScale[i] = 1;
		m_dDrawStartX[i] = 0;
		m_dDrawStartY[i] = 0;
	}

	for(int i=0; i< MAX_TOOL_NO; i++)
	{
		m_pToolCode[i] = new CToolCodeList;
		m_pToolCode[i]->Initialize();
		m_bSelectToolDraw[i] = FALSE;
		m_nDataType[i] = HOLE_DATA;
	}

	for(int i = 0; i< MAX_FID_BLOCK; i++)
	{
		m_nSelectedFiducial[i] = -1;
	}

	m_dRefPosX = 600;
	m_dRefPosY = 700;

	m_pbCanvas = NULL;
	m_pUnitCanvas = NULL;
	m_nAxisMode = X_Y;
	m_bSelectDrawMode = FALSE;
	m_bPathDrawMode = FALSE;
	m_bShowSortIndex = FALSE;
	m_bShowSelectionFid = FALSE;

	m_nTotalHole = 0;
	m_nTotalLine = 0;
	m_nSelectFireHole = 0;
	m_nVisibleHole = 0;
	m_nSelectFireLine = 0;
	m_nVisibleLine = 0;
	
	m_nSelectFireHoleShot = 0;
	m_nVisibleHoleShot = 0;
	m_nSelectFireLineShot = 0;
	m_nVisibleLineShot = 0;

	m_nRadius = 0;
	m_nCenterX = 0;
	m_nCenterY = 0;
	m_nRotateInfo = X_Y;
	memset(&m_szVisionProjectName, 0, sizeof(m_szVisionProjectName));
	
	m_bSkivingMode = FALSE;
	m_bMultiFidAscentOrder = FALSE;
	m_nVacuumType = 0;
	m_nDummyFreeType = 0;

	m_dMeanScale = 100.0;
	m_dScaleTolerance2 = 0.02;
	m_dScaleTolerance1 = 0.02;

	m_n1stBaseFid = NULL;
	m_n2ndBaseFid = NULL;
	m_n1stSubFid = NULL;
	m_n2ndSubFid = NULL;

	m_bSaveRefFidData = FALSE;

	m_pRefFidData = new FID_DATA;
	memset(m_pRefFidData, 0, sizeof(FID_DATA));
	m_pRefFidData->nCam = 1; //Default = Low Cam
	m_pRefFidData->sVisInfo.nModelType = 1;
	strcpy_s(m_szTempFileName, _T("Untitle.txt"));
	strcpy_s(m_szFileName, _T("Untitle.txt"));
	m_CurrentMode = NONE_DRILL_MODE;
	m_nHoleFind = NO_FIND;
	m_bArrayCopy = FALSE;
	m_bFidInfoChangeForScale = FALSE;
}
DProject::~DProject()
{
	if(m_pRefFidData)
	{
		delete m_pRefFidData;
		m_pRefFidData = NULL;
	}
	
	for(int i=0; i<MAX_TOOL_NO; i++)
	{
		delete m_pToolCode[i];
		m_pToolCode[i] = NULL;
	}

	if(m_pbCanvas)
		delete m_pbCanvas;

	if(m_pUnitCanvas)
	{
		RemoveUnitCanvas();
		delete [] m_pUnitCanvas;
	}

	Delete();
}

void DProject::operator=( DProject& myDProject )
{
	m_nVersion			= myDProject.m_nVersion;
	strcpy_s(m_szFileName, myDProject.m_szFileName);
	
	m_nRangeXDisp		= myDProject.m_nRangeXDisp; 
	m_nRangeYDisp		= myDProject.m_nRangeYDisp;		
	m_nDivRangeXDisp	= myDProject.m_nDivRangeXDisp; 
	m_nDivRangeYDisp	= myDProject.m_nDivRangeYDisp;
	m_nTextRangeXDisp	= myDProject.m_nTextRangeXDisp; 
	m_nTextRangeYDisp	= myDProject.m_nTextRangeYDisp;
	m_dScaleLimitX1Pluse = myDProject.m_dScaleLimitX1Pluse;
	m_dScaleLimitX2Pluse = myDProject.m_dScaleLimitX2Pluse; 
	m_dScaleLimitY1Pluse = myDProject.m_dScaleLimitY1Pluse; 
	m_dScaleLimitY2Pluse = myDProject.m_dScaleLimitY2Pluse; 
	m_dScaleLimitX1Minus = myDProject.m_dScaleLimitX1Minus; 
	m_dScaleLimitX2Minus = myDProject.m_dScaleLimitX2Minus; 
	m_dScaleLimitY1Minus = myDProject.m_dScaleLimitY1Minus;
	m_dScaleLimitY2Minus = myDProject.m_dScaleLimitY2Minus; 
	m_dScaleManual		= myDProject.m_dScaleManual;
	m_nScaleMode		= myDProject.m_nScaleMode;
	m_dScaleTolerance1  = myDProject.m_dScaleTolerance1;
	m_dScaleTolerance2	= myDProject.m_dScaleTolerance2; 
	m_dMeanScale		= myDProject.m_dMeanScale;

	m_dRefFidOffsetX	= myDProject.m_dRefFidOffsetX;
	m_dRefFidOffsetY	= myDProject.m_dRefFidOffsetY;

//	m_nInputUnit		= myDProject.m_nInputUnit; 
//	m_nTZS				= myDProject.m_nTZS; 
//	m_nABS				= myDProject.m_nABS;
	
//	m_nCheckR90			= myDProject.m_nCheckR90; 
//	m_bCheckXMir		= myDProject.m_bCheckXMir;
//	m_bCheckYMir		= myDProject.m_bCheckYMir;
	m_dPcbThick			= myDProject.m_dPcbThick;
	m_dPcbThick2		= myDProject.m_dPcbThick2;
	m_dSkivingThickOffset = myDProject.m_dSkivingThickOffset;
	m_bUseCuDirect		= myDProject.m_bUseCuDirect;
//	m_cToolOrder		= myDProject.m_cToolOrder;
//	m_AxisPref			= myDProject.m_AxisPref; 
//	m_ScanPref			= myDProject.m_ScanPref; 
	m_bSkivingMode		= myDProject.m_bSkivingMode;
	m_bMultiFidAscentOrder = myDProject.m_bMultiFidAscentOrder;
	m_nSeparation		= myDProject.m_nSeparation; 
	m_nVacuumType		= myDProject.m_nVacuumType; 
	m_nDummyFreeType		= myDProject.m_nDummyFreeType; 
	m_nAxisMode			= myDProject.m_nAxisMode;
	m_nRotateInfo		= myDProject.m_nRotateInfo;
	m_bUnitDivide		= myDProject.m_bUnitDivide;
	m_nMaxFidBlock		= myDProject.m_nMaxFidBlock;
	
	strcpy_s(m_szJobFilePath, myDProject.m_szJobFilePath);
	strcpy_s(m_szVisionProjectName, myDProject.m_szVisionProjectName);
	strcpy_s(m_szLotId, myDProject.m_szLotId);
	strcpy_s(m_szToolName, myDProject.m_szToolName);

	for(int i = 0; i < MAX_FID_KIND_NO; i++)
	{
		m_FidInfo[i].nModelType			= myDProject.m_FidInfo[i].nModelType;
		m_FidInfo[i].dSizeA				= myDProject.m_FidInfo[i].dSizeA;
		m_FidInfo[i].dSizeB				= myDProject.m_FidInfo[i].dSizeB;
		m_FidInfo[i].dSizeC				= myDProject.m_FidInfo[i].dSizeC;
		m_FidInfo[i].nPolarity			= myDProject.m_FidInfo[i].nPolarity;
		m_FidInfo[i].dScoreSize			= myDProject.m_FidInfo[i].dScoreSize;
		m_FidInfo[i].dScoreAngle		= myDProject.m_FidInfo[i].dScoreAngle;
		m_FidInfo[i].dAspectRatio		= myDProject.m_FidInfo[i].dAspectRatio;

		for(int j = 0; j < 4; j++)
		{
			m_FidInfo[i].nCoaxial[j]		= myDProject.m_FidInfo[i].nCoaxial[j];
			m_FidInfo[i].nRing[j]			= myDProject.m_FidInfo[i].nRing[j];
			m_FidInfo[i].dBrightness[j]		= myDProject.m_FidInfo[i].dBrightness[j];
			m_FidInfo[i].dContrast[j]		= myDProject.m_FidInfo[i].dContrast[j];
		}
	}

	m_dRefPosX = myDProject.m_dRefPosX;
	m_dRefPosY = myDProject.m_dRefPosY;
	
	for(int i = 0 ; i < MAX_TOOL_NO; i++)
	{
		m_pToolCode[i]->m_nToolNo = myDProject.m_pToolCode[i]->m_nToolNo;
		m_pToolCode[i]->m_bUseTool = myDProject.m_pToolCode[i]->m_bUseTool;
		m_pToolCode[i]->m_bToolOrder = myDProject.m_pToolCode[i]->m_bToolOrder;
		m_pToolCode[i]->m_nToolSize = myDProject.m_pToolCode[i]->m_nToolSize;
		m_pToolCode[i]->m_nApertureSize = myDProject.m_pToolCode[i]->m_nApertureSize;
		m_pToolCode[i]->m_nToolColor = myDProject.m_pToolCode[i]->m_nToolColor;
		m_pToolCode[i]->m_nTotalSubNo = myDProject.m_pToolCode[i]->m_nTotalSubNo;
		m_pToolCode[i]->m_bVisible = myDProject.m_pToolCode[i]->m_bVisible;
		m_pToolCode[i]->m_nLeadIn = myDProject.m_pToolCode[i]->m_nLeadIn;
		m_pToolCode[i]->m_nLeadOut = myDProject.m_pToolCode[i]->m_nLeadOut;
		m_pToolCode[i]->m_nMarkingSize = myDProject.m_pToolCode[i]->m_nMarkingSize;
		m_pToolCode[i]->m_bPreworkPower = myDProject.m_pToolCode[i]->m_bPreworkPower;
		m_pToolCode[i]->m_bPreworkScanner = myDProject.m_pToolCode[i]->m_bPreworkScanner;
		m_pToolCode[i]->m_bPreworkPreheat= myDProject.m_pToolCode[i]->m_bPreworkPreheat;
		m_pToolCode[i]->m_bHoldFind = myDProject.m_pToolCode[i]->m_bHoldFind;
		m_pToolCode[i]->m_SubToolData.RemoveAll();
		
		SUBTOOLDATA toolData;
		POSITION pos = myDProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		while(pos)
		{
			toolData = myDProject.m_pToolCode[i]->m_SubToolData.GetNext(pos);
			m_pToolCode[i]->m_SubToolData.AddTail(toolData);
		}
	}

	m_nDataLoadStep = myDProject.m_nDataLoadStep;

	m_nMinX = myDProject.m_nMinX;
	m_nMaxX = myDProject.m_nMaxX;
	m_nMinY = myDProject.m_nMinY;
	m_nMaxY = myDProject.m_nMaxY;

	for(int i = 0; i<2; i++)
	{
		m_dScale[i] = myDProject.m_dScale[i];
		m_dDrawStartX[i] = myDProject.m_dDrawStartX[i];
		m_dDrawStartY[i] = myDProject.m_dDrawStartY[i];
		m_rcDraw[i] = myDProject.m_rcDraw[i];
	}
	
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		m_ToolSumInfo[i].nToolAtri			= myDProject.m_ToolSumInfo[i].nToolAtri;
		m_ToolSumInfo[i].nRealToolNo		= myDProject.m_ToolSumInfo[i].nRealToolNo;
		m_ToolSumInfo[i].nSameAreaToolNo	= myDProject.m_ToolSumInfo[i].nSameAreaToolNo;
	}

	m_Glyphs = myDProject.m_Glyphs;

	RemoveAreaList();
	DAreaInfo* pAreaInfo;
	POSITION pos;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		pos = myDProject.m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = myDProject.m_Areas[i].GetNext(pos);
			pAreaInfo->m_nRefNo++;
			m_Areas[i].AddTail(pAreaInfo);
		}
	}

	m_nRadius = myDProject.m_nRadius;
	m_nCenterX = myDProject.m_nCenterX;
	m_nCenterY = myDProject.m_nCenterY;

	m_nptRefFidPos = myDProject.m_nptRefFidPos; // 20091029
	m_nHoleFind = myDProject.m_nHoleFind;
}

BOOL DProject::Serialize(CArchiveMark &ar, int nVersion)
{
	BOOL bSuccess = TRUE;
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			m_nVersion = 10025; // version 1.00.25 : Add Tool Path
								// version 1.00.24 : Add check scale limit for fiducial 
								// version 1.00.23 : Add Scale Tolerance 
								// version 1.00.22 : min shot Freq, max shot Freq parameter add
								// version 1.00.21 : min shot time for kunshan 8
								// version 1.00.20 : Hole Find Cam 
								// version 1.00.19 : Hole Vision Info
								// version 1.00.18 : DummyFree 2 add
								// version 1.00.17 : DutyOffsetMS, VolOffsetMS
								// version 1.00.16 : TextMarking Size
								// version 1.00.15 : TextMarking
								// version 1.00.14 : Multi fiducial fire order option
								// version 1.00.13 : Use Multi fiducial
								// version 1.00.12 : Vision Threashold 
								// version 1.00.11 : Power Min/Max sub tool-> main tool & add Prework 
								// version 1.00.10 : ScaleMode(Minus)
								// version 1.00.09 : ScaleMode
								// version 1.00.08 : each Fiducial Info.
								// version 1.00.07 : Tophat mode
								// version 1.00.06 : Cu-direct
								// version 1.00.05 : Rotate Info.
								// version 1.00.04 : AOM profile file
								// version 1.00.03 : skiving height add
			                    // version 1.00.02 : unit insert, fiducial change
								// version 1.00.01 : MatroxVision JobFilePath
								// version 1.00.00
			
			ar << _T("Version = ") << m_nVersion << _T("\n");
			bSuccess = SaveFile10000(ar, m_nVersion);
		}
		else
		{	// loading code
			ar >> m_nVersion; 
			
			#ifdef __PUSAN_OLD_32__
				if(m_nVersion > 10008)
					bSuccess = LoadFile10000(ar, m_nVersion);
				else
					bSuccess = LoadFile10000Pusan32(ar, m_nVersion); // 32 ȣ�� version ȣȯ�� ���ؼ�
			#else
				bSuccess = LoadFile10000(ar, m_nVersion);
			#endif
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
	}
	END_CATCH

	return bSuccess;

}

BOOL DProject::SaveFile10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			str.Format(_T("%s\0"), m_szFileName);
			ar << str << _T("\n");
			ar << _T("\n");
			ar << _T("DataStep = ") << min(m_nDataLoadStep, SET_FID_ORIGIN + FIELD_DIVIED) << _T("\n"); //20091029
			ar << _T("Thick = ") << m_dPcbThick << _T("\n");
			ar << _T("Thick2 = ") << m_dPcbThick2 << _T("\n");
			ar << _T("Thick Offset = ") << m_dSkivingThickOffset << _T("\n");

			ar << _T("CuDirect = ") << m_bUseCuDirect << _T("\n");

			ar << _T("RangeXDisp = ") << m_nRangeXDisp << _T("\n");
			ar << _T("RangeYDisp = ") << m_nRangeYDisp << _T("\n");
			ar << _T("DivRangeXDisp = ") << m_nDivRangeXDisp << _T("\n");
			ar << _T("DivRangeYDisp = ") << m_nDivRangeYDisp << _T("\n");
			ar << _T("TextRangeXDisp = ") << m_nTextRangeXDisp << _T("\n");
			ar << _T("TextRangeYDisp = ") << m_nTextRangeYDisp << _T("\n");
			ar << _T("Separation = ") << m_nSeparation << _T("\n");

			if(nVersion > 10008)
			{
				ar << _T("ScaleLimit1 = ") << m_dScaleLimitX1Pluse << _T("\n");
				ar << _T("ScaleLimit2 = ") << m_dScaleLimitY1Pluse << _T("\n");
				ar << _T("ScaleManual = ") << m_dScaleManual << _T("\n");
				ar << _T("ScaleMode = ") << m_nScaleMode << _T("\n");
			}
			if(nVersion > 10009)
			{
				ar << _T("ScaleLimit1Minus = ") << m_dScaleLimitX1Minus << _T("\n");
				ar << _T("ScaleLimit2Minus = ") << m_dScaleLimitY1Minus << _T("\n");
				ar << _T("RefFiddOffsetX = ") << m_dRefFidOffsetX << _T("\n");
				ar << _T("RefFiddOffsetY = ") << m_dRefFidOffsetY << _T("\n");
			}

			ar << _T("MeanScale = ") << m_dMeanScale << _T("\n");
			ar << _T("ScaleTolerance1 = ") << m_dScaleTolerance1 << _T("\n");
			ar << _T("ScaleTolerance2 = ") << m_dScaleTolerance2 << _T("\n");

			if(nVersion > 10004) // ver 10005
				ar << _T("RotateInfo = ") << m_nRotateInfo << _T("\n");

			if(nVersion > 10001) // ver 10002
			{
				ar << _T("Radius = ") << m_nRadius << _T("\n");
				ar << _T("CX = ") << m_nCenterX << _T("\n");
				ar << _T("CY = ") << m_nCenterY << _T("\n");
				ar << _T("UnitDivide = ") << m_bUnitDivide << _T("\n");
				if(nVersion > 10012) // ver 10013
					ar << _T("MaxFidBlock = ") << m_nMaxFidBlock << _T("\n");//20111123 bskim
			}

			ar << _T("Fid_TablePosX = ") << m_dRefPosX << _T("\n");
			ar << _T("Fid_TablePosY = ") << m_dRefPosY << _T("\n");
			ar << _T("MinX = ") << m_nMinX << _T("\n");
			ar << _T("MinY = ") << m_nMinY << _T("\n");
			ar << _T("MaxX = ") << m_nMaxX << _T("\n");
			ar << _T("MaxY = ") << m_nMaxY << _T("\n");

			str.Format(_T("%s"), m_szVisionProjectName);
			ar << str << _T("\n");

			ar << _T("SkivingMode = ") << m_bSkivingMode << _T("\n");
			ar << _T("MultiFidOrder = ") << m_bMultiFidAscentOrder << _T("\n");
			ar << _T("VacuumType = ") << m_nVacuumType << _T("\n");

			if(nVersion >= 10018)
				ar << _T("DummyFreeType = ") << m_nDummyFreeType << _T("\n");
		
			ar << _T("HoleFindTYPE = ") << m_nHoleFind << _T("\n");

			if(nVersion < 10008)
			{					
				for(int i = 0; i < MAX_FID_KIND_NO; i++)
				{
					str.Format(_T("\nFidInfo%d\n"), i);
					ar << str;
					ar << _T("ModelType = ") << m_FidInfo[i].nModelType << _T("\n");
					ar << _T("SizeA = ") << m_FidInfo[i].dSizeA << _T("\n");
					ar << _T("SizeB = ") << m_FidInfo[i].dSizeB << _T("\n");
					ar << _T("SizeC = ") << m_FidInfo[i].dSizeC << _T("\n");
					ar << _T("Polarity = ") << m_FidInfo[i].nPolarity << _T("\n");
					ar << _T("MaxSize = ") << m_FidInfo[i].dScoreSize << _T("\n");
					ar << _T("MaxAngle = ") << m_FidInfo[i].dScoreAngle << _T("\n");
					ar << _T("AspectRatio = ") << m_FidInfo[i].dAspectRatio << _T("\n");

					for(int j = 0; j < 4; j++)
					{
						str.Format(_T("Cam %d\n"), j);
						ar << str;
						str.Format(_T(_T("Coaxial = ")), j+1);
						ar << str << m_FidInfo[i].nCoaxial[j] << _T("\n");
						
						str.Format(_T(_T("Ring = ")), j+1);
						ar << str << m_FidInfo[i].nRing[j] << _T("\n");

						str.Format(_T(_T("Brightness = ")), j+1);
						ar << str << m_FidInfo[i].dBrightness[j] << _T("\n");

						str.Format(_T(_T("Contrast = ")), j+1);
						ar << str << m_FidInfo[i].dContrast[j] << _T("\n");
					}
				}
			}
			ar << _T("\n");

			if(nVersion > 10000) // ver 10001
			{
				str.Format(_T("%s\0"), m_szJobFilePath);
				ar << str << _T("\n");
				ar << _T("\n");
			}

			if(nVersion >= 10025)
			{
				str.Format(_T("%s\0"), m_szToolName);
				ar << str << _T("\n");
				ar << _T("\n");
			}

			for(int i = 0; i < MAX_TOOL_NO; i++)
			{
				str.Format(_T("Tool Sum Info %d\n"), i);
				ar << str;
				ar << _T("ToolAtri = ") << m_ToolSumInfo[i].nToolAtri << _T("\n");
				ar << _T("RealToolNo = ") << m_ToolSumInfo[i].nRealToolNo << _T("\n");
				ar << _T("SameAreaToolNo = ") << m_ToolSumInfo[i].nSameAreaToolNo << _T("\n");
			}
			ar << _T("\n");

			for(int i = 0; i < MAX_TOOL_NO; i++)
			{
				m_pToolCode[i]->SaveFile10000(ar, nVersion);
			}

			ar << _T("Data start\n");

			if((m_nDataLoadStep & 0x0b) < LOAD_EXCELLON) // 20091029
			{
				m_Glyphs.SaveFileFid10000(ar, nVersion);
			}
			else if((m_nDataLoadStep & 0x0b) == LOAD_EXCELLON) // ONLY load excellon // 20091029
			{
				ar << _T("MinX = ") << m_Glyphs.m_nMinX << _T("\n");
				ar << _T("MinY = ") << m_Glyphs.m_nMinY << _T("\n");
				ar << _T("MaxX = ") << m_Glyphs.m_nMaxX << _T("\n");
				ar << _T("MaxY = ") << m_Glyphs.m_nMaxY << _T("\n");
				m_Glyphs.SaveFile10000(ar, nVersion);
				m_Glyphs.SaveFileFid10000(ar, nVersion);
			}
			else
			{
				ar << _T("MinX = ") << m_Glyphs.m_nMinX << _T("\n");
				ar << _T("MinY = ") << m_Glyphs.m_nMinY << _T("\n");
				ar << _T("MaxX = ") << m_Glyphs.m_nMaxX << _T("\n");
				ar << _T("MaxY = ") << m_Glyphs.m_nMaxY << _T("\n");
				
				if(nVersion > 10000) // ver 10001
					m_Glyphs.SaveFileUnit10000(ar, nVersion);

				m_Glyphs.SaveFileFid10000(ar, nVersion);
				for(int i = 0; i < MAX_TOOL_NO; i++)
				{
					ar << _T("Area No = ") << m_Areas[i].GetCount() << _T("\n");
					DAreaInfo* pAreaInfo;
					POSITION pos = m_Areas[i].GetHeadPosition();
					while (pos)
					{
						pAreaInfo = m_Areas[i].GetNext(pos);
						pAreaInfo->SaveFile10000(ar, nVersion);
					}
				}
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL DProject::LoadFile10000Pusan32(CArchiveMark &ar, int nVersion)
{
	CString str;
	int nCount;
	MemoryInfo tempMInfo, tempMInfo2;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code
			ar >> str;
			strcpy_s(m_szFileName, str);
			ar >> str;
			ar >> m_nDataLoadStep;
			ar >> m_dPcbThick >> m_dPcbThick2;
			if(nVersion >= 10003)
				ar >> m_dSkivingThickOffset;
			else
				m_dSkivingThickOffset = 0;

			if(nVersion >= 10006)
				ar >> m_bUseCuDirect;
			else
				m_bUseCuDirect = TRUE;

			ar >> m_nRangeXDisp;
			ar >> m_nRangeYDisp;
			ar >> m_nDivRangeXDisp;
			ar >> m_nDivRangeYDisp;
			
			m_nTextRangeXDisp = 1; // default
			m_nTextRangeYDisp = 1;

			ar >> m_nSeparation;

			if(nVersion >= 10005)
				ar >> m_nRotateInfo;
			else
				m_nRotateInfo = X_Y;

			if(nVersion > 10001) // ver 10002
			{
				ar >> m_nRadius;
				ar >> m_nCenterX;
				ar >> m_nCenterY;
				ar >> m_bUnitDivide;
			}

			m_nMaxFidBlock = 0; // default

			ar >> m_dRefPosX;
			ar >> m_dRefPosY;
			ar >> m_nMinX; 
			ar >> m_nMinY;
			ar >> m_nMaxX;
			ar >> m_nMaxY;

			strcpy_s(m_szVisionProjectName, "");

			for(int i = 0; i < MAX_FID_KIND_NO; i++)
			{
				ar >> str;
				ar >> str;
				ar >> m_FidInfo[i].nModelType;
				ar >> m_FidInfo[i].dSizeA;
				ar >> m_FidInfo[i].dSizeB;
				ar >> m_FidInfo[i].dSizeC;
				ar >> m_FidInfo[i].nPolarity;
				ar >> m_FidInfo[i].dScoreSize;
				ar >> m_FidInfo[i].dScoreAngle;
				ar >> m_FidInfo[i].dAspectRatio;

				for(int j = 0; j < 4; j++)
				{
					ar >> str;
					ar >> m_FidInfo[i].nCoaxial[j];
					ar >> m_FidInfo[i].nRing[j];
					ar >> m_FidInfo[i].dBrightness[j];
					ar >> m_FidInfo[i].dContrast[j];
				}
				
				// fid data
			}

			ar >> str;
			ar >> str;
			strcpy_s(m_szJobFilePath, str);
			ar >> str;

			for(int i = 0; i < MAX_TOOL_NO; i++)
			{
				ar >> str;
				ar >> m_ToolSumInfo[i].nToolAtri;
				ar >> m_ToolSumInfo[i].nRealToolNo;
				ar >> m_ToolSumInfo[i].nSameAreaToolNo;
				m_ToolSumInfo[i].bUsed = FALSE;
			}
			ar >> str;

			for(int i = 0; i < MAX_TOOL_NO; i++)
			{
				if(!m_pToolCode[i]->LoadFile10000Pusan32(ar, nVersion))
					return FALSE;
			}

			ar >> str;
			ReMoveExcellon();
			RemoveAreaList();

			if((m_nDataLoadStep & 0x0b) < LOAD_EXCELLON) // 20091029
			{
				m_Glyphs.LoadFileFid10000Pusan32(ar, nVersion);
			}
			else if((m_nDataLoadStep & 0x0b) == LOAD_EXCELLON) // ONLY load excellon // 20091029
			{
				ar >> m_Glyphs.m_nMinX; 
				ar >> m_Glyphs.m_nMinY;
				ar >> m_Glyphs.m_nMaxX;
				ar >> m_Glyphs.m_nMaxY;
				m_Glyphs.LoadFile10000Pusan32(ar, nVersion);
				m_Glyphs.LoadFileFid10000Pusan32(ar, nVersion);
			}
			else
			{
				ar >> m_Glyphs.m_nMinX; 
				ar >> m_Glyphs.m_nMinY;
				ar >> m_Glyphs.m_nMaxX;
				ar >> m_Glyphs.m_nMaxY;
				LPDUNIT pUnit;
				if(nVersion < 10002)
				{
					pUnit = new DUnit;
					m_Glyphs.m_Units.AddTail(pUnit);
				}
				else
				{
					m_Glyphs.LoadFileUnit10000Pusan32(ar, nVersion);
				}
				m_Glyphs.LoadFileFid10000Pusan32(ar, nVersion);
				m_Glyphs.m_FileMemoryInfo.RemoveAll();
				for(int i = 0; i < MAX_TOOL_NO; i++)
				{
					ar >> nCount;
					for(int j = 0; j < nCount; j++)
					{
						DAreaInfo* pAreaInfo = new DAreaInfo();
						if(!pAreaInfo->LoadFile10000Pusan32(ar, nVersion, &m_Glyphs))
							return FALSE;

						pAreaInfo->m_nRefNo = 1;
						pAreaInfo->m_nFireStatus = NO_FIRE;
						m_Areas[i].AddTail(pAreaInfo);
						if(nVersion < 10002)
						{
							if(pUnit->m_nMaxX < pAreaInfo->m_nMaxX)
								pUnit->m_nMaxX = pAreaInfo->m_nMaxX;
							if(pUnit->m_nMaxY < pAreaInfo->m_nMaxY)
								pUnit->m_nMaxY = pAreaInfo->m_nMaxY;
							if(pUnit->m_nMinX > pAreaInfo->m_nMinX)
								pUnit->m_nMinX = pAreaInfo->m_nMinX;
							if(pUnit->m_nMinY > pAreaInfo->m_nMinY)
								pUnit->m_nMinY = pAreaInfo->m_nMinY;
						}
					}
				}
				nCount = m_Glyphs.m_FileMemoryInfo.GetSize();
				for(int i = 0; i < nCount; i++ )
				{
					if(i == nCount - 1)
						break;
					if(i == 0)
					{
						tempMInfo = m_Glyphs.m_FileMemoryInfo.GetAt(0);
					}
					else
					{
						tempMInfo = tempMInfo2;
					}
					tempMInfo2 = m_Glyphs.m_FileMemoryInfo.GetAt(i + 1);

					if(tempMInfo2.nOrigin <= tempMInfo.nOrigin)
					{
						CString strString, strMsg;
						strString.LoadString(IDS_ERR_FILE_FORMAT);
						strMsg.Format(strString, "Line order error");
						ErrMessage(strMsg);
						return FALSE;
					}

				}
				m_Glyphs.m_FileMemoryInfo.RemoveAll();
			}
			if(m_nDataLoadStep & SET_FID_ORIGIN) // 20091029
				BackupRefFidPos();
			else
				m_nptRefFidPos.x = m_nptRefFidPos.y = INT_MAX;
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH

	// fid info 
	LPFIDDATA pFidData;
	POSITION pos = m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);

		pFidData->nCam		= LOW_CAM;
		pFidData->nFidType	= FID_PRIMARY + FID_FIND;
		pFidData->nToolNo	= 0;
		pFidData->dOffsetZ	= 0;
		pFidData->bCheckScaleLimit = TRUE;
		
		pFidData->sVisInfo.nModelType	= m_FidInfo[DEFAULT_FID_INDEX].nModelType;
		pFidData->sVisInfo.dSizeA		= m_FidInfo[DEFAULT_FID_INDEX].dSizeA;
		pFidData->sVisInfo.dSizeB		= m_FidInfo[DEFAULT_FID_INDEX].dSizeB;
		pFidData->sVisInfo.dSizeC		= m_FidInfo[DEFAULT_FID_INDEX].dSizeC;
		pFidData->sVisInfo.nPolarity	= m_FidInfo[DEFAULT_FID_INDEX].nPolarity;
		pFidData->sVisInfo.dScoreSize	= m_FidInfo[DEFAULT_FID_INDEX].dScoreSize;
		pFidData->sVisInfo.dScoreAngle	= m_FidInfo[DEFAULT_FID_INDEX].dScoreAngle;
		pFidData->sVisInfo.dAspectRatio	= m_FidInfo[DEFAULT_FID_INDEX].dAspectRatio;
		pFidData->sVisInfo.nThreshold = 0;
		pFidData->nFidBlock = 0;
		
		for(int i=0; i<4; i++)
		{
			pFidData->sVisInfo.nCoaxial[i]		= m_FidInfo[DEFAULT_FID_INDEX].nCoaxial[i];
			pFidData->sVisInfo.nRing[i]			= m_FidInfo[DEFAULT_FID_INDEX].nRing[i];
			pFidData->sVisInfo.dBrightness[i]	= m_FidInfo[DEFAULT_FID_INDEX].dBrightness[i];
			pFidData->sVisInfo.dContrast[i]		= m_FidInfo[DEFAULT_FID_INDEX].dContrast[i];
		}
	}

	return TRUE;	
}

BOOL DProject::LoadFile10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	int nCount;
	double dTemp;
	MemoryInfo tempMInfo, tempMInfo2;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code
			ar >> str;
			strcpy_s(m_szFileName, str);
			ar >> str;
			ar >> m_nDataLoadStep;
			ar >> m_dPcbThick >> m_dPcbThick2;
			if(nVersion >= 10003)
				ar >> m_dSkivingThickOffset;
			else
				m_dSkivingThickOffset = 0;
#ifndef __PUSAN_LDD__
			if(nVersion >= 10006)
#else
			if(nVersion >= 10018)
#endif
				ar >> m_bUseCuDirect;
			else
				m_bUseCuDirect = TRUE;

			ar >> m_nRangeXDisp;
			ar >> m_nRangeYDisp;
			ar >> m_nDivRangeXDisp;
			ar >> m_nDivRangeYDisp;
#ifdef __PUSAN_LDD__
			if(nVersion >= 10005 && nVersion < 10018)
			{
				ar >> str;
				ar >> str; 
			}
#endif
			if(nVersion >= 10015)
			{
				ar >> m_nTextRangeXDisp;
				ar >> m_nTextRangeYDisp;
			}
			else
			{
				m_nTextRangeXDisp = 1;
				m_nTextRangeYDisp = 1;
			}
			ar >> m_nSeparation;

			if(nVersion > 10008)
			{
				ar >> dTemp;
				ar >> dTemp;
				ar >> m_dScaleManual;
				ar >> m_nScaleMode;
			}
			if(nVersion > 10009)
			{
				ar >> dTemp;
				ar >> dTemp;
				ar >> m_dRefFidOffsetX;
				ar >> m_dRefFidOffsetY;
			}

			m_dMeanScale = 100;
			if(nVersion > 10023)
				ar >> m_dMeanScale;

			if(nVersion > 10022)
			{
				ar >> m_dScaleTolerance1;
				ar >> m_dScaleTolerance2;
				InitFidTolData();
			}
			else
			{
				m_dScaleTolerance1 = 0.02;
				m_dScaleTolerance2 = 0.02;
				InitFidTolData();
			}
			if(nVersion >= 10014)
				ar >> m_nRotateInfo;
			else
				m_nRotateInfo = X_Y;
#ifndef __PUSAN_LDD__
			if(nVersion > 10001) // ver 10002
#else
			if(nVersion >= 10018)
#endif
			{
				ar >> m_nRadius;
				ar >> m_nCenterX;
				ar >> m_nCenterY;
				ar >> m_bUnitDivide;
			}
			if(nVersion > 10012) // ver 10013
				ar >> m_nMaxFidBlock; //20111123 bskim
			else
				m_nMaxFidBlock = 0;

			ar >> m_dRefPosX;
			ar >> m_dRefPosY;
			ar >> m_nMinX; 
			ar >> m_nMinY;
			ar >> m_nMaxX;
			ar >> m_nMaxY;

			if(nVersion >= 10008)
			{
				ar >> str;
				strcpy_s(m_szVisionProjectName, str);

				ar >> m_bSkivingMode;
				if(nVersion > 10013)
					ar >> m_bMultiFidAscentOrder;
				ar >> m_nVacuumType;

				if(nVersion >= 10018)
					ar >> m_nDummyFreeType;


			}
			else 
			{
				strcpy_s(m_szVisionProjectName, _T(""));
			}

			if(nVersion >= 10019 )
				ar >> m_nHoleFind;

			if(nVersion < 10008)
			{
				for(int i = 0; i < MAX_FID_KIND_NO; i++)
				{
					ar >> str;
					ar >> str;
					ar >> m_FidInfo[i].nModelType;
					ar >> m_FidInfo[i].dSizeA;
					ar >> m_FidInfo[i].dSizeB;
					ar >> m_FidInfo[i].dSizeC;
					ar >> m_FidInfo[i].nPolarity;
					ar >> m_FidInfo[i].dScoreSize;
					ar >> m_FidInfo[i].dScoreAngle;
					ar >> m_FidInfo[i].dAspectRatio;

					for(int j = 0; j < 4; j++)
					{
						ar >> str;
						ar >> m_FidInfo[i].nCoaxial[j];
						ar >> m_FidInfo[i].nRing[j];
						ar >> m_FidInfo[i].dBrightness[j];
						ar >> m_FidInfo[i].dContrast[j];
					}
				}
				// fid data
			}
			ar >> str;

			if(nVersion > 10000) // ver 10001
			{
				ar >> str;
				strcpy_s(m_szJobFilePath, str);
				ar >> str;
			}
			if(nVersion >= 10025)
			{
				ar >> str;
				strcpy_s(m_szToolName, str);
				ar >> str;
			}
			for(int i = 0; i < MAX_TOOL_NO; i++)
			{
				ar >> str;
				ar >> m_ToolSumInfo[i].nToolAtri;
				ar >> m_ToolSumInfo[i].nRealToolNo;
				ar >> m_ToolSumInfo[i].nSameAreaToolNo;
				m_ToolSumInfo[i].bUsed = FALSE;
			}
			ar >> str;
		
			for(int i = 0; i < MAX_TOOL_NO; i++)
			{
				if(!m_pToolCode[i]->LoadFile10000(ar, nVersion))
					return FALSE;
			}
		 
			if(gProcessINI.m_sProcessSystem.bUseOpenTool) // ������� �������� �� ����
			{
				CStdioFile file;
				TRY
				{
					if (FALSE == file.Open(m_szToolName, CFile::modeRead))
					{
						return FALSE;
					}
					CArchiveMark ar2(&file, CArchive::load);
					for(int i = 0; i < MAX_TOOL_NO; i++)
					{
						if(!m_pToolCode[i]->LoadFile10000(ar2, nVersion))
							return FALSE;
					}
				}
				CATCH (CException, e)
				{
					e->Delete();
					return FALSE;
				}
				END_CATCH

				
			}
			ar >> str;
			ReMoveExcellon();
			RemoveAreaList();

			if((m_nDataLoadStep & 0x0b) < LOAD_EXCELLON) // 20091029
			{
				m_Glyphs.LoadFileFid10000(ar, nVersion, m_FidInfo);
			}
			else if((m_nDataLoadStep & 0x0b) == LOAD_EXCELLON) // ONLY load excellon // 20091029
			{
				ar >> m_Glyphs.m_nMinX; 
				ar >> m_Glyphs.m_nMinY;
				ar >> m_Glyphs.m_nMaxX;
				ar >> m_Glyphs.m_nMaxY;
				m_Glyphs.LoadFile10000(ar, nVersion);
				m_Glyphs.LoadFileFid10000(ar, nVersion, m_FidInfo);
			}
			else
			{
				ar >> m_Glyphs.m_nMinX; 
				ar >> m_Glyphs.m_nMinY;
				ar >> m_Glyphs.m_nMaxX;
				ar >> m_Glyphs.m_nMaxY;

				LPDUNIT pUnit;
#ifndef __PUSAN_LDD__
				if(nVersion < 10002)
#else
				if(nVersion < 10018)
#endif
				{
					pUnit = new DUnit;
					m_Glyphs.m_Units.AddTail(pUnit);
				}
				else
				{
					m_Glyphs.LoadFileUnit10000(ar, nVersion);
				}
				m_Glyphs.LoadFileFid10000(ar, nVersion, m_FidInfo);
				m_Glyphs.m_FileMemoryInfo.RemoveAll();
				for(int i = 0; i < MAX_TOOL_NO; i++)
				{
					ar >> nCount;
					for(int j = 0; j < nCount; j++)
					{
						DAreaInfo* pAreaInfo = new DAreaInfo();
						if(!pAreaInfo->LoadFile10000(ar, nVersion, &m_Glyphs))
							return FALSE;

						pAreaInfo->m_nRefNo = 1;
						pAreaInfo->m_nFireStatus = NO_FIRE;
						m_Areas[i].AddTail(pAreaInfo);
						if(nVersion < 10002)
						{
							if(pUnit->m_nMaxX < pAreaInfo->m_nMaxX)
								pUnit->m_nMaxX = pAreaInfo->m_nMaxX;
							if(pUnit->m_nMaxY < pAreaInfo->m_nMaxY)
				 				pUnit->m_nMaxY = pAreaInfo->m_nMaxY;
							if(pUnit->m_nMinX > pAreaInfo->m_nMinX)
								pUnit->m_nMinX = pAreaInfo->m_nMinX;
							if(pUnit->m_nMinY > pAreaInfo->m_nMinY)
								pUnit->m_nMinY = pAreaInfo->m_nMinY;
						}
					}
				}
				nCount = m_Glyphs.m_FileMemoryInfo.GetSize();
				for(int i = 0; i < nCount; i++ )
				{
					if(i == nCount - 1)
						break;
					if(i == 0)
					{
						tempMInfo = m_Glyphs.m_FileMemoryInfo.GetAt(0);
					}
					else
					{
						tempMInfo = tempMInfo2;
					}
					tempMInfo2 = m_Glyphs.m_FileMemoryInfo.GetAt(i + 1);

					if(tempMInfo2.nOrigin <= tempMInfo.nOrigin)
					{
						CString strString, strMsg;
						strString.LoadString(IDS_ERR_FILE_FORMAT);
						strMsg.Format(strString, _T("Line order error"));
						ErrMessage(strMsg);
						return FALSE;
					}

				}
				m_Glyphs.m_FileMemoryInfo.RemoveAll();
			}
			if(m_nDataLoadStep & SET_FID_ORIGIN) // 20091029
				BackupRefFidPos();
			else
				m_nptRefFidPos.x = m_nptRefFidPos.y = INT_MAX;
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

void DProject::InitToolData() //excellon ���� �ε��Ҷ� ȣ���.
{
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		m_pToolCode[i]->m_bUseTool = FALSE;
		m_pToolCode[i]->m_bVisible = TRUE;
	}
}

void DProject::SetMinMaxRect()
{
	m_nMaxX = m_Glyphs.m_nMaxX;
	m_nMaxY = m_Glyphs.m_nMaxY;
	m_nMinX = m_Glyphs.m_nMinX;
	m_nMinY = m_Glyphs.m_nMinY;
}

void DProject::HoleDrawModeDP(CDC *pDC, CRect rc, BOOL bSkip, BOOL isThereArea)
{
	if(bSkip && !m_bSelectDrawMode)
	{
		pDC->SetTextColor(RGB(0, 255, 0));
		pDC->ExtTextOut ( 5, 5, ETO_CLIPPED, NULL, _T("Hole Draw Skip"), NULL);
	}
	pDC->SetTextColor(RGB(125, 125, 125));
	pDC->SetBkColor (0x00A5FF);
	if(m_bSelectDrawMode)
		pDC->ExtTextOut ( 5, 25, ETO_CLIPPED, NULL, _T(" Select-view Mode "), NULL);
	else
		pDC->ExtTextOut ( 5, 25, ETO_CLIPPED, NULL, _T(" Drawing-all Mode "), NULL);

	if(isThereArea)
	{
		if(m_bPathDrawMode)
			pDC->ExtTextOut ( 5, 45, ETO_CLIPPED, NULL, _T(" Path-view Mode "), NULL);
		else
			pDC->ExtTextOut ( 5, 45, ETO_CLIPPED, NULL, _T(" Disable path Mode "), NULL);
	}
}

void DProject::Draw(CDC *pDC, CRect rc, BOOL bRunView, int nFidPane, int nFidIndex, BOOL bDrawOnlyFid)
{
	m_Glyphs.m_nFidIndex = nFidIndex;

	double dDrawEndX, dDrawEndY;
	double dRateX, dRateY;
	int nSkipNo, nHoleNo, nFieldNo;
	dDrawEndX = m_dDrawStartX[nFidPane] + m_dScale[nFidPane] * rc.Width();
	dDrawEndY = m_dDrawStartY[nFidPane] - m_dScale[nFidPane] * rc.Height();

	dRateX = (dDrawEndX - m_dDrawStartX[nFidPane]) / 50000; // 50mm field ���� ����
	dRateY = (m_dDrawStartY[nFidPane] - dDrawEndY) / 50000;
	dRateX = min(dRateX, dRateY);

	nHoleNo = m_Glyphs.GetTotalHoleCount();
	nFieldNo = max((m_nMaxX - m_nMinX) / 50000 * (m_nMaxY - m_nMinY) / 50000, 1);
	nHoleNo = (int)(min(nHoleNo, nHoleNo / nFieldNo * dRateX * dRateY));
	
	if(nFidPane)
		nSkipNo = nHoleNo / 2000 + 1; // 2000�� �̻��� Ȧ�� drawing �ȴٸ� skip
	else
		nSkipNo = nHoleNo / 30000 + 1; // 30000�� �̻��� Ȧ�� drawing �ȴٸ� skip
	if( nFidPane ==3)
		nSkipNo = nHoleNo / 30000 + 1; // 30000�� �̻��� Ȧ�� drawing �ȴٸ� skip

	if(nSkipNo % 2 == 0)
		nSkipNo++;

	if(bRunView)
		nSkipNo *= 20;
	
//	if(dRateX > 5) nSkipNo = 29;
//	else if(dRateX > 3) nSkipNo = 11;
//	else if(dRateX > 2) nSkipNo = 5;
//	else nSkipNo = 1;

	CPen pen;
	CPen* pOldPen = NULL;
	COLORREF pColor = RGB(100, 100, 100);
	
	pen.CreatePen(PS_SOLID, 1, pColor);
	pOldPen = pDC->SelectObject(&pen);

	int nTransX, nTransY, nSize;
	if(m_nRadius != 0)
	{
		CBrush cBr2;
		CBrush* pOldBrush;
		
		cBr2.CreateSolidBrush(RGB(200, 200, 200));
		pOldBrush = pDC->SelectObject(&cBr2);

		nSize = (int)(m_nRadius / m_dScale[nFidPane]);
		m_Glyphs.GetXY(m_nAxisMode, m_nCenterX, m_nCenterY, nTransX, nTransY, m_dDrawStartX[nFidPane], m_dDrawStartY[nFidPane], m_dScale[nFidPane]);
		pDC->Ellipse(nTransX - nSize, nTransY - nSize, nTransX + nSize, nTransY + nSize);
		pDC->MoveTo(0, nTransY);
		pDC->LineTo(rc.Width(), nTransY);
		pDC->MoveTo(nTransX, 0);
		pDC->LineTo(nTransX, rc.Height());

		pDC->SelectObject(pOldBrush);
	}
	
	DAreaInfo* pAreaInfo;
	POSITION pos;
	BOOL bIsThereArea = FALSE;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			bIsThereArea = TRUE;
			pAreaInfo = m_Areas[i].GetNext(pos);
			
//			if(pAreaInfo->m_nMinX > dDrawEndX) continue;
//			if(pAreaInfo->m_nMaxX < m_dDrawStartX) continue;
//			if(pAreaInfo->m_nMinY > m_dDrawStartY) continue;
//			if(pAreaInfo->m_nMaxY < dDrawEndY) continue;
			if(IsDrawData(pAreaInfo, m_dDrawStartX[nFidPane], m_dDrawStartY[nFidPane], dDrawEndX, dDrawEndY))
			{
				if(m_bSelectDrawMode)
					pAreaInfo->DrawSelectOnly(pDC, rc, m_dScale[nFidPane], m_dDrawStartX[nFidPane], m_dDrawStartY[nFidPane], &m_pToolCode[0], nSkipNo, m_nAxisMode, m_bPathDrawMode, m_bShowSortIndex);
				else
					pAreaInfo->Draw(pDC, rc, m_dScale[nFidPane], m_dDrawStartX[nFidPane], m_dDrawStartY[nFidPane], &m_pToolCode[0], nSkipNo, m_nAxisMode, m_bPathDrawMode, m_bShowSortIndex);
			}
		}
	}

	pDC->SelectObject(pOldPen);
	pen.DeleteObject();
	pOldPen = NULL;

	if(!bIsThereArea) // area ���� �Ǳ� �� drawing
	{
		if(m_bSelectDrawMode)
			m_Glyphs.DrawSelectOnly(pDC, rc, m_dScale[nFidPane], m_dDrawStartX[nFidPane], m_dDrawStartY[nFidPane], &m_pToolCode[0], nSkipNo, m_nAxisMode, m_bShowSortIndex);
		else
			m_Glyphs.Draw(pDC, rc, m_dScale[nFidPane], m_dDrawStartX[nFidPane], m_dDrawStartY[nFidPane], &m_pToolCode[0], nSkipNo, m_nAxisMode, m_bShowSortIndex);
	}
	else
	{
		m_Glyphs.DrawFiducialOnly(pDC, rc, m_dScale[nFidPane], m_dDrawStartX[nFidPane], m_dDrawStartY[nFidPane], &m_pToolCode[0], m_nAxisMode, m_bShowSortIndex, m_bSelectDrawMode);
	}

	m_Glyphs.DrawUnit(pDC, rc, m_dScale[nFidPane], m_dDrawStartX[nFidPane], m_dDrawStartY[nFidPane], &m_pToolCode[0], m_nAxisMode);

	if(!bRunView && !nFidPane)
	{
		if(nSkipNo > 1)
			HoleDrawModeDP(pDC, rc, TRUE, bIsThereArea);
		else
			HoleDrawModeDP(pDC, rc, FALSE, bIsThereArea);
	}
}
void DProject::DrawOnlyFiducial(CDC *pDC, CRect rc, int nPanelNo)
{
	m_Glyphs.DrawFiducialOnly(pDC, rc, m_dScale[0], m_dDrawStartX[0], m_dDrawStartY[0], &m_pToolCode[0], m_nAxisMode, m_bShowSortIndex, m_bSelectDrawMode, TRUE, nPanelNo);
}

void DProject::DrawToolInfo(CDC *pDC, CRect rc)
{
	CString str;
	pDC->SetTextColor(RGB(255, 255, 255));
	int nYstart = 5;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(m_pToolCode[i]->m_bUseTool)
		{
//			CBrush* pOldBrush;
//			CBrush cBr;
//			RECT rect = {rc.right - 80, nYstart + 18, rc.right - 5, nYstart};
			if(m_pToolCode[i]->m_bVisible)
				//cBr.CreateSolidBrush(GetRGB(m_pToolCode[i]->m_nToolColor));
				pDC->SetBkColor (GetRGB(m_pToolCode[i]->m_nToolColor));
			else
				//cBr.CreateSolidBrush(RGB(200, 200, 200));
				pDC->SetBkColor (RGB(240, 240, 240));

//			pOldBrush = pDC->SelectObject(&cBr);
//			pDC->FillRect(&rect, &cBr);

			str.Format(_T(" Tool %d "), i);
			pDC->ExtTextOut ( rc.right - 60, nYstart, ETO_CLIPPED, NULL, str, NULL);
			
//			pDC->SelectObject(pOldBrush);
			nYstart += 20;
		}
	}
}

void DProject::DrawToolInfoRunView(CDC *pDC, CRect rc)
{
	CString str;
	pDC->SetTextColor(RGB(255, 255, 255));
	int nYstart = 5;
	if(m_bSelectDrawMode)
	{
		for(int i = 0; i < MAX_TOOL_NO; i++)
		{
			if(m_pToolCode[i]->m_bUseTool)
			{
				if(m_bSelectToolDraw[i])
					pDC->SetBkColor (GetRGB(m_pToolCode[i]->m_nToolColor));
				else
					pDC->SetBkColor (RGB(240, 240, 240));
				
				
				str.Format(_T(" Tool %d "), i);
				pDC->ExtTextOut ( rc.right - 60, nYstart, ETO_CLIPPED, NULL, str, NULL);
				
				nYstart += 20;
			}
		}
	}
	else
	{
		for(int i = 0; i < MAX_TOOL_NO; i++)
		{
			if(m_pToolCode[i]->m_bUseTool)
			{
				if(m_pToolCode[i]->m_bVisible)
					pDC->SetBkColor (GetRGB(m_pToolCode[i]->m_nToolColor));
				else
					pDC->SetBkColor (RGB(240, 240, 240));
				
				
				str.Format(_T(" Tool %d "), i);
				pDC->ExtTextOut ( rc.right - 60, nYstart, ETO_CLIPPED, NULL, str, NULL);
				
				nYstart += 20;
			}
		}
	}
}

void DProject::InitialDrawRatio(CRect rc, int nFidPane)
{
	m_rcDraw[nFidPane] = rc;

	double dRateX, dRateY, dXLeng, dYLeng, dXFileLeng, dYFileLeng;
	
	if(m_nAxisMode == X_Y)
	{
		m_dDrawStartX[nFidPane] = m_nMinX;
		m_dDrawStartY[nFidPane] = m_nMaxY;
		dRateX = (abs(m_nMaxX - m_nMinX) + 10000) / ((double)m_rcDraw[nFidPane].Width());
		dRateY = (abs(m_nMaxY - m_nMinY) + 10000) / ((double)m_rcDraw[nFidPane].Height());
		dXFileLeng = abs(m_nMaxX - m_nMinX);
		dYFileLeng = abs(m_nMaxY - m_nMinY);
	}
	else if(m_nAxisMode == MX_Y)
	{
		m_dDrawStartX[nFidPane] = -m_nMaxX;
		m_dDrawStartY[nFidPane] = m_nMaxY;
		dRateX = (abs(m_nMaxX - m_nMinX) + 10000) / ((double)m_rcDraw[nFidPane].Width());
		dRateY = (abs(m_nMaxY - m_nMinY) + 10000) / ((double)m_rcDraw[nFidPane].Height());
		dXFileLeng = abs(m_nMaxX - m_nMinX);
		dYFileLeng = abs(m_nMaxY - m_nMinY);
	}
	else if(m_nAxisMode == X_MY)
	{
		m_dDrawStartX[nFidPane] = m_nMinX;
		m_dDrawStartY[nFidPane] = -m_nMinY;
		dRateX = (abs(m_nMaxX - m_nMinX) + 10000) / ((double)m_rcDraw[nFidPane].Width());
		dRateY = (abs(m_nMaxY - m_nMinY) + 10000) / ((double)m_rcDraw[nFidPane].Height());
		dXFileLeng = abs(m_nMaxX - m_nMinX);
		dYFileLeng = abs(m_nMaxY - m_nMinY);
	}
	else if(m_nAxisMode == MX_MY)
	{
		m_dDrawStartX[nFidPane] = -m_nMaxX;
		m_dDrawStartY[nFidPane] = -m_nMinY;
		dRateX = (abs(m_nMaxX - m_nMinX) + 10000) / ((double)m_rcDraw[nFidPane].Width());
		dRateY = (abs(m_nMaxY - m_nMinY) + 10000) / ((double)m_rcDraw[nFidPane].Height());
		dXFileLeng = abs(m_nMaxX - m_nMinX);
		dYFileLeng = abs(m_nMaxY - m_nMinY);
	}
	else if(m_nAxisMode == Y_X)
	{
		m_dDrawStartX[nFidPane] = m_nMinY;
		m_dDrawStartY[nFidPane] = m_nMaxX;
		dRateY = (abs(m_nMaxX - m_nMinX) + 10000) / ((double)m_rcDraw[nFidPane].Width());
		dRateX = (abs(m_nMaxY - m_nMinY) + 10000) / ((double)m_rcDraw[nFidPane].Height());
		dYFileLeng = abs(m_nMaxX - m_nMinX);
		dXFileLeng = abs(m_nMaxY - m_nMinY);
	}
	else if(m_nAxisMode == MY_X)
	{
		m_dDrawStartX[nFidPane] = -m_nMaxY;
		m_dDrawStartY[nFidPane] = m_nMaxX;
		dRateY = (abs(m_nMaxX - m_nMinX) + 10000) / ((double)m_rcDraw[nFidPane].Width());
		dRateX = (abs(m_nMaxY - m_nMinY) + 10000) / ((double)m_rcDraw[nFidPane].Height());
		dYFileLeng = abs(m_nMaxX - m_nMinX);
		dXFileLeng = abs(m_nMaxY - m_nMinY);
	}
	else if(m_nAxisMode == Y_MX)
	{
		m_dDrawStartX[nFidPane] = m_nMinY;
		m_dDrawStartY[nFidPane] = -m_nMinX;
		dRateY = (abs(m_nMaxX - m_nMinX) + 10000) / ((double)m_rcDraw[nFidPane].Width());
		dRateX = (abs(m_nMaxY - m_nMinY) + 10000) / ((double)m_rcDraw[nFidPane].Height());
		dYFileLeng = abs(m_nMaxX - m_nMinX);
		dXFileLeng = abs(m_nMaxY - m_nMinY);
	}
	else
	{
		m_dDrawStartX[nFidPane] = -m_nMaxY;
		m_dDrawStartY[nFidPane] = -m_nMinX;
		dRateY = (abs(m_nMaxX - m_nMinX) + 10000) / ((double)m_rcDraw[nFidPane].Width());
		dRateX = (abs(m_nMaxY - m_nMinY) + 10000) / ((double)m_rcDraw[nFidPane].Height());
		dYFileLeng = abs(m_nMaxX - m_nMinX);
		dXFileLeng = abs(m_nMaxY - m_nMinY);
	}
	
	m_dScale[nFidPane] = max(dRateX, dRateY);
	dXLeng = m_dScale[nFidPane] * m_rcDraw[nFidPane].Width();
	dYLeng = m_dScale[nFidPane] * m_rcDraw[nFidPane].Height();
	m_dDrawStartX[nFidPane] -= (dXLeng - dXFileLeng)/2.0;
	m_dDrawStartY[nFidPane] += (dYLeng - dYFileLeng)/2.0;
}

void DProject::SetDrawRect(CPoint pt, int nbZoomIn, int nFidPane)
{
	int nX = pt.x - m_rcDraw[nFidPane].left;
	int nY = pt.y - m_rcDraw[nFidPane].top;
	double dX = nX * m_dScale[nFidPane] * 0.3;
	double dY = nY * m_dScale[nFidPane] * 0.3;
	
	if(nbZoomIn == 1)
	{
		if(m_dScale[nFidPane]*1.3 < 0.01 || m_dScale[nFidPane]*1.3 > 10000)
			return;

		m_dDrawStartX[nFidPane] -= dX;
		m_dDrawStartY[nFidPane] += dY;
		m_dScale[nFidPane] *= 1.3;
	}
	else if(nbZoomIn == -1)
	{
		if(m_dScale[nFidPane]*0.7 < 0.01 || m_dScale[nFidPane]*0.7 > 10000)
			return;

		m_dDrawStartX[nFidPane] += dX;
		m_dDrawStartY[nFidPane] -= dY;
		m_dScale[nFidPane] *= 0.7;
	}
	else if(nbZoomIn == 5)
	{
		if(m_dScale[nFidPane]*1.5 < 0.01 || m_dScale[nFidPane]*1.5 > 10000)
			return;

		nX = m_rcDraw[nFidPane].Width()/2;
		nY = m_rcDraw[nFidPane].Height()/2;
		dX = nX * m_dScale[nFidPane] * 0.5;
		dY = nY * m_dScale[nFidPane] * 0.5;
		m_dDrawStartX[nFidPane] -= dX;
		m_dDrawStartY[nFidPane] += dY;
		m_dScale[nFidPane] *= 1.5;
	}
	else if(nbZoomIn == -5)
	{
		if(m_dScale[nFidPane]*0.5 < 0.01 || m_dScale[nFidPane]*0.5 > 10000)
			return;

		nX = m_rcDraw[nFidPane].Width()/2;
		nY = m_rcDraw[nFidPane].Height()/2;
		dX = nX * m_dScale[nFidPane] * 0.5;
		dY = nY * m_dScale[nFidPane] * 0.5;
		m_dDrawStartX[nFidPane] += dX;
		m_dDrawStartY[nFidPane] -= dY;
		m_dScale[nFidPane] *= 0.5;
	}
	else
	{
		m_dDrawStartX[nFidPane] -= pt.x * m_dScale[nFidPane];
		m_dDrawStartY[nFidPane] += pt.y * m_dScale[nFidPane];
	}
}

void DProject::SelectGlyph(CPoint point, int nFidPane)
{
	CPoint umPoint, ptChange;
	int nX = point.x;
	int nY = point.y;
	int nTol = (int)(10 * m_dScale[nFidPane]);
	umPoint.x = (int)(m_dDrawStartX[nFidPane] + nX * m_dScale[nFidPane]);
	umPoint.y = (int)(m_dDrawStartY[nFidPane] - nY * m_dScale[nFidPane]);

	ptChange = GetNoAxisChangePos(umPoint);

//	if(m_Glyphs.IsSelect(ptChange, nTol, &m_pToolCode[0], m_bSelectDrawMode))
//		return;

	DAreaInfo* pAreaInfo;
	POSITION pos;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			if(pAreaInfo->IsSelect(ptChange, nTol, &m_pToolCode[0], m_bSelectDrawMode, &m_Glyphs))
				return;
		}
	}
}

void DProject::Flip(BOOL bX)
{
	m_Glyphs.Flip(bX);
}

void DProject::Rotate(double dDeg)
{
	m_Glyphs.Rotate(dDeg);
}

void DProject::Move(int nX, int nY)
{
//	m_Glyphs.Move(nX, nY);
}

BOOL DProject::GetMinPos(int &nX, int &nY)
{
	int nCount = 0;

	nX = m_Glyphs.m_nMinX; nY = m_Glyphs.m_nMinY;
	return TRUE;
}

void DProject::Delete()
{
	ReMoveExcellon();
	RemoveAreaList();
}

BOOL DProject::IsFidHoleGet(BOOL &bFidList, CPoint& pt, BOOL &bSkiving, BOOL bFidDraw)
{
	CPoint umPoint, ptChange;
	int nTol = (int)(10 * m_dScale[bFidDraw]);
	umPoint.x = (int)(m_dDrawStartX[bFidDraw] + pt.x * m_dScale[bFidDraw]);
	umPoint.y = (int)(m_dDrawStartY[bFidDraw] - pt.y * m_dScale[bFidDraw]);
	pt = GetNoAxisChangePos(umPoint);
	
	if(m_Glyphs.IsFidHoleGet(bFidList, pt, nTol, bSkiving))
		return TRUE;
	
	return FALSE;
}

BOOL DProject::AddFiducial(CPoint pt, int nFidKind)
{
	CPoint umPoint, ptChange;
	int nTol = (int)(10 * m_dScale[0]);
	umPoint.x = (int)(m_dDrawStartX[0] + pt.x * m_dScale[0]);
	umPoint.y = (int)(m_dDrawStartY[0] - pt.y * m_dScale[0]);
	ptChange = GetNoAxisChangePos(umPoint);
	
	return m_Glyphs.AddFiducial(ptChange, nTol, nFidKind);
}
BOOL DProject::AddRandomFiducial(CPoint pt)
{
	return m_Glyphs.AddRandomFiducial(pt);
}

BOOL DProject::AddSubFiducial(CPoint pt)
{
	return m_Glyphs.AddSubFiducial(pt);
}

void DProject::DelFiducial(CPoint pt)
{
	CPoint umPoint, ptChange;
	int nTol = (int)(10 * m_dScale[0]);
	umPoint.x = (int)(m_dDrawStartX[0] + pt.x * m_dScale[0]);
	umPoint.y = (int)(m_dDrawStartY[0] - pt.y * m_dScale[0]);
	ptChange = GetNoAxisChangePos(umPoint);

	m_Glyphs.DelFiducial(ptChange, nTol);
}

void DProject::OnSetRefFid(CPoint pt)
{
	CPoint umPoint, ptChange;
	int nTol = (int)(10 * m_dScale[0]);
	umPoint.x = (int)(m_dDrawStartX[0] + pt.x * m_dScale[0]);
	umPoint.y = (int)(m_dDrawStartY[0] - pt.y * m_dScale[0]);
	ptChange = GetNoAxisChangePos(umPoint);
	
	m_Glyphs.OnSetRefFid(ptChange, nTol);
}

////////  Data ó�� ��ƾ //////////////////////////////////////////////////
BOOL DProject::FieldDivide(int nFidBlock)
{
	InitToolSumInfo();

	for(int i = ADDED_FID_TOOL + 1; i < MAX_TOOL_NO; i++) // ADDED_FID_TOOL + 1 : skiving data�� ó�� ���Ѵ�
	{
		if(!m_pToolCode[i]->m_bUseTool)
			continue;

		if(gProcessINI.m_sProcessSystem.bNoDivideUnit)
		{
			ClearUnitCanvas();
			if(UnitCanvasFill(i))
				CreateUnitArea(i);
		}
		else
		{
			gProcessINI.m_sProcessSystem.bFieldMinimumDivide = TRUE; // default line ������ �ϵ��� ��.
			CheckDataType(i);
			if(m_nDataType[i] == HOLE_DATA)
			{
				ClearCanvas();
				if(CanvasFill(i, nFidBlock))
					CreateArea(i, nFidBlock);
			}
			else
			{
				if(!GetLineField(i, nFidBlock))
				{
					gProcessINI.m_sProcessSystem.bFieldMinimumDivide = FALSE;
					CheckDataType(i);
					ClearCanvas();
					if(CanvasFill(i, nFidBlock))
						CreateArea(i, nFidBlock);

				}
			}
		}
	}
	return TRUE;
}
void DProject::CheckDataType(int nTool)
{
	m_nDataType[nTool] = HOLE_DATA;
	if(!gProcessINI.m_sProcessSystem.bFieldMinimumDivide)
		return;
	LPLINEDATA pLineData;
	POSITION pos;
	POSITION posUnit = m_Glyphs.m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)	
	{
		pUnit = m_Glyphs.m_Units.GetNext(posUnit);
		pos = pUnit->m_LineData.GetHeadPosition();
		while(pos)
		{
			pLineData = pUnit->m_LineData.GetNext(pos);
			if(pLineData != NULL)
			{
				if(m_ToolSumInfo[pLineData->nToolNo].nSameAreaToolNo  == m_ToolSumInfo[nTool].nSameAreaToolNo)
				{
					m_nDataType[nTool] = LINE_DATA;
					return;
				}
			}
		}
	}
}

BOOL DProject::GetLineField(int nTool, int nFidBlock)
{
	if(m_ToolSumInfo[m_ToolSumInfo[nTool].nSameAreaToolNo].bUsed) // �̹� �˻��� tool�� ���
		return TRUE;
	
	CPoint pt;
	LPLINEDATA pLineData;
	POSITION pos;
	POSITION posUnit = m_Glyphs.m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Glyphs.m_Units.GetNext(posUnit);
		pos =  pUnit->m_LineData.GetHeadPosition();
		while (pos) 
		{
			pLineData = pUnit->m_LineData.GetNext(pos);
			pLineData->bDivideDone = FALSE;
		}
	}
	int nMinX, nMaxX, nMinY, nMaxY;

	DAreaInfo* pAreaInfo;
	int nXStart, nYStart, nXEnd, nYEnd;
	int nXFieldSize = m_nDivRangeXDisp * 1000;
	int nYFieldSize = m_nDivRangeYDisp * 1000;
	BOOL isThereData = TRUE;
	int nAddLineToAreaY = 0;
	int nAddLineToAreaX = 0;
	int nXLineBigger = 0;
	int nYLineBigger = 0;
	while (isThereData)
	{
		isThereData = FALSE;
		ClearCanvas();
		POSITION posUnit = m_Glyphs.m_Units.GetHeadPosition();
		LPDUNIT pUnit;
		int nUnitNo = 0;
		while(posUnit)
		{
			pUnit = m_Glyphs.m_Units.GetNext(posUnit);
			pos =  pUnit->m_LineData.GetHeadPosition();
			while (pos) 
			{
				pLineData =pUnit->m_LineData.GetNext(pos);
				if(m_ToolSumInfo[pLineData->nToolNo].nSameAreaToolNo  == m_ToolSumInfo[nTool].nSameAreaToolNo &&
					(nFidBlock == -1 || nFidBlock == pLineData->nFidBlock))
				{
					if(!pLineData->bDivideDone)
					{
						if(abs(pLineData->npStartPos.x - pLineData->npEndPos.x) > nXFieldSize)
							return FALSE;
						if(abs(pLineData->npStartPos.y - pLineData->npEndPos.y) > nYFieldSize)
							return FALSE;
						
						if(pLineData->npStartPos.x > pLineData->npEndPos.x)
						{
							nXStart = (pLineData->npEndPos.x - m_nMinX)/1000;
							nXEnd = (pLineData->npStartPos.x - m_nMinX)/1000;
						}
						else
						{
							nXStart = (pLineData->npStartPos.x - m_nMinX)/1000;
							nXEnd = (pLineData->npEndPos.x - m_nMinX)/1000;
						}
						if(pLineData->npStartPos.y > pLineData->npEndPos.y)
						{
							nYStart = (pLineData->npEndPos.y - m_nMinY)/1000;
							nYEnd = (pLineData->npStartPos.y - m_nMinY)/1000;
						}
						else
						{
							nYStart = (pLineData->npStartPos.y - m_nMinY)/1000;
							nYEnd = (pLineData->npEndPos.y - m_nMinY)/1000;
						}
						for(int j = nYStart; j <= nYEnd; j++)
						{
							for(int k = nXStart; k <= nXEnd; k++)
							{
								m_pbCanvas[k*MAX_Y_TABLE + j] = TRUE;
							}
						}
						isThereData = TRUE;
					}
				}
			}
			nUnitNo++;
		}
		if(!isThereData)
			break;

		// add to field
		pAreaInfo = GetOneArea(nTool, nAddLineToAreaX, nAddLineToAreaY);
		if(!pAreaInfo)
			return FALSE;

		
		nUnitNo = 0;
		posUnit = m_Glyphs.m_Units.GetHeadPosition();
		BOOL bAddLine = FALSE;
		nXLineBigger = 0;
		nYLineBigger = 0;
		while(posUnit)
		{
			pUnit = m_Glyphs.m_Units.GetNext(posUnit);
			pos =  pUnit->m_LineData.GetHeadPosition();
			while (pos) 
			{
				pLineData = pUnit->m_LineData.GetNext(pos);
				if(m_ToolSumInfo[pLineData->nToolNo].nSameAreaToolNo  == m_ToolSumInfo[nTool].nSameAreaToolNo &&
					(nFidBlock == -1 || nFidBlock == pLineData->nFidBlock)) // flying, boardOne ����, �������� �Բ� 
				{
					if(!pLineData->bDivideDone)
					{
						if(pLineData->npStartPos.x > pLineData->npEndPos.x)
						{
							nMinX = pLineData->npEndPos.x; nMaxX = pLineData->npStartPos.x;
						}
						else
						{
							nMinX = pLineData->npStartPos.x; nMaxX = pLineData->npEndPos.x;
						}
						if(pLineData->npStartPos.y > pLineData->npEndPos.y)
						{
							nMinY = pLineData->npEndPos.y; nMaxY = pLineData->npStartPos.y;
						}
						else
						{
							nMinY = pLineData->npStartPos.y; nMaxY = pLineData->npEndPos.y;
						}
						if(pAreaInfo->IsInData2(pLineData, nMinX, nMaxX, nMinY, nMaxY, emFlying, m_ToolSumInfo[pLineData->nToolNo].nRealToolNo, nUnitNo, nXLineBigger, nYLineBigger)) // ������ �߸��� �ȵǼ� emFlying
						{
							pLineData->bDivideDone = TRUE;
							bAddLine = TRUE;
							nAddLineToAreaX = 0;
							nAddLineToAreaY = 0;
						}
					}
				}
			}
			nUnitNo++;
		}
		if(bAddLine == FALSE)
		{
			if(nXLineBigger > nYLineBigger)
				nAddLineToAreaX++;
			else
				nAddLineToAreaY++;
		}
		m_Areas[nTool].AddTail(pAreaInfo);
	}

	posUnit = m_Glyphs.m_Units.GetHeadPosition();
	while(posUnit)
	{
		pUnit = m_Glyphs.m_Units.GetNext(posUnit);
		pos =  pUnit->m_LineData.GetHeadPosition();
		while (pos) 
		{
			pLineData = pUnit->m_LineData.GetNext(pos);
			if(m_ToolSumInfo[pLineData->nToolNo].nSameAreaToolNo  == m_ToolSumInfo[nTool].nSameAreaToolNo &&
				(nFidBlock == -1 || nFidBlock == pLineData->nFidBlock))
			{
				if(!pLineData->bDivideDone)
					return FALSE;
			}
		}
	}

	m_ToolSumInfo[nTool].bUsed = TRUE;
	return TRUE;
}


DAreaInfo* DProject::GetOneArea(int nTool, int nAddLineToAreaX, int nAddLineToAreaY)
{
	if(m_nDivRangeXDisp == 0 || m_nDivRangeYDisp == 0) // project���� ������ ������ �ʵ��� ũ�Ⱑ 0�̸� 
		return NULL;
	
	int nXIndex, nYIndex;
	int nMinRangeX, nMinRangeY; // �ּҹ��� �ε��� 
	nXIndex = nYIndex = nMinRangeX = nMinRangeY = 0;
	BOOL bXRightDirect = TRUE, bBottomUpDirection = TRUE;
	DAreaInfo* pAreaInfo;
	BOOL bDivideX = FALSE, bDivideY = FALSE;
	
	nYIndex = SkipYIndex(nXIndex, nYIndex, nMinRangeY, bDivideY, nTool, bBottomUpDirection);
	if(nYIndex >= MAX_Y_TABLE)
		return NULL;
	
	nXIndex = 0;
	nXIndex = SkipXIndex(nXIndex, nYIndex, nMinRangeY, bXRightDirect, nMinRangeX, bDivideX, nTool);
	if(nXIndex < MAX_X_TABLE)
	{
		pAreaInfo = new DAreaInfo();
		pAreaInfo->m_nFireStatus = NO_FIRE;
		pAreaInfo->m_nMinX = nXIndex * 1000 + m_nMinX;
		pAreaInfo->m_nMinY = nYIndex * 1000 + m_nMinY;
		
		pAreaInfo->m_nMaxX = (nMinRangeX + 1 + nAddLineToAreaX) * 1000 - 1 + m_nMinX;
		pAreaInfo->m_nMaxY = (nMinRangeY + 1 + nAddLineToAreaY) * 1000 - 1 + m_nMinY;
		
		//		pAreaInfo->m_nMaxX = pAreaInfo->m_nMinX + m_nDivRangeXDisp * 1000 - 1;
		//		pAreaInfo->m_nMaxY = pAreaInfo->m_nMinY + m_nDivRangeYDisp * 1000 - 1;
		pAreaInfo->m_nRefNo = 1;
		return pAreaInfo;
		
		//		m_Areas[nTool].AddTail(pAreaInfo);
		
		TRACE(_T("X ( %d, %d ) Y ( %d, %d )\n"), pAreaInfo->m_nMinX, pAreaInfo->m_nMaxX,
											 pAreaInfo->m_nMinY, pAreaInfo->m_nMaxY);
	}
	else
		return NULL;
}
BOOL DProject::CanvasFill(int nTool, int nFidBlock) // return true : tool exist, else reture false
{
	BOOL bChange = FALSE;
	int nX, nY, nXStart, nYStart, nXEnd, nYEnd;
	if(nTool == ADDED_FID_TOOL) // skiving �̸�
	{
		CPoint pt;
		int nCount = m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX); //ADDED_FID_INDEX); �׳� ��üFiducial�κп��� ����
		LPFIDDATA pFidData;
		for(int i = 0; i < nCount; i++)
		{
//			if(!m_Glyphs.GetIsDelPoint(ADDED_FID_INDEX, i))
//			{
				pFidData = m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
				if( (pFidData->nFidType & FID_SECONDARY) && (pFidData->nFidType & FID_DRILL))
				{
					pt = pFidData->npPosition; //m_Glyphs.GetUseFidIntPoint(ADDED_FID_INDEX, i);
					nX = (pt.x - m_nMinX)/1000; // um �̹Ƿ� 1mm�� ����� ���� 1000����.
					nY = (pt.y - m_nMinY)/1000;
					m_pbCanvas[nX*MAX_Y_TABLE + nY] = TRUE;
					bChange = TRUE;
				}
//			}
		}
	}
	else
	{
		if(m_ToolSumInfo[m_ToolSumInfo[nTool].nSameAreaToolNo].bUsed) // �̹� �˻��� tool�� ���
			return FALSE;
		
		m_ToolSumInfo[nTool].bUsed = TRUE;
		
		CPoint pt;
		LPHOLEDATA pHoleData;
		LPLINEDATA pLineData;
		POSITION posUnit = m_Glyphs.m_Units.GetHeadPosition();
		LPDUNIT pUnit;
		while(posUnit)
		{
			pUnit = m_Glyphs.m_Units.GetNext(posUnit);
			POSITION pos =  pUnit->m_HoleData.GetHeadPosition();
			while (pos) 
			{
				pHoleData = pUnit->m_HoleData.GetNext(pos);
				if(m_ToolSumInfo[pHoleData->nToolNo].nSameAreaToolNo  == m_ToolSumInfo[nTool].nSameAreaToolNo &&
					(nFidBlock == -1 || nFidBlock == pHoleData->nFidBlock)) // flying, boardOne ����, �������� �Բ� 
				{
					nX = (pHoleData->npPos.x - m_nMinX)/1000; // + k;
					nY = (pHoleData->npPos.y - m_nMinY)/1000; // + j;
					m_pbCanvas[nX*MAX_Y_TABLE + nY] = TRUE;
					bChange = TRUE;
				}
			}
			pos =  pUnit->m_LineData.GetHeadPosition();
			while (pos) 
			{
				pLineData = pUnit->m_LineData.GetNext(pos);
				if(m_ToolSumInfo[pLineData->nToolNo].nSameAreaToolNo  == m_ToolSumInfo[nTool].nSameAreaToolNo &&
					(nFidBlock == -1 || nFidBlock == pLineData->nFidBlock))
				{
					if(pLineData->npStartPos.x > pLineData->npEndPos.x)
					{
						nXStart = (pLineData->npEndPos.x - m_nMinX)/1000;
						nXEnd = (pLineData->npStartPos.x - m_nMinX)/1000;
					}
					else
					{
						nXStart = (pLineData->npStartPos.x - m_nMinX)/1000;
						nXEnd = (pLineData->npEndPos.x - m_nMinX)/1000;
					}
					if(pLineData->npStartPos.y > pLineData->npEndPos.y)
					{
						nYStart = (pLineData->npEndPos.y - m_nMinY)/1000;
						nYEnd = (pLineData->npStartPos.y - m_nMinY)/1000;
					}
					else
					{
						nYStart = (pLineData->npStartPos.y - m_nMinY)/1000;
						nYEnd = (pLineData->npEndPos.y - m_nMinY)/1000;
					}
					for(int j = nYStart; j <= nYEnd; j++)
					{
						for(int k = nXStart; k <= nXEnd; k++)
						{
							m_pbCanvas[k*MAX_Y_TABLE + j] = TRUE;
						}
					}
					bChange = TRUE;
				}
			}
		}
	}
	return bChange;
}

BOOL DProject::UnitCanvasFill(int nTool)
{
	BOOL bChange = FALSE;
	int nX, nY, nXStart, nYStart, nXEnd, nYEnd;
	UNIT_DATA* pUnitRect;
	if(nTool == ADDED_FID_TOOL) // skiving �̸�
	{
		CPoint pt;
		int nCount = m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX); //ADDED_FID_INDEX); �׳� ��üFiducial�κп��� ����
		LPFIDDATA pFidData;
		for(int i = 0; i < nCount; i++)
		{
			pFidData = m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			if( (pFidData->nFidType & FID_SECONDARY) && (pFidData->nFidType & FID_DRILL))
			{
				pt = pFidData->npPosition; //m_Glyphs.GetUseFidIntPoint(ADDED_FID_INDEX, i);
				nX = (pt.x - m_nMinX)/1000; // um �̹Ƿ� 1mm�� ����� ���� 1000����.
				nY = (pt.y - m_nMinY)/1000;
				pUnitRect = new UNIT_DATA;
				pUnitRect->nMaxX = pUnitRect->nMinX = nX;
				pUnitRect->nMaxY = pUnitRect->nMinY = nY;
				m_pUnitCanvas[nX*MAX_Y_TABLE + nY].AddTail(pUnitRect);
				bChange = TRUE;
			}
		}
	}
	else
	{
		if(m_ToolSumInfo[m_ToolSumInfo[nTool].nSameAreaToolNo].bUsed) // �̹� �˻��� tool�� ���
			return FALSE;
		
		m_ToolSumInfo[nTool].bUsed = TRUE;
		
		CPoint pt;
		LPHOLEDATA pHoleData;
		LPLINEDATA pLineData;
		POSITION posUnit = m_Glyphs.m_Units.GetHeadPosition();
		LPDUNIT pUnit;
		while(posUnit)
		{
			pUnitRect = NULL;
			pUnit = m_Glyphs.m_Units.GetNext(posUnit);
			POSITION pos =  pUnit->m_HoleData.GetHeadPosition();
			while (pos) 
			{
				pHoleData = pUnit->m_HoleData.GetNext(pos);
				if(m_ToolSumInfo[pHoleData->nToolNo].nSameAreaToolNo  == m_ToolSumInfo[nTool].nSameAreaToolNo) // flying, boardOne ����, �������� �Բ� 
				{
					nX = (pHoleData->npPos.x - m_nMinX)/1000; // + k;
					nY = (pHoleData->npPos.y - m_nMinY)/1000; // + j;
					if(pUnitRect)
					{
						if(pUnitRect->nMaxX < nX) 
							pUnitRect->nMaxX = nX;
						if(pUnitRect->nMaxY < nY) 
							pUnitRect->nMaxY = nY;
						if(pUnitRect->nMinX > nX) 
							pUnitRect->nMinX = nX;
						if(pUnitRect->nMinY > nY) 
							pUnitRect->nMinY = nY;	
					}
					else
					{
						pUnitRect = new UNIT_DATA;
						pUnitRect->nMaxX = pUnitRect->nMinX = nX;
						pUnitRect->nMaxY = pUnitRect->nMinY = nY;	
					}
					bChange = TRUE;
				}
			}
			pos =  pUnit->m_LineData.GetHeadPosition();
			while (pos) 
			{
				pLineData = pUnit->m_LineData.GetNext(pos);
				if(m_ToolSumInfo[pLineData->nToolNo].nSameAreaToolNo  == m_ToolSumInfo[nTool].nSameAreaToolNo)
				{
					if(pLineData->npStartPos.x > pLineData->npEndPos.x)
					{
						nXStart = (pLineData->npEndPos.x - m_nMinX)/1000;
						nXEnd = (pLineData->npStartPos.x - m_nMinX)/1000;
					}
					else
					{
						nXStart = (pLineData->npStartPos.x - m_nMinX)/1000;
						nXEnd = (pLineData->npEndPos.x - m_nMinX)/1000;
					}
					if(pLineData->npStartPos.y > pLineData->npEndPos.y)
					{
						nYStart = (pLineData->npEndPos.y - m_nMinY)/1000;
						nYEnd = (pLineData->npStartPos.y - m_nMinY)/1000;
					}
					else
					{
						nYStart = (pLineData->npStartPos.y - m_nMinY)/1000;
						nYEnd = (pLineData->npEndPos.y - m_nMinY)/1000;
					}

					if(pUnitRect)
					{
						if(pUnitRect->nMaxX < nXStart) 
							pUnitRect->nMaxX = nXStart;
						if(pUnitRect->nMaxY < nYStart) 
							pUnitRect->nMaxY = nYStart;
						if(pUnitRect->nMinX > nXStart) 
							pUnitRect->nMinX = nXStart;
						if(pUnitRect->nMinY > nYStart) 
							pUnitRect->nMinY = nYStart;
					}
					else
					{
						pUnitRect = new UNIT_DATA;
						pUnitRect->nMaxX = pUnitRect->nMinX = nXStart;
						pUnitRect->nMaxY = pUnitRect->nMinY = nYStart;	
					}

					if(pUnitRect->nMaxX < nXEnd) 
						pUnitRect->nMaxX = nXEnd;
					if(pUnitRect->nMaxY < nYEnd) 
						pUnitRect->nMaxY = nYEnd;
					if(pUnitRect->nMinX > nXEnd) 
						pUnitRect->nMinX = nXEnd;
					if(pUnitRect->nMinY > nYEnd) 
						pUnitRect->nMinY = nYEnd;

					bChange = TRUE;
				}
			}
			if(bChange)
			{
				if(pUnitRect != NULL)
				{
					pUnitRect->pUnit = pUnit;
					m_pUnitCanvas[pUnitRect->nMinX*MAX_Y_TABLE + pUnitRect->nMinY].AddTail(pUnitRect);
				}

			}
		}
	}
	return bChange;
}

void DProject::ClearCanvas()
{
//	m_nCanvasMinX = MAX_X_TABLE;
//	m_nCanvasMinY = MAX_Y_TABLE;
//	m_nCanvasMaxX = -1;
//	m_nCanvasMaxY = -1;

	if(m_pbCanvas == NULL)
	{
		m_pbCanvas = new BOOL [MAX_X_TABLE * MAX_Y_TABLE];
		memset(m_pbCanvas, NULL, sizeof(BOOL)*MAX_X_TABLE * MAX_Y_TABLE);
	}
	else
	{
		memset(m_pbCanvas, NULL, sizeof(BOOL)*MAX_X_TABLE * MAX_Y_TABLE);
	}

}

void DProject::ClearUnitCanvas()
{
	if(m_pUnitCanvas == NULL)
	{
		m_pUnitCanvas = new UnitRectList [MAX_X_TABLE * MAX_Y_TABLE];
	}
	else
	{
		RemoveUnitCanvas();
	}	
}

void DProject::CreateArea(int nTool, int nFidBlock)
{
	if(m_nDivRangeXDisp == 0 || m_nDivRangeYDisp == 0) // project���� ������ ������ �ʵ��� ũ�Ⱑ 0�̸� 
		return;
	
	int nOldDivRangeXDisp, nOldDivRangeYDisp;
	nOldDivRangeXDisp = m_nDivRangeXDisp;
	nOldDivRangeYDisp = m_nDivRangeYDisp;
	if(m_ToolSumInfo[nTool].bTextType)
	{
		m_nDivRangeXDisp = m_nTextRangeXDisp; 
		m_nDivRangeYDisp = m_nTextRangeYDisp;
	}

	int nXIndex, nYIndex, nYIndexReverse, nYCurrent, nCenterOfData = MAX_Y_TABLE/2, nTotalLength = MAX_Y_TABLE, nDivideCnt = 0;
	int nMinRangeX, nMinRangeY; // �ּҹ��� �ε��� 
	nXIndex = nYIndex = nMinRangeX = nMinRangeY = 0;
	nYIndexReverse = MAX_Y_TABLE - 1;
	BOOL bXRightDirect = TRUE, bBottomUpDirection = TRUE;
	DAreaInfo* pAreaInfo;
	BOOL bDivideX = FALSE, bDivideY = FALSE;
	BOOL bFirst = TRUE, bEndBottom = FALSE, bEndTop = FALSE;
	AreaList TempArea;
	POSITION posCopy;
	//
	int nStartY = SkipYIndex(nXIndex, nYIndex, nMinRangeY, bDivideY, nTool, TRUE);
	int nEndY = SkipYIndex(nXIndex, nYIndexReverse, nMinRangeY, bDivideY, nTool, FALSE);
	
	nTotalLength  = nEndY - nStartY;
	nCenterOfData = (nEndY - nStartY)/2;
	nDivideCnt = ceil((double)(nTotalLength / m_nDivRangeYDisp));
	
	while (nYIndex < MAX_Y_TABLE ||  nYIndexReverse >= 0)
	{
		if(bBottomUpDirection)
		{
			nYIndex = SkipYIndex(nXIndex, nYIndex, nMinRangeY, bDivideY, nTool, bBottomUpDirection);
			if(bDivideY && gProcessINI.m_sProcessSystem.bFieldMinimumDivide)
			{
				//�����Ͱ� ��������� 
				ErrMessage(_T("Please Check Field Divide Size\n Data is Divided"));
				m_nDivRangeXDisp = nOldDivRangeXDisp;
				m_nDivRangeYDisp = nOldDivRangeYDisp;
				return;
			}

			if(nMinRangeY >= nCenterOfData)
			{
				bEndBottom = TRUE;
			}
			nYCurrent = nYIndex;
		}
		else
		{
			nYIndexReverse = SkipYIndex(nXIndex, nYIndexReverse, nMinRangeY, bDivideY, nTool, bBottomUpDirection);
			if(bDivideY && gProcessINI.m_sProcessSystem.bFieldMinimumDivide)
			{
				//�����Ͱ� ��������� 
				ErrMessage(_T("Please Check Field Divide Size\n Data is Divided"));
				m_nDivRangeXDisp = nOldDivRangeXDisp;
				m_nDivRangeYDisp = nOldDivRangeYDisp;
				return;
			}

			if(nYIndexReverse <= nCenterOfData)
			{
				bEndTop = TRUE;
			}
			nYCurrent = nMinRangeY;
			nMinRangeY = nYIndexReverse;
		}
		
		if(bXRightDirect) //��� �����̿��� 
		{
			nXIndex = 0;
			while (nXIndex < MAX_X_TABLE)
			{
				nXIndex = SkipXIndex(nXIndex, nYCurrent, nMinRangeY, bXRightDirect, nMinRangeX, bDivideX, nTool);
				if(bDivideX && gProcessINI.m_sProcessSystem.bFieldMinimumDivide)
				{
					//�����Ͱ� ��������� 
					ErrMessage(_T("Please Check Field Divide Size\n Data is Divided"));
					m_nDivRangeXDisp = nOldDivRangeXDisp;
					m_nDivRangeYDisp = nOldDivRangeYDisp;
					return;
				}
				if(nXIndex < MAX_X_TABLE)
				{
					pAreaInfo = new DAreaInfo();
					pAreaInfo->m_nFireStatus = NO_FIRE;
					pAreaInfo->m_nFidBlock = nFidBlock;
					if(bBottomUpDirection)
					{
						pAreaInfo->m_nMinX = nXIndex * 1000 + m_nMinX;
						pAreaInfo->m_nMinY = nYCurrent * 1000 + m_nMinY;
						
						pAreaInfo->m_nMaxX = pAreaInfo->m_nMinX + m_nDivRangeXDisp * 1000 - 1;
						pAreaInfo->m_nMaxY = pAreaInfo->m_nMinY + m_nDivRangeYDisp * 1000 - 1;
					}
					else
					{
						pAreaInfo->m_nMinX = nXIndex * 1000 + m_nMinX;
						pAreaInfo->m_nMaxY = (nMinRangeY + 1) * 1000 + m_nMinY - 1;

						pAreaInfo->m_nMinY = pAreaInfo->m_nMaxY - m_nDivRangeYDisp * 1000 + 1;
						pAreaInfo->m_nMaxX = pAreaInfo->m_nMinX + m_nDivRangeXDisp * 1000 - 1;
						
					}
					nXIndex += m_nDivRangeXDisp;

					pAreaInfo->m_nRefNo = 1;

					if(bBottomUpDirection)
						m_Areas[nTool].AddTail(pAreaInfo);
					else
					{
						TempArea.AddTail(pAreaInfo);
					}

					TRACE(_T("X ( %d, %d ) Y ( %d, %d )\n"), pAreaInfo->m_nMinX, pAreaInfo->m_nMaxX,
														 pAreaInfo->m_nMinY, pAreaInfo->m_nMaxY);
				}
			}
		}
		else
		{
			nXIndex = MAX_X_TABLE - 1;
			while (nXIndex >= 0)
			{
				nXIndex = SkipXIndex(nXIndex, nYCurrent, nMinRangeY, bXRightDirect, nMinRangeX, bDivideX, nTool);
				if(bDivideX && gProcessINI.m_sProcessSystem.bFieldMinimumDivide)
				{
					//�����Ͱ� ��������� 
					ErrMessage(_T("Please Check Field Divide Size\n Data is Divided"));
					m_nDivRangeXDisp = nOldDivRangeXDisp;
					m_nDivRangeYDisp = nOldDivRangeYDisp;
					return;
				}
				if(nXIndex >= 0)
				{
					pAreaInfo = new DAreaInfo();
					pAreaInfo->m_nFireStatus = NO_FIRE;
					pAreaInfo->m_nFidBlock = nFidBlock;
					if(bBottomUpDirection)
					{
						pAreaInfo->m_nMinY = nYCurrent * 1000 + m_nMinY;
						pAreaInfo->m_nMaxX = (nXIndex + 1) * 1000 + m_nMinX - 1;

						pAreaInfo->m_nMinX = pAreaInfo->m_nMaxX - m_nDivRangeXDisp * 1000 + 1;
						pAreaInfo->m_nMaxY = pAreaInfo->m_nMinY + m_nDivRangeYDisp * 1000 - 1;
					}
					else
					{
						pAreaInfo->m_nMaxX = (nXIndex + 1) * 1000 + m_nMinX - 1;
						pAreaInfo->m_nMaxY = (nMinRangeY + 1) * 1000 + m_nMinY - 1;

						pAreaInfo->m_nMinX = pAreaInfo->m_nMaxX - m_nDivRangeXDisp * 1000 + 1;
						pAreaInfo->m_nMinY = pAreaInfo->m_nMaxY - m_nDivRangeYDisp * 1000 + 1;
						
					}

					nXIndex -= m_nDivRangeXDisp;
	
					pAreaInfo->m_nRefNo = 1;

					if(bBottomUpDirection)
						m_Areas[nTool].AddTail(pAreaInfo);
					else
					{
						TempArea.AddTail(pAreaInfo);
					}

					TRACE(_T("X ( %d, %d ) Y ( %d, %d )\n"), pAreaInfo->m_nMinX, pAreaInfo->m_nMaxX,
						pAreaInfo->m_nMinY, pAreaInfo->m_nMaxY);			
					
				}
			}
		}
	
		if(bBottomUpDirection)
		{
			if(!bEndBottom)
				nYIndex = nMinRangeY + 1;
		}
		else
		{
			nYIndexReverse = nYCurrent - 1;
		}

		if(bBottomUpDirection)
		{
			bBottomUpDirection = FALSE;
			if(nDivideCnt % 2 == 0)
			{
				if(bXRightDirect)
					bXRightDirect = FALSE;
				else
					bXRightDirect = TRUE;
			}
		}
		else
		{
			bBottomUpDirection = TRUE;
			if(nDivideCnt % 2 == 1) 
			{
				if(bXRightDirect)
					bXRightDirect = FALSE;
				else
					bXRightDirect = TRUE;
			}
		}
		if(bEndTop && bEndBottom)
			break;
	}

	posCopy = TempArea.GetTailPosition();
	while(posCopy)
	{
		pAreaInfo = TempArea.GetPrev(posCopy);
		m_Areas[nTool].AddTail(pAreaInfo);
	}

	m_nDivRangeXDisp = nOldDivRangeXDisp;
	m_nDivRangeYDisp = nOldDivRangeYDisp;
}


void DProject::CreateUnitArea(int nTool)
{
	if(m_nDivRangeXDisp == 0 || m_nDivRangeYDisp == 0) // project���� ������ ������ �ʵ��� ũ�Ⱑ 0�̸� 
		return;
	
	int nXIndex, nYIndex;
	nXIndex = nYIndex = 0;
	BOOL bXRightDirect = TRUE;
	DAreaInfo* pAreaInfo;
	UNIT_DATA* pUnitRect;
	LPDUNIT pUnit;
	POSITION pos;
	
	while (nYIndex < MAX_Y_TABLE)
	{
		nYIndex = SkipYUnitIndex(nYIndex);
		if(nYIndex >= MAX_Y_TABLE)
			return;

		nXIndex = 0;
		if(bXRightDirect) //��� �����̿��� 
		{
			while (nXIndex < MAX_X_TABLE)
			{
				pUnitRect = SkipXUnitIndex(nXIndex, nYIndex, bXRightDirect);
				if(pUnitRect)
				{
					pAreaInfo = new DAreaInfo();
					pAreaInfo->m_nFireStatus = NO_FIRE;
					pAreaInfo->m_nMinX = pUnitRect->nMinX * 1000 + m_nMinX;
					pAreaInfo->m_nMinY = pUnitRect->nMinY * 1000 + m_nMinY;
					pAreaInfo->m_nMaxX = (pUnitRect->nMaxX + 1) * 1000 - 1 + m_nMinX;
					pAreaInfo->m_nMaxY = (pUnitRect->nMaxY + 1) * 1000 - 1 + m_nMinY;
					pAreaInfo->m_nRefNo = 1;

					pos = m_TempUnits.GetHeadPosition();
					while(pos)
					{
						pUnit = m_TempUnits.GetNext(pos);
						pAreaInfo->m_Units.AddTail(pUnit);
					}
					m_TempUnits.RemoveAll();
				
					m_Areas[nTool].AddTail(pAreaInfo);
				
					TRACE(_T("X ( %d, %d ) Y ( %d, %d )\n"), pAreaInfo->m_nMinX, pAreaInfo->m_nMaxX,
						pAreaInfo->m_nMinY, pAreaInfo->m_nMaxY);
					nXIndex = pUnitRect->nMinX;
					delete pUnitRect;
				}
				else
				{
					nXIndex = MAX_X_TABLE;
				}
			}
		}
		else
		{
			nXIndex = MAX_X_TABLE - 1;
			while (nXIndex >= 0)
			{
				pUnitRect = SkipXUnitIndex(nXIndex, nYIndex, bXRightDirect);
				if(pUnitRect)
				{
					pAreaInfo = new DAreaInfo();
					pAreaInfo->m_nFireStatus = NO_FIRE;
					pAreaInfo->m_nMinX = pUnitRect->nMinX * 1000 + m_nMinX;
					pAreaInfo->m_nMinY = pUnitRect->nMinY * 1000 + m_nMinY;
					pAreaInfo->m_nMaxX = (pUnitRect->nMaxX + 1) * 1000 - 1 + m_nMinX;
					pAreaInfo->m_nMaxY = (pUnitRect->nMaxY + 1) * 1000 - 1 + m_nMinY;
					pAreaInfo->m_nRefNo = 1;

					pos = m_TempUnits.GetHeadPosition();
					while(pos)
					{
						pUnit = m_TempUnits.GetNext(pos);
						pAreaInfo->m_Units.AddTail(pUnit);
					}
					m_TempUnits.RemoveAll();

					m_Areas[nTool].AddTail(pAreaInfo);

					TRACE(_T("X ( %d, %d ) Y ( %d, %d )\n"), pAreaInfo->m_nMinX, pAreaInfo->m_nMaxX,
						pAreaInfo->m_nMinY, pAreaInfo->m_nMaxY);
					nXIndex = pUnitRect->nMinX;
					delete pUnitRect;
				}
				else
				{
					nXIndex = -1;
				}
			}
		}
		nYIndex += m_nDivRangeYDisp;
		
		if(bXRightDirect)
			bXRightDirect = FALSE;
		else
			bXRightDirect = TRUE;
	}	
}

void DProject::InitToolSumInfo()
{
	ResetToolSumUsedFlag();
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(i == 0)
		m_ToolSumInfo[i].nToolAtri = emOneBoardTool;
		else
		{
			m_ToolSumInfo[i].nToolAtri = m_pToolCode[i]->GetToolSumInfo();
		
			if(m_ToolSumInfo[i].nToolAtri == emTextOneBoard)
			{
				m_ToolSumInfo[i].bTextType = TRUE;
				m_ToolSumInfo[i].nToolAtri = emOneBoardTool;
			}
			else
				m_ToolSumInfo[i].bTextType = FALSE;
		}
		m_ToolSumInfo[i].nRealToolNo = i;
		m_ToolSumInfo[i].nSameAreaToolNo = i;
	}

	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(m_ToolSumInfo[i].nToolAtri == emSameTool
			|| m_ToolSumInfo[i].nToolAtri == emOneFieldTool)
		{	
			for(int j = i + 1; j < MAX_TOOL_NO; j++)
			{
				if(m_ToolSumInfo[j].nToolAtri == emSameTool
					|| m_ToolSumInfo[j].nToolAtri == emOneFieldTool)
				{
					if(m_ToolSumInfo[j].bUsed)
						continue;
					
					if(!m_pToolCode[i]->IsSameBeamPath(m_pToolCode[j]))
						continue;

					if(!m_pToolCode[i]->IsSameMinMaxFreq(m_pToolCode[j]))
						continue;

					m_ToolSumInfo[j].bUsed = TRUE;
					m_ToolSumInfo[j].nSameAreaToolNo = i;
				}
			}
		}
	}
	ResetToolSumUsedFlag();

	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(m_ToolSumInfo[i].nToolAtri == emSameTool)
		{	
			for(int j = i + 1; j < MAX_TOOL_NO; j++)
			{
				if(m_ToolSumInfo[j].nToolAtri == emSameTool)
				{
					if(m_ToolSumInfo[j].bUsed)
						continue;
					if(m_pToolCode[i]->IsSameTool(m_pToolCode[j]))
					{
						m_ToolSumInfo[j].bUsed = TRUE;
						m_ToolSumInfo[j].nRealToolNo = i;
					}
				}
			}
		}
	}
	ResetToolSumUsedFlag();
}

void DProject::SetRealToolInfo()
{
/*	int nToolSum;
	ResetToolSumUsedFlag();
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		m_ToolSumInfo[i].nToolAtri = m_pToolCode[i]->GetToolSumInfo();
		m_ToolSumInfo[i].nRealToolNo = i;
	}
	
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(m_ToolSumInfo[i].nToolAtri == emSameTool)
		{	
			for(int j = i + 1; j < MAX_TOOL_NO; j++)
			{
				if(m_ToolSumInfo[j].nToolAtri == emSameTool)
				{
					if(m_ToolSumInfo[j].bUsed)
						continue;
					if(m_pToolCode[i]->IsSameTool(m_pToolCode[j]))
					{
						m_ToolSumInfo[j].bUsed = TRUE;
						m_ToolSumInfo[j].nRealToolNo = i;
					}
				}
			}
		}
	}
	ResetToolSumUsedFlag();
*/
}

void DProject::ResetToolSumUsedFlag()
{
	for(int i = 0; i < MAX_TOOL_NO; i++)
		m_ToolSumInfo[i].bUsed = FALSE;
}

int DProject::SkipYUnitIndex(int nY)
{
	for(int j = nY; j < MAX_Y_TABLE; j++)
	{
		for(int i = 0; i < MAX_X_TABLE; i++)
		{
			if(m_pUnitCanvas[i*MAX_Y_TABLE + j].GetCount() > 0)
				return j;
		}
	}
	return MAX_Y_TABLE;
}

UNIT_DATA* DProject::SkipXUnitIndex(int nX, int nY, BOOL bRightDirect)
{
	m_TempUnits.RemoveAll();
	UNIT_DATA* pUnitRect;
	if(bRightDirect)
	{
		for(int i = nX; i < MAX_X_TABLE; i++)
		{
			for(int j = nY; j < nY + m_nDivRangeYDisp; j++)
			{
				if(m_pUnitCanvas[i*MAX_Y_TABLE + j].GetCount() > 0)
				{
					pUnitRect = GetMinMaxData(i, j, nX, nY);
					return pUnitRect;
				}
			}
		}
		return NULL;
	}
	else
	{
		for(int i = nX; i >= 0; i--)
		{
			for(int j = nY; j < nY + m_nDivRangeYDisp; j++)
			{
				if(m_pUnitCanvas[i*MAX_Y_TABLE + j].GetCount() > 0)
				{
					pUnitRect = GetMinMaxData(i, j, nX, nY);
					return pUnitRect;
				}
			}
		}
		return NULL;
	}
	return NULL;
}

UNIT_DATA* DProject::GetMinMaxData(int nXIndex, int nYIndex, int nStartX, int nStartY)
{
	UNIT_DATA* pReturnUnitRect = new UNIT_DATA;
	UNIT_DATA* pUnitRect;
	int nSX, nEX, nSY, nEY, nSizeX, nSizeY;
	BOOL bFind;

	pReturnUnitRect->nMinX = pReturnUnitRect->nMinY	= INT_MAX;
	pReturnUnitRect->nMaxX = pReturnUnitRect->nMaxY	= INT_MIN;

	while(TRUE)
	{
		POSITION pos = m_pUnitCanvas[nXIndex*MAX_Y_TABLE + nYIndex].GetHeadPosition();
		POSITION beforePos = pos;
		while(pos)
		{
			pUnitRect = m_pUnitCanvas[nXIndex*MAX_Y_TABLE + nYIndex].GetNext(pos);
			if(pReturnUnitRect->nMaxX < pUnitRect->nMaxX) 
				pReturnUnitRect->nMaxX = pUnitRect->nMaxX;
			if(pReturnUnitRect->nMaxY < pUnitRect->nMaxY) 
				pReturnUnitRect->nMaxY = pUnitRect->nMaxY;
			if(pReturnUnitRect->nMinX > pUnitRect->nMinX) 
				pReturnUnitRect->nMinX = pUnitRect->nMinX;
			if(pReturnUnitRect->nMinY > pUnitRect->nMinY) 
				pReturnUnitRect->nMinY = pUnitRect->nMinY;

			m_TempUnits.AddTail(pUnitRect->pUnit);
			m_pUnitCanvas[nXIndex*MAX_Y_TABLE + nYIndex].RemoveAt(beforePos);
			delete pUnitRect;
			beforePos = pos;
		}

		nSizeX = m_nDivRangeXDisp - (pReturnUnitRect->nMaxX - pReturnUnitRect->nMinX) - 1;
		nSX = pReturnUnitRect->nMinX - nSizeX;
		if(nSX < 0) nSX = 0;
		nEX = pReturnUnitRect->nMaxX + nSizeX;
		if(nEX >= MAX_X_TABLE) nEX = MAX_X_TABLE - 1;

		nSizeY = m_nDivRangeYDisp - (pReturnUnitRect->nMaxY - pReturnUnitRect->nMinY) - 1;
		nSY = pReturnUnitRect->nMinY - nSizeY;
		if(nSY < 0) nSY = 0;
		nEY = pReturnUnitRect->nMaxY + nSizeY;
		if(nEY >= MAX_Y_TABLE) nEY = MAX_Y_TABLE - 1;

		bFind = FALSE;

		for(int i = nSX; i <= nEX; i++)
		{
			for(int j = nSY; j <= nEY; j++)
			{
				pos = m_pUnitCanvas[i*MAX_Y_TABLE + j].GetHeadPosition();
				beforePos = pos;
				while(pos)
				{
					pUnitRect = m_pUnitCanvas[i*MAX_Y_TABLE + j].GetNext(pos);
					if(pUnitRect->nMaxX <= nEX && pUnitRect->nMaxY <= nEY)
					{
						if(pReturnUnitRect->nMaxX < pUnitRect->nMaxX)
							pReturnUnitRect->nMaxX = pUnitRect->nMaxX;
						if(pReturnUnitRect->nMaxY < pUnitRect->nMaxY) 
							pReturnUnitRect->nMaxY = pUnitRect->nMaxY;
						if(pReturnUnitRect->nMinX > pUnitRect->nMinX) 
							pReturnUnitRect->nMinX = pUnitRect->nMinX;
						if(pReturnUnitRect->nMinY > pUnitRect->nMinY) 
							pReturnUnitRect->nMinY = pUnitRect->nMinY;

						m_TempUnits.AddTail(pUnitRect->pUnit);
//						m_pUnitCanvas[nXIndex*MAX_Y_TABLE + nYIndex].RemoveAt(beforePos);
						m_pUnitCanvas[i*MAX_Y_TABLE + j].RemoveAt(beforePos);
						delete pUnitRect;
						i = nEX + 1;
						j = nEY + 1;
						bFind = TRUE;
						break;
					}
					beforePos = pos;
				}
			}
		}
		if(bFind == FALSE)
			return pReturnUnitRect;
	}

	return NULL;
	
}

int DProject::SkipYIndex( int nX, int nY , int& nMinRangeIndex, BOOL &bDivide,  int nTool, BOOL bBottomUpDirection)
{
	BOOL bFindIndex = FALSE;
	if(bBottomUpDirection)
	{
		int nStartPos = MAX_Y_TABLE;
		for(int j = nY; j < MAX_Y_TABLE; j++)
		{
			for(int i = 0; i < MAX_X_TABLE; i++)
			{
				if(m_pbCanvas[i * MAX_Y_TABLE + j])
				{
					if(gProcessINI.m_sProcessSystem.bFieldMinimumDivide && m_nDataType[nTool] == LINE_DATA)
					{
						nStartPos = j;
						bFindIndex = TRUE;
					}
					else
					{
						nMinRangeIndex = j + m_nDivRangeYDisp - 1;
						return j;
					}
				}
				if(bFindIndex)
					break;
			}
			if(bFindIndex)
				break;
		}
		if(!bFindIndex)
		{
			nMinRangeIndex = nStartPos;
			return nStartPos;
		}
		//�ڿ������� �ѹ� �� üũ
		int nEndRange;
		if(nStartPos + m_nDivRangeYDisp > MAX_Y_TABLE)
			nEndRange = MAX_Y_TABLE;
		else
			nEndRange = nStartPos + m_nDivRangeYDisp;

		BOOL bAllWhite;
		for(int j =  nEndRange; j > nStartPos; j--)
		{
			bAllWhite = TRUE;
			for(int i = 0; i < MAX_X_TABLE; i++)
			{
				if(m_pbCanvas[i * MAX_Y_TABLE + j])
				{
					bAllWhite = FALSE;
				}
			}
			if(bAllWhite)
			{
				nMinRangeIndex = j - 1;
				return nStartPos;
			}
		}

		if(nStartPos + m_nDivRangeYDisp > MAX_Y_TABLE)
			nMinRangeIndex = MAX_Y_TABLE;
		else
			nMinRangeIndex = nEndRange - 1;

		bDivide = TRUE;
		return nStartPos;
	}
	else
	{
		int nStartPos = -1;
		for(int j = nY; j >= 0; j--)
		{
			for(int i = 0; i < MAX_X_TABLE; i++)
			{
				if(m_pbCanvas[i * MAX_Y_TABLE + j])
				{
					if(gProcessINI.m_sProcessSystem.bFieldMinimumDivide && m_nDataType[nTool] == LINE_DATA)
					{
						nStartPos = j;
						bFindIndex = TRUE;
					}
					else
					{
						nMinRangeIndex = j - m_nDivRangeYDisp + 1;
						return j;
					}
				}
				if(bFindIndex)
					break;
			}
			if(bFindIndex)
				break;
		}
		if(!bFindIndex)
		{
			nMinRangeIndex = nStartPos;
			return nStartPos;
		}
		//�ڿ������� �ѹ� �� üũ
		int nEndRange;
		if(nStartPos - m_nDivRangeYDisp < 0)
			nEndRange = 0;
		else
			nEndRange = nStartPos - m_nDivRangeYDisp;

		BOOL bAllWhite;
		for(int j =  nEndRange; j > nStartPos; j--)
		{
			bAllWhite = TRUE;
			for(int i = 0; i < MAX_X_TABLE; i++)
			{
				if(m_pbCanvas[i * MAX_Y_TABLE + j])
				{
					bAllWhite = FALSE;
				}
			}
			if(bAllWhite)
			{
				nMinRangeIndex = j + 1;
				return nStartPos;
			}
		}

		if(nStartPos - m_nDivRangeYDisp < 0)
			nMinRangeIndex = 0;
		else
			nMinRangeIndex = nEndRange + 1;

		bDivide = TRUE;
		return nStartPos;
	}

}

int DProject::SkipXIndex(int nX, int nStartY, int nEndY, BOOL bRightDirect, int& nMinRangeIndex, BOOL& bDivide,  int nTool)
{
	int nStartPos;
	int nEndRange;
	BOOL bFindIndex = FALSE;

	if(bRightDirect) // + ����
	{
		nStartPos = MAX_X_TABLE;
		for(int i = nX; i < MAX_X_TABLE; i++)
		{
			for(int j = nStartY; j <= nEndY; j++)
			{
				if(m_pbCanvas[i * MAX_Y_TABLE + j])
				{
					if(gProcessINI.m_sProcessSystem.bFieldMinimumDivide && m_nDataType[nTool] == LINE_DATA)
					{
						nStartPos = i;
						bFindIndex = TRUE;
					}
					else
					{
						nMinRangeIndex = i + m_nDivRangeXDisp - 1;
						return i;
					}
				}
				if(bFindIndex)
					break;				
			}
			if(bFindIndex)
				break;
		}
		if(!bFindIndex)
		{
			nMinRangeIndex = nStartPos;
			return nStartPos;
		}
		
		if(nStartPos + m_nDivRangeXDisp > MAX_X_TABLE)
			nEndRange = MAX_X_TABLE;
		else
			nEndRange = nStartPos + m_nDivRangeXDisp;

		BOOL bAllWhite;
		for(int i = nEndRange; i > nStartPos; i --)
		{
			bAllWhite = TRUE;
			for(int j = nStartY; j <= nEndY; j++)
			{
				if(m_pbCanvas[ i * MAX_Y_TABLE + j])
				{
					bAllWhite = FALSE;
				}
			}
			if(bAllWhite)
			{
				nMinRangeIndex = i - 1;
				return nStartPos;
			}
		}
		if(nStartPos + m_nDivRangeXDisp > MAX_X_TABLE)
			nMinRangeIndex = MAX_X_TABLE;
		else
			nMinRangeIndex = nEndRange - 1;		

		bDivide = TRUE;
		return nStartPos;
	}
	else // - ���� 
	{
		nStartPos = -1;
		for(int i = nX; i >= 0; i--)
		{
			for(int j = nStartY; j <= nEndY; j++)
			{
				if(m_pbCanvas[i * MAX_Y_TABLE + j])
				{
					if(gProcessINI.m_sProcessSystem.bFieldMinimumDivide && m_nDataType[nTool] == LINE_DATA)
					{
						nStartPos = i;
						bFindIndex = TRUE;
					}
					else
					{
						nMinRangeIndex = i - m_nDivRangeXDisp + 1;
						return i;
					}
				}
				if(bFindIndex)
					break;				
			}
			if(bFindIndex)
				break;
		}

		if(!bFindIndex)
		{
			nMinRangeIndex = nStartPos;
			return nStartPos;
		}

		if(nStartPos - m_nDivRangeXDisp < 0)
			nEndRange = 0;
		else
			nEndRange = nStartPos - m_nDivRangeXDisp;


		BOOL bAllWhite;
		for(int i = nEndRange; i < nStartPos; i++)
		{
			bAllWhite = TRUE;
			for(int j = nStartY; j <= nEndY; j++)
			{
				if(m_pbCanvas[ i * MAX_Y_TABLE + j])
				{
					bAllWhite = FALSE;
				}
			}
			if(bAllWhite)
			{
				nMinRangeIndex = i + 1;
				return nStartPos;
			}
		}
		if(nStartPos - m_nDivRangeXDisp < 0)
			nMinRangeIndex = 0;
		else
			nMinRangeIndex = nEndRange + 1;

		bDivide = TRUE;
		return nStartPos;
	}
}

BOOL DProject::CollectData(int nFidBlock)
{
	ResetToolSumUsedFlag(); // only use flag reset
	
	for(int i = ADDED_FID_TOOL + 1; i < MAX_TOOL_NO; i++)
	{
		if(gProcessINI.m_sProcessSystem.bNoDivideUnit)
		{
			if(FALSE == CollectUnitOneTool(i))
				return FALSE;
		}
		else
		{
//			CheckDataType(i);
			if(m_nDataType[i] == HOLE_DATA) // LINE_DATA�� fieldDivide���� �̹� �����͸� �ִ´�.
			{
				if(FALSE == CollectOneTool(i, nFidBlock))
					return FALSE;
			}
		}
	}
	return TRUE;	
}

BOOL DProject::CollectUnitOneTool(int nTool)
{
	int nMinX, nMaxX, nMinY, nMaxY;

	POSITION posArea;
	DAreaInfo* pAreaInfo;
	BOOL bInOK;
	if(nTool == ADDED_FID_TOOL) // skiving �̸�
	{
		CPoint pt;
		int nCount = m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX); //ADDED_FID_INDEX); �׳� ��üFiducial�κп��� ����
		LPFIDDATA pFidData;
		for(int i = 0; i < nCount; i++)
		{
//			if(!m_Glyphs.GetIsDelPoint(ADDED_FID_INDEX, i))
//			{
				pFidData = m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
				if( (pFidData->nFidType & FID_SECONDARY) && (pFidData->nFidType & FID_DRILL))
				{
					bInOK = FALSE;
					pt = pFidData->npPosition; //m_Glyphs.GetUseFidIntPoint(ADDED_FID_INDEX, i);

					posArea = m_Areas[nTool].GetHeadPosition();
					while (posArea) 
					{
						pAreaInfo = m_Areas[nTool].GetNext(posArea);
						if(pAreaInfo->IsInData(pt, i))
						{
							bInOK = TRUE;
							break;
						}
					}
					if(!bInOK)
						return FALSE;
				}
//			}
		}
	}
	else
	{
		if(m_ToolSumInfo[m_ToolSumInfo[nTool].nSameAreaToolNo].bUsed) // �̹� �˻��� tool�� ���
			return TRUE;
		
		m_ToolSumInfo[nTool].bUsed = TRUE;
		

//		if(nTool == i || m_ToolSumInfo[nTool].nToolAtri != emOneBoardTool)
//			m_ToolSumInfo[nTool].bUsed = TRUE;
		
		LPHOLEDATA pHoleData;
		LPLINEDATA pLineData;
		POSITION posUnit = m_Glyphs.m_Units.GetHeadPosition();
		LPDUNIT pUnit;
		int nUnitNo = 0;
		while(posUnit)
		{
			pUnit = m_Glyphs.m_Units.GetNext(posUnit);
			POSITION pos =  pUnit->m_HoleData.GetHeadPosition();
			while (pos) 
			{
				bInOK = FALSE;
				pHoleData = pUnit->m_HoleData.GetNext(pos);
				if(m_ToolSumInfo[pHoleData->nToolNo].nSameAreaToolNo  == m_ToolSumInfo[nTool].nSameAreaToolNo) // flying, boardOne ����, �������� �Բ� 
				{
					posArea = m_Areas[nTool].GetHeadPosition(); // nTool�̾ nRealToolNo �� �׻� ����.
					while (posArea) 
					{
						pAreaInfo = m_Areas[nTool].GetNext(posArea);
						if(!pAreaInfo->IsThereSameUnit(pUnit))
							continue;

						if(pAreaInfo->IsInData(pHoleData, m_ToolSumInfo[pHoleData->nToolNo].nRealToolNo, nUnitNo))
						{
							bInOK = TRUE;
							break;
						}
					}
					if(!bInOK)
						return FALSE;
				}
			}
			pos =  pUnit->m_LineData.GetHeadPosition();
			while (pos) 
			{
				bInOK = FALSE; 
				pLineData = pUnit->m_LineData.GetNext(pos);
				if(m_ToolSumInfo[pLineData->nToolNo].nSameAreaToolNo  == m_ToolSumInfo[nTool].nSameAreaToolNo) // flying, boardOne ����, �������� �Բ� 
				{
					if(pLineData->npStartPos.x > pLineData->npEndPos.x)
					{
						nMinX = pLineData->npEndPos.x; nMaxX = pLineData->npStartPos.x;
					}
					else
					{
						nMinX = pLineData->npStartPos.x; nMaxX = pLineData->npEndPos.x;
					}
					if(pLineData->npStartPos.y > pLineData->npEndPos.y)
					{
						nMinY = pLineData->npEndPos.y; nMaxY = pLineData->npStartPos.y;
					}
					else
					{
						nMinY = pLineData->npStartPos.y; nMaxY = pLineData->npEndPos.y;
					}

					posArea = m_Areas[nTool].GetHeadPosition();
					while (posArea) 
					{
						pAreaInfo = m_Areas[nTool].GetNext(posArea);
						if(!pAreaInfo->IsThereSameUnit(pUnit))
							continue;

						if(pAreaInfo->IsInData(pLineData, nMinX, nMaxX, nMinY, nMaxY, m_ToolSumInfo[nTool].nToolAtri, m_ToolSumInfo[pLineData->nToolNo].nRealToolNo, nUnitNo))
						{
							bInOK = TRUE;
							if(m_ToolSumInfo[nTool].nToolAtri == emFlying)
								break;
						}
					}
					if(!bInOK)
						return FALSE;
				}
			}
			nUnitNo++;
		}
	}
	return TRUE;
}

BOOL DProject::CollectOneTool(int nTool, int nFidBlock)
{
	int nMinX, nMaxX, nMinY, nMaxY;

	POSITION posArea;
	DAreaInfo* pAreaInfo;
	BOOL bInOK;
	if(nTool == ADDED_FID_TOOL) // skiving �̸�
	{
		CPoint pt;
		int nCount = m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX); //ADDED_FID_INDEX); �׳� ��üFiducial�κп��� ����
		LPFIDDATA pFidData;
		for(int i = 0; i < nCount; i++)
		{
//			if(!m_Glyphs.GetIsDelPoint(ADDED_FID_INDEX, i))
//			{
				pFidData = m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
				if( (pFidData->nFidType & FID_SECONDARY) && (pFidData->nFidType & FID_DRILL))
				{
					bInOK = FALSE;
					pt = pFidData->npPosition; //m_Glyphs.GetUseFidIntPoint(ADDED_FID_INDEX, i);

					posArea = m_Areas[nTool].GetHeadPosition();
					while (posArea) 
					{
						pAreaInfo = m_Areas[nTool].GetNext(posArea);
						if(pAreaInfo->IsInData(pt, i))
						{
							bInOK = TRUE;
							break;
						}
					}
					if(!bInOK)
						return FALSE;
				}
//			}
		}
	}
	else
	{
		if(m_ToolSumInfo[m_ToolSumInfo[nTool].nSameAreaToolNo].bUsed) // �̹� �˻��� tool�� ���
			return TRUE;
		
		m_ToolSumInfo[nTool].bUsed = TRUE;
		

//		if(nTool == i || m_ToolSumInfo[nTool].nToolAtri != emOneBoardTool)
//			m_ToolSumInfo[nTool].bUsed = TRUE;
		
		LPHOLEDATA pHoleData;
		LPLINEDATA pLineData;
		POSITION posUnit = m_Glyphs.m_Units.GetHeadPosition();
		LPDUNIT pUnit;
		int nUnitNo = 0;
		while(posUnit)
		{
			pUnit = m_Glyphs.m_Units.GetNext(posUnit);
			POSITION pos =  pUnit->m_HoleData.GetHeadPosition();
			while (pos) 
			{
				bInOK = FALSE;
				pHoleData = pUnit->m_HoleData.GetNext(pos);
				if(m_ToolSumInfo[pHoleData->nToolNo].nSameAreaToolNo  == m_ToolSumInfo[nTool].nSameAreaToolNo &&
					(nFidBlock == -1 || nFidBlock == pHoleData->nFidBlock)) // flying, boardOne ����, �������� �Բ� 
				{
					posArea = m_Areas[nTool].GetHeadPosition(); // nTool�̾ nRealToolNo �� �׻� ����.
					while (posArea) 
					{
						pAreaInfo = m_Areas[nTool].GetNext(posArea);
						if(nFidBlock == -1 || pAreaInfo->m_nFidBlock == nFidBlock)
						{
							if(pAreaInfo->IsInData(pHoleData, m_ToolSumInfo[pHoleData->nToolNo].nRealToolNo, nUnitNo))
							{
								bInOK = TRUE;
								break;
							}
						}
					}
					if(!bInOK)
						return FALSE;
				}
			}
			pos =  pUnit->m_LineData.GetHeadPosition();
			while (pos) 
			{
				bInOK = FALSE;
				pLineData = pUnit->m_LineData.GetNext(pos);
				if(m_ToolSumInfo[pLineData->nToolNo].nSameAreaToolNo  == m_ToolSumInfo[nTool].nSameAreaToolNo &&
					(nFidBlock == -1 || nFidBlock == pLineData->nFidBlock)) // flying, boardOne ����, �������� �Բ� 
				{
					if(pLineData->npStartPos.x > pLineData->npEndPos.x)
					{
						nMinX = pLineData->npEndPos.x; nMaxX = pLineData->npStartPos.x;
					}
					else
					{
						nMinX = pLineData->npStartPos.x; nMaxX = pLineData->npEndPos.x;
					}
					if(pLineData->npStartPos.y > pLineData->npEndPos.y)
					{
						nMinY = pLineData->npEndPos.y; nMaxY = pLineData->npStartPos.y;
					}
					else
					{
						nMinY = pLineData->npStartPos.y; nMaxY = pLineData->npEndPos.y;
					}

					posArea = m_Areas[nTool].GetHeadPosition();
					while (posArea) 
					{
						pAreaInfo = m_Areas[nTool].GetNext(posArea);
						if(nFidBlock == -1 || pAreaInfo->m_nFidBlock == nFidBlock)
						{
							if(pAreaInfo->IsInData(pLineData, nMinX, nMaxX, nMinY, nMaxY, m_ToolSumInfo[nTool].nToolAtri, m_ToolSumInfo[pLineData->nToolNo].nRealToolNo, nUnitNo))
							{
								bInOK = TRUE;
								if(m_ToolSumInfo[nTool].nToolAtri == emFlying)
									break;
							}
						}
					}
					if(!bInOK)
						return FALSE;
				}
			}
			nUnitNo++;
		}
	}
	return TRUE;
}

BOOL DProject::PuzzleOut()
{
	if(m_nMaxX - m_nMinX >= 1000000 ||
		m_nMaxY - m_nMinY >= 1000000)
	{
		ErrMessage(IDS_ERR_FIELD_LIMIT);
		return FALSE;
	}

	RemoveAreaList();
	m_Glyphs.ChangeDataWithAxis(m_nAxisMode); // X_Y aixs �� ��� ��ȯ
	ChangeDataWithAxis();
	m_nAxisMode = X_Y;
	
	double dWaitTime = 0.0;
	CCorrectTime myTime;
	myTime.StartTime();

	int nStartFidBlock, nEndFidBlock;
	if(m_bMultiFidAscentOrder)
	{
		nStartFidBlock = 0; 
		nEndFidBlock = m_nMaxFidBlock;
	}
	else
	{
		nStartFidBlock = nEndFidBlock = -1; // �ѹ��� ��� fid block�� �����Ѵ�.
	}

	int nIndex = 0;
	int nTempIndex;
	CProgressWnd wndProgress(NULL, _T("Data Sorting"), TRUE);
	wndProgress.GoModal();
	wndProgress.SetRange(0, 0);
	wndProgress.SetText(_T("Sorting data.... Please wait."));
	for(int i = nStartFidBlock; i <= nEndFidBlock; i++)
	{
		wndProgress.SetText(_T("Field Dividing"));
		if(!FieldDivide(i))
		{
			RemoveAreaList();
			ErrMessage(_T("Can't divide Line. (The length of line is bigger than the field size.)"));
			wndProgress.SetParentWinActive();
			return FALSE;
		}
		dWaitTime = myTime.PresentTime();
		TRACE(_T("FieldDivide Time : %.3f\r\n"), dWaitTime);
		myTime.StartTime();	
		wndProgress.SetText(_T("Data Loading"));
		if(!CollectData(i))
		{
			RemoveAreaList();
			wndProgress.SetParentWinActive();
			return FALSE;
		}

		dWaitTime = myTime.PresentTime();
		TRACE(_T("CollectData Time : %.3f\r\n"), dWaitTime);
		myTime.StartTime();

		wndProgress.SetText(_T("Field optimizing"));
		if(!ShrinkArea(i))
		{
			RemoveAreaList();
			wndProgress.SetParentWinActive();
			return FALSE;
		}

	//	SetRealToolInfo();
		ResetToolSumUsedFlag();
		
		if(gProcessINI.m_sProcessSystem.bNoSortArea)
		{
			wndProgress.SetText(_T("Area Numbering"));
			if(!NumberingArea())
			{
				RemoveAreaList();
				wndProgress.SetParentWinActive();
				return FALSE;
			}
		}
		else
		{
			wndProgress.SetText(_T("Area Sorting"));
			if(!SortArea(i, nIndex, nTempIndex)) // SortArea(i) : nFidBlock ������ sort �ؾ� ������ --> ���߿� �� �ض� 20111206 bhlee
			{
				RemoveAreaList();
				wndProgress.SetParentWinActive();
				return FALSE;
			}
			nIndex = nTempIndex;
		}

		dWaitTime = myTime.PresentTime();
		TRACE(_T("Shrink & SortArea Time : %.3f\r\n"), dWaitTime);
		myTime.StartTime();
	}

	m_dLengFinal = 0;
	wndProgress.SetText(_T("Hole Sorting"));
	if(!SortAllField())
	{
		RemoveAreaList();
		wndProgress.SetParentWinActive();
		return FALSE;
	}

	GetHoleDistance();
	dWaitTime = myTime.PresentTime();
	TRACE(_T("SortAllField Time : %.3f\r\n"), dWaitTime);

	CPoint nptRefFid; // 20091029
	int nX, nY;
	if(FALSE == m_Glyphs.GetRefFidPos(nX, nY))
	{
		nptRefFid.x = nptRefFid.y =INT_MAX;
	}
	else
	{
		nptRefFid.x = nX;
		nptRefFid.y = nY;
	}

	if(nptRefFid.x == INT_MAX || nptRefFid != m_nptRefFidPos)
		m_nDataLoadStep = FIELD_DIVIED;
	else
		m_nDataLoadStep = FIELD_DIVIED + (m_nDataLoadStep & SET_FID_ORIGIN);

	m_bUnitDivide = !gProcessINI.m_sProcessSystem.bNoDivideUnit;

	UnSelectAll();
	wndProgress.SetParentWinActive();
	if(m_bArrayCopy)
		m_bArrayCopy = FALSE;
	return TRUE;
}

BOOL DProject::PuzzleOutOnlyAxisTrans()
{
	m_Glyphs.ChangeDataWithAxis(m_nAxisMode); // X_Y aixs �� ��� ��ȯ
	m_Glyphs.SortFiducial(DEFAULT_FID_INDEX);
	m_Glyphs.SortFiducial(ADDED_FID_INDEX);

	ChangeDataWithAxis();
	m_nAxisMode = X_Y;
	
	CPoint nptRefFid; // 20091029
	int nX, nY;
	if(FALSE == m_Glyphs.GetRefFidPos(nX, nY))
	{
		nptRefFid.x = nptRefFid.y =INT_MAX;
	}
	else
	{
		nptRefFid.x = nX;
		nptRefFid.y = nY;
	}
	
	if(nptRefFid.x == INT_MAX || nptRefFid != m_nptRefFidPos)
		m_nDataLoadStep = FIELD_DIVIED;
	else
		m_nDataLoadStep = FIELD_DIVIED + (m_nDataLoadStep & SET_FID_ORIGIN);

// 110727 Flip������ �ص� Selection �����ǵ���
//	UnSelectAll();
	return TRUE;
}

BOOL DProject::GetProximateArea(int nTool, int nFidBlock)
{
	//������ fiducial�� ����� Area ã��
	LPFIDDATA pFidData;
	int nAddProperty = FID_FIND;
	int nDelProperty = FID_VERIFY;
	int nFidCount = 0;
		
	nFidCount = m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, nAddProperty, nDelProperty, nFidBlock );
	pFidData = m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, nFidCount-1, nAddProperty, nDelProperty, nFidBlock);

	if(nFidCount == 0)
		return FALSE;
	//cal area center pos 
	POSITION pos, beforepos;
	DAreaInfo* pAreaInfo, *pNearArea;
	
	double dTempX, dTempY;
	int nIndex = -1, nNearIndex; 
	pos = m_Areas[nTool].GetHeadPosition();
	double dMinDist, dTempDist;
	while (pos) 
	{
		pAreaInfo = m_Areas[nTool].GetNext(pos);
		nIndex++;
		
		if(pAreaInfo->m_nFidBlock != nFidBlock && nFidBlock != -1)
			continue;

		dTempX = (pAreaInfo->m_nCenterX - pFidData->npPosition.x)/1000.;
		dTempY = (pAreaInfo->m_nCenterY - pFidData->npPosition.y)/1000.;
		dTempDist = sqrt((dTempX * dTempX) + (dTempY * dTempY));
		if(nIndex == 0)
		{
			dMinDist = dTempDist;	
			nNearIndex = nIndex;
			pNearArea = pAreaInfo;
		}
		else
		{
			if(dMinDist >= dTempDist)
			{
				dMinDist = dTempDist;
				nNearIndex = nIndex;
				pNearArea = pAreaInfo;
			}
		}
	}

	nIndex = 0;
	pos = m_Areas[nTool].GetHeadPosition();
	beforepos = pos;
	while(pos)
	{
		m_Areas[nTool].GetNext(pos);

		if(nIndex == nNearIndex)
		{
			m_Areas[nTool].RemoveAt(beforepos);
			break;
		}
		nIndex++;
		beforepos = pos;
	}

	m_Areas[nTool].AddHead(pNearArea);

	return TRUE;
		
}

BOOL DProject::SortArea(int nFidBlock , int nIndex, int &nRtIndex)
{
	TSP sortTSP;
	int nMaxNum = 0;
	AREA_SORT_DATA* pAreaInfoList = NULL;
	POSITION posArea, posBefore;
	DAreaInfo* pAreaInfo;
	int nCount, nAreaTotalNo;
	int nSortIndex;
//	double dRatio = 1;

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		if(m_Areas[i].GetCount() > nMaxNum)
			nMaxNum = m_Areas[i].GetCount();
	}
	if(nMaxNum)
	{
		pAreaInfoList = new AREA_SORT_DATA[nMaxNum];
	}

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
//		nAreaTotalNo = m_Areas[i].GetCount();
		nAreaTotalNo = 0; // �ش� �ʵ��� Area�� �ٽ� ���� 
		posArea = m_Areas[i].GetHeadPosition();
		while (posArea) 
		{
			pAreaInfo = m_Areas[i].GetNext(posArea);
			if(pAreaInfo->m_nFidBlock != nFidBlock && nFidBlock != -1)
				continue;
			nAreaTotalNo++;
		}
		
		if(nAreaTotalNo > 3)
		{
			GetProximateArea(i, nFidBlock);
			if(pAreaInfoList)
				memset(pAreaInfoList, NULL, sizeof(AREA_SORT_DATA) * nMaxNum);
				
			sortTSP.ResetSortData();
			sortTSP.SetSortCount(nAreaTotalNo);
			posArea = m_Areas[i].GetHeadPosition();
			nCount = 0;
			while (posArea) 
			{
				pAreaInfo = m_Areas[i].GetNext(posArea);
				if(pAreaInfo->m_nFidBlock != nFidBlock && nFidBlock != -1)
					continue;

				pAreaInfoList[nCount].pAreaInfo = pAreaInfo;
				nCount++;
				sortTSP.AddHole(pAreaInfo->m_nCenterX, pAreaInfo->m_nCenterY * gProcessINI.m_sProcessSystem.dSortAreaYRatio);
			}

			if(sortTSP.RunTSP()) // fail
			{
				continue;
			}
			////////////////////////////////////////////////////////////////////////////////////////////
			//check valid sort
			for(int j = 0; j < nAreaTotalNo; j++)
			{
				nSortIndex = sortTSP.m_pSortHoles[j].nIndex;
				pAreaInfoList[nSortIndex].bUsed = TRUE;
				pAreaInfoList[j].nSortIndex = nSortIndex;
			}
			
			BOOL bIsValid = TRUE;
			for(int j =  0; j < nAreaTotalNo; j++)
			{
				if(pAreaInfoList[j].bUsed == FALSE)
				{
					bIsValid = FALSE;
					break;
				}
			}
			//check valid sort end : bIsValid
			if(bIsValid)
			{
				posArea = m_Areas[i].GetHeadPosition();
				posBefore = posArea;
				while(posArea)
				{
					pAreaInfo = m_Areas[i].GetNext(posArea);
					if(nFidBlock == -1 || pAreaInfo->m_nFidBlock == nFidBlock)
					{
						m_Areas[i].RemoveAt(posBefore);
					}
					posBefore = posArea;
				}
				for(int j =  0; j < nAreaTotalNo; j++)
				{
					if(!pAreaInfoList[pAreaInfoList[j].nSortIndex].pAreaInfo->IsEmpty())
					{
						pAreaInfoList[ pAreaInfoList[j].nSortIndex ].pAreaInfo->m_nSortIndex = nIndex++;
						m_Areas[i].AddTail(pAreaInfoList[ pAreaInfoList[j].nSortIndex ].pAreaInfo);
					}
					else
					{
						delete pAreaInfoList[ pAreaInfoList[j].nSortIndex ].pAreaInfo;
						pAreaInfoList[ pAreaInfoList[j].nSortIndex ].pAreaInfo = NULL;
					}
				}
			}

			posArea = m_Areas[i].GetHeadPosition();
			posBefore = posArea;
			while(posArea)
			{
				pAreaInfo = m_Areas[i].GetNext(posArea);
				TRACE(_T("Fid Block : %d\n"), pAreaInfo->m_nFidBlock);
			}
		}
		else
		{
			if(pAreaInfoList)
				memset(pAreaInfoList, NULL, sizeof(AREA_SORT_DATA) * nMaxNum);

			nCount = 0;
			posArea = m_Areas[i].GetHeadPosition();
			while (posArea) 
			{
				pAreaInfo = m_Areas[i].GetNext(posArea);
				if(pAreaInfo->m_nFidBlock != nFidBlock && nFidBlock != -1)
					continue;
				pAreaInfoList[nCount].pAreaInfo = pAreaInfo;
				nCount++;
			}

			posArea = m_Areas[i].GetHeadPosition();
			posBefore = posArea;
			while(posArea)
			{
				pAreaInfo = m_Areas[i].GetNext(posArea);
				if(nFidBlock == -1 || pAreaInfo->m_nFidBlock == nFidBlock)
				{
					m_Areas[i].RemoveAt(posBefore);
				}
				posBefore = posArea;
			}
			
			for(int j = 0; j < nCount; j++)
			{
				if(!pAreaInfoList[j].pAreaInfo->IsEmpty())
				{
					pAreaInfoList[j].pAreaInfo->m_nSortIndex = nIndex++;
					m_Areas[i].AddTail(pAreaInfoList[j].pAreaInfo);
				}
				else
				{
					delete pAreaInfoList[j].pAreaInfo;
					pAreaInfoList[j].pAreaInfo = NULL;
				}
			}
		}
	}
	
	if(pAreaInfoList)
	{
		delete [] pAreaInfoList;
		pAreaInfoList = NULL;
	}

	nRtIndex = nIndex;
	return TRUE;
}



BOOL DProject::NumberingArea()
{
	int nMaxNum = 0;
	AREA_SORT_DATA* pAreaInfoList = NULL;
	POSITION posArea;
	DAreaInfo* pAreaInfo;
	int nCount, nAreaTotalNo, nValidCount = 0;

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		if(m_Areas[i].GetCount() > nMaxNum)
			nMaxNum = m_Areas[i].GetCount();
	}
	if(nMaxNum)
	{
		pAreaInfoList = new AREA_SORT_DATA[nMaxNum];
	}

	int nIndex = 0;

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		nAreaTotalNo = m_Areas[i].GetCount();

		if(nAreaTotalNo != 0)
			nValidCount++;
		if(pAreaInfoList)
			memset(pAreaInfoList, NULL, sizeof(AREA_SORT_DATA) * nMaxNum);
		
		nCount = 0;
		posArea = m_Areas[i].GetHeadPosition();
		while (posArea) 
		{
			pAreaInfo = m_Areas[i].GetNext(posArea);
			pAreaInfoList[nCount].pAreaInfo = pAreaInfo;
			nCount++;
		}

		for(int j = 0; j < nAreaTotalNo; j++)
		{
			pAreaInfoList[j].bUsed = TRUE;
		}
		
		BOOL bIsValid = TRUE;
		for(int j =  0; j < nAreaTotalNo; j++)
		{
			if(pAreaInfoList[j].bUsed == FALSE)
			{
				bIsValid = FALSE;
				break;
			}
		}
		//check valid sort end : bIsValid
		if(bIsValid)
		{
			m_Areas[i].RemoveAll();
			if(nValidCount % 2 == 1)
			{
				for(int j =  0; j < nAreaTotalNo; j++)
				{
					if(!pAreaInfoList[j].pAreaInfo->IsEmpty())
					{
						pAreaInfoList[j].pAreaInfo->m_nSortIndex = nIndex++;
						m_Areas[i].AddTail(pAreaInfoList[j].pAreaInfo);
					}
					else
					{
						delete pAreaInfoList[j].pAreaInfo;
						pAreaInfoList[j].pAreaInfo = NULL;
					}
				}
			}
			else if(nValidCount % 2 == 0)
			{
				for(int j =  nAreaTotalNo - 1; j >= 0; j--)
				{
					if(!pAreaInfoList[j].pAreaInfo->IsEmpty())
					{
						pAreaInfoList[j].pAreaInfo->m_nSortIndex = nIndex++;
						m_Areas[i].AddTail(pAreaInfoList[j].pAreaInfo);
					}
					else
					{
						delete pAreaInfoList[j].pAreaInfo;
						pAreaInfoList[j].pAreaInfo = NULL;
					}
				}
			}
		}
	}
	
	if(pAreaInfoList)
	{
		delete [] pAreaInfoList;
		pAreaInfoList = NULL;
	}
	
	return TRUE;
}

BOOL DProject::SortAllField()
{
	POSITION pos;
	DAreaInfo* pAreaInfo;
	HOLE_SORT_DATA* pHoleInfoList = NULL;
	LINE_SORT_DATA* pLineInfoList = NULL;

	// nMaxNum ���ϱ�
	int nMaxNum = 0, nMaxLineNum = 0;
	int nDivideCount = 0;
	int nOldDivideCount = 0;
	for(int i = ADDED_FID_TOOL + 1; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			for(int j = ADDED_FID_TOOL + 1; j < MAX_TOOL_NO; j++)
			{
				if(pAreaInfo->m_FireHoles[j].GetCount() > nMaxNum)
					nMaxNum = pAreaInfo->m_FireHoles[j].GetCount();
				if(pAreaInfo->m_FireLines[j].GetCount() > nMaxLineNum)
					nMaxLineNum = pAreaInfo->m_FireLines[j].GetCount();

				nDivideCount = (pAreaInfo->m_nMaxY - pAreaInfo->m_nMinY) / (gProcessINI.m_sProcessSystem.nHoleSortPitch*1000);
				if((pAreaInfo->m_nMaxY - pAreaInfo->m_nMinY) % (gProcessINI.m_sProcessSystem.nHoleSortPitch*1000) > 0)
					nDivideCount++;

				if(nOldDivideCount < nDivideCount)
					nOldDivideCount = nDivideCount;
			}
		}
	}
	nDivideCount = nOldDivideCount;

	// nMaxNum ���ϱ� ��
	if(nMaxNum)
		pHoleInfoList = new HOLE_SORT_DATA[nMaxNum + (nDivideCount*5)];  //Zigzag Sort�� Divide Area ���� 5���� Hole �� �߰��ϴϱ�
	if(nMaxLineNum)
		pLineInfoList = new LINE_SORT_DATA[nMaxLineNum];

	int nCount = 0;
	for(int i = ADDED_FID_TOOL + 1; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			if(!SortOneField(pAreaInfo, pHoleInfoList, pLineInfoList, nMaxNum + (nDivideCount*5), nMaxLineNum, nCount))
			{
				if(pHoleInfoList)
				{
					delete [] pHoleInfoList;
					pHoleInfoList = NULL;
				}
				if(pLineInfoList)
				{
					delete [] pLineInfoList;
					pLineInfoList = NULL;
				}
				return FALSE;
			}
			nCount++;
		}
	}

	if(pHoleInfoList)
	{
		delete [] pHoleInfoList;
		pHoleInfoList = NULL;
	}
	if(pLineInfoList)
	{
		delete [] pLineInfoList;
		pLineInfoList = NULL;
	}
	
	return TRUE;
}


BOOL DProject::GetCuttedAreaForZiazag(DAreaInfo *pAreaInfo, DAreaInfo *pCreateAreaInfo, int nIndex, int nTool, BOOL bRightDirection)
{

	int nDividePitch = gProcessINI.m_sProcessSystem.nHoleSortPitch*1000 -1;
	pCreateAreaInfo->m_nMinX = pAreaInfo->m_nMinX;
	pCreateAreaInfo->m_nMaxX = pAreaInfo->m_nMaxX;
	pCreateAreaInfo->m_nMinY = pAreaInfo->m_nMinY +( nDividePitch * nIndex);
	pCreateAreaInfo->m_nMaxY = pCreateAreaInfo->m_nMinY + nDividePitch;

	if(pCreateAreaInfo->m_nMaxY > pAreaInfo->m_nMaxY)
		pCreateAreaInfo->m_nMaxY = pAreaInfo->m_nMaxY;

	
	double dMinDist = 9999999, dCurDist, dX, dY;
	CPoint cpComparePos;
	//add virtual hole for sorting 
	int nHalfX = (int)gSystemINI.m_sSystemDevice.dFieldSize.x * 1000;
	int nHalfY = (int)gSystemINI.m_sSystemDevice.dFieldSize.x * 1000;
	int nOffsetX[2], nOffsetY[2];
	

	if(!bRightDirection)
	{
		cpComparePos.x = pCreateAreaInfo->m_nMinX;
		cpComparePos.y = pCreateAreaInfo->m_nMinY;
	}
	else
	{
		cpComparePos.x = pCreateAreaInfo->m_nMinX;
		cpComparePos.y = pCreateAreaInfo->m_nMinY;
	}
	POSITION pos;
	LPFIREHOLE pHole;
	int nCount = 0; 
	int nTemp = 0;
	for(int i = 1; i<MAX_TOOL_NO; i++)
	{
		if(!m_pToolCode[i]->m_bUseTool)
			continue;

		pos = pAreaInfo->m_FireHoles[nTool].GetHeadPosition();
		while (pos)
		{
			nTemp++;
			pHole = pAreaInfo->m_FireHoles[nTool].GetNext(pos);		
			if(pHole->pOrigin->npPos.x >= pCreateAreaInfo->m_nMinX && 
				pHole->pOrigin->npPos.x <= pCreateAreaInfo->m_nMaxX &&
				pHole->pOrigin->npPos.y >= pCreateAreaInfo->m_nMinY &&
				pHole->pOrigin->npPos.y <= pCreateAreaInfo->m_nMaxY )
			{
				
				LPFIREHOLE copyHole = new HOLECONVERTDATA;
				copyHole->bSelect = FALSE;
				copyHole->npPos1.x = pHole->npPos1.x;
				copyHole->npPos1.y = pHole->npPos1.y;
				copyHole->npPos2.x = pHole->npPos2.x;
				copyHole->npPos2.y = pHole->npPos2.y;
				
				LPHOLEDATA pOriHole = new HOLEDATA;

				pOriHole->bRotate		= pHole->pOrigin->bRotate;
				pOriHole->bSelect		= pHole->pOrigin->bSelect;
				pOriHole->nFidBlock	= pHole->pOrigin->nFidBlock;
				memcpy(pOriHole->nFidIndex, pHole->pOrigin->nFidIndex, sizeof(pHole->pOrigin->nFidIndex));
				pOriHole->npPos.x		= pHole->pOrigin->npPos.x;
				pOriHole->npPos.y		= pHole->pOrigin->npPos.y ;
				pOriHole->nRefNo		= pHole->pOrigin->nRefNo;
				pOriHole->nToolNo		= pHole->pOrigin->nToolNo;
				pOriHole->nUnitIndex	= pHole->pOrigin->nUnitIndex;
				copyHole->pOrigin = pOriHole;
				
					
				dX = cpComparePos.x - pOriHole->npPos.x;
				dY = cpComparePos.y - pOriHole->npPos.y;
			
			//	dX = cpComparePos.x - pHole->pOrigin->npPos.x;
			//	dY = cpComparePos.y - pHole->pOrigin->npPos.y;

				dCurDist = sqrt( dX * dX + dY * dY);

				if(dCurDist < dMinDist)
				{
					pCreateAreaInfo->m_FireHoles[i].AddHead(copyHole);
					dMinDist = dCurDist;
				}
				else
					pCreateAreaInfo->m_FireHoles[i].AddTail(copyHole);
				nCount++;
			}
		}
		if(nCount > 0)
		{
			if(bRightDirection)
			{
				nOffsetX[0] = pCreateAreaInfo->m_nMinX - 10;

				nOffsetY[0] = pCreateAreaInfo->m_nMaxY + 10;		
			}
			else
			{
				nOffsetX[0] = pCreateAreaInfo->m_nMinX - 10;

				nOffsetY[0] = pCreateAreaInfo->m_nMinY - 10;		
			}

			for(int k = 0; k < 1; k++)
			{

				LPFIREHOLE virHole = new HOLECONVERTDATA;
				LPHOLEDATA virOri = new HOLEDATA;

				virHole->bSelect = FALSE;
				virHole->npPos1.x = nOffsetX[k];
				virHole->npPos1.y = nOffsetY[k];
				virHole->npPos2.x = nOffsetX[k];
				virHole->npPos2.y = nOffsetY[k];

				virOri->bRotate		= FALSE;
				virOri->bSelect		= FALSE;
				virOri->nFidBlock	= -1;
				virOri->npPos.x		= nOffsetX[k];
				virOri->npPos.y		= nOffsetY[k];
				virHole->pOrigin = virOri;

				pCreateAreaInfo->m_FireHoles[i].AddHead(virHole);
			}

			if(bRightDirection)
			{
				nOffsetX[0] = pCreateAreaInfo->m_nMaxX + nHalfX;
				//			nOffsetX[1] = pCreateAreaInfo->m_nMaxX + nHalfX;


				//			nOffsetY[0] = pCreateAreaInfo->m_nMaxY;
				nOffsetY[0] = pCreateAreaInfo->m_nMaxY + nHalfY;
			}
			else
			{
				nOffsetX[0] = pCreateAreaInfo->m_nMinX - nHalfX;
				//			nOffsetX[1] = pCreateAreaInfo->m_nMinX - nHalfX;

				//			nOffsetY[0] = pCreateAreaInfo->m_nMaxY;
				nOffsetY[0] = pCreateAreaInfo->m_nMaxY + nHalfY;
			}


			for(int k =  0; k < 1; k++)
			{
				LPFIREHOLE virHole = new HOLECONVERTDATA;
				LPHOLEDATA virOri = new HOLEDATA;

				virHole->bSelect = FALSE;
				virHole->npPos1.x = nOffsetX[k];
				virHole->npPos1.y = nOffsetY[k];
				virHole->npPos2.x = nOffsetX[k];
				virHole->npPos2.y = nOffsetY[k];

				virOri->bRotate		= FALSE;
				virOri->bSelect		= FALSE;
				virOri->nFidBlock	= -1;
				virOri->npPos.x		= nOffsetX[k];
				virOri->npPos.y		= nOffsetY[k];
				virHole->pOrigin = virOri;

				pCreateAreaInfo->m_FireHoles[i].AddTail(virHole);
			}
		}
	}

	return TRUE;
}

BOOL DProject::GetCuttedAreaForTornado(DAreaInfo *pAreaInfo, DAreaInfo *pCreateAreaInfo, int nIndexX, int nIndexY, int nTool, BOOL bHorizontal)
{

	int nDividePitch = gProcessINI.m_sProcessSystem.nHoleSortPitch*1000;
	pCreateAreaInfo->m_nMinX = pAreaInfo->m_nMinX +( nDividePitch * nIndexX);
	pCreateAreaInfo->m_nMaxX = pCreateAreaInfo->m_nMinX + nDividePitch;
	pCreateAreaInfo->m_nMinY = pAreaInfo->m_nMinY +( nDividePitch * nIndexY);
	pCreateAreaInfo->m_nMaxY = pCreateAreaInfo->m_nMinY + nDividePitch;

	if(pCreateAreaInfo->m_nMaxY > pAreaInfo->m_nMaxY)
		pCreateAreaInfo->m_nMaxY = pAreaInfo->m_nMaxY;

	if(pCreateAreaInfo->m_nMaxX > pAreaInfo->m_nMaxX)
		pCreateAreaInfo->m_nMaxX = pAreaInfo->m_nMaxX;

	double dMinDist = 9999999, dCurDist, dX, dY;
	CPoint cpComparePos;
	//add virtual hole for sorting 
	int nHalfX = (int)gSystemINI.m_sSystemDevice.dFieldSize.x * 1000;
	int nHalfY = (int)gSystemINI.m_sSystemDevice.dFieldSize.x * 1000;
	
	cpComparePos.x = pCreateAreaInfo->m_nMinX;
	cpComparePos.y = pCreateAreaInfo->m_nMinY;

	POSITION pos;
	LPFIREHOLE pHole;
	int nCount = 0; 
	for(int i = 1; i<MAX_TOOL_NO; i++)
	{
		if(!m_pToolCode[i]->m_bUseTool)
			continue;

		pos = pAreaInfo->m_FireHoles[i].GetHeadPosition();
		while (pos)
		{
			pHole = pAreaInfo->m_FireHoles[i].GetNext(pos);		
			if(pHole->pOrigin->npPos.x > pCreateAreaInfo->m_nMinX && 
				pHole->pOrigin->npPos.x <= pCreateAreaInfo->m_nMaxX &&
				pHole->pOrigin->npPos.y > pCreateAreaInfo->m_nMinY &&
				pHole->pOrigin->npPos.y <= pCreateAreaInfo->m_nMaxY )
			{
				
				LPFIREHOLE copyHole = new HOLECONVERTDATA;
				copyHole->bSelect = FALSE;
				copyHole->npPos1.x = pHole->npPos1.x;
				copyHole->npPos1.y = pHole->npPos1.y;
				copyHole->npPos2.x = pHole->npPos2.x;
				copyHole->npPos2.y = pHole->npPos2.y;
				
				LPHOLEDATA pOriHole = new HOLEDATA;

				pOriHole->bRotate		= pHole->pOrigin->bRotate;
				pOriHole->bSelect		= pHole->pOrigin->bSelect;
				pOriHole->nFidBlock	= pHole->pOrigin->nFidBlock;
				memcpy(pOriHole->nFidIndex, pHole->pOrigin->nFidIndex, sizeof(pHole->pOrigin->nFidIndex));
				pOriHole->npPos.x		= pHole->pOrigin->npPos.x;
				pOriHole->npPos.y		= pHole->pOrigin->npPos.y ;
				pOriHole->nRefNo		= pHole->pOrigin->nRefNo;
				pOriHole->nToolNo		= pHole->pOrigin->nToolNo;
				pOriHole->nUnitIndex	= pHole->pOrigin->nUnitIndex;
				copyHole->pOrigin = pOriHole;
				
					
				dX = cpComparePos.x - pOriHole->npPos.x;
				dY = cpComparePos.y - pOriHole->npPos.y;
			
				dCurDist = sqrt( dX * dX + dY * dY);

				if(dCurDist < dMinDist)
				{
					pCreateAreaInfo->m_FireHoles[i].AddHead(copyHole);
					dMinDist = dCurDist;
				}
				else
					pCreateAreaInfo->m_FireHoles[i].AddTail(copyHole);
				nCount++;
			}
		}
/*
		if(bHorizontal)
		{
			nOffsetX[0] = pCreateAreaInfo->m_nMinX - 10;
			
			nOffsetY[0] = pCreateAreaInfo->m_nMaxY + 10;		
		}
		else
		{
			nOffsetX[0] = pCreateAreaInfo->m_nMinX - 10;
			
			nOffsetY[0] = pCreateAreaInfo->m_nMinY - 10;		
		}
		
		for(int k = 0; k < 1; k++)
		{
			
			LPFIREHOLE virHole = new HOLECONVERTDATA;
			LPHOLEDATA virOri = new HOLEDATA;
			
			virHole->bSelect = FALSE;
			virHole->npPos1.x = nOffsetX[k];
			virHole->npPos1.y = nOffsetY[k];
			virHole->npPos2.x = nOffsetX[k];
			virHole->npPos2.y = nOffsetY[k];
			
			virOri->bRotate		= FALSE;
			virOri->bSelect		= FALSE;
			virOri->nFidBlock	= -1;
			virOri->npPos.x		= nOffsetX[k];
			virOri->npPos.y		= nOffsetY[k];
			virHole->pOrigin = virOri;
			
			pCreateAreaInfo->m_FireHoles[i].AddHead(virHole);
		}

		if(bHorizontal)
		{
			nOffsetX[0] = pCreateAreaInfo->m_nMaxX + nHalfX;
//			nOffsetX[1] = pCreateAreaInfo->m_nMaxX + nHalfX;
			

//			nOffsetY[0] = pCreateAreaInfo->m_nMaxY;
			nOffsetY[0] = pCreateAreaInfo->m_nMaxY + nHalfY;
		}
		else
		{
			nOffsetX[0] = pCreateAreaInfo->m_nMinX - nHalfX;
//			nOffsetX[1] = pCreateAreaInfo->m_nMinX - nHalfX;
			
//			nOffsetY[0] = pCreateAreaInfo->m_nMaxY;
			nOffsetY[0] = pCreateAreaInfo->m_nMaxY + nHalfY;
		}


		for(int k =  0; k < 0; k++)
		{
			LPFIREHOLE virHole = new HOLECONVERTDATA;
			LPHOLEDATA virOri = new HOLEDATA;

			virHole->bSelect = FALSE;
			virHole->npPos1.x = nOffsetX[k];
			virHole->npPos1.y = nOffsetY[k];
			virHole->npPos2.x = nOffsetX[k];
			virHole->npPos2.y = nOffsetY[k];

			virOri->bRotate		= FALSE;
			virOri->bSelect		= FALSE;
			virOri->nFidBlock	= -1;
			virOri->npPos.x		= nOffsetX[k];
			virOri->npPos.y		= nOffsetY[k];
			virHole->pOrigin = virOri;
			
			pCreateAreaInfo->m_FireHoles[i].AddTail(virHole);
		}
		*/
	}

	return TRUE;
}

BOOL DProject::SortOneField(DAreaInfo *pAreaInfo, HOLE_SORT_DATA* pHoleInfoList, LINE_SORT_DATA* pLineInfoList, int nMaxNum, int nMaxLineNum, int nAreaNo)
{
	POSITION pos;
	LPFIREHOLE pHole;
	int nCurHoleNo, nTotalHole, nCutAreaHole, nDividedTotalHole;
	int nSortIndex;
	TSP sortTSP; 
	TSP saveLongDistTSP;
	BOOL bAllOK= TRUE;
	BOOL bRightDirection = TRUE;
	double dHoleDistance = 0.0;
	CPoint dSavePrevHole = 0;
	
	if(gProcessINI.m_sProcessSystem.nNoSortHole != NO_USE_SORT && pHoleInfoList != NULL)
	{
		for(int i = ADDED_FID_TOOL + 1; i < MAX_TOOL_NO; i++)
		{
			nCurHoleNo = 0;
			
			memset(pHoleInfoList, NULL, sizeof(HOLE_SORT_DATA) * nMaxNum);
			if(!m_pToolCode[i]->m_bUseTool)
				continue;

			if(gProcessINI.m_sProcessSystem.nNoSortHole == ZIGZAG_SORT)
			{
				nTotalHole = 0;
				int nDivideCount = (pAreaInfo->m_nMaxY - pAreaInfo->m_nMinY) / (gProcessINI.m_sProcessSystem.nHoleSortPitch*1000);
				if((pAreaInfo->m_nMaxY - pAreaInfo->m_nMinY) % (gProcessINI.m_sProcessSystem.nHoleSortPitch*1000) > 0)
					nDivideCount++;

				for(int nSortCount = 0; nSortCount < nDivideCount; ++nSortCount)
				{
					nCurHoleNo = 0;
					DAreaInfo* pHoleDivideAreaInfo = new DAreaInfo;

					GetCuttedAreaForZiazag(pAreaInfo, pHoleDivideAreaInfo, nSortCount, i, (nSortCount == 0)? TRUE:FALSE);

					nCutAreaHole = pHoleDivideAreaInfo->m_FireHoles[i].GetCount();

					if(nCutAreaHole <= 2)
						continue;
					else
						bRightDirection = !bRightDirection;


					nDividedTotalHole = nCutAreaHole;
					sortTSP.ResetSortData();
					sortTSP.SetSortCount(nDividedTotalHole);

					pos = pHoleDivideAreaInfo->m_FireHoles[i].GetHeadPosition();

					int nC = 0;
					while (pos)
					{
						pHole = pHoleDivideAreaInfo->m_FireHoles[i].GetNext(pos);
						
						pHoleInfoList[nTotalHole + nCurHoleNo++].pHole = pHole;
						sortTSP.AddHole(pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y);
						nC++;
					}
					
					if(sortTSP.RunTSP()) // fail
					{
						continue;
					}
					//check valid sort
					for(int j = 0; j < nDividedTotalHole; j++)
					{
						nSortIndex = sortTSP.m_pSortHoles[j].nIndex + nTotalHole;
						pHoleInfoList[nSortIndex].bUsed = TRUE;
						pHoleInfoList[j + nTotalHole].nSortIndex = nSortIndex;
					}
					nTotalHole += nDividedTotalHole;
				}
				BOOL bIsValid = TRUE;
				for(int j = 0; j < nTotalHole; j++)
				{
					if(pHoleInfoList[j].bUsed == FALSE)
					{
						bIsValid = FALSE;
						break;
					}
				}
				//check valid sort end : bIsValid
				if(bIsValid)
				{
				
					pAreaInfo->m_FireHoles[i].RemoveAll();
					for(int j = 0; j < nTotalHole; j++)
					{
						if(pHoleInfoList[ pHoleInfoList[j].nSortIndex ].pHole->pOrigin->npPos.x <= pAreaInfo->m_nMaxX &&
							pHoleInfoList[ pHoleInfoList[j].nSortIndex ].pHole->pOrigin->npPos.x >= pAreaInfo->m_nMinX &&
							pHoleInfoList[ pHoleInfoList[j].nSortIndex ].pHole->pOrigin->npPos.y <= pAreaInfo->m_nMaxY &&
							pHoleInfoList[ pHoleInfoList[j].nSortIndex ].pHole->pOrigin->npPos.y >= pAreaInfo->m_nMinY)
						{
							pAreaInfo->m_FireHoles[i].AddTail(pHoleInfoList[ pHoleInfoList[j].nSortIndex ].pHole);
						}
						
					}
				}
			}
			else if(gProcessINI.m_sProcessSystem.nNoSortHole == TONADO_SORT) // ������ ���� ���ô�~ ��� ���� ���ô�~ 
			{
				nTotalHole = 0;
				int nDivideCountX = (pAreaInfo->m_nMaxX - pAreaInfo->m_nMinX) / (gProcessINI.m_sProcessSystem.nHoleSortPitch*1000);
				if((pAreaInfo->m_nMaxX - pAreaInfo->m_nMinX) % (gProcessINI.m_sProcessSystem.nHoleSortPitch*1000) > 0)
					nDivideCountX++;

				int nDivideCountY = (pAreaInfo->m_nMaxY - pAreaInfo->m_nMinY) / (gProcessINI.m_sProcessSystem.nHoleSortPitch*1000);
				if((pAreaInfo->m_nMaxY - pAreaInfo->m_nMinY) % (gProcessINI.m_sProcessSystem.nHoleSortPitch*1000) > 0)
					nDivideCountY++;

				int nCurrentIndexX = 0, nCurrentIndexY = 0; //��ġ �ε���
				int nCountX = 0, nCountY = 0; // ������ �ٲ� �ѹ� �����ϴ� �ε��� 
				int nTotalCount = 0;
				BOOL bHorizontal = TRUE;
				BOOL bHorRightDirect = TRUE, bVerUpDirect = TRUE;
				
				while(nDivideCountX*nDivideCountY > nTotalCount )
				{	
				/*	nCurHoleNo = 0;
					DAreaInfo* pHoleDevideAreaInfo = new DAreaInfo;
					
					GetCuttedAreaForTornado(pAreaInfo, pHoleDevideAreaInfo, nCurrentIndexX, nCurrentIndexY, i, bHorizontal );
					
					nCutAreaHole = pHoleDevideAreaInfo->m_FireHoles[i].GetCount();
					
					if(nCutAreaHole < 1)
						continue;
									
					nDividedTotalHole = nCutAreaHole;
					sortTSP.ResetSortData();
					sortTSP.SetSortCount(nDividedTotalHole);
					
					pos = pHoleDevideAreaInfo->m_FireHoles[i].GetHeadPosition();
					while (pos)
					{
						pHole = pHoleDevideAreaInfo->m_FireHoles[i].GetNext(pos);
						
						pHoleInfoList[nTotalHole + nCurHoleNo++].pHole = pHole;
						sortTSP.AddHole(pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y);
						
					}
					
					if(sortTSP.RunTSP()) // fail
					{
						continue;
					}
					//check valid sort
					for(int j = 0; j < nDividedTotalHole; j++)
					{
						nSortIndex = sortTSP.m_pSortHoles[j].nIndex + nTotalHole;
						pHoleInfoList[nSortIndex].bUsed = TRUE;
						pHoleInfoList[j + nTotalHole].nSortIndex = nSortIndex;
					}
					nTotalHole += nDividedTotalHole;

*/
					//get index 
					if(bHorizontal)
					{
						if(bHorRightDirect)
						{
							if(nCurrentIndexX == nDivideCountX -nCountX -1 )
							{
								bHorizontal = FALSE;
								bHorRightDirect = FALSE;
								nCountX++;
								if(bVerUpDirect)
									nCurrentIndexY++;
								else
									nCurrentIndexY--;
								
							}
							else
								nCurrentIndexX++;
						}
						else
						{
							if(nCurrentIndexX == nCountX-1)
							{
								bHorizontal = FALSE;
								bHorRightDirect = TRUE;
								nCountX++;
								if(bVerUpDirect)
									nCurrentIndexY++;
								else
									nCurrentIndexY--;
							}
							else
								nCurrentIndexX--;
						}

					}
					else
					{
						if(	bVerUpDirect)
						{
							if(nCurrentIndexY == nDivideCountY - nCountY -1)
							{
								bHorizontal = TRUE;
								bVerUpDirect = FALSE;
								if(bHorRightDirect)
									nCurrentIndexX++;
								else
									nCurrentIndexX--;
								nCountY++;
							}
							else
								nCurrentIndexY++;
						}
						else
						{
							if(nCurrentIndexY == nCountY-1)
							{
								bHorizontal = TRUE;
								bVerUpDirect = TRUE;
								if(bHorRightDirect)
									nCurrentIndexX++;
								else
									nCurrentIndexX--;
								nCountY++;
							}
							else
								nCurrentIndexY--;
						}
					}
					nTotalCount++;
				}	
			//	nCount++;
				BOOL bIsValid = TRUE;
				for(int j = 0; j < nTotalHole; j++)
				{
					if(pHoleInfoList[j].bUsed == FALSE)
					{
						bIsValid = FALSE;
						break;
					}
				}
				//check valid sort end : bIsValid
				if(bIsValid)
				{
					// 				double dOldX, dOldY, dNewX, dNewY;
					pAreaInfo->m_FireHoles[i].RemoveAll();
					for(int j = 0; j < nTotalHole; j++)
					{
						if(pHoleInfoList[ pHoleInfoList[j].nSortIndex ].pHole->pOrigin->npPos.x <= pAreaInfo->m_nMaxX &&
							pHoleInfoList[ pHoleInfoList[j].nSortIndex ].pHole->pOrigin->npPos.x >= pAreaInfo->m_nMinX &&
							pHoleInfoList[ pHoleInfoList[j].nSortIndex ].pHole->pOrigin->npPos.y <= pAreaInfo->m_nMaxY &&
							pHoleInfoList[ pHoleInfoList[j].nSortIndex ].pHole->pOrigin->npPos.y >= pAreaInfo->m_nMinY)
						{
							pAreaInfo->m_FireHoles[i].AddTail(pHoleInfoList[ pHoleInfoList[j].nSortIndex ].pHole);
						}
						
					}
				}
			}
			else
			{
				// ���� �⺻ sorting �ǽ� (Ȧ�� �Ÿ��� ��Ȯ�� �˱� ����)
				nTotalHole = pAreaInfo->m_FireHoles[i].GetCount();
				if(nTotalHole <= 3)
					continue;

				sortTSP.ResetSortData();
				sortTSP.SetSortCount(nTotalHole);

				pos = pAreaInfo->m_FireHoles[i].GetHeadPosition();
				while (pos)
				{
					pHole = pAreaInfo->m_FireHoles[i].GetNext(pos);
					pHoleInfoList[nCurHoleNo++].pHole = pHole;
					sortTSP.AddHole(pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y);
				}

				if(sortTSP.RunTSP()) // fail
				{
					continue;
				}
				//check valid sort
				for(int j = 0; j < nTotalHole; j++)
				{
					nSortIndex = sortTSP.m_pSortHoles[j].nIndex;
					pHoleInfoList[nSortIndex].bUsed = TRUE;
					pHoleInfoList[j].nSortIndex = nSortIndex;
				}

				BOOL bIsValid = TRUE;
				for(int j =  0; j < nTotalHole; j++)
				{
					if(pHoleInfoList[j].bUsed == FALSE)
					{
						bIsValid = FALSE;
						break;
					}
				}
				//check valid sort end : bIsValid
				if(bIsValid)
				{
	// 				double dOldX, dOldY, dNewX, dNewY;
					pAreaInfo->m_FireHoles[i].RemoveAll();
					for(int j = 0; j < nTotalHole; j++)
					{
						pAreaInfo->m_FireHoles[i].AddTail(pHoleInfoList[ pHoleInfoList[j].nSortIndex ].pHole);

					}
				}

				memset(pHoleInfoList, NULL, sizeof(HOLE_SORT_DATA) * nMaxNum);

				// Ȧ�� �Ÿ� üũ �� sorting �ǽ�
				BOOL bFirstHole = TRUE;
				HOLE_SORT_DATA* pLongDistHoleList, *pTempHoleList;
				int	nDistOKHoleCnt = 0;
				int nDistNGHoleCnt = 0;
				int nStartCnt = 0;
				int nDistLimit = gProcessINI.m_sProcessSystem.nHoleDistancePitch;
				
				nTotalHole = pAreaInfo->m_FireHoles[i].GetCount();
				if(nTotalHole <= 3)
					continue;

				pLongDistHoleList = new HOLE_SORT_DATA[nTotalHole];
				pTempHoleList = new HOLE_SORT_DATA[nTotalHole];

				pos = pAreaInfo->m_FireHoles[i].GetHeadPosition();
				while (pos)
				{
					pHole = pAreaInfo->m_FireHoles[i].GetNext(pos);

					if(!bFirstHole)
					{
						dHoleDistance = sqrt((double)(pHole->pOrigin->npPos.x - dSavePrevHole.x) * (pHole->pOrigin->npPos.x - dSavePrevHole.x) + (pHole->pOrigin->npPos.y - dSavePrevHole.y) * (pHole->pOrigin->npPos.y - dSavePrevHole.y));
					}
					if(bFirstHole || dHoleDistance > nDistLimit)
					{
						bFirstHole = FALSE;
						pHoleInfoList[nDistOKHoleCnt++].pHole = pHole;
						dSavePrevHole.x = pHole->pOrigin->npPos.x;
						dSavePrevHole.y = pHole->pOrigin->npPos.y;
					}
					else
					{
						pLongDistHoleList[nDistNGHoleCnt++].pHole = pHole;
					}
				}

				int nStartHole = 0;
				while(TRUE)
				{
					if(nDistOKHoleCnt <= 3)
						break;

					sortTSP.ResetSortData();
					sortTSP.SetSortCount(nDistOKHoleCnt);
					 
					for(int nDistOK = nStartHole; nDistOK < nStartHole + nDistOKHoleCnt; nDistOK++)
					{
						sortTSP.AddHole(pHoleInfoList[nDistOK].pHole->pOrigin->npPos.x, 
							pHoleInfoList[nDistOK].pHole->pOrigin->npPos.y);
					}

					if(sortTSP.RunTSP()) // fail
					{
						continue;
					}

					for(int j = nStartHole; j < nStartHole + nDistOKHoleCnt; j++)
					{
						nSortIndex = sortTSP.m_pSortHoles[j - nStartHole].nIndex + nStartHole;
						pHoleInfoList[nSortIndex].bUsed = TRUE;
						pHoleInfoList[j].nSortIndex = nSortIndex;
					}

					bFirstHole = TRUE;
					int nNGTemp = 0;
					int nOKTemp = 0;

					nStartHole += nDistOKHoleCnt;
					nDistOKHoleCnt = 0;
					while(nOKTemp <= 3)
					{	
						memset(pTempHoleList, NULL, sizeof(HOLE_SORT_DATA) * nTotalHole);
						for(int nInput = 0; nInput < nDistNGHoleCnt; nInput++)
						{
							if(!bFirstHole)
							{
								dHoleDistance = sqrt((double)(pLongDistHoleList[nInput].pHole->pOrigin->npPos.x - dSavePrevHole.x) * (pLongDistHoleList[nInput].pHole->pOrigin->npPos.x - dSavePrevHole.x) + (pLongDistHoleList[nInput].pHole->pOrigin->npPos.y - dSavePrevHole.y) * (pLongDistHoleList[nInput].pHole->pOrigin->npPos.y - dSavePrevHole.y));
							}

							if(bFirstHole || dHoleDistance > nDistLimit)
							{
								bFirstHole = FALSE;
								pHoleInfoList[nStartHole + nOKTemp].pHole = pLongDistHoleList[nInput].pHole;
								dSavePrevHole.x = pLongDistHoleList[nInput].pHole->pOrigin->npPos.x;
								dSavePrevHole.y = pLongDistHoleList[nInput].pHole->pOrigin->npPos.y;
								nOKTemp++;
							}
							else
							{
								pTempHoleList[nNGTemp++].pHole = pLongDistHoleList[nInput].pHole;
							}
						}
						memset(pLongDistHoleList, NULL, sizeof(HOLE_SORT_DATA) * nTotalHole);
						for(int nNG = 0; nNG < nNGTemp; nNG++)
							pLongDistHoleList[nNG].pHole = pTempHoleList[nNG].pHole;

						if(nOKTemp <= 3)
						{
							nDistLimit /= 2;
							nDistOKHoleCnt += nOKTemp;	
							nDistNGHoleCnt = nNGTemp;	
							nNGTemp = 0;
						}
						else
						{
							nDistNGHoleCnt = nNGTemp;
							nDistOKHoleCnt = nOKTemp;	
						}

						if(nDistNGHoleCnt <= 3 && nDistOKHoleCnt <= 3)
							break;
					}
					if(nDistNGHoleCnt <= 3 && nDistOKHoleCnt <= 3)
					{
						for(int nNGtoOK = nDistNGHoleCnt; nNGtoOK > 0; nNGtoOK--)
						{
							pHoleInfoList[nTotalHole - nNGtoOK].pHole = pLongDistHoleList[nDistNGHoleCnt - nNGtoOK].pHole;
						}

						for(int nLast = nTotalHole - nDistOKHoleCnt - nDistNGHoleCnt; nLast < nTotalHole; nLast++)
						{
							pHoleInfoList[nLast].bUsed = TRUE;
							pHoleInfoList[nLast].nSortIndex = nLast;
						}
					}
				}
				delete[] pLongDistHoleList;
				pLongDistHoleList = NULL;
				delete[] pTempHoleList;
				pTempHoleList = NULL;

				bIsValid = TRUE;
				for(int j =  0; j < nTotalHole; j++)
				{
					if(pHoleInfoList[j].bUsed == FALSE)
					{
						bIsValid = FALSE;
						break;
					}
				}
				//check valid sort end : bIsValid
				if(bIsValid)
				{
					// 				double dOldX, dOldY, dNewX, dNewY;
					pAreaInfo->m_FireHoles[i].RemoveAll();
					for(int j = 0; j < nTotalHole; j++)
					{
						pAreaInfo->m_FireHoles[i].AddTail(pHoleInfoList[ pHoleInfoList[j].nSortIndex ].pHole);
					
					}
				}
			}
		} // end of for (tool) 
	}
	
	// sort line
	LPFIRELINE pLine, pOldLine;
	BOOL bStart = TRUE;
	int nCount = 0, nMinIndex;
	int nTotalLine;
	double dDist1, dDist2, dMinDist;
	CPoint tempP;
	
	if(!gProcessINI.m_sProcessSystem.bNoSortLine && pLineInfoList != NULL)
	{
		for(int i = ADDED_FID_TOOL + 1; i < MAX_TOOL_NO; i++)
		{
			bStart = TRUE;
			nTotalLine = pAreaInfo->m_FireLines[i].GetCount();
			if(m_ToolSumInfo[m_ToolSumInfo[i].nSameAreaToolNo].nToolAtri == emFlying)
				continue;

			if(nTotalLine <= 1)
				continue;
			memset(pLineInfoList, NULL, sizeof(LINE_SORT_DATA) * nMaxLineNum);

			nCount = 0;
			pos = pAreaInfo->m_FireLines[i].GetHeadPosition();
			while (pos) 
			{
				pLine = pAreaInfo->m_FireLines[i].GetNext(pos);
				pLineInfoList[nCount++].pLine = pLine;
			}
			pAreaInfo->m_FireLines[i].RemoveAll();

			for(int j = 0; j < nCount; j++)
			{
				if( j == 0)
				{
					pAreaInfo->m_FireLines[i].AddTail(pLineInfoList[j].pLine);
					pOldLine = pLineInfoList[j].pLine;
					pLineInfoList[j].bUsed = TRUE;
				}
				else
				{
					nMinIndex = -1;
					dMinDist = 1000000000000000000;
					for(int k = 0; k < nCount; k++)
					{
						if(pLineInfoList[k].bUsed)
							continue;
						dDist1 = (double)(pLineInfoList[k].pLine->npStartPos.x - pOldLine->npEndPos.x) *
							(double)(pLineInfoList[k].pLine->npStartPos.x - pOldLine->npEndPos.x) +
							(double)(pLineInfoList[k].pLine->npStartPos.y - pOldLine->npEndPos.y) *
							(double)(pLineInfoList[k].pLine->npStartPos.y - pOldLine->npEndPos.y);
						dDist2 = (double)(pLineInfoList[k].pLine->npEndPos.x - pOldLine->npEndPos.x) *
							(double)(pLineInfoList[k].pLine->npEndPos.x - pOldLine->npEndPos.x) +
							(double)(pLineInfoList[k].pLine->npEndPos.y - pOldLine->npEndPos.y) *
							(double)(pLineInfoList[k].pLine->npEndPos.y - pOldLine->npEndPos.y);
						if(dDist1 < dDist2)
						{
							pLineInfoList[k].bChange = FALSE;
							if(dDist1 < dMinDist)
							{
								dMinDist = dDist1;
								nMinIndex = k;
							}
						}
						else
						{
							pLineInfoList[k].bChange = TRUE;
							if(dDist2 < dMinDist)
							{
								dMinDist = dDist2;
								nMinIndex = k;
							}
						}
					}
					if(nMinIndex == -1)
					{
						// error
						pAreaInfo->m_FireLines[i].RemoveAll();
						for(int k = 0; k < nCount; k++)
						{
							pAreaInfo->m_FireLines[i].AddTail(pLineInfoList[k].pLine);
						}
						break;
					}
					else
					{
						pAreaInfo->m_FireLines[i].AddTail(pLineInfoList[nMinIndex].pLine);
						pOldLine = pLineInfoList[nMinIndex].pLine;
						pLineInfoList[nMinIndex].bUsed = TRUE;
						if(pLineInfoList[nMinIndex].bChange)
						{
							tempP = pLineInfoList[nMinIndex].pLine->npStartPos;
							pLineInfoList[nMinIndex].pLine->npStartPos = pLineInfoList[nMinIndex].pLine->npEndPos;
							pLineInfoList[nMinIndex].pLine->npEndPos = tempP;
						}
					}
				}
			}

			if(nTotalLine != pAreaInfo->m_FireLines[i].GetCount())
			{
				// error
				pAreaInfo->m_FireLines[i].RemoveAll();
				for(int k = 0; k < nCount; k++)
				{
					pAreaInfo->m_FireLines[i].AddTail(pLineInfoList[k].pLine);
				}
				break;
			}

		}

	}

	return TRUE;
}


BOOL DProject::ShrinkArea(int nFidBlock)
{
	POSITION pos, beforepos, dataPos;
	DAreaInfo* pAreaInfo;
	LPFIREHOLE pHole;
	LPFIRELINE pLine;
	int nMaxX, nMaxY, nMinX, nMinY, nIndex;
	CPoint pt;

	nMaxX = nMaxY = INT_MIN;
	nMinX = nMinY = INT_MAX;
	pos = m_Areas[ADDED_FID_TOOL].GetHeadPosition(); // skiving data
	beforepos = pos;
	while (pos) 
	{
		nMaxX = nMaxY = INT_MIN;
		nMinX = nMinY = INT_MAX;
		pAreaInfo = m_Areas[ADDED_FID_TOOL].GetNext(pos);

		if(nFidBlock != -1 && pAreaInfo->m_nFidBlock != nFidBlock)
		{
			beforepos = pos; continue;
		}
		if(pAreaInfo->m_FireHoles[ADDED_FID_TOOL].GetCount() == 0)
		{
			delete pAreaInfo;
			m_Areas[ADDED_FID_TOOL].RemoveAt(beforepos);
		}
		else
		{
			dataPos = pAreaInfo->m_FireHoles[ADDED_FID_TOOL].GetHeadPosition();
			while (dataPos)
			{
				pHole = pAreaInfo->m_FireHoles[ADDED_FID_TOOL].GetNext(dataPos);
				nIndex = (int)(pHole->pOrigin); // ���� ������ hole�� ��� m_FidData[]�� index�� �����߾���.
				pt = m_Glyphs.GetUseFidIntPoint(DEFAULT_FID_INDEX, nIndex); //ADDED_FID_INDEX, nIndex);
				if(pt.x > nMaxX) nMaxX = pt.x;
				if(pt.x < nMinX) nMinX = pt.x;
				if(pt.y > nMaxY) nMaxY = pt.y;
				if(pt.y < nMinY) nMinY = pt.y;
			}
			pAreaInfo->m_nMinX = nMinX;
			pAreaInfo->m_nMaxX = nMaxX;
			pAreaInfo->m_nMinY = nMinY;
			pAreaInfo->m_nMaxY = nMaxY;
			if(pAreaInfo->m_nMinX == pAreaInfo->m_nMaxX)
			{
				pAreaInfo->m_nMinX -= 1000;
				pAreaInfo->m_nMaxX += 1000;
			}
			if(pAreaInfo->m_nMinY == pAreaInfo->m_nMaxY)
			{
				pAreaInfo->m_nMinY -= 1000;
				pAreaInfo->m_nMaxY += 1000;
			}
			pAreaInfo->m_nCenterX = (pAreaInfo->m_nMinX + pAreaInfo->m_nMaxX) / 2;
			pAreaInfo->m_nCenterY = (pAreaInfo->m_nMinY + pAreaInfo->m_nMaxY) / 2;
		}
		beforepos = pos;
	}
	
	for(int i = ADDED_FID_TOOL + 1; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		beforepos = pos;
		while (pos) 
		{
			nMaxX = nMaxY = INT_MIN;
			nMinX = nMinY = INT_MAX;
			pAreaInfo = m_Areas[i].GetNext(pos);
			if(nFidBlock != -1 && pAreaInfo->m_nFidBlock != nFidBlock)
			{
				beforepos = pos; continue;
			}
			if(pAreaInfo->IsEmpty())
			{
				delete pAreaInfo;
				m_Areas[i].RemoveAt(beforepos);
			}
			else
			{
				for(int j = ADDED_FID_TOOL + 1; j < MAX_TOOL_NO; j++)
				{
					dataPos = pAreaInfo->m_FireHoles[j].GetHeadPosition();
					while (dataPos)
					{
						pHole = pAreaInfo->m_FireHoles[j].GetNext(dataPos);
						nIndex = (int)(pHole->pOrigin); // test
						if(pHole->pOrigin->npPos.x > nMaxX) nMaxX = pHole->pOrigin->npPos.x;
						if(pHole->pOrigin->npPos.x < nMinX) nMinX = pHole->pOrigin->npPos.x;
						if(pHole->pOrigin->npPos.y > nMaxY) nMaxY = pHole->pOrigin->npPos.y;
						if(pHole->pOrigin->npPos.y < nMinY) nMinY = pHole->pOrigin->npPos.y;
					}
				}
				for(int j =  ADDED_FID_TOOL + 1; j < MAX_TOOL_NO; j++)
				{
					dataPos = pAreaInfo->m_FireLines[j].GetHeadPosition();
					while (dataPos)
					{
						pLine = pAreaInfo->m_FireLines[j].GetNext(dataPos);
						if(pLine->npStartPos.x > nMaxX) nMaxX = pLine->npStartPos.x;
						if(pLine->npStartPos.x < nMinX) nMinX = pLine->npStartPos.x;
						if(pLine->npEndPos.x > nMaxX) nMaxX = pLine->npEndPos.x;
						if(pLine->npEndPos.x < nMinX) nMinX = pLine->npEndPos.x;
						if(pLine->npStartPos.y > nMaxY) nMaxY = pLine->npStartPos.y;
						if(pLine->npStartPos.y < nMinY) nMinY = pLine->npStartPos.y;
						if(pLine->npEndPos.y > nMaxY) nMaxY = pLine->npEndPos.y;
						if(pLine->npEndPos.y < nMinY) nMinY = pLine->npEndPos.y;
					}
					pAreaInfo->m_nMinX = nMinX;
					pAreaInfo->m_nMaxX = nMaxX;
					pAreaInfo->m_nMinY = nMinY;
					pAreaInfo->m_nMaxY = nMaxY;
					if(pAreaInfo->m_nMinX == pAreaInfo->m_nMaxX)
					{
						pAreaInfo->m_nMinX -= 1000;
						pAreaInfo->m_nMaxX += 1000;
					}
					if(pAreaInfo->m_nMinY == pAreaInfo->m_nMaxY)
					{
						pAreaInfo->m_nMinY -= 1000;
						pAreaInfo->m_nMaxY += 1000;
					}
					pAreaInfo->m_nCenterX = (pAreaInfo->m_nMinX + pAreaInfo->m_nMaxX) / 2;
					pAreaInfo->m_nCenterY = (pAreaInfo->m_nMinY + pAreaInfo->m_nMaxY) / 2;
				}
			}
			beforepos = pos;
		}
	}
	return TRUE;
}



BOOL DProject::GetSubTool(int nTool, int nSubIndex, SUBTOOLDATA &subTool)
{
	SUBTOOLDATA ToolData;
	POSITION pos;
	int nCount = 0;
	pos = m_pToolCode[nTool]->m_SubToolData.GetHeadPosition();
	while (pos) 
	{
		ToolData = m_pToolCode[nTool]->m_SubToolData.GetNext(pos);
		if(nCount == nSubIndex)
		{
			memcpy(&subTool, &ToolData, sizeof(SUBTOOLDATA));
			return TRUE;
		}
		nCount++;
	}
	return FALSE;
}

int DProject::CalculateFidScale(BOOL b1stPanel, int nFidNo)
{
#ifndef __KUNSAN_SAMSUNG_LARGE__ // samsung large �ƴ� ��쿡�� scale�� ���� ��Ű�� �ʴ´�.
	return 0;
#endif

	if(nFidNo < 4)
		return 0;

	memset(m_npNewOffset, NULL, sizeof(m_npNewOffset));

	double dRefLength, dTransLength, dNewLength, dScale, dOriScale;
	DPOINT ptRefCenter, ptTransCenter, ptRefFid, ptTransFid, ptNew;

	double dLimit1Min = min(m_dScaleLimitX1Minus, m_dScaleLimitY1Minus);
	double dLimit1Max = max(m_dScaleLimitX1Pluse, m_dScaleLimitY1Pluse);
	double dLimit2Min = min(m_dScaleLimitX2Minus, m_dScaleLimitY2Minus);
	double dLimit2Max = max(m_dScaleLimitX2Pluse, m_dScaleLimitY2Pluse);

	BOOL bPanel = !b1stPanel;

	// �� �밢���� ������ �߽� ���ϰ�
//	ptRefCenter = GetQuadrangleCenter(b1stPanel, TRUE, nFidCount);
//	ptTransCenter = GetQuadrangleCenter(b1stPanel, FALSE, nFidCount);
	DPOINT ptTemp1, ptTemp2;
	
	BOOL bChange = FALSE;
	BOOL bReturnVal = FALSE;
	int nFidCount;
	
	// ������ǥ�� ������ǥ scale ���ϰ�, ������ǥ ����
	for(int j=0; j<=m_nMaxFidBlock; j++)  // fid block ���� ��ŭ
	{
		bChange = FALSE;
		nFidCount = m_RefTrans[bPanel][j].GetNumPoint();

		if(!m_RefTrans[bPanel][j].m_bUseScaleLimit) // skip
		{
			CString strFile, strFidOffset; // 20130312
			strFile.Format(_T("FidSkipData"));
			strFidOffset.Format(_T("Panel %d , Block %d is disable to check scale limit"), bPanel, j);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
			continue;
		}

		for(int i=0; i<nFidCount; i++)
		{
			ptRefFid.x = m_RefTrans[bPanel][j].GetRefsPoint(i).x;
			ptRefFid.y = m_RefTrans[bPanel][j].GetRefsPoint(i).y;

			ptTransFid.x = m_RefTrans[bPanel][j].GetTransPoint(i).x;
			ptTransFid.y = m_RefTrans[bPanel][j].GetTransPoint(i).y;

			if(i==0 || i==2)
			{ 
				ptTemp1.x = m_RefTrans[bPanel][j].GetRefsPoint(0).x;
				ptTemp1.y = m_RefTrans[bPanel][j].GetRefsPoint(0).y;

				ptTemp2.x = m_RefTrans[bPanel][j].GetRefsPoint(2).x;
				ptTemp2.y = m_RefTrans[bPanel][j].GetRefsPoint(2).y;

				ptRefCenter.x = (ptTemp1.x + ptTemp2.x) / 2.0;
				ptRefCenter.y = (ptTemp1.y + ptTemp2.y) / 2.0;

				ptTemp1.x = m_RefTrans[bPanel][j].GetTransPoint(0).x;
				ptTemp1.y = m_RefTrans[bPanel][j].GetTransPoint(0).y;

				ptTemp2.x = m_RefTrans[bPanel][j].GetTransPoint(2).x;
				ptTemp2.y = m_RefTrans[bPanel][j].GetTransPoint(2).y;

				ptTransCenter.x = (ptTemp1.x + ptTemp2.x) / 2.0;
				ptTransCenter.y = (ptTemp1.y + ptTemp2.y) / 2.0;
			}
			else
			{
				ptTemp1.x = m_RefTrans[bPanel][j].GetRefsPoint(1).x;
				ptTemp1.y = m_RefTrans[bPanel][j].GetRefsPoint(1).y;

				ptTemp2.x = m_RefTrans[bPanel][j].GetRefsPoint(3).x;
				ptTemp2.y = m_RefTrans[bPanel][j].GetRefsPoint(3).y;

				ptRefCenter.x = (ptTemp1.x + ptTemp2.x) / 2.0;
				ptRefCenter.y = (ptTemp1.y + ptTemp2.y) / 2.0;

				ptTemp1.x = m_RefTrans[bPanel][j].GetTransPoint(1).x;
				ptTemp1.y = m_RefTrans[bPanel][j].GetTransPoint(1).y;

				ptTemp2.x = m_RefTrans[bPanel][j].GetTransPoint(3).x;
				ptTemp2.y = m_RefTrans[bPanel][j].GetTransPoint(3).y;

				ptTransCenter.x = (ptTemp1.x + ptTemp2.x) / 2.0;
				ptTransCenter.y = (ptTemp1.y + ptTemp2.y) / 2.0;
			}
			
			dRefLength = GetDistance(ptRefCenter.x, ptRefCenter.y, ptRefFid.x, ptRefFid.y);

			dTransLength = GetDistance(ptTransCenter.x, ptTransCenter.y, ptTransFid.x, ptTransFid.y);

			dOriScale = dTransLength / dRefLength;
			dScale = dOriScale * 100.0;

			if(m_nScaleMode == 0) // AutoScale
			{
				if( dScale >= dLimit1Min && dScale <= dLimit1Max )
				{
					continue;
				}
				else if( dScale < dLimit2Min || dScale > dLimit2Max )
				{
#ifndef __TEST__
					return -1;
#endif
				}
				else
				{
					CString strFile, strFidOffset; // 20130312
					strFile.Format(_T("FidModifyData"));
					strFidOffset.Format(_T("Fiducial Info. is changed : Auto Scale : CalScale"));
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));

					if(dScale > 100.0)
					{
						ptNew.x = (ptTransFid.x - ptTransCenter.x) / dTransLength * (dLimit1Max / 100.0 * dRefLength) + ptTransCenter.x;
						ptNew.y = (ptTransFid.y - ptTransCenter.y) / dTransLength * (dLimit1Max / 100.0 * dRefLength) + ptTransCenter.y;
						dNewLength = GetDistance(ptTransCenter.x, ptTransCenter.y, ptNew.x, ptNew.y);
	
						m_npNewOffset[j][i].x = (long)(ptNew.x - ptTransFid.x);
						m_npNewOffset[j][i].y = (long)(ptNew.y - ptTransFid.y);
	
						bChange = TRUE;
						bReturnVal = TRUE;
					}
					else
					{
						ptNew.x = (ptTransFid.x - ptTransCenter.x) / dTransLength * (dLimit1Min / 100.0 * dRefLength) + ptTransCenter.x;
						ptNew.y = (ptTransFid.y - ptTransCenter.y) / dTransLength * (dLimit1Min / 100.0 * dRefLength) + ptTransCenter.y;
						dNewLength = GetDistance(ptTransCenter.x, ptTransCenter.y, ptNew.x, ptNew.y);
	
	
	
						m_npNewOffset[j][i].x = (long)(ptNew.x - ptTransFid.x);
						m_npNewOffset[j][i].y = (long)(ptNew.y - ptTransFid.y);
	
						bChange = TRUE;
						bReturnVal = TRUE;
					}
				}
			}
			else // ManualScale
			{
				CString strFile, strFidOffset; // 20130312
				strFile.Format(_T("FidModifyData"));
				strFidOffset.Format(_T("Fiducial Info. is changed : CalScale"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));

				ptNew.x = (ptTransFid.x - ptTransCenter.x) / dTransLength * (m_dScaleManual / 100.0 * dRefLength) + ptTransCenter.x;
				ptNew.y = (ptTransFid.y - ptTransCenter.y) / dTransLength * (m_dScaleManual / 100.0 * dRefLength) + ptTransCenter.y;
				dNewLength = GetDistance(ptTransCenter.x, ptTransCenter.y, ptNew.x, ptNew.y);
	
				m_npNewOffset[j][i].x = (long)(ptNew.x - ptTransFid.x);
				m_npNewOffset[j][i].y = (long)(ptNew.y - ptTransFid.y);
	
				bChange = TRUE;
				bReturnVal = TRUE;
			}
		}
		// apply new
		if(bChange)
		{
			CString strFile, strFidOffset; // 20130312
			strFile.Format(_T("FidModifyData"));

			strFidOffset.Format(_T("Block %d | Panel %d"), j, bPanel);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
			for(int i=0; i<nFidCount; i++)
			{
				ptRefFid.x = m_RefTrans[bPanel][j].GetRefsPoint(i).x;
				ptRefFid.y = m_RefTrans[bPanel][j].GetRefsPoint(i).y;
				ptTransFid.x = m_RefTrans[bPanel][j].GetTransPoint(i).x;
				ptTransFid.y = m_RefTrans[bPanel][j].GetTransPoint(i).y;

				strFidOffset.Format(_T("Fid %d | File PosX %d | Find PosX %d | Change PosX %d | File PosY %d | Find PosY %d | Change PosY %d"), i,
									(int)ptRefFid.x, (int)ptTransFid.x, (int)ptTransFid.x + (int)m_npNewOffset[j][i].x,
									(int)ptRefFid.y, (int)ptTransFid.y, (int)ptTransFid.y + (int)m_npNewOffset[j][i].y);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));

				m_RefTrans[bPanel][j].SetTransformedPoint(ptTransFid.x + m_npNewOffset[j][i].x, 
														  ptTransFid.y + m_npNewOffset[j][i].y, i);
			}
			strFidOffset.Format(_T("\t"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		}

	}
	return bReturnVal;
}

double DProject::GetFidScale(BOOL b1stPanel, int nFidIndex)
{
	double dRefLength, dTransLength, dScale, dOriScale;
	DPOINT ptRefCenter, ptTransCenter, ptRefFid, ptTransFid;

	BOOL bPanel = !b1stPanel;

	// �� �밢���� ������ �߽� ���ϰ�

	DPOINT ptTemp1, ptTemp2;
	
	BOOL bChange = FALSE;
	int nFidCount = m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);
	int nFidBlock = m_Glyphs.GetFidBlockStatus(DEFAULT_FID_INDEX, nFidIndex);
	// ������ǥ�� ������ǥ scale ���ϰ�, ������ǥ ����


		ptRefFid.x = m_RefTrans[bPanel][nFidBlock - 1].GetRefsPoint(nFidIndex).x;
		ptRefFid.y = m_RefTrans[bPanel][nFidBlock - 1].GetRefsPoint(nFidIndex).y;

		ptTransFid.x = m_RefTrans[bPanel][nFidBlock - 1].GetTransPoint(nFidIndex).x;
		ptTransFid.y = m_RefTrans[bPanel][nFidBlock - 1].GetTransPoint(nFidIndex).y;

		if(nFidIndex==0 || nFidIndex==2)
		{ 
			ptTemp1.x = m_RefTrans[bPanel][nFidBlock - 1].GetRefsPoint(0).x;
			ptTemp1.y = m_RefTrans[bPanel][nFidBlock - 1].GetRefsPoint(0).y;

			ptTemp2.x = m_RefTrans[bPanel][nFidBlock - 1].GetRefsPoint(2).x;
			ptTemp2.y = m_RefTrans[bPanel][nFidBlock - 1].GetRefsPoint(2).y;

			ptRefCenter.x = (ptTemp1.x + ptTemp2.x) / 2.0;
			ptRefCenter.y = (ptTemp1.y + ptTemp2.y) / 2.0;

			ptTemp1.x = m_RefTrans[bPanel][nFidBlock - 1].GetTransPoint(0).x;
			ptTemp1.y = m_RefTrans[bPanel][nFidBlock - 1].GetTransPoint(0).y;

			ptTemp2.x = m_RefTrans[bPanel][nFidBlock - 1].GetTransPoint(2).x;
			ptTemp2.y = m_RefTrans[bPanel][nFidBlock - 1].GetTransPoint(2).y;

			ptTransCenter.x = (ptTemp1.x + ptTemp2.x) / 2.0;
			ptTransCenter.y = (ptTemp1.y + ptTemp2.y) / 2.0;
		}
		else
		{
			ptTemp1.x = m_RefTrans[bPanel][nFidBlock - 1].GetRefsPoint(1).x;
			ptTemp1.y = m_RefTrans[bPanel][nFidBlock - 1].GetRefsPoint(1).y;

			ptTemp2.x = m_RefTrans[bPanel][nFidBlock - 1].GetRefsPoint(3).x;
			ptTemp2.y = m_RefTrans[bPanel][nFidBlock - 1].GetRefsPoint(3).y;

			ptRefCenter.x = (ptTemp1.x + ptTemp2.x) / 2.0;
			ptRefCenter.y = (ptTemp1.y + ptTemp2.y) / 2.0;

			ptTemp1.x = m_RefTrans[bPanel][nFidBlock - 1].GetTransPoint(1).x;
			ptTemp1.y = m_RefTrans[bPanel][nFidBlock - 1].GetTransPoint(1).y;

			ptTemp2.x = m_RefTrans[bPanel][nFidBlock - 1].GetTransPoint(3).x;
			ptTemp2.y = m_RefTrans[bPanel][nFidBlock - 1].GetTransPoint(3).y;

			ptTransCenter.x = (ptTemp1.x + ptTemp2.x) / 2.0;
			ptTransCenter.y = (ptTemp1.y + ptTemp2.y) / 2.0;
		}
		
		dRefLength = GetDistance(ptRefCenter.x, ptRefCenter.y, ptRefFid.x, ptRefFid.y);

		dTransLength = GetDistance(ptTransCenter.x, ptTransCenter.y, ptTransFid.x, ptTransFid.y);

		if(dRefLength == 0 || dTransLength == 0)
			dScale = 0;
		else
		{
			dOriScale = dTransLength / dRefLength;
			dScale = dOriScale * 100.0;
		}
		return dScale;
}

BOOL DProject::CalculateFidAngle(BOOL b1stPanel, int nFidNo) // ������ �˻簡 �ǹ�
{
	BOOL bPanel = !b1stPanel;
	DPOINT	dpVPos[4], dpRealPos[4];
	int nFidCount;
	
	for(int j=0; j<=m_nMaxFidBlock; j++) //fid block ���� ��ŭ 
	{
		nFidCount = m_RefTrans[bPanel][j].GetNumPoint();
		if(nFidCount < 4) // 4�� �϶��� ������ �˻簡 �ǹ̰� ����
			continue;

		for(int i=0; i<nFidCount; i++)
		{
			dpVPos[i].x = m_RefTrans[bPanel][j].GetRefsPoint(i).x; 
			dpVPos[i].y = m_RefTrans[bPanel][j].GetRefsPoint(i).y;
			dpRealPos[i].x = m_RefTrans[bPanel][j].GetTransPoint(i).x; 
			dpRealPos[i].y = m_RefTrans[bPanel][j].GetTransPoint(i).y;
		}	
		
		if(!ValidateRotateFiducial(dpVPos[1], dpVPos[0], dpVPos[2],	dpRealPos[1], dpRealPos[0], dpRealPos[2]))
			return FALSE;
		
		if(!ValidateRotateFiducial(dpVPos[2], dpVPos[1], dpVPos[3],	dpRealPos[2], dpRealPos[1], dpRealPos[3]))
			return FALSE;
		
		if(!ValidateRotateFiducial(dpVPos[3], dpVPos[2], dpVPos[0],	dpRealPos[3], dpRealPos[2], dpRealPos[0]))
			return FALSE;
		
		if(!ValidateRotateFiducial(dpVPos[0], dpVPos[3], dpVPos[1],	dpRealPos[0], dpRealPos[3], dpRealPos[1]))
			return FALSE;
	}

	return TRUE;
}

BOOL DProject::ValidateRotateFiducial(DPOINT rP1, DPOINT rP2, DPOINT rP3, DPOINT transP1, DPOINT transP2, DPOINT transP3)
{
	double dOffsetX, dOffsetY;
	dOffsetX = transP1.x - rP1.x;
	dOffsetY = transP1.y - rP1.y;
	
	DPOINT rP2_trans;
	CDPoint rP3_trans, P_Center;
	
	rP2_trans.x = rP2.x + dOffsetX;
	rP2_trans.y = rP2.y + dOffsetY;
	
	double dAngle1 = atan2(rP2_trans.y - transP1.y , rP2_trans.x - transP1.x);
	double dAngle2 = atan2(transP2.y - transP1.y , transP2.x - transP1.x);
	double dTheta = dAngle2 - dAngle1;
	
	P_Center.x = transP1.x;
	P_Center.y = transP1.y;
	
	rP3_trans.x = rP3.x + dOffsetX;
	rP3_trans.y = rP3.y + dOffsetY;
	
	double cosTheta, sinTheta;
	double tempx;
	
	cosTheta = cos(dTheta);
	sinTheta = sin(dTheta);
	tempx =	cosTheta * (rP3_trans.x - P_Center.x) - sinTheta * (rP3_trans.y - P_Center.y) + P_Center.x;
	rP3_trans.y = sinTheta * (rP3_trans.x - P_Center.x) + cosTheta * (rP3_trans.y - P_Center.y) + P_Center.y;
	rP3_trans.x = tempx;
	
	double dDist;	
	if(fabs(rP1.x - rP2.x) > fabs(rP1.y - rP2.y)) 
		dDist = fabs(rP3_trans.x - transP3.x);
	else
		dDist = fabs(rP3_trans.y - transP3.y);
	
	double dFidError = gProcessINI.m_sProcessFidFind.dFidAngleLimit * 1000.0;
		
	if(dFidError < dDist)
	{
		CString strFile, strLog;
		strFile.Format(_T("FidAngle"));
		strLog.Format(_T("FiducialRotate : %f < %f"), dFidError, dDist);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		return FALSE;
	}
	
	return TRUE;
}

DPOINT DProject::GetQuadrangleCenter(BOOL b1stPanel, BOOL bRef, int nFidCount) // �簢 ������ center���ϱ�
{
	BOOL bPanel = !b1stPanel;
	DPOINT ptVertex[4];
	for(int i=0; i<nFidCount; i++)
	{
		if(bRef)
		{
			ptVertex[i].x = m_RefTrans[bPanel][0].GetRefsPoint(i).x;
			ptVertex[i].y = m_RefTrans[bPanel][0].GetRefsPoint(i).y;
		}
		else
		{
			ptVertex[i].x = m_RefTrans[bPanel][0].GetTransPoint(i).x;
			ptVertex[i].y = m_RefTrans[bPanel][0].GetTransPoint(i).y;
		}
	}
	
	//////////////
	// D1    B2 //
	// A0    C3 //
	//////////////

	// ptA�� ptB
	double a1 = (ptVertex[0].y - ptVertex[2].y) / (ptVertex[0].x - ptVertex[2].x);
	double b1 = ptVertex[0].y - (a1 * ptVertex[0].x);
		
	// ptC�� ptD
	double a2 = (ptVertex[3].y - ptVertex[1].y) / (ptVertex[3].x - ptVertex[1].x);
	double b2 = ptVertex[3].y - (a2 * ptVertex[3].x);
	
	// ����
	DPOINT ptCenter;
	ptCenter.x = (b2 - b1) / (a1 - a2);
	ptCenter.y  = (a2 * ptCenter.x) + b2;

	return ptCenter;
}

int DProject::ApplyFidDataToShot_Coarse(int nFidKind, int nFindMethod, int nDualMode, BOOL& b1stOK, BOOL& b2ndOK, BOOL bCompensationMode)
{
	int nReturnError = 0;
	CString strFile, strFidOffset;
	strFile.Format(_T("FidFailData"));

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	int nError = 0;
	BOOL b1Use, b2Use, b1stPanel = TRUE;
	CPoint npFile, npOffset;
	int nUnitIndex;
	DUnit* pUnit;

	if(nDualMode == USE_DUAL) // || m_nSeparation == USE_1ST)
	{
		b1Use = b2Use = TRUE;
	}
	else if(nDualMode == USE_1ST)
	{
		b1Use = TRUE; b2Use = FALSE;
	}
	else
	{
		b1Use = FALSE; b2Use = TRUE;
		b1stPanel = FALSE;
	}
	////////////////////////////////////////////////////
	POSITION pos, dataPos;
	DAreaInfo* pAreaInfo;
	LPFIREHOLE pHole;
	LPFIRELINE pLine;
	double dPanelOffsetX = 0, dPanelOffsetY = 0;
	double dRefX, dRefY;
	double dValX, dValY, dValX2, dValY2;
	double dFidAngle;
	m_Glyphs.GetRefPosition(dRefX, dRefY); // ������ ������ �ǵ���� ���� ��ǥ
	
	int nXtableLimit, nYtableLimit;
	int nXVal, nYVal;
#ifdef __MP920_MOTOR__
	nXVal = 1000000; // no table limit check
	nYVal = 1000000;
#else
//	nXVal = (int)(gDeviceFactory.GetMotor()->m_dXLimitP * 1000);
//	nYVal = (int)(gDeviceFactory.GetMotor()->m_dYLimitP * 1000);
	nXVal = 1000000; // no table limit check
	nYVal = 1000000;
#endif

	DeleteFidIndex();
	
	m_n1stBaseFid = new int[MAX_FIDUCIAL];
	memset(m_n1stBaseFid, -1, sizeof(int)*(MAX_FIDUCIAL));
	m_n2ndBaseFid = new int[MAX_FIDUCIAL];
	memset(m_n2ndBaseFid, -1, sizeof(int)*(MAX_FIDUCIAL));

	int nFidRank = nFidKind;

	if(nFidKind != DEFAULT_FID_INDEX)
	{
		nFidRank = FID_DRILL;
	}

	BOOL bRef1 = m_Glyphs.GetFidIndex(m_n1stBaseFid, DEFAULT_FID_INDEX, TRUE, nFidRank); //GetBigFidIndex(m_n1stBaseFid, DEFAULT_FID_INDEX, TRUE, nFidRank);
	BOOL bRef2 = m_Glyphs.GetFidIndex(m_n2ndBaseFid, DEFAULT_FID_INDEX, FALSE, nFidRank); //GetBigFidIndex(m_n2ndBaseFid, DEFAULT_FID_INDEX, FALSE, nFidRank);

	if(b1Use && !bRef1)
	{
		strFidOffset.Format(_T("1st Panel Fid Index Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		
		b1stOK &= FALSE;
		if(gProcessINI.m_sProcessSystem.bFailFidCountinue)
		{
			if(nDualMode == USE_DUAL)
				nReturnError = FIDUCIAL_TRANS_ERROR;
			else
			{
				DeleteFidIndex();
				return FIDUCIAL_TRANS_ERROR;
			}
		}
		else
		{
			DeleteFidIndex();
			return FIDUCIAL_TRANS_ERROR;
		}
	}
	if(b2Use && !bRef2)
	{	
		strFidOffset.Format(_T("2nd Panel Fid Index Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		DeleteFidIndex();

		b2ndOK &= FALSE;
		if(gProcessINI.m_sProcessSystem.bFailFidCountinue)
		{
			if(nDualMode == USE_DUAL)
				nReturnError = FIDUCIAL_TRANS_ERROR;
			else
			{
				DeleteFidIndex();
				return FIDUCIAL_TRANS_ERROR;
			}
		}
		else
		{
			DeleteFidIndex();
			return FIDUCIAL_TRANS_ERROR;
		}
	}

	if((b1Use && !b1stOK) || (b2Use && !b2ndOK))
	{
		DeleteFidIndex();
		return nReturnError;
	}
	else if(b1Use && !b2Use && !b1stOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}
	else if(!b1Use && b2Use && !b2ndOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}

	int nRefCnt1 = 0, nRefCnt2 = 0;
	// ��ü fiducial
	for(int k=0; k<4; k++)
	{
		if(m_n1stBaseFid[k] != -1)
			nRefCnt1++;

		if(m_n2ndBaseFid[k] != -1)
			nRefCnt2++;
	}

	if(b1Use && b1stOK)
	{
		if(bCompensationMode)
		{
			if(!CalScale(nRefCnt1, TRUE, TRUE)) 
			{
				strFidOffset.Format(_T("1st Panel CalTransformAndScale Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				nReturnError = FIDUCIAL_TRANS_ERROR;
				b1stOK &= FALSE;
			}
		}
		else
		{
			if(!CalTransformAndScaleCoaseAndSlive(nRefCnt1, TRUE, nFidRank, TRUE)) 
			{
				strFidOffset.Format(_T("1st Panel CalTransformAndScale Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				nReturnError = FIDUCIAL_TRANS_ERROR;
				b1stOK &= FALSE;
			}
		}
	}
	if(b2Use && b2ndOK)
	{
		if(bCompensationMode)
		{
			if(!CalScale(nRefCnt2, FALSE, TRUE)) 
			{
				strFidOffset.Format(_T("2nd Panel CalTransformAndScale Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				nReturnError = FIDUCIAL_TRANS_ERROR;
				b2ndOK &= FALSE;
			}
		}
		else
		{
			if(!CalTransformAndScaleCoaseAndSlive(nRefCnt2, FALSE, nFidRank, TRUE)) 
			{
				strFidOffset.Format(_T("2nd Panel CalTransformAndScale Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				nReturnError = FIDUCIAL_TRANS_ERROR;
				b2ndOK &= FALSE;
			}
		}
	}

	if((b1Use && !b1stOK) || (b2Use && !b2ndOK))
	{
		DeleteFidIndex();
		return nReturnError;
	}
	else if(b1Use && !b2Use && !b1stOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}
	else if(!b1Use && b2Use && !b2ndOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}

	SaveLogTransInfo();

	int nOpticMX = 0, nOpticMY = 0, nOpticSX = 0, nOpticSY = 0;
	nOpticMX = gProcessINI.m_sProcessAutoSetting.nOpticMX;
	nOpticMY = gProcessINI.m_sProcessAutoSetting.nOpticMY;
	nOpticSX = gProcessINI.m_sProcessAutoSetting.nOpticSX;
	nOpticSY = gProcessINI.m_sProcessAutoSetting.nOpticSY;

	double dLaserMOffsetX, dLaserMOffsetY, dLaserSOffsetX, dLaserSOffsetY;
	HEocard* pEoCard = gDeviceFactory.GetEocard();
	
	CPoint npData;
	for(int i = ADDED_FID_TOOL + 1; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);

			nUnitIndex = pAreaInfo->GetUnitForFidCal(nFindMethod, &m_pToolCode[0]);
			if(nUnitIndex == -1)
			{
				continue;
			}
			pUnit = m_Glyphs.GetUnit(nUnitIndex);
			if(pUnit == NULL || pUnit->m_bTransOK == FALSE)
			{
				DeleteFidIndex();
				return FIDUCIAL_TRANS_ERROR;
			}

			if(b1stPanel)
			{
				m_RefTrans[0][0].TransformPoint(pAreaInfo->m_nCenterX, pAreaInfo->m_nCenterY, dValX, dValY);

				pAreaInfo->m_d1stAngle = m_RefTrans[0][0].GetTransAngle();
				pAreaInfo->m_nFidChangeCenterX = (int)dValX;
				pAreaInfo->m_nFidChangeCenterY = (int)dValY;
				pAreaInfo->m_nTableX = (int)(1000 * (m_dRefPosX - (pAreaInfo->m_nFidChangeCenterX / 1000.0 - dRefX)));
				pAreaInfo->m_nTableY = (int)(1000 * (m_dRefPosY - (pAreaInfo->m_nFidChangeCenterY / 1000.0 - dRefY)));

				nXtableLimit = nXVal - pAreaInfo->m_nTableX;
				nYtableLimit = nYVal - pAreaInfo->m_nTableY;

				if(pAreaInfo->m_nTableX/1000 < gSystemINI.m_sAxisInfo[AXIS_X].dLimitMinus || 
					pAreaInfo->m_nTableX/1000 > gSystemINI.m_sAxisInfo[AXIS_X].dLimitPlus ||
					pAreaInfo->m_nTableY/1000 < gSystemINI.m_sAxisInfo[AXIS_Y].dLimitMinus || 
					pAreaInfo->m_nTableY/1000 > gSystemINI.m_sAxisInfo[AXIS_Y].dLimitPlus)
				{
					DeleteFidIndex();
					return TABLE_MOVE_ERROR;
				}

				if(b2Use && b2ndOK)
				{
					pAreaInfo->m_d2ndAngle = m_2ndTrans.GetTransAngle();
					pMotor->GetAxisMoveOffset(pAreaInfo->m_nTableX/1000., pAreaInfo->m_nTableY/1000., dPanelOffsetX, dPanelOffsetY, DELTA_PANEL_OFFSET);
					dPanelOffsetX = (dPanelOffsetX + 0.0005) * 1000;
					dPanelOffsetY = (dPanelOffsetY + 0.0005) * 1000;
				}
			}
			else
			{
				m_RefTrans[1][0].TransformPoint(pAreaInfo->m_nCenterX, pAreaInfo->m_nCenterY, dValX, dValY);

				pAreaInfo->m_d2ndAngle = m_RefTrans[1][0].GetTransAngle();
				pAreaInfo->m_nFidChangeCenterX = (int)dValX;
				pAreaInfo->m_nFidChangeCenterY = (int)dValY;
				pAreaInfo->m_nTableX = (int)(1000 * (m_dRefPosX - (pAreaInfo->m_nFidChangeCenterX / 1000.0 - dRefX)));
				pAreaInfo->m_nTableY = (int)(1000 * (m_dRefPosY - (pAreaInfo->m_nFidChangeCenterY / 1000.0 - dRefY)));
				
				nXtableLimit = nXVal - pAreaInfo->m_nTableX;
				nYtableLimit = nYVal - pAreaInfo->m_nTableY;

				if(pAreaInfo->m_nTableX/1000 < gSystemINI.m_sAxisInfo[AXIS_X].dLimitMinus || 
					pAreaInfo->m_nTableX/1000 > gSystemINI.m_sAxisInfo[AXIS_X].dLimitPlus ||
					pAreaInfo->m_nTableY/1000 < gSystemINI.m_sAxisInfo[AXIS_Y].dLimitMinus || 
					pAreaInfo->m_nTableY/1000 > gSystemINI.m_sAxisInfo[AXIS_Y].dLimitPlus)
				{
					DeleteFidIndex();
					return TABLE_MOVE_ERROR;
				}
			}

			if((b1Use && !b1stOK) || (b2Use && !b2ndOK))
			{
				DeleteFidIndex();
				return nReturnError;
			}
			else if(b1Use && !b2Use && !b1stOK)
			{
				DeleteFidIndex();
				return nReturnError;
			}
			else if(!b1Use && b2Use && !b2ndOK)
			{
				DeleteFidIndex();
				return nReturnError;
			}

			pEoCard->GetLaserOffset(pAreaInfo->m_nTableX/1000, pAreaInfo->m_nTableY/1000, dLaserMOffsetX, dLaserMOffsetY, FIRST_PANEL_OFFSET);
			pEoCard->GetLaserOffset(pAreaInfo->m_nTableX/1000, pAreaInfo->m_nTableY/1000, dLaserSOffsetX, dLaserSOffsetY, SECOND_PANEL_OFFSET);
			dLaserMOffsetX = dLaserMOffsetX * 1000;
			dLaserMOffsetY = dLaserMOffsetY * 1000;
			dLaserSOffsetX = dLaserSOffsetX * 1000;
			dLaserSOffsetY = dLaserSOffsetY * 1000;

			// hole and skiving ó��
			for(int j = ADDED_FID_TOOL + 1; j < MAX_TOOL_NO; j++)
			{
				dataPos = pAreaInfo->m_FireHoles[j].GetHeadPosition();
				while (dataPos)
				{
					pHole = pAreaInfo->m_FireHoles[j].GetNext(dataPos);
					if(!IsFireHole(nFindMethod, pHole, NULL, i))
						continue;

					pUnit = m_Glyphs.GetUnit(pHole->pOrigin->nUnitIndex);
					if(pUnit == NULL || pUnit->m_bTransOK == FALSE)
					{
						DeleteFidIndex();
						return FIDUCIAL_TRANS_ERROR;
					}

					if(b1Use && b1stOK)
					{	
						m_RefTrans[0][pHole->pOrigin->nFidBlock].TransformPoint(pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, dValX, dValY);
						
						if(!CalLSBValue(pHole->npPos1.x, pHole->npPos1.y, 
							dValX - pAreaInfo->m_nFidChangeCenterX + nOpticMX - dLaserMOffsetX, dValY - pAreaInfo->m_nFidChangeCenterY + nOpticMY - dLaserMOffsetY,
							m_pToolCode[pHole->pOrigin->nToolNo]->m_nApertureSize))
						{
							b1stOK &= FALSE;
							nReturnError = MISSHOT_ERROR; // miss shot
						}

						if(nXtableLimit + (dValX - pAreaInfo->m_nFidChangeCenterX)  < 0 || 
							nYtableLimit + (dValY - pAreaInfo->m_nFidChangeCenterY) < 0)
						{
							b1stOK &= FALSE;
							nReturnError = OUT_TABLE_FIRE;
						}
					}
					if(b2Use && b2ndOK)
					{
						m_RefTrans[1][pHole->pOrigin->nFidBlock].TransformPoint(pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, dValX, dValY);
						
						if(!CalLSBValue(pHole->npPos2.x, pHole->npPos2.y, 
							dValX - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX + nOpticSX - dLaserSOffsetX, dValY - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY + nOpticSY - dLaserSOffsetY,
							m_pToolCode[pHole->pOrigin->nToolNo]->m_nApertureSize))
						{
							b2ndOK &= FALSE;
							nReturnError = MISSHOT_ERROR; // miss shot
						}

						if(nXtableLimit + (dValX - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX)  < 0 || 
							nYtableLimit + (dValY - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY) < 0)
						{
							b2ndOK &= FALSE;
							nReturnError = OUT_TABLE_FIRE;
						}
					}
			
					if((b1Use && !b1stOK) || (b2Use && !b2ndOK))
					{
						DeleteFidIndex();
						return nReturnError;
					}
					else if(b1Use && !b2Use && !b1stOK)
					{
						DeleteFidIndex();
						return nReturnError;
					}
					else if(!b1Use && b2Use && !b2ndOK)
					{
						DeleteFidIndex();
						return nReturnError;
					}
				}
			}
			// line ó��
			for(int j =  ADDED_FID_TOOL + 1; j < MAX_TOOL_NO; j++)
			{
				dataPos = pAreaInfo->m_FireLines[j].GetHeadPosition();
				while (dataPos)
				{
					pLine = pAreaInfo->m_FireLines[j].GetNext(dataPos);

					if(!IsFireHole(nFindMethod, NULL, pLine, i))
						continue;
					
					pUnit = m_Glyphs.GetUnit(pLine->pOrigin->nUnitIndex);
					if(pUnit == NULL || pUnit->m_bTransOK == FALSE)
					{
						DeleteFidIndex();
						return FIDUCIAL_TRANS_ERROR;
					}

					if(b1Use && b1stOK)
					{	
						m_RefTrans[0][pLine->pOrigin->nFidBlock].TransformPoint(pLine->npStartPos.x, pLine->npStartPos.y, dValX, dValY);
						dFidAngle = m_RefTrans[0][pLine->pOrigin->nFidBlock].GetTransAngle();

						if(m_ToolSumInfo[m_ToolSumInfo[j].nSameAreaToolNo].nToolAtri == emFlying)
						{
						}
						else
						{
							if(!CalLSBValue(pLine->npFidSPos1.x, pLine->npFidSPos1.y, 
								dValX - pAreaInfo->m_nFidChangeCenterX, dValY - pAreaInfo->m_nFidChangeCenterY))
							{
								b1stOK &= FALSE;
								nReturnError = MISSHOT_ERROR; // miss shot
							}

							if(nXtableLimit + (dValX - pAreaInfo->m_nFidChangeCenterX) < 0 || 
								nYtableLimit + (dValY - pAreaInfo->m_nFidChangeCenterY) < 0)
							{
								b1stOK &= FALSE;
								nReturnError = OUT_TABLE_FIRE;
							}
						}
					
						m_RefTrans[0][pLine->pOrigin->nFidBlock].TransformPoint(pLine->npEndPos.x, pLine->npEndPos.y, dValX2, dValY2);

						if(!CalLSBValue(pLine->npFidEPos1.x, pLine->npFidEPos1.y, 
							dValX2 - pAreaInfo->m_nFidChangeCenterX, dValY2 - pAreaInfo->m_nFidChangeCenterY))
						{
							b1stOK &= FALSE;
							nReturnError = MISSHOT_ERROR; // miss shot
						}
						
						if(nXtableLimit + (dValX2 - pAreaInfo->m_nFidChangeCenterX) < 0 || 
							nYtableLimit + (dValY2 - pAreaInfo->m_nFidChangeCenterY) < 0)
						{
							b1stOK &= FALSE;
							nReturnError = OUT_TABLE_FIRE;
						}
					}
					if(b2Use && b2ndOK)
					{
						m_RefTrans[1][pLine->pOrigin->nFidBlock].TransformPoint(pLine->npStartPos.x, pLine->npStartPos.y, dValX, dValY);
						dFidAngle = m_RefTrans[1][pLine->pOrigin->nFidBlock].GetTransAngle();

						if(m_ToolSumInfo[m_ToolSumInfo[j].nSameAreaToolNo].nToolAtri == emFlying)
						{
						}
						else
						{
							if(!CalLSBValue(pLine->npFidSPos2.x, pLine->npFidSPos2.y, 
								dValX - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX, dValY - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY))
							{
								b2ndOK &=FALSE;
								nReturnError = MISSHOT_ERROR; // miss shot
							}

							if(nXtableLimit + (dValX - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX) < 0 || 
								nYtableLimit + (dValY - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY) < 0)
							{
								b2ndOK &=FALSE;
								nReturnError = OUT_TABLE_FIRE;
							}
						}

						m_RefTrans[1][pLine->pOrigin->nFidBlock].TransformPoint(pLine->npEndPos.x, pLine->npEndPos.y, dValX2, dValY2);

						if(!CalLSBValue(pLine->npFidEPos2.x, pLine->npFidEPos2.y, 
							dValX2 - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX, dValY2 - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY))
						{
							b2ndOK &=FALSE;
							nReturnError = MISSHOT_ERROR; // miss shot
						}

						if(nXtableLimit + (dValX2 - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX) < 0 || 
							nYtableLimit + (dValY2 - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY) < 0)
						{
							b2ndOK &=FALSE;
							nReturnError = OUT_TABLE_FIRE;
						}
					}

					if((b1Use && !b1stOK) || (b2Use && !b2ndOK))
					{
						DeleteFidIndex();
						return nReturnError;
					}
					else if(b1Use && !b2Use && !b1stOK)
					{
						DeleteFidIndex();
						return nReturnError;
					}
					else if(!b1Use && b2Use && !b2ndOK)
					{
						DeleteFidIndex();
						return nReturnError;
					}
				}
			}
		}
	}

	DeleteFidIndex();

	return nReturnError; // no error
}
int DProject::OnlyTransform(int nFidKind, int nFindMethod, BOOL bSelectFire, int nFidBlock, int nDualMode, BOOL& b1stOK, BOOL& b2ndOK)
{
	CString strFile, strFidOffset;
	strFile.Format(_T("FidFailData"));
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	int nError = 0;
	BOOL b1Use, b2Use, b1stPanel = TRUE;
	CPoint npFile, npOffset;
	int nReturnError = 0;
	if(nDualMode == USE_DUAL) // || m_nSeparation == USE_1ST)
	{
		b1Use = b2Use = TRUE;
	}
	else if(nDualMode == USE_1ST)
	{
		b1Use = TRUE; b2Use = FALSE;
	}
	else
	{
		b1Use = FALSE; b2Use = TRUE;
		b1stPanel = FALSE;
	}
	
	////////////////////////////////////////////////////
	int nToolStart, nToolEnd;
	nToolStart = ADDED_FID_TOOL + 1;
	nToolEnd = MAX_TOOL_NO;
	
	double dPanelOffsetX = 0, dPanelOffsetY = 0;
	double dRefX, dRefY;
	m_Glyphs.GetRefPosition(dRefX, dRefY); // ������ ������ �ǵ���� ���� ��ǥ
	
	int nXVal, nYVal;
#ifdef __MP920_MOTOR__
	nXVal = 1000000; // no table limit check
	nYVal = 1000000;
#else
	//	nXVal = (int)(gDeviceFactory.GetMotor()->m_dXLimitP * 1000);
	//	nYVal = (int)(gDeviceFactory.GetMotor()->m_dYLimitP * 1000);
	nXVal = (int)(gSystemINI.m_sSystemDevice.dTableLimitMaxX * 1000);
	nYVal = (int)(gSystemINI.m_sSystemDevice.dTableLimitMaxY * 1000);
#endif

	DeleteFidIndex();

	m_n1stBaseFid = new int[MAX_FIDUCIAL];
	memset(m_n1stBaseFid, -1, sizeof(int)*(MAX_FIDUCIAL));

	m_n2ndBaseFid = new int[MAX_FIDUCIAL];
	memset(m_n2ndBaseFid, -1, sizeof(int)*(MAX_FIDUCIAL));
	
	int nFidRank = FID_PRIMARY;

	if(nFidKind != DEFAULT_FID_INDEX)
	{
		nFidRank = FID_DRILL;
	}
	BOOL bRef1 = m_Glyphs.GetFidIndex(m_n1stBaseFid, DEFAULT_FID_INDEX, TRUE, nFidRank); //GetBigFidIndex(m_n1stBaseFid, DEFAULT_FID_INDEX, TRUE, nFidRank);
	BOOL bRef2 = m_Glyphs.GetFidIndex(m_n2ndBaseFid, DEFAULT_FID_INDEX, FALSE, nFidRank); //GetBigFidIndex(m_n2ndBaseFid, DEFAULT_FID_INDEX, FALSE, nFidRank);

	if(b1Use && !bRef1)
	{
		strFidOffset.Format(_T("1st Panel Fid Index Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		
		b1stOK = FALSE;
		nReturnError = FIDUCIAL_TRANS_ERROR;
	}
	if(b2Use && !bRef2)
	{	
		strFidOffset.Format(_T("2nd Panel Fid Index Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		DeleteFidIndex();
		b2ndOK = FALSE; 
		nReturnError = FIDUCIAL_TRANS_ERROR;
	}

	if(b1Use && b2Use && !b1stOK && !b2ndOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}
	else if(b1Use && !b2Use && !b1stOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}
	else if(!b1Use && b2Use && !b2ndOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}
	int nRefCnt1 = 0, nRefCnt2 = 0;
	// ��ü fiducial
	for(int k=0; k<m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX); k++)
	{
		if(m_n1stBaseFid[k] != -1)
			nRefCnt1++;

		if(m_n2ndBaseFid[k] != -1)
			nRefCnt2++;
	}

	if(b1Use)
	{
		if(!DoTransform(nRefCnt1, TRUE, nFidRank)) 
		{
			strFidOffset.Format(_T("1st Panel CalTransformAndScale Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
			DeleteFidIndex();
			b1stOK = FALSE;
			return FIDUCIAL_TRANS_ERROR;
		}
	}
	if(b2Use)
	{
		if(!DoTransform(nRefCnt2, FALSE, nFidRank)) 
		{
			strFidOffset.Format(_T("2nd Panel CalTransformAndScale Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
			DeleteFidIndex();
			b2ndOK = FALSE;
			return FIDUCIAL_TRANS_ERROR;
		}
	}
	return 0;

}
int DProject::ApplyFidDataToShot_MultiFiducial(int nFidKind, int nFindMethod, BOOL bSelectFire, int nFidBlock, int nDualMode, BOOL& b1stOK, BOOL& b2ndOK, BOOL bCompensationMode)
{
	CString strFile, strFidOffset;
	strFile.Format(_T("FidFailData"));
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	int nError = 0;
	BOOL b1Use, b2Use, b1stPanel = TRUE;
	CPoint npFile, npOffset;
	int nUnitIndex;
	DUnit* pUnit;
	int nReturnError = 0;
	if(nDualMode == USE_DUAL) // || m_nSeparation == USE_1ST)
	{
		b1Use = b2Use = TRUE;
	}
	else if(nDualMode == USE_1ST)
	{
		b1Use = TRUE; b2Use = FALSE;
	}
	else
	{
		b1Use = FALSE; b2Use = TRUE;
		b1stPanel = FALSE;
	}
	////////////////////////////////////////////////////
	int nToolStart, nToolEnd;
	nToolStart = ADDED_FID_TOOL + 1;
	nToolEnd = MAX_TOOL_NO;
	
	POSITION pos, dataPos;
	DAreaInfo* pAreaInfo;
	LPFIREHOLE pHole;
	LPFIRELINE pLine;
	double dPanelOffsetX = 0, dPanelOffsetY = 0;
	double dRefX, dRefY;
	double dValX, dValY, dValX2, dValY2;
	double dFidAngle;
	m_Glyphs.GetRefPosition(dRefX, dRefY); // ������ ������ �ǵ���� ���� ��ǥ
	
	int nXtableLimit, nYtableLimit;
	int nXVal, nYVal;
#ifdef __MP920_MOTOR__
	nXVal = 1000000; // no table limit check
	nYVal = 1000000;
#else
	//	nXVal = (int)(gDeviceFactory.GetMotor()->m_dXLimitP * 1000);
	//	nYVal = (int)(gDeviceFactory.GetMotor()->m_dYLimitP * 1000);
	nXVal = 1000000; // no table limit check
	nYVal = 1000000;
#endif

	DeleteFidIndex();

	m_n1stBaseFid = new int[MAX_FIDUCIAL];
	memset(m_n1stBaseFid, -1, sizeof(int)*(MAX_FIDUCIAL));

	m_n2ndBaseFid = new int[MAX_FIDUCIAL];
	memset(m_n2ndBaseFid, -1, sizeof(int)*(MAX_FIDUCIAL));
	
	int nFidRank = FID_PRIMARY;

	if(nFidKind != DEFAULT_FID_INDEX)
	{
		nFidRank = FID_DRILL;
	}

	BOOL bRef1 = m_Glyphs.GetFidIndex(m_n1stBaseFid, DEFAULT_FID_INDEX, TRUE, nFidRank); //GetBigFidIndex(m_n1stBaseFid, DEFAULT_FID_INDEX, TRUE, nFidRank);
	BOOL bRef2 = m_Glyphs.GetFidIndex(m_n2ndBaseFid, DEFAULT_FID_INDEX, FALSE, nFidRank); //GetBigFidIndex(m_n2ndBaseFid, DEFAULT_FID_INDEX, FALSE, nFidRank);

	if(b1Use && !bRef1)
	{
		strFidOffset.Format(_T("1st Panel Fid Index Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		nReturnError = FIDUCIAL_TRANS_ERROR;
		b1stOK &= FALSE;
	}
	if(b2Use && !bRef2)
	{	
		strFidOffset.Format(_T("2nd Panel Fid Index Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		nReturnError= FIDUCIAL_TRANS_ERROR;
		b2ndOK &= FALSE;
	}

	if((b1Use && !b1stOK) || (b2Use && !b2ndOK))
	{
		DeleteFidIndex();
		return nReturnError;
	}
	else if(b1Use && !b2Use && !b1stOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}
	else if(!b1Use && b2Use && !b2ndOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}

	int nRefCnt1 = 0, nRefCnt2 = 0;
	// ��ü fiducial
	for(int k=0; k<m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX); k++)
	{
		if(m_n1stBaseFid[k] != -1)
			nRefCnt1++;

		if(m_n2ndBaseFid[k] != -1)
			nRefCnt2++;
	}

	if(b1Use && b1stOK)
	{
		if(bCompensationMode)
		{
			if(!CalScale(nRefCnt1, TRUE, FALSE)) 
			{
				strFidOffset.Format(_T("1st Panel CalTransformAndScale Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				nReturnError = FIDUCIAL_TRANS_ERROR;
				b1stOK &= FALSE;
			}
		}
		else
		{
			if(!CalTransformAndScaleCoaseAndSlive(nRefCnt1, TRUE, nFidRank)) 
			{
				strFidOffset.Format(_T("1st Panel CalTransformAndScale Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				b1stOK &= FALSE;
				nReturnError = FIDUCIAL_TRANS_ERROR;
			}
		}
	}
	if(b2Use && b2ndOK)
	{
		if(bCompensationMode)
		{
			if(!CalScale(nRefCnt2, FALSE, FALSE)) 
			{
				strFidOffset.Format(_T("2nd Panel CalTransformAndScale Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				nReturnError = FIDUCIAL_TRANS_ERROR;
				b2ndOK &= FALSE;
			}
		}
		else
		{
			if(!CalTransformAndScaleCoaseAndSlive(nRefCnt2, FALSE, nFidRank)) 
			{
				strFidOffset.Format(_T("2nd Panel CalTransformAndScale Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				nReturnError = FIDUCIAL_TRANS_ERROR;
				b2ndOK &= FALSE;
			}
		}
	}
	if((b1Use && !b1stOK) || (b2Use && !b2ndOK))
	{
		DeleteFidIndex();
		return nReturnError;
	}
	else if(b1Use && !b2Use && !b1stOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}
	else if(!b1Use && b2Use && !b2ndOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}

	SaveLogTransInfo();

	int nOpticMX = 0, nOpticMY = 0, nOpticSX = 0, nOpticSY = 0;
	nOpticMX = gProcessINI.m_sProcessAutoSetting.nOpticMX;
	nOpticMY = gProcessINI.m_sProcessAutoSetting.nOpticMY;
	nOpticSX = gProcessINI.m_sProcessAutoSetting.nOpticSX;
	nOpticSY = gProcessINI.m_sProcessAutoSetting.nOpticSY;

	double dLaserMOffsetX, dLaserMOffsetY, dLaserSOffsetX, dLaserSOffsetY;
	HEocard* pEoCard = gDeviceFactory.GetEocard();

	CPoint npData;
	for(int i = nToolStart; i < nToolEnd; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);

			nUnitIndex = pAreaInfo->GetUnitForFidCal(nFindMethod, &m_pToolCode[0]);
			if(nUnitIndex == -1)
			{
				continue;
			}
			pUnit = m_Glyphs.GetUnit(nUnitIndex);
			if(pUnit == NULL || pUnit->m_bTransOK == FALSE)
			{
				DeleteFidIndex();
				return FIDUCIAL_TRANS_ERROR;
			}

			if(b1stPanel)
			{
				if(!bSelectFire)
				{
					if(nFidBlock == -1)
						m_RefTrans[0][0].TransformPoint(pAreaInfo->m_nCenterX, pAreaInfo->m_nCenterY, dValX, dValY);
					else
						m_RefTrans[0][nFidBlock].TransformPoint(pAreaInfo->m_nCenterX, pAreaInfo->m_nCenterY, dValX, dValY);
				}
				else
				{
					m_RefTrans[0][nFidBlock].TransformPoint(pAreaInfo->m_nCenterX, pAreaInfo->m_nCenterY, dValX, dValY);
				}

				if(pAreaInfo->IsThereSameBlockData(nFidBlock))
				{
					pAreaInfo->m_nFidChangeCenterX = (int)dValX;
					pAreaInfo->m_nFidChangeCenterY = (int)dValY;
					pAreaInfo->m_nTableX = (int)(1000 * (m_dRefPosX - (pAreaInfo->m_nFidChangeCenterX / 1000.0 - dRefX)));
					pAreaInfo->m_nTableY = (int)(1000 * (m_dRefPosY - (pAreaInfo->m_nFidChangeCenterY / 1000.0 - dRefY)));

					nXtableLimit = nXVal - pAreaInfo->m_nTableX;
					nYtableLimit = nYVal - pAreaInfo->m_nTableY;

					if(pAreaInfo->m_nTableX/1000 < gSystemINI.m_sAxisInfo[AXIS_X].dLimitMinus || 
						pAreaInfo->m_nTableX/1000 > gSystemINI.m_sAxisInfo[AXIS_X].dLimitPlus ||
						pAreaInfo->m_nTableY/1000 < gSystemINI.m_sAxisInfo[AXIS_Y].dLimitMinus || 
						pAreaInfo->m_nTableY/1000 > gSystemINI.m_sAxisInfo[AXIS_Y].dLimitPlus)
					{
						DeleteFidIndex();
						return TABLE_MOVE_ERROR;
					}

					if(b2Use)
					{
						pAreaInfo->m_d2ndAngle = m_2ndTrans.GetTransAngle();
						pMotor->GetAxisMoveOffset(pAreaInfo->m_nTableX/1000., pAreaInfo->m_nTableY/1000., dPanelOffsetX, dPanelOffsetY, DELTA_PANEL_OFFSET);
						dPanelOffsetX = (dPanelOffsetX + 0.0005) * 1000;
						dPanelOffsetY = (dPanelOffsetY + 0.0005) * 1000;
					}
				}
			}
			else
			{
				if(!bSelectFire)
				{
					if(nFidBlock == -1)
						m_RefTrans[1][0].TransformPoint(pAreaInfo->m_nCenterX, pAreaInfo->m_nCenterY, dValX, dValY);
					else
						m_RefTrans[1][nFidBlock].TransformPoint(pAreaInfo->m_nCenterX, pAreaInfo->m_nCenterY, dValX, dValY);
				}
				else
				{
					m_RefTrans[1][nFidBlock].TransformPoint(pAreaInfo->m_nCenterX, pAreaInfo->m_nCenterY, dValX, dValY);
				}

				if(pAreaInfo->IsThereSameBlockData(nFidBlock))
				{
					pAreaInfo->m_nFidChangeCenterX = (int)dValX;
					pAreaInfo->m_nFidChangeCenterY = (int)dValY;
					pAreaInfo->m_nTableX = (int)(1000 * (m_dRefPosX - (pAreaInfo->m_nFidChangeCenterX / 1000.0 - dRefX)));
					pAreaInfo->m_nTableY = (int)(1000 * (m_dRefPosY - (pAreaInfo->m_nFidChangeCenterY / 1000.0 - dRefY)));
					
					nXtableLimit = nXVal - pAreaInfo->m_nTableX;
					nYtableLimit = nYVal -	pAreaInfo->m_nTableY;

					if(pAreaInfo->m_nTableX/1000 < gSystemINI.m_sAxisInfo[AXIS_X].dLimitMinus || 
						pAreaInfo->m_nTableX/1000 > gSystemINI.m_sAxisInfo[AXIS_X].dLimitPlus ||
						pAreaInfo->m_nTableY/1000 < gSystemINI.m_sAxisInfo[AXIS_Y].dLimitMinus || 
						pAreaInfo->m_nTableY/1000 > gSystemINI.m_sAxisInfo[AXIS_Y].dLimitPlus)
					{
						DeleteFidIndex();
						return TABLE_MOVE_ERROR;
					}
				}
			}

			pEoCard->GetLaserOffset(pAreaInfo->m_nTableX/1000, pAreaInfo->m_nTableY/1000, dLaserMOffsetX, dLaserMOffsetY, FIRST_PANEL_OFFSET);
			pEoCard->GetLaserOffset(pAreaInfo->m_nTableX/1000, pAreaInfo->m_nTableY/1000, dLaserSOffsetX, dLaserSOffsetY, SECOND_PANEL_OFFSET);
			dLaserMOffsetX = dLaserMOffsetX * 1000;
			dLaserMOffsetY = dLaserMOffsetY * 1000;
			dLaserSOffsetX = dLaserSOffsetX * 1000;
			dLaserSOffsetY = dLaserSOffsetY * 1000;
			// hole and skiving ó��
			for(int j = nToolStart; j < nToolEnd; j++)
			{
				dataPos = pAreaInfo->m_FireHoles[j].GetHeadPosition();
				while (dataPos)
				{
					pHole = pAreaInfo->m_FireHoles[j].GetNext(dataPos);
					if(nFidBlock != -1 && pHole->pOrigin->nFidBlock != nFidBlock)
						continue;

					if(!IsFireHole(nFindMethod, pHole, NULL, i))
						continue;

					pUnit = m_Glyphs.GetUnit(pHole->pOrigin->nUnitIndex);
					if(pUnit == NULL || pUnit->m_bTransOK == FALSE)
					{
						DeleteFidIndex();
						return FIDUCIAL_TRANS_ERROR;
					}

					if(b1Use && b1stOK)
					{	
						m_RefTrans[0][pHole->pOrigin->nFidBlock].TransformPoint(pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, dValX, dValY);
						
						if(!CalLSBValue(pHole->npPos1.x, pHole->npPos1.y, 
							dValX - pAreaInfo->m_nFidChangeCenterX + nOpticMX - dLaserMOffsetX, dValY - pAreaInfo->m_nFidChangeCenterY + nOpticMY - dLaserMOffsetY,
							m_pToolCode[pHole->pOrigin->nToolNo]->m_nApertureSize))
						{
							nReturnError = MISSHOT_ERROR; // miss shot
							b1stOK &= FALSE;
						}

						if(nXtableLimit + (dValX - pAreaInfo->m_nFidChangeCenterX)  < 0 || 
							nYtableLimit + (dValY - pAreaInfo->m_nFidChangeCenterY) < 0)
						{
							nReturnError = OUT_TABLE_FIRE;
							b1stOK &= FALSE;
						}
					}
					if(b2Use && b2ndOK)
					{
						m_RefTrans[1][pHole->pOrigin->nFidBlock].TransformPoint(pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, dValX, dValY);
						
						if(!CalLSBValue(pHole->npPos2.x, pHole->npPos2.y, 
							dValX - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX + nOpticSX - dLaserSOffsetX, dValY - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY + nOpticSY - dLaserSOffsetY,
							m_pToolCode[pHole->pOrigin->nToolNo]->m_nApertureSize))
						{
							nReturnError = MISSHOT_ERROR; // miss shot
							b2ndOK &= FALSE;
						}

						if(nXtableLimit + (dValX - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX)  < 0 || 
							nYtableLimit + (dValY - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY) < 0)
						{
							nReturnError = OUT_TABLE_FIRE;
							b2ndOK &= FALSE;
						}
					}
					if((b1Use && !b1stOK) || (b2Use && !b2ndOK))
					{
						DeleteFidIndex();
						return nReturnError;
					}
					else if(b1Use && !b2Use && !b1stOK)
					{
						DeleteFidIndex();
						return nReturnError;
					}
					else if(!b1Use && b2Use && !b2ndOK)
					{
						DeleteFidIndex();
						return nReturnError;
					}
				}
			}
			// line ó��
			for(int j =  nToolStart; j < nToolEnd; j++)
			{
				dataPos = pAreaInfo->m_FireLines[j].GetHeadPosition();
				while (dataPos)
				{
					pLine = pAreaInfo->m_FireLines[j].GetNext(dataPos);
					if(nFidBlock != -1 && pLine->pOrigin->nFidBlock != nFidBlock)
						continue;

					if(!IsFireHole(nFindMethod, NULL, pLine, i))
						continue;
					
					pUnit = m_Glyphs.GetUnit(pLine->pOrigin->nUnitIndex);
					if(pUnit == NULL || pUnit->m_bTransOK == FALSE)
					{
						DeleteFidIndex();
						return FIDUCIAL_TRANS_ERROR;
					}

					if(b1Use && b1stOK)
					{	
						m_RefTrans[0][pLine->pOrigin->nFidBlock].TransformPoint(pLine->npStartPos.x, pLine->npStartPos.y, dValX, dValY);
						dFidAngle = m_RefTrans[0][pLine->pOrigin->nFidBlock].GetTransAngle();

						if(m_ToolSumInfo[m_ToolSumInfo[j].nSameAreaToolNo].nToolAtri == emFlying)
						{
						}
						else
						{
							if(!CalLSBValue(pLine->npFidSPos1.x, pLine->npFidSPos1.y, 
								dValX - pAreaInfo->m_nFidChangeCenterX, dValY - pAreaInfo->m_nFidChangeCenterY))
							{
								b1stOK &= FALSE;
								nReturnError = MISSHOT_ERROR; // miss shot
							}

							if(nXtableLimit + (dValX - pAreaInfo->m_nFidChangeCenterX) < 0 || 
								nYtableLimit + (dValY - pAreaInfo->m_nFidChangeCenterY) < 0)
							{
								b1stOK &= FALSE;
								nReturnError = OUT_TABLE_FIRE;
							}
						}
						if(b1stOK)
						{
							m_RefTrans[0][pLine->pOrigin->nFidBlock].TransformPoint(pLine->npEndPos.x, pLine->npEndPos.y, dValX2, dValY2);

							if(!CalLSBValue(pLine->npFidEPos1.x, pLine->npFidEPos1.y, 
								dValX2 - pAreaInfo->m_nFidChangeCenterX, dValY2 - pAreaInfo->m_nFidChangeCenterY))
							{
								b1stOK &= FALSE;
								nReturnError = MISSHOT_ERROR; // miss shot
							}

							if(nXtableLimit + (dValX2 - pAreaInfo->m_nFidChangeCenterX) < 0 || 
								nYtableLimit + (dValY2 - pAreaInfo->m_nFidChangeCenterY) < 0)
							{
								b1stOK &= FALSE;
								nReturnError = OUT_TABLE_FIRE;
							}
						}
						
					}
					if(b2Use && b2ndOK)
					{
						m_RefTrans[1][pLine->pOrigin->nFidBlock].TransformPoint(pLine->npStartPos.x, pLine->npStartPos.y, dValX, dValY);
						dFidAngle = m_RefTrans[1][pLine->pOrigin->nFidBlock].GetTransAngle();

						if(m_ToolSumInfo[m_ToolSumInfo[j].nSameAreaToolNo].nToolAtri == emFlying)
						{
						}
						else
						{
							if(!CalLSBValue(pLine->npFidSPos2.x, pLine->npFidSPos2.y, 
								dValX - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX, dValY - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY))
							{
								b2ndOK &= FALSE;
								nReturnError = MISSHOT_ERROR; // miss shot
							}

							if(nXtableLimit + (dValX - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX) < 0 || 
								nYtableLimit + (dValY - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY) < 0)
							{
								b2ndOK &= FALSE;
								nReturnError = OUT_TABLE_FIRE;
							}
						}
						if(b2ndOK)
						{
							m_RefTrans[1][pLine->pOrigin->nFidBlock].TransformPoint(pLine->npEndPos.x, pLine->npEndPos.y, dValX2, dValY2);

							if(!CalLSBValue(pLine->npFidEPos2.x, pLine->npFidEPos2.y, 
								dValX2 - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX, dValY2 - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY))
							{
								b2ndOK &= FALSE;
								nReturnError = MISSHOT_ERROR; // miss shot
							}

							if(nXtableLimit + (dValX2 - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX) < 0 || 
								nYtableLimit + (dValY2 - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY) < 0)
							{
								b2ndOK &= FALSE;
								nReturnError = OUT_TABLE_FIRE;
							}
						}
					}
					if((b1Use && !b1stOK) || (b2Use && !b2ndOK))
					{
						DeleteFidIndex();
						return nReturnError;
					}
					else if(b1Use && !b2Use && !b1stOK)
					{
						DeleteFidIndex();
						return nReturnError;
					}
					else if(!b1Use && b2Use && !b2ndOK)
					{
						DeleteFidIndex();
						return nReturnError;
					}

				}
			}
		}
	}

	DeleteFidIndex();
	return 0; // no error
}

int DProject::ApplyFidDataToShot(int nFidKind, int nFindMethod, int nDualMode, BOOL& b1stOK, BOOL& b2ndOK, BOOL bCompensationMode)
{
	CString strFile, strFidOffset;
	strFile.Format(_T("FidFailData"));
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	int nError = 0;
	BOOL b1Use, b2Use, b1stPanel = TRUE;
	CPoint npFile, npOffset;
	int nUnitIndex;
	DUnit* pUnit;
	int nReturnError = 0;
	if(nDualMode == USE_DUAL) // || m_nSeparation == USE_1ST)
	{
		b1Use = b2Use = TRUE;
	}
	else if(nDualMode == USE_1ST)
	{
		b1Use = TRUE; b2Use = FALSE;
	}
	else
	{
		b1Use = FALSE; b2Use = TRUE;
		b1stPanel = FALSE;
	}

	////////////////////////////////////////////////////
	int nToolStart, nToolEnd;
	nToolStart = ADDED_FID_TOOL + 1;
	nToolEnd = MAX_TOOL_NO;
	
	POSITION pos, dataPos;
	DAreaInfo* pAreaInfo;
	LPFIREHOLE pHole;
	LPFIRELINE pLine;
	double dPanelOffsetX = 0, dPanelOffsetY = 0;
	double dRefX, dRefY;
	double dValX, dValY, dValX2, dValY2;
	double dFidAngle;
	m_Glyphs.GetRefPosition(dRefX, dRefY); // ������ ������ �ǵ���� ���� ��ǥ
	
	int nXtableLimit, nYtableLimit;
	int nXVal, nYVal;
#ifdef __MP920_MOTOR__
	nXVal = 1000000; // no table limit check
	nYVal = 1000000;
#else
	//	nXVal = (int)(gDeviceFactory.GetMotor()->m_dXLimitP * 1000);
	//	nYVal = (int)(gDeviceFactory.GetMotor()->m_dYLimitP * 1000);
	nXVal = 1000000; // no table limit check
	nYVal = 1000000;
#endif

	// Only Normal flying
	int	nThetaCenterX, nThetaCenterY, nThetaCenterX2, nThetaCenterY2;
	int nCenterAndRefOffsetX, nCenterAndRefOffsetY, nCenterAndRefOffsetX2, nCenterAndRefOffsetY2;
	nThetaCenterX = (int)(gSystemINI.m_sSystemDevice.d1stThetaCenter.x - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x);
	nThetaCenterY = (int)(gSystemINI.m_sSystemDevice.d1stThetaCenter.y - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y);
	nCenterAndRefOffsetX = (int)(nThetaCenterX - m_dRefPosX * 1000);
	nCenterAndRefOffsetY = (int)(nThetaCenterY - m_dRefPosY * 1000);

	nThetaCenterX2 = (int)(gSystemINI.m_sSystemDevice.d2ndThetaCenter.x - gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x);
	nThetaCenterY2 = (int)(gSystemINI.m_sSystemDevice.d2ndThetaCenter.y - gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y);
	nCenterAndRefOffsetX2 = (int)(nThetaCenterX2 - m_dRefPosX * 1000);
	nCenterAndRefOffsetY2 = (int)(nThetaCenterY2 - m_dRefPosY * 1000);
	
//	LPFIDDATA pFidData;

/*
m_n1stuseFid, m_n2ndUseFid��
�� Hole,Line�� Fidcuial ���� �ʿ��� �κ��̳�
��� Data���� �ϳ��ϳ� Transform�ϴٺ��� �ð��� �����ɸ�.
���߿� ����ϰ� �Ǹ� �� �����ؾ� ��.
���Fiducial ������ �׷��� ���� �̿��ؾ� �� ��.
*/
	
	DeleteFidIndex();
	
	m_n1stBaseFid = new int[MAX_FIDUCIAL];
	memset(m_n1stBaseFid, -1, sizeof(int)*(MAX_FIDUCIAL));

	m_n2ndBaseFid = new int[MAX_FIDUCIAL];
	memset(m_n2ndBaseFid, -1, sizeof(int)*(MAX_FIDUCIAL));
	
	m_n1stSubFid = new int[MAX_FIDUCIAL];
	memset(m_n1stSubFid, -1, sizeof(int)*(MAX_FIDUCIAL));
	
	m_n2ndSubFid = new int[MAX_FIDUCIAL];
	memset(m_n2ndSubFid, -1, sizeof(int)*(MAX_FIDUCIAL));

	int nFidRank = FID_PRIMARY;
	if(nFidKind != DEFAULT_FID_INDEX)
	{
		nFidRank = FID_DRILL;
	}

	BOOL bRef1 = m_Glyphs.GetFidIndex(m_n1stBaseFid, DEFAULT_FID_INDEX, TRUE, nFidRank); //GetBigFidIndex(m_n1stBaseFid, DEFAULT_FID_INDEX, TRUE, nFidRank);
	BOOL bRef2 = m_Glyphs.GetFidIndex(m_n2ndBaseFid, DEFAULT_FID_INDEX, FALSE, nFidRank); //GetBigFidIndex(m_n2ndBaseFid, DEFAULT_FID_INDEX, FALSE, nFidRank);

	if(b1Use && !bRef1)
	{
		strFidOffset.Format(_T("1st Panel Fid Index Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		b1stOK &= FALSE;
		nReturnError =FIDUCIAL_TRANS_ERROR;
	}
	if(b2Use && !bRef2)
	{	
		strFidOffset.Format(_T("2nd Panel Fid Index Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		DeleteFidIndex();
		b2ndOK &= FALSE;
		nReturnError = FIDUCIAL_TRANS_ERROR;
	}

	if((b1Use && !b1stOK) || (b2Use && !b2ndOK))
	{
		DeleteFidIndex();
		return nReturnError;
	}
	else if(b1Use && !b2Use && !b1stOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}
	else if(!b1Use && b2Use && !b2ndOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}

	int nRefCnt1 = 0, nRefCnt2 = 0;
	// ��ü fiducial
	for(int k=0; k<4; k++)
	{
		if(m_n1stBaseFid[k] != -1)
			nRefCnt1++;

		if(m_n2ndBaseFid[k] != -1)
			nRefCnt2++;
	}

	BOOL bSub1 = FALSE, bSub2 = FALSE;
	int nSubCnt1 = 0, nSubCnt2 = 0;
	// Secondary Fiducial�� �־ SkivingMode���� �ƴ��� Ȯ���ϰ�
//	if(!m_bSkivingMode)
	{
		if(b1Use && b1stOK)
			bSub1 = m_Glyphs.GetFidIndex(m_n1stSubFid, DEFAULT_FID_INDEX, TRUE, FID_SECONDARY);
		if(b2Use && b2ndOK)
			bSub2 = m_Glyphs.GetFidIndex(m_n2ndSubFid, DEFAULT_FID_INDEX, FALSE, FID_SECONDARY);

		if((b1Use && bSub1) || (b2Use && bSub2))
		{
			for(int k = 0; k<4; k++)
			{
				if(m_n1stSubFid[k] != -1)
					nSubCnt1++;
				
				if(m_n2ndSubFid[k] != -1)
					nSubCnt2++;
			}
		}
		
		if((b1Use && bSub1 && nRefCnt1 != nSubCnt1 && b1stOK))// ������ �ٸ��� �񱳸� ���ϴϱ�
		{
			strFidOffset.Format(_T("Primary, secondary count Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
			nReturnError = FIDUCIAL_TRANS_ERROR;
			b1stOK &= FALSE;
		}
		if(b2Use && bSub2 && nRefCnt2 != nSubCnt2 && b2ndOK) 
		{
			strFidOffset.Format(_T("Primary, secondary count Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
			nReturnError = FIDUCIAL_TRANS_ERROR;
			b2ndOK &= FALSE;
		}

		if((b1Use && !b1stOK) || (b2Use && !b2ndOK))
		{
			DeleteFidIndex();
			return nReturnError;
		}
		else if(b1Use && !b2Use && !b1stOK)
		{
			DeleteFidIndex();
			return nReturnError;
		}
		else if(!b1Use && b2Use && !b2ndOK)
		{
			DeleteFidIndex();
			return nReturnError;
		}
	}

//	int nRetScale;

	if(b1Use && b1stOK)
	{
		if(bSub1) // Primary 4��, Secondary 4�� �߰������� Ref����
		{
			ResetFiducialArray();

			CalFiducialPos(nRefCnt1, nSubCnt1, TRUE, TRUE); // Primary�� Secondary Fiducial�� Position�� ����

			if(!CalTransformAndScale(nRefCnt1, nSubCnt1, TRUE, MID_FIDUCIAL)) 
			{
				strFidOffset.Format(_T("1st Panel CalTransformAndScale Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				nReturnError = FIDUCIAL_TRANS_ERROR;
				b1stOK &= FALSE;
			}
		}
		else // Primary 4���� Ref����
		{
			if(!CalTransformAndScaleCoaseAndSlive(nRefCnt1, TRUE, nFidRank)) 
			{
				strFidOffset.Format(_T("2nd Panel CalTransformAndScale Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				nReturnError = FIDUCIAL_TRANS_ERROR;
				b1stOK &= FALSE;
			}
		}
	}
	if(b2Use)
	{
		if(bSub2) // Primary 4��, Secondary 4�� �߰������� Ref����
		{
			ResetFiducialArray();

			CalFiducialPos(nRefCnt2, nSubCnt2, FALSE, TRUE); // Primary�� Secondary Fiducial�� Position�� ����

			if(!CalTransformAndScale(nRefCnt2, nSubCnt2, FALSE, MID_FIDUCIAL)) // m_RefTrans[1].Transform() �� Calculate FidScale(FALSE)�� ��� ó��
			{
				b2ndOK &= FALSE;
				nReturnError = FIDUCIAL_TRANS_ERROR;
			}
		}
		else // Primary 4���� Ref����
		{
			if(!CalTransformAndScaleCoaseAndSlive(nRefCnt2, FALSE, nFidRank)) // m_RefTrans[1].Transform() �� Calculate FidScale(FALSE)�� ��� ó��
			{
				b2ndOK &= FALSE;
				nReturnError = FIDUCIAL_TRANS_ERROR;
			}
		}
	}

	if((b1Use && !b1stOK) || (b2Use && !b2ndOK))
	{
		DeleteFidIndex();
		return nReturnError;
	}
	else if(b1Use && !b2Use && !b1stOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}
	else if(!b1Use && b2Use && !b2ndOK)
	{
		DeleteFidIndex();
		return nReturnError;
	}

	int nOpticMX = 0, nOpticMY = 0, nOpticSX = 0, nOpticSY = 0;
	nOpticMX = gProcessINI.m_sProcessAutoSetting.nOpticMX;
	nOpticMY = gProcessINI.m_sProcessAutoSetting.nOpticMY;
	nOpticSX = gProcessINI.m_sProcessAutoSetting.nOpticSX;
	nOpticSY = gProcessINI.m_sProcessAutoSetting.nOpticSY;

	double dLaserMOffsetX, dLaserMOffsetY, dLaserSOffsetX, dLaserSOffsetY;
	HEocard* pEoCard = gDeviceFactory.GetEocard();

	int nIndex;
	CPoint npData;
	for(int i = nToolStart; i < nToolEnd; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);

			nUnitIndex = pAreaInfo->GetUnitForFidCal(nFindMethod, &m_pToolCode[0]);
			if(nUnitIndex == -1)
			{
				continue;
			}
			pUnit = m_Glyphs.GetUnit(nUnitIndex);
			if(pUnit == NULL || pUnit->m_bTransOK == FALSE)
			{
				DeleteFidIndex();
				return FIDUCIAL_TRANS_ERROR;
			}

			if(b1stPanel)
			{
				m_RefTrans[0][0].TransformPoint(pAreaInfo->m_nCenterX, pAreaInfo->m_nCenterY, dValX, dValY);

				pAreaInfo->m_d1stAngle = m_RefTrans[0][0].GetTransAngle();
				pAreaInfo->m_nFidChangeCenterX = (int)dValX;
				pAreaInfo->m_nFidChangeCenterY = (int)dValY;
				pAreaInfo->m_nTableX = (int)(1000 * (m_dRefPosX - (pAreaInfo->m_nFidChangeCenterX / 1000.0 - dRefX)));
				pAreaInfo->m_nTableY = (int)(1000 * (m_dRefPosY - (pAreaInfo->m_nFidChangeCenterY / 1000.0 - dRefY)));

				nXtableLimit = nXVal - pAreaInfo->m_nTableX;
				nYtableLimit = nYVal - pAreaInfo->m_nTableY;

				if(pAreaInfo->m_nTableX/1000 < gSystemINI.m_sAxisInfo[AXIS_X].dLimitMinus || 
					pAreaInfo->m_nTableX/1000 > gSystemINI.m_sAxisInfo[AXIS_X].dLimitPlus ||
					pAreaInfo->m_nTableY/1000 < gSystemINI.m_sAxisInfo[AXIS_Y].dLimitMinus || 
					pAreaInfo->m_nTableY/1000 > gSystemINI.m_sAxisInfo[AXIS_Y].dLimitPlus)
				{
					DeleteFidIndex();
					return TABLE_MOVE_ERROR;
				}

				if(b2Use)
				{
					pAreaInfo->m_d2ndAngle = m_2ndTrans.GetTransAngle();
					pMotor->GetAxisMoveOffset(pAreaInfo->m_nTableX/1000., pAreaInfo->m_nTableY/1000., dPanelOffsetX, dPanelOffsetY, DELTA_PANEL_OFFSET);
					dPanelOffsetX = (dPanelOffsetX + 0.0005) * 1000;
					dPanelOffsetY = (dPanelOffsetY + 0.0005) * 1000;
				}
			}
			else
			{
				m_RefTrans[1][0].TransformPoint(pAreaInfo->m_nCenterX, pAreaInfo->m_nCenterY, dValX, dValY);

				pAreaInfo->m_d2ndAngle = m_RefTrans[1][0].GetTransAngle();
				pAreaInfo->m_nFidChangeCenterX = (int)dValX;
				pAreaInfo->m_nFidChangeCenterY = (int)dValY;
				pAreaInfo->m_nTableX = (int)(1000 * (m_dRefPosX - (pAreaInfo->m_nFidChangeCenterX / 1000.0 - dRefX)));
				pAreaInfo->m_nTableY = (int)(1000 * (m_dRefPosY - (pAreaInfo->m_nFidChangeCenterY / 1000.0 - dRefY)));
				
				nXtableLimit = nXVal - pAreaInfo->m_nTableX;
				nYtableLimit = nYVal - pAreaInfo->m_nTableY;

				if(pAreaInfo->m_nTableX/1000 < gSystemINI.m_sAxisInfo[AXIS_X].dLimitMinus || 
					pAreaInfo->m_nTableX/1000 > gSystemINI.m_sAxisInfo[AXIS_X].dLimitPlus ||
					pAreaInfo->m_nTableY/1000 < gSystemINI.m_sAxisInfo[AXIS_Y].dLimitMinus || 
					pAreaInfo->m_nTableY/1000 > gSystemINI.m_sAxisInfo[AXIS_Y].dLimitPlus)
				{
					DeleteFidIndex();
					return TABLE_MOVE_ERROR;
				}
			}

			pEoCard->GetLaserOffset(pAreaInfo->m_nTableX/1000, pAreaInfo->m_nTableY/1000, dLaserMOffsetX, dLaserMOffsetY, FIRST_PANEL_OFFSET);
			pEoCard->GetLaserOffset(pAreaInfo->m_nTableX/1000, pAreaInfo->m_nTableY/1000, dLaserSOffsetX, dLaserSOffsetY, SECOND_PANEL_OFFSET);
			dLaserMOffsetX = dLaserMOffsetX * 1000;
			dLaserMOffsetY = dLaserMOffsetY * 1000;
			dLaserSOffsetX = dLaserSOffsetX * 1000;
			dLaserSOffsetY = dLaserSOffsetY * 1000;
			// hole and skiving ó��
			for(int j = nToolStart; j < nToolEnd; j++)
			{
				dataPos = pAreaInfo->m_FireHoles[j].GetHeadPosition();
				while (dataPos)
				{
					pHole = pAreaInfo->m_FireHoles[j].GetNext(dataPos);

					if(!IsFireHole(nFindMethod, pHole, NULL, i))
						continue;

					pUnit = m_Glyphs.GetUnit(pHole->pOrigin->nUnitIndex);
					if(pUnit == NULL || pUnit->m_bTransOK == FALSE)
					{
						DeleteFidIndex();
						return FIDUCIAL_TRANS_ERROR;
					}

					if(j == 0) // skiving fire data
					{
						nIndex = (int)(pHole->pOrigin);
						npData = m_Glyphs.GetFidIntPoint(DEFAULT_FID_INDEX, nIndex); //ADDED_FID_INDEX, nIndex);
						if(b1Use && b1stOK)
						{	
							m_RefTrans[0][pHole->pOrigin->nFidBlock].TransformPoint(npData.x, npData.y, dValX, dValY);
							
							if(!CalLSBValue(pHole->npPos1.x, pHole->npPos1.y, 
								dValX - pAreaInfo->m_nFidChangeCenterX + nOpticMX - dLaserMOffsetX, dValY - pAreaInfo->m_nFidChangeCenterY + nOpticMY - dLaserMOffsetY, 
								m_pToolCode[ADDED_FID_TOOL]->m_nApertureSize))
							{
								b1stOK &= FALSE;
								nReturnError = MISSHOT_ERROR; // miss shot
							}
							
							if(nXtableLimit + (dValX - pAreaInfo->m_nFidChangeCenterX) < 0 || 
								nYtableLimit + (dValY - pAreaInfo->m_nFidChangeCenterY) < 0)
							{
								b1stOK &= FALSE;
								nReturnError = OUT_TABLE_FIRE;
							}
							if(b1stOK)
								m_Glyphs.SetUseFidOffset(ADDED_FID_INDEX, nIndex, TRUE, 
														(dValX - npData.x) / 1000.0, (dValY - npData.y) / 1000.0);
//							m_Glyphs.SetFidIntOffset(ADDED_FID_INDEX, nIndex, TRUE,		// skiving �����ϰ� ���� skiving ã����
//													  dValX - npData.x , dValY - npData.y); // �ٷ� ã������ offset ���� 
						}
						if(b2Use && b2ndOK)
						{
							m_RefTrans[1][pHole->pOrigin->nFidBlock].TransformPoint(npData.x, npData.y, dValX, dValY);
														
							if(!CalLSBValue(pHole->npPos2.x, pHole->npPos2.y, 
								dValX - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX + nOpticSX - dLaserSOffsetX, dValY - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY + nOpticSY - dLaserSOffsetY,
								m_pToolCode[ADDED_FID_TOOL]->m_nApertureSize))
							{
								b2ndOK &= FALSE;
								nReturnError = MISSHOT_ERROR; // miss shot
							}

							if(nXtableLimit + (dValX - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX) < 0 || 
								nYtableLimit + (dValY - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY) < 0)
							{
								b2ndOK &= FALSE;
								nReturnError = OUT_TABLE_FIRE;
							}

							if(b2ndOK)	
								m_Glyphs.SetUseFidOffset(ADDED_FID_INDEX, nIndex, FALSE, 
														(dValX - npData.x) / 1000.0, (dValY - npData.y) / 1000.0);// skiving �����ϰ� ���� skiving ã����
//							m_Glyphs.SetFidIntOffset(ADDED_FID_INDEX, nIndex, FALSE, dValX - npData.x , dValY - npData.y);
						}

					}
					else
					{
						if(b1Use && b1stOK )
						{	
							m_RefTrans[0][pHole->pOrigin->nFidBlock].TransformPoint(pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, dValX, dValY);
							
							if(!CalLSBValue(pHole->npPos1.x, pHole->npPos1.y, 
								dValX - pAreaInfo->m_nFidChangeCenterX + nOpticMX - dLaserMOffsetX, dValY - pAreaInfo->m_nFidChangeCenterY + nOpticMY - dLaserMOffsetY,
								m_pToolCode[pHole->pOrigin->nToolNo]->m_nApertureSize))
							{
								b1stOK &= FALSE;
								nReturnError = MISSHOT_ERROR; // miss shot
							}

							if(nXtableLimit + (dValX - pAreaInfo->m_nFidChangeCenterX)  < 0 || 
								nYtableLimit + (dValY - pAreaInfo->m_nFidChangeCenterY) < 0)
							{
								b1stOK &= FALSE;
								nReturnError = OUT_TABLE_FIRE;
							}
						}
						if(b2Use)
						{
							m_RefTrans[1][pHole->pOrigin->nFidBlock].TransformPoint(pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, dValX, dValY);

							if(!CalLSBValue(pHole->npPos2.x, pHole->npPos2.y, 
								dValX - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX + nOpticSX - dLaserSOffsetX, dValY - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY + nOpticSY - dLaserSOffsetY,
								m_pToolCode[pHole->pOrigin->nToolNo]->m_nApertureSize))
							{
								b2ndOK &= FALSE;
								nReturnError = MISSHOT_ERROR; // miss shot
							}

							if(nXtableLimit + (dValX - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX)  < 0 || 
								nYtableLimit + (dValY - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY) < 0)
							{
								b2ndOK &= FALSE;
								nReturnError = OUT_TABLE_FIRE;
							}
						}
					}
			
					if((b1Use && !b1stOK) || (b2Use && !b2ndOK))
					{
						DeleteFidIndex();
						return nReturnError;
					}
					else if(b1Use && !b2Use && !b1stOK)
					{
						DeleteFidIndex();
						return nReturnError;
					}
					else if(!b1Use && b2Use && !b2ndOK)
					{
						DeleteFidIndex();
						return nReturnError;
					}
				}
			}
			// line ó��
			for(int j =  nToolStart; j < nToolEnd; j++)
			{
				dataPos = pAreaInfo->m_FireLines[j].GetHeadPosition();
				while (dataPos)
				{
					pLine = pAreaInfo->m_FireLines[j].GetNext(dataPos);

					if(!IsFireHole(nFindMethod, NULL, pLine, i))
						continue;
					
					pUnit = m_Glyphs.GetUnit(pLine->pOrigin->nUnitIndex);
					if(pUnit == NULL || pUnit->m_bTransOK == FALSE)
					{
						DeleteFidIndex();
						return FIDUCIAL_TRANS_ERROR;
					}

					if(b1Use && b1stOK)
					{	
						m_RefTrans[0][pLine->pOrigin->nFidBlock].TransformPoint(pLine->npStartPos.x, pLine->npStartPos.y, dValX, dValY);
						dFidAngle = m_RefTrans[0][pLine->pOrigin->nFidBlock].GetTransAngle();

						if(m_ToolSumInfo[m_ToolSumInfo[j].nSameAreaToolNo].nToolAtri == emFlying)
						{
						}
						else
						{
							if(!CalLSBValue(pLine->npFidSPos1.x, pLine->npFidSPos1.y, 
								dValX - pAreaInfo->m_nFidChangeCenterX, dValY - pAreaInfo->m_nFidChangeCenterY))
							{
								b1stOK &= FALSE;
								nReturnError = MISSHOT_ERROR; // miss shot
							}

							if(nXtableLimit + (dValX - pAreaInfo->m_nFidChangeCenterX) < 0 || 
								nYtableLimit + (dValY - pAreaInfo->m_nFidChangeCenterY) < 0)
							{
								b1stOK &= FALSE;
								nReturnError = OUT_TABLE_FIRE;
							}
						}
						if(b1stOK)
						{			
							m_RefTrans[0][pLine->pOrigin->nFidBlock].TransformPoint(pLine->npEndPos.x, pLine->npEndPos.y, dValX2, dValY2);

							if(m_ToolSumInfo[m_ToolSumInfo[j].nSameAreaToolNo].nToolAtri == emFlying)
							{
								// Only Normal flying
								if(!CalTablePos(pLine->npFidSPos1.x, pLine->npFidSPos1.y, pLine->npFidEPos1.x, 
											pLine->nLeadPos1.x, pLine->nLeadPos1.y,
											(int)dValX, (int)dValY, (int)dValX2, (int)dValY2,
											pLine->npStartPos.x, pLine->npEndPos.x,	
											nThetaCenterX, nThetaCenterY,	
											m_pToolCode[pLine->pOrigin->nToolNo]->m_nLeadIn * 1000, 
											m_pToolCode[pLine->pOrigin->nToolNo]->m_nLeadOut * 1000, 
											dFidAngle))	
								{
									b1stOK &= FALSE;
									nReturnError = OUT_TABLE_FIRE;
								}
							}
							else
							{
								if(!CalLSBValue(pLine->npFidEPos1.x, pLine->npFidEPos1.y, 
									dValX2 - pAreaInfo->m_nFidChangeCenterX, dValY2 - pAreaInfo->m_nFidChangeCenterY))
								{
									b1stOK &= FALSE;
									nReturnError = MISSHOT_ERROR; // miss shot
								}
							
								if(nXtableLimit + (dValX2 - pAreaInfo->m_nFidChangeCenterX) < 0 || 
									nYtableLimit + (dValY2 - pAreaInfo->m_nFidChangeCenterY) < 0)
								{
									b1stOK &= FALSE;
									nReturnError = OUT_TABLE_FIRE;
								}
							}
						}
					}
					if(b2Use && b2ndOK)
					{
						m_RefTrans[1][pLine->pOrigin->nFidBlock].TransformPoint(pLine->npStartPos.x, pLine->npStartPos.y, dValX, dValY);
						dFidAngle = m_RefTrans[1][pLine->pOrigin->nFidBlock].GetTransAngle();

						if(m_ToolSumInfo[m_ToolSumInfo[j].nSameAreaToolNo].nToolAtri == emFlying)
						{
						}
						else
						{
							if(!CalLSBValue(pLine->npFidSPos2.x, pLine->npFidSPos2.y, 
								dValX - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX, dValY - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY))
							{
								b2ndOK &= FALSE;
								nReturnError = MISSHOT_ERROR; // miss shot
							}

							if(nXtableLimit + (dValX - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX) < 0 || 
								nYtableLimit + (dValY - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY) < 0)
							{
								b2ndOK &= FALSE;
								nReturnError = OUT_TABLE_FIRE;
							}
						}

						if(b2ndOK)
						{
							m_RefTrans[1][pLine->pOrigin->nFidBlock].TransformPoint(pLine->npEndPos.x, pLine->npEndPos.y, dValX2, dValY2);

							if(m_ToolSumInfo[m_ToolSumInfo[j].nSameAreaToolNo].nToolAtri == emFlying)
							{
								// Only Normal flying
								if(!CalTablePos(pLine->npFidSPos2.x, pLine->npFidSPos2.y, pLine->npFidEPos2.x, 
												pLine->nLeadPos2.x, pLine->nLeadPos2.y,
												(int)dValX, (int)dValY, (int)dValX2, (int)dValY2,
												pLine->npStartPos.x, pLine->npEndPos.x,	
												nThetaCenterX2, nThetaCenterY2,	
												m_pToolCode[pLine->pOrigin->nToolNo]->m_nLeadIn * 1000, 
												m_pToolCode[pLine->pOrigin->nToolNo]->m_nLeadOut * 1000, 
												dFidAngle))	
								{
									b2ndOK &= FALSE;
									nReturnError =  OUT_TABLE_FIRE;
								}
							}
							else
							{
								if(!CalLSBValue(pLine->npFidEPos2.x, pLine->npFidEPos2.y, 
									dValX2 - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX, dValY2 - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY))
								{
									DeleteFidIndex();
									return MISSHOT_ERROR; // miss shot
								}

								if(nXtableLimit + (dValX2 - dPanelOffsetX - pAreaInfo->m_nFidChangeCenterX) < 0 || 
									nYtableLimit + (dValY2 - dPanelOffsetY - pAreaInfo->m_nFidChangeCenterY) < 0)
								{
									b2ndOK &= FALSE;
									nReturnError = OUT_TABLE_FIRE;
								}
							}
						}
					}

					if((b1Use && !b1stOK) || (b2Use && !b2ndOK))
					{
						DeleteFidIndex();
						return nReturnError;
					}
					else if(b1Use && !b2Use && !b1stOK)
					{
						DeleteFidIndex();
						return nReturnError;
					}
					else if(!b1Use && b2Use && !b2ndOK)
					{
						DeleteFidIndex();
						return nReturnError;
					}
				}
			}
		}
	}

	DeleteFidIndex();

	return 0; // no error
}

void DProject::DeleteFidIndex()
{
	if(m_n1stBaseFid)
	{
		delete m_n1stBaseFid;
		m_n1stBaseFid = NULL;
	}
	if(m_n2ndBaseFid)
	{
		delete m_n2ndBaseFid;
		m_n2ndBaseFid = NULL;
	}

	if(m_n1stSubFid)
	{
		delete m_n1stSubFid;
		m_n1stSubFid = NULL;
	}
	if(m_n2ndSubFid)
	{
		delete m_n2ndSubFid;
		m_n2ndSubFid = NULL;
	}
}

BOOL DProject::CalLSBValue(long &usX, long &usY, double dPosX, double dPosY, int umSize)
{
	double dGalvoPosX = (dPosX) * (static_cast<double>(MAXLSB) / gSystemINI.m_sSystemDevice.dFieldSize.x) / 1000.0;
	double dGalvoPosY = (dPosY) * (static_cast<double>(MAXLSB) / gSystemINI.m_sSystemDevice.dFieldSize.y) / 1000.0;
	
	dGalvoPosX += HALFLSB;
	dGalvoPosY += HALFLSB;
	usX = (long)(dGalvoPosX + 0.5);
	usY = (long)(dGalvoPosY + 0.5);
	
	if(umSize == 0)
	{
		if (usX > MAXLSB || usX < 0 || usY > MAXLSB || usY < 0)
		{
			return FALSE;
		}
	}
	else
	{
		umSize = (int)(umSize * MAXLSB / gSystemINI.m_sSystemDevice.dFieldSize.x / 1000 + 1);
		if (usX + umSize > MAXLSB || usX - umSize < 0 || usY + umSize > MAXLSB || usY - umSize < 0)
		{
			return FALSE;
		}
	}
	
	return TRUE;
}


void DProject::ReMoveExcellon()
{
	m_Glyphs.RemoveAllUnit();
}

void DProject::RemoveAreaList()
{
	DAreaInfo* pAreaInfo;
	POSITION pos;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			if(pAreaInfo->m_nRefNo == 1)
				delete pAreaInfo;
			else
				pAreaInfo->m_nRefNo--;
		}
		m_Areas[i].RemoveAll();
	}
}

int DProject::GetChangeFieldMode(DProject& myDProject)
{
	if((myDProject.m_nDataLoadStep & 0x0b) <= LOAD_EXCELLON) // 20091029
		return FIELD_CHANGE;

	if(myDProject.m_nDivRangeXDisp != m_nDivRangeXDisp ||
		myDProject.m_nDivRangeYDisp != m_nDivRangeYDisp)
		return FIELD_CHANGE;

	if(myDProject.m_nTextRangeXDisp != m_nTextRangeXDisp ||
		myDProject.m_nTextRangeYDisp != m_nTextRangeYDisp)
		return FIELD_CHANGE;

	if(gProcessINI.m_sProcessSystem.bNoDivideUnit == m_bUnitDivide)
		return FIELD_CHANGE;
	
	if(myDProject.m_bMultiFidAscentOrder != m_bMultiFidAscentOrder)
		return FIELD_CHANGE;

	if(myDProject.m_bArrayCopy)
		return FIELD_CHANGE;

/*	if(myDProject.m_Glyphs.GetUseFidCount(ADDED_FID_INDEX) != m_Glyphs.GetUseFidCount(ADDED_FID_INDEX))
		return FIELD_CHANGE;

	CPoint pt1, pt2;
	for(int i = 0; i < m_Glyphs.GetUseFidCount(ADDED_FID_INDEX); i++)
	{
		pt1 = m_Glyphs.GetUseFidIntPoint(ADDED_FID_INDEX, i);
		pt2 = myDProject.m_Glyphs.GetUseFidIntPoint(ADDED_FID_INDEX, i);
		if(pt1 != pt2)
			return FIELD_CHANGE;
	}
*/
	InitToolSumInfo();
	myDProject.InitToolSumInfo();
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(m_ToolSumInfo[i].nToolAtri != myDProject.m_ToolSumInfo[i].nToolAtri ||
			m_ToolSumInfo[i].nRealToolNo != myDProject.m_ToolSumInfo[i].nRealToolNo ||
			m_ToolSumInfo[i].nSameAreaToolNo != myDProject.m_ToolSumInfo[i].nSameAreaToolNo)
			return FIELD_CHANGE;
	}
	

	if( myDProject.m_nAxisMode != m_nAxisMode)
		return FIELD_AXIS_CHANGE;

	return FIELD_NONE_CHANGE;
}

void DProject::FlipMode(BOOL bX)
{
	if(bX)
	{
		if(m_nAxisMode == X_Y)
			m_nAxisMode = MX_Y;
		else if(m_nAxisMode == MX_Y)
			m_nAxisMode = X_Y;
		else if(m_nAxisMode == X_MY)
			m_nAxisMode = MX_MY;
		else if(m_nAxisMode == MX_MY)
			m_nAxisMode = X_MY;
		else if(m_nAxisMode == Y_X)
			m_nAxisMode = MY_X;
		else if(m_nAxisMode == MY_X)
			m_nAxisMode = Y_X;
		else if(m_nAxisMode == Y_MX)
			m_nAxisMode = MY_MX;
		else
			m_nAxisMode = Y_MX;

		if(m_nRotateInfo == X_Y)
			m_nRotateInfo = MX_Y;
		else if(m_nRotateInfo == MX_Y)
			m_nRotateInfo = X_Y;
		else if(m_nRotateInfo == X_MY)
			m_nRotateInfo = MX_MY;
		else if(m_nRotateInfo == MX_MY)
			m_nRotateInfo = X_MY;
		else if(m_nRotateInfo == Y_X)
			m_nRotateInfo = MY_X;
		else if(m_nRotateInfo == MY_X)
			m_nRotateInfo = Y_X;
		else if(m_nRotateInfo == Y_MX)
			m_nRotateInfo = MY_MX;
		else
			m_nRotateInfo = Y_MX;
	}
	else
	{
		if(m_nAxisMode == X_Y)
			m_nAxisMode = X_MY;
		else if(m_nAxisMode == MX_Y)
			m_nAxisMode = MX_MY;
		else if(m_nAxisMode == X_MY)
			m_nAxisMode = X_Y;
		else if(m_nAxisMode == MX_MY)
			m_nAxisMode = MX_Y;
		else if(m_nAxisMode == Y_X)
			m_nAxisMode = Y_MX;
		else if(m_nAxisMode == MY_X)
			m_nAxisMode = MY_MX;
		else if(m_nAxisMode == Y_MX)
			m_nAxisMode = Y_X;
		else
			m_nAxisMode = MY_X;

		if(m_nRotateInfo == X_Y)
			m_nRotateInfo = X_MY;
		else if(m_nRotateInfo == MX_Y)
			m_nRotateInfo = MX_MY;
		else if(m_nRotateInfo == X_MY)
			m_nRotateInfo = X_Y;
		else if(m_nRotateInfo == MX_MY)
			m_nRotateInfo = MX_Y;
		else if(m_nRotateInfo == Y_X)
			m_nRotateInfo = Y_MX;
		else if(m_nRotateInfo == MY_X)
			m_nRotateInfo = MY_MX;
		else if(m_nRotateInfo == Y_MX)
			m_nRotateInfo = Y_X;
		else
			m_nRotateInfo = MY_X;
	}
}

void DProject::RotateMode()
{
	if(m_nAxisMode == X_Y)
		m_nAxisMode = MY_X;
	else if(m_nAxisMode == MX_Y)
		m_nAxisMode = MY_MX;
	else if(m_nAxisMode == X_MY)
		m_nAxisMode = Y_X;
	else if(m_nAxisMode == MX_MY)
		m_nAxisMode = Y_MX;
	else if(m_nAxisMode == Y_X)
		m_nAxisMode = MX_Y;
	else if(m_nAxisMode == MY_X)
		m_nAxisMode = MX_MY;
	else if(m_nAxisMode == Y_MX)
		m_nAxisMode = X_Y;
	else
		m_nAxisMode = X_MY;

	if(m_nRotateInfo == X_Y)
		m_nRotateInfo = MY_X;
	else if(m_nRotateInfo == MX_Y)
		m_nRotateInfo = MY_MX;
	else if(m_nRotateInfo == X_MY)
		m_nRotateInfo = Y_X;
	else if(m_nRotateInfo == MX_MY)
		m_nRotateInfo = Y_MX;
	else if(m_nRotateInfo == Y_X)
		m_nRotateInfo = MX_Y;
	else if(m_nRotateInfo == MY_X)
		m_nRotateInfo = MX_MY;
	else if(m_nRotateInfo == Y_MX)
		m_nRotateInfo = X_Y;
	else
		m_nRotateInfo = X_MY;
}

BOOL DProject::IsDrawData(DAreaInfo *pAreaInfo, double dSx, double dSy, double dEx, double dEy)
{
	int nMinX, nMaxX, nMinY, nMaxY;
	
	if(m_nAxisMode == X_Y)
	{
		nMinX = pAreaInfo->m_nMinX;
		nMaxX = pAreaInfo->m_nMaxX;
		nMinY = pAreaInfo->m_nMinY;
		nMaxY = pAreaInfo->m_nMaxY;
	}
	else if(m_nAxisMode == MX_Y)
	{
		nMinX = -pAreaInfo->m_nMaxX;
		nMaxX = -pAreaInfo->m_nMinX;
		nMinY = pAreaInfo->m_nMinY;
		nMaxY = pAreaInfo->m_nMaxY;
	}
	else if(m_nAxisMode == X_MY)
	{
		nMinX = pAreaInfo->m_nMinX;
		nMaxX = pAreaInfo->m_nMaxX;
		nMinY = -pAreaInfo->m_nMaxY;
		nMaxY = -pAreaInfo->m_nMinY;
	}
	else if(m_nAxisMode == MX_MY)
	{
		nMinX = -pAreaInfo->m_nMaxX;
		nMaxX = -pAreaInfo->m_nMinX;
		nMinY = -pAreaInfo->m_nMaxY;
		nMaxY = -pAreaInfo->m_nMinY;
	}
	else if(m_nAxisMode == Y_X)
	{
		nMinX = pAreaInfo->m_nMinY;
		nMaxX = pAreaInfo->m_nMaxY;
		nMinY = pAreaInfo->m_nMinX;
		nMaxY = pAreaInfo->m_nMaxX;
	}
	else if(m_nAxisMode == MY_X)
	{
		nMinX = -pAreaInfo->m_nMaxY;
		nMaxX = -pAreaInfo->m_nMinY;
		nMinY = pAreaInfo->m_nMinX;
		nMaxY = pAreaInfo->m_nMaxX;
	}
	else if(m_nAxisMode == Y_MX)
	{
		nMinX = pAreaInfo->m_nMinY;
		nMaxX = pAreaInfo->m_nMaxY;
		nMinY = -pAreaInfo->m_nMaxX;
		nMaxY = -pAreaInfo->m_nMinX;
	}
	else
	{
		nMinX = -pAreaInfo->m_nMaxY;
		nMaxX = -pAreaInfo->m_nMinY;
		nMinY = -pAreaInfo->m_nMaxX;
		nMaxY = -pAreaInfo->m_nMinX;
	}
	
	if(nMinX > dEx) return FALSE;
	if(nMaxX < dSx) return FALSE;
	if(nMinY > dSy) return FALSE;
	if(nMaxY < dEy) return FALSE;

	return TRUE;
}

CPoint DProject::GetNoAxisChangePos(CPoint pt)
{
	CPoint ptChange;
	if(m_nAxisMode == X_Y)
	{
		ptChange.x = pt.x;
		ptChange.y = pt.y;
	}
	else if(m_nAxisMode == MX_Y)
	{
		ptChange.x = -pt.x;
		ptChange.y = pt.y;
	}
	else if(m_nAxisMode == X_MY)
	{
		ptChange.x = pt.x;
		ptChange.y = -pt.y;
	}
	else if(m_nAxisMode == MX_MY)
	{
		ptChange.x = -pt.x;
		ptChange.y = -pt.y;
	}
	else if(m_nAxisMode == Y_X)
	{
		ptChange.x = pt.y;
		ptChange.y = pt.x;
	}
	else if(m_nAxisMode == MY_X)
	{
		ptChange.x = pt.y;
		ptChange.y = -pt.x;
	}
	else if(m_nAxisMode == Y_MX)
	{
		ptChange.x = -pt.y;
		ptChange.y = pt.x;
	}
	else
	{
		ptChange.x = -pt.y;
		ptChange.y = -pt.x;
	}
	return ptChange;
}

void DProject::ChangeViewIndex()
{
	m_bShowSortIndex = !m_bShowSortIndex;
}

void DProject::ChangeDrawMode()
{
	if(m_bSelectDrawMode)
		m_bSelectDrawMode = FALSE;
	else
		m_bSelectDrawMode = TRUE;
}

void DProject::ChangePathDrawMode()
{
	if(m_bPathDrawMode)
		m_bPathDrawMode = FALSE;
	else
		m_bPathDrawMode = TRUE;
}

CPoint DProject::GetFilePos(CPoint ptPick, BOOL bTrans)
{
	CPoint umPoint;
	umPoint.x = (int)(m_dDrawStartX[0] + ptPick.x * m_dScale[0]);
	umPoint.y = (int)(m_dDrawStartY[0] - ptPick.y * m_dScale[0]);
	
	// 091230 ȸ�� ���� ���� �� add fiducial ��ǥ�� ����
	CPoint ptChange;
	ptChange = GetNoAxisChangePos(umPoint);
	
	if(bTrans)
		return ptChange;
	//

	return umPoint;
}

void DProject::SelectGlyphWithRect(CPoint pt1, CPoint pt2, BOOL bUnitSelect)
{
	CPoint umPoint, ptChange1, ptChange2;
//	BOOL bUnitSelect = FALSE;
	umPoint.x = (int)(m_dDrawStartX[0] + pt1.x * m_dScale[0]);
	umPoint.y = (int)(m_dDrawStartY[0] - pt1.y * m_dScale[0]);
	ptChange1 = GetNoAxisChangePos(umPoint);

	umPoint.x = (int)(m_dDrawStartX[0] + pt2.x * m_dScale[0]);
	umPoint.y = (int)(m_dDrawStartY[0] - pt2.y * m_dScale[0]);
	ptChange2 = GetNoAxisChangePos(umPoint);

	if(ptChange1.x > ptChange2.x)
	{
		umPoint.x = ptChange1.x;
		ptChange1.x = ptChange2.x;
		ptChange2.x = umPoint.x;
//		bUnitSelect = TRUE;
	}

	if(ptChange1.y > ptChange2.y)
	{
		umPoint.y = ptChange1.y;
		ptChange1.y = ptChange2.y;
		ptChange2.y = umPoint.y;
	}

//	m_bShowSelectionFid = FALSE;
	m_Glyphs.m_bShowSelectionFid = m_bShowSelectionFid;
	
	if(bUnitSelect)
	{
		m_Glyphs.IsSelect(ptChange1, ptChange2, &m_pToolCode[0], m_bSelectDrawMode);
		return;
	}
	
	DAreaInfo* pAreaInfo;
	POSITION pos;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			if(pAreaInfo->IsSelect(ptChange1, ptChange2, &m_pToolCode[0], m_bSelectDrawMode, &m_Glyphs))
				return;
		}
	}

	if(m_Glyphs.SelectData(ptChange1, ptChange2, &m_pToolCode[0], m_bSelectDrawMode) != -1)
		m_bShowSelectionFid = TRUE;
	else
		m_bShowSelectionFid = FALSE;
	
	m_Glyphs.m_bShowSelectionFid = m_bShowSelectionFid;
}

BOOL DProject::DisunifyUnit(CPoint pt1, CPoint pt2)
{
	CPoint umPoint, ptChange1, ptChange2;
	umPoint.x = (int)(m_dDrawStartX[0] + pt1.x * m_dScale[0]);
	umPoint.y = (int)(m_dDrawStartY[0] - pt1.y * m_dScale[0]);
	ptChange1 = GetNoAxisChangePos(umPoint);
	
	umPoint.x = (int)(m_dDrawStartX[0] + pt2.x * m_dScale[0]);
	umPoint.y = (int)(m_dDrawStartY[0] - pt2.y * m_dScale[0]);
	ptChange2 = GetNoAxisChangePos(umPoint);
	
	if(ptChange1.x > ptChange2.x)
	{
		umPoint.x = ptChange1.x;
		ptChange1.x = ptChange2.x;
		ptChange2.x = umPoint.x;
	}
	
	if(ptChange1.y > ptChange2.y)
	{
		umPoint.y = ptChange1.y;
		ptChange1.y = ptChange2.y;
		ptChange2.y = umPoint.y;
	}
	return m_Glyphs.DisunifyUnit(ptChange1, ptChange2);
}

void DProject::UnSelectAll()
{
	m_Glyphs.UnSelectAllUnit();
	m_Glyphs.UnSelectAllFid();
	m_Glyphs.UnSelectAllData();

	DAreaInfo* pAreaInfo;
	POSITION pos;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			pAreaInfo->UnSelectAll();
		}
	}

	m_bShowSelectionFid = FALSE;
}

int DProject::IsValidParameter() // use tool �ε� sub tool�� �ϳ��� ���� ���
{
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(m_pToolCode[i]->m_bUseTool)
		{
			if(m_pToolCode[i]->m_SubToolData.GetCount() < 1)
				return NONE_SUBPARAM;
			POSITION pos = m_pToolCode[i]->m_SubToolData.GetHeadPosition();
			SUBTOOLDATA subTool;
			int nOldType = -1;

			if(pos)
			{
				m_pToolCode[i]->CalApertureSizeAndLeadInOut();

				if(!m_pToolCode[i]->IsValidCount())
					return APERTURE_COUNT_ERROR;
			}

			while (pos)
			{
				subTool = m_pToolCode[i]->m_SubToolData.GetNext(pos);
				if(subTool.nToolType == BARCODE_TYPE)
				{
					if(m_pToolCode[i]->m_nToolSize <= 0)
						return BARCODE_SIZE_ERROR;
				}

				if(i == ADDED_FID_TOOL && subTool.nToolType == MARKING_TYPE)
				{
					return LINE_DOT_MISMATCH;
				}

				if(nOldType == -1)
				{
					if(subTool.nToolType == MARKING_TYPE || subTool.nToolType == FLYING_TYPE)
					{
						if(m_Glyphs.IsDotData(i))
						{
							return LINE_DOT_MISMATCH;
						}
					}
					else
					{
						if(m_Glyphs.IsLineData(i))
						{
							return LINE_DOT_MISMATCH;
						}
					}
				}
				else
				{
					if(nOldType != subTool.nToolType)
					{
						return DIFF_SUB_TYPE;
					}
				}
				nOldType = subTool.nToolType;
			}
		}
	}
	return VALID_PARAM;
}

void DProject::ChangeDataWithAxis()
{
	int nX1, nX2, nY1, nY2;
	GetXY(m_nMinX, m_nMinY, nX1, nY1);
	GetXY(m_nMaxX, m_nMaxY, nX2, nY2);
	if(nX1 > nX2)
	{
		m_nMinX = nX2; m_nMaxX = nX1;
	}
	else
	{
		m_nMinX = nX1; m_nMaxX = nX2;
	}
	if(nY1 > nY2)
	{
		m_nMinY = nY2; m_nMaxY = nY1;
	}
	else
	{
		m_nMinY = nY1; m_nMaxY = nY2;
	}

	DAreaInfo* pAreaInfo;
	POSITION pos;
	BOOL bIsThereArea = FALSE;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			bIsThereArea = TRUE;
			pAreaInfo = m_Areas[i].GetNext(pos);
			pAreaInfo->ChangeDataWithAxis(m_nAxisMode);

		}
	}
}

void DProject::GetXY(int nX, int nY, int &nTransX, int &nTransY)
{
	if(m_nAxisMode == X_Y)
	{
		nTransX = nX;
		nTransY = nY;
	}
	else if(m_nAxisMode == MX_Y)
	{
		nTransX = -nX;
		nTransY = nY;
	}
	else if(m_nAxisMode == X_MY)
	{
		nTransX = nX;
		nTransY = -nY;
	}
	else if(m_nAxisMode == MX_MY)
	{
		nTransX = -nX;
		nTransY = -nY;
	}
	else if(m_nAxisMode == Y_X)
	{
		nTransX = nY;
		nTransY = nX;
	}
	else if(m_nAxisMode == MY_X)
	{
		nTransX = -nY;
		nTransY = nX;
	}
	else if(m_nAxisMode == Y_MX)
	{
		nTransX = nY;
		nTransY = -nX;
	}
	else
	{
		nTransX = -nY;
		nTransY = -nX;
	}
}

BOOL DProject::IsThereSelectData()
{
	DAreaInfo* pAreaInfo;
	POSITION pos;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			if(pAreaInfo->IsThereSelectData())
				return TRUE;
		}
	}
	return FALSE;
}

void DProject::ResetFidOffset()
{
	m_Glyphs.ResetFidOffset();
}

void DProject::DrawDoingFireField(CDC *pDC, CRect rc)
{
	double dDrawEndX, dDrawEndY;
	dDrawEndX = m_dDrawStartX[0] + m_dScale[0] * rc.Width();
	dDrawEndY = m_dDrawStartY[0] - m_dScale[0] * rc.Height();

	DAreaInfo* pAreaInfo;
	POSITION pos;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);

			if(pAreaInfo->m_nFireStatus == DOING_FIRE)
			{
				pAreaInfo->DrawDoingFire(pDC, rc, m_dScale[0], m_dDrawStartX[0], m_dDrawStartY[0], m_nAxisMode);
				return;
			}
		}
	}
}

void DProject::ResetFireStatus()
{
	DAreaInfo* pAreaInfo;
	POSITION pos;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			pAreaInfo->m_nFireStatus = NO_FIRE;
		}
	}
}

void DProject::CalculateDataCount()
{
	m_nTotalHole = 0; //m_Glyphs.m_HoleData.GetCount();
	m_nTotalLine = 0; //m_Glyphs.m_LineData.GetCount();

	m_nSelectFireHole = 0;
	m_nVisibleHole = 0;
	m_nSelectFireLine = 0;
	m_nVisibleLine = 0;

	m_nSelectFireHoleShot = 0;
	m_nVisibleHoleShot = 0;
	m_nSelectFireLineShot = 0;
	m_nVisibleLineShot = 0;

	for(int i=0; i< MAX_TOOL_NO; i++)
	{
		m_bSelectToolDraw[i] = FALSE;
	}

	POSITION pos;
	DAreaInfo* pAreaInfo;

	int nMaxNum, nMaxLineNum, nMaxVisibleNum, nMaxVisibleLineNum;

	SUBTOOLDATA subTool;
	POSITION posSub;

	LPFIREHOLE pHole;
	LPFIRELINE pLine;
	POSITION dataPos;
	
	int* pFidIndex;
	int nUnitCount = m_Glyphs.m_Units.GetCount();
	pFidIndex = new int[nUnitCount];
	memset(pFidIndex, NULL, sizeof(int)*nUnitCount);

	int nSubShot, nSelect;

	for(int i = ADDED_FID_TOOL + 1; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);

			for(int j = ADDED_FID_TOOL; j < MAX_TOOL_NO; j++)
			{
				nSelect = 0;
				nMaxNum = 0;
				nMaxVisibleNum = 0;
				nSubShot = 0;
				posSub = m_pToolCode[j]->m_SubToolData.GetHeadPosition();
				while(posSub)
				{
					subTool = m_pToolCode[j]->m_SubToolData.GetNext(posSub);
					nSubShot += subTool.nTotalShot;
				}
				
				if(nSubShot == 0)
					continue;

				dataPos = pAreaInfo->m_FireHoles[j].GetHeadPosition();
				while (dataPos)
				{
					pHole = pAreaInfo->m_FireHoles[j].GetNext(dataPos);
					nMaxNum++;
					if(m_pToolCode[pHole->pOrigin->nToolNo]->m_bVisible)
					{
						nMaxVisibleNum++;
						pFidIndex[pHole->pOrigin->nUnitIndex] = pFidIndex[pHole->pOrigin->nUnitIndex] | 2;

						if(pHole->bSelect)
						{
							nSelect++;
							pFidIndex[pHole->pOrigin->nUnitIndex] = pFidIndex[pHole->pOrigin->nUnitIndex] | 1;
						}
					}
				}

				m_nTotalHole += nMaxNum;
	
				m_nVisibleHole += nMaxVisibleNum;
				m_nVisibleHoleShot += (nMaxVisibleNum * nSubShot);

				m_nSelectFireHole += nSelect;
				m_nSelectFireHoleShot += (nSelect * nSubShot);
				
				nSelect = 0;
				nMaxLineNum = 0;
				nMaxVisibleLineNum = 0;
				dataPos = pAreaInfo->m_FireLines[j].GetHeadPosition();
				while (dataPos)
				{
					pLine = pAreaInfo->m_FireLines[j].GetNext(dataPos);
					nMaxLineNum++;
					if(m_pToolCode[pLine->pOrigin->nToolNo]->m_bVisible)
					{
						nMaxVisibleLineNum++;
						pFidIndex[pLine->pOrigin->nUnitIndex] = pFidIndex[pLine->pOrigin->nUnitIndex] | 2;
						
						if(pLine->bSelect)
						{
							nSelect++;
							pFidIndex[pLine->pOrigin->nUnitIndex] = pFidIndex[pLine->pOrigin->nUnitIndex] | 1;
						}
					}
				}

				m_nTotalLine += nMaxLineNum;
				
				m_nVisibleLine += nMaxVisibleLineNum;
				m_nVisibleLineShot += (nMaxVisibleLineNum * nSubShot);

				m_nSelectFireLine += nSelect;
				m_nSelectFireLineShot += (nSelect * nSubShot);
			}
		}
	}
	m_Glyphs.ResetFindFidList();
	for(int i = 0; i < nUnitCount; i++ )
	{
		m_Glyphs.ChangeFindFidList(i, pFidIndex[i]);
	}
	delete pFidIndex;
}

int DProject::GetDataNo(int nTool)
{
	int nCount = 0;
	LPHOLEDATA pHole;
	POSITION posUnit = m_Glyphs.m_Units.GetHeadPosition();
	LPDUNIT pUnit;
	while(posUnit)
	{
		pUnit = m_Glyphs.m_Units.GetNext(posUnit);
		POSITION pos = pUnit->m_HoleData.GetHeadPosition();
		while (pos) 
		{
			pHole = pUnit->m_HoleData.GetNext(pos);
			if(pHole->nToolNo != 1)
			{
//				TRACE(_T("%d\n"), pHole->nToolNo);
			}
			if(pHole->nToolNo == nTool)
				nCount++;
		}
		
		LPLINEDATA pLine;
		pos = pUnit->m_LineData.GetHeadPosition();
		while (pos) 
		{
			pLine = pUnit->m_LineData.GetNext(pos);
			if(pLine->nToolNo == nTool)
				nCount++;
		}
	}

 	return nCount;
}

double DProject::GetTransAngle(BOOL b1stPanel)
{
	return 0;
//	if(b1stPanel)
//		return m_1stTrans.GetTransAngle();
//	else
//		return m_2ndTrans.GetTransAngle();
}

CString DProject::GetChangeValue(DProject& project1)
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));
	
	if(m_nDivRangeXDisp != project1.m_nDivRangeXDisp ||
		m_nDivRangeYDisp != project1.m_nDivRangeYDisp)
	{
		strTemp.Format(_T("| Divide Size = (%d, %d) "), project1.m_nDivRangeXDisp,
														project1.m_nDivRangeYDisp);
		strMessage += strTemp;
	}
	
	if(m_dPcbThick != project1.m_dPcbThick)
	{
		strTemp.Format(_T("| PCB Thick = %.3f "), project1.m_dPcbThick);
		strMessage += strTemp;
	}

	if(m_nSeparation != project1.m_nSeparation)
	{
		if(project1.m_nSeparation == USE_DUAL)
			strTemp.Format(_T("| Use Dual Panel "));
		else if(project1.m_nSeparation == USE_DUAL)
			strTemp.Format(_T("| Use 1st Panel "));
		else
			strTemp.Format(_T("| Use 2nd Panel "));
		strMessage += strTemp;
	}

	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(!m_pToolCode[i]->IsSameTool(project1.m_pToolCode[i]))
		{
			strTemp.Format(_T("| Tool %d is changed "), i);
			strMessage += strTemp;
		}

		if(m_pToolCode[i]->m_bVisible != project1.m_pToolCode[i]->m_bVisible)
		{
			if(project1.m_pToolCode[i]->m_bVisible)
				strTemp.Format(_T("| Tool %d is visiable "), i);
			else
				strTemp.Format(_T("| Tool %d is invisiable "), i);
			strMessage += strTemp;
		}
	}
	return strMessage;
}

void DProject::InitToolVisable()
{
	for(int i=0; i< MAX_TOOL_NO; i++)
	{
		m_pToolCode[i]->m_bVisible = TRUE;
	}
}

BOOL DProject::IsFieldNumber(CPoint pt, CRect rc, int& nIndex)
{
	CPoint umPoint, ptChange;
	int nTol = (int)(10 * m_dScale[0]);
	umPoint.x = (int)(m_dDrawStartX[0] + pt.x * m_dScale[0]);
	umPoint.y = (int)(m_dDrawStartY[0] - pt.y * m_dScale[0]);
	ptChange = GetNoAxisChangePos(umPoint);

	double dDrawEndX, dDrawEndY;
	dDrawEndX = m_dDrawStartX[0] + m_dScale[0] * rc.Width();
	dDrawEndY = m_dDrawStartY[0] - m_dScale[0] * rc.Height();

	DAreaInfo* pAreaInfo;
	POSITION pos;
	BOOL bIsThereArea = FALSE;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			bIsThereArea = TRUE;
			pAreaInfo = m_Areas[i].GetNext(pos);

			if(IsDrawData(pAreaInfo, m_dDrawStartX[0], m_dDrawStartY[0], dDrawEndX, dDrawEndY))
			{
				int nX, nY;
				nX = ptChange.x;
				nY = ptChange.y;
				if(pAreaInfo->IsFieldNumber(ptChange, nTol, m_nAxisMode, m_dDrawStartX[0], m_dDrawStartY[0], m_dScale[0]))
				{
					nIndex = pAreaInfo->m_nSortIndex;
					return TRUE;
				}
			}
		}
	}

	nIndex = -1;
	return FALSE;

}

void DProject::SetSelectFidBlock(int nFidBlock, BOOL bSelect)
{
	DAreaInfo* pAreaInfo;
	POSITION pos;
	BOOL bIsThereArea = FALSE;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);

			pAreaInfo->SetSelectFidBlock(nFidBlock, bSelect);
		}
	}
}

void DProject::SetSelectData(int nIndex, BOOL bOnlyOne)
{
	DAreaInfo* pAreaInfo;
	POSITION pos;
	BOOL bIsThereArea = FALSE;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			
			if(bOnlyOne)
			{
				if(pAreaInfo->m_nSortIndex != nIndex)
					continue;
			}
			else
			{
				if(pAreaInfo->m_nSortIndex < nIndex)
					continue;
			}

			pAreaInfo->SetSelectData(TRUE);
		}
	}
}

void DProject::SetTableOffset(int nIndex, double dX, double dY)
{
	DAreaInfo* pAreaInfo;
	POSITION pos;
	BOOL bIsThereArea = FALSE;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			
			if(pAreaInfo->m_nSortIndex != nIndex)
				continue;
			else
			{
				pAreaInfo->SetTableOffset(dX, dY);
				return;
			}
		}
	}
}

void DProject::GetTableOffset(int nIndex, double& dX, double& dY)
{
	DAreaInfo* pAreaInfo;
	POSITION pos;
	BOOL bIsThereArea = FALSE;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			
			if(pAreaInfo->m_nSortIndex != nIndex)
				continue;
			else
			{
				pAreaInfo->GetTableOffset(dX, dY);
				return;
			}
		}
	}
}

void DProject::DisplayUseFiducial(int nIndex)
{
	m_Glyphs.SetDisplayFidIndex(-1, TRUE);

	DAreaInfo* pAreaInfo;
	POSITION pos;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			
			if(pAreaInfo->m_nSortIndex != nIndex)
			{
				pAreaInfo->m_bCheckIndex = FALSE;
			}
			else
			{
				pAreaInfo->m_bCheckIndex = TRUE;
				POSITION posFid;
				LPFID_INDEX pFid;
				posFid = pAreaInfo->m_FidIndex.GetHeadPosition();
				while (posFid)
				{
					pFid = pAreaInfo->m_FidIndex.GetNext(posFid);
					m_Glyphs.SetDisplayFidIndex(pFid->nIndex);
				}
			}
		}
	}
}

void DProject::ClearFiducialIndex(int nIndex)
{
	DAreaInfo* pAreaInfo;
	POSITION pos;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			pAreaInfo->m_bCheckIndex = FALSE;
			
			if(pAreaInfo->m_nSortIndex != nIndex)
				continue;
			else
			{
				pAreaInfo->ClearFiducialIndex();
				m_Glyphs.SetDisplayFidIndex(-1, TRUE);
				return;
			}
		}
	}
}

BOOL DProject::AddFiducialIndex(CPoint pt, int nIndex)
{
	if(nIndex < 0)
		return FALSE;

	BOOL bRet = FALSE;

	CPoint umPoint, ptChange;
	int nTol = (int)(10 * m_dScale[0]);
	umPoint.x = (int)(m_dDrawStartX[0] + pt.x * m_dScale[0]);
	umPoint.y = (int)(m_dDrawStartY[0] - pt.y * m_dScale[0]);
	ptChange = GetNoAxisChangePos(umPoint);
	
	int nFidIndex = m_Glyphs.GetFiducialIndex(ptChange, nTol);

	DAreaInfo* pAreaInfo;
	POSITION pos;
	BOOL bIsThereArea = FALSE;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			
			if(pAreaInfo->m_nSortIndex != nIndex)
			{
				pAreaInfo->m_bCheckIndex = FALSE;
				continue;
			}
			else
			{
				pAreaInfo->m_bCheckIndex = TRUE;
				bRet = pAreaInfo->AddFiducialIndex(nFidIndex);
				return bRet;
			}
		}
	}
	return bRet;
}

BOOL DProject::DeleteFiducialIndex(CPoint pt, int nIndex)
{
	if(nIndex < 0)
		return FALSE;

	BOOL bRet = FALSE;

	CPoint umPoint, ptChange;
	int nTol = (int)(10 * m_dScale[0]);
	umPoint.x = (int)(m_dDrawStartX[0] + pt.x * m_dScale[0]);
	umPoint.y = (int)(m_dDrawStartY[0] - pt.y * m_dScale[0]);
	ptChange = GetNoAxisChangePos(umPoint);
	
	int nFidIndex = m_Glyphs.GetFiducialIndex(ptChange, nTol);
	
	DAreaInfo* pAreaInfo;
	POSITION pos;
	BOOL bIsThereArea = FALSE;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			
			if(pAreaInfo->m_nSortIndex != nIndex)
			{
				pAreaInfo->m_bCheckIndex = FALSE;
				continue;
			}
			else
			{	
				pAreaInfo->m_bCheckIndex = TRUE;
				bRet = pAreaInfo->DeleteFiducialIndex(nFidIndex);
				return bRet;
			}
		}
	}
	return bRet;
}

BOOL DProject::IsValidFiducialIndex()
{
	return TRUE;
	
/*	int nAreaCount = 0;
	int nCount = 0;
	DAreaInfo* pAreaInfo;
	POSITION pos;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			nAreaCount++;
			pAreaInfo = m_Areas[i].GetNext(pos);
			nCount = pAreaInfo->m_FidIndex.GetCount();
			if(nCount < 2 || nCount > 4)
				return FALSE;
		}
	}
	if(nCount > 0)
		return TRUE;
	else
		return FALSE;
*/
}

void DProject::RemoveUnitCanvas()
{
	UNIT_DATA* pUnitRect;
	for(int i = 0; i < MAX_X_TABLE; i++)
	{
		for(int j = 0; j < MAX_Y_TABLE; j++)
		{
			POSITION pos = m_pUnitCanvas[i*MAX_Y_TABLE + j].GetHeadPosition();
			while(pos)
			{
				pUnitRect = m_pUnitCanvas[i*MAX_Y_TABLE + j].GetNext(pos);
				delete pUnitRect;
			}
			m_pUnitCanvas[i*MAX_Y_TABLE + j].RemoveAll();
		}
	}
}

BOOL DProject::CheckUnitSize()
{
	if(!gProcessINI.m_sProcessSystem.bNoDivideUnit)
		return TRUE;

	int nXSize, nYSize;
	LPDUNIT pUnit;
	POSITION pos = m_Glyphs.m_Units.GetHeadPosition();
	nXSize = m_nDivRangeXDisp * 1000;
	nYSize = m_nDivRangeYDisp * 1000;
	while(pos)
	{
		pUnit = m_Glyphs.m_Units.GetNext(pos);
		if(pUnit->m_nMaxX - pUnit->m_nMinX + 1 > nXSize)
			return FALSE;
		if(pUnit->m_nMaxY - pUnit->m_nMinY + 1 > nYSize)
			return FALSE;
	}
	return TRUE;
}

BOOL DProject::MoveUnit(int nDirection)
{
	return m_Glyphs.MoveUnit(nDirection);
}

CPoint DProject::MoveUnitDP(int nX, int nY)
{
	CPoint ptMove;
	ptMove.x = (int)(nX * m_dScale[0]);
	ptMove.y = (int)(nY * m_dScale[0]);
	ptMove = GetNoAxisChangePos(ptMove);
	m_Glyphs.MoveUnit(ptMove.x, ptMove.y);
	return ptMove;
}

BOOL DProject::IsPickUnit(CPoint ptPoint, int nFidPane)
{
	CPoint umPoint, ptChange;
	int nX = ptPoint.x;
	int nY = ptPoint.y;
	int nTol = (int)(3 * m_dScale[nFidPane]);
	umPoint.x = (int)(m_dDrawStartX[nFidPane] + nX * m_dScale[nFidPane]);
	umPoint.y = (int)(m_dDrawStartY[nFidPane] - nY * m_dScale[nFidPane]);
	
	ptChange = GetNoAxisChangePos(umPoint);

	return m_Glyphs.IsPickUnit(ptChange, nTol);
}

BOOL DProject::DeleteSelectUnit()
{
	return m_Glyphs.DeleteSelectUnit();
}

void DProject::ArrayCopy(int nCopyType, int nShape, int nR, int nCOffsetX, int nCOffsetY, int nX, int nY)
{
	m_Glyphs.ArrayCopy(nCopyType, nShape, nR, nCOffsetX, nCOffsetY, nX, nY);
	if(nCopyType == 0) // circle
	{
		m_nRadius = nR;
		m_nCenterX = nCOffsetX;
		m_nCenterY = nCOffsetY;
	}
}
void DProject::FieldCopy(int nFieldNo, int nRepeatX, int nRepeatY, double dX, double dY)
{
	DAreaInfo* pAreaInfo;
	DAreaInfo* pCopyAreaInfo;
	POSITION pos;
	BOOL bIsThereArea = FALSE;
	double dMoveX, dMoveY;
	int nCount = GetAreaCount();
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			
			if(pAreaInfo->m_nSortIndex == nFieldNo)
			{
				for(int k = 1; k <= nRepeatY; k++)
				{
					for(int q = 1; q <= nRepeatX; q++)
					{
						dMoveX = q * dX * 1000; // um
						dMoveY = k * dY * 1000;

						pCopyAreaInfo = new DAreaInfo();
						pCopyAreaInfo->FieldCopy(pAreaInfo, &m_Glyphs, dMoveX, dMoveY, nCount);
				
						m_Areas[i].AddTail(pCopyAreaInfo);
						nCount ++;

					}
				}		
			}
		} //end of while
	}
}
int DProject::GetAreaCount()
{
	int nCount = 0;
	POSITION pos;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			m_Areas[i].GetNext(pos);
			nCount++;
		}
	}

	return nCount;
}
void DProject::MoveFiducial(CPoint ptPoint, CPoint ptMove)
{
	int nTol = (int)(10 * m_dScale[0]);
	m_Glyphs.MoveFiducial(ptPoint, ptMove, nTol);
}

void DProject::AddMoveUnitsToUndoList()
{
	m_Glyphs.AddMoveUnitsToUndoList();
}

BOOL DProject::GetUnitPos(CPoint& ptPoint)
{
	return m_Glyphs.GetUnitPos(ptPoint);
}

void DProject::MoveUnit(int nX, int nY)
{
	m_Glyphs.MoveUnit(nX, nY);
}

void DProject::ReCalRect()
{
	m_Glyphs.ReCalRect();

	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;

	if(m_nMinX > m_Glyphs.m_nMinX)
		m_nMinX = m_Glyphs.m_nMinX;
	if(m_nMaxX < m_Glyphs.m_nMaxX)
		m_nMaxX = m_Glyphs.m_nMaxX;
	if(m_nMinY > m_Glyphs.m_nMinY)
		m_nMinY = m_Glyphs.m_nMinY;
	if(m_nMaxY < m_Glyphs.m_nMaxY)
		m_nMaxY = m_Glyphs.m_nMaxY;
}

void DProject::SetProjectStatusToExcellOpen()
{
	RemoveAreaList();

	CPoint nptRefFid; // 20091029
	int nSetOrigin = (m_nDataLoadStep &SET_FID_ORIGIN);
	int nX, nY;
	if(FALSE == m_Glyphs.GetRefFidPos(nX, nY))
	{
		nptRefFid.x = nptRefFid.y =INT_MAX;
	}
	else
	{
		nptRefFid.x = nX;
		nptRefFid.y = nY;
	}
	
	if(nptRefFid.x == INT_MAX || nptRefFid != m_nptRefFidPos)
		nSetOrigin = 0;

	if(m_Glyphs.m_Units.GetCount() != 0)
		m_nDataLoadStep = LOAD_EXCELLON + nSetOrigin;
	else
		m_nDataLoadStep = NON_EXCELLON + nSetOrigin;
}

int DProject::IsThereFid(CPoint &pt)
{
	CPoint umPoint, ptChange;
	int nTol = (int)(10 * m_dScale[0]);
	umPoint.x = (int)(m_dDrawStartX[0] + pt.x * m_dScale[0]);
	umPoint.y = (int)(m_dDrawStartY[0] - pt.y * m_dScale[0]);
	ptChange = GetNoAxisChangePos(umPoint);
	
	int nResult = m_Glyphs.IsThereFid(ptChange, nTol);
	if(nResult == -1)
		pt = umPoint;

	return nResult;
}

BOOL DProject::AddSubFiducial(int nIndex)
{
	return m_Glyphs.AddSubFiducial(nIndex);
}

BOOL DProject::IsFireHole(int nFindMethod, LPFIREHOLE pHole, LPFIRELINE pLine, int nTOOL)
{
	if(nFindMethod == FIND_ALL_FID)
		return TRUE;
	else if(nFindMethod == FIND_VISIBLE_ONLY)
	{
		if(pHole)
		{
			if(nTOOL == ADDED_FID_TOOL)
				return TRUE;

			if(m_pToolCode[pHole->pOrigin->nToolNo]->m_bVisible)
				return TRUE;
			else
				return FALSE;
		}
		if(pLine)
		{
			if(m_pToolCode[pLine->pOrigin->nToolNo]->m_bVisible)
				return TRUE;
			else
				return FALSE;
		}
	}
	else
	{
		if(pHole)
		{
			if(nTOOL == ADDED_FID_TOOL)
				return pHole->bSelect;

			if(m_pToolCode[pHole->pOrigin->nToolNo]->m_bVisible && pHole->bSelect)
				return TRUE;
			else
				return FALSE;
		}
		if(pLine)
		{
			if(m_pToolCode[pLine->pOrigin->nToolNo]->m_bVisible && pLine->bSelect)
				return TRUE;
			else
				return FALSE;
		}
	}
	return FALSE;
}

BOOL DProject::CalTablePos(LONG &nTargetSX, LONG &nTargetSY, LONG &nTargetEX, // 
						   LONG &nLeadInTargetX, LONG &nLeadOutTargetX,
						   int nPosSX, int nPosSY, int nPosEX, int nPosEY,	// fid ���� �� ��ġ��
						   int nFileSX, int nFileEX,						// fid ���� �ȵ� ��ġ : ���� ���� �Ǵ�
						   int nRotatePosX, int nRotatePosY,				// theta�� ȸ�� �߽�
						   int nLeadIn, int nLeadOut,
						   double dFidDeg)								// fid ���� angle
{
	BOOL bVertical = FALSE;
	double dRefX, dRefY;
	CDPoint dStartP, dEndP;
	m_Glyphs.GetRefPosition(dRefX, dRefY); // ������ ������ �ǵ���� ���� ��ǥ

	if(nFileEX - nFileSX == 0)
		bVertical = TRUE;

	int nCenterAndRefOffsetX, nCenterAndRefOffsetY;
	nCenterAndRefOffsetX = (int)((nRotatePosX - m_dRefPosX) * 1000);
	nCenterAndRefOffsetY = (int)((nRotatePosY - m_dRefPosY) * 1000);

	dStartP.x = ( nPosSX + nCenterAndRefOffsetX )/ 1000.0 - dRefX;
	dStartP.y = ( nPosSY + nCenterAndRefOffsetY )/ 1000.0 - dRefY;
	dEndP.x = ( nPosEX + nCenterAndRefOffsetX )/ 1000.0 - dRefX;
	dEndP.y = ( nPosEY + nCenterAndRefOffsetY )/ 1000.0 - dRefY;

	if(bVertical)
	{
		dStartP.rotateRadian(CDPoint(0,0), (-90-dFidDeg)*M_PI/180.);
		dEndP.rotateRadian(CDPoint(0,0), (-90-dFidDeg)*M_PI/180.);
	}
	else
	{
		dStartP.rotateRadian(CDPoint(0,0), (-dFidDeg)*M_PI/180.);
		dEndP.rotateRadian(CDPoint(0,0), (-dFidDeg)*M_PI/180.);
	}

	nTargetSX = (int)(dStartP.x * 1000);
	nTargetEX = (int)(dEndP.x * 1000);
	nTargetSY = (int)(dStartP.y * 1000);

	if(dStartP.x > dEndP.x)
	{
		nTargetSX = (int)(dEndP.x * 1000);
		nTargetEX = (int)(dStartP.x * 1000);
	}
	nLeadInTargetX = nTargetSX - nLeadIn;
	nLeadOutTargetX = nTargetEX + nLeadOut;

	nTargetSX		= nRotatePosX - nTargetSX;
	nTargetEX		= nRotatePosX - nTargetEX;
	nTargetSY		= nRotatePosY - nTargetSY;
	nLeadInTargetX	= nRotatePosX - nLeadInTargetX;
	nLeadOutTargetX = nRotatePosX - nLeadOutTargetX;

	if(nLeadInTargetX > gSystemINI.m_sAxisInfo[0].dLimitPlus * 1000 ||
	   nLeadInTargetX < gSystemINI.m_sAxisInfo[0].dLimitMinus * 1000)
	   return FALSE;

	if(nLeadOutTargetX > gSystemINI.m_sAxisInfo[0].dLimitPlus * 1000 ||
		nLeadOutTargetX < gSystemINI.m_sAxisInfo[0].dLimitMinus * 1000)
	   return FALSE;

	if(nTargetSY > gSystemINI.m_sAxisInfo[1].dLimitPlus * 1000 ||
		nTargetSY < gSystemINI.m_sAxisInfo[1].dLimitMinus * 1000)
	   return FALSE;

	return TRUE;
}

void DProject::BackupRefFidPos() // 20091029
{
	int nX, nY;
	if(m_Glyphs.GetRefFidPos(nX, nY))
	{
		m_nptRefFidPos.x = nX;
		m_nptRefFidPos.y = nY;
	}
	else
	{
		m_nptRefFidPos.x = INT_MAX;
		m_nptRefFidPos.y = INT_MAX;
	}
}

void DProject::ResetUseToolFlag()
{
	for(int i = 0; i<MAX_TOOL_NO; i++)
		m_pToolCode[i]->m_bUseTool = FALSE;
}

void DProject::ResetMinMaxData()
{
	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;

	m_Glyphs.m_nMinX		= INT_MAX;
	m_Glyphs.m_nMinY		= INT_MAX;
	m_Glyphs.m_nMaxX		= INT_MIN;
	m_Glyphs.m_nMaxY		= INT_MIN;
}

void DProject::SetFiducial(int nIndex, BOOL bSubFid)
{
	m_Glyphs.SetFiducial(nIndex, bSubFid);
}

void DProject::ResetOneFiducial(int nIndex, BOOL bSubFid)
{
	m_Glyphs.ResetOneFiducial(nIndex, bSubFid);
}

void DProject::ResetAllFiducial(BOOL bSubFid)
{
	m_Glyphs.ResetAllFiducial(bSubFid);
}

void DProject::ResetTempData(int* nUseFid, BOOL& bFind, int& nTotalCnt)
{
	memset(nUseFid, -1, sizeof(int)*(4));
	bFind = FALSE;
	nTotalCnt = 0;
}

void DProject::SetUseFidIndex(LPFIREHOLE pHole, LPFIRELINE pLine, int nFidKind, BOOL bUse, int* nUseFid, BOOL& bFind, int& nTotalCnt, BOOL b1st, int nFidRank)
{
	for(int n=0; n<2; n++) // Main, Sub
	{
		if(bUse && !bFind)
			nTotalCnt = 0;
		
		for(int k=0; k<4; k++) // ���� 4��
		{
			if(pHole)
			{
				if(pHole->pOrigin->nFidIndex[k][n] == -1)
					continue;

				if(bUse && !bFind)
				{
					if(m_Glyphs.GetFidAcquireRet(nFidKind, pHole->pOrigin->nFidIndex[k][n], !b1st, nFidRank))
					{
						nTotalCnt++;
						nUseFid[k] = pHole->pOrigin->nFidIndex[k][n];
					}
				}
			}
			if(pLine)
			{
				if(pLine->pOrigin->nFidIndex[k][n] == -1)
					continue;

				if(bUse && !bFind)
				{
					if(m_Glyphs.GetFidAcquireRet(nFidKind, pLine->pOrigin->nFidIndex[k][n], !b1st, nFidRank))
					{
						nTotalCnt++;
						nUseFid[k] = pLine->pOrigin->nFidIndex[k][n];
					}
				}
			}
		}

		if(bUse && nTotalCnt > 2)
			bFind = TRUE;
		
		if(bFind)
			break;
	}
}

void DProject::GetTransformPoint(double x, double y, double& dXVal, double& dYVal, BOOL b1stPanel, int nFidBlock)
{
	m_RefTrans[!b1stPanel][nFidBlock].TransformPoint(x, y, dXVal, dYVal);
}

void DProject::ResetFiducialArray()
{
	memset(m_ptPrimaryRef, NULL, sizeof(m_ptPrimaryRef));
	memset(m_ptPrimaryTrans, NULL, sizeof(m_ptPrimaryTrans));
	memset(m_ptSecondaryRef, NULL, sizeof(m_ptSecondaryRef));
	memset(m_ptSecondaryTrans, NULL, sizeof(m_ptSecondaryTrans));
	memset(m_ptMidRef, NULL, sizeof(m_ptMidRef));
	memset(m_ptMidTrans, NULL, sizeof(m_ptMidTrans));

	memset(m_npNewOffset, NULL, sizeof(m_npNewOffset));
}

void DProject::SortFiducialPos(int nRefCnt, int nSubCnt)
{
	CPoint ptTemp1[4], ptTemp2[4], ptTemp3[4], ptTemp4[4];
	double dMinX, dMinY, dMaxX, dMaxY;
	double dCenterX, dCenterY;
//	int nIndex;

	// Sorting 
	// 1 2
	// 0 3

	// m_ptPrimaryRef
	dMinX = dMinY = DBL_MAX;
	dMaxX = dMaxY = -DBL_MAX;
	memcpy(ptTemp1, m_ptPrimaryRef, sizeof(m_ptPrimaryRef));
	memcpy(ptTemp2, m_ptPrimaryTrans, sizeof(m_ptPrimaryTrans));
	memcpy(ptTemp3, m_ptSecondaryRef, sizeof(m_ptSecondaryRef));
	memcpy(ptTemp4, m_ptSecondaryTrans, sizeof(m_ptSecondaryTrans));

	for(int k=0; k<nRefCnt; k++)
	{
		if(ptTemp1[k].x < dMinX) dMinX = ptTemp1[k].x;
		if(ptTemp1[k].y < dMinY) dMinY = ptTemp1[k].y;
		if(ptTemp1[k].x > dMaxX) dMaxX = ptTemp1[k].x;
		if(ptTemp1[k].y > dMaxY) dMaxY = ptTemp1[k].y;
	}
	dCenterX = (dMaxX + dMinX) / 2.0;
	dCenterY = (dMaxY + dMinY) / 2.0;

	for(int k=0; k<nRefCnt; k++)
	{
		// m_ptPrimaryRef
		if(ptTemp1[k].x < dCenterX && ptTemp1[k].y < dCenterY)
			m_ptPrimaryRef[0] = ptTemp1[k];
		if(ptTemp1[k].x < dCenterX && ptTemp1[k].y > dCenterY)
			m_ptPrimaryRef[1] = ptTemp1[k];
		if(ptTemp1[k].x > dCenterX && ptTemp1[k].y > dCenterY)
			m_ptPrimaryRef[2] = ptTemp1[k];
		if(ptTemp1[k].x > dCenterX && ptTemp1[k].y < dCenterY)
			m_ptPrimaryRef[3] = ptTemp1[k];

		// m_ptPrimaryTrans
		if(ptTemp2[k].x < dCenterX && ptTemp2[k].y < dCenterY)
			m_ptPrimaryTrans[0] = ptTemp2[k];
		if(ptTemp2[k].x < dCenterX && ptTemp2[k].y > dCenterY)
			m_ptPrimaryTrans[1] = ptTemp2[k];
		if(ptTemp2[k].x > dCenterX && ptTemp2[k].y > dCenterY)
			m_ptPrimaryTrans[2] = ptTemp2[k];
		if(ptTemp2[k].x > dCenterX && ptTemp2[k].y < dCenterY)
			m_ptPrimaryTrans[3] = ptTemp2[k];

		// m_ptSecondaryRef
		if(ptTemp3[k].x < dCenterX && ptTemp3[k].y < dCenterY)
			m_ptSecondaryRef[0] = ptTemp3[k];
		if(ptTemp3[k].x < dCenterX && ptTemp3[k].y > dCenterY)
			m_ptSecondaryRef[1] = ptTemp3[k];
		if(ptTemp3[k].x > dCenterX && ptTemp3[k].y > dCenterY)
			m_ptSecondaryRef[2] = ptTemp3[k];
		if(ptTemp3[k].x > dCenterX && ptTemp3[k].y < dCenterY)
			m_ptSecondaryRef[3] = ptTemp3[k];

		// m_ptSecondaryTrans
		if(ptTemp4[k].x < dCenterX && ptTemp4[k].y < dCenterY)
			m_ptSecondaryTrans[0] = ptTemp4[k];
		if(ptTemp4[k].x < dCenterX && ptTemp4[k].y > dCenterY)
			m_ptSecondaryTrans[1] = ptTemp4[k];
		if(ptTemp4[k].x > dCenterX && ptTemp4[k].y > dCenterY)
			m_ptSecondaryTrans[2] = ptTemp4[k];
		if(ptTemp4[k].x > dCenterX && ptTemp4[k].y < dCenterY)
			m_ptSecondaryTrans[3] = ptTemp4[k];
	}
}

void DProject::CalFiducialPos(int nRefCnt, int nSubCnt, BOOL b1st, BOOL bUseMidCal)
{
	CPoint npFile, npOffset;

	for(int k=0; k<nRefCnt; k++) // Primary Fiducial
	{
		if(b1st)
		{
			npFile = m_Glyphs.GetUseFidIntPoint(DEFAULT_FID_INDEX, m_n1stBaseFid[k]);
			npOffset = m_Glyphs.GetUseFidIntOffset(DEFAULT_FID_INDEX, m_n1stBaseFid[k], TRUE);
		}
		else
		{
			npFile = m_Glyphs.GetUseFidIntPoint(DEFAULT_FID_INDEX, m_n2ndBaseFid[k]);
			npOffset = m_Glyphs.GetUseFidIntOffset(DEFAULT_FID_INDEX, m_n2ndBaseFid[k], FALSE);
		}
		
		// Ref
		m_ptPrimaryRef[k].x = npFile.x;
		m_ptPrimaryRef[k].y = npFile.y;
		
		// Trans
		m_ptPrimaryTrans[k].x = npFile.x + npOffset.x;
		m_ptPrimaryTrans[k].y = npFile.y + npOffset.y;
	}
	
	for(int k = 0; k<nSubCnt; k++) // Secondary Fiducial
	{
		if(b1st)
		{
			npFile = m_Glyphs.GetUseFidIntPoint(DEFAULT_FID_INDEX, m_n1stSubFid[k]);
			npOffset = m_Glyphs.GetUseFidIntOffset(DEFAULT_FID_INDEX, m_n1stSubFid[k], TRUE);
		}
		else
		{
			npFile = m_Glyphs.GetUseFidIntPoint(DEFAULT_FID_INDEX, m_n2ndSubFid[k]);
			npOffset = m_Glyphs.GetUseFidIntOffset(DEFAULT_FID_INDEX, m_n2ndSubFid[k], FALSE);
		}
		
		// Ref
		m_ptSecondaryRef[k].x = npFile.x;
		m_ptSecondaryRef[k].y = npFile.y;
		
		// Trans
		m_ptSecondaryTrans[k].x = npFile.x + npOffset.x;
		m_ptSecondaryTrans[k].y = npFile.y + npOffset.y;
	}
	
	if(bUseMidCal)		//�߰��� ����� �ʿ��� ��Ȳ������ ���
	{
		SortFiducialPos(nRefCnt, nSubCnt);
		
		// Primary,Secondary �߰��� ���ϱ� (Ref, Trans �Ѵ�)
		for(int k = 0; k<nRefCnt; k++)
		{
			m_ptMidRef[k].x = (long)((m_ptPrimaryRef[k].x + m_ptSecondaryRef[k].x) / 2.0);
			m_ptMidRef[k].y = (long)((m_ptPrimaryRef[k].y + m_ptSecondaryRef[k].y) / 2.0);
			
			m_ptMidTrans[k].x = (long)((m_ptPrimaryTrans[k].x + m_ptSecondaryTrans[k].x) / 2.0);
			m_ptMidTrans[k].y = (long)((m_ptPrimaryTrans[k].y + m_ptSecondaryTrans[k].y) / 2.0);
		}
	}
}

BOOL DProject::CalTransformAndScaleCoaseAndSlive(int nRefCnt, BOOL b1st, int nFidType, BOOL bCoarse)
{
	CString strFile, strFidOffset;
	strFile.Format(_T("FidFailData"));
	CPoint npFile, npOffset, npTablePos;
	LPFIDDATA pFidData;
	int nRetScale;
	int nFidCount[MAX_FID_BLOCK];
	memset(nFidCount, 0, sizeof(int) * MAX_FID_BLOCK);
	m_bFidInfoChangeForScale = FALSE;

	for(int i = 0; i < MAX_FID_BLOCK; i++)
	{
		m_RefTrans[!b1st][i].SetNumPoint(0);
	}

	for(int i = 0; i < m_Glyphs.GetFidCount(DEFAULT_FID_INDEX); i++)
	{
		pFidData = m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
		
		if(pFidData->nFidType & FID_VERIFY)
			continue;

		if((pFidData->bAcquire[0] && b1st) ||
			(pFidData->bAcquire[1] && !b1st) )
		{
			if(((bCoarse && (pFidData->nFidType & FID_SECONDARY)) ||  
				(!bCoarse && (pFidData->nFidType & FID_PRIMARY))) && pFidData->cType != FID_FILE_NOT_USE)
				nFidCount[pFidData->nFidBlock]++;
			else if(pFidData->nFidType & nFidType)
				nFidCount[pFidData->nFidBlock]++;
		}
	}

	for(int nFidBlockCnt=0; nFidBlockCnt<=m_nMaxFidBlock; nFidBlockCnt++)	// fid block ���� ��ŭ Num point ����
	{
		m_RefTrans[!b1st][nFidBlockCnt].SetNumPoint(nFidCount[nFidBlockCnt]);
		m_TablePosTrans[!b1st][nFidBlockCnt].SetNumPoint(nFidCount[nFidBlockCnt]); // 20130312
	}

	memset(nFidCount, 0, sizeof(int) * MAX_FID_BLOCK);

	for(int k=0; k<nRefCnt; k++)
	{
		if(b1st)
		{
			pFidData = m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_n1stBaseFid[k]);
			npFile = pFidData->npPosition;// m_Glyphs.GetUseFidIntPoint(DEFAULT_FID_INDEX, m_n1stBaseFid[k]);
			npOffset = pFidData->npTransPosition;//m_Glyphs.GetUseFidIntOffset(DEFAULT_FID_INDEX, m_n1stBaseFid[k], TRUE);
			npTablePos = pFidData->npTablePos1;// 20130312
		}
		else
		{
			pFidData = m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_n2ndBaseFid[k]);
			npFile = pFidData->npPosition;//m_Glyphs.GetUseFidIntPoint(DEFAULT_FID_INDEX, m_n2ndBaseFid[k]);
			npOffset = pFidData->npTransPosition2;//m_Glyphs.GetUseFidIntOffset(DEFAULT_FID_INDEX, m_n2ndBaseFid[k], FALSE);
			npTablePos = pFidData->npTablePos2;// 20130312
		}

		if(( pFidData->cType != FID_FILE_NOT_USE && 
			((bCoarse && (pFidData->nFidType & FID_SECONDARY)) || (!bCoarse && (pFidData->nFidType & FID_PRIMARY)))) ||
			(pFidData->nFidType & nFidType))
		{
			m_RefTrans[!b1st][pFidData->nFidBlock].SetReferencePoint(npFile.x, npFile.y, nFidCount[pFidData->nFidBlock]);
			m_RefTrans[!b1st][pFidData->nFidBlock].SetTransformedPoint(npFile.x + npOffset.x, npFile.y + npOffset.y, nFidCount[pFidData->nFidBlock]);

			m_TablePosTrans[!b1st][pFidData->nFidBlock].SetReferencePoint(npFile.x, npFile.y, nFidCount[pFidData->nFidBlock]);// 20130312
			m_TablePosTrans[!b1st][pFidData->nFidBlock].SetTransformedPoint(npTablePos.x, npTablePos.y, nFidCount[pFidData->nFidBlock]);

			if(pFidData->bCheckScaleLimit) // �ϳ��� üũ�ϰ� �Ǿ� ������ üũ��.
			{
				m_RefTrans[!b1st][pFidData->nFidBlock].SetCheckScaleLimit(TRUE);
			}
			m_npNewOffset[pFidData->nFidBlock][nFidCount[pFidData->nFidBlock]++] = 0;
//			m_npNewOffset[pFidData->nFidBlock][nFidCount[pFidData->nFidBlock]] = 0;
		}
	}

	for(int k = 0; k<=m_nMaxFidBlock; k++)
	{
		m_RefTrans[!b1st][k].Transform();	//fid block ���� ��ŭ Transform
		m_TablePosTrans[!b1st][k].Transform(); // 20130312
	}

	if(!CalculateFidAngle(b1st, nRefCnt))
	{
		strFidOffset.Format(_T("Panel Location mis match Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		return FALSE;
	}

	nRetScale = CalculateFidScale(b1st, nRefCnt);
	if(nRetScale == -1)
	{
		strFidOffset.Format(_T("Panel Scale Cal. Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		return FALSE;
	}
	else if(nRetScale == 1) // ���� Transform
	{
		strFidOffset.Format(_T("Fiducial Info. is changed"));// 20130312
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));

		for(int k = 0; k<=m_nMaxFidBlock; k++)
		{
			m_RefTrans[!b1st][k].Transform();	//fid block ���� ��ŭ Transform
		}
		m_bFidInfoChangeForScale = TRUE;
	}

	return TRUE;
}

BOOL DProject::CalTransformAndScale(int nRefCnt, int nSubCnt, BOOL b1st, int nFiducialFindType)
{
	CString strFile, strFidOffset;
	strFile.Format(_T("FidFailData"));
	CPoint npFile, npOffset;
	int nRetScale;
	m_bFidInfoChangeForScale = FALSE;

	for(int i = 0; i < MAX_FID_BLOCK; i++)
	{
		m_RefTrans[!b1st][i].SetNumPoint(0);
	}

	m_RefTrans[!b1st][0].SetNumPoint(nSubCnt);
//	m_RefTrans[!b1st][0].Transform();	//fid block ���� ��ŭ Transform

	for(int k=0; k<nRefCnt; k++)
	{
		if(nFiducialFindType == MID_FIDUCIAL)
		{
			npFile = m_ptMidRef[k];
			npOffset = m_ptMidTrans[k];
		}
		else if(nFiducialFindType == COARSE_FIDUCIAL)
		{
			npFile = m_ptSecondaryRef[k];
			npOffset = m_ptSecondaryTrans[k];
		}
		
		m_RefTrans[!b1st][0].SetReferencePoint(npFile.x, npFile.y, k);
		m_RefTrans[!b1st][0].SetTransformedPoint(npOffset.x, npOffset.y, k);
	}
	m_RefTrans[!b1st][0].Transform();

	// Scale����
	if(!CalculateFidAngle(b1st, nRefCnt))
	{
		strFidOffset.Format(_T("Panel Location mis match Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		return FALSE;
	}

	nRetScale = CalculateFidScale(b1st, nRefCnt);
	if(nRetScale == -1)
	{
		strFidOffset.Format(_T("Panel Scale Cal. Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		return FALSE;
	}
	else if(nRetScale == 1) // ���� Transform
	{
		strFidOffset.Format(_T("Fiducial Info. is changed : 2nd"));// 20130312
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));

		m_RefTrans[!b1st][0].Transform();
		m_bFidInfoChangeForScale = TRUE;
	}

	return TRUE;
}


BOOL DProject::DoTransform(int nRefCnt, BOOL b1st, int nFidType, BOOL bCoarse)
{
	CString strFile, strFidOffset;
	strFile.Format(_T("FidFailData"));
	CPoint npFile, npOffset, npTablePos;
	LPFIDDATA pFidData;
	int nFidCount[MAX_FID_BLOCK];
	memset(nFidCount, 0, sizeof(int) * MAX_FID_BLOCK);
	
	for(int i = 0; i < MAX_FID_BLOCK; i++)
	{
		m_RefTrans[!b1st][i].SetNumPoint(0);
	}
	
	for(int i = 0; i < m_Glyphs.GetFidCount(DEFAULT_FID_INDEX); i++)
	{
		pFidData = m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
		
		if(pFidData->nFidType & FID_VERIFY)
			continue;
		
		if((pFidData->bAcquire[0] && b1st) ||
			(pFidData->bAcquire[1] && !b1st) )
		{
			if(((bCoarse && (pFidData->nFidType & FID_SECONDARY)) || (!bCoarse && (pFidData->nFidType & FID_PRIMARY))) && 
				pFidData->cType != FID_FILE_NOT_USE)
				nFidCount[pFidData->nFidBlock]++;
			else if(pFidData->nFidType & nFidType)
				nFidCount[pFidData->nFidBlock]++;
		}
	}
	
	for(int nFidBlockCnt=0; nFidBlockCnt<=m_nMaxFidBlock; nFidBlockCnt++)	// fid block ���� ��ŭ Num point ����
	{
		m_RefTrans[!b1st][nFidBlockCnt].SetNumPoint(nFidCount[nFidBlockCnt]);
		m_TablePosTrans[!b1st][nFidBlockCnt].SetNumPoint(nFidCount[nFidBlockCnt]); // 20130312
	}
	
	memset(nFidCount, 0, sizeof(int) * MAX_FID_BLOCK);
	
	for(int k=0; k<nRefCnt; k++)
	{
		if(b1st)
		{
			pFidData = m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_n1stBaseFid[k]);
			npFile = pFidData->npPosition;// m_Glyphs.GetUseFidIntPoint(DEFAULT_FID_INDEX, m_n1stBaseFid[k]);
			npOffset = pFidData->npTransPosition;//m_Glyphs.GetUseFidIntOffset(DEFAULT_FID_INDEX, m_n1stBaseFid[k], TRUE);
			npTablePos = pFidData->npTablePos1; // 20130312
		}
		else
		{
			pFidData = m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, m_n2ndBaseFid[k]);
			npFile = pFidData->npPosition;//m_Glyphs.GetUseFidIntPoint(DEFAULT_FID_INDEX, m_n2ndBaseFid[k]);
			npOffset = pFidData->npTransPosition2;//m_Glyphs.GetUseFidIntOffset(DEFAULT_FID_INDEX, m_n2ndBaseFid[k], FALSE);
			npTablePos = pFidData->npTablePos2; // 20130312
		}
		
		if(( pFidData->cType != FID_FILE_NOT_USE && 
			((bCoarse && (pFidData->nFidType & FID_SECONDARY)) || (!bCoarse && (pFidData->nFidType & FID_PRIMARY)))) ||
			(pFidData->nFidType & nFidType))
		{
			m_RefTrans[!b1st][pFidData->nFidBlock].SetReferencePoint(npFile.x, npFile.y, nFidCount[pFidData->nFidBlock]);
			m_RefTrans[!b1st][pFidData->nFidBlock].SetTransformedPoint(npFile.x + npOffset.x, npFile.y + npOffset.y, nFidCount[pFidData->nFidBlock]);

			m_TablePosTrans[!b1st][pFidData->nFidBlock].SetReferencePoint(npFile.x, npFile.y, nFidCount[pFidData->nFidBlock]);// 20130312
			m_TablePosTrans[!b1st][pFidData->nFidBlock].SetTransformedPoint(npTablePos.x, npTablePos.y, nFidCount[pFidData->nFidBlock]);

			m_npNewOffset[pFidData->nFidBlock][nFidCount[pFidData->nFidBlock]++] = 0;
			if(pFidData->bCheckScaleLimit) // �ϳ��� üũ�ϰ� �Ǿ� ������ üũ��.
			{
				m_RefTrans[!b1st][pFidData->nFidBlock].SetCheckScaleLimit(TRUE);
			}
			//			m_npNewOffset[pFidData->nFidBlock][nFidCount[pFidData->nFidBlock]] = 0;
		}
	}
	
	for(int k = 0; k<=m_nMaxFidBlock; k++)
	{
		m_RefTrans[!b1st][k].Transform();	//fid block ���� ��ŭ Transform
		m_TablePosTrans[!b1st][k].Transform();// 20130312
	}

	return TRUE;
}

BOOL DProject::CalScale(int nRefCnt, BOOL b1st, BOOL bCoarse)
{
	CString strFile, strFidOffset;
	strFile.Format(_T("FidFailData"));
	CPoint npFile, npOffset;
	int nRetScale;
	int nFidCount[MAX_FID_BLOCK];
	memset(nFidCount, 0, sizeof(int) * MAX_FID_BLOCK);
	m_bFidInfoChangeForScale = FALSE;

	if(!CalculateFidAngle(b1st, nRefCnt))
	{
		strFidOffset.Format(_T("Panel Location mis match Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		return FALSE;
	}

	nRetScale = CalculateFidScale(b1st, nRefCnt);
	if(nRetScale == -1)
	{
		strFidOffset.Format(_T("Panel Scale Cal. Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		return FALSE;
	}
	else if(nRetScale == 1) // ���� Transform
	{
		strFidOffset.Format(_T("Fiducial Info. is changed : CalScale"));// 20130312
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));

		for(int k = 0; k<=m_nMaxFidBlock; k++)
		{
			m_RefTrans[!b1st][k].Transform();	//fid block ���� ��ŭ Transform
		}
		m_bFidInfoChangeForScale = TRUE;
	}
	return TRUE;
}

void DProject::GetHoleDistance()
{
	POSITION pos, posHole;
	DAreaInfo* pAreaInfo;
	BOOL bFirst;
	CPoint ptOldPoint;
	int		nCount[1000];
	int		nMaxDist;
	LPFIREHOLE pHole;
	memset(nCount, 0, sizeof(nCount));
	for(int i = ADDED_FID_TOOL + 1; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			bFirst = TRUE;
			pAreaInfo = m_Areas[i].GetNext(pos);
			for(int j = ADDED_FID_TOOL + 1; j < MAX_TOOL_NO; j++)
			{
				if(!m_pToolCode[j]->m_bUseTool)
					continue;

				posHole = pAreaInfo->m_FireHoles[j].GetHeadPosition();
				while (posHole)
				{
					pHole = pAreaInfo->m_FireHoles[j].GetNext(posHole);		
					if(bFirst)
					{
						bFirst = FALSE;
						ptOldPoint = pHole->pOrigin->npPos;
						continue;
					}
					nMaxDist = max(abs(pHole->pOrigin->npPos.x - ptOldPoint.x), abs(pHole->pOrigin->npPos.y - ptOldPoint.y));
					nCount[(nMaxDist%100000)/100]++;
					ptOldPoint = pHole->pOrigin->npPos;
				}
			}
		}
	}

	CString strPath;
	strPath.Format(_T("%s\\ProjectDistanceInfo.txt"), gEasyDrillerINI.m_clsDirPath.GetTempDir());
	FILE* pfile;
	errno_t err = fopen_s(&pfile, strPath, "w+");
	if(err != 0)
		pfile = NULL;

	fprintf(pfile,_T("Hole Distance\n"));
	for(int i = 0; i < 1000; i++)
	{
		if(nCount[i] > 0)
			fprintf(pfile,_T("%d\t%d\n"), (i+1)*100, nCount[i]);
	}

	LPFIRELINE pLine;
	memset(nCount, 0, sizeof(nCount));
	for(int i = ADDED_FID_TOOL + 1; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			for(int j = ADDED_FID_TOOL + 1; j < MAX_TOOL_NO; j++)
			{
				if(!m_pToolCode[j]->m_bUseTool)
					continue;

				posHole = pAreaInfo->m_FireLines[j].GetHeadPosition();
				while (posHole)
				{
					pLine = pAreaInfo->m_FireLines[j].GetNext(posHole);		
					nCount[j] += (int)(sqrt((double)(pLine->npStartPos.x - pLine->npEndPos.x) * (pLine->npStartPos.x - pLine->npEndPos.x) + 
									        (double)(pLine->npStartPos.y - pLine->npEndPos.y) * (pLine->npStartPos.y - pLine->npEndPos.y)));
				}
			}
		}
	}

	fprintf(pfile,_T("\nLine Distance\n"));
	for(int i = ADDED_FID_TOOL + 1; i < MAX_TOOL_NO; i++)
	{
		if(nCount[i] > 0)
			fprintf(pfile,_T("%d\t%d\n"), i, nCount[i]);
	}

	if(pfile) fclose(pfile);
}

void DProject::CalScaleLimit(double dAvgScaleX, double dAvgScaleY)
{

#ifdef __KUNSAN_SAMSUNG_LARGE__
	m_dScaleLimitX1Minus = m_dMeanScale - m_dScaleTolerance1;
	m_dScaleLimitY1Minus = m_dMeanScale - m_dScaleTolerance1;

	m_dScaleLimitX1Pluse = m_dMeanScale + m_dScaleTolerance1;
	m_dScaleLimitY1Pluse = m_dMeanScale + m_dScaleTolerance1;

	m_dScaleLimitX2Minus = m_dMeanScale - m_dScaleTolerance2;
	m_dScaleLimitY2Minus = m_dMeanScale - m_dScaleTolerance2;

	m_dScaleLimitX2Pluse = m_dMeanScale + m_dScaleTolerance2;
	m_dScaleLimitY2Pluse = m_dMeanScale + m_dScaleTolerance2;
#else
	m_dScaleLimitX1Minus = dAvgScaleX - m_dScaleTolerance2;
	m_dScaleLimitY1Minus = dAvgScaleY - m_dScaleTolerance2;

	m_dScaleLimitX1Pluse = dAvgScaleX + m_dScaleTolerance2;
	m_dScaleLimitY1Pluse = dAvgScaleY + m_dScaleTolerance2;

	m_dScaleLimitX2Minus = dAvgScaleX - m_dScaleTolerance2;
	m_dScaleLimitY2Minus = dAvgScaleY - m_dScaleTolerance2;

	m_dScaleLimitX2Pluse = dAvgScaleX + m_dScaleTolerance2;
	m_dScaleLimitY2Pluse = dAvgScaleY + m_dScaleTolerance2;
#endif

}

void DProject::InitFidTolData()
{
	m_dScaleLimitX1Pluse = 100.5;
	m_dScaleLimitX2Pluse = 100.5; 
	m_dScaleLimitY1Pluse = 100.5; 
	m_dScaleLimitY2Pluse = 100.5; 
	m_dScaleLimitX1Minus = 99.5; 
	m_dScaleLimitX2Minus = 99.5; 
	m_dScaleLimitY1Minus = 99.5;
	m_dScaleLimitY2Minus = 99.5; 
}

BOOL DProject::CheckScalVal(double dAvgScaleX, double dAvgScaleY)
{
	if(m_dScaleLimitX2Minus > dAvgScaleX || m_dScaleLimitX2Pluse < dAvgScaleX)
		return FALSE;

	if(m_dScaleLimitY2Minus > dAvgScaleY || m_dScaleLimitY2Pluse < dAvgScaleY)
		return FALSE;

	return TRUE;
}

void DProject::SaveLogTransInfo()
{
	CString strFile, strFidOffset;
	strFile.Format(_T("FidTransInfo"));
	int nFidCount;
	
	for(int i = 0; i < MAX_FID_BLOCK; i++)
	{
		nFidCount = m_RefTrans[0][i].GetNumPoint();
		for(int j = 0; j < nFidCount; j++)
		{
			strFidOffset.Format(_T("1st\t%d\t %d %d %d %d"), i, (int)(m_RefTrans[0][i].GetRefsPoint(i).x), (int)(m_RefTrans[0][i].GetRefsPoint(i).y),
																(int)(m_RefTrans[0][i].GetTransPoint(i).x), (int)(m_RefTrans[0][i].GetTransPoint(i).y));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		}
		nFidCount = m_RefTrans[1][i].GetNumPoint();
		for(int j = 0; j < nFidCount; j++)
		{
			strFidOffset.Format(_T("1st\t%d\t %d %d %d %d"), i, (int)(m_RefTrans[1][i].GetRefsPoint(i).x), (int)(m_RefTrans[1][i].GetRefsPoint(i).y),
																(int)(m_RefTrans[1][i].GetTransPoint(i).x), (int)(m_RefTrans[1][i].GetTransPoint(i).y));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
		}
	}
}
BOOL DProject::ChangeMarkingParam(DProject& myProject, CString strPath)
{
	BOOL bChange = FALSE;

	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		if(!m_pToolCode[i]->IsSameTool(myProject.m_pToolCode[i], TRUE))
		{
			bChange = TRUE;
		}
	}
	if(bChange)	
		SaveMarkingParam(myProject, strPath);

	return TRUE;
}

void DProject::SaveMarkingParam(DProject& myProject, CString strPrjPath)
{
	SUBTOOLDATA subTool, subToolRef;
	POSITION pos;
	POSITION posRef;
	CString strName, strData, strChange, strCurrent, strTemp, str1, str2;
	CString strPath = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CTime curDate = CTime::GetCurrentTime();
	strData.Format("%s", myProject.m_szFileName);
	int nIndex = strData.ReverseFind(_T('\\'));
	strData = strData.Mid(nIndex+1);
	nIndex = strData.ReverseFind(_T('.'));	
	strData = strData.Left(nIndex);

	strCurrent.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());

	strName.Format(_T("ChangeToolInfo_%s_%s.txt"), strData, strCurrent);
	strPath += strName;

	CFileFind find;
	BOOL bExist = TRUE;
	bExist = find.FindFile((LPCTSTR)strPath);

	CStdioFile file;
	if (FALSE == file.Open(strPath, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;

	int nSubCount =0;
	TRY
	{
		if(!bExist)
		{
			strTemp.Format(_T("Item\t\tBefore\tAfter\tChange\n"));
			file.Write(strTemp, strTemp.GetLength());
			strTemp.Format(_T("------------------------------------------------------------\n"));
			file.Write(strTemp, strTemp.GetLength());
		}
	
		file.SeekToEnd();
		strTemp.Format(_T("Time : %02d:%02d:%02d\n"), curDate.GetHour(), curDate.GetMinute(), curDate.GetSecond());
		file.Write(strTemp, strTemp.GetLength());
		strTemp.Format(_T("Data : %s\n"), m_szFileName);
		file.Write(strTemp, strTemp.GetLength());
		strTemp.Format(_T("Project : %s\n"), strPrjPath);
		file.Write(strTemp, strTemp.GetLength());

	
		for(int i = 0; i < MAX_TOOL_NO; i++)
		{

			if(myProject.m_pToolCode[i]->m_bUseTool)
			{
				strTemp.Format(_T("# Tool %d \n"), i);
				file.Write(strTemp, strTemp.GetLength());

				nSubCount = 0;
				posRef = m_pToolCode[i]->m_SubToolData.GetHeadPosition();
				pos = myProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();

				while(pos)
				{
					nSubCount++;
					strTemp.Format(_T("## SubTool %d ##\n"), nSubCount);
					file.Write(strTemp, strTemp.GetLength());

					if(posRef)
						subTool = m_pToolCode[i]->m_SubToolData.GetNext(posRef); // old 
					else 
					{
						SUBTOOLDATA subTemp;
						memset(&subTemp, 0, sizeof(SUBTOOLDATA));
						subTool = subTemp;
					}
					if(pos)
						subToolRef = myProject.m_pToolCode[i]->m_SubToolData.GetNext(pos); // new 


					if(subTool.nToolType != subToolRef.nToolType) // tool type
						strChange.Format(_T("o"));
					else
						strChange.Format(_T(" "));

					strTemp.Format(_T("Tool Type\t%d\t%d\t%s\n"), subTool.nToolType, subToolRef.nToolType, strChange);
					file.Write(strTemp, strTemp.GetLength());

					if(subTool.nMask != subToolRef.nMask) // beampath
						strChange.Format(_T("o"));
					else
						strChange.Format(_T(" "));

					strTemp.Format(_T("BeamPath\t%d\t%d\t%s\n"), subTool.nMask, subToolRef.nMask, strChange);
					file.Write(strTemp, strTemp.GetLength());

					if(subTool.nTotalShot != subToolRef.nTotalShot) // TotalShot
						strChange.Format(_T("o"));
					else
						strChange.Format(_T(" "));

					strTemp.Format(_T("Total Shot\t%d\t%d\t%s\n"), subTool.nTotalShot, subToolRef.nTotalShot, strChange);
					file.Write(strTemp, strTemp.GetLength());

					if(subTool.nBurstShot != subToolRef.nBurstShot) // Bust Shot
						strChange.Format(_T("o"));
					else
						strChange.Format(_T(" "));

					strTemp.Format(_T("Bust Shot\t%d\t%d\t%s\n"), subTool.nBurstShot, subToolRef.nBurstShot, strChange);
					file.Write(strTemp, strTemp.GetLength());

					if(subTool.bUseAperture != subToolRef.bUseAperture) // Use Aperture
						strChange.Format(_T("o"));
					else
						strChange.Format(_T(" "));

					strTemp.Format(_T("Use Aperture\t%d\t%d\t%s\n"), subTool.bUseAperture, subToolRef.bUseAperture, strChange);
					file.Write(strTemp, strTemp.GetLength());
					
					if(subTool.nApertureBurst != subToolRef.nApertureBurst) // Aperture Bust
						strChange.Format(_T("o"));
					else
						strChange.Format(_T(" "));

					strTemp.Format(_T("Aperture Bust\t%d\t%d\t%s\n"), subTool.nApertureBurst, subToolRef.nApertureBurst, strChange);
					file.Write(strTemp, strTemp.GetLength());

					if(subTool.nLaserOnDelay != subToolRef.nLaserOnDelay) // Laser On Delay
						strChange.Format(_T("o"));
					else
						strChange.Format(_T(" "));

					strTemp.Format(_T("Laser On Delay\t%d\t%d\t%s\n"), subTool.nLaserOnDelay, subToolRef.nLaserOnDelay, strChange);
					file.Write(strTemp, strTemp.GetLength());

					if(subTool.nLaserOnDelay != subToolRef.nLaserOnDelay) // Laser On Delay
						strChange.Format(_T("o"));
					else
						strChange.Format(_T(" "));

					strTemp.Format(_T("Laser On Delay\t%d\t%d\t%s\n"), subTool.nLaserOnDelay, subToolRef.nLaserOnDelay, strChange);
					file.Write(strTemp, strTemp.GetLength());

					if(subTool.nLaserOffDelay != subToolRef.nLaserOffDelay) // Laser Off Delay
						strChange.Format(_T("o"));
					else
						strChange.Format(_T(" "));

					strTemp.Format(_T("Laser Off Delay\t%d\t%d\t%s\n"), subTool.nLaserOffDelay, subToolRef.nLaserOffDelay, strChange);
					file.Write(strTemp, strTemp.GetLength());

					if(subTool.nDrawStepPeriod != subToolRef.nDrawStepPeriod) // Draw Speed
						strChange.Format(_T("o"));
					else
						strChange.Format(_T(" "));

					strTemp.Format(_T("DrawSpeed\t%d\t%d\t%s\n"), subTool.nDrawStepPeriod, subToolRef.nDrawStepPeriod, strChange);
					file.Write(strTemp, strTemp.GetLength());

					str1.Format(_T("%s"), subTool.cAOMFilePath[i]);
					str2.Format(_T("%s"), subToolRef.cAOMFilePath[i]);
					
					if(0 != str1.CompareNoCase(str2)) // Aperture path
						strChange.Format(_T("o"));
					else
						strChange.Format(_T(" "));

					strTemp.Format(_T("AperturePath\t%s\t%s\t%s\n"),  subTool.cAOMFilePath[i], subToolRef.cAOMFilePath[i], strChange);
					file.Write(strTemp, strTemp.GetLength());
				
					

					for(int i=0; i < subToolRef.nTotalShot; i++)
					{
						if(subTool.dShotDuty[i] != subToolRef.dShotDuty[i]) // Draw Speed
							strChange.Format(_T("o"));
						else
							strChange.Format(_T(" "));

						strTemp.Format(_T("ShotDuty%d\t%.1f\t%.1f\t%s\n"), i, subTool.dShotDuty[i], subToolRef.dShotDuty[i], strChange);
						file.Write(strTemp, strTemp.GetLength());

						if(subTool.dShotMaxFreq[i] != subToolRef.dShotMaxFreq[i]) // Draw Speed
							strChange.Format(_T("o"));
						else
							strChange.Format(_T(" "));

						strTemp.Format(_T("MaxFreq%d\t%.1f\t%.1f\t%s\n"), i, subTool.dShotMaxFreq[i], subToolRef.dShotMaxFreq[i], strChange);
						file.Write(strTemp, strTemp.GetLength());

					}
				}
			}
		}
		strTemp.Format(_T("------------------------------------------------------------\n"));
		file.Write(strTemp, strTemp.GetLength());
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		file.Close();
	}
	END_CATCH

	file.Close();
}

BOOL DProject::LoadLPCData(CString strFilePath)
{
	FILE* pFile;
	errno_t err = fopen_s(&pFile, strFilePath, _T("rb"));
	if (err != NULL)
		return FALSE;

	// MAX_LPC_HOLE_INFO 50000
	int nAreaIndex, nSubToolIndex, nShotIndex;
	int nOldAreaIndex = -1;
	int nNGType;
	DAreaInfo* pAreaInfo;
	CPoint ptFilePos;
	
	while(nNGType = GetOneBadLPCIndex(pFile, nAreaIndex, nSubToolIndex, nShotIndex, ptFilePos))
	{
//		if(nOldAreaIndex != nAreaIndex)
//		{
			pAreaInfo = FindLPCArea(nAreaIndex);
			if(pAreaInfo == NULL)
			{
				fclose(pFile);
				return FALSE;
			}
			if(!FindLPCDataAndCheckIt(pAreaInfo, ptFilePos, nNGType))
			{
				fclose(pFile);
				return FALSE;
			}
//		}
//		nOldAreaIndex = nAreaIndex;
	}
	fclose(pFile);
	return TRUE;
}

BOOL  DProject::FindLPCDataAndCheckIt(DAreaInfo* pAreaInfo, CPoint ptFilePos, int nNGType)
{
	LPFIREHOLE pHole;
	POSITION pos;
	for(int i = ADDED_FID_TOOL+1; i < MAX_TOOL_NO; i++)
	{
		pos = pAreaInfo->m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pHole =pAreaInfo-> m_FireHoles[i].GetNext(pos);
			if(pHole->pOrigin->npPos == ptFilePos)
			{
				pHole->pOrigin->nLPCError = nNGType;
				return TRUE;
			}
		}
	}
	return FALSE;
}

DAreaInfo* DProject::FindLPCArea(int nAreaIndex)
{
	DAreaInfo* pAreaInfo = NULL;
	POSITION pos;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = m_Areas[i].GetHeadPosition();
		while (pos) 
		{
			pAreaInfo = m_Areas[i].GetNext(pos);
			if(pAreaInfo->m_nSortIndex == nAreaIndex)
				return pAreaInfo;
		}
	}
	return NULL;;
}

int DProject::GetOneBadLPCIndex(FILE* pFile, int& nAreaIndex, int& nSubToolIndex, int&nShotIndex, CPoint& ptFilePos)
{
	TCHAR chBuffer[BUFMAX + 1], *token;
	TCHAR *szNext;
	TCHAR szSeps[] = _T(" \r\n");

	int nNGType;

	while (!feof(pFile))
	{
		if (NULL == fgets(chBuffer, BUFMAX, pFile))
			return FALSE;
	
		if(chBuffer[0] == 'F')
		{
			if (NULL == (token = strtok_s(chBuffer, szSeps, &szNext)))
				return FALSE;
			if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
					return FALSE;
			nAreaIndex =  atoi(token);

			if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				return FALSE;
			if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				return FALSE;
			nSubToolIndex = atoi(token);

			if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				return FALSE;
			if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				return FALSE;
			nShotIndex = atoi(token);

			if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				return FALSE;
			if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				return FALSE;
			nNGType = atoi(token);

			if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				return FALSE;
			if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				return FALSE;
			ptFilePos.x = atoi(token);

			if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				return FALSE;
			if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				return FALSE;
			ptFilePos.y = atoi(token);

			if(nNGType > 0)
				return nNGType;
		}
	};
	return FALSE;
}

void DProject::DrawLPCErrorInfo(CDC *pDC, CRect rc)
{
	CString str;
	pDC->SetTextColor(RGB(255, 255, 255));
	int nYstart = 5;

	pDC->SetBkColor (RGB(90,250,250));
	str.Format(_T(" LPC NG Type 1 "));
	pDC->ExtTextOut ( rc.left, nYstart, ETO_CLIPPED, NULL, str, NULL);
	nYstart += 20;
	pDC->SetBkColor (RGB(100,255,100));
	str.Format(_T(" LPC NG Type 2 "));
	pDC->ExtTextOut ( rc.left, nYstart, ETO_CLIPPED, NULL, str, NULL);
	nYstart += 20;
	pDC->SetBkColor (RGB(160,70,255));
	str.Format(_T(" Current NG View "));
	pDC->ExtTextOut ( rc.left, nYstart, ETO_CLIPPED, NULL, str, NULL);
	nYstart += 20;

}
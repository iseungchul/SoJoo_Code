// DProcessINI.h: interface for the DProcessINI class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DPROCESSINI_H__457DF6D7_5B5E_451F_A959_D3D401AD6154__INCLUDED_)
#define AFX_DPROCESSINI_H__457DF6D7_5B5E_451F_A959_D3D401AD6154__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DProcessINI  
{
public:
	DProcessINI();
	virtual ~DProcessINI();

	SPROCESSLASERSCANNER		m_sProcessLaserScanner;
	SAUTOSETTING				m_sProcessAutoSetting;
	SPROCESSOPTION				m_sProcessOption;
	SPROCESSCALIBRATION			m_sProcessCal;
	SPROCESSSYSTEM				m_sProcessSystem;
	SPROCESSFIDFIND				m_sProcessFidFind;
	SPROCESSSCANNERCAL			m_sProcessScannerCal;
	SPROCESSPOWERMEASURE		m_sProcessPowerMeasure;
};

extern DProcessINI gProcessINI;
extern SLOTINFO		gLotInfo;

#endif // !defined(AFX_DPROCESSINI_H__457DF6D7_5B5E_451F_A959_D3D401AD6154__INCLUDED_)

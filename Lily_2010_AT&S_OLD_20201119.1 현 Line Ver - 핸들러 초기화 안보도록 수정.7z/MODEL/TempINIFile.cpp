// TempINIFile.cpp: implementation of the CTempINIFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "TempINIFile.h"
#include "DTempINI.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CTempINIFile::CTempINIFile()
{

}

CTempINIFile::~CTempINIFile()
{

}

BOOL CTempINIFile::OpenTempINIFile(CString strFilePath, DTempINI &clsTempINI)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;

	if( FALSE == sFile.Open( strFilePath, CFile::modeRead | CFile::typeText ) )
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, strFilePath);
		ErrMessage(strMsg, MB_OK, 0);

		WriteLog(strMsg);
		return bRet;
	}

	CString strGetData;

	CString strMsg;

	while( sFile.ReadString( strGetData ) )
	{
		if( 0 == strGetData.CompareNoCase(_T("// START TIME SECTION")) )
		{
			if( FALSE == ParsingTime( sFile, clsTempINI ) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingTimeSection"));
				ErrMessage(strMsg);

				WriteLog(strMsg);
				break;
			}
		}// END EASYDRILLER TEMP INI FILE
		else if( 0 == strGetData.CompareNoCase(_T("// END EASYDRILLER TEMP INI FILE")) )
		{
			bRet = TRUE;
			break;
		}
	}

	sFile.Close();

	return bRet;
}


BOOL CTempINIFile::ParsingTime(CStdioFile &sFile, DTempINI &clsTempINI)
{
	BOOL bRet = FALSE;
	CString strGetData, strTemp;
	BOOL bOKM = FALSE, bOKS = FALSE;
	BOOL bOKM2 = FALSE, bOKS2 = FALSE;
	int k = 0;
	int i = 0; 
	while( sFile.ReadString( strGetData ) )
	{
		if(bOKM && bOKS)
		{
			i++;
			bOKS = FALSE;
			bOKM = FALSE;
		}
		if(bOKM2 && bOKS2)
		{
			k++;
			bOKS2 = FALSE;
			bOKM2 = FALSE;
		}

		if( ScanSys( strGetData, _T("AUTO PREHEAT END TIME ="), clsTempINI.m_sTempTime.nAutoPreheatEndTime ) )
			continue;

		if( ScanSys( strGetData, _T("FID 1ST SECOND POS X ="), clsTempINI.m_sTempTime.n1stFidSecondPosX ) )
			continue;
		if( ScanSys( strGetData, _T("FID 1ST SECOND POS Y ="), clsTempINI.m_sTempTime.n1stFidSecondPosY ) )
			continue;
		if( ScanSys( strGetData, _T("FID 2ND FIRST POS X ="), clsTempINI.m_sTempTime.n2ndFidFirstPosX ) )
			continue;
		if( ScanSys( strGetData, _T("FID 2ND FIRST POS Y ="), clsTempINI.m_sTempTime.n2ndFidFirstPosY ) )
			continue;
		if( ScanSys( strGetData, _T("FID 2ND SECOND POS X ="), clsTempINI.m_sTempTime.n2ndFidSecondPosX ) )
			continue;
		if( ScanSys( strGetData, _T("FID 2ND SECOND POS Y ="), clsTempINI.m_sTempTime.n2ndFidSecondPosY ) )
			continue;

		strTemp.Format(_T("AUTO POWER END TIME #%d M ="), k);
		if( ScanSys( strGetData, (LPSTR)(LPCTSTR)strTemp, clsTempINI.m_sTempTime.nAutoPowerEndTime[k][0] ) )
		{
			bOKM2 = TRUE;
			continue;
		}

		strTemp.Format(_T("AUTO POWER END TIME #%d S ="), k);
		if( ScanSys( strGetData, (LPSTR)(LPCTSTR)strTemp, clsTempINI.m_sTempTime.nAutoPowerEndTime[k][1] ) )
		{
			bOKM2 = TRUE;
			continue;
		}

		strTemp.Format(_T("AUTO SCAL END TIME #%d M ="), i);
		if( ScanSys( strGetData, (LPSTR)(LPCTSTR)strTemp, clsTempINI.m_sTempTime.nAutoScalEndTime[i][0] ) )
		{
			bOKM = TRUE;
			continue;
		}
		strTemp.Format(_T("AUTO SCAL END TIME #%d S ="), i);
		if( ScanSys( strGetData, (LPSTR)(LPCTSTR)strTemp, clsTempINI.m_sTempTime.nAutoScalEndTime[i][1] ) )
		{
			bOKS = TRUE;
			continue;
		}

		strTemp.Format(_T("AUTO SCAL TEMPER #%d M ="), i);
		if( ScanSys( strGetData, (LPSTR)(LPCTSTR)strTemp, clsTempINI.m_sTempTime.dAutoScalTemperature[i][0] ) )
		{
			bOKM = TRUE;
			continue;
		}
		strTemp.Format(_T("AUTO SCAL TEMPER #%d S ="), i);
		if( ScanSys( strGetData, (LPSTR)(LPCTSTR)strTemp, clsTempINI.m_sTempTime.dAutoScalTemperature[i][1] ) )
		{
			bOKM = TRUE;
			continue;
		}

		strTemp.Format(_T("AUTO SCAL END TEMPER #%d M ="), i);
		if( ScanSys( strGetData, (LPSTR)(LPCTSTR)strTemp, clsTempINI.m_sTempTime.dAutoScalEndTemperature[i][0] ) )
		{
			bOKM = TRUE;
			continue;
		}
		strTemp.Format(_T("AUTO SCAL END TEMPER #%d S ="), i);
		if( ScanSys( strGetData, (LPSTR)(LPCTSTR)strTemp, clsTempINI.m_sTempTime.dAutoScalEndTemperature[i][1] ) )
		{
			bOKM = TRUE;
			continue;
		}
		
		if( 0 == strGetData.CompareNoCase(_T("// END TIME SECTION")) )
		{
			bRet = TRUE;
			break;
		}

	
	}

	if(bRet == FALSE)
		WriteLog(strGetData);

	return bRet;
}

BOOL CTempINIFile::SaveTempINIFile(CString strFilePath, DTempINI clsTempINI)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;
	
	if(FALSE == sFile.Open(strFilePath,CFile::modeCreate|CFile::modeWrite|CFile::typeText) )
	{
		return bRet;
	}
	
	CString strSetData;
	
	strSetData.Format(_T("// START EASYDRILLER TEMP INI FILE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	CTime CurTime = CTime::GetCurrentTime();
	strSetData.Format(_T("Last Update Time : %04d-%02d-%02d %02d:%02d:%2d\n\n"), CurTime.GetYear(), 
					   CurTime.GetMonth(), CurTime.GetDay(), CurTime.GetHour(), CurTime.GetMinute(), 
					   CurTime.GetSecond() );
	sFile.WriteString( strSetData );
	
	SaveTime( sFile, clsTempINI );
	
	strSetData.Format(_T("// END EASYDRILLER TEMP INI FILE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	sFile.Close();
	bRet = TRUE;
	
	return bRet;
}

BOOL CTempINIFile::SaveTime(CStdioFile &sFile, DTempINI clsTempINI)
{
	BOOL bRet = FALSE;
	CString strSetData;
	
	strSetData.Format(_T("// START TIME SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	strSetData.Format(_T("AUTO PREHEAT END TIME = %d\n"), clsTempINI.m_sTempTime.nAutoPreheatEndTime);
	sFile.WriteString( (LPCTSTR)strSetData );

	strSetData.Format(_T("FID 1ST SECOND POS X = %d\n"), clsTempINI.m_sTempTime.n1stFidSecondPosX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("FID 1ST SECOND POS Y = %d\n"), clsTempINI.m_sTempTime.n1stFidSecondPosY);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("FID 2ND FIRST POS X = %d\n"), clsTempINI.m_sTempTime.n2ndFidFirstPosX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("FID 2ND FIRST POS Y = %d\n"), clsTempINI.m_sTempTime.n2ndFidFirstPosY);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("FID 2ND SECOND POS X = %d\n"), clsTempINI.m_sTempTime.n2ndFidSecondPosX);
	sFile.WriteString( (LPCTSTR)strSetData );
	strSetData.Format(_T("FID 2ND SECOND POS Y = %d\n"), clsTempINI.m_sTempTime.n2ndFidSecondPosY);
	sFile.WriteString( (LPCTSTR)strSetData );

	for(int i =0; i<50; i++)
	{
		
		strSetData.Format(_T("AUTO POWER END TIME #%d M = %d\n"), i, clsTempINI.m_sTempTime.nAutoPowerEndTime[i][0]);
		sFile.WriteString( (LPCTSTR)strSetData );
		
		strSetData.Format(_T("AUTO POWER END TIME #%d S = %d\n"), i, clsTempINI.m_sTempTime.nAutoPowerEndTime[i][1]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("AUTO SCAL END TIME #%d M = %d\n"), i, clsTempINI.m_sTempTime.nAutoScalEndTime[i][0]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("AUTO SCAL END TIME #%d S = %d\n"), i, clsTempINI.m_sTempTime.nAutoScalEndTime[i][1]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("AUTO SCAL TEMPER #%d M = %.3f\n"), i, clsTempINI.m_sTempTime.dAutoScalTemperature[i][0]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("AUTO SCAL TEMPER #%d S = %.3f\n"), i, clsTempINI.m_sTempTime.dAutoScalTemperature[i][1]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("AUTO SCAL END TEMPER #%d M = %.3f\n"), i, clsTempINI.m_sTempTime.dAutoScalEndTemperature[i][0]);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("AUTO SCAL END TEMPER #%d S = %.3f\n"), i, clsTempINI.m_sTempTime.dAutoScalEndTemperature[i][1]);
		sFile.WriteString( (LPCTSTR)strSetData );
	}

	strSetData.Format(_T("// END TIME SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	return bRet;
}

void CTempINIFile::WriteLog(CString strLog)
{
	CString strPathName = _T("D:\\ViaHole\\ErrorLog\\");
	CTime EventTime = CTime::GetCurrentTime();
	strPathName += EventTime.Format(_T("INI_%y%m%d"));
	
	CStdioFile cFile;
	if (FALSE == cFile.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;
	
	CString strWrite;
	strWrite.Format(_T("%02d:%02d:%02d | %s\n"),
		EventTime.GetHour(),
		EventTime.GetMinute(),
		EventTime.GetSecond(),
		strLog);
	TRY
	{
		cFile.SeekToEnd();		
		cFile.Write(strWrite, strWrite.GetLength());
		cFile.Close();
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH
}

#include "stdafx.h"
#include "DTemperCompensation.h"
#include "math.h"
#include "..\EasyDriller.h"
#include "..\model\DProcessINI.h"
#include "..\model\DSystemINI.h"
#define UM_WRITE_LOG		WM_USER+222


DTemperCompensation::DTemperCompensation(void)
{
	m_bNoCalReturn  = FALSE;
	InitData();
	m_dAutoRunStartT = 0;
	m_nPowerIndex = -1;
	memset(m_nPower, 0 , sizeof(m_nPower));
	m_nStartPower = 0;
	m_dAutoRunEndT = 0;
	m_dReferenceT = 20;
	m_bRefTSet = FALSE;

	time(&t_FireEndTime);

	FILE* fp = NULL;
	CString strFileName;
	strFileName.Format(_T("D:\\Viahole\\FireEndTime"));
	if (NULL == fopen_s(&fp, strFileName,_T("r")))
	{
		int nData;
		fscanf(fp,_T("%d"), &nData);
		fclose(fp);
		t_FireEndTime = nData;
	}
}

DTemperCompensation::~DTemperCompensation(void)
{
}

time_t	DTemperCompensation::GetFireEndTime()
{
	return t_FireEndTime;
}

void DTemperCompensation::InitData()
{
	memset(m_nRepeatDataX, 0, sizeof(m_nRepeatDataX));
	memset(m_nRepeatDataY, 0, sizeof(m_nRepeatDataY));
	memset(m_dRepeatTemper, 0, sizeof(m_nRepeatDataY));
	
	m_nRepeatIndex = 0;
	m_nRepeatMax = 5;

	m_nGrid = 2;
	memset(m_nOffsetTIndex, 0, sizeof(m_nOffsetTIndex));
	m_nOffsetTMax = 2;
	m_dStartTemper = 20;
	m_dDeltaT = 0.1;
	memset(m_nOffsetX, 0, sizeof(m_nOffsetX));
	memset(m_nOffsetY, 0, sizeof(m_nOffsetY));

	memset(m_dGradient, 0, sizeof(m_dGradient));
	memset(m_dYIntercept, 0, sizeof(m_dYIntercept));

	memset(m_dScannerBlockGradient, 0, sizeof(m_dScannerBlockGradient));
	m_dSCalTemperIndex = 0;
}

void  DTemperCompensation:: SetAutoRunStartTemperature(double dAutoStartT)
{
	m_dAutoRunStartT = dAutoStartT;
}

void  DTemperCompensation:: SetAutoRunLastTemperature(double dAutoEndT)
{
	if(dAutoEndT <= m_dReferenceT)
		m_dAutoRunEndT = m_dReferenceT + fabs(m_dTransT * m_nOffsetTIndex[0]);
	else
		m_dAutoRunEndT = dAutoEndT;

	FILE* fp = NULL;
	CString strFileName;
	strFileName.Format(_T("D:\\Viahole\\FireEndTime"));
	if (NULL == fopen_s(&fp, strFileName,_T("w+")))
	{
		time_t	timeNow;
		time(&timeNow);
		fprintf(fp,_T("%d"), (int)timeNow);
		fclose(fp);
	}
}

double DTemperCompensation:: GetAutoRunLastTemperature()
{
	return m_dAutoRunEndT;
}

void   DTemperCompensation::SetRefTemperature(double dRefT)
{
	m_dReferenceT = dRefT;
	m_bRefTSet = TRUE;
}

BOOL DTemperCompensation::GetIsSetRefT()
{
	return m_bRefTSet;
}

BOOL DTemperCompensation::SetDataInfo(int nGridNo, double dDeltaT, int nRepeatNo, double dTransT)
{
	if(nGridNo != 2 && nGridNo != 3 && nGridNo != 5 && nGridNo != 9)
		return FALSE;

	if(nRepeatNo < 1 || nRepeatNo > MAX_REPEAT_NO)
		return FALSE;

	memset(m_nRepeatDataX, 0, sizeof(m_nRepeatDataX));
	memset(m_nRepeatDataY, 0, sizeof(m_nRepeatDataY));
	m_nRepeatIndex = 0;
	m_nRepeatMax = nRepeatNo;

	m_nGrid = nGridNo;
	
	memset(m_nOffsetTIndex, 0, sizeof(m_nOffsetTIndex));

	m_dDeltaT = dDeltaT;
	m_dTransT = dTransT;
	m_bSavedLowTemp = FALSE;

	m_dSCalTemperIndex = 0;
	return TRUE;
}

BOOL DTemperCompensation::CalLine()
{
	return TRUE;
}

void DTemperCompensation::SetScalTemperature(double dVal)
{
	if(m_dSCalTemperIndex >= MAX_TEMPER_NO * MAX_REPEAT_NO)
		return;

	m_dSCalTemper[m_dSCalTemperIndex] = dVal;
	m_dSCalTemperIndex++;
}

// 0    72  dX, dY index�� ��ġ		//	 [0][8]    [8][8]
//												//
// 8    80									//   [0][0]    [8][0]
BOOL DTemperCompensation::SetOneData(double dTemper, DPOINT* dMeasureOffset) //double* dX, double* dY)
{
	int nDivide = (MAX_GRID_NO - 1) / (m_nGrid - 1);
	int nXIndex = 0, nYIndex = m_nGrid -1;
	for(int nX = 0; nX < MAX_GRID_NO; nX++)
	{
		nYIndex = m_nGrid -1;
		for(int nY = 0; nY < MAX_GRID_NO; nY++)
		{
			if(nX%nDivide == 0 && nY%nDivide == 0)
			{
				m_nRepeatDataX[m_nPowerIndex][m_nRepeatIndex][nXIndex][nYIndex]  = (int)(dMeasureOffset[nX*MAX_GRID_NO + nY].x*1000) ;
				m_nRepeatDataY[m_nPowerIndex][m_nRepeatIndex][nXIndex][nYIndex]  = (int)(dMeasureOffset[nX*MAX_GRID_NO + nY].y*1000) ;
			}
			if(nY%nDivide == 0)
				nYIndex--;
		}
		if(nX%nDivide == 0)
			nXIndex++;
	}
	dTemper = m_dSCalTemper[m_nOffsetTIndex[m_nPowerIndex]*m_nRepeatMax + m_nRepeatIndex];
	m_dRepeatTemper[m_nRepeatIndex] = dTemper;
	m_nRepeatIndex++;

	if(m_nRepeatIndex == m_nRepeatMax * 2)
	{
		m_nRepeatIndex = 0;
		double dMeanGradient;
		for(int nX = 0; nX < m_nGrid; nX++)
		{
			for(int nY = 0; nY < m_nGrid; nY++)
			{
				// ���� X
				dMeanGradient = 0;
				for(int i = 0; i < m_nRepeatMax; i++)
				{
					for(int j = 0; j < m_nRepeatMax; j++)
					{
						dMeanGradient += (m_nRepeatDataX[m_nPowerIndex][j + m_nRepeatMax ][nX][nY] - m_nRepeatDataX[m_nPowerIndex][i][nX][nY]) / (m_dRepeatTemper[j + m_nRepeatMax ] - m_dRepeatTemper[i]);
					}
				}
				dMeanGradient /= (m_nRepeatMax * m_nRepeatMax);
				m_dGradient[m_nPowerIndex][m_nOffsetTIndex[m_nPowerIndex]][0][nX][nY] = dMeanGradient;
				// ���� Y
				dMeanGradient = 0;
				for(int i = 0; i < m_nRepeatMax; i++)
				{
					for(int j = 0; j < m_nRepeatMax; j++)
					{
						dMeanGradient += (m_nRepeatDataY[m_nPowerIndex][j + m_nRepeatMax ][nX][nY] - m_nRepeatDataY[m_nPowerIndex][i][nX][nY]) / (m_dRepeatTemper[j + m_nRepeatMax ] - m_dRepeatTemper[i]);
					}
				}
				dMeanGradient /= (m_nRepeatMax * m_nRepeatMax);
				m_dGradient[m_nPowerIndex][m_nOffsetTIndex[m_nPowerIndex]][1][nX][nY] = dMeanGradient;
			}
		}
		// reset data
		for(int i = 0; i < m_nRepeatMax; i++)
		{
			m_dRepeatTemper[i] = m_dRepeatTemper[m_nRepeatMax + i];
			for(int nX = 0; nX < m_nGrid; nX++)
			{
				for(int nY = 0; nY < m_nGrid; nY++)
				{
					m_nRepeatDataX[m_nPowerIndex][i ][nX][nY] = m_nRepeatDataX[m_nPowerIndex][i + m_nRepeatMax ][nX][nY];
					m_nRepeatDataY[m_nPowerIndex][i ][nX][nY] = m_nRepeatDataY[m_nPowerIndex][i + m_nRepeatMax ][nX][nY];
				}
			}
			m_nRepeatIndex = m_nRepeatMax;
		}
		m_nOffsetTIndex[m_nPowerIndex]++;

	}
	return TRUE;
}

BOOL DTemperCompensation::SetScannerBlockOneData(double dTemper, DPOINT* dMeasureOffset)
{
	return TRUE;
}

/*
BOOL DTemperCompensation::GetCompenPosition(double dCurrTemper, double dSCalTemper, int& nXLsb, int& nYLsb, int nFieldsizeUM, double dTemerMin, double dTemperMax, double dPower)
{
	if(dCurrTemper < dTemerMin || dCurrTemper > dTemperMax)
		return FALSE;

	if(!m_bRefTSet)
		return FALSE;

	double dMatrixStep = 65536 / (m_nGrid - 1);
	int lx, ly, hx, hy;
	double ax, ay, bx, by;
	double dScalX0_0, dScalX1_0, dScalX0_1, dScalX1_1, dScalY0_0, dScalY1_0, dScalY0_1, dScalY1_1;

	int modx = nXLsb%(int)dMatrixStep;
	int mody = nYLsb%(int)dMatrixStep;

	if( modx == 0 )
		lx = hx = (int)(nXLsb/dMatrixStep);
	else
	{
		lx = (int)(nXLsb/dMatrixStep);
		hx = lx + 1;
	}
	if( mody == 0 )
		ly = hy = (int)(nYLsb/dMatrixStep);
	else
	{
		ly = (int)(nYLsb/dMatrixStep);
		hy = ly + 1;
	}
	if(lx >= m_nGrid || hx >= m_nGrid || ly >= m_nGrid || hy >= m_nGrid)
		return FALSE;

	double dTotalDiff = 0;
	double dABSTransPoint;
	double dStartApplyT, dEndApplyT;

	int nPowerIndex = 0;
	double dDiffPowerMin = 999999;
	for(int i = 0; i < m_nPowerIndex; i++)
	{
		if(fabs(dPower - (m_nStartPower + m_nStepPower * i)) < dDiffPowerMin)
		{
			dDiffPowerMin = fabs(dPower - (m_nStartPower + m_nStepPower * i));
			nPowerIndex = i;
		}
	}

	if(dCurrTemper > dSCalTemper)
	{
		for(int i = 0; i < m_nOffsetTIndex[nPowerIndex]; i++)
		{
			dABSTransPoint = m_dAutoRunStartT + m_dTransT * (i + 1);

			dStartApplyT = dSCalTemper;
			if(dSCalTemper < (m_dAutoRunStartT + m_dTransT * i))
			{
				if(i != 0) // start��ġ �ƴϸ�
					dStartApplyT = m_dAutoRunStartT + m_dTransT * i;
			}
			else if(dSCalTemper > dABSTransPoint)
			{
				continue;
			}
			dEndApplyT = dCurrTemper;
			if(dCurrTemper > dABSTransPoint)
			{
				if(i != m_nOffsetTIndex[nPowerIndex] - 1) // start��ġ�̸�
					dEndApplyT = dABSTransPoint;
			}
			else if (dCurrTemper < (m_dAutoRunStartT + m_dTransT * i))
			{
				continue;
			}

			dTotalDiff += (dEndApplyT - dStartApplyT);

			dScalX0_0 = m_dGradient[nPowerIndex][i][0][lx][ly] * (dEndApplyT - dStartApplyT);
			dScalX1_0 = m_dGradient[nPowerIndex][i][0][hx][ly] * (dEndApplyT - dStartApplyT);
			dScalX0_1 = m_dGradient[nPowerIndex][i][0][lx][hy] * (dEndApplyT - dStartApplyT);
			dScalX1_1 = m_dGradient[nPowerIndex][i][0][hx][hy] * (dEndApplyT - dStartApplyT);
			dScalY0_0 = m_dGradient[nPowerIndex][i][1][lx][ly] * (dEndApplyT - dStartApplyT);
			dScalY1_0 = m_dGradient[nPowerIndex][i][1][hx][ly] * (dEndApplyT - dStartApplyT);
			dScalY0_1 = m_dGradient[nPowerIndex][i][1][lx][hy] * (dEndApplyT - dStartApplyT);
			dScalY1_1 = m_dGradient[nPowerIndex][i][1][hx][hy] * (dEndApplyT - dStartApplyT);

			ax = dScalX0_0 + ( (dScalX0_1 - dScalX0_0)*mody/dMatrixStep);
			bx = dScalX1_0 + ( (dScalX1_1 - dScalX1_0)*mody/dMatrixStep);
			ay = dScalY0_0 + ( (dScalY1_0 - dScalY0_0)*modx/dMatrixStep);
			by = dScalY0_1 + ( (dScalY1_1 - dScalY0_1)*modx/dMatrixStep);

			nXLsb = nXLsb - (int)((ax + (bx - ax)*modx/dMatrixStep)  * 65535 / nFieldsizeUM);
			nYLsb = nYLsb - (int)((ay + (by - ay)*mody/dMatrixStep)  * 65535 / nFieldsizeUM);

			if(nXLsb < 0 || nXLsb > 65535 || nYLsb < 0 || nYLsb > 65535)
				return FALSE;
		}
		if(fabs((dCurrTemper - dSCalTemper) - dTotalDiff ) > 0.05)
			return FALSE;
	}
	else
	{
		for(int i = m_nOffsetTIndex[nPowerIndex] - 1; i >= 0; i--)
		{
			dABSTransPoint = m_dAutoRunStartT + m_dTransT * (i + 1);

			dStartApplyT = dSCalTemper;
			if(dSCalTemper > dABSTransPoint)
			{
				if(i !=  m_nOffsetTIndex[nPowerIndex] - 1) // start��ġ �ƴϸ�
					dStartApplyT = dABSTransPoint;
			}
			else if(dSCalTemper < dABSTransPoint)
			{
				continue;
			}
			dEndApplyT = dCurrTemper;
			if(dCurrTemper < (m_dAutoRunStartT + m_dTransT * i))
			{
				if(i != 0) // start��ġ�̸�
					dEndApplyT = (m_dAutoRunStartT + m_dTransT * i);
			}
			else if (dCurrTemper > dABSTransPoint )
			{
				continue;
			}

			dTotalDiff += (dEndApplyT - dStartApplyT);

			dScalX0_0 = m_dGradient[nPowerIndex][i][0][lx][ly] * (dEndApplyT - dStartApplyT);
			dScalX1_0 = m_dGradient[nPowerIndex][i][0][hx][ly] * (dEndApplyT - dStartApplyT);
			dScalX0_1 = m_dGradient[nPowerIndex][i][0][lx][hy] * (dEndApplyT - dStartApplyT);
			dScalX1_1 = m_dGradient[nPowerIndex][i][0][hx][hy] * (dEndApplyT - dStartApplyT);
			dScalY0_0 = m_dGradient[nPowerIndex][i][1][lx][ly] * (dEndApplyT - dStartApplyT);
			dScalY1_0 = m_dGradient[nPowerIndex][i][1][hx][ly] * (dEndApplyT - dStartApplyT);
			dScalY0_1 = m_dGradient[nPowerIndex][i][1][lx][hy] * (dEndApplyT - dStartApplyT);
			dScalY1_1 = m_dGradient[nPowerIndex][i][1][hx][hy] * (dEndApplyT - dStartApplyT);

			ax = dScalX0_0 + ( (dScalX0_1 - dScalX0_0)*mody/dMatrixStep);
			bx = dScalX1_0 + ( (dScalX1_1 - dScalX1_0)*mody/dMatrixStep);
			ay = dScalY0_0 + ( (dScalY1_0 - dScalY0_0)*modx/dMatrixStep);
			by = dScalY0_1 + ( (dScalY1_1 - dScalY0_1)*modx/dMatrixStep);

			nXLsb = nXLsb - (int)((ax + (bx - ax)*modx/dMatrixStep)  * 65535 / nFieldsizeUM);
			nYLsb = nYLsb - (int)((ay + (by - ay)*mody/dMatrixStep)  * 65535 / nFieldsizeUM);

			if(nXLsb < 0 || nXLsb > 65535 || nYLsb < 0 || nYLsb > 65535)
				return FALSE;
		}
		if(fabs((dCurrTemper - dSCalTemper) - dTotalDiff ) > 0.05)
			return FALSE;
	}
	return TRUE;
}
*/

void DTemperCompensation::GetOffsetForDeltaT(int nFieldsizeUM, int modx, int mody, int lx, int ly, int hx, int hy, int nPowerIndex, double dDeltaT, double& dXOffset, double& dYOffset)
{
	double ax, ay, bx, by;
	double dScalX0_0, dScalX1_0, dScalX0_1, dScalX1_1, dScalY0_0, dScalY1_0, dScalY0_1, dScalY1_1;
	double dMatrixStep = 65536 / (m_nGrid - 1);

	dScalX0_0 = dScalX1_0 = dScalX0_1 = dScalX1_1 = dScalY0_0 = dScalY1_0 = dScalY0_1 = dScalY1_1 = 0;

	dXOffset = dYOffset = 0;
	for(int i = 0; i < m_nOffsetTIndex[nPowerIndex]; i++)
	{
		if(dDeltaT <= 0)
			return;

		if(dDeltaT <= m_dTransT || i ==m_nOffsetTIndex[nPowerIndex] - 1 ) // ������ �����̰ų� delta T �� ������ �κ�
		{
			dScalX0_0 += m_dGradient[nPowerIndex][i][0][lx][ly] * dDeltaT;
			dScalX1_0 += m_dGradient[nPowerIndex][i][0][hx][ly] * dDeltaT;
			dScalX0_1 += m_dGradient[nPowerIndex][i][0][lx][hy] * dDeltaT;
			dScalX1_1 += m_dGradient[nPowerIndex][i][0][hx][hy] * dDeltaT;
			dScalY0_0 += m_dGradient[nPowerIndex][i][1][lx][ly] * dDeltaT;
			dScalY1_0 += m_dGradient[nPowerIndex][i][1][hx][ly] * dDeltaT;
			dScalY0_1 += m_dGradient[nPowerIndex][i][1][lx][hy] * dDeltaT;
			dScalY1_1 += m_dGradient[nPowerIndex][i][1][hx][hy] * dDeltaT;

			ax = dScalX0_0 + ( (dScalX0_1 - dScalX0_0)*mody/dMatrixStep);
			bx = dScalX1_0 + ( (dScalX1_1 - dScalX1_0)*mody/dMatrixStep);
			ay = dScalY0_0 + ( (dScalY1_0 - dScalY0_0)*modx/dMatrixStep);
			by = dScalY0_1 + ( (dScalY1_1 - dScalY0_1)*modx/dMatrixStep);

			dXOffset = dXOffset - (int)((ax + (bx - ax)*modx/dMatrixStep)  * 65535 / nFieldsizeUM);
			dYOffset = dYOffset - (int)((ay + (by - ay)*mody/dMatrixStep)  * 65535 / nFieldsizeUM);
			return;
		}
		else
		{
			dScalX0_0 += m_dGradient[nPowerIndex][i][0][lx][ly] * m_dTransT;
			dScalX1_0 += m_dGradient[nPowerIndex][i][0][hx][ly] * m_dTransT;
			dScalX0_1 += m_dGradient[nPowerIndex][i][0][lx][hy] * m_dTransT;
			dScalX1_1 += m_dGradient[nPowerIndex][i][0][hx][hy] * m_dTransT;
			dScalY0_0 += m_dGradient[nPowerIndex][i][1][lx][ly] * m_dTransT;
			dScalY1_0 += m_dGradient[nPowerIndex][i][1][hx][ly] * m_dTransT;
			dScalY0_1 += m_dGradient[nPowerIndex][i][1][lx][hy] * m_dTransT;
			dScalY1_1 += m_dGradient[nPowerIndex][i][1][hx][hy] * m_dTransT;
		}
		dDeltaT -= m_dTransT;
	}
}
BOOL DTemperCompensation::GetCompenPosition(double dCurrTemper, double dSCalTemper, double dSCalEndTemper, int& nXLsb, int& nYLsb, int nFieldsizeUM, double dTemerMin, double dTemperMax, double dPower)
{
	if(m_bNoCalReturn)
	{
		return TRUE;
	}
	if(gSystemINI.m_sHardWare.bTemperCompConnect == 0)
	{
		return TRUE;
	}
	CString strFile, strLog;
	strFile.Format(_T("SCal_Time_Log"));

	if (dCurrTemper < dTemerMin || dCurrTemper > dTemperMax)
		return FALSE;
	
	

	if(!m_bRefTSet) // || dCurrTemper <= m_dAutoRunStartT - 0.2) // 0.0�̻� ������ ������
	{
		strLog.Format(_T("bRefTSet Error"), dCurrTemper, m_dAutoRunStartT );								
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		return FALSE;
	}
//	if((dCurrTemper > m_dAutoRunStartT - 0.2) && (dCurrTemper < m_dAutoRunStartT)) // ����ϸ� ���� ���� ���¿��� �˰����� ���� ���Ÿ� ���� ���� ������ �Ѵ�.
//		dCurrTemper = m_dAutoRunStartT;
	if(dCurrTemper < m_dAutoRunStartT) // ���� ���� �� �µ��� �������� ��찡 �־
	{
		strLog.Format(_T("dCurrTemper < m_dAutoRunStartT warning : %.3f, %.3f"), dCurrTemper, m_dAutoRunStartT );								
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		m_dAutoRunStartT = dCurrTemper;
	}

	if(m_dAutoRunEndT + 0.05 < m_dReferenceT)
	{
		m_bRefTSet = FALSE;
		strLog.Format(_T("m_dAutoRunEndT + 0.05 < m_dReferenceT Error : %.3f, %.3f"), m_dAutoRunEndT, m_dReferenceT );								
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		return FALSE;
	}
	if(m_dAutoRunEndT < m_dReferenceT)
		m_dAutoRunEndT = m_dReferenceT;

	if((dSCalTemper > dSCalEndTemper) || (dSCalEndTemper <m_dReferenceT))
	{
		m_bRefTSet = FALSE;
		strLog.Format(_T("dSCalTemper > dSCalEndTemper || dSCalEndTemper <m_dReferenceT Error : %.3f, %.3f, %.3f"), dSCalTemper, dSCalEndTemper, m_dReferenceT );								
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		return FALSE;
	}

	double dMatrixStep = 65536 / (m_nGrid - 1);
	int lx, ly, hx, hy;

	int modx = nXLsb%(int)dMatrixStep;
	int mody = nYLsb%(int)dMatrixStep;

	if( modx == 0 )
		lx = hx = (int)(nXLsb/dMatrixStep);
	else
	{
		lx = (int)(nXLsb/dMatrixStep);
		hx = lx + 1;
	}
	if( mody == 0 )
		ly = hy = (int)(nYLsb/dMatrixStep);
	else
	{
		ly = (int)(nYLsb/dMatrixStep);
		hy = ly + 1;
	}
	if(lx >= m_nGrid || hx >= m_nGrid || ly >= m_nGrid || hy >= m_nGrid)
		return FALSE;

	double dTotalDiff = 0;

	int nPowerIndex = 0;
	double dDiffPowerMin = 999999;
	for(int i = 0; i < m_nPowerIndex; i++)
	{
		if(fabs(dPower - (m_nStartPower + m_nStepPower * i)) < dDiffPowerMin)
		{
			dDiffPowerMin = fabs(dPower - (m_nStartPower + m_nStepPower * i));
			nPowerIndex = i;
		}
	}

	double dTotalOffsetX = 0, dTotalOffsetY = 0;
	if(m_dAutoRunStartT <= m_dReferenceT)
	{
		double dX1, dY1, dX2, dY2;
		GetOffsetForDeltaT(nFieldsizeUM, modx, mody, lx, ly, hx, hy, nPowerIndex, m_nOffsetTIndex[nPowerIndex] * m_dTransT, dX1, dY1); // RT����
		GetOffsetForDeltaT(nFieldsizeUM, modx, mody, lx, ly, hx, hy, nPowerIndex, m_nOffsetTIndex[nPowerIndex] * m_dTransT +(m_dReferenceT - m_dAutoRunStartT), dX2, dY2); // AST������ ��
		dTotalOffsetX = dX1 - dX2;
		dTotalOffsetY = dY1 - dY2;
		GetOffsetForDeltaT(nFieldsizeUM, modx, mody, lx, ly, hx, hy, nPowerIndex, dCurrTemper - m_dAutoRunStartT, dX1, dY1);
		dTotalOffsetX += dX1;
		dTotalOffsetY += dY1;

		//AGC
		GetOffsetForDeltaT(nFieldsizeUM, modx, mody, lx, ly, hx, hy, nPowerIndex, dSCalEndTemper - m_dReferenceT, dX1, dY1); // AGC end T ���� Ref
		GetOffsetForDeltaT(nFieldsizeUM, modx, mody, lx, ly, hx, hy, nPowerIndex, dSCalEndTemper -  dSCalTemper, dX2, dY2); // AGC T ���� AGC end T ����
		dTotalOffsetX += (dX2 - dX1);
		dTotalOffsetY += (dY2 - dY1);
	}
	else
	{
		if(dCurrTemper < m_dAutoRunEndT)
		{
			double dX1, dY1, dX2, dY2;
			GetOffsetForDeltaT(nFieldsizeUM, modx, mody, lx, ly, hx, hy, nPowerIndex, m_dAutoRunEndT - m_dReferenceT, dX1, dY1); //  end T
			GetOffsetForDeltaT(nFieldsizeUM, modx, mody, lx, ly, hx, hy, nPowerIndex, m_dAutoRunEndT - m_dAutoRunStartT, dX2, dY2); // end T ~ AST
			dTotalOffsetX = dX1 - dX2;
			dTotalOffsetY = dY1 - dY2;
			GetOffsetForDeltaT(nFieldsizeUM, modx, mody, lx, ly, hx, hy, nPowerIndex, dCurrTemper - m_dAutoRunStartT, dX1, dY1);
			dTotalOffsetX += dX1;
			dTotalOffsetY += dY1;

			// AGC
			GetOffsetForDeltaT(nFieldsizeUM, modx, mody, lx, ly, hx, hy, nPowerIndex, dSCalEndTemper - m_dReferenceT, dX1, dY1); // AGC end T ���� Ref
			GetOffsetForDeltaT(nFieldsizeUM, modx, mody, lx, ly, hx, hy, nPowerIndex, dSCalEndTemper -  dSCalTemper, dX2, dY2); // AGC T ���� AGC end T ����
			dTotalOffsetX += (dX2 - dX1);
			dTotalOffsetY += (dY2 - dY1);
		}
		else
		{
			double dX1, dY1, dX2, dY2;
			GetOffsetForDeltaT(nFieldsizeUM, modx, mody, lx, ly, hx, hy, nPowerIndex, dCurrTemper - m_dReferenceT, dX1, dY1); // CT ~ ref
			dTotalOffsetX = dX1;
			dTotalOffsetY = dY1;

			// AGC
			GetOffsetForDeltaT(nFieldsizeUM, modx, mody, lx, ly, hx, hy, nPowerIndex, dSCalEndTemper - m_dReferenceT, dX1, dY1); // AGC end T ���� Ref
			GetOffsetForDeltaT(nFieldsizeUM, modx, mody, lx, ly, hx, hy, nPowerIndex, dSCalEndTemper -  dSCalTemper, dX2, dY2); // AGC T ���� AGC end T ����
			dTotalOffsetX += (dX2 - dX1);
			dTotalOffsetY += (dY2 - dY1);
		}
	}


	nXLsb = nXLsb + (int)(dTotalOffsetX);
	nYLsb = nYLsb + (int)(dTotalOffsetY);

	if(nXLsb > 65535 || nXLsb < 0 || nYLsb > 65535 || nYLsb < 0)
	{
		strLog.Format(_T("LSB over Error %d, %d, %.0f, %0.f"), nXLsb, nYLsb, dTotalOffsetX, dTotalOffsetY );								
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		return FALSE;
	}

	return TRUE;
}

BOOL DTemperCompensation::LoadTemperCompenFile(CString strFile)
{
	TCHAR szSeps[] = _T("\t\r\n");
	TCHAR szBuf[256], *token = NULL;
	TCHAR *szNext;
	FILE* fp = NULL;
	
	if (NULL == fopen_s(&fp, strFile, "rb"))
	{
		if (NULL == fgets(szBuf, 255, fp))
		{
			InitData();
			fclose(fp);
			return FALSE;
		}

		if (NULL == (token = strtok_s(szBuf, szSeps, &szNext))) // m_nGrid
		{
			InitData();
			fclose(fp);
			return FALSE;
		}
		int nTemp = atoi(token);
		if (nTemp < 2 || nTemp > MAX_GRID_NO)
		{
			InitData();
			fclose(fp);
			return FALSE;
		}
		m_nGrid = nTemp;

/*		if (NULL == (token = strtok_s(NULL, szSeps, &szNext))) // m_nOffsetTMax
		{
			InitData();
			fclose(fp);
			return FALSE;
		}
		nTemp = atoi(token);
		if (nTemp < 2 || nTemp > MAX_TEMPER_NO)
		{
			InitData();
			fclose(fp);
			return FALSE;
		}
		m_nOffsetTMax = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext))) // m_dStartTemper
		{
			InitData();
			fclose(fp);
			return FALSE;
		}
		double dTemp = atof(token) + 0.00001;
		m_dStartTemper = dTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext))) // m_dDeltaT
		{
			InitData();
			fclose(fp);
			return FALSE;
		}
		dTemp = atof(token) + 0.00001;
		m_dDeltaT = dTemp;
*/
		if (NULL == (token = strtok_s(NULL, szSeps, &szNext))) // m_dTransT
		{
			InitData();
			fclose(fp);
			return FALSE;
		}
		double dTemp = atof(token) + 0.00001;
		m_dTransT = dTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext))) // Power Start
		{
			InitData();
			fclose(fp);
			return FALSE;
		}
		m_nStartPower = atoi(token);

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext))) // Power Count
		{
			InitData();
			fclose(fp);
			return FALSE;
		}
		m_nPowerIndex = atoi(token);
		
		if (NULL == (token = strtok_s(NULL, szSeps, &szNext))) // m_nStepPower
		{
			InitData();
			fclose(fp);
			return FALSE;
		}
		m_nStepPower = atoi(token);

		for(int nPower = 0; nPower <= m_nPowerIndex; nPower++)
		{
			if (NULL == fgets(szBuf, 255, fp))
			{
				InitData();
				fclose(fp);
				return FALSE;
			}

			if (NULL == (token = strtok_s(szBuf, szSeps, &szNext))) // m_nOffsetTIndex
			{
				InitData();
				fclose(fp);
				return FALSE;
			}
			m_nOffsetTIndex[nPower] = atoi(token);
			for(int nTransPoint = 0; nTransPoint < m_nOffsetTIndex[nPower]; nTransPoint++)
			{
				for(int nXY = 0; nXY < 2; nXY++)
				{
					for (int i = 0; i < m_nGrid; i++)
					{
						for (int j = 0; j < m_nGrid; j++)
						{
							if (NULL == fgets(szBuf, 255, fp))
							{
								InitData();
								fclose(fp);
								return FALSE;
							}

							if (NULL == (token = strtok_s(szBuf, szSeps, &szNext))) // [ %d ][ %d ]
							{
								InitData();
								fclose(fp);
								return FALSE;
							}

							if (NULL == (token = strtok_s(NULL, szSeps, &szNext))) // m_dGradient
							{
								InitData();
								fclose(fp);
								return FALSE;
							}
							m_dGradient[nPower][nTransPoint][nXY][i][j] = atof(token);
						}
					}
				}
			}
		}
	}
	else
	{
		InitData();
		return FALSE;
	}
	fclose(fp);
	return TRUE;
}

BOOL DTemperCompensation::SaveTemperCompenFile(CString strFile)
{
	FILE* fp = NULL;
	
	if (NULL == fopen_s(&fp, strFile,_T("w")))
	{
		fprintf(fp,_T("%d\t%.3f\t%d\t%d\t%d\n"), m_nGrid, m_dTransT, m_nStartPower,m_nPowerIndex, m_nStepPower);

		for(int nPower = 0; nPower <= m_nPowerIndex ; nPower++)
		{
			fprintf(fp,_T("%d\n"), m_nOffsetTIndex[nPower]);
			for(int nTransPoint = 0; nTransPoint < m_nOffsetTIndex[nPower]; nTransPoint++)
			{
				for(int nXY = 0; nXY < 2; nXY++)
				{
					for (int i = 0; i < m_nGrid; i++)
					{
						for (int j = 0; j < m_nGrid; j++)
						{
							fprintf(fp,_T("[ %d ][ %d ][ %d ][ %d ][ %d ]\t%f\n"), m_nPower[nPower], nTransPoint, nXY, i, j, m_dGradient[m_nPowerIndex][nTransPoint][nXY][i][j]);
						}
					}
				}
			}
		}
		fclose(fp);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
	return TRUE;
}

void DTemperCompensation::SetCurrentPower(int nIndex, int nPower, int nStepPower)
{
	if(nIndex == 0)
		m_nStartPower = nPower;

	m_nPowerIndex = nIndex;
	m_nPower[nIndex] = nPower;

	m_nStepPower = nStepPower;
	m_nRepeatIndex = 0;
	m_nOffsetTIndex[nIndex] = 0;
}

int DTemperCompensation::GetTableNo()
{
	return m_nPowerIndex + 1;
}
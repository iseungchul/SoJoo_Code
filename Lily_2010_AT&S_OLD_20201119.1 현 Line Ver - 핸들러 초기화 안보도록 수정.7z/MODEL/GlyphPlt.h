// GlyphPlt.h: interface for the GlyphPlt class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GLYPHPLT_H__F69F456F_233E_4EF8_8C1F_27CF07E5101A__INCLUDED_)
#define AFX_GLYPHPLT_H__F69F456F_233E_4EF8_8C1F_27CF07E5101A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Glyph.h"



class GlyphPlt : public Glyph  
{
public:
	virtual void Move(int nX, int nY);
	virtual void Rotate(double dDeg);
	virtual void Flip(BOOL bX);
	virtual BOOL IsSelect(CPoint point, int nTolerence, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
	virtual BOOL IsSelect(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
	virtual void Draw(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList** pToolCodes, int nMode);
	DECLARE_SERIAL( GlyphPlt );

	GlyphPlt();
	virtual ~GlyphPlt();

};

#endif // !defined(AFX_GLYPHPLT_H__F69F456F_233E_4EF8_8C1F_27CF07E5101A__INCLUDED_)

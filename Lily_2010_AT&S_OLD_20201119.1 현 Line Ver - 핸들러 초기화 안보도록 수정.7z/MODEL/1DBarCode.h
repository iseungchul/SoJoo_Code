// 1DBarCode.h: interface for the C1DBarCode class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_1DBARCODE_H__4353B9C6_634A_4E74_B271_52162E7FF58E__INCLUDED_)
#define AFX_1DBARCODE_H__4353B9C6_634A_4E74_B271_52162E7FF58E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//#include "..\model\GlyphBarcode1D.h"
//#include "TECBarCode.h"
#include "1DAdd\tbarCode.h"
#include "vicdefs.h"


struct BLINE {
	CPoint		npStartPos;
	CPoint		npEndPos;
};
typedef BLINE *	LPBLINE;
typedef CTypedPtrList <CPtrList, LPBLINE>	BDataList;

//##ModelId=3E410B230196
class C1DBarCode  
{
public:
	int Resiz_Imgbuf(imgdes *image, int width, int length, int bppixel);
	BOOL MakePLTDotFromBmp_1D(CString strImagePath, int nCol, int nRow);
   BOOL MakePLTDotFromBmp_2D(CString strImagePath, int nCol, int nRow);
    BOOL MakePLTDotFromBmp_2D_New(CString strImagePath, int nCol, int nRow);
	bool MakeBarcode_LineMarking_1D();
	bool MakeBarcode_LineMarking_2D(bool bOldVer);
	bool MakeBarcode_LineMarking_2D_New(bool bOldVer);
	BOOL GetBarcodeLineMarkingData(int nRefMode, int umFieldSize, BOOL bFlipX, BOOL bFilpY, int nRotate);	
	void RemoveResultData();	
	BOOL GetNextPoint(BOOL bDot, int &nX, int &nY, int &nX2, int &nY2);
	int GetDataCount(BOOL bDot);
	void ChangeAxis(BOOL bFilpX, BOOL bFilpY, int nRotate);
	void RepositionData(int nMode);

	C1DBarCode();
	//##ModelId=3E410B2301C6
	virtual ~C1DBarCode();




	int m_nLeft;	
	int m_nRight;	
	int m_nBottom;	
	int m_nTop;	
	
	BDataList m_LineData;	
	int m_nUmFieldSize;
	
	POSITION m_pos;	



	////
protected:

};

#endif // !defined(AFX_1DBARCODE_H__4353B9C6_634A_4E74_B271_52162E7FF58E__INCLUDED_)

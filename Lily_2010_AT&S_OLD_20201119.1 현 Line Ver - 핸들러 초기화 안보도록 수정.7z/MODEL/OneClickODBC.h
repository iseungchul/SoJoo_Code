// OneClickOdbc.h: interface for the COneClickOdbc class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OneClickOdbc_H__F88ADDD4_19AF_40AA_9A54_3789C27A18A3__INCLUDED_)
#define AFX_OneClickOdbc_H__F88ADDD4_19AF_40AA_9A54_3789C27A18A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>
#include <stdio.h>
#include <sqlext.h>
#include <conio.h>


class COneClickOdbc  
{
public:
	CString m_strWorkingDir;
	SQLHSTMT m_hStmt;
	SQLHDBC m_hDbc;
	SQLHENV m_hEnv;
	BOOL m_bOpen;

	void GetDiagonostics();
	BOOL GetManageNo(char* pLot);
	void DBDisconnect();
	BOOL DBConnect();
	COneClickOdbc();
	virtual ~COneClickOdbc();

	CString	m_strLotID;
	CString m_strGetManage;
	CString	m_strRecipeLayer;
	CString m_strLayUpCode;
	CString m_strMaterialGroup;
	CString m_strMaterialThick;
	CString m_strFiducialSize;
	CString m_strTrimFinalThick;
	CString m_strProductCount;
	CString m_strHoleSize;
	CString m_strMeterialMaker;

	CString m_strCopperThick;
	CString m_strMeterialKind;
	CString m_strCustomerCode;
	CString m_strProcessCode;
	CString m_strBackwardLevel;

	CString m_strPrevProcessCode;
};

#endif // !defined(AFX_OneClickOdbc_H__F88ADDD4_19AF_40AA_9A54_3789C27A18A3__INCLUDED_)

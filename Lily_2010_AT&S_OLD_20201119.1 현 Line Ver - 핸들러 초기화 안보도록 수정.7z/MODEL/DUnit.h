// DUnit.h: interface for the DUnit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DUNIT_H__67DDD6E7_7FC0_4854_A030_7DAB6FD28376__INCLUDED_)
#define AFX_DUNIT_H__67DDD6E7_7FC0_4854_A030_7DAB6FD28376__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ToolCodeList.h"
#include "2DTransform.h"
#include "HOLEDATA.h"
#include "DBlock.h"
struct LINEDATA {
	int			nToolNo;
	int			nRefToolNo;
	CPoint		npStartPos;
	CPoint		npEndPos;
	//	BOOL		bSelect;
	int			nRefNo;
	int			nUnitIndex;
	BOOL		bDivideDone;

	// 110516
	int			nFidIndex[4][2]; // 4�� Fiducial�� primary, secondary index
	BOOL		bSelect;
	BOOL		nLPCError;
	int			nFidBlock;
};
typedef LINEDATA*	LPLINEDATA;
typedef CTypedPtrList <CPtrList, LPLINEDATA>	LineDataList;
/*
struct HOLEDATA {
	int			nToolNo;
	CPoint		npPos;
	//	BOOL		bSelect;
	int			nRefNo;
};
*/
//typedef HOLEDATA*	LPHOLEDATA;
// typedef CTypedPtrList <CPtrList, LPHOLEDATA>	HoleDataList;
typedef CTypedPtrList <CPtrList, int*>	SubFidIndexList;
typedef CTypedPtrList <CPtrList, LPHOLEDATA> PATTERN_HOLE_LIST;
typedef CTypedPtrList <CPtrList, LPLINEDATA> PATTERN_LINE_LIST;
#define			USER_SELECT_PATTERN

class DOriginLineSort;
class GlyphExcellon;
class DUnit  
{
public:

	void ReCalRect(BlockList* pBlocks);
	BOOL IsAnyData();
	void DelInRect(CPoint point1, CPoint point2, BOOL bReverse);
	void Merge(DUnit* pUnit);
	void Copy(DUnit *pUnit, int nOffsetX, int nOffsetY);
	void Move(int nX, int nY);
	BOOL m_bSelect;
	void SetSelect();
	void Copy(DUnit* pUnit);
	BOOL IsLineData(int nTool);
	BOOL IsDotData(int nTool);
	void ReMoveAllHoleData();
	void ReMoveAllLineData();
	void Rotate(double dDeg, int& nMinX, int& nMaxX, int& nMinY, int& nMaxY);
	void Flip(BOOL bX, int nMinX, int nMaxX, int nMinY, int nMaxY);
	BOOL IsSelect(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
	BOOL IsSelect(CPoint point, int nTolerence, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
	BOOL LoadFile10000(CArchiveMark &ar, int nVersion);
	BOOL SaveFile10000(CArchiveMark &ar, int nVersion);
	BOOL LoadFileRect10000(CArchiveMark &ar, int nVersion);
	BOOL SaveFileRect10000(CArchiveMark &ar, int nVersion);
	DUnit();
	virtual ~DUnit();

	SubFidIndexList m_SubFidIndexData;
	int	m_nMinX;
	int	m_nMinY;
	int	m_nMaxX;
	int	m_nMaxY;
	LineDataList	m_LineData;
	HoleDataList	m_HoleData;
	HoleDataList	m_HoleDataTemp;
	BOOL m_bTransOK;
	C2DTransform m_1stTrans;
	C2DTransform m_2ndTrans;

	BOOL SelectData(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);//, BOOL bSelectionPlus);
	void UnSelectData();

	void SetFiducial(int nIndex, BOOL bSubFid);
	void ResetOneFiducial(int nIndex, BOOL bSubFid);
	void ResetAllFiducial(BOOL bSubFid);
	BOOL IsUseFidInArea(int nIndex, BOOL bSubFid);
	

	BOOL IsAnySelectedData(CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
	// 4 head
	void ChangeBlockWithPosition(int* nChangeBlock);
	int CalMappingIndex(int& nYCount);
	BOOL Make1mmGridDataMap(PATTERN_HOLE_LIST* pPatternHoleList, int nTool);
	int SetMapping(PATTERN_HOLE_LIST* pPatternHoleLis, int& nYCount);

	// make pattern
	void SetBlockInfoToToolInfo(CToolCodeList** pToolCodes);
	void RemoveAllMemory();
	void BlockFirstPositionToZero(CPoint ptOffset, int nBlockName);

	BOOL FindPattern(CPoint pt1, CPoint pt2, GlyphExcellon* pGlyphExcellon);

	void MovePattern(DUnit *pUnit);
	void InitIsPatternFlag();
	LPHOLEDATA GetRepeatHoleData(PATTERN_HOLE_LIST* pPatternHoleList, int nXIndex, int nYIndex, LPHOLEDATA pHoleData, int nTotalPattLengX, int nTotalPattLengY, int nTool);
	
	void GetOriginIndex(int* nPatternDist, int nPatternCnt, int nPatternStartUm, int& nStartI, int& nEndI);
	BOOL ApplyToOrigin(PATTERN_HOLE_LIST* pPatternHoleList, PATTERN_LINE_LIST* pPatternLineList, int nTool,
									int* nPatternDistX, int nPatternCntX, int nPatternStartUmX,
									int* nPatternDistY, int nPatternCntY, int nPatternStartUmY, int nDataType);
	void Make1mmGridDataMap(PATTERN_HOLE_LIST* pPatternHoleList, PATTERN_LINE_LIST* pPatternLineList, int nTool, int nDataType);
	
	int DivideDataForXYDirect(PATTERN_HOLE_LIST* pPatternXHoleList, 
													PATTERN_LINE_LIST* pPatternXLineList, 
													PATTERN_HOLE_LIST* pPatternYHoleList, 
													PATTERN_LINE_LIST* pPatternYLineList, int nTool);
	BOOL GetDistanceCandidate(PATTERN_HOLE_LIST* pPatternHoleList, PATTERN_LINE_LIST* pPatternLineList, int nTool, BOOL bXDirect, int nDataType,
															int* nPatternDistance, int& nCntCandidateNo, int* nPatternCnt, int* nPatternStartUm);
	void GetMatchHoleCountAndDist(CPoint& ptFResultPoint, int* pnRawDataUm, int* nHolespos, int n1stStart, int n2ndStart);
	int GetPatternDistance(int*nHolespos, int* nPatternStart, int nCount, int* nResultPatternDist);
#ifdef			USER_SELECT_PATTERN
	CPoint m_nPatternStartP;
	CPoint m_nPatternEndP;
	int GetUserPatternIndex(int*nHolespos, int*nHoleDist, int nHoleNo, int& nStartIndex, int& nEndIndex, BOOL bXDirect);
	int GetPatternStartPos(int*nHolespos, int*nHoleDist, int nPatternStart, int nPatternEnd, int nHoleNo, int* nResultPatterndStart, int& nPatternTotalNo);

#else
	int m_nPatternMinSizeX;
	int m_nPatternMinSizeY;
	int GetMinPatternSizeEndI(int*nHoleDist, int nStartIndex, int nHoleNo, BOOL bXDirect);
	int GetPatternStartPos(int*nHolespos, int*nHoleDist, int n1stStart, int n2ndStart, int n2ndEnd, int nPCnt, int* nResultPatterndStart, int& nPatternTotalNo);
#endif
	GlyphExcellon* m_pGlyphExcellon;
};

#endif // !defined(AFX_DUNIT_H__67DDD6E7_7FC0_4854_A030_7DAB6FD28376__INCLUDED_)

// UPC.h: interface for the CUPC class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UPC_H__BFD8B825_8815_4789_B4BE_D2941B0EE356__INCLUDED_)
#define AFX_UPC_H__BFD8B825_8815_4789_B4BE_D2941B0EE356__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Barcode.h"

class CUPC : public CBarcode  
{
public:
	CUPC();
	CUPC(int nSymbology);

	virtual ~CUPC();
	void LoadData(CString csMessage, double dNarrowBar, double dFinalHeight, long nGuardbarHeight, int nStartingXPixel, int nStartingYPixel, double dRatio);
	
	void DrawBitmap();
	void BitmapToClipboard();
	CStringList list;
	CStringList numList;
	
	private:
	long m_nGuardbarHeight;
	long CalculateCheckSumDigit();

	CString RetrieveSystemNumberPattern(int iSystemNumber/* = 0*/, int iNumber);

	CString RetrieveLeftOddParityPattern(int iNumber); //used for encoding UPCE barcode
	CString RetrieveLeftEvenParityPattern(int iNumber);//used for encoding UPCE barcode
	
	CString RetrieveLeftPattern(int iNumber);
	CString RetrieveRightPattern(int iNumber);

	void DrawPattern(CString csPattern);

	void DrawUPCA();
	void DrawUPCE();


};

#endif // !defined(AFX_UPC_H__BFD8B825_8815_4789_B4BE_D2941B0EE356__INCLUDED_)

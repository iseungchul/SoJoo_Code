// ArchiveMark.cpp: implementation of the CArchiveMark class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ArchiveMark.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#include "DPoint.h"
#include <afxwin.h>
#include <stdlib.h>
#include <math.h>

#define SZ_EQUAL	_T("= ")
#define SZ_MARKDRAW	_T("MARK_DRAW")
#define SZ_MARKJUMP	_T("MARK_JUMP")

////////////////////////////////////////////////////////////////////////////
// Archive object input/output

// minimum buffer size
enum { nBufSizeMin = 128 };

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//##ModelId=3EB85B480196
CArchiveMark::CArchiveMark(CStdioFile *pFile, UINT nMode, int nBufSize, LPTSTR lpszBuf) 
{
	ASSERT_VALID(pFile);
	
	// initialize members not dependent on allocated buffer
	m_nMode = nMode;
	m_pFile = pFile;

	// initialize the buffer.  minimum size is 128
	m_lpszBuf = lpszBuf;
	m_bUserBuf = TRUE;
	
	if (nBufSize < nBufSizeMin)
	{
		// force use of private buffer of minimum size
		m_nBufSize = nBufSizeMin;
		m_lpszBuf = NULL;
	}
	else
		m_nBufSize = nBufSize;
	
	if (m_lpszBuf == NULL)
	{
		// no support for direct buffering, allocate new buffer
		m_lpszBuf = new TCHAR[m_nBufSize];
		m_bUserBuf = FALSE;
	}
	
	ASSERT(m_lpszBuf != NULL);
	ASSERT(AfxIsValidAddress(m_lpszBuf, nBufSize, IsStoring()));
}

//##ModelId=403400C903CD
CArchiveMark::~CArchiveMark()
{
	// Close makes m_pFile NULL. If it is not NULL, we must Close the CArchive
	if (m_pFile != NULL && !(m_nMode & bNoFlushOnDelete))
		Close();
	
	Abort();    // abort completely shuts down the archive
}

//##ModelId=403400CA0000
void CArchiveMark::Abort()
{
	ASSERT(m_lpszBuf == NULL || AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	// disconnect from the file
	m_pFile = NULL;
	
	if (!m_bUserBuf)
	{
		delete[] m_lpszBuf;
	}
}

//##ModelId=403400C903DF
void CArchiveMark::Close()
{
	ASSERT_VALID(m_pFile);
	
	m_pFile = NULL;
}

//##ModelId=403400C903DE
void CArchiveMark::Flush()
{
	ASSERT_VALID(m_pFile);
	ASSERT(m_lpszBuf != NULL);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	// write out the current buffer to file
	m_pFile->WriteString(m_lpszBuf);
}

//##ModelId=403400CA0001
void CArchiveMark::WriteString(LPCTSTR lpsz)
{
	ASSERT_VALID(m_pFile);
	ASSERT(AfxIsValidString(lpsz));

	m_pFile->WriteString(lpsz);
}

//##ModelId=403400CA0003
LPTSTR CArchiveMark::ReadString(LPTSTR lpsz, UINT nMax)
{
	ASSERT_VALID(m_pFile);

	// if nMax is negative (such a large number doesn't make sense given today's
	// 2gb address space), then assume it to mean "keep the newline".
	int nStop = (int)nMax < 0 ? -(int)nMax : (int)nMax;
	ASSERT(AfxIsValidAddress(lpsz, nStop*sizeof(TCHAR)));

	return m_pFile->ReadString(lpsz, nStop);
}
//##ModelId=403400CA0011
BOOL CArchiveMark::ReadString(CString& rString)
{
	ASSERT_VALID(m_pFile);

	return m_pFile->ReadString(rString);
}

/////////////////////////////////////////////////////////////////////////////

// insertion operations
//##ModelId=3EB85B480207
CArchiveMark& CArchiveMark::operator<<(BYTE by)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%d"), by);
	Flush();

	return *this;
}

//##ModelId=3EB85B480214
CArchiveMark& CArchiveMark::operator<<(WORD w)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%d"), w);
	Flush();

	return *this;
}

//##ModelId=3EB85B480222
CArchiveMark& CArchiveMark::operator<<(LONG l)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%ld"), l);
	Flush();

	return *this;
}

//##ModelId=3EB85B480224
CArchiveMark& CArchiveMark::operator<<(DWORD dw)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%ld"), dw);
	Flush();
	
	return *this;
}

//##ModelId=3EB85B480232
CArchiveMark& CArchiveMark::operator<<(float f)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%f"), f);
	Flush();
	
	return *this;
}

//##ModelId=3EB85B480234
CArchiveMark& CArchiveMark::operator<<(double d)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%lf"), d);
	Flush();
	
	return *this;
}

//##ModelId=3EB85B480262
CArchiveMark& CArchiveMark::operator<<(LPCTSTR lpsz)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%s"), lpsz);
	Flush();

	return *this;
}


//##ModelId=3EB85B480243
CArchiveMark& CArchiveMark::operator<<(int i)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%d"), i);
	Flush();
	
	return *this;
}

//##ModelId=3F00F4CC031C
CArchiveMark& CArchiveMark::operator<<(__int64 i64)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%I64d"), i64);
	Flush();
	
	return *this;
}

//##ModelId=3EB85B480245
CArchiveMark& CArchiveMark::operator<<(short w)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%hd"), w);
	Flush();

	return *this;
}
//##ModelId=3EB85B480252
CArchiveMark& CArchiveMark::operator<<(TCHAR ch)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%c"), ch);
	Flush();

	return *this;
}

//##ModelId=3EB85B480203
CArchiveMark& CArchiveMark::operator<<(bool b)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%hd"), b);
	Flush();

	return *this;
}

//##ModelId=3EB85B480254
CArchiveMark& CArchiveMark::operator<<(unsigned u)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%u"), u);
	Flush();

	return *this;
}

//##ModelId=3EB85B480272
CArchiveMark& CArchiveMark::operator<<(CDPoint pt)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%lf, %lf"), pt.x, pt.y);
	Flush();

	return *this;
}

//##ModelId=3EB85B480280
CArchiveMark& CArchiveMark::operator<<(CPoint pt)
{
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	_stprintf_s(m_lpszBuf, m_nBufSize, _T("%ld, %ld"), pt.x, pt.y);
	Flush();

	return *this;
}

//##ModelId=3EB85B4802A2
CArchiveMark& CArchiveMark::operator>>(LONG& l)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));

	LPTSTR lpsz = m_pFile->ReadString(m_lpszBuf, m_nBufSize);
	ASSERT(NULL != lpsz);

	lpsz = _tcsstr(m_lpszBuf, SZ_EQUAL) + _tcslen(SZ_EQUAL)*sizeof(TCHAR);
	ASSERT(NULL != lpsz);

	l = _ttol(lpsz);

	return *this;
}

//##ModelId=3EB85B4802AF
CArchiveMark& CArchiveMark::operator>>(float& f)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	LPTSTR lpsz = m_pFile->ReadString(m_lpszBuf, m_nBufSize);
	ASSERT(NULL != lpsz);
	
	lpsz = _tcsstr(m_lpszBuf, SZ_EQUAL) + _tcslen(SZ_EQUAL)*sizeof(TCHAR);
	ASSERT(NULL != lpsz);
	
	f = (float)_tcstod(lpsz, NULL);
	
	return *this;
}
//##ModelId=3EB85B4802B1
CArchiveMark& CArchiveMark::operator>>(double& d)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	LPTSTR lpsz = m_pFile->ReadString(m_lpszBuf, m_nBufSize);
	ASSERT(NULL != lpsz);
	
	lpsz = _tcsstr(m_lpszBuf, SZ_EQUAL) + _tcslen(SZ_EQUAL)*sizeof(TCHAR);
	ASSERT(NULL != lpsz);
	
	d = _tcstod(lpsz, NULL);
	
	return *this;
}

//##ModelId=3EB85B4802BF
CArchiveMark& CArchiveMark::operator>>(int& i)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	LPTSTR lpsz = m_pFile->ReadString(m_lpszBuf, m_nBufSize);
	ASSERT(NULL != lpsz);
	
	lpsz = _tcsstr(m_lpszBuf, SZ_EQUAL) + _tcslen(SZ_EQUAL)*sizeof(TCHAR);
	ASSERT(NULL != lpsz);
	
	i = _ttoi(lpsz);
	
	return *this;
}


//##ModelId=3F00F4CF031C
CArchiveMark& CArchiveMark::operator>>(__int64& i64)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	LPTSTR lpsz = m_pFile->ReadString(m_lpszBuf, m_nBufSize);
	ASSERT(NULL != lpsz);
	
	lpsz = _tcsstr(m_lpszBuf, SZ_EQUAL) + _tcslen(SZ_EQUAL)*sizeof(TCHAR);
	ASSERT(NULL != lpsz);
	
	i64 = _ttoi64(lpsz);

	return *this;
}

//##ModelId=3EB85B4802C1
CArchiveMark& CArchiveMark::operator>>(short& w)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	LPTSTR lpsz = m_pFile->ReadString(m_lpszBuf, m_nBufSize);
	ASSERT(NULL != lpsz);
	
	lpsz = _tcsstr(m_lpszBuf, SZ_EQUAL) + _tcslen(SZ_EQUAL)*sizeof(TCHAR);
	ASSERT(NULL != lpsz);
	
	w = (short)_ttoi(lpsz);
	
	return *this;
}

//##ModelId=3EB85B4802CE
CArchiveMark& CArchiveMark::operator>>(TCHAR& ch)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	LPTSTR lpsz = m_pFile->ReadString(m_lpszBuf, m_nBufSize);
	ASSERT(NULL != lpsz);
	
	lpsz = _tcsstr(m_lpszBuf, SZ_EQUAL) + _tcslen(SZ_EQUAL)*sizeof(TCHAR);
	ASSERT(NULL != lpsz);
	
	ch = lpsz[0];

	return *this;
}
//##ModelId=3EB85B4802D0
CArchiveMark& CArchiveMark::operator>>(unsigned& u)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	LPTSTR lpsz = m_pFile->ReadString(m_lpszBuf, m_nBufSize);
	ASSERT(NULL != lpsz);
	
	lpsz = _tcsstr(m_lpszBuf, SZ_EQUAL) + _tcslen(SZ_EQUAL)*sizeof(TCHAR);
	ASSERT(NULL != lpsz);
	
	u = _ttoi(lpsz);
	
	return *this;
}

//##ModelId=3EB85B480294
CArchiveMark& CArchiveMark::operator>>(WORD& w)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	LPTSTR lpsz = m_pFile->ReadString(m_lpszBuf, m_nBufSize);
	ASSERT(NULL != lpsz);
	
	lpsz = _tcsstr(m_lpszBuf, SZ_EQUAL) + _tcslen(SZ_EQUAL)*sizeof(TCHAR);
	ASSERT(NULL != lpsz);
	
	w = (WORD)_ttoi(lpsz);

	return *this;
}
// extraction operations
//##ModelId=3EB85B480292
CArchiveMark& CArchiveMark::operator>>(BYTE& by)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	LPTSTR lpsz = m_pFile->ReadString(m_lpszBuf, m_nBufSize);
	ASSERT(NULL != lpsz);
	
	lpsz = _tcsstr(m_lpszBuf, SZ_EQUAL) + _tcslen(SZ_EQUAL)*sizeof(TCHAR);
	ASSERT(NULL != lpsz);
	
	by = (BYTE)_ttoi(lpsz);
	
	return *this;
}
//##ModelId=3EB85B4802A0
CArchiveMark& CArchiveMark::operator>>(DWORD& dw)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	LPTSTR lpsz = m_pFile->ReadString(m_lpszBuf, m_nBufSize);
	ASSERT(NULL != lpsz);
	
	lpsz = _tcsstr(m_lpszBuf, SZ_EQUAL) + _tcslen(SZ_EQUAL)*sizeof(TCHAR);
	ASSERT(NULL != lpsz);
	
	dw = (DWORD)_ttoi(lpsz);

	return *this;
}

//##ModelId=3EB85B4802DF
CArchiveMark& CArchiveMark::operator>>(CDPoint& pt)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	LPTSTR lpsz = m_pFile->ReadString(m_lpszBuf, m_nBufSize);
	ASSERT(NULL != lpsz);
	
	lpsz = _tcsstr(m_lpszBuf, SZ_EQUAL) + _tcslen(SZ_EQUAL)*sizeof(TCHAR);
	ASSERT(NULL != lpsz);

	VERIFY(2 == _stscanf_s(lpsz, _T("%lf, %lf"), &pt.x, &pt.y));

	return *this;
}

//##ModelId=3EB85B4802E1
CArchiveMark& CArchiveMark::operator>>(CPoint& pt)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	LPTSTR lpsz = m_pFile->ReadString(m_lpszBuf, m_nBufSize);
	ASSERT(NULL != lpsz);
	
	lpsz = _tcsstr(m_lpszBuf, SZ_EQUAL) + _tcslen(SZ_EQUAL)*sizeof(TCHAR);
	ASSERT(NULL != lpsz);
	
	VERIFY(2 == _stscanf_s(lpsz, _T("%ld, %ld"), &pt.x, &pt.y));

	return *this;
}

//##ModelId=3EB85B4802D2
CArchiveMark& CArchiveMark::operator>>(CString& rString)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	VERIFY(m_pFile->ReadString(rString));

	return *this;
}

//##ModelId=3EB85B480205
CArchiveMark& CArchiveMark::operator>>(bool b)
{
	ASSERT_VALID(m_pFile);
	ASSERT(NULL != m_lpszBuf);
	ASSERT(AfxIsValidAddress(m_lpszBuf, m_nBufSize, IsStoring()));
	
	LPTSTR lpsz = m_pFile->ReadString(m_lpszBuf, m_nBufSize);
	ASSERT(NULL != lpsz);
	
	lpsz = _tcsstr(m_lpszBuf, SZ_EQUAL) + _tcslen(SZ_EQUAL)*sizeof(TCHAR);
	ASSERT(NULL != lpsz);
	
	b = (0 != _ttoi(lpsz));

	return *this;
}



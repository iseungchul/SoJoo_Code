// 2DBarCode.h: interface for the C2DBarCode class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_2DBARCODE_H__853226EC_E432_4925_B85A_FCF99F83684F__INCLUDED_)
#define AFX_2DBARCODE_H__853226EC_E432_4925_B85A_FCF99F83684F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "TECBarCode.h"
#include "1DAdd\tbarcode.h"
#include "vicdefs.h"

enum MarkEnum 
{
	
	//##ModelId=4034008500BD
	MARK_DRAW,
		
	//##ModelId=4034008500BE
	MARK_JUMP,
		
	//##ModelId=4034008500CB
	MARK_POINT,
		
	//##ModelId=4034008500CC
	MARK_IMAGE
};

typedef struct 
{
    BOOL bLeftStart;
	BOOL bRightEnd;
	BOOL bDraw;
} BARCODEINFO;

//##ModelId=3E410B220290
class C2DBarCode  
{
public:
	//##ModelId=3E410B22029F
	int m_nBarMSize;
	BOOL m_bFlipX;
	BOOL m_bFlipY;
	double m_dRotate1;
	double m_dRotate2;
	int m_nUmFieldSize;
	int m_nUmBarcodeSize;

	int m_nXIndex;
	int m_nYIndex;

	int m_nPenStatus;
	int Sindex, Cindex, SrcLen;
	//##ModelId=3E410B2202A0
	int CurrentMode;
	int BarRow, BarCol;
	//##ModelId=3E410B2202A1
	int *BarArray;
	//##ModelId=3E410B2202AF
	int Xindex;
	//##ModelId=3E410B2202B0
	int SwitchMode;
	//##ModelId=3E410B2202B1
	int m_dDotSize;
	//##ModelId=3E410B2202BF
	int MatrixWidth;
	//##ModelId=3E410B2202C0
	int MatrixHeight;
	//##ModelId=3E410B2202C1
	int MatrixData[4096];
	//##ModelId=3E410B2202C2
	char m_strData[500];
	//##ModelId=3E410B2202CE
	char StrXValue[50];
	//##ModelId=3E410B2202CF
	unsigned char SrcStr[100];
	//##ModelId=3E410B2202D0
	unsigned char CodeStr[100];

	/* GF(256) log and antilog tables: */
	//##ModelId=3E410B2202E0
	int gfpwr[255];
	//##ModelId=3E410B2202E1
	int gflog[256];

	/* symbol's symbol character array */
	//##ModelId=3E410B2202E2
	unsigned char sym[255*8];
	//##ModelId=3E410B2202EE
	unsigned char datacode[255*8];
public:
	BOOL GetNextPoint(int& nBarX1, int& nBarY1, int& nBarX2, int& nBarY2);
	//##ModelId=3E410B2202EF
	C2DBarCode();
	//##ModelId=3E410B2202FD
	virtual ~C2DBarCode();

	//##ModelId=3E410B220341
	int NewObject(BOOL bFlipX, BOOL bFlipY, double dRotate1, double dRotate2, int umSize, int umFieldSize, CString strContents, int nMSize);

	//##ModelId=3E410B22035B
	double CalcReal2DObjectSize(double MatrixSize, double OneCellSize, CString Contents);



protected:
	//
	// Functions
	//
	//##ModelId=3E410B22036B
	void GetX12Value(unsigned char ch, unsigned char *value);
	//##ModelId=3E410B22037C
	void module(int row, int col, int chr, int bit);
	//##ModelId=3E410B220399
	void utah(int row, int col, int chr);
	//##ModelId=3E410B2203A9
	void corner1(int chr);
	//##ModelId=3E410B2203B9
	void corner2(int chr);
	//##ModelId=3E410B2203C8
	void corner3(int chr);
	//##ModelId=3E410B2203D8
	void corner4(int chr);
	//##ModelId=3E410B2203DA
	void ecc200(void);
	//##ModelId=3E410B230001
	void MakeECC200(int row, int col);
	//##ModelId=3E410B230010
	void InitLogTables();
	//##ModelId=3E410B23001F
	void GetTextValue(unsigned char ch, int *type, unsigned int *value);
	//##ModelId=3E410B23002E
	void GetC40Value(unsigned char ch, int *type, unsigned int *value);
	//##ModelId=3E410B23003E
	int Make2DBarcode(unsigned char *SrcStr1, int *BarcodeArray);

	int Make2DBarcodeNew(CString &strContents, int *BarcodeArray);
	int resiz_imgbuf(imgdes *image, int width, int length, int bppixel);

	//##ModelId=3E410B23004E
	int X12Encode(void);
	//##ModelId=3E410B230050
	int GFmul(int p1, int p2);
	//##ModelId=3E410B23006D
	int CalcChecks(int size);
	//##ModelId=3E410B23007D
	int CalError(int code);
	//##ModelId=3E410B23007F
	int EDIFACTEncode(void);
	//##ModelId=3E410B23008D
	int GetTextCodewords(unsigned int *Values, unsigned int *Code1, unsigned int *Code2);
	//##ModelId=3E410B23009D
	int GetTextValues(unsigned char DataCh, unsigned int *Value);
	//##ModelId=3E410B2300AD
	int FindMatrixType(void);
	//##ModelId=3E410B2300BB
	int IsNativeEDF(int index);
	//##ModelId=3E410B2300BD
	int IsNativeX12(int index);
	//##ModelId=3E410B2300CC
	int IsNativeText(int index);
	//##ModelId=3E410B2300DA
	int IsNativeC40(int index);
	//##ModelId=3E410B2300DC
	int LookAheadTest(int index);
	//##ModelId=3E410B2300EA
	int TextEncode(void);
	//##ModelId=3E410B2300EC
	int GetC40Values(unsigned char DataCh, unsigned int *Value);
	//##ModelId=3E410B2300FB
	int GetC40Codewords(unsigned int *Values, unsigned int *Code1, unsigned int *Code2);
	//##ModelId=3E410B230109
	int C40Encode(void);
	//##ModelId=3E410B23010B
	int ASCIIEncode(void);
	//##ModelId=3E410B23010D
	unsigned char State253(unsigned char Tcode, int Pos);


};
extern int nrow, ncol, *array;
extern unsigned char datacode[];
extern unsigned char sym[];

#endif // !defined(AFX_2DBARCODE_H__853226EC_E432_4925_B85A_FCF99F83684F__INCLUDED_)

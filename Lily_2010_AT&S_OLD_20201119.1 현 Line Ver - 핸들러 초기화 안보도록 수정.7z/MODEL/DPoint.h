// CDPoint.h: interface for the CDPoint class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _CDPOINT_H_
#define _CDPOINT_H_

//====================================================================
// Structure MDPOINT
//====================================================================
struct DPOINT
{
	double x, y;
};

typedef DPOINT* LPDPOINT;

//////////////////////////////////////////////////////////////////////
// CDPoint Class
//====================================================================
class CDPoint : public DPOINT
{
// Constructors
public:
	CDPoint( void );
	CDPoint( const DPOINT& pt );
	CDPoint( double x, double y );
	CDPoint( const CDPoint& pt );

// Operators
public:
	void operator=( LPPOINT lpPoint );
	void operator=( LPDPOINT lpPoint );
	void operator+=( LPDPOINT lpPoint );
	void operator+=( const CDPoint& pt );
	operator LPDPOINT( void );
	void rotateRadian(CDPoint center,double angle);
	void Set(double refx, double refy);
};

#endif

//////////////////////////////////////////////////////////////////////

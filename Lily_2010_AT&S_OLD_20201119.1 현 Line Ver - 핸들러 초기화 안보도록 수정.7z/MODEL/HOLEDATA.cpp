// HOLEDATA.cpp: implementation of the HOLEDATA class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "HOLEDATA.h"

//HANDLE HOLEDATA::s_hHeap = NULL;
//UINT   HOLEDATA::s_uNumAllocsInHeap = 0;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HOLEDATA::HOLEDATA()
{
	nToolNo = -1;
	npPos.x = npPos.y = 0;
	nRefNo = 0;
	nUnitIndex = -1;
	bSelect = FALSE;
	nLPCError = FALSE;
	bCurrnetLPCError = FALSE;
	
	memset(&nFidIndex, -1, sizeof(nFidIndex));

	nArrayNo = 1; //2015.12.02
}



HoleDataList::HoleDataList()
{
	m_nCount = 0;
	m_nAddCount = 0;
	m_pHeadHoleData = NULL;
	m_pTailHoleData = NULL;
}

HoleDataList::~HoleDataList()
{
	RemoveAll();
}

int HoleDataList::GetCount()
{
	return m_nCount;
}

POSITION HoleDataList::GetHeadPosition()
{
	if(m_nCount == 0)
		return NULL;
	return ((POSITION)m_pHeadHoleData);
}

LPHOLEDATA HoleDataList::GetNext(POSITION &pos)
{
	if(m_nCount == 0)
		return NULL;

	LPHOLEDATA pData = (LPHOLEDATA)pos;
	pos = (POSITION)(pData->pNext);
	return pData;
}

HOLEDATA* HoleDataList::AddTail(HOLEDATA pData)
{
	LPHOLEDATAUNIT pHoleUnit;
	int nArray, nIndex;
	nArray = m_nAddCount/MAX_UNIT_NO;
	nIndex = m_nAddCount%MAX_UNIT_NO;
	if(nIndex == 0)
	{
		pHoleUnit = new HOLEDATAUNIT;
		m_List.Add(pHoleUnit);
	}
	else
		pHoleUnit =  m_List.GetAt(nArray);

	memcpy(&pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount], &pData, sizeof(HOLEDATA));

	if(m_pHeadHoleData == NULL)
	{
		pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount].pBefore = NULL;
		pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount].pNext = NULL;
		m_pHeadHoleData = &pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount];
		m_pTailHoleData = &pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount];
	}
	else
	{
		pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount].pBefore = m_pTailHoleData;
		pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount].pNext = NULL;
		m_pTailHoleData->pNext = &pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount];
		m_pTailHoleData = &pHoleUnit->m_HoleUnitList[pHoleUnit->m_nUnitCount];
	}

	pHoleUnit->m_nUnitCount++;
	m_nCount++;
	m_nAddCount++;

	return m_pTailHoleData;
}

void HoleDataList::RemoveAll()
{
	m_nCount = 0;
	m_nAddCount = 0;
	m_pHeadHoleData = NULL;
	m_pTailHoleData = NULL;

	LPHOLEDATAUNIT pHoleUnit;
	int nUnitCount = m_List.GetCount();
	for(int i = 0; i < nUnitCount; i++)
	{
		pHoleUnit =  m_List.GetAt(i);
		delete pHoleUnit;
	}
	m_List.RemoveAll();
}

void HoleDataList::RemoveAt(POSITION pos)
{
	if(pos == NULL)
		return;

	LPHOLEDATA pData = (LPHOLEDATA)pos;

	if(pData->pBefore)
	{
		(pData->pBefore)->pNext = pData->pNext;
		if(pData->pNext)
		{
			(pData->pNext)->pBefore = pData->pBefore;
		}
		else
		{
			m_pTailHoleData = pData->pBefore;
		}
	}
	else
	{
		if(pData->pNext)
		{
			m_pHeadHoleData = pData->pNext;
			m_pHeadHoleData->pBefore = NULL;
		}
		else
		{
			m_pHeadHoleData = m_pTailHoleData = NULL;
		}
	}
	m_nCount--;
}

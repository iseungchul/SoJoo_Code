// AutoManualScaleINIFile.cpp: implementation of the CAutoManualScaleINIFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "AutoManualScaleINIFile.h"
#include "DAutoManualScaleINI.h"
#include "DSystemINI.h"
#include "DEasyDrillerINI.h"



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAutoManualScaleINIFile::CAutoManualScaleINIFile()
{

}

CAutoManualScaleINIFile::~CAutoManualScaleINIFile()
{

}

BOOL CAutoManualScaleINIFile::OpenAutoManualScaleINIFile(CString strFilePath, DAutoManualScaleINI& clsAutoManualScaleINI)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;

	if( FALSE == sFile.Open( strFilePath, CFile::modeRead | CFile::typeText ) )
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, strFilePath);
		ErrMessage(strMsg);

//		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		WriteLog(strMsg);
		return bRet;
	}

	CString strGetData;

	CString strMsg;

	while( sFile.ReadString( strGetData ) )
	{
		if( 0 == strGetData.CompareNoCase(_T("// START AUTO MANUAL SCALE SECTION")) )
		{
			if( FALSE == ParsingAutoManualScale( sFile, clsAutoManualScaleINI ) )
			{
				CString strString;
				strString.LoadString(IDS_ERR_FILE_FORMAT);
				strMsg.Format(strString, _T("ParsingAutoManualScale"));
				ErrMessage(strMsg);

//				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				WriteLog(strMsg);
				break;
			}
		}
	
		else if( 0 == strGetData.CompareNoCase(_T("// END AUTO MANUAL SCALE INI FILE")) )
		{
			bRet = TRUE;
			break;
		}
	}

	sFile.Close();

	return bRet;
}

BOOL CAutoManualScaleINIFile::GetOldAutoManualScaleData(DAutoManualScaleINI& clsAutoManualScaleINI, DSystemINI clsSystemINI)
{
	CString strTemp;
	for(int i = 0; i < AUTO_MANUAL_SCALE_COUNT; i++)
	{
		clsAutoManualScaleINI.m_sAutoManualScale.nInfoId[i] = i;	
		clsAutoManualScaleINI.m_sAutoManualScale.nFilmLayer[i] = i;
		clsAutoManualScaleINI.m_sAutoManualScale.nScaleType[i] = 0;
	}
	
	return TRUE;
}

BOOL CAutoManualScaleINIFile::ParsingAutoManualScale(CStdioFile& sFile, DAutoManualScaleINI& clsAutoManualScaleINI)
{
	BOOL bRet = FALSE;
	CString strGetData;
	CString strTarget;
	int nIndex = 0;
	
	while( sFile.ReadString( strGetData ) )
	{
		// Index
		if( ScanSys( strGetData, _T("INDEX ="), nIndex ) )
			continue;

		clsAutoManualScaleINI.m_sAutoManualScale.nInfoId[nIndex] = nIndex;
		// id
		if( ScanSys( strGetData, _T("FILM LAYER ="), clsAutoManualScaleINI.m_sAutoManualScale.nFilmLayer[nIndex]) )
			continue;
		if( ScanSys( strGetData, _T("SCALE TYPE ="), clsAutoManualScaleINI.m_sAutoManualScale.nScaleType[nIndex]) )
			continue;

		if( 0 == strGetData.CompareNoCase(_T("// END AUTO MANUAL SCALE SECTION")) )
		{
			bRet = TRUE;
			break;
		}
	}
	
	if(bRet == FALSE)
		WriteLog(strGetData);
	
	return bRet;
}



BOOL CAutoManualScaleINIFile::SaveAutoManualScaleINIFile(CString strFilePath, DAutoManualScaleINI clsAutoManualScaleINI)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;
	
	if(FALSE == sFile.Open(strFilePath,CFile::modeCreate|CFile::modeWrite|CFile::typeText) )
	{
		//		CString strMsg;
		
		//		strMsg.Format(_T("Can't Save %s file  "), strFilePath);
		//		ErrMessage(strMsg, MB_ICONERROR);
		
		return bRet;
	}
	
	CString strSetData;
	
	strSetData.Format(_T("// START AUTO MANUAL SCALE INI FILE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	CTime CurTime = CTime::GetCurrentTime();
	strSetData.Format(_T("Last Update Time : %04d-%02d-%02d %02d:%02d:%2d\n\n"), CurTime.GetYear(), 
					   CurTime.GetMonth(), CurTime.GetDay(), CurTime.GetHour(), CurTime.GetMinute(), 
					   CurTime.GetSecond() );
	sFile.WriteString( strSetData );
	
	SaveAutoManualScale( sFile, clsAutoManualScaleINI );

	
	strSetData.Format(_T("// END AUTO MANUAL SCALE INI FILE\n"));
	sFile.WriteString( (LPCTSTR)strSetData );
	
	sFile.Close();
	bRet = TRUE;
	
	return bRet;
}


BOOL CAutoManualScaleINIFile::SaveAutoManualScale(CStdioFile& sFile, DAutoManualScaleINI clsAutoManualScaleINI)
{
	BOOL bRet = FALSE;
	CString strSetData;
	int nRepeatcount;


	strSetData.Format(_T("// START AUTO MANUAL SCALE SECTION\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	//// Total count
	//strSetData.Format(_T("LASTINDEX = %d\n"), clsBeamPathINI.m_sBeampath.nLastIndex);
	//sFile.WriteString( (LPCTSTR)strSetData );

	//nRepeatcount = clsBeamPathINI.m_sBeampath.nLastIndex;

	for(int i = 0 ;i < AUTO_MANUAL_SCALE_COUNT ;i++)
	{	
		// Index
		strSetData.Format(_T("INDEX = %d\n"), i);
		sFile.WriteString( (LPCTSTR)strSetData );

		strSetData.Format(_T("FILM LAYER = %d\n"), i);
		sFile.WriteString( (LPCTSTR)strSetData );

		// Power Compen Check
		strSetData.Format(_T("SCALE TYPE = %d\n"), clsAutoManualScaleINI.m_sAutoManualScale.nScaleType[i]);
		sFile.WriteString( (LPCTSTR)strSetData );
	}
	
	strSetData.Format(_T("// END AUTO MANUAL SCALE SECTION\n\n"));
	sFile.WriteString( (LPCTSTR)strSetData );

	return bRet;
}


void CAutoManualScaleINIFile::WriteLog(CString strLog)
{
	CString strPathName;
	strPathName.Format(_T("D:\\ViaHole\\ErrorLog\\"));
	CTime EventTime = CTime::GetCurrentTime();
	strPathName += EventTime.Format(_T("INI_%y%m%d"));
	
	CStdioFile cFile;
	if (FALSE == cFile.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;
	
	CString strWrite;
	strWrite.Format(_T("%02d:%02d:%02d | %s\n"),
		EventTime.GetHour(),
		EventTime.GetMinute(),
		EventTime.GetSecond(),
		strLog);
	TRY
	{
		cFile.SeekToEnd();		
		cFile.Write(strWrite, strWrite.GetLength());
		cFile.Close();
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH
}
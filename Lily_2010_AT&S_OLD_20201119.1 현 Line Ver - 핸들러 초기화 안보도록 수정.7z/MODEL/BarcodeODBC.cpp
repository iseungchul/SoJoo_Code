// BarcodeOdbc.cpp: implementation of the CBarcodeOdbc class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "BarcodeOdbc.h"
//#include <sqlext.h>
#include "DEasyDrillerINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

const int BUFFER_MAX = 512;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBarcodeOdbc::CBarcodeOdbc()
{
	m_hEnv			= NULL;
	m_hDbc			= NULL;
	m_hStmt			= NULL;
	m_strWorkingDir.Format(_T("D:\\ViaHole\\System\\"));
	m_bOpen			= NULL;
}

CBarcodeOdbc::~CBarcodeOdbc()
{

}

BOOL CBarcodeOdbc::DBConnect()
{
	CString strINI;
	strINI.Format("LotDB.mdb");
	
	SQLCHAR		InCon[255];
	SQLCHAR		OutCon[1024];
	SQLSMALLINT	cbOutCon;
	char Dir[255] = {0,};
	SQLRETURN	bRet;
	
	m_strWorkingDir = gEasyDrillerINI.m_clsDirPath.GetBarcodeDir();
//	m_strWorkingDir.Format("D:\\ViaHole\\System\\LotDB.mdb");

	// Set SQL Env Handle
	if( ::SQLAllocHandle( SQL_HANDLE_ENV, SQL_NULL_HANDLE, &m_hEnv ) != SQL_SUCCESS )
		return FALSE;
	
	if( ::SQLSetEnvAttr( m_hEnv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 
		SQL_IS_INTEGER ) != SQL_SUCCESS )
		return FALSE;
	
	// Set SQL Dbc Handle
	if( ::SQLAllocHandle( SQL_HANDLE_DBC, m_hEnv, &m_hDbc ) != SQL_SUCCESS )
		return FALSE;
	
	// Connect mdb file
	CString strDBPath;
	
	// 2011 02 24
//	strDBPath.Format("\\\\%s\\mdb\\%s", m_strWorkingDir,strINI);
	strDBPath = m_strWorkingDir;
	strDBPath = m_strWorkingDir;
	sprintf_s( Dir, 255, "%s", strDBPath );
	wsprintf( (char*)InCon, "DRIVER={Microsoft Access Driver (*.mdb)};"
		"DBQ=%s;", Dir);
	
	bRet = ::SQLDriverConnect( m_hDbc, NULL, InCon, sizeof(InCon), OutCon, sizeof(OutCon),
		&cbOutCon, SQL_DRIVER_NOPROMPT );
	
	if( bRet != SQL_SUCCESS && bRet != SQL_SUCCESS_WITH_INFO )
		return FALSE;
	
	// Set Stat Handle
	if( ::SQLAllocHandle( SQL_HANDLE_STMT, m_hDbc, &m_hStmt ) != SQL_SUCCESS )
		return FALSE;
	
	m_bOpen = TRUE;
	return TRUE;
}

void CBarcodeOdbc::DBDisconnect()
{
	// Free Stmt Handle
	if( NULL != m_hStmt )
	{
		::SQLFreeHandle( SQL_HANDLE_STMT, m_hStmt );
		m_hStmt = NULL;
	}
	
	// Free Dbc Handle
	if( NULL != m_hDbc )
	{
		// Disconnect
		::SQLDisconnect(m_hDbc);
		::SQLFreeHandle( SQL_HANDLE_DBC, m_hDbc );
		m_hDbc = NULL;
	}
	
	// Free Env Handle
	if( NULL != m_hEnv )
	{
		::SQLFreeHandle( SQL_HANDLE_ENV, m_hEnv );
		m_hEnv = NULL;
	}
	m_bOpen = FALSE;
}

BOOL CBarcodeOdbc::GetManageNo(char *pLot, char *pManage, char *pCurrent)
{
	if(!DBConnect())
		return FALSE;

	BOOL bRet = 0;
	memset(pManage, 0, sizeof(pManage));
	memset(pCurrent, 0, sizeof(pCurrent));
	if(!m_bOpen)
		return FALSE;
	
	char	szSql[BUFFER_MAX] = {0,};
	char	szLot[BUFFER_MAX] = {0,};
	
	sprintf_s(szLot, 512, "%s", pLot);
	
	SQLCHAR	szID[BUFFER_MAX] = {0,};
	SQLCHAR	szDATA[BUFFER_MAX] = {0,};
	SQLCHAR szDATA2[BUFFER_MAX] = {0,};
	SQLINTEGER nDATA, nDATA2;
	
	// Column Binding
	::SQLBindCol( m_hStmt, 1, SQL_C_CHAR, szDATA, sizeof(szDATA), &nDATA );
	::SQLBindCol( m_hStmt, 2, SQL_C_CHAR, szDATA2, sizeof(szDATA2), &nDATA2 );
	
	
	
	// Excute SQL
	//sprintf_s(szSql, "select ID, DATA, DATA2 from %s where DATA = '%s'", szSection, szData );
	sprintf_s(szSql, 512, "select MANAGE_NUM, ������� from LotInfo where LOT_NUM = '%s'", szLot );

#ifdef 	__KUNSAN_6__		//  ��� (6ȣ��~ , 23�� ����) ���� 
	sprintf_s(szSql, 512, "select MANAGE_NUM, CURRENT from LotInfo where LOT_NUM = '%s'", szLot );
#endif
#ifdef 	__KUNSAN_8__		//  ��� (6ȣ��~ , 23�� ����) ���� 
	sprintf_s(szSql, 512, "select MANAGE_NUM, CURRENT from LotInfo where LOT_NUM = '%s'", szLot );
#endif
#ifdef	__KUNSAN_1__		//  ��� (1ȣ��~ 5, 5�� ����) ����
	sprintf_s(szSql, 512, "select MANAGE_NUM, CURRENT from LotInfo where LOT_NUM = '%s'", szLot );
#endif
#ifdef __KUNSAN_2012__
	sprintf_s(szSql, 512, "select MANAGE_NUM, CURRENT from LotInfo where LOT_NUM = '%s'", szLot );
#endif
#ifdef __KUNSAN_2013__		// ��� 3RDAOD 
	sprintf_s(szSql, 512, "select MANAGE_NUM, CURRENT from LotInfo where LOT_NUM = '%s'", szLot );
#endif
	
	
	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS ); 
	if( nRet != SQL_SUCCESS && nRet != SQL_SUCCESS_WITH_INFO )
	{
		GetDiagonostics();
		DBDisconnect();
		
		return FALSE;
	}
	
	// Fetch Result Set
	int nResultSet = 0;
	
	while( SQL_NO_DATA != ::SQLFetch( m_hStmt ) )
	{
		sprintf_s( pManage, BUFMAX, "%s", szDATA);
		sprintf_s( pCurrent, BUFMAX, "%s", szDATA2);
		nResultSet++;
	}
	
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );
	
	bRet = 1;
	
	DBDisconnect();
	return bRet;
}

void CBarcodeOdbc::GetDiagonostics()
{
	int			nDiag = 0;
	SQLINTEGER	nNativeError;
	SQLCHAR		szSqlState[6];
	SQLCHAR		szMsg[BUFFER_MAX];
	SQLSMALLINT	nMsgLen;
	
	::SQLGetDiagField( SQL_HANDLE_STMT, m_hStmt, 0, SQL_DIAG_NUMBER, &nDiag, 0, &nMsgLen );
	
	SQLRETURN nRet;
	
	nDiag = 1;
	while( 1 )
	{
		nRet = ::SQLGetDiagRec( SQL_HANDLE_STMT, m_hStmt, nDiag, szSqlState, &nNativeError, szMsg, sizeof(szMsg), &nMsgLen );
		if( nRet == SQL_NO_DATA )
			break;
		ErrMessage( (LPCTSTR)szMsg, MB_ICONSTOP );
		nDiag++;
	}
}

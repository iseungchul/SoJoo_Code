// DDirPath.h: interface for the DDirPath class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DDIRPATH_H__52E8CBD4_166A_4B0C_9508_7074CFF8A380__INCLUDED_)
#define AFX_DDIRPATH_H__52E8CBD4_166A_4B0C_9508_7074CFF8A380__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DDirPath  
{
public:
	DDirPath();
	virtual ~DDirPath();

// Operation
public :
	void		SetRootDir(CString strDir);
	CString		GetRootDir();

	void		SetTempDir(CString strTemp);
	CString		GetTempDir();

	void		SetParameterDir(CString strDir);
	CString		GetParameterDir();

	void		SetCorrectDir(CString strDir);
	CString		GetCorrectDir();

	void		SetProjectDir(CString strDir);
	CString		GetProjectDir();

	void		SetDataDir(CString strDir);
	CString		GetDataDir();

	void		SetConvertedDir(CString strDir);
	CString		GetConvertedDir();

	void		SetImageDir(CString strDir);
	CString		GetImageDir();

	void		SetErrorLogDir(CString strDir);
	CString		GetErrorLogDir();

	void		SetProcessLogDir(CString strDir);
	CString		GetProcessLogDir();

	void		SetLPCLogDir(CString strDir);
	CString		GetLPCLogDir();


	void		SetBackupDir(CString strDir);
	CString		GetBackupDir();

	void		SetSystemDir(CString strSys);
	CString		GetSystemDir();
	
	void		SetApertureDir(CString strDir);
	CString		GetApertureDir();

	CString		GetBarcodeDir();
	void		SetBarcodeDir(CString strDir);

	void		SetScaleLogDir(CString strDir);
	CString		GetScaleLogDir();

	void		SetNetworkDir(CString strDir);
	CString		GetNetworkDir();

	void		SetDatabaseNetworkDir(CString strDir);
	CString		GetDatabaseNetworkDir();

	void		SetImportantLogDir(CString strDir);
	CString		GetImportantLogDir();

	void		Set1stMasterCalFilePath(CString strPath);
	CString		Get1stMasterCalFilePath();

	void		Set1stSlaveCalFilePath(CString strPath);
	CString		Get1stSlaveCalFilePath();

	void		Set2ndMasterCalFilePath(CString strPath);
	CString		Get2ndMasterCalFilePath();

	void		Set2ndSlaveCalFilePath(CString strPath);
	CString		Get2ndSlaveCalFilePath();
	
	void		SetScannerProfileFilePath(CString strPath);
	CString		GetScannerProfileFilePath();

	void		SetVisionProjectPath(CString strPath);
	CString		GetVisionProjectPath();

	void		CheckDirectory();

// Attributes
protected :
	CString		m_strRoot;
	CString		m_strParameter;
	CString		m_strCorrect;
	CString		m_strProject;
	CString		m_strData;
	CString		m_strConverted;
	CString		m_strImage;
	CString		m_strErrorLog;
	CString		m_strProcessLog;
	CString		m_strLPCLog;
	CString		m_strBackup;
	CString		m_strSystem;
	CString		m_strAperture;
	CString		m_strScaleLog;
	CString		m_strNetwork;
	CString		m_strDatabaseNetwork;
	CString		m_strTemp;
	CString		m_str1stMasterCalFilePath;
	CString		m_str1stSlaveCalFilePath;
	CString		m_str2ndMasterCalFilePath;
	CString		m_str2ndSlaveCalFilePath;
	CString		m_strScannerProfilePath;
	CString		m_strVisionProjectPath;
	CString		m_strBarcodeFilePath;
	CString		m_strImportantLog;
};

//extern DDirPath gDirPath;

#endif // !defined(AFX_DDIRPATH_H__52E8CBD4_166A_4B0C_9508_7074CFF8A380__INCLUDED_)

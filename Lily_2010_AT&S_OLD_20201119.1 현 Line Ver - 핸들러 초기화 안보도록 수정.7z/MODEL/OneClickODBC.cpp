// OneClickOdbc.cpp: implementation of the COneClickOdbc class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "OneClickOdbc.h"
//#include <sqlext.h>
#include "DEasyDrillerINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

const int BUFFER_MAX = 512;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

COneClickOdbc::COneClickOdbc()
{
	m_hEnv			= NULL;
	m_hDbc			= NULL;
	m_hStmt			= NULL;
	m_strWorkingDir.Format(_T("D:\\ViaHole\\System\\"));
	m_bOpen			= NULL;
}

COneClickOdbc::~COneClickOdbc()
{

}

BOOL COneClickOdbc::DBConnect()
{

	char Dir[255] = {0,};
	SQLRETURN	bRet;

	// Set SQL Env Handle
	if( ::SQLAllocHandle( SQL_HANDLE_ENV, SQL_NULL_HANDLE, &m_hEnv ) != SQL_SUCCESS )
		return FALSE;
	if( ::SQLSetEnvAttr( m_hEnv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 
		SQL_IS_INTEGER ) != SQL_SUCCESS )
		return FALSE;

	// Set SQL Dbc Handle
	if( ::SQLAllocHandle( SQL_HANDLE_DBC, m_hEnv, &m_hDbc ) != SQL_SUCCESS )
		return FALSE;

	// Connect mdb file
	CString strDBPath;
	SQLCHAR szDSN[256], szUID[256], szPWD[256];

	wsprintf( (char*)szDSN, "LotDB" );
	wsprintf( (char*)szUID, "eotech" );
	wsprintf( (char*)szPWD, "Eo*user2015" );

	bRet = ::SQLConnect( m_hDbc, szDSN, SQL_NTS, szUID, SQL_NTS,
							szPWD, SQL_NTS );
	if( bRet != SQL_SUCCESS && bRet != SQL_SUCCESS_WITH_INFO)
	{
		//GetDiagonostics();
		AfxMessageBox("Can not connect to ERP server!!");
		DBDisconnect();
		return FALSE;
	}

	// Set Stat Handle
	if( ::SQLAllocHandle( SQL_HANDLE_STMT, m_hDbc, &m_hStmt ) != SQL_SUCCESS )
		return FALSE;

	m_bOpen = TRUE;
	return TRUE;


	/*
	CString strINI;
	strINI.Format("ParameterDB.mdb");
	
	SQLCHAR		InCon[255];
	SQLCHAR		OutCon[1024];
	SQLSMALLINT	cbOutCon;
	char Dir[255] = {0,};
	SQLRETURN	bRet;
	
	m_strWorkingDir = gEasyDrillerINI.m_clsDirPath.GetDatabaseNetworkDir();
	m_strWorkingDir.Format(_T("%s\\%s"),gEasyDrillerINI.m_clsDirPath.GetDatabaseNetworkDir(), strINI);

	// Set SQL Env Handle
	if( ::SQLAllocHandle( SQL_HANDLE_ENV, SQL_NULL_HANDLE, &m_hEnv ) != SQL_SUCCESS )
		return FALSE;
	
	if( ::SQLSetEnvAttr( m_hEnv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 
		SQL_IS_INTEGER ) != SQL_SUCCESS )
		return FALSE;
	
	// Set SQL Dbc Handle
	if( ::SQLAllocHandle( SQL_HANDLE_DBC, m_hEnv, &m_hDbc ) != SQL_SUCCESS )
		return FALSE;
	
	// Connect mdb file
	CString strDBPath;
	
	// 2011 02 24
//	strDBPath.Format("\\\\%s\\mdb\\%s", m_strWorkingDir,strINI);
	strDBPath = m_strWorkingDir;
	strDBPath = m_strWorkingDir;
	sprintf_s( Dir, 255, "%s", strDBPath );
	wsprintf( (char*)InCon, "DRIVER={Microsoft Access Driver (*.mdb)};"
		"DBQ=%s;", Dir);
	
	bRet = ::SQLDriverConnect( m_hDbc, NULL, InCon, sizeof(InCon), OutCon, sizeof(OutCon),
		&cbOutCon, SQL_DRIVER_NOPROMPT );
	
	if( bRet != SQL_SUCCESS && bRet != SQL_SUCCESS_WITH_INFO )
		return FALSE;
	
	// Set Stat Handle
	if( ::SQLAllocHandle( SQL_HANDLE_STMT, m_hDbc, &m_hStmt ) != SQL_SUCCESS )
		return FALSE;
	
	m_bOpen = TRUE;
	return TRUE;*/
}

void COneClickOdbc::DBDisconnect()
{
	// Free Stmt Handle
	if( NULL != m_hStmt )
	{
		::SQLFreeHandle( SQL_HANDLE_STMT, m_hStmt );
		m_hStmt = NULL;
	}
	
	// Free Dbc Handle
	if( NULL != m_hDbc )
	{
		// Disconnect
		::SQLDisconnect(m_hDbc);
		::SQLFreeHandle( SQL_HANDLE_DBC, m_hDbc );
		m_hDbc = NULL;
	}
	
	// Free Env Handle
	if( NULL != m_hEnv )
	{
		::SQLFreeHandle( SQL_HANDLE_ENV, m_hEnv );
		m_hEnv = NULL;
	}
	m_bOpen = FALSE;
}

BOOL COneClickOdbc::GetManageNo(char *pLot)
{
	if(!DBConnect())
		return FALSE;

	BOOL bRet = 0;
	if(!m_bOpen)
		return FALSE;
	
	char	szSql[BUFFER_MAX] = {0,};
	char	szLot[BUFFER_MAX] = {0,};
	
	sprintf_s(szLot, 512, "%s", pLot);

	SQLCHAR	szID[BUFFER_MAX] = {0,};
	SQLCHAR	szLotNo[BUFFER_MAX] = {0,};
	SQLCHAR	szManagement[BUFFER_MAX] = {0,};
	SQLCHAR szMaterialGroup[BUFFER_MAX] = {0,};
	SQLCHAR szMaterialMaker[BUFFER_MAX] = {0,};
	SQLCHAR szMaterialThick[BUFFER_MAX] = {0,};
	SQLCHAR szFiducialSize[BUFFER_MAX] = {0,};
	SQLCHAR szTrimThick[BUFFER_MAX] = {0,};
	SQLCHAR szHoleSize[BUFFER_MAX] = {0,};
	SQLCHAR szNaming[BUFFER_MAX] = {0,};
	SQLCHAR szBeamPath[BUFFER_MAX] = {0,};
	SQLCHAR szProductCount[BUFFER_MAX] = {0,};
	SQLCHAR szLayer[BUFFER_MAX] = {0,};

	SQLCHAR szCopperThick[BUFFER_MAX] = {0,};
	SQLCHAR szLayupCode[BUFFER_MAX] = {0,};
	SQLCHAR szMaterialKind[BUFFER_MAX] = {0,};
	SQLCHAR szCustomerCode[BUFFER_MAX] = {0,};
	SQLCHAR szProcessCode[BUFFER_MAX] = {0,};
	SQLCHAR szBackwardLevel[BUFFER_MAX] = {0,};
	SQLCHAR szPrevProcessCode[BUFFER_MAX] = {0,};
	SQLINTEGER nCopperThick, nLayupCode, nMaterialKind, nCustomerCode, nPrevProcessCode;


	SQLINTEGER nManagement, nMaterialGroup, nMaterialMaker, nMaterialThick, nFiducialSize, nTrimThick;
	SQLINTEGER nHoleSize, nNaming, nBeamPath, nProductCount, nLotNo, nID, nLayer, nProcessCode, nBackwardLevel;
	SQLDOUBLE dMaterialThick;
	// Column Binding
//	::SQLBindCol( m_hStmt, 0, SQL_C_CHAR, szID, sizeof(szID), &nID );
	::SQLBindCol( m_hStmt, 1, SQL_C_CHAR, szLotNo, sizeof(szLotNo), &nLotNo );
	::SQLBindCol( m_hStmt, 2, SQL_C_CHAR, szManagement, sizeof(szManagement), &nManagement );

	::SQLBindCol( m_hStmt, 3, SQL_C_CHAR, szProcessCode, sizeof(szProcessCode), &nProcessCode );

	::SQLBindCol( m_hStmt, 4, SQL_C_CHAR, szMaterialGroup, sizeof(szMaterialGroup), &nMaterialGroup );
	::SQLBindCol( m_hStmt, 5, SQL_C_CHAR, szMaterialMaker, sizeof(szMaterialMaker), &nMaterialMaker );
	::SQLBindCol( m_hStmt, 6, SQL_C_DOUBLE, &dMaterialThick, sizeof(dMaterialThick), &nMaterialThick );
//	::SQLBindCol( m_hStmt, 7, SQL_C_CHAR, szFiducialSize, sizeof(szFiducialSize), &nFiducialSize );

	::SQLBindCol( m_hStmt, 7, SQL_C_CHAR, szTrimThick, sizeof(szTrimThick), &nTrimThick );

//	::SQLBindCol( m_hStmt, 8, SQL_C_CHAR, szHoleSize, sizeof(szHoleSize), &nHoleSize );
//	::SQLBindCol( m_hStmt, 9, SQL_C_CHAR, szNaming, sizeof(szNaming), &nNaming );
//	::SQLBindCol( m_hStmt, 10, SQL_C_CHAR, szBeamPath, sizeof(szBeamPath), &nBeamPath );
	::SQLBindCol( m_hStmt, 8, SQL_C_CHAR, szProductCount, sizeof(szProductCount), &nProductCount );
	::SQLBindCol( m_hStmt, 9, SQL_C_CHAR, szCopperThick, sizeof(szCopperThick), &nCopperThick );
	::SQLBindCol( m_hStmt, 10, SQL_C_CHAR, szLayupCode, sizeof(szLayupCode), &nLayupCode );
	::SQLBindCol( m_hStmt, 11, SQL_C_CHAR, szMaterialKind, sizeof(szMaterialKind), &nMaterialKind );
	::SQLBindCol( m_hStmt, 12, SQL_C_CHAR, szCustomerCode, sizeof(szCustomerCode), &nCustomerCode );
	::SQLBindCol( m_hStmt, 13, SQL_C_CHAR, szBackwardLevel, sizeof(szBackwardLevel), &nBackwardLevel );
	::SQLBindCol( m_hStmt, 14, SQL_C_CHAR, szPrevProcessCode, sizeof(szMaterialThick), &nPrevProcessCode );
	
	sprintf_s(szSql, 512, "select LotNumber, ManagementCode, ProcessCode, MaterialGroup, MakerName, MaterialThick, TRIM_Final_Thick, CurrentSheets, LayupCode, Copper_Thick, MaterialKind, CustomerCode, BackwardLevel, PrevProcessCode  from MES30_LotInfo where LotNumber = '%s'", szLot );

//	sprintf_s(szSql, 512, "select MANAGEMENT CODE, MATERIAL GROUP, MATERIAL MAKER, MATERIAL THICK, FIDUCIAL SIZE, TRIM FINAL THICK, HOLE SIZE, NAMING, BEAM PATH, PRODUCT COUNT from DPD3000CK where LOT NO = '%s'", szLot );
	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS ); 
	if( nRet != SQL_SUCCESS && nRet != SQL_SUCCESS_WITH_INFO )
	{
		GetDiagonostics();
		DBDisconnect();
		
		return FALSE;
	}
	
	// Fetch Result Set
	int nResultSet = 0;
	
	while( SQL_NO_DATA != ::SQLFetch( m_hStmt ) )
	{
		m_strLotID.Format(_T("%s"),szLotNo);
		m_strLotID.TrimLeft();
		m_strLotID.TrimRight();

		m_strGetManage.Format(_T("%s"),szManagement);
		m_strGetManage.TrimLeft();
		m_strGetManage.TrimRight();

		/*m_strRecipeLayer.Format(_T("%s"),szLayer);
		m_strRecipeLayer.TrimLeft();
		m_strRecipeLayer.TrimRight();
*/
		m_strProcessCode.Format(_T("%s"),szProcessCode);
		m_strProcessCode.TrimLeft();
		m_strProcessCode.TrimRight();
		

		m_strMaterialGroup.Format(_T("%s"),szMaterialGroup);
		m_strMaterialGroup.TrimLeft();
		m_strMaterialGroup.TrimRight();

		m_strMeterialMaker.Format(_T("%s"),szMaterialMaker);
		m_strMeterialMaker.TrimLeft();
		m_strMeterialMaker.TrimRight();

		m_strMaterialThick.Format(_T("%.2f"),dMaterialThick);
		m_strMaterialThick.TrimLeft();
		m_strMaterialThick.TrimRight();

		m_strFiducialSize.Format(_T("%s"),szFiducialSize);
		m_strFiducialSize.TrimLeft();
		m_strFiducialSize.TrimRight();

		m_strTrimFinalThick.Format(_T("%s"),szTrimThick);
		m_strTrimFinalThick.TrimLeft();
		m_strTrimFinalThick.TrimRight();

		m_strProductCount.Format(_T("%s"),szProductCount);
		m_strProductCount.TrimLeft();
		m_strProductCount.TrimRight();

		m_strLayUpCode.Format(_T("%s"),szLayupCode);
		m_strLayUpCode.TrimLeft();
		m_strLayUpCode.TrimRight();

		m_strCopperThick.Format(_T("%s"),szCopperThick);
		m_strCopperThick.TrimLeft();
		m_strCopperThick.TrimRight();

		m_strMeterialKind.Format(_T("%s"),szMaterialKind);
		m_strMeterialKind.TrimLeft();
		m_strMeterialKind.TrimRight();

		m_strCustomerCode.Format(_T("%s"),szCustomerCode);
		m_strCustomerCode.TrimLeft();
		m_strCustomerCode.TrimRight();

		m_strHoleSize.Format(_T("%s"),szHoleSize);
		m_strHoleSize.TrimLeft();
		m_strHoleSize.TrimRight();

		m_strBackwardLevel.Format(_T("%s"),szBackwardLevel);
		m_strBackwardLevel.TrimLeft();
		m_strBackwardLevel.TrimRight();

		m_strPrevProcessCode.Format(_T("%s"),szPrevProcessCode);
		m_strPrevProcessCode.TrimLeft();
		m_strPrevProcessCode.TrimRight();

		nResultSet++;
	}
	
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );
	
	bRet = 1;
	
	DBDisconnect();
	return bRet;
}

void COneClickOdbc::GetDiagonostics()
{
	int			nDiag = 0;
	SQLINTEGER	nNativeError;
	SQLCHAR		szSqlState[6];
	SQLCHAR		szMsg[BUFFER_MAX];
	SQLSMALLINT	nMsgLen;
	
	::SQLGetDiagField( SQL_HANDLE_STMT, m_hStmt, 0, SQL_DIAG_NUMBER, &nDiag, 0, &nMsgLen );
	
	SQLRETURN nRet;
	
	nDiag = 1;
	while( 1 )
	{
		nRet = ::SQLGetDiagRec( SQL_HANDLE_STMT, m_hStmt, nDiag, szSqlState, &nNativeError, szMsg, sizeof(szMsg), &nMsgLen );
		if( nRet == SQL_NO_DATA )
			break;
		ErrMessage( (LPCTSTR)szMsg, MB_ICONSTOP );
		nDiag++;
	}
}

// ParamOdbc.cpp: implementation of the ParamOdbc class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "ParamOdbc.h"
//#include <sqlext.h>
#include "DEasyDrillerINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

const int BUFFER_MAX = 512;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ParamOdbc::ParamOdbc()
{
	m_hEnv			= NULL;
	m_hDbc			= NULL;
	m_hStmt			= NULL;
	m_strWorkingDir.Format(_T("D:\\ViaHole\\System\\"));
	m_bOpen			= NULL;
}

ParamOdbc::~ParamOdbc()
{

}

BOOL ParamOdbc::DBConnect()
{
	CString strINI;
	strINI.Format("ShotParam.mdb");
	
	SQLCHAR		InCon[255];
	SQLCHAR		OutCon[1024];
	SQLSMALLINT	cbOutCon;
	char Dir[255] = {0,};
	SQLRETURN	bRet;
	
	m_strWorkingDir = gEasyDrillerINI.m_clsDirPath.GetSystemDir();
//	m_strWorkingDir.Format("D:\\ViaHole\\System\\LotDB.mdb");

	// Set SQL Env Handle
	if( ::SQLAllocHandle( SQL_HANDLE_ENV, SQL_NULL_HANDLE, &m_hEnv ) != SQL_SUCCESS )
		return FALSE;
	
	if( ::SQLSetEnvAttr( m_hEnv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 
		SQL_IS_INTEGER ) != SQL_SUCCESS )
		return FALSE;
	
	// Set SQL Dbc Handle
	if( ::SQLAllocHandle( SQL_HANDLE_DBC, m_hEnv, &m_hDbc ) != SQL_SUCCESS )
		return FALSE;
	
	// Connect mdb file
	CString strDBPath;
	
	// 2011 02 24
	strDBPath.Format("%s%s", m_strWorkingDir,strINI);
	sprintf_s( Dir, 255, "%s", strDBPath );
	wsprintf( (char*)InCon, "DRIVER={Microsoft Access Driver (*.mdb)};"
		"DBQ=%s;", Dir);
	
	bRet = ::SQLDriverConnect( m_hDbc, NULL, InCon, sizeof(InCon), OutCon, sizeof(OutCon),
		&cbOutCon, SQL_DRIVER_NOPROMPT );
	
	if( bRet != SQL_SUCCESS && bRet != SQL_SUCCESS_WITH_INFO )
		return FALSE;
	
	// Set Stat Handle
	if( ::SQLAllocHandle( SQL_HANDLE_STMT, m_hDbc, &m_hStmt ) != SQL_SUCCESS )
		return FALSE;
	
	m_bOpen = TRUE;
	return TRUE;
}

void ParamOdbc::DBDisconnect()
{
	// Free Stmt Handle
	if( NULL != m_hStmt )
	{
		::SQLFreeHandle( SQL_HANDLE_STMT, m_hStmt );
		m_hStmt = NULL;
	}
	
	// Free Dbc Handle
	if( NULL != m_hDbc )
	{
		// Disconnect
		::SQLDisconnect(m_hDbc);
		::SQLFreeHandle( SQL_HANDLE_DBC, m_hDbc );
		m_hDbc = NULL;
	}
	
	// Free Env Handle
	if( NULL != m_hEnv )
	{
		::SQLFreeHandle( SQL_HANDLE_ENV, m_hEnv );
		m_hEnv = NULL;
	}
	m_bOpen = FALSE;
}
BOOL ParamOdbc::SetUpdateDutyOffset(int nShotNo, int nIndex, BOOL bShotType, int nBeamPath, double* dMaxFreq, double* dDuty, double* dOffset)
{
 	BOOL bRet = 0;

	if(!m_bOpen)
		return FALSE;
	
	char	szSql[BUFFER_MAX] = {0,};
	char	szID[BUFFER_MAX] = {0,};

	int nINDEX;
	SQLINTEGER nDATA;

	// Column Binding
	::SQLBindCol( m_hStmt, 1, SQL_INTEGER, &nINDEX, sizeof(nINDEX), &nDATA );

	CString strQueryCmd, strAddCmd1, strAddCmd2, strAddCmd3, strVAl;

	strQueryCmd.Format(_T("update ShotParam set OFFSET = "));
	
	strAddCmd1 += _T("");
	for(int i = 0; i < nShotNo; i++)
	{
		strVAl.Format(_T("%.0f"), dOffset[i]);
		strAddCmd1 += strVAl;
	}
	strAddCmd1 += _T("");

	strVAl.Format(_T(" where ID = %d "), nIndex);
	strQueryCmd = strQueryCmd + strAddCmd1 +strVAl;

	// Excute SQL
	sprintf_s(szSql, 512,strQueryCmd);
	
	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS ); 
	if( nRet != SQL_SUCCESS && nRet != SQL_SUCCESS_WITH_INFO )
	{
		GetDiagonostics();
		
		if( NULL != m_hStmt )
			::SQLCloseCursor( m_hStmt );

		return FALSE;
	}
	
	// Fetch Result Set
	int nResultSet = 0;
	
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );
	
	bRet = 1;

	return bRet;
}
BOOL ParamOdbc::GetStartIndex(int nShotNo, BOOL bShotType, int nBeamPath, double* dMaxFreq, double* dDuty, int* nIndex,  double* dOffset)
{
	BOOL bRet = 0;

	if(!m_bOpen)
		return FALSE;
	
	char	szSql[BUFFER_MAX] = {0,};
	char	szID[BUFFER_MAX] = {0,};

	int nINDEX;
	char szOffset[256];
	SQLINTEGER nDATA, nDATA2;
	SQLCHAR szDATA[BUFFER_MAX];
	memset(szOffset, 0, sizeof(szOffset));
	// Column Binding
	::SQLBindCol( m_hStmt, 1, SQL_INTEGER, &nINDEX, sizeof(nINDEX), &nDATA );
	::SQLBindCol( m_hStmt, 2, SQL_C_CHAR, &szDATA, sizeof(szDATA), &nDATA2 );
	
	CString strQueryCmd, strAddCmd1, strAddCmd2, strVAl;

	strQueryCmd.Format(_T("select ID, OFFSET from ShotParam where DRILL_TYPE = %d and BEAMPATH = %d and "), bShotType, nBeamPath);
	strAddCmd1.Format(_T("MAX_FREQ = "));
	strAddCmd2.Format(_T(" and DUTY = "));
	for(int i = 0; i < nShotNo; i++)
	{
		strVAl.Format(_T("%.0f"), dMaxFreq[i]);
		strAddCmd1 += strVAl;

		strVAl.Format(_T("%.0f"), dDuty[i]);
		strAddCmd2 += strVAl;
	}

	strAddCmd1 += _T("");
	strAddCmd2 += _T("");

	strQueryCmd = strQueryCmd + strAddCmd1 + strAddCmd2;

	// Excute SQL
	sprintf_s(szSql, 512, strQueryCmd);
	
	
	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS ); 
	if( nRet != SQL_SUCCESS && nRet != SQL_SUCCESS_WITH_INFO )
	{
		GetDiagonostics();
		return FALSE;
	}
	
	// Fetch Result Set
	int nResultSet = 0;
	
	while( SQL_NO_DATA != ::SQLFetch( m_hStmt ) )
	{
		sprintf_s( szID, BUFMAX, "%d", nINDEX);
	/*	if(strcmp(szID,"") == 0)
		{
			memset(nIndex, -1, sizeof(nIndex));
			if( NULL != m_hStmt )
				::SQLCloseCursor( m_hStmt );
			return FALSE;
		}*/
		nIndex[nResultSet] = atoi(szID);
		sprintf_s( szOffset, BUFMAX, "%s", szDATA);
		char* pToken;
		pToken = strtok(szOffset, _T(";"));
		int nCount = 0;
		while(pToken != NULL)
		{
			dOffset[nCount++] = atof(pToken);
			pToken = strtok(NULL, _T(";"));
		}
		nResultSet++;
		break;
	}
	
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );
	
	return nResultSet;
}

void ParamOdbc::GetDiagonostics()
{
	int			nDiag = 0;
	SQLINTEGER	nNativeError;
	SQLCHAR		szSqlState[6];
	SQLCHAR		szMsg[BUFFER_MAX];
	SQLSMALLINT	nMsgLen;
	
	::SQLGetDiagField( SQL_HANDLE_STMT, m_hStmt, 0, SQL_DIAG_NUMBER, &nDiag, 0, &nMsgLen );
	
	SQLRETURN nRet;
	
	nDiag = 1;
	while( 1 )
	{
		nRet = ::SQLGetDiagRec( SQL_HANDLE_STMT, m_hStmt, nDiag, szSqlState, &nNativeError, szMsg, sizeof(szMsg), &nMsgLen );
		if( nRet == SQL_NO_DATA )
			break;
		ErrMessage( (LPCTSTR)szMsg, MB_ICONSTOP );
		nDiag++;
	}
}


BOOL ParamOdbc::SetDutyOffset(int nShotNo, BOOL bShotType, int nBeamPath, double* dMaxFreq, double* dDuty, double* dOffset)
{
	BOOL bRet = 0;

	if(!m_bOpen)
		return FALSE;
	
	char	szSql[BUFFER_MAX] = {0,};
	char	szID[BUFFER_MAX] = {0,};

	int nINDEX;
	SQLINTEGER nDATA;

	// Column Binding
	::SQLBindCol( m_hStmt, 1, SQL_INTEGER, &nINDEX, sizeof(nINDEX), &nDATA );

	// Excute SQL

	CString strQueryCmd, strAddCmd1, strAddCmd2, strAddCmd3, strVAl;

	strQueryCmd.Format(_T("insert into ShotParam(DRILL_TYPE,BEAMPATH,MAX_FREQ,DUTY,OFFSET) values(%d,%d,"), bShotType, nBeamPath);
	
	strAddCmd1 += _T("");
	strAddCmd2 += _T("");
	strAddCmd3 += _T("");

	for(int i = 0; i < nShotNo; i++)
	{
		strVAl.Format(_T("%.0f"), dMaxFreq[i]);
		strAddCmd1 += strVAl;

		strVAl.Format(_T("%.0f"), dDuty[i]);
		strAddCmd2 += strVAl;

		strVAl.Format(_T("%.0f"), dOffset[i]);
		strAddCmd3 += strVAl;
	}

	strAddCmd1 += _T(",");
	strAddCmd2 += _T(",");
	strAddCmd3 += _T("");

	strQueryCmd = strQueryCmd + strAddCmd1 + strAddCmd2 +strAddCmd3 + _T(")");

	sprintf_s(szSql, 512, strQueryCmd);
	
	int nRet =  ::SQLExecDirect( m_hStmt, (SQLCHAR*)szSql, SQL_NTS ); 
	if( nRet != SQL_SUCCESS && nRet != SQL_SUCCESS_WITH_INFO )
	{
		GetDiagonostics();
		
		if( NULL != m_hStmt )
			::SQLCloseCursor( m_hStmt );

		return FALSE;
	}
	
	// Fetch Result Set
	if( NULL != m_hStmt )
		::SQLCloseCursor( m_hStmt );

	return TRUE;
}
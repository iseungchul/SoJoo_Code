// HVisionMatrox.h: interface for the HVisionMatrox class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HVISIONMATROX_H__87F451E7_A9F0_4111_9796_E7BBD12297F4__INCLUDED_)
#define AFX_HVISIONMATROX_H__87F451E7_A9F0_4111_9796_E7BBD12297F4__INCLUDED_

#include "..\model\DPoint.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class HVisionMatrox  
{
public:
	void SetLevel(BOOL bSuperUser);
	void SetInspectArea(DPOINT dpStart, DPOINT dpEnd);
	void OnCamChange(int nCam);
	void LoadJobFile(CString strPath);
	BOOL GetRealPos(DPOINT* rPos, int nIndex, BOOL bTrigger, char* pchar = NULL);
	BOOL OnFindFiducial(int nIndex, CString& strMsg);
	BOOL OnFindHole(int nIndex, CString& strMsg);
	void OnLive(BOOL bLive);
	void SetViewHandle(HWND* pHwnd);
	void ShowVisionDialog(BOOL bShow = TRUE);
	void InitMatroxVision();
	HVisionMatrox();
	virtual ~HVisionMatrox();

	HWND m_hVision;
	BOOL m_bIsLive;
	DPOINT m_dPos;
	
	DPOINT m_dpEnd;
	DPOINT m_dpStart;
};

#endif // !defined(AFX_HVISIONMATROX_H__87F451E7_A9F0_4111_9796_E7BBD12297F4__INCLUDED_)

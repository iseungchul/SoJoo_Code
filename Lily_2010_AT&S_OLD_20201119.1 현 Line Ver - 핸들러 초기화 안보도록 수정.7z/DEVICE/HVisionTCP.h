// HVisionTCP.h: interface for the HVisionTCP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HVISIONTCP_H__2F5ABC16_672C_489B_AB5B_62BA1E5D1863__INCLUDED_)
#define AFX_HVISIONTCP_H__2F5ABC16_672C_489B_AB5B_62BA1E5D1863__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CClientSock;

class HVisionTCP  
{
public:
	BOOL GetRealPos(DPOINT* ptdPos, int nCamNo, int nIndex,  char* pchar = NULL, int nMaskNo = 5);
	BOOL LoadJobFile(CString strFile);
	BOOL ReConnect();
	BOOL InitMatroxTCP();
	HVisionTCP();
	virtual ~HVisionTCP();

	CClientSock*	m_pClientSock;
};

#endif // !defined(AFX_HVISIONTCP_H__2F5ABC16_672C_489B_AB5B_62BA1E5D1863__INCLUDED_)

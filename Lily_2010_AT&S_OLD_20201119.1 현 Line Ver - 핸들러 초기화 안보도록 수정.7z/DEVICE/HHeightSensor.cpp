// HHeightSensor.cpp: implementation of the HHeightSensor class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "HHeightSensor.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

LPCTSTR ERROR_LIBARAYOPEN		= _T("Loading of library 'Orbit_IF.dll' Failed");
LPCTSTR ERROR_LIBARAYADDRESS	= _T("Height sensor function Failed");
LPCTSTR ERROR_LIBRARYCONNECT	= _T("Connect network number Failed");
LPCTSTR ERROR_LIBRARYNUMBER		= _T("Chose network number Failed");

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const double HEIGHT_SCALE		= 3276.8;	// mm = (14bit + 1) / stroke

HHeightSensor::HHeightSensor()
{
	sprintf_s(m_szSensorID, 1024, _T("130A625P15"));
}

HHeightSensor::~HHeightSensor()
{
	UnLoad();
}

BOOL HHeightSensor::InitHeightSensor()
{
	Load();
	Reset(0);
	Reset(1);

	SetAddress(m_szSensorID, 0);
	return SetAddress(m_szSensorID2, 1);
}

BOOL HHeightSensor::Load()
{
	m_hHeightLib = LoadLibrary(_T("Orbit_IF.dll"));
	if(m_hHeightLib == NULL)
	{
		ErrMessage(ERROR_LIBARAYOPEN, MB_ICONSTOP);
		return FALSE;
	}

	if(GetHeightFunctionAddresses() == FALSE)
	{
		ErrMessage(ERROR_LIBARAYADDRESS, MB_ICONSTOP);
		return FALSE;
	}

	int nNetworkAddress = 0;
	if(FunConnectNetwork(&nNetworkAddress) != 0)
	{
		ErrMessage(ERROR_LIBRARYCONNECT, MB_ICONSTOP);
		return FALSE;
	} 

	int nNetworkNumber = ChoseNetwork(nNetworkAddress, 0);
	if(nNetworkNumber < 0)
	{
 		ErrMessage(ERROR_LIBRARYNUMBER, MB_ICONSTOP);
		return FALSE;
	}
	
	return Reset(nNetworkNumber);
}

BOOL HHeightSensor::UnLoad()
{
	FunDisconnectFromNetworks();
	return FreeLibrary(m_hHeightLib);
}

BOOL HHeightSensor::Reset(int nNetNumber)
{
	TRACE(_T("New Number : %d\n"),  nNetNumber);
	return FunReset(nNetNumber);
}

BOOL HHeightSensor::GetHeightFunctionAddresses()
{
	SetLastError(0);
	FunReset		= (tOrbitRst)GetProcAddress(m_hHeightLib,		_T("OrbitRst"));
	FunSetAddress	= (tOrbitSetaddr)GetProcAddress(m_hHeightLib,	_T("OrbitSetaddr"));
	FunRead			= (tOrbitRead1)GetProcAddress(m_hHeightLib,		_T("OrbitRead1"));

	FunConnectNetwork			= (tConnectToOrbitNetworks)GetProcAddress(m_hHeightLib, _T("ConnectToOrbitNetworks"));
	FunGetNetworkNameAndType	= (tGetOrbitNetworkNameAndType)GetProcAddress(m_hHeightLib, _T("GetOrbitNetworkNameAndType"));
	FunDisconnectFromNetworks	= (tDisconnectFromOrbitNetworks)GetProcAddress(m_hHeightLib, _T("DisconnectFromOrbitNetworks"));
	if(GetLastError() != 0)
		return FALSE;

	return TRUE;
}

int HHeightSensor::ChoseNetwork(int nNetworks, int nNumber)
{
	int nStatus = 0;
	int nNetworkType;
	char chNetworkName[NUMBER_OF_CHARS_IN_NETWORK_NAME + 1];

	for(int nPos = 0; nPos < nNetworks; nPos ++)
	{
		strncpy_s(chNetworkName, NUMBER_OF_CHARS_IN_NETWORK_NAME + 1, DEFAULT_NETWORK_NAME, NUMBER_OF_CHARS_IN_NETWORK_NAME + 1);
		nStatus = FunGetNetworkNameAndType(nPos, chNetworkName, &nNetworkType);
		if(nStatus != 0)
			return ERROR;
	}

	if(nStatus == 0)
	{
		if(nNumber >= 0 && nNumber < nNetworks)
			return nNumber;
	}
	
	return ERROR;
}

int HHeightSensor::SetAddress(char* chID, int nNetNumber, int nAddress)
{
#ifndef __NO_USE_HEIGHT_SENSOR__
	Sleep(100);
#endif

	TRACE(_T("ID         : %s\n"),  chID);
	TRACE(_T("New Number : %d\n"),  nNetNumber);
	TRACE(_T("Address    : %d\n"),  nAddress);
	int nOpt = 0;
	return FunSetAddress(nNetNumber, nAddress, chID, &nOpt);
}

int HHeightSensor::Reading(double& dValue, int nNetNumber, int nAddress)
{
#ifdef __NO_USE_HEIGHT_SENSOR__
	int nStatus = 0;
	dValue = 0.3;
#elif defined(__TEST__)
	int nStatus = 0;
	dValue = 0.3;
#else
	int nTemp;
	int nStatus = FunRead(nNetNumber, nAddress, &nTemp);

	dValue = (double)nTemp / HEIGHT_SCALE;

	TRACE(_T("Reading : %d %d\n"), nStatus, dValue);
#endif
	return nStatus;
}

void HHeightSensor::SetSensorID(int nNumber, char* pID)
{
	if(nNumber == 0)
		sprintf_s( m_szSensorID, 1024, _T("%s"), pID);
	else
		sprintf_s( m_szSensorID2, 1024, _T("%s"), pID);
}
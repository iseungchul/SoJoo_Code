// DevChiller.cpp: implementation of the CDevLaserPower class.
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DevChiller.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

const int STX = 0x02;
const int CR = 0x0D;
const int LF = 0x0A;
//extern HINSTANCE g_hDllDeviceCom;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDevChiller::CDevChiller()
	: CAsyncComm()
{
	memset(m_szCmd, 0, sizeof(m_szCmd));
}

CDevChiller::~CDevChiller()
{

}

BOOL CDevChiller::Create()
{
	InitializeCriticalSection(&m_csCommunicationSync);
	SetBinaryMode(TRUE);
	CheckParity(FALSE);
	SetPort((TPort)m_nPortNo);
	SetBaudRate((TBaudRate)m_nBaudRate);
	SetParity((TParity)m_nParity);
	SetByteSize((TByteSize)m_nDataBits);
	SetStopBits((TStopBits)m_nStopBits);
	SetFlowControl((TFlowControl)m_nFlowControl);
	SetTimeOut(300);
	SetEventChar(0x0d);
	SetEventMask(EV_BREAK | EV_CTS | EV_DSR | EV_ERR | EV_RING | EV_RLSD | EV_RXCHAR | EV_RXFLAG | EV_TXEMPTY);
	
	OpenComm();
	if(PortOpened())
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

void CDevChiller::Destroy()
{
	CloseComm();
	DeleteCriticalSection(&m_csCommunicationSync);
}

char* CDevChiller::QueryCommand(char *szCmd)
{
	if (!PortOpened())
		return "";

	char szTmp[1024], szTrans[1024], szRet[1024];
	BOOL FEnd;
	TAssWaitResult wr;

	memset(szTmp, 0x00, sizeof(szTmp));
	memset(szRet, 0x00, sizeof(szRet));
	memset(szTrans, 0x00, sizeof(szTrans));

	EnterCriticalSection(&m_csCommunicationSync);
  
	if (strlen(szCmd) <= 102)
	{
		FEnd = FALSE;
		sprintf_s(szTrans, 1024, _T("%s\r\n"), szCmd); 

	    WriteString(szTrans);
    
		wr = FReceiveEvent.WaitFor(FTimeOut);
		if (wr == wrSignaled)
		{
#ifndef __TEST__
			Sleep(200);
#endif
			strcpy_s(szRet, ReadString());

			if (strlen(szRet) > 0)
			{
				LeaveCriticalSection(&m_csCommunicationSync);
				return &szRet[0];
			}
			else
			{
      			LeaveCriticalSection(&m_csCommunicationSync);
				return _T("");
			}
		}
		else
		{
		FireTimeOut();       
    	LeaveCriticalSection(&m_csCommunicationSync);
		return _T("");
	    }
	}
	LeaveCriticalSection(&m_csCommunicationSync);
	return &szTmp[0];
}

void CDevChiller::ProcessMonitor()
{

}

void CDevChiller::FireReceived()
{
	FReceiveEvent.SetEvent();
}

void CDevChiller::SetParameter(int nPortNo, int nBaudRate, int nParity, int nDataBits, int nStopBits, int nFlowControl)
{
	m_nPortNo = nPortNo;
	m_nBaudRate = nBaudRate;
	m_nParity = nParity;
	m_nDataBits = nDataBits;
	m_nStopBits = nStopBits;
	m_nFlowControl = nFlowControl;
}

char* CDevChiller::MakePack(char* szCmd)
{
	//�۽� = STX + "01DRS,02,0001" + CR + LF
	//���� = STX + "01DRS,OK,04D2,0929" + CR + LF
	// # PV=04D2 �� 1234 �� 123.4, SV = 0929 �� 2345 �� 234.5

	CString strTemp1;
	memset(m_szCmd, 0, sizeof(m_szCmd));
	
	strTemp1.Format(_T("%c01%s,01,0001%c%c"), STX, szCmd, CR, LF);
	sprintf_s(m_szCmd, strTemp1);
	
	return m_szCmd;
}

double CDevChiller::ParsePack(char* szResult)
{
	CString str;
	str.Format("%s", szResult);
	double dVal = 0;
	char szTemp[5];
	memset(szTemp, 0, sizeof(szTemp));


	int nIndex;
	nIndex = str.Find("OK");

	if(nIndex == -1)
		return -1;
	else
	{
		str = str.Mid(nIndex+1,4);
		strcpy_s(szTemp, (LPCTSTR)str);
		
		for(int i = 0; szTemp[i] != ' '; i++)
		{
			dVal += ConvertASCIItoNum(szTemp[i]);
		}

		return dVal/10.;
	}
	return -1;

}
int CDevChiller::ConvertASCIItoNum(char ascii)
{
	if(isdigit(ascii))
		return ascii - '0';
	if(islower(ascii))
		return ascii - 'a' + 10;

	return ascii - 'A' + 10;
}

BOOL CDevChiller::IsConnect()
{
	return PortOpened();
}

double CDevChiller::GetChillerTemp()
{
	double dVal;
	char szCmd[30], szResult[30];
	memset(szCmd, 0 , sizeof(szCmd));
	memset(szResult, 0, sizeof(szResult));

	strcpy(szCmd, MakePack("DRS"));

	strcpy(szResult, QueryCommand(szCmd));

	dVal = ParsePack(szResult);
	
	return dVal;
}
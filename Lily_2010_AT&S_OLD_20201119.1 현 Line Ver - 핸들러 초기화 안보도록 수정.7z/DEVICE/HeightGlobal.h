//***************************************************************************
// Filename:  orb_glob.h         Creation Date: 10.10.97       Language: C
// Author:    paul dorrell   
// Project:   orbit interface software
// Copyright: (c) Solartron Group Limited 1997
//                Solartron Metrology, Steyning Way, Bognor Regis, Sussex, UK. 
//                Tel + 44 (0)1243 825011,  Fax + 44 (0)1243 861244
//***************************************************************************
// Purpose:
// To define symbolic constants shared between orbit interface software and
// an orbit application software.
//***************************************************************************
// Modification History.
//***************************************************************************
// Name:                                                   Date: xx/xx/xx
// Version:
// Mod Details:
//
// Name:                                                   Date: xx/xx/xx
// Version:
// Mod Details:
//
//***************************************************************************

// Constant string definitions
#define NUMBER_OF_CHARS_IN_IF_VERSION 31
#define DEFAULT_IF_VERSION_STRING "Orbit Network DLL - Version x.x"
#define NUMBER_OF_CHARS_IN_NETWORK_NAME 20
#define DEFAULT_NETWORK_NAME "********************"
#define NUMBER_OF_CHARS_IN_PROBE_ID 10
#define DEFAULT_PROBE_ID "**********"
#define NUMBER_OF_CHARS_IN_DEVICE_TYPE 12
#define DEFAULT_DEVICE_TYPE "************"
#define NUMBER_OF_CHARS_IN_SOFTWARE_VERSION 5
#define DEFAULT_SOFTWARE_VERSION "V****"
#define NUMBER_OF_CHARS_IN_MODULE_TYPE 4
#define DEFAULT_MODULE_TYPE "****"
#define NUMBER_OF_CHARS_IN_MODULE_INFO 32
#define DEFAULT_MODULE_INFO "********************************"
#define SIZE_OF_READINGS_ARRAY 25
#define MAX_NUMBER_OF_PROBES_IN_NETWORK 31
//#define NUMBER_OF_CHARS_IN_CARD_NAME 10
#define DEFAULT_CARD_NAME "**********"
#define MAX_NUMBER_OF_ORBIT_NETWORK_CARDS 4
#define NUMBER_OF_NETWORKS_PER_CARD 2
#define MAX_NUMBER_OF_ISA_NETWORKS MAX_NUMBER_OF_ORBIT_NETWORK_CARDS * NUMBER_OF_NETWORKS_PER_CARD
#define MAX_NUMBER_OF_232_NETWORKS 2
#define MAX_NUMBER_OF_NETWORKS MAX_NUMBER_OF_ISA_NETWORKS + MAX_NUMBER_OF_232_NETWORKS

// Bit masking defininitions
#define PROBE_TYPE_MASK 0xc000

#define BIT_0	0x0001
#define BIT_1	0x0002
#define BIT_2	0x0004
#define BIT_3	0x0008
#define BIT_4	0x0010
#define BIT_5	0x0020
#define BIT_6	0x0040
#define BIT_7	0x0080
#define BIT_8	0x0100
#define BIT_9	0x0200
#define BIT_10	0x0400
#define BIT_11	0x0800
#define BIT_12	0x1000
#define BIT_13	0x2000
#define BIT_14	0x4000
#define BIT_15	0x8000

#define LE_DIRECTION	  	BIT_2
#define LE_REFMARK_FOUND	BIT_3
#define LE_REFMARK_READ		BIT_4
#define LE_REFMARK_SOUGHT	BIT_5
#define LE_NEW_READING		BIT_11
#define LE_DIFF_STOPPED		BIT_14
#define LE_DIFF_STARTED		BIT_15

// Type enumerations for Orbit controllers
enum NETWORK_CONTROLLER_TYPE {
   UNDEFINED_NETWORK_CONTROLLER,
   ISA,
   RS232,
};

// Enumeration for Orbit Interface DLL returns
enum ORBIT_STATUS_ERRORS {
   ORBIT_STATUS_OK = 0,	

   // network controller errors
   NETWORK_CONTROLLER_NOT_FOUND = 1,
   NETWORK_CONTROLLER_TIMEOUT = 2,
   NETWORK_CONTROLLER_WRITE_TIMEOUT = 3,
   NETWORK_CONTROLLER_READ_TIMEOUT = 4,
   UNRECOGNISED_NETWORK_CONTROLLER = 6,
   MISSING_PROBE_ACKNOWLEDGEMENT,

   // passed parameter errors
   BAD_NETWORK_NUMBER = 10,
   BAD_PROBE_ADDRESS,
   BAD_ID_STRING_LENGTH,
   BAD_MODULE_TYPE_STRING_LENGTH,
   BAD_SOFTWARE_VERSION_STRING_LENGTH,
   NETWORK_ADDRESS_ALREADY_ALLOCATED,
   BAD_NETWORK_STRING_LENGTH,
   BAD_DEVICE_TYPE_STRING_LENGTH,
   BAD_MODULE_INFO_STRING_LENGTH,
   BAD_IF_VERSION_STRING_LENGTH,

   // rs485 comms errors
   RS485_PARITY_ERROR               = 0x00fe,
   RS485_RX_TIMEOUT                 = 0x00ff,

   // probe errors
   PROBE_CAL_OVERFLOW               = 0x2111,
   PROBE_OVER_RANGE                 = 0x2113,
   PROBE_UNDER_RANGE                = 0x2112,
   PROBE_MULTIPLY_OVERFLOW          = 0x2114,

   // special Linear Encoder errors
   PROBE_OVER_SPEED                 = 0x21C4,
};

// User defined data type for storing records of probe address assignments
struct PROBE_ASSIGNMENT
{
   int Assigned;
   char Id[NUMBER_OF_CHARS_IN_PROBE_ID + 1];
};


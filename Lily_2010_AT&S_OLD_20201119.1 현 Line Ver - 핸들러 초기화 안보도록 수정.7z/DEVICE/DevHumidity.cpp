// DevHumidity.cpp: implementation of the CDevLaserPower class.
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DevHumidity.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

const int STX = 0x02;
const int CR = 0x0D;
const int LF = 0x0A;
//extern HINSTANCE g_hDllDeviceCom;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDevHumidity::CDevHumidity()
	: CAsyncComm()
{
	m_dDewPoint = 0.0;
	m_dHumidity = 0.0;
	m_dTemperature = 0.0;
	memset(m_szCmd, 0, sizeof(m_szCmd));
	memset(m_szResult, 0, sizeof(m_szResult));
}

CDevHumidity::~CDevHumidity()
{

}

BOOL CDevHumidity::Create()
{
	InitializeCriticalSection(&m_csCommunicationSync);
	SetBinaryMode(TRUE);
	CheckParity(FALSE);
 	SetPort((TPort)m_nPortNo);
	SetBaudRate((TBaudRate)m_nBaudRate);
	SetParity((TParity)m_nParity);
	SetByteSize((TByteSize)m_nDataBits);
	SetStopBits((TStopBits)m_nStopBits);
	SetFlowControl((TFlowControl)m_nFlowControl);
	SetTimeOut(1000);
	SetEventChar(0x0d);
//	SetEventMask(EV_BREAK | EV_CTS | EV_DSR | EV_ERR | EV_RING | EV_RLSD | EV_RXCHAR | EV_RXFLAG | EV_TXEMPTY);
	
	OpenComm();
 	PurgeComm( FHandle, PURGE_RXABORT | PURGE_RXCLEAR | PURGE_TXABORT | PURGE_TXCLEAR);
	if(PortOpened())
	{

		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

void CDevHumidity::Destroy()
{
	CloseComm();
	DeleteCriticalSection(&m_csCommunicationSync);
}

char* CDevHumidity::QueryCommand(char *szCmd)
{
	if (!PortOpened())
		return "";

	char szTmp[1024], szTrans[1024], szRet[1024];
	BOOL FEnd;
	TAssWaitResult wr;

	memset(szTmp, 0x00, sizeof(szTmp));
	memset(szRet, 0x00, sizeof(szRet));
	memset(szTrans, 0x00, sizeof(szTrans));

 	EnterCriticalSection(&m_csCommunicationSync);
  
	SetAcceptNULL(TRUE);
	SetCmdSize(8);
	if (strlen(szCmd) <= 102)
	{
		FEnd = FALSE;
		PurgeComm( FHandle, PURGE_TXCLEAR);
		PurgeComm( FHandle, PURGE_RXABORT + PURGE_RXCLEAR );
		//FReceiveEvent.SetEvent();
		WriteString(m_szCmd);
		Sleep(10);
		wr = FReceiveEvent.WaitFor(FTimeOut);
		if (wr == wrSignaled)
		{
#ifndef __TEST__
			Sleep(200);
#endif
			strcpy_s(szRet, ReadString());

			if (strlen(szRet) > 0)
			{
				LeaveCriticalSection(&m_csCommunicationSync);
				return &szRet[0];
			}
			else
			{
      			LeaveCriticalSection(&m_csCommunicationSync);
				return _T("");
			}
		}
	else
		{
			FireTimeOut();       
			LeaveCriticalSection(&m_csCommunicationSync);
			return _T("");
	    }
	}
	LeaveCriticalSection(&m_csCommunicationSync);
	return &szTmp[0];
}

void CDevHumidity::ProcessMonitor()
{

}

void CDevHumidity::FireReceived()
{
	FReceiveEvent.SetEvent();
}

void CDevHumidity::SetParameter(int nPortNo, int nBaudRate, int nParity, int nDataBits, int nStopBits, int nFlowControl)
{
	m_nPortNo = nPortNo;
	m_nBaudRate = nBaudRate;
	m_nParity = nParity;
	m_nDataBits = nDataBits;
	m_nStopBits = nStopBits;
	m_nFlowControl = nFlowControl;
}

void CDevHumidity::MakePack()
{
	CString str;
	char addr = 0x01;
	char func = 0x03;
	char StartHi = 0x00;
	char StartLo = 0x15;
	char PointHi = 0x00;
	char PointLo = 0x02;
	char CheckSumHI = 0xD5;
	char CheckSumLo = 0xCF;//addr + func + StartHi + StartLo + PointHi + PointLo;

	m_szCmd[0] = addr;
	m_szCmd[1] = func;
	m_szCmd[2] = StartHi;
	m_szCmd[3] = StartLo;
	m_szCmd[4] = PointHi;
	m_szCmd[5] = PointLo;
	m_szCmd[6] = CheckSumHI;
	m_szCmd[7] = CheckSumLo;

//	str.Format(_T("0x010x030x000x150x000x030x000x1C"));//, addr,func,StartHi,StartLo,PointHi,PointLo,CheckSumHI,CheckSumLo);
//	strcpy(m_szCmd, (LPCTSTR)str);

}
void CDevHumidity::ParsePack()
{
	//���� �µ� �̽��� ������ 3���� ����
	BYTE HumiHi;
	BYTE HumiLo;
	BYTE TempHi;
	BYTE TempLo;
	BYTE DewPHi;
	BYTE DewPLo;
	CString str;
	str.Format(_T("%s"), m_szResult);

	//���� �򰥸���.....���� ������
	HumiHi = atoi(str.Mid(3,1));
	HumiLo = atoi(str.Mid(4,1));
	TempHi = atoi(str.Mid(5,1));
	TempLo = atoi(str.Mid(6,1));
	DewPHi = atoi(str.Mid(7,1));
	DewPLo = atoi(str.Mid(8,1));

	double dHumi, dTemp, dDew;
	dHumi = HumiHi * 256 + HumiLo;
	dTemp = TempHi * 256 + TempLo;
	dDew = DewPHi * 256 + DewPLo;

	m_dHumidity = dHumi/10;
	m_dTemperature = dTemp/10;
	m_dDewPoint = dDew/10;
}


BOOL CDevHumidity::IsConnect()
{
	return PortOpened();
}

void CDevHumidity::GetHumiTempDew(double& dHumidity, double& dTemperature, double& dDewPoint)
{
	memset(m_szCmd, 0, sizeof(m_szCmd));
	memset(m_szResult, 0, sizeof(m_szResult));
	
	MakePack();
	strcpy(m_szResult, QueryCommand(m_szCmd));
	ParsePack();

	dHumidity = m_dHumidity;
	dTemperature = m_dTemperature;
	dDewPoint = m_dDewPoint;
}  
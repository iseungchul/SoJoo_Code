#include "stdafx.h"
#include "DevTemperCompen.h"
#include "math.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define UM_WRITE_LOG		WM_USER+222


CDevTemperCompen::CDevTemperCompen(void)
{
	m_dTemperDiff = 0.2;
	memset(m_dTemperature, 0, sizeof(m_dTemperature));
	m_nBackupCount = 0;
	memset(m_dOldTemperature, 0, sizeof(m_dOldTemperature));

	m_dTemperMinLimit = 10;
	m_dTemperMaxLimit = 40;
	m_dTemperDeltaTLimit = 0.2;
}


CDevTemperCompen::~CDevTemperCompen(void)
{
	Destroy();
}

BOOL CDevTemperCompen::Create()
{
	for(int i = 0; i < 5; i++)
	{
		for(int j = 0; j< 10; j++)
			m_dOldTemperature[i][j] = -999;
	}
	InitializeCriticalSection(&m_csCommunicationSync);
	SetHIOKI8431(TRUE);
	SetBinaryMode(TRUE);
	CheckParity(FALSE);
	SetPort((TPort)m_nPortNo); 
	SetBaudRate((TBaudRate)m_nBaudRate);
	SetParity((TParity)m_nParity);
	SetByteSize((TByteSize)m_nDataBits);
	SetStopBits((TStopBits)m_nStopBits);
	SetFlowControl((TFlowControl)m_nFlowControl);
	SetTimeOut(300);
	SetEventChar(0x0d);
	SetEventMask(EV_BREAK | EV_CTS | EV_DSR | EV_ERR | EV_RING | EV_RLSD | EV_RXCHAR | EV_RXFLAG | EV_TXEMPTY);
	
	OpenComm();
	if(PortOpened())
	{
		if(!SystemStart())
		{
			SetPortOpen(FALSE);
			return FALSE;
		}
		if(!StartTrigger())
		{
			SetPortOpen(FALSE);
			return FALSE;
		}
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

void CDevTemperCompen::Destroy()
{
	if(PortOpened())
	{
		SystemStop();
		CloseComm();
	}

	if(m_csCommunicationSync.LockCount >= -1)
		DeleteCriticalSection(&m_csCommunicationSync);
}
/*
void CDevTemperCompen::ReadTemperature()
{
	if (!PortOpened())
		return;

	char szTmp[1024]; 
	memset(szTmp, 0x00, sizeof(szTmp));

	EnterCriticalSection(&m_csCommunicationSync);
  
	strcpy_s(szTmp, ReadString());

	BOOL bReadCh[10];
	bReadCh[0] = bReadCh[1] = bReadCh[2] =bReadCh[3] = bReadCh[4] = bReadCh[5] = bReadCh[6] =bReadCh[7] = bReadCh[8] = bReadCh[9] = FALSE;
	unsigned short cVal[2];
	BOOL bDegree;
	int nChannel;
	int nPlus;
	int nDivideNo;
	int nTarget;
	double dResult;
	double dTemper[10];
	memset(dTemper, 0, sizeof(dTemper));

	for(int i = 0; i < 8; i++) // ������ ����ؼ� 2�� �ݺ� reading
	{
		nTarget = 0;
		cVal[0] = szTmp[i*16 + 0] & 0xFF;
		if(cVal[0] != 2)
			continue;

		cVal[0] = szTmp[i*16 + 2] & 0xFF - 48;
		nChannel = (int)cVal[0] - 1;

		if(nChannel < 0 || nChannel > 9)
			continue;

		cVal[0] = szTmp[i*16 + 4] & 0xFF - 48;
		if(cVal[0] == 1)
			bDegree = TRUE;
		else
			bDegree = FALSE;

		cVal[0] = szTmp[i*16 + 5] & 0xFF - 48;
		if(cVal[0] == 0)
			nPlus = 1;
		else
			nPlus = -1;

		cVal[0] = szTmp[i*16 + 6] & 0xFF - 48;
		nDivideNo = cVal[0];

		for(int j = 0; j < 8; j++)
		{
			cVal[0] = szTmp[i*16 + 7 + j] & 0xFF - 48;
			nTarget = nTarget * 10;
			nTarget = nTarget + cVal[0];
		}

		dResult = (double)nTarget * nPlus;
		for(int j = 0; j < nDivideNo; j++)
			dResult = dResult /10.;

		if(!bDegree)
			dResult = (dResult - 32) *5./9.;

		if(bReadCh[nChannel] == FALSE)
		{
			dTemper[nChannel] = dResult;
			bReadCh[nChannel] = TRUE;
		}
	}
*/	
	/*
	if(bReadCh[m_nTCMasterCH1] && bReadCh[m_nTCMasterCH2] &&
		bReadCh[m_nTCSlaveCH1] && bReadCh[m_nTCSlaveCH2]) // 4 channel ��� ���� reading �� ���
	{
		if(fabs(dTemper[m_nTCMasterCH1] - dTemper[m_nTCMasterCH2]) < m_dTemperDiff &&
			fabs(dTemper[m_nTCSlaveCH1] - dTemper[m_nTCSlaveCH2]) < m_dTemperDiff)
		{
			m_dTemperature[m_nTCMasterCH1] = m_dTemperature[m_nTCMasterCH2] = (dTemper[m_nTCMasterCH1] + dTemper[m_nTCMasterCH2]) / 2.;
			m_dTemperature[m_nTCSlaveCH1] = m_dTemperature[m_nTCSlaveCH2] = (dTemper[m_nTCSlaveCH1] + dTemper[m_nTCSlaveCH2]) / 2.;
			time(&m_TemperatureSaveTime);
		}
		else
		{
			TRACE("Ng Get DAta : %.1f, %.1f, %.1f, %.1f\n", dTemper[m_nTCMasterCH1], dTemper[m_nTCMasterCH2], dTemper[m_nTCSlaveCH1],  dTemper[m_nTCSlaveCH2]);
		}
	}
	else
	{
		TRACE("Ng Get DAta\n");
	}
	*/
/*
	for(int i = 0; i < 8; i++)
	{
		if(bReadCh[i])
		{
			m_dTemperature[i] = dTemper[i];
			time(&m_TemperatureSaveTime);
		}
	}
	TRACE("Ng Get DAta : %.1f, %.1f, %.1f, %.1f\n", dTemper[0], dTemper[1], dTemper[2],  dTemper[3]);


	LeaveCriticalSection(&m_csCommunicationSync);
}
*/
double CDevTemperCompen::GetTemperature(int nMainIndex)
{
	if(nMainIndex < 0 || nMainIndex >= 10)
		return -999;

	time_t currtime;
	time(&currtime);
	double dTime = difftime(currtime, m_TemperatureSaveTime[nMainIndex]);
	if(dTime > 10) // 10sec ���� �����ʹ� ������� �ν��Ѵ�.
		return -999;
	
	return m_dTemperature[nMainIndex];
}

BOOL CDevTemperCompen::GetTemperature(double* pdTempVal)
{
	time_t currtime;
	time(&currtime);
/*	double dTime = difftime(currtime, m_TemperatureSaveTime[);
	if(dTime > 10) // 10sec ���� �����ʹ� ������� �ν��Ѵ�.
	{
		for(int i = 0; i < 10; i++)
		{
			pdTempVal[i] = -999;
		}
		return FALSE;
	}
*/	
	memcpy(pdTempVal, m_dTemperature, sizeof(m_dTemperature));
	return TRUE;
}

void CDevTemperCompen::ProcessMonitor()
{

}

void CDevTemperCompen::FireReceived()
{
	FReceiveEvent.SetEvent();
}

void CDevTemperCompen::SetParameter(int nPortNo, int nBaudRate, int nParity, int nDataBits, int nStopBits, int nFlowControl)
{
	m_nPortNo = nPortNo;
	m_nBaudRate = nBaudRate;
	m_nParity = nParity;
	m_nDataBits = nDataBits;
	m_nStopBits = nStopBits;
	m_nFlowControl = nFlowControl;
}

void CDevTemperCompen::SetChannelIndex(int nMTC1, int nMTC2, int nMSB1, int nMSB2, int nSTC1, int nSTC2, int nSSB1, int nSSB2)
{
	if(nMTC1 < 0 || nMTC1 > 9)
		nMTC1 = -1;
	if(nMTC2 < 0 || nMTC2 > 9)
		nMTC2 = -1;
	if(nMSB1 < 0 || nMSB1 > 9)
		nMSB1 = -1;
	if(nMSB2 < 0 || nMSB2 > 9)
		nMSB2 = -1;

	if(nSTC1 < 0 || nSTC1 > 9)
		nSTC1 = -1;
	if(nSTC2 < 0 || nSTC2 > 9)
		nSTC2 = -1;
	if(nSSB1 < 0 || nSSB1 > 9)
		nSSB1 = -1;
	if(nSSB2 < 0 || nSSB2 > 9)
		nSSB2 = -1;

	m_nTCMasterCH1 = nMTC1;
	m_nTCMasterCH2 = nMTC2;
	m_nTCSlaveCH1 = nSTC1;
	m_nTCSlaveCH2 = nSTC2;
	m_nSBMasterCH1 = nMSB1 ;
	m_nSBMasterCH2 =nMSB2 ;
	m_nSBSlaveCH1 = nSSB1;
	m_nSBSlaveCH2 = nSSB2 ;
}

void CDevTemperCompen::SetTemperLimit(double dDiff, double dMin, double dMax, double dDelta)
{
	m_dTemperDiff = dDiff;
	m_dTemperMinLimit = dMin;
	m_dTemperMaxLimit = dMax;
	m_dTemperDeltaTLimit = dDelta;
}

BOOL CDevTemperCompen::SystemStart()
{
	char szCmd[1024], szRet[1024];
	BOOL FEnd;
	TAssWaitResult wr;

	memset(szRet, 0x00, sizeof(szRet));
	memset(szCmd, 0x00, sizeof(szCmd));

	EnterCriticalSection(&m_csCommunicationSync);
  
	if (strlen(szCmd) <= 102)
	{
		FEnd = FALSE;

		szCmd[0] = 0x02; 
		szCmd[1] = 0x01; 
		szCmd[2] = 0x50; 
		szCmd[3] = 0x00; 
		szCmd[4] = 0x00; 

		SetCmdSize(5);
	    WriteString(szCmd);
    
		wr = FReceiveEvent.WaitFor(FTimeOut);
		if (wr == wrSignaled)
		{
#ifndef __TEST__
			Sleep(50);
#endif
			memcpy(szRet, ReadString(), 255);

			if (strlen(szRet) > 0)
			{
				LeaveCriticalSection(&m_csCommunicationSync);
				if(szRet[0] == 0x02 && szRet[1] == 0x01 &&	szRet[2] == 0x50 && szRet[3] == 0x00 &&	szRet[4] == 0x01 && szRet[5] == 0x00)
					return TRUE;
				else 
					return FALSE;
			}
			else
			{
      			LeaveCriticalSection(&m_csCommunicationSync);
				return FALSE;
			}
		}
		else
		{
			FireTimeOut();       
    		LeaveCriticalSection(&m_csCommunicationSync);
			return FALSE;
	    }
	}
	LeaveCriticalSection(&m_csCommunicationSync);

	return FALSE;
}

BOOL CDevTemperCompen::SystemStop()
{
	if (!PortOpened())
		return FALSE;

	char szCmd[1024], szRet[1024];
	BOOL FEnd;
	TAssWaitResult wr;

	memset(szRet, 0x00, sizeof(szRet));
	memset(szCmd, 0x00, sizeof(szCmd));

	EnterCriticalSection(&m_csCommunicationSync);
  
	if (strlen(szCmd) <= 102)
	{
		FEnd = FALSE;

		szCmd[0] = 0x02; 
		szCmd[1] = 0x01; 
		szCmd[2] = 0x51; 
		szCmd[3] = 0x00; 
		szCmd[4] = 0x00; 

		SetCmdSize(5);
	    WriteString(szCmd);
    
		wr = FReceiveEvent.WaitFor(FTimeOut);
		if (wr == wrSignaled)
		{
#ifndef __TEST__
			Sleep(50);
#endif
			memcpy(szRet, ReadString(), 255);

			if (strlen(szRet) > 0)
			{
				LeaveCriticalSection(&m_csCommunicationSync);
				if(szRet[0] == 0x02 && szRet[1] == 0x01 &&	szRet[2] == 0x51 && szRet[3] == 0x00 &&	szRet[4] == 0x01 && szRet[5] == 0x00)
					return TRUE;
				else 
					return FALSE;
			}
			else
			{
      			LeaveCriticalSection(&m_csCommunicationSync);
				return FALSE;
			}
		}
		else
		{
			FireTimeOut();       
    		LeaveCriticalSection(&m_csCommunicationSync);
			return FALSE;
	    }
	}
	LeaveCriticalSection(&m_csCommunicationSync);

	return FALSE;
}

BOOL CDevTemperCompen::StartTrigger()
{
	char szCmd[1024], szRet[1024];
	BOOL FEnd;
	TAssWaitResult wr;

	memset(szRet, 0x00, sizeof(szRet));
	memset(szCmd, 0x00, sizeof(szCmd));

	EnterCriticalSection(&m_csCommunicationSync);
  
	if (strlen(szCmd) <= 102)
	{
		FEnd = FALSE;

		szCmd[0] = 0x02; 
		szCmd[1] = 0x01; 
		szCmd[2] = 0x58; 
		szCmd[3] = 0x00; 
		szCmd[4] = 0x00; 

		SetCmdSize(5);
	    WriteString(szCmd);
    
		wr = FReceiveEvent.WaitFor(FTimeOut);
		if (wr == wrSignaled)
		{
#ifndef __TEST__
			Sleep(50);
#endif
			memcpy(szRet, ReadString(), 255);

			if (strlen(szRet) > 0)
			{
				LeaveCriticalSection(&m_csCommunicationSync);
				if(szRet[0] == 0x02 && szRet[1] == 0x01 &&	szRet[2] == 0x58 && szRet[3] == 0x00 &&	szRet[4] == 0x01 && szRet[5] == 0x00)
					return TRUE;
				else 
					return FALSE;
			}
			else
			{
      			LeaveCriticalSection(&m_csCommunicationSync);
				return FALSE;
			}
		}
		else
		{
			FireTimeOut();       
    		LeaveCriticalSection(&m_csCommunicationSync);
			return FALSE;
	    }
	}
	LeaveCriticalSection(&m_csCommunicationSync);

	return FALSE;
}

void CDevTemperCompen::ReadAddress()
{
	if (!PortOpened())
		return;

	char szCmd[1024], szRet[1024];
	BOOL FEnd;
	TAssWaitResult wr;

	memset(szRet, 0x00, sizeof(szRet));
	memset(szCmd, 0x00, sizeof(szCmd));

	EnterCriticalSection(&m_csCommunicationSync);
  
	if (strlen(szCmd) <= 102)
	{
		FEnd = FALSE;

		szCmd[0] = 0x02; 
		szCmd[1] = 0x01; 
		szCmd[2] = 0x53; 
		szCmd[3] = 0x00; 
		szCmd[4] = 0x00; 

		SetCmdSize(5);
	    WriteString(szCmd);
    
		wr = FReceiveEvent.WaitFor(FTimeOut);
		if (wr == wrSignaled)
		{
#ifndef __TEST__
			Sleep(50);
#endif
			memcpy(szRet, ReadString(), 255);

			if (strlen(szRet) > 0)
			{
				
				if(szRet[0] == 0x02 && szRet[1] == 0x01 &&	szRet[2] == 0x53 && szRet[3] == 0x00 &&	szRet[4] == 0x10)
				{
						m_cAddress[0] = szRet[13]; 
						m_cAddress[1] = szRet[14]; 
						m_cAddress[2] = szRet[15]; 
						m_cAddress[3] = szRet[16]; 
						m_cAddress[4] = szRet[17]; 
						m_cAddress[5] = szRet[18]; 
						m_cAddress[6] = szRet[19]; 
						m_cAddress[7] = szRet[20]; 
				}
				else 
				{
					LeaveCriticalSection(&m_csCommunicationSync);
					return;
				}
			}
			else
			{
      			LeaveCriticalSection(&m_csCommunicationSync);
				return;
			}
		}
		else
		{
			FireTimeOut();       
    		LeaveCriticalSection(&m_csCommunicationSync);
			return;
	    }
	}
	LeaveCriticalSection(&m_csCommunicationSync);
}

void CDevTemperCompen::ReadTemperature()
{
 	if (!PortOpened())
		return;

	double dTemper[10];
	char szCmd[1024], szRet[1024];
	BOOL FEnd;
	TAssWaitResult wr;

	memset(szRet, 0x00, sizeof(szRet));
	memset(szCmd, 0x00, sizeof(szCmd));

	EnterCriticalSection(&m_csCommunicationSync);

	// Get Data

	FEnd = FALSE;

	szCmd[0] = 0x02; 
	szCmd[1] = 0x01; 
	szCmd[2] = 0x55; 
	szCmd[3] = 0x00; 
	szCmd[4] = 0x10; 

	szCmd[5] = m_cAddress[0]; 
	szCmd[6] = m_cAddress[1]; 
	szCmd[7] = m_cAddress[2]; 
	szCmd[8] = m_cAddress[3]; 
	szCmd[9] = m_cAddress[4]; 
	szCmd[10] = m_cAddress[5]; 
	szCmd[11] = m_cAddress[6]; 
	szCmd[12] = m_cAddress[7]; 

	szCmd[20] = 0x01; // 1��

	memset(szRet, 0x00, sizeof(szRet));

	SetCmdSize(21);
	WriteString(szCmd);
    
	wr = FReceiveEvent.WaitFor(FTimeOut);
	if (wr == wrSignaled)
	{
#ifndef __TEST__
		Sleep(50);
#endif
		memcpy(szRet, ReadString(), 255);
		unsigned short  nHigh, nLow;

		if (strlen(szRet) > 0)
		{
			if(szRet[0] == 0x02 && szRet[1] == 0x01 &&	szRet[2] == 0x55 && szRet[3] == 0x00 &&	szRet[4] == 0x21)
			{
				for(int i = 0; i < 10; i++)
				{
					if(m_nTCMasterCH1 != i && m_nTCMasterCH2 != i && 
						m_nTCSlaveCH1 != i && m_nTCSlaveCH2 != i && 
						m_nSBMasterCH1 != i && m_nSBMasterCH2 != i && 
						m_nSBSlaveCH1 != i && m_nSBSlaveCH2 != i)
						continue;

					nHigh = szRet[59 + i * 2] & 0xFF;
					nLow = szRet[59 + i * 2 + 1] & 0xFF;
					dTemper[i] = ( ( nHigh * 256 +nLow ) - 32768) / 10.;
				}

				// ���� ä�� ��
				if(m_nTCMasterCH1 != -1 && m_nTCMasterCH2 != -1) // �Ѵ� ���Ǵ� ä���̶��
				{
					if(fabs(dTemper[m_nTCMasterCH1] - dTemper[m_nTCMasterCH2]) > m_dTemperDiff)
					{
						CString strFile, str;
						strFile.Format(_T("TemperBad"));
						str.Format(_T("Diff error %d\t%.1f\t%.1f"), m_nTCMasterCH1, dTemper[m_nTCMasterCH1], dTemper[m_nTCMasterCH2]);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
						dTemper[m_nTCMasterCH1] = dTemper[m_nTCMasterCH2] = -999;
					}
				}
				if(m_nTCSlaveCH1 != -1 && m_nTCSlaveCH2 != -1) // �Ѵ� ���Ǵ� ä���̶��
				{
					if(fabs(dTemper[m_nTCSlaveCH1] - dTemper[m_nTCSlaveCH2]) > m_dTemperDiff)
					{
						CString strFile, str;
						strFile.Format(_T("TemperBad"));
						str.Format(_T("Diff error %d\t%.1f\t%.1f"), m_nTCSlaveCH1, dTemper[m_nTCSlaveCH1], dTemper[m_nTCSlaveCH2]);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
						dTemper[m_nTCSlaveCH1] = dTemper[m_nTCSlaveCH2] = -999;
					}
				}
				if(m_nSBMasterCH1 != -1 && m_nSBMasterCH2 != -1) // �Ѵ� ���Ǵ� ä���̶��
				{
					if(fabs(dTemper[m_nSBMasterCH1] - dTemper[m_nSBMasterCH2]) > m_dTemperDiff)
					{
						CString strFile, str;
						strFile.Format(_T("TemperBad"));
						str.Format(_T("Diff error %d\t%.1f\t%.1f"), m_nSBMasterCH1, dTemper[m_nSBMasterCH1], dTemper[m_nSBMasterCH2]);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
						dTemper[m_nSBMasterCH1] = dTemper[m_nSBMasterCH2] = -999;
					}
				}
				if(m_nSBSlaveCH1 != -1 && m_nSBSlaveCH2 != -1) // �Ѵ� ���Ǵ� ä���̶��
				{
					if(fabs(dTemper[m_nSBSlaveCH1] - dTemper[m_nSBSlaveCH2]) > m_dTemperDiff)
					{
						CString strFile, str;
						strFile.Format(_T("TemperBad"));
						str.Format(_T("Diff error %d\t%.1f\t%.1f"), m_nSBSlaveCH1, dTemper[m_nSBSlaveCH1], dTemper[m_nSBSlaveCH2]);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
						dTemper[m_nSBSlaveCH1] = dTemper[m_nSBSlaveCH2] = -999;
					}
				}
				
				for(int i = 0; i < 10; i++)
				{
					if(m_nTCMasterCH1 != i && m_nTCMasterCH2 != i && 
						m_nTCSlaveCH1 != i && m_nTCSlaveCH2 != i && 
						m_nSBMasterCH1 != i && m_nSBMasterCH2 != i && 
						m_nSBSlaveCH1 != i && m_nSBSlaveCH2 != i)
						continue;
					// ������ ó�� ��ƾ
					if(dTemper[i] < m_dTemperMinLimit || dTemper[i] > m_dTemperMaxLimit) // min max ����ó��
					{
						CString strFile, str;
						strFile.Format(_T("TemperBad"));
						str.Format(_T("%d\t%.1f"), i, dTemper[i]);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
						continue;
					}

					// ������ ó�� ��ƾ
					if(m_dOldTemperature[3][i] == -999) // �ι� ���� ���� ���̸�
					{
					}
					else
					{
						if(fabs(m_dOldTemperature[3][i] - dTemper[i]) > m_dTemperDeltaTLimit)
						{
							if(fabs(m_dOldTemperature[4][i] - dTemper[i]) <= 0.05) // �ι� ���� Ƣ�� ���� ������ ����
							{
							}
							else
							{
								CString strFile, str;
								strFile.Format(_T("TemperBad"));
								str.Format(_T("%d\tOld1\t%.1f\tOld2\t%.1f\tOld3\t%.1f\tOld4\t%.1f\tOld5\t%.1f\tCurr\t%.1f"), i, m_dOldTemperature[0][i], m_dOldTemperature[1][i], m_dOldTemperature[2][i], m_dOldTemperature[3][i], m_dOldTemperature[4][i], dTemper[i]);
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
								continue;
							}
						}
						else
						{
						}
					}
					for(int kk = 0; kk < 4; kk++)
						m_dOldTemperature[kk][i] = m_dOldTemperature[kk + 1][i];
					m_dOldTemperature[4][i] = dTemper[i];
					time(&m_TemperatureSaveTime[i]);
					m_dTemperature[i] = dTemper[i];
				}
				// ������ ó�� ��ƾ end
				LeaveCriticalSection(&m_csCommunicationSync);
				return;
			}
			else 
			{
				LeaveCriticalSection(&m_csCommunicationSync);
				return;
				}
		}
		else
		{
      		LeaveCriticalSection(&m_csCommunicationSync);
			return;
		}
	}
	else
	{
		FireTimeOut();       
    	LeaveCriticalSection(&m_csCommunicationSync);
		return;
	}

	LeaveCriticalSection(&m_csCommunicationSync);

}

#include "stdafx.h"
#include "DEVICE\HVision2D.h"
#include "2DVisionSocket.h"

const BYTE  INTERNALRELAY		= 0x90;
const BYTE  DATAREGISTER		= 0xA8;

#define BASE_ADDR	0x79
HVision2D::HVision2D(void)
{
	m_pClientSock = new C2DVisionSocket();
	m_bConnect = FALSE;
}


HVision2D::~HVision2D(void)
{
	if(m_pClientSock != NULL)
	{
		delete m_pClientSock;
		m_pClientSock = NULL;
	}
}
BOOL HVision2D::Connect()
{
	if(m_pClientSock != NULL)
	{
		delete m_pClientSock;
		m_pClientSock = NULL;
	}
	if(m_pClientSock == NULL)
	{
		m_pClientSock->InitWinSock();

 		if(!m_pClientSock->Connect())
		{
			m_bConnect = FALSE;
			return FALSE;
		}
		SetAcqTriggerEnable(TRUE);
	}
		
	m_bConnect = TRUE;
	return TRUE;
}
void HVision2D::Get2DBarcode(char * szResult)
{
	if(!m_bConnect)
		return;	
	
	SetAcqTriggerEnable(TRUE);
	BYTE cResult = GetAcqStatusRegister();
	Sleep(50);

	if(!(cResult & 0x01)) // not ready
		return;
	
	SetBufferResultEnable(TRUE);
	SetAcqTrigger(TRUE);

	do
	{
		cResult = GetAcqStatusRegister();
//		if(cResult & 0x02) // Trigger Ack;
//			break;

		if(cResult & 0x08) // Miss Acquistion
			return;

		Sleep(10);

	}while(cResult & 0x04); // Acquiring
	Sleep(100);

	BOOL bDecoding = FALSE;
	do 
	{
		cResult = GetDecodeStatusRegister();
		
		if(cResult & 0x02)
		{
			bDecoding = TRUE;
			break;
		}
	}while(cResult & 0x01);
	
	if(!bDecoding)
		return;

	Sleep(100);
//	char szResult[50]; 	
//	= GetResultData();
	SetDecodeResultAck(TRUE);// �а��� ����� ������� �ʱ�ȭ 
	//??? int -> char

}
BOOL HVision2D::SetAcqTriggerEnable(BOOL bUse)
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	BYTE cVal;

	if(!bUse)	cVal = 0x10; // On�̸� ������
	else		cVal = 0x01;

//	bResult = m_pClientSock->WriteBitMembyBits(&cVal, 0x9, 1); // 1 bits
	return bResult;
}
BOOL HVision2D::SetAcqTrigger(BOOL bTrigger)
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	BYTE cVal;

	if(!bTrigger)	cVal = 0x10; // On�̸� ������
	else		cVal = 0x01;

//	bResult = m_pClientSock->WriteBitMembyBits(&cVal, BASE_ADDR + 0x9, 1); // 1 bits
	return bResult;
}
BYTE HVision2D::GetAcqStatusRegister()
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	BYTE cVal;

//	bResult = m_pClientSock->ReadBitMembyBits(&cVal, BASE_ADDR + 0xB, 8);

	return cVal;
}
BOOL HVision2D::SetUserData(char* Data)
{
	if(!m_bConnect)
		return FALSE;

	char szTemp[50];
	memset(szTemp, 0, sizeof(szTemp));
	strcpy(szTemp, Data);
	WORD wVal;

	BOOL bResult = TRUE;
	BYTE cVal;
	
	//bResult = m_pClientSock->WriteMemsbyWord(D>(szTemp), BASE_ADDR + 0xC,DATAREGISTER, sizeof(szTemp));
	return bResult;
}
BOOL HVision2D::SetBufferResultEnable(BOOL bEnable)
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	BYTE cVal;

	if(!bEnable)	cVal = 0x10; // On�̸� ������
	else		cVal = 0x01;

//	bResult = m_pClientSock->WriteBitMembyBits(&cVal, BASE_ADDR + 0xD, 1); 
	return bResult;
}
BYTE HVision2D::GetDecodeStatusRegister()
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	BYTE cVal;

//	bResult = m_pClientSock->ReadBitMembyBits(&cVal, BASE_ADDR + 0xE, 8); 
	return cVal;
}
BOOL HVision2D::SetDecodeResultAck(BOOL bAck)
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	BYTE cVal;

	if(!bAck)	cVal = 0x10; // On�̸� ������
	else		cVal = 0x01;

//	bResult = m_pClientSock->WriteBitMembyBits(&cVal, BASE_ADDR + 0xF, 1); // 1 bits
	return bResult;
}
UINT HVision2D::GetDecodeResult()
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	WORD wVal;

//	bResult = m_pClientSock->ReadMemsbyWord(&wVal, BASE_ADDR + 0x10, DATAREGISTER, sizeof(WORD)); 
	return bResult;
}
UINT HVision2D::GetResultID()
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	WORD wVal;

//	bResult = m_pClientSock->ReadMemsbyWord(&wVal, BASE_ADDR + 0x10, DATAREGISTER, sizeof(WORD)); 
	return (UINT)wVal;
}
UINT HVision2D::GetResultCode()
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	WORD wVal;

//	bResult = m_pClientSock->ReadMemsbyWord(&wVal, BASE_ADDR + 0x10, DATAREGISTER, sizeof(WORD)); 
	return bResult;
}
UINT HVision2D::GetResultExtended()
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	WORD wVal;

//	bResult = m_pClientSock->ReadMemsbyWord(&wVal, BASE_ADDR + 0x10, DATAREGISTER, sizeof(WORD)); 
	return bResult;
}
UINT HVision2D::GetResultLength()
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	WORD wVal;

//	bResult = m_pClientSock->ReadMemsbyWord(&wVal, BASE_ADDR + 0x10, DATAREGISTER, sizeof(WORD)); 
	return bResult;
}
void HVision2D::GetResultData(char* pData)
{
	if(!m_bConnect)
		return;

	BOOL bResult = TRUE;
	BYTE cVal[50];

	int nSize = GetResultLength();
//	bResult = m_pClientSock->ReadMemsbyWord(&cVal, BASE_ADDR + 0x10, DATAREGISTER, nSize); 
}
BOOL HVision2D::SetSoftEvents()
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	WORD wVal;
	
//	bResult = m_pClientSock->WriteMemsbyWord(&wVal, BASE_ADDR + 0x12, DATAREGISTER,sizeof(WORD));
	return bResult;
}
UINT HVision2D::GetTriggerID()
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	WORD wVal;

//	bResult = m_pClientSock->ReadMemsbyWord(&wVal, BASE_ADDR + 0x15, DATAREGISTER, sizeof(WORD)); 
	return bResult;

}
BOOL HVision2D::SetUserDataOption()
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	WORD wVal;
	
//	bResult = m_pClientSock->WriteMemsbyWord(&wVal, BASE_ADDR + 0x16, DATAREGISTER,sizeof(WORD));
	return bResult;
}
BOOL HVision2D::SetUserDataLength(int nSize)
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	WORD wVal;
	wVal = nSize;
//	bResult = m_pClientSock->WriteMemsbyWord(&wVal, BASE_ADDR + 0x16, DATAREGISTER,sizeof(WORD));
	return bResult;
}
BYTE HVision2D::GetSoftEventAck()
{
	if(!m_bConnect)
		return FALSE;

	BOOL bResult = TRUE;
	WORD wVal;

//	bResult = m_pClientSock->ReadMemsbyWord(&wVal, BASE_ADDR + 0x18, DATAREGISTER, sizeof(WORD)); 
	return bResult;
}
// BiLinear.cpp: implementation of the CBiLinear class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "BiLinear.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBiLinear::CBiLinear()
{
}

CBiLinear::~CBiLinear()
{
}

void CBiLinear::UpdateWholeCalibration()
{
	if (!m_bIsSet)
		return;

	for (int nX = MIN_TABLE; nX <= MAX_TABLE; nX++)
	{
		for (int nY = MIN_TABLE; nY <= MAX_TABLE; nY++)
		{
			double dX, dY;
			GetPartialCalibrationOffset(nX, nY, dX, dY);
			m_Matrix[nX][nY].x += static_cast<float>(dX);
			m_Matrix[nX][nY].y += static_cast<float>(dY);
		}
	}
}

void CBiLinear::GetPartialCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset)
{
	if (IsPartialInside(dX, dY))
	{
		// index = m_nGridY * nX + nY
		int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
		int nY = static_cast<int>((dY - m_dYStart) / m_dGap);

		double dXDist = dX - m_dXStart - m_dGap * nX;
		double dYDist = dY - m_dYStart - m_dGap * nY;

		double ax, bx, ay, by;

		if (nX == m_nGridX - 1)
			ax = m_Offset[m_nGridY * nX + nY].x;
		else
			ax = m_Offset[m_nGridY * nX + nY].x + (m_Offset[m_nGridY * (nX + 1) + nY].x - m_Offset[m_nGridY * nX + nY].x) * dXDist / m_dGap;

		if (nY == m_nGridY - 1)
			bx = ax;
		else if (nX == m_nGridX - 1 && nY != m_nGridY - 1)
			bx = m_Offset[m_nGridY * nX + nY + 1].x;
		else
			bx = m_Offset[m_nGridY * nX + nY + 1].x + (m_Offset[m_nGridY * (nX + 1) + nY + 1].x - m_Offset[m_nGridY * nX + nY + 1].x) * dXDist / m_dGap;

		if (nY == m_nGridY - 1)
			ay = m_Offset[m_nGridY * nX + nY].y;
		else
			ay = m_Offset[m_nGridY * nX + nY].y + (m_Offset[m_nGridY * nX + nY + 1].y - m_Offset[m_nGridY * nX + nY].y) * dYDist / m_dGap;

		if (nX == m_nGridX - 1)
			by = ay;
		else if (nX != m_nGridX - 1 && nY == m_nGridY - 1)
			by = m_Offset[m_nGridY * (nX + 1) + nY].y;
		else
			by = m_Offset[m_nGridY * (nX + 1) + nY].y + (m_Offset[m_nGridY * (nX + 1) + nY + 1].y - m_Offset[m_nGridY * (nX + 1) + nY].y) * dYDist / m_dGap;

		dXOffset = ax + (bx - ax) * dYDist / m_dGap;
		dYOffset = ay + (by - ay) * dXDist / m_dGap;
	}
	else if (IsInside(dX, dY))
	{
		if (m_dXStart < MIN_TABLE || m_dXEnd > MAX_TABLE || m_dYStart < MIN_TABLE || m_dYEnd > MAX_TABLE)
		{
			dXOffset = dYOffset = 0.0;
			return;
		}

		if (dX < m_dXStart && dY < m_dYStart)
		{
			double dXDist = dX;
			double dYDist = dY;

			double ax = 0.0;
			double bx = m_Offset[m_nGridY * 0 + 0].x * dXDist / m_dXStart;
			double ay = 0.0;
			double by = m_Offset[m_nGridY * 0 + 0].y * dYDist / m_dYStart;

			dXOffset = ax + (bx - ax) * dYDist / m_dYStart;
			dYOffset = ay + (by - ay) * dXDist / m_dXStart;
		}
		else if (dX >= m_dXStart && dX <= m_dXEnd && dY < m_dYStart)
		{
			// index = m_nGridY * nX + nY
			int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
			int nY = 0;
			
			double dXDist = dX - m_dXStart - m_dGap * nX;
			double dYDist = dY;
			
			double ax = 0.0, bx;
			if (nX == m_nGridX - 1)
				bx = m_Offset[m_nGridY * nX + nY].x;
			else
				bx = m_Offset[m_nGridY * nX + nY].x + (m_Offset[m_nGridY * (nX + 1) + nY].x - m_Offset[m_nGridY * nX + nY].x) * dXDist / m_dGap;
			
			double ay = m_Offset[m_nGridY * nX + nY].y * dYDist / m_dYStart, by;
			if (nX == m_nGridX - 1)
				by = ay;
			else
				by = m_Offset[m_nGridY * (nX + 1) + nY].y * dYDist / m_dYStart;
			
			dXOffset = ax + (bx - ax) * dYDist / m_dYStart;
			dYOffset = ay + (by - ay) * dXDist / m_dGap;
		}
		else if (dX > m_dXEnd && dY < m_dYStart)
		{
			double dXDist = dX - m_dXEnd;
			double dYDist = dY;
			
			double ax = 0.0;
			double bx = m_Offset[m_nGridY * (m_nGridX - 1) + 0].x - m_Offset[m_nGridY * (m_nGridX - 1) + 0].x * dXDist / (MAX_TABLE - m_dXEnd);
			double ay = m_Offset[m_nGridY * (m_nGridX - 1) + 0].y * dYDist / m_dYStart;
			double by = 0.0;
			
			dXOffset = ax + (bx - ax) * dYDist / m_dYStart;
			dYOffset = ay + (by - ay) * dXDist / (MAX_TABLE - m_dXEnd);
		}
		else if (dX < m_dXStart && dY >= m_dYStart && dY <= m_dYEnd)
		{
			// index = m_nGridY * nX + nY
			int nX = 0;
			int nY = static_cast<int>((dY - m_dYStart) / m_dGap);
			
			double dXDist = dX;
			double dYDist = dY - m_dYStart - m_dGap * nY;
			
			double ax = m_Offset[m_nGridY * nX + nY].x * dXDist / m_dXStart, bx;
			if (nY == m_nGridY - 1)
				bx = ax;
			else
				bx = m_Offset[m_nGridY * nX + nY + 1].x * dXDist / m_dXStart;

			double ay = 0.0, by;
			if (nY == m_nGridY - 1)
				by = m_Offset[m_nGridY * nX + nY].y;
			else
				by = m_Offset[m_nGridY * nX + nY].y + (m_Offset[m_nGridY * nX + nY + 1].y - m_Offset[m_nGridY * nX + nY].y) * dYDist / m_dGap;
			
			dXOffset = ax + (bx - ax) * dYDist / m_dGap;
			dYOffset = ay + (by - ay) * dXDist / m_dXStart;
		}
		else if (dX > m_dXEnd && dY >= m_dYStart && dY <= m_dYEnd)
		{
			// index = m_nGridY * nX + nY
			int nX = m_nGridX - 1;
			int nY = static_cast<int>((dY - m_dYStart) / m_dGap);
			
			double dXDist = dX - m_dXEnd;
			double dYDist = dY - m_dYStart - m_dGap * nY;
			
			double ax = m_Offset[m_nGridY * nX + nY].x - m_Offset[m_nGridY * nX + nY].x * dXDist / (MAX_TABLE - m_dXEnd), bx;
			if (nY == m_nGridY - 1)
				bx = ax;
			else
				bx = m_Offset[m_nGridY * nX + nY + 1].x - m_Offset[m_nGridY * nX + nY + 1].x * dXDist / (MAX_TABLE - m_dXEnd);
			
			double ay;
			if (nY == m_nGridY - 1)
				ay = m_Offset[m_nGridY * nX + nY].y;
			else
				ay = m_Offset[m_nGridY * nX + nY].y + (m_Offset[m_nGridY * nX + nY + 1].y - m_Offset[m_nGridY * nX + nY].y) * dYDist / m_dGap;
			double by = 0.0;
			
			dXOffset = ax + (bx - ax) * dYDist / m_dGap;
			dYOffset = ay + (by - ay) * dXDist / (MAX_TABLE - m_dXEnd);
		}
		else if (dX < m_dXStart && dY > m_dYEnd)
		{
			double dXDist = dX;
			double dYDist = dY - m_dYEnd;
			
			double ax = m_Offset[m_nGridY * 0 + m_nGridY - 1].x * dXDist / m_dXStart;
			double bx = 0.0;
			double ay = 0.0;
			double by = m_Offset[m_nGridY * 0 + m_nGridY - 1].y - m_Offset[m_nGridY * 0 + m_nGridY - 1].y * dYDist / (MAX_TABLE - m_dYEnd);
			
			dXOffset = ax + (bx - ax) * dYDist / (MAX_TABLE - m_dYEnd);
			dYOffset = ay + (by - ay) * dXDist / m_dXStart;
		}
		else if (dX >= m_dXStart && dX <= m_dXEnd && dY > m_dYEnd)
		{
			// index = m_nGridY * nX + nY
			int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
			int nY = m_nGridY - 1;
			
			double dXDist = dX - m_dXStart - m_dGap * nX;
			double dYDist = dY - m_dYEnd;
			
			double ax;
			if (nX == m_nGridX - 1)
				ax = m_Offset[m_nGridY * nX + nY].x;
			else
				ax = m_Offset[m_nGridY * nX + nY].x + (m_Offset[m_nGridY * (nX + 1) + nY].x - m_Offset[m_nGridY * nX + nY].x) * dXDist / m_dGap;
			double bx = 0.0;
			
			double ay = m_Offset[m_nGridY * nX + nY].y - m_Offset[m_nGridY * nX + nY].y * dYDist / (MAX_TABLE - m_dYEnd), by;
			if (nX == m_nGridX - 1)
				by = ay;
			else
				by = m_Offset[m_nGridY * (nX + 1) + nY].y - m_Offset[m_nGridY * (nX + 1) + nY].y * dYDist / (MAX_TABLE - m_dYEnd);
			
			dXOffset = ax + (bx - ax) * dYDist / (MAX_TABLE - m_dYEnd);
			dYOffset = ay + (by - ay) * dXDist / m_dGap;
		}
		else if (dX > m_dXEnd && dY > m_dYEnd)
		{
			double dXDist = dX - m_dXEnd;
			double dYDist = dY - m_dYEnd;
			
			double ax = m_Offset[m_nGridY * (m_nGridX - 1) + m_nGridY - 1].x - m_Offset[m_nGridY * (m_nGridX - 1) + m_nGridY - 1].x * dXDist / (MAX_TABLE - m_dXEnd);
			double bx = 0.0;
			double ay = m_Offset[m_nGridY * (m_nGridX - 1) + m_nGridY - 1].y - m_Offset[m_nGridY * (m_nGridX - 1) + m_nGridY - 1].y * dYDist / (MAX_TABLE - m_dYEnd);;
			double by = 0.0;
			
			dXOffset = ax + (bx - ax) * dYDist / (MAX_TABLE - m_dYEnd);
			dYOffset = ay + (by - ay) * dXDist / (MAX_TABLE - m_dXEnd);
		}
		else
			dXOffset = dYOffset = 0.0;
	}
	else
		dXOffset = dYOffset = 0.0;
}

// HVision2DBarcode.h: interface for the HVision class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HVISION2DBARCODE_H__178E52BD_B49D_420A_BEB7_A6C0223CA9C4__INCLUDED_)
#define AFX_HVISION2DBARCODE_H__178E52BD_B49D_420A_BEB7_A6C0223CA9C4__INCLUDED_


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class HVision2DBarcodeSock;

class HVision2DBarcode  
{
public:
	HVision2DBarcode();
	~HVision2DBarcode();
	BOOL Connect(BOOL bLoad);
	void Disconnect();
	BOOL GetResult(char* szResult);
	
	static volatile __int64 m_n64Count;
	HVision2DBarcodeSock*    m_pClientSock;
	BOOL m_bConnect;

};

#endif // !defined(AFX_HVISION2DBARCODE_H__178E52BD_B49D_420A_BEB7_A6C0223CA9C4__INCLUDED_)

// HEocard5Pusan1.cpp: implementation of the HEocard5Pusan1 class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "..\EasyDriller.h"
#include "HEocard5Pusan1.h"
//#include "..\sysdef.h"
#include "..\Model\DSystemINI.h"
#include "..\model\DBeampathINI.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\model\DProject.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HEocard5Pusan1::HEocard5Pusan1()
{
	m_cCO2Laser = 0xFF;
//	m_TDrillParam.b4Beam = FALSE;
//	m_TDrillParam.nUsedBeamBitMap.bit.beam1 = TRUE;
//	m_TDrillParam.nUsedBeamBitMap.bit.beam2 = TRUE;
//	m_TDrillParam.nUsedBeamBitMap.bit.beam3 = FALSE;
//	m_TDrillParam.nUsedBeamBitMap.bit.beam4 = FALSE;
	m_TDrillParam.bDryRun = TRUE;
	m_TDrillParam.eDrillMode = (EDrillMode)STEP_DIVIDE_MODE;
	m_TDrillParam.nMinShotLoopTime = 1000; 
	m_TDrillParam.nDotBatch_inPtn = 65535;
	m_TDrillParam.nTimeAfterInpos = 0; // jump delay�� ��ü
	m_TDrillParam.nTimeAfterShot = 0; // ?
	m_TDrillParam.nHoleCount = 0;
//	m_TDrillParam.bUse_FirstOrderBeam = TRUE;


	m_TDrillParam.DumperPos.Pos[0].x = 0;
	m_TDrillParam.DumperPos.Pos[0].y = 32767;
	m_TDrillParam.DumperPos.Pos[1].x = 65535;
	m_TDrillParam.DumperPos.Pos[1].y = 32767;

	
#ifndef __USE_DUALBAND_EOCARD__

		m_TAomParam.bUse_DualAom = FALSE;

#endif
	gSystemINI.m_sHardWare.nUseFirstOrder = TRUE;
	m_TAomParam.bUse_FirstOrderBeam = TRUE;

	m_bStandbyShotRun = FALSE;

	m_pDriver = NULL;

	m_pM1Asc = new DOUBLE_POINT[ASC_AXIS_SIZE*ASC_AXIS_SIZE];
	m_pM2Asc = new DOUBLE_POINT[ASC_AXIS_SIZE*ASC_AXIS_SIZE];
	m_pS1Asc = new DOUBLE_POINT[ASC_AXIS_SIZE*ASC_AXIS_SIZE];
	m_pS2Asc = new DOUBLE_POINT[ASC_AXIS_SIZE*ASC_AXIS_SIZE];

	memset(m_pM1Asc, 0, sizeof(DOUBLE_POINT)*ASC_AXIS_SIZE*ASC_AXIS_SIZE);
	memset(m_pM2Asc, 0, sizeof(DOUBLE_POINT)*ASC_AXIS_SIZE*ASC_AXIS_SIZE);
	memset(m_pS1Asc, 0, sizeof(DOUBLE_POINT)*ASC_AXIS_SIZE*ASC_AXIS_SIZE);
	memset(m_pS2Asc, 0, sizeof(DOUBLE_POINT)*ASC_AXIS_SIZE*ASC_AXIS_SIZE);

	memset(m_ToolConfig, 0, sizeof(TDrillToolInfo) * 31);

	m_pLPC_Monitor = new TDrill_LPCMonitor;
	memset(m_pLPC_Monitor, NULL, sizeof(TDrill_LPCMonitor));

	m_b4Beam		= FALSE;
	m_nApertureMode = STEP_ORIGIN_MODE;
	m_nBurstShotNo	= 3000;

	m_nDownHoleCount = 0;

	m_pBackUpData = new TDrillHoleData[DOWNLOAD_MAX_HOLE];
	memset(m_pBackUpData, 0, sizeof(TDrillHoleData)*DOWNLOAD_MAX_HOLE);
	m_nBackupCount = 0;
	m_nAOMDutyOffsetBackup = 0;
	memset(m_nHoleCnt, 0, sizeof(int)*31);

	m_CalLPC = NULL;
	m_CalLPC = new CBicubicInterpolation;
	m_CalLPC->SetMaster(TRUE);
	
	CString strCalPath;
	strCalPath = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	LoadLPCCalibrationFile(strCalPath + _T("\\LPC.Cal"));

	InitCard();

	m_nToolOldNo = -1;
}

HEocard5Pusan1::~HEocard5Pusan1()
{
	if(m_pDriver)
	{
		delete m_pDriver;
		m_pDriver = NULL;
	}

	if(m_pBackUpData)
	{
		delete[] m_pBackUpData;
		m_pBackUpData = NULL;
	}
	if(m_CalLPC)
	{
		delete m_CalLPC;
		m_CalLPC = NULL;
	}
	delete m_pLPC_Monitor;

	delete[] m_pM1Asc;
	delete[] m_pM2Asc;
	delete[] m_pS1Asc;
	delete[] m_pS2Asc;
}

BOOL HEocard5Pusan1::InitCard()
{
#ifdef __TEST__
	return TRUE;
#endif
//	return TRUE;

	m_pDriver = new CETSx_API();
	BOOL bOpen = m_pDriver->PortOpen(0); // 0 index card loading

	if(!bOpen)
	{
		::AfxMessageBox(_T("Eocard Port Open Error"), MB_OK);
		delete m_pDriver;
		m_pDriver = NULL;
		return FALSE;
	}

	//---------

	m_UsedBeam.v = 0;
	if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_1ST)
		m_UsedBeam.bit.beam1 = TRUE;
	if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_2ND)
		m_UsedBeam.bit.beam2 = TRUE;
	if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_3RD)
		m_UsedBeam.bit.beam3 = TRUE;
	if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_4TH)
		m_UsedBeam.bit.beam4 = TRUE;

	m_pDriver->ScanCfg_SetUsedBeam(&m_UsedBeam);

	m_pDriver->Drill_SetParaAll(&m_TDrillParam);


#ifndef  __USE_DUALBAND_EOCARD__
			m_TAomParam.bUse_DualAom = FALSE;
#endif
	m_TAomParam.bUse_FirstOrderBeam = TRUE;
	m_pDriver->Drill_SetAomPara(&m_TAomParam);

	// ETS5 Initialization
	EChannelCfg scanch[MAX_SCAN_CHANNEL] = {
		OUT_Beam1y, OUT_Beam1x, OUT_Beam2y, OUT_Beam2x,
		OUT_Beam3y, OUT_Beam3x, OUT_Beam4y, OUT_Beam4x
	};

	if(gSystemINI.m_sHardWare.nScannerAxisType == PX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType == NX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType == PX_NY ||
		gSystemINI.m_sHardWare.nScannerAxisType == NX_NY)
	{
		scanch[0] = OUT_Beam1x; scanch[1] = OUT_Beam1y;
//		scanch[2] = OUT_Beam2x; scanch[3] = OUT_Beam2y;
	}

	if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == NX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == PX_NY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == NX_NY)
	{
//		scanch[0] = OUT_Beam1x; scanch[1] = OUT_Beam1y;
		scanch[2] = OUT_Beam2x; scanch[3] = OUT_Beam2y;
	}


	EChannelCfg dach[MAX_DA_CHANNEL] = {
		OUT_AnalogFps, OUT_RfOffLevel, OUT_LaserPower, OUT_Da1
	};
	
	CScanParaCmd Sp; 
//	CScanParaAux SpAux;
//	TLaserPara Lp;
	Sp.Init();
	Sp.fFieldSize_mm = (int)gSystemINI.m_sSystemDevice.dFieldSize.x;

	TLaserType lasertype;	
	lasertype.v = 0;
//	lasertype.bit.Ipg = 0;
#ifdef __KUNSAN_6__
	lasertype.bit.Standby = 0;
#else
	lasertype.bit.StandbyPulse = 0;
#endif
	lasertype.bit.Analog_FPS = 0;

//	m_pDriver->SetLaserType(lasertype);

	m_pDriver->LaserCtrl_SetEnableIO(FALSE);
	
	m_pDriver->BoardIO_SetTopBoard(1);						// Top Board �⺻Type ���� User Mode�� ���

	// Hsif0�� 1�� �ϵ���� �������� �ܶ��Ǿ��ִ�.
	// 0�� 1�� ������ ��ȣ.
//	m_pDriver->BoardIO_SetPinMux(Pin_OUT_HighSpeed_IF, 0, SIG_GATE, 0);
//	m_pDriver->BoardIO_SetPinMux(Pin_OUT_HighSpeed_IF, 1, SIG_GATE, 0);
///	m_pDriver->BoardIO_SetPinMux(Pin_OUT_HighSpeed_IF, 2, SIG_AOM, 0);

	m_pDriver->BoardIO_SetPinMux(Pin_OUT_Laser_IF, 0, SIG_FPS, FALSE);
	m_pDriver->BoardIO_SetPinMux(Pin_OUT_Laser_IF, 1, SIG_LM, FALSE);

	m_pDriver->BoardIO_SetPinMux(Pin_INOUT_LaserPower_IF, 0, SIG_LOAD_DATA0, 0); // laser enable
	m_pDriver->BoardIO_SetPinMux(Pin_INOUT_LaserPower_IF, 1, SIG_LOAD_DATA1, 0); // shutter open/close
	m_pDriver->BoardIO_SetPinMux(Pin_INOUT_LaserPower_IF, 2, SIG_LOAD_DATA2, 0); // laser power on/off


//	m_pDriver->SetIOInversion(0, 0);							//0: OutLif
//	m_pDriver->SetIOInversion(1, 4);							//1: InLif
//	m_pDriver->SetIOInversion(2, 0);							//2: OutHif

	m_pDriver->BoardIO_SetPinMux(Pin_IN_Laser_IF, 2, SIG_INPUT, TRUE);

								
//	m_pDriver->ScanCtrl_SetNumOfBeam(2);						
	m_pDriver->ScanCfg_SetNumOfBeam(2); // 100825						
	m_pDriver->BoardIO_SetChannel(EETSx_Scanner_Channel, scanch); //
	m_pDriver->BoardIO_SetChannel(EETSx_DA_Channel, dach);				//�ϵ���� ä�� ����

	SetFunction(65535); // CO2 high : laser power on  (X)

	m_pDriver->LaserCtrl_SetEnableIO(TRUE);

	BOOL bXReverse, bYReverse, bAxisCange = FALSE;

	if(gSystemINI.m_sHardWare.nScannerAxisType == PX_PY)
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_PY)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PX_NY)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_NY)
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_PX) // ------------------------------------
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NY_PX)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_NX)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else 
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
//	m_pDriver->ScanCtrl_SetAxis(0, bXReverse, bYReverse, 0, TRUE);
	m_pDriver->ScanCfg_SetAxis(0, bXReverse, bYReverse, 0, TRUE); // 100825

	//---------------------------------------------------------
	if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_PY)
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NX_PY)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_NY)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NX_NY)
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PY_PX) // ------------------------------------
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NY_PX)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PY_NX)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else 
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
//	m_pDriver->ScanCtrl_SetAxis(1, bXReverse, bYReverse, 0, TRUE);
	m_pDriver->ScanCfg_SetAxis(1, bXReverse, bYReverse, 0, TRUE); // 100825

//	m_pDriver->List_ConfigSize(8192,8192);							// ����Ʈ ���� ����
//	m_pDriver->List_SetMode(LISTMODE_Rotary); // m_pDriver->SetListMode(LISTMODE_Rotary); //LISTMODE_Auto_Change);				// ����Ʈ �ڵ� �����Ͽ� ����

	m_pDriver->ScanPara_SetCmdAll(Sp, TRUE);			//��ĳ�� �Ķ���� ����
//	m_pDriver->ScanPara_SetAuxAll(SpAux, TRUE);
//	m_pDriver->LaserPara_SetAll(Lp, TRUE);			//������ �Ķ���� ����
	m_pDriver->Timer_UpdateTime();

	ResetCO2Laser();

	return TRUE;  // return TRUE unless you set the focus to a control
}

BOOL HEocard5Pusan1::SetParameter(FParameter *pParam, double dAOMOffset, int nMask)
{
//	CString strSequenceLog;
//	strSequenceLog.Format(_T("DS=%d, JS=%d, SP=%d, CD=%d, JD=%d, LD=%d, LOnD=%d, LOffD=%d, FPSD=%d, DUTY=%.3f, FRQ=%d, DSP=%d, AOMDelay=%.3f, AOMDuty=%.3f, BeamPath=%d"), pParam->DrawStep, pParam->JumpStep, pParam->StepPeriod, pParam->CornerDelay, pParam->LineDelay, pParam->JumpDelay, pParam->LaserOnDelay, pParam->LaserOffDelay, pParam->FPSDelay, pParam->dDuty, pParam->Frequency, pParam->DrawStepPeriod, pParam->dAOMDelay, pParam->dAOMDuty, nMask);
//	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));

	if(!m_pDriver)
		return TRUE;

	BOOL bResult;

 	if(pParam->dDuty <= 0)
	{
		::AfxMessageBox(_T("Error : Laser Duty  <= 0. Check Offset."));
		return FALSE;
	}

	double dSpeedRate = 1000 * gSystemINI.m_sSystemDevice.dFieldSize.x / 65535.;
	bResult = m_pDriver->ScanPara_SetEach(EETSx_DrawSpeed_ms, pParam->DrawStep/1000. , TRUE); // mm/s
	bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_JumpSpeed_ms, gSystemINI.m_sSystemDevice.dJumpSpeed/1000., TRUE);
	bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_CornerDelay_us, gSystemINI.m_sSystemDevice.nCornerDelay, TRUE);
	bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_LineDelay_us, gSystemINI.m_sSystemDevice.nLineDelay, TRUE);
	bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_JumpDelay_us, gSystemINI.m_sSystemDevice.nJumpDelay, TRUE);
	bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_LaserOffDelay_us, pParam->LaserOffDelay, TRUE);
	bResult = bResult & m_pDriver->ScanPara_SetEach(EETSx_LaserOnDelay_us, pParam->LaserOnDelay, TRUE);
//	bResult = bResult & m_pDriver->SetParaShortJumpDelay(Sp.ShortJumpDelay, TRUE);  ?
//	bResult = bResult & m_pDriver->SetParaShortJumpSpeed1(Sp.ShortJumpSpeed1, TRUE);
//	bResult = bResult & m_pDriver->SetParaShortJumpSpeed2(Sp.ShortJumpSpeed2, TRUE);

//	bResult = bResult & m_pDriver->SetParaLaserPower(Lp.LaserPower, TRUE);			//������ �Ķ���� ����
//	if(pParam->dDuty/100. >= 100 || pParam->dDuty/100. <= 0)
//		return FALSE;

	bResult = bResult & m_pDriver->LaserPara_SetEach(EETSx_LMFreq_Hz, pParam->Frequency, TRUE);
	bResult = bResult & m_pDriver->LaserPara_SetEach(EETSx_LMDuty_us, pParam->dDuty/100., TRUE);
	bResult = bResult & m_pDriver->LaserPara_SetEach(EETSx_FPSDelay_us, pParam->FPSDelay, TRUE); // ?
	bResult = bResult & m_pDriver->LaserPara_SetEach(EETSx_FPSOnTime_us, 10 /*Lp.FPS_OnTime (us)*/, TRUE); // ?
	bResult = bResult & m_pDriver->LaserPara_SetEach(EETSx_StandbyPulseFreq_Hz, 1000, TRUE); // for CO2 Lp.StandbyPulse_Freq, 
	bResult = bResult & m_pDriver->LaserPara_SetEach(EETSx_StandbyPulseDuty_us, 0.2, TRUE); // for CO2 Lp.StandbyPulse_Duty(%), TRUE);

//	bResult = bResult & m_pDriver->SetAOMPara(pParam->dAOMDelay, pParam->dAOMDuty);
	CString str;
	str.Format(_T("%s"), pParam->cAOMFilePath);
	m_Parameter.DrawStep = pParam->DrawStep;
	m_Parameter.JumpStep = pParam->JumpStep;
	m_Parameter.StepPeriod = pParam->StepPeriod;
	m_Parameter.CornerDelay = pParam->CornerDelay;
	m_Parameter.JumpDelay = pParam->JumpDelay;
	m_Parameter.LineDelay = pParam->LineDelay;
	m_Parameter.LaserOnDelay = pParam->LaserOnDelay;
	m_Parameter.LaserOffDelay = pParam->LaserOffDelay;
	m_Parameter.FPSDelay = pParam->FPSDelay;
	m_Parameter.dDuty = pParam->dDuty;
	m_Parameter.Frequency = pParam->Frequency;
	m_Parameter.DrawStepPeriod = pParam->DrawStepPeriod;
	m_Parameter.dAOMDelay = pParam->dAOMDelay;
	m_Parameter.dAOMDuty = pParam->dAOMDuty;
	bResult = bResult & DownloadAOMProfile(-1, -1, str, 0, 0, 0, dAOMOffset, 0, 0, 0, 0, nMask);
	memcpy(m_Parameter.cAOMFilePath, pParam->cAOMFilePath, 255);

	if(bResult)
	{
		m_TDrillParam.nMinShotLoopTime = pParam->CycleTime * 1000; // ?
//		m_TDrillParam.eDrillMode = UV_LINE_MODE;
//		m_TDrillParam.nDotBatch_inPtn = 65535;
#ifndef __USE_DUALBAND_EOCARD__
		m_TAomParam.bUse_DualAom = FALSE;
#endif
		m_TAomParam.bUse_FirstOrderBeam = TRUE;

		bResult = m_pDriver->Drill_SetParaAll(&m_TDrillParam);
		bResult &= m_pDriver->Drill_SetAomPara(&m_TAomParam);
		return bResult;
	}
	else
		return FALSE;

	return TRUE;
}

BOOL HEocard5Pusan1::SetMinCycleTime(int us)
{
	if(!m_pDriver)
		return TRUE;

	if(us < 10)
		us = 0;

	m_TDrillParam.nMinShotLoopTime = us; 
	return m_pDriver->Drill_SetParaAll(&m_TDrillParam);
}

BOOL HEocard5Pusan1::SetSelfLineDivide(BOOL bOn) // use ?
{
	if(!m_pDriver)
		return TRUE;

	return TRUE;
}

BOOL HEocard5Pusan1::SetMinShotTime(int us)
{
	return TRUE;
/*
	if(!m_pDriver)
		return TRUE;

	if(us < 10)
		us = 0;

	m_TDrillParam.nMinShotTime = us; 
	return m_pDriver->Drill_SetParaAll(&m_TDrillParam);
*/}

void HEocard5Pusan1::jump(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return;

//	m_pDriver->ScanCtrl_aJump(x, y);
	TArrayPos3D posdata;
	posdata.Pos[0].x = x;
	posdata.Pos[0].y = y;
	posdata.Pos[1].x = xS;
	posdata.Pos[1].y = yS;
	posdata.Pos[2].x = x;
	posdata.Pos[2].y = y;
	posdata.Pos[3].x = xS;
	posdata.Pos[3].y = yS;
	

	m_pDriver->ScanCtrl_aJump4B(&posdata); // 100825

	if(bWaitEnd)
		StatusOK(IDLE);
}

void HEocard5Pusan1::mark(int x, int y, int xS, int yS, int x_2, int y_2, int xS_2, int yS_2, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return;
	
//	m_pDriver->ScanCtrl_aDraw(x, y);
	TArrayPos3D posdata;
	posdata.Pos[0].x = x;
	posdata.Pos[0].y = y;
	posdata.Pos[1].x = xS;
	posdata.Pos[1].y = yS;
	posdata.Pos[2].x = x;
	posdata.Pos[2].y = y;
	posdata.Pos[3].x = xS;
	posdata.Pos[3].y = yS;
	

	m_pDriver->ScanCtrl_aDraw4B(&posdata);

	if(bWaitEnd)
		StatusOK(IDLE);
}

BOOL HEocard5Pusan1::MoveDrillCenterPos()
{
	if(!m_pDriver)
		return TRUE;

//	m_pDriver->Cal_SetEnableEach(0, FALSE);
//	m_pDriver->Cal_SetEnableEach(1, FALSE);

	TArrayPos3D posdata;
	posdata.Pos[0].x = HALF_LSB;
	posdata.Pos[0].y = HALF_LSB;
	posdata.Pos[1].x = HALF_LSB;
	posdata.Pos[1].y = HALF_LSB;
	posdata.Pos[2].x = HALF_LSB;
	posdata.Pos[2].y = HALF_LSB;
	posdata.Pos[3].x = HALF_LSB;
	posdata.Pos[3].y = HALF_LSB;
	

	m_pDriver->ScanCtrl_aJump4B(&posdata); // 100825


	StatusOK(IDLE);
	
//	m_pDriver->Cal_SetEnableEach(0, TRUE);
//	m_pDriver->Cal_SetEnableEach(1, TRUE);
	return TRUE;
}

BOOL HEocard5Pusan1::ApertureDataReset(int nToolNo) // toon no �ƴ�, nToolNo) // aperturn = pattern
{
	if(!m_pDriver)
		return TRUE;

	return m_pDriver->Drill_ResetPtn(nToolNo);// ���� �ؾ� ��. nToolNo); ***
}

BOOL HEocard5Pusan1::DownloadAperture(int nToolNo, int nX, int nY, int nAction)
{
	if(!m_pDriver)
		return TRUE;

//	TDrillPtnData ptnData;
//	ptnData.dx = nX;
//	ptnData.dy = nY;
//	ptnData.isJump = !nAction;
#ifndef __USE_DUALBAND_EOCARD__
	return m_pDriver->Drill_SetPtnDot(nToolNo, m_PtnInfo[nToolNo].nUsedDotCnt, m_PtnInfo[nToolNo].PtnDot);
#endif
	return TRUE;
}

BOOL HEocard5Pusan1::DownloadShotDataDummy(	unsigned short usMasterX,
										unsigned short usMasterY,
										unsigned short usSlaveX,
										unsigned short usSlaveY,
										BOOL bApplyCalibrationMaster,
										BOOL bApplyCalibrationSlave,
										int nTCode)
{
	if(!m_pDriver)
		return TRUE;

	m_DummyPos.Pos[0].x = usMasterX;
	m_DummyPos.Pos[0].y = usMasterY;
	m_DummyPos.Pos[1].x = usSlaveX;
	m_DummyPos.Pos[1].y = usSlaveY;
	m_DummyPos.Pos[2].x = 32767;
	m_DummyPos.Pos[2].y = 32767;
	m_DummyPos.Pos[3].x = 32767;
	m_DummyPos.Pos[3].y = 32767;

	return TRUE;
}

BOOL HEocard5Pusan1::DownloadShotData2( unsigned short usMasterX,
										  unsigned short usMasterY,
										  unsigned short usSlaveX,
										  unsigned short usSlaveY,
										  BOOL bApplyCalibrationMaster, // ? use ??
										  BOOL bApplyCalibrationSlave,
										  int nTCode,
										   int nShotFilePosForLPCX,
										 int nShotFilePosForLPCY)
{
	if(!m_pDriver)
		return TRUE;

	m_ptData[m_nDownHoleCount].nToolNum = nTCode;
	m_ptData[m_nDownHoleCount].HolePos[0].x = usMasterX;
	m_ptData[m_nDownHoleCount].HolePos[0].y = usMasterY;
	m_ptData[m_nDownHoleCount].HolePos[1].x = usSlaveX;
	m_ptData[m_nDownHoleCount].HolePos[1].y = usSlaveY;
	m_ptData[m_nDownHoleCount].HolePos[2].x = 32767;
	m_ptData[m_nDownHoleCount].HolePos[2].y = 32767;
	m_ptData[m_nDownHoleCount].HolePos[3].x = 32767;
	m_ptData[m_nDownHoleCount].HolePos[3].y = 32767;
	m_ptData[m_nDownHoleCount].nUseAngle = 0;
	m_ptData[m_nDownHoleCount].fSine = 0;
	m_ptData[m_nDownHoleCount].fCosine = 1;

	
	m_pBackUpData[m_nBackupCount].nToolNum = nTCode;
	m_pBackUpData[m_nBackupCount].HolePos[0].x = usMasterX;
	m_pBackUpData[m_nBackupCount].HolePos[0].y = usMasterY;
	m_pBackUpData[m_nBackupCount].HolePos[1].x = usSlaveX;
	m_pBackUpData[m_nBackupCount].HolePos[1].y = usSlaveY;
	m_pBackUpData[m_nBackupCount].HolePos[2].x = 32767;
	m_pBackUpData[m_nBackupCount].HolePos[2].y = 32767;
	m_pBackUpData[m_nBackupCount].HolePos[3].x = 32767;
	m_pBackUpData[m_nBackupCount].HolePos[3].y = 32767;
	m_pBackUpData[m_nBackupCount].nUseAngle = 0;
	m_pBackUpData[m_nBackupCount].fSine = 0;
	m_pBackUpData[m_nBackupCount++].fCosine = 1;

	m_nHoleCnt[nTCode]++;
	
	m_nDownHoleCount++;

	TDrillPara Para;
//	TDrillHoleData HoleData100[100];
	BOOL bResult;
	int nRetry = 0;
	int nOnceDownCount = gSystemINI.m_sSystemDevice.nEocardDownCount;
	if(gSystemINI.m_sSystemDevice.bCheckHoleData)
		nOnceDownCount = 100;

	if(m_nDownHoleCount == nOnceDownCount) // 100�� ������ downloading
	{
		if(gSystemINI.m_sSystemDevice.bCheckHoleData)
		{
			bResult = m_pDriver->Drill_GetPara(&Para);
			if(!bResult)
				return FALSE;
		}
		m_nDownHoleCount = 0;
		bResult = m_pDriver->Drill_AddHoleData(nOnceDownCount, m_ptData);
		
//		if(!gSystemINI.m_sSystemDevice.bCheckHoleData)
			return bResult;

/*		if(!bResult)
			return FALSE;
		while(nRetry <= 3)
		{
			bResult = m_pDriver->Drill_GetPara(&Para2);
			if(bResult)
			{
				if((int)(Para2.nHoleCount - Para.nHoleCount) == nOnceDownCount)
					break;
			}
			::Sleep(1);
			nRetry++;
		}
		if(nRetry > 3)
			return FALSE;

		bResult = m_pDriver->Drill_CheckHoleData100(HoleData100);
		if(!bResult)
			return FALSE;
		return IsSameHoleData(HoleData100, nOnceDownCount);
*/	}
	else
		return TRUE;

	return TRUE;
}

BOOL HEocard5Pusan1::ShotDataReset()
{
	if(!m_pDriver)
		return TRUE;

	m_nDownHoleCount = 0;
	m_nBackupCount = 0;
	memset(m_nHoleCnt, 0, sizeof(int)*31);

	BOOL bVal = m_pDriver->Drill_ResetFiredCount();
	return bVal & m_pDriver->Drill_ResetHole();
}

BOOL HEocard5Pusan1::SetRunMode(BOOL b4Beam, int nSP, int nApertureMode, int nBurstShotNo, int nDownmode)
{
	if(!m_pDriver)
		return TRUE;

	if(DSP_ONLY == nDownmode || DSP_CONST_ONLY == nDownmode)
		return TRUE;

	if(nDownmode == DSP_ONLY)
	{
//		m_TDrillParam.b4Beam = m_b4Beam;
		m_TDrillParam.eDrillMode = (EDrillMode)m_nApertureMode;
		m_TDrillParam.nDotBatch_inPtn = m_nBurstShotNo;
	}

	if(nDownmode == DSP_CONST_ONLY)
	{
//		m_TDrillParam.b4Beam = m_b4Beam;
		m_TDrillParam.eDrillMode = (EDrillMode)m_nApertureMode;
		m_TDrillParam.nDotBatch_inPtn = m_nBurstShotNo;
	}
	else if(nDownmode == ALL_DOWN)
	{
//		m_TDrillParam.b4Beam = b4Beam;
		m_TDrillParam.eDrillMode = (EDrillMode)nApertureMode;
		m_TDrillParam.nDotBatch_inPtn = nBurstShotNo;

		m_b4Beam		= b4Beam;
		m_nApertureMode = nApertureMode;
		m_nBurstShotNo	= nBurstShotNo;
	}
	else
	{
//		m_TDrillParam.b4Beam = b4Beam;
		m_TDrillParam.eDrillMode = (EDrillMode)nApertureMode;
		m_TDrillParam.nDotBatch_inPtn = nBurstShotNo;

		m_b4Beam		= b4Beam;
		m_nApertureMode = nApertureMode;
		m_nBurstShotNo	= nBurstShotNo;
	}

//	m_TDrillParam.b4Beam = b4Beam;
//	m_TDrillParam.eDrillMode = (EDrillMode)nApertureMode;
//	m_TDrillParam.nDotBatch_inPtn = nBurstShotNo;
	
	return m_pDriver->Drill_SetParaAll(&m_TDrillParam);
}

BOOL HEocard5Pusan1::DownloadTcode(TCODE_INFO *pToolInfo) // no used
{
	return TRUE;
/*	TDrillToolInfo	ToolConfig;

	pToolInfo->dDuty

	ToolConfig.nFreq = pToolInfo->nFreq;
	ToolConfig.nDuty[MAX_SHOTCNT];	// 1.5% --> 150 (100��)
	ToolConfig.nAOMDelay;	// 1 --> 0.05us
	ToolConfig.nAOMDuty;	// 1 --> 0.05us
	ToolConfig.nShotCnt;	// �� Pattern�� ��� shot�ؾ��ϴ°�? �Ǵ� �̹��� ��� Shot�ؾ��ϴ°�(MCCMD�ؼ��ҋ� CListItem�� ��Ҥ��� ���)
	ToolConfig.nBurstShot;		
	ToolConfig.bUsePtn;
	ToolConfig.nIndex;
*/
}

void HEocard5Pusan1::EStop()
{
	if(!m_pDriver)
		return;


	m_pDriver->Emergency_Cmd(Emergency_Stop);

}

BOOL HEocard5Pusan1::FieldStart(BOOL bDryRun)
{
	if(!m_pDriver)
		return TRUE;

	return m_pDriver->Drill_Start(bDryRun);
}

int HEocard5Pusan1::ReadHoleCount()
{
	if(!m_pDriver)
		return 0;

	TDrillPara Para;
	if(!m_pDriver->Drill_GetPara(&Para))
	{
		::Sleep(10);
		if(!m_pDriver->Drill_GetPara(&Para))
			return -1; // false
	}

	return Para.nHoleCount;
}

void HEocard5Pusan1::DrillMove(BOOL bMark, int x, int y, BOOL bM1ApplyCal,
								 int xS, int yS, BOOL bS1ApplyCal,
								 int x_2, int y_2, BOOL bM2ApplyCal,
								 int xS_2, int yS_2, BOOL bS2ApplyCal, BOOL bWaitEnd)
{
	return;

	if(!m_pDriver)
		return;

	if(bM1ApplyCal)
		GetApplyCalPos(x, y, MASTER_1);

	if(bS1ApplyCal)
		GetApplyCalPos(xS, yS, SLAVE_1);

	if(bM2ApplyCal)
		GetApplyCalPos(x_2, y_2, MASTER_2);

	if(bS2ApplyCal)
		GetApplyCalPos(xS_2, yS_2, SLAVE_2);

//	m_pDriver->Cal_SetEnableEach(0, FALSE);
//	m_pDriver->Cal_SetEnableEach(1, FALSE);

	TArrayPos3D pt3D;
	pt3D.Pos[0].x = x;
	pt3D.Pos[0].y = y;
	pt3D.Pos[1].x = xS;
	pt3D.Pos[1].y = yS;
	pt3D.Pos[2].x = x_2;
	pt3D.Pos[2].y = y_2;
	pt3D.Pos[3].x = xS_2;
	pt3D.Pos[3].y = yS_2;


	if(!bMark)
		m_pDriver->ScanCtrl_aJump4B(&pt3D);
	else
		m_pDriver->ScanCtrl_aDraw4B(&pt3D);

//	m_pDriver->ScanImm_aJump(&pt3D, 4); // 100825

	StatusOK(IDLE);

//	m_pDriver->Cal_SetEnableEach(0, TRUE);
//	m_pDriver->Cal_SetEnableEach(1, TRUE);
}

void HEocard5Pusan1::DrillMoveDump(BOOL bMark, int x, int y, BOOL bMaster, BOOL bWaitEnd)
{
	return;

	if(!m_pDriver)
		return;

	int x1, y1, x2, y2;
	x1 = x2 = x;
	y1 = y2 = y;
	if(bMaster)
	{
		GetApplyCalPos(x1, y1, MASTER_1);
		GetApplyCalPos(x2, y2, MASTER_2); 
	}
	else
	{
		GetApplyCalPos(x1, y1, SLAVE_1);
		GetApplyCalPos(x2, y2, SLAVE_2); 
	}

//	m_pDriver->Cal_SetEnableEach(0, FALSE);
//	m_pDriver->Cal_SetEnableEach(1, FALSE);

	TArrayPos3D pt3D;
	pt3D.Pos[0].x = x1;
	pt3D.Pos[0].y = y1;
	pt3D.Pos[1].x = x2;
	pt3D.Pos[1].y = y2;
	pt3D.Pos[2].x = x1;
	pt3D.Pos[2].y = y1;
	pt3D.Pos[3].x = x2;
	pt3D.Pos[3].y = y2;


	m_pDriver->ScanCtrl_aJump4B(&pt3D);

//	m_pDriver->ScanImm_aJump(&pt3D, 4); // 100825

//	DrillMove(bMark, x1, y1, x2, y2, bMaster, bWaitEnd); ?????

	StatusOK(IDLE);
	
//	m_pDriver->Cal_SetEnableEach(0, TRUE);
//	m_pDriver->Cal_SetEnableEach(1, TRUE);

}

void HEocard5Pusan1::GetApplyCalPos(int &nX, int &nY, int nScannerNo)
{
	int nRefX, nRefY, nDiffX, nDiffY;
	BOOL bXChange = FALSE, bYChange = FALSE;
	nRefX = nDiffX = nX;
	nRefY = nDiffY = nY;

	if(nX < 0)
	{
		nRefX = 0;
		nDiffX = nRefX - nX;
		bXChange = TRUE;
	}
	if(nX > FIELD_LSB)
	{
		nRefX = FIELD_LSB;
		nDiffX = FIELD_LSB + nRefX - nX;
		bXChange = TRUE;
	}

	if(nY < 0)
	{
		nRefY = 0;
		nDiffY = nRefY - nY;
		bYChange = TRUE;
	}
	if(nY > FIELD_LSB)
	{
		nRefY = FIELD_LSB;
		nDiffY = FIELD_LSB + nRefY - nY;
		bYChange = TRUE;
	}

	if(bXChange || bYChange) // 0 ~ 65535 ����� ��� (��迡���� aperture �����Ҷ� �߻�, �ַ� ��ĳ�� ����������)
	{
		GetASCPos(nRefX, nRefY, nScannerNo);
		GetASCPos(nDiffX, nDiffY, nScannerNo);

		if(bXChange)
			nX = nRefX + nRefX - nDiffX;
		else
			nX = nRefX;
		if(bYChange)
			nY = nRefY + nRefY - nDiffY;
		else
			nY = nRefY;
	}
	else
	{
		GetASCPos(nX, nY, nScannerNo);
	}
}

void HEocard5Pusan1::GetASCPos(int &nX, int &nY, int nScannerNo)
{
	DOUBLE_POINT* pOffsetData;
	unsigned int i, j;
	int n_x, n_y;
	int a0, a1, a2, b0, b1, b2, c0;

	if(nScannerNo == MASTER_1) pOffsetData = m_pM1Asc;
	else if(nScannerNo == MASTER_2) pOffsetData = m_pM2Asc;
	else if(nScannerNo == SLAVE_1) pOffsetData = m_pS1Asc;
	else pOffsetData = m_pS2Asc;

	i = ((unsigned int)nX >> 10);	// ������ 1024�� ��
	j = ((unsigned int)nY >> 10);	// ������ 1024�� ��
	
	n_x = nX - (i<<10);				// ������ 1024�� ������
	n_y = nY - (j<<10);				// ������ 1024�� ������
	
	a0 = (int)(pOffsetData[i * ASC_AXIS_SIZE + j].dX);
	a1 = (int)(pOffsetData[(i + 1) * ASC_AXIS_SIZE + j].dX);
	b0 = (int)(pOffsetData[i * ASC_AXIS_SIZE + j + 1].dX);        
	b1 = (int)(pOffsetData[(i + 1) * ASC_AXIS_SIZE + j + 1].dX);
	
	a2 = a0 + ((n_x*(a1-a0))>>10);    
	b2 = b0 + ((n_x*(b1-b0))>>10);
	c0 = a2 + ((n_y*(b2-a2))>>10);
	
	c0 += nX;					// ������ ���ϱ� (unsigned�̸� �Ʒ� �񱳿� ������ ���� �� �����Ƿ� �ѹ� ��ģ �� ���� ���� Ȯ��.
	nX = ROUND_0_FFFF(c0);		// ���Ѱ� ó��
	
	a0 = (int)(pOffsetData[i * ASC_AXIS_SIZE + j].dY);
	a1 = (int)(pOffsetData[(i + 1) * ASC_AXIS_SIZE + j].dY);
	b0 = (int)(pOffsetData[i * ASC_AXIS_SIZE + j + 1].dY);        
	b1 = (int)(pOffsetData[(i + 1) * ASC_AXIS_SIZE + j + 1].dY);
	
	a2 = a0 + ((n_x*(a1-a0))>>10);    
	b2 = b0 + ((n_x*(b1-b0))>>10);
	c0 = a2 + ((n_y*(b2-a2))>>10);
	
	c0 += nY;					// ������ ���ϱ� (unsigned�̸� �Ʒ� �񱳿� ������ ���� �� �����Ƿ� �ѹ� ��ģ �� ���� ���� Ȯ��.
	nY = ROUND_0_FFFF(c0);		// ���Ѱ� ó��
}

BOOL HEocard5Pusan1::LoadCalibrationFile(char *strM1path, char *strS1path, char *strM2path, char *strS2path)
{
	DOUBLE_POINT* pOffsetData;
	if(!m_pDriver)
		return TRUE;
	ts32 cal_data_x[MAX_PACKET_CALDATA_SIZE][MAX_PACKET_CALDATA_SIZE];		//���� �������� ��Ŷ ������ 33*33
	ts32 cal_data_y[MAX_PACKET_CALDATA_SIZE][MAX_PACKET_CALDATA_SIZE];

	int k, i, j;
	float data;
	char buf[256];	
	FILE* fp;
	errno_t err;
	fp = NULL;
	for(int kk = 0; kk < 4; kk++)
	{
		if(kk == MASTER_1) 
		{
			pOffsetData = m_pM1Asc;
			if(strM1path == NULL)
				continue;
			err = fopen_s(&fp, strM1path,_T("r"));	
		}
		else if(kk == MASTER_2) 
		{
			pOffsetData = m_pM2Asc;
			if(strM2path == NULL)
				continue;
			err = fopen_s(&fp, strM2path,_T("rt"));
		}
		else if(kk == SLAVE_1) 
		{
			pOffsetData = m_pS1Asc;
			if(strS1path == NULL)
				continue;
			err = fopen_s(&fp, strS1path,_T("rt"));
		}
		else 
		{
			pOffsetData = m_pS2Asc;
			if(strS2path == NULL)
				continue;
			err = fopen_s(&fp, strS2path,_T("rt"));
		}

		if(NULL != err)
			return FALSE;
		
		fgets(buf, sizeof(buf), fp);	
		for (k=0; k < 2; k++) 
		{
			for  (j=0; j<65; j++) 
			{
				for (i=0; i<65; i++)   
				{
					switch(k) {
					case  0:
						fscanf(fp, _T("%f"), &data);
						cal_data_y[i][j]  = (int)data;
						pOffsetData[i * ASC_AXIS_SIZE + j].dY  = data;
						break;
					case  1:
						fscanf(fp, _T("%f"), &data);
						cal_data_x[i][j]  = (int)data;
						pOffsetData[i * ASC_AXIS_SIZE + j].dX  = data;
						break;
					default:  break;
					}
				}//  for (i)
			}//  for (j)
		} //  for (k)	
		fclose(fp);
		
		if(!m_pDriver->Cal_LoadData(kk, 0, &cal_data_x[0][0]))		//x�� ���� ������
			return FALSE;
		if(!m_pDriver->Cal_LoadData(kk, 1, &cal_data_y[0][0]))		//y�� ���� ������
			return FALSE;
	}
	return TRUE;
}

void HEocard5Pusan1::CO2LaserEnable(BOOL bEnable)
{
	if(bEnable)
		m_cCO2Laser = m_cCO2Laser & 0xFA;
	else
		m_cCO2Laser = m_cCO2Laser | 0x05;

	SetFunction(m_cCO2Laser);
	return;
}

BOOL HEocard5Pusan1::CO2LaserMainShutter(BOOL bOn)
{
	if(bOn)
		m_cCO2Laser = m_cCO2Laser & 0xFD;
	else
		m_cCO2Laser = m_cCO2Laser | 0x02;

	SetFunction(m_cCO2Laser);
	return TRUE;
}

BOOL HEocard5Pusan1::GetParameter(FParameter *pParam)
{
	pParam->DrawStep		= m_Parameter.DrawStep;
	pParam->JumpStep		= m_Parameter.JumpStep;
	pParam->StepPeriod		= m_Parameter.StepPeriod;
	pParam->CornerDelay		= m_Parameter.CornerDelay;
	pParam->JumpDelay		= m_Parameter.JumpDelay;
	pParam->LineDelay		= m_Parameter.LineDelay;
	pParam->LaserOnDelay	= m_Parameter.LaserOnDelay;
	pParam->LaserOffDelay	= m_Parameter.LaserOffDelay;
	pParam->FPSDelay		= m_Parameter.FPSDelay;
	pParam->dDuty			= m_Parameter.dDuty;
	pParam->Frequency		= m_Parameter.Frequency;
	pParam->DrawStepPeriod	= m_Parameter.DrawStepPeriod;
	pParam->dAOMDelay		= m_Parameter.dAOMDelay;
	pParam->dAOMDuty		= m_Parameter.dAOMDuty;
	memcpy(pParam->cAOMFilePath, m_Parameter.cAOMFilePath, 255);

	return TRUE;
}

BOOL HEocard5Pusan1::Create()
{
	if(!m_pDriver)
		return TRUE;
//	if(gSystemINI.m_sSystemDevice.nSelfLineDivide) ????????????????
//	m_TDrillParam.eDrillMode = (EDrillMode)STEP_DIVIDE_MODE;
	return TRUE;
}

BOOL HEocard5Pusan1::DownloadTCode(unsigned int nToolNo, unsigned int nFreq, unsigned int nBurstShot, unsigned int nTotalShot, BOOL bUseAperture)
{
	if(!m_pDriver)
		return TRUE;
//	m_ToolConfig[nToolNo].nFreq = nFreq;
//	m_ToolConfig[nToolNo].nBurstShot = nBurstShot;
//	m_ToolConfig[nToolNo].nShotCnt = nTotalShot;
//	m_ToolConfig[nToolNo].bUsePtn = bUseAperture;
	#ifndef __NEW_STRUCTURE__
		if(!bUseAperture)
		{
			m_ToolConfig[nToolNo].nNumUsedPtn = 1;
			m_ToolConfig[nToolNo].nUsedPtnId[0] = 0;
		}
		else
		{
			m_ToolConfig[nToolNo].nNumUsedPtn = 1;
			m_ToolConfig[nToolNo].nUsedPtnId[0] = nToolNo;
		}

		m_PtnInfo[nToolNo].PtnConfig.nFreq = nFreq;
		m_PtnInfo[nToolNo].PtnConfig.nDotBurstShotCnt = nBurstShot;
		m_PtnInfo[nToolNo].PtnConfig.nDotTotalShotCnt = nTotalShot;
		m_PtnInfo[nToolNo].PtnConfig.bUsePtn = bUseAperture;

		return m_pDriver->Drill_SetPtnConfig(nToolNo, &m_PtnInfo[nToolNo].PtnConfig);
	#else
		return TRUE;
	#endif
	
//	return m_pDriver->Drill_SetToolConfig(nToolNo, &m_ToolConfig[nToolNo]);
}

BOOL HEocard5Pusan1::DownloadDutyAOM(unsigned int nToolNo, unsigned int nShotIndex, double dDuty, double dAOMDelay, double dAOMDuty)
{
	
	if(!m_pDriver)
		return TRUE;
	
	#ifndef __NEW_STRUCTURE__
	BOOL bReturnVal;
		if(dDuty / (10000. / m_PtnInfo[nToolNo].PtnConfig.nFreq) >= 100 || dDuty <= 0)
		{
			::AfxMessageBox(_T("Error : Laser Duty  <= 0. Check Duty and Offset."));
			return FALSE;
		}

		m_PtnInfo[nToolNo].PtnConfig.fDuty_us[nShotIndex] = dDuty;			// us
		m_PtnInfo[nToolNo].PtnConfig.nAomInfoId[nShotIndex] = nToolNo * 15 + nShotIndex;
	//	m_PtnInfo[nToolNo].PtnConfig.fAOMDelay[nShotIndex] = dAOMDelay; // us
	//	m_PtnInfo[nToolNo].PtnConfig.fAOMDuty_us[nShotIndex] = dAOMDuty;	// us
		if(nToolNo == DUMMY_TOOL)
			m_PtnInfo[nToolNo].PtnConfig.nMinShotTime[nShotIndex] = 0; // 20101217 ����
		else
			m_PtnInfo[nToolNo].PtnConfig.nMinShotTime[nShotIndex] = gSystemINI.m_sSystemDevice.nMinShotTime;
		bReturnVal = m_pDriver->Drill_SetPtnConfig(nToolNo, &m_PtnInfo[nToolNo].PtnConfig);
		return bReturnVal;
	#else
			return TRUE;
	#endif
}

void HEocard5Pusan1::jump(int x, int y, int xS, int yS, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return;
	
	TArrayPos3D posdata;
	posdata.Pos[0].x = x;
	posdata.Pos[0].y = y;
	posdata.Pos[1].x = x;
	posdata.Pos[1].y = y;
	posdata.Pos[2].x = x;
	posdata.Pos[2].y = y;
	posdata.Pos[3].x = x;
	posdata.Pos[3].y = y;
	

	m_pDriver->ScanCtrl_aJump4B(&posdata); // 100825

	if(bWaitEnd)
		StatusOK(IDLE);
}

void HEocard5Pusan1::mark(int x, int y, int xS, int yS, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return;
	
	TArrayPos3D posdata;
	posdata.Pos[0].x = x;
	posdata.Pos[0].y = y;
	posdata.Pos[1].x = x;
	posdata.Pos[1].y = y;
	posdata.Pos[2].x = x;
	posdata.Pos[2].y = y;
	posdata.Pos[3].x = x;
	posdata.Pos[3].y = y;

	m_pDriver->ScanCtrl_aDraw4B(&posdata);

}

BOOL HEocard5Pusan1::IsDSPBusy()
{
	if(!m_pDriver) 
		return TRUE;

	TRunStatus dData;

	m_pDriver->List_GetRunStatus(&dData);
	return dData.bit.Busy;
}
BOOL HEocard5Pusan1::ResetScannerStatusErrorCount()
{
	if(!m_pDriver) 
		return TRUE;

	#ifdef __KUNSAN_6__
		return TRUE;
	#else
		#ifndef __NEW_STRUCTURE__
			return m_pDriver->Error_Reset_ScanErrorCnt();
		#else
			return m_pDriver->Error_Reset_ScanErrorStatusCount();
		#endif
	#endif

	return TRUE;

	
}
BOOL HEocard5Pusan1::IsDrillTimeOut()
{
	if(!m_pDriver) 
		return TRUE;
	
//	TRunStatus dData;
	
//	m_pDriver->List_GetRunStatus(&dData);
//	return dData.bit.TimeOut;
	TErrorStatus dError;
	m_pDriver->Error_GetErrorStatus(&dError);
	int nErrorBit = 0;
	if(dError.TimeOutCnt[0] > 0)//�迭�� index �� 0 = Master X, 1 = Master Y, 2 = Slave X, 3 = Slave Y   --> return ���� Bit ������ �Ѱ��ٰ���
	{
		nErrorBit = nErrorBit | 0x1;
	}
	if(dError.TimeOutCnt[1] > 0)
	{
		nErrorBit = nErrorBit | 0x2;
	}
	if(dError.TimeOutCnt[2] > 0)
	{
		nErrorBit = nErrorBit | 0x4;
	}
	if(dError.TimeOutCnt[3] > 0)
	{
		nErrorBit = nErrorBit | 0x8;
	}
	return nErrorBit;
}

BOOL HEocard5Pusan1::IsMotorFault()
{
	if(!m_pDriver) 
		return TRUE;
	
	//	return 0;
//	TRunStatus dData;
	
//	m_pDriver->List_GetRunStatus(&dData);
//	return dData.bit.MotorFault;
	TErrorStatus dError;
	m_pDriver->Error_GetErrorStatus(&dError);
	int nErrorBit = 0;
	if(dError.MotorFaultCnt[0] > 0)//�迭�� index �� 0 = Master X, 1 = Master Y, 2 = Slave X, 3 = Slave Y   --> return ���� Bit ������ �Ѱ��ٰ���
	{
		nErrorBit = nErrorBit | 0x1;
	}
	if(dError.MotorFaultCnt[1] > 0)
	{
		nErrorBit = nErrorBit | 0x2;
	}
	if(dError.MotorFaultCnt[2] > 0)
	{
		nErrorBit = nErrorBit | 0x4;
	}
	if(dError.MotorFaultCnt[3] > 0)
	{
		nErrorBit = nErrorBit | 0x8;
	}
	return nErrorBit;
}
BOOL HEocard5Pusan1::IsScannerCableError()
{
	if(!m_pDriver) 
		return TRUE;


	TErrorStatus dError;
	m_pDriver->Error_GetErrorStatus(&dError);
	return dError.nGsbStsSigErrCnt;


}
void HEocard5Pusan1::MakeInpositionTable()
{
	if(!m_pDriver) 
		return;

	//	return 0;

#ifndef __PUSAN_LDD__
	TRunStatus dData;
	m_pDriver->List_GetRunStatus(&dData);
	if(dData.bit.GsbStsSigErr || dData.bit.MotorFault || dData.bit.TimeOut)
	{
		EStop();
		BOOL bBusy = TRUE;
		while(bBusy)
		{
			bBusy = IsDSPBusy();
		}
	}
	Sleep(1);
	m_pDriver->List_GetRunStatus(&dData);
	if(dData.bit.GsbStsSigErr || dData.bit.MotorFault)
	{	// ���� gsb status signal error, motor fault ���� �߻��� �����޼��� �߻�
		::AfxMessageBox(_T("Check the Scanner & Scanner Power & Scanner Cable!"), MB_OK);
		return;
	}
	unsigned int nEnbleCal[MAX_NUMBER_OF_BEAM] = {0,0,0,0 };
	m_pDriver->Cal_SetEnableAll(nEnbleCal);

	for( unsigned int kk=0; kk<MAX_NUMBER_OF_BEAM; kk++ )
	{
		m_pDriver->ScanCfg_SetAxis(kk, FALSE,FALSE,FALSE);
	}
	/////////////////////////////////////////////////////////////////
	Sleep(100);

	m_pDriver->Drill_MakeInposTimeTable();
	Sleep(100);
	BOOL bBusy = TRUE;

	while(bBusy)
	{
		bBusy = IsDSPBusy();
	}

	// ����� calibration���ð� axis reverse������ �����Ѵ�.
	m_pDriver->Cal_SetEnableEach(0, TRUE);
	m_pDriver->Cal_SetEnableEach(1, TRUE);
	BOOL bXReverse, bYReverse, bAxisCange = FALSE;

	if(gSystemINI.m_sHardWare.nScannerAxisType == PX_PY)
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_PY)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PX_NY)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_NY)
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_PX) // ------------------------------------
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NY_PX)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_NX)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else 
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
	//	m_pDriver->ScanCtrl_SetAxis(0, bXReverse, bYReverse, 0, TRUE);
	m_pDriver->ScanCfg_SetAxis(0, bXReverse, bYReverse, 0, TRUE); // 100825

	//---------------------------------------------------------
	if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_PY)
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NX_PY)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_NY)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NX_NY)
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PY_PX) // ------------------------------------
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NY_PX)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PY_NX)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else 
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
	//	m_pDriver->ScanCtrl_SetAxis(1, bXReverse, bYReverse, 0, TRUE);
	m_pDriver->ScanCfg_SetAxis(1, bXReverse, bYReverse, 0, TRUE); // 100825
	////////////////////////////////////////////////////////////////////////////////////////////////////
	Sleep(500);
	SaveInposTimeTable();
	::AfxMessageBox("Complete to Make InpositionTable!!", MB_OK);
#endif
}

void HEocard5Pusan1::SaveInposTimeTable()
{
	if(!m_pDriver) 
		return;

	unsigned int time_X[MAX_DRILL_INPOSTIME_DATA+1];
	unsigned int time_Y[MAX_DRILL_INPOSTIME_DATA+1];
	m_pDriver->Drill_GetInposTimeTable(&time_X[0], &time_Y[0]);

	time_t timer = time(NULL);
	struct tm *pTime = localtime(&timer);

	char szPath[30];
	sprintf(szPath,"D:\\ETS5_Log");
	CreateDirectory(szPath,NULL);

	char szfilename[100];

	sprintf(szfilename,"%s\\InposTimeTable_%4d%02d%02d%02d%02d%02d.txt",szPath,pTime->tm_year+1900,pTime->tm_mon+1,pTime->tm_mday,pTime->tm_hour, pTime->tm_min, pTime->tm_sec);

	FILE* stream = fopen(szfilename, "a+t");	
	fseek(stream, 0L, SEEK_SET);

	fprintf(stream, "Position,	X,		Y\n"); 
	double fdistance = gSystemINI.m_sSystemDevice.dFieldSize.x/512.0;
	for(int i=0; i<MAX_DRILL_INPOSTIME_DATA; i++)
	{
		double fdistance_vm; 
		fdistance_vm = fdistance*i;
		fprintf(stream, "%d,		%d,		%d\n", (int)fdistance_vm, time_X[i], time_Y[i]); 
	}
	fclose(stream);

}

void HEocard5Pusan1::GetDumperPosition(USHORT &usDumpMX, USHORT &usDumpMY, USHORT &usDumpSX, USHORT &usDumpSY)
{
	usDumpMX = 65535;
	usDumpMY = 32767;
	usDumpSX = 65535;
	usDumpSY = 32767;
}

BOOL HEocard5Pusan1::LaserOnOff(BOOL bOn)
{
	if(!m_pDriver) 
		return TRUE;
	if(bOn)
		return m_pDriver->LaserCtrl_LaserOnOff(TRUE);
	else
		return m_pDriver->LaserCtrl_LaserOnOff(FALSE);
}

BOOL HEocard5Pusan1::jumpOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return FALSE;

	TArrayPos3D posdata;
	posdata.Pos[0].x = x;
	posdata.Pos[0].y = y;
	posdata.Pos[1].x = x;
	posdata.Pos[1].y = y;
	posdata.Pos[2].x = x;
	posdata.Pos[2].y = y;
	posdata.Pos[3].x = x;
	posdata.Pos[3].y = y;
	

	m_pDriver->ScanCtrl_aJump4B(&posdata); // 100825

	if(bWaitEnd)
		StatusOK(IDLE);

	return TRUE;
}

BOOL HEocard5Pusan1::markOne(int x, int y, BOOL bIsMaster, BOOL bWaitEnd)
{
	if(!m_pDriver) 
		return TRUE;

	TArrayPos3D posdata;
	posdata.Pos[0].x = x;
	posdata.Pos[0].y = y;
	posdata.Pos[1].x = x;
	posdata.Pos[1].y = y;
	posdata.Pos[2].x = x;
	posdata.Pos[2].y = y;
	posdata.Pos[3].x = x;
	posdata.Pos[3].y = y;

	m_pDriver->ScanCtrl_aDraw4B(&posdata);

	if(bWaitEnd)
		StatusOK(IDLE);

	return TRUE;
}

void HEocard5Pusan1::MoveToCenter()
{
//	jump(HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB);
}

BOOL HEocard5Pusan1::ResetSubToolForAllTool()
{
#ifndef __NEW_STRUCTURE__
	for(int i = 0; i < 31 ; i++)
	{
		m_ToolConfig[i].nNumUsedPtn = 1;
		m_ToolConfig[i].nUsedPtnId[0] = 0;
		m_PtnInfo[i].PtnConfig.nFreq = 1000;
		m_PtnInfo[i].PtnConfig.nDotBurstShotCnt = 0;
		m_PtnInfo[i].PtnConfig.nDotTotalShotCnt = 0;
		m_PtnInfo[i].PtnConfig.bUsePtn = 0;
	}
#endif
	return TRUE;
}

BOOL HEocard5Pusan1::DownloadOneSubTool(int nTool, SUBTOOLDATA subTool,  BOOL bSetPowerLevel,  BOOL bMakeLPCTable)
{
//	if(!m_pDriver) 
//		return TRUE;


	BOOL bResult;
	FParameter Para;
	GetParameter(&Para);
//	BOOL bTophat = subTool.bUseTophat;

	m_nToolOldNo = nTool;
	memcpy(&m_subToolOld, &subTool, sizeof(SUBTOOLDATA));

	double dMaskDutyOffset; 
	double dMaskAOMDelayOffset;
	double dMaskAOMDutyOffset;
	double dPowerDutyOffset;
//	if(!bTophat)
//	{
		dMaskDutyOffset = gBeamPathINI.m_sBeampath.dPowOffsetDuty[subTool.nMask];
		dMaskAOMDelayOffset = gBeamPathINI.m_sBeampath.dPowOffsetAomDelay[subTool.nMask];
		dMaskAOMDutyOffset = gBeamPathINI.m_sBeampath.dPowOffsetAomDuty[subTool.nMask];
		dPowerDutyOffset = gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[subTool.nMask];
	double dVoltage1 = gBeamPathINI.m_sBeampath.dBeamPathVoltage1[subTool.nMask];
	double dVoltage2 = gBeamPathINI.m_sBeampath.dBeamPathVoltage2[subTool.nMask];
/*	}
	else
	{
		dMaskDutyOffset = gSystemINI.m_sSystemTophat.nDutyOffset[subTool.nMask]/100.;
		dMaskAOMDelayOffset = gSystemINI.m_sSystemTophat.nAOMDelayOffset[subTool.nMask]/100.;
		dMaskAOMDutyOffset = gSystemINI.m_sSystemTophat.nAOMDutyOffset[subTool.nMask]/100.;
		dPowerDutyOffset = gSystemINI.m_sSystemTophat.dPowerDuty[subTool.nMask];
	}
*/	if(subTool.nToolType == MARKING_TYPE)
	{
		Para.DrawStep = (int)subTool.dDrawStep;
		Para.JumpStep = subTool.nJumpStep;
		Para.DrawStepPeriod = subTool.nDrawStepPeriod; // Mark default
		Para.StepPeriod = subTool.nJumpStepPeriod;
		Para.CornerDelay = subTool.nCornerDelay;
		Para.JumpDelay = subTool.nJumpDelay;
		Para.LineDelay = subTool.nLineDelay;
		Para.LaserOnDelay = subTool.nLaserOnDelay;
		Para.LaserOffDelay = subTool.nLaserOffDelay;
		Para.Frequency = subTool.nFrequency;
		Para.dAOMDelay = subTool.dShotAOMDelay[0] + dMaskAOMDelayOffset;
		Para.dAOMDuty = subTool.dShotAOMDuty[0] + dMaskAOMDutyOffset + dPowerDutyOffset;
		memcpy(Para.cAOMFilePath, subTool.cAOMFilePath[0], 255);
		if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			if(Para.Frequency < 15000 || Para.Frequency > 100000)
				Para.Frequency = 15000;
		}
		if(gSystemINI.m_sHardWare.nLaserType == LASER_UV ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
			Para.dDuty = 5000; // 50%  : UV�� duty ��� ����.
		else
			Para.dDuty = subTool.dShotDuty[0] * 100 + dMaskDutyOffset * 100 + (dPowerDutyOffset * 100.0); // unit 0.01% (0 index ���)
		Para.FPSDelay = subTool.nFPS;
		bResult = SetRunMode(FALSE, Para.DrawStepPeriod, 2 /* line mode */, 1 /* not use */, EXCEPT_DSP); // marker use only DSP.
		if(bResult) bResult = bResult & SetParameter(&Para, dMaskAOMDutyOffset + dPowerDutyOffset, subTool.nMask);
		if(bResult) bResult = bResult & SetInpositionCheckINI(FALSE);
	
		return bResult;
	}
	else if(subTool.nToolType == SHOT_DRILL_TYPE)
	{
		// Para.DrawStep = subTool.nDrawStep; // ���� ������� ���� : �Ŀ� aperture �Ѱ������� Ǯ�����.
		Para.JumpStep = subTool.nJumpStep;
		Para.DrawStepPeriod = subTool.nDrawStepPeriod; 
		Para.StepPeriod = subTool.nJumpStepPeriod;
		// Para.CornerDelay = subTool.nCornerDelay; // ���� ������� ���� : �Ŀ� aperture �Ѱ������� Ǯ�����.
		Para.JumpDelay = subTool.nJumpDelay;
		// Para.LineDelay = subTool.nLineDelay;
		Para.LaserOnDelay = subTool.nLaserOnDelay;
		Para.LaserOffDelay = Para.LaserOnDelay; 
		Para.Frequency = subTool.nFrequency;
		Para.dAOMDelay = subTool.dShotAOMDelay[0];
		Para.dAOMDuty = subTool.dShotAOMDuty[0] + dPowerDutyOffset;
		memcpy(Para.cAOMFilePath, subTool.cAOMFilePath[0], 255);
		if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			if(Para.Frequency < 15000 || Para.Frequency > 100000)
				Para.Frequency = 15000;
		}
		Para.FPSDelay = subTool.nFPS;
		Para.MinShotTime = gSystemINI.m_sSystemDevice.nMinShotTime;
		Para.CycleTime = gSystemINI.m_sSystemDevice.nMinCycleTime;
		if(gSystemINI.m_sSystemDevice.nShotDrillType == SHOT_DRILL_ORIGIN)
			bResult = SetRunMode(FALSE, Para.DrawStepPeriod, STEP_ORIGIN_MODE, subTool.nApertureBurst, EXCEPT_DSP); 
		else
			bResult = SetRunMode(FALSE, Para.DrawStepPeriod, STEP_DIVIDE_MODE, subTool.nApertureBurst, EXCEPT_DSP); 

		if(bResult) bResult = bResult & SetParameter(&Para, 0, subTool.nMask);
		if(bResult) bResult = bResult & SetMinShotTime(Para.MinShotTime);
		if(bResult) bResult = bResult & SetMinCycleTime(Para.CycleTime * 1000);
		if(bResult) bResult = bResult & DownloadTCode(nTool, Para.Frequency, 
														subTool.nBurstShot, 
														subTool.nTotalShot,
														subTool.bUseAperture );
		if(bResult) bResult = bResult & DownloadTCode(DUMMY_TOOL, gSystemINI.m_sSystemDump.nDummyFreq, 
														1, //subTool.nBurstShot, 
														1, //subTool.nTotalShot,
														FALSE);//subTool.bUseAperture );
		
		CString str;
		for(int i = 0; i < subTool.nTotalShot; i++)
		{
			if(gSystemINI.m_sHardWare.nLaserType == LASER_UV ||
				gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
			{
				if(bResult) bResult = bResult & DownloadDutyAOM(nTool, i, 50, 0, 0); // 50%  : UV�� duty ��� ����.
			}
			else
			{
				str.Format(_T("%s"), subTool.cAOMFilePath[i]);
				if(bResult) bResult = bResult & DownloadDutyAOM(nTool, i, subTool.dShotDuty[i] + dMaskDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[i] + subTool.dShotDutyOffsetS[i],  
																		  subTool.dShotAOMDelay[i] + dMaskAOMDelayOffset, 
																		  subTool.dShotAOMDuty[i] + dMaskAOMDutyOffset + dPowerDutyOffset + subTool.dShotDutyOffsetM[i] + subTool.dShotDutyOffsetS[i]);
				if(bResult) bResult = bResult & DownloadAOMProfile(nTool, i, str, subTool.dShotDuty[i] + dMaskDutyOffset + dPowerDutyOffset, 
																				  subTool.dShotAOMDelay[i] + dMaskAOMDelayOffset, 
																				  subTool.dShotAOMDuty[i] + dMaskAOMDutyOffset + dPowerDutyOffset, 
																				  dMaskAOMDutyOffset + dPowerDutyOffset, 
																				  subTool.dShotDutyOffsetM[i],
																				  subTool.dShotDutyOffsetS[i],
																				  subTool.dShotVolOffsetM[i] + dVoltage1,
																				  subTool.dShotVolOffsetS[i] + dVoltage2,
																				  subTool.nMask);

				if(bSetPowerLevel)
				{
					double dLPCVal, dLPCValFinal, dMinLPC, dMaxLPC;
					m_CalLPC->GetCalibrationOffset(m_dAOMOpenLastTime, subTool.dShotDuty[i], dLPCVal, dLPCValFinal);
					dMinLPC = dLPCVal * gSystemINI.m_sHardWare.dLPCMinTolerence;// + 2048;
					dMaxLPC = dLPCVal * gSystemINI.m_sHardWare.dLPCMaxTolerence;//dLPCVal * (2 - gSystemINI.m_sHardWare.dLPCTolerence);// + 2048;
					if(bResult) bResult = bResult & DownloadPowerLevel(nTool, i, dMinLPC, dMaxLPC);
				}
				else
				{
					if(bResult) bResult = bResult & DownloadPowerLevel(nTool, i, 0, 0);//gSystemINI.m_sHardWare.nLPCMinDefault, gSystemINI.m_sHardWare.nLPCMaxDefault);
				}

				if(bResult) bResult = bResult & DownloadDutyAOM(DUMMY_TOOL, i,			gSystemINI.m_sSystemDump.nDummyDuty, gSystemINI.m_sSystemDump.nDummyAOMDelay, gSystemINI.m_sSystemDump.nDummyAOMDuty);
				if(bResult) bResult = bResult & DownloadAOMProfile(DUMMY_TOOL, i, str,	gSystemINI.m_sSystemDump.nDummyDuty, gSystemINI.m_sSystemDump.nDummyAOMDelay, gSystemINI.m_sSystemDump.nDummyAOMDuty, 0, 0, 0, dVoltage1, dVoltage2, subTool.nMask);
			}
		}

		
		str.Format(_T("%s"), subTool.cFilePath);
		if(subTool.bUseAperture && str.GetLength() > 0)
		{
			if(bResult) bResult = bResult & DownloadOneAperture(str, nTool);
		}
//		str.Format(_T("%s"), subTool.cMoveProfileFilePath);
//		if(bResult) bResult = bResult & DownloadProfileFile(str);

		if(bResult) bResult = bResult & SetInpositionCheckINI(TRUE);
		
		return bResult;
	}
	else if(subTool.nToolType == LINE_DRILL_TYPE || subTool.nToolType == BARCODE_TYPE)
	{
		if(gSystemINI.m_sSystemDevice.nSelfLineDivide)
			Para.DrawStep = (int)subTool.dDrawStep; 
		else
			Para.DrawStep = 65535; // subTool.nDrawStep; // ���� ������� ���� : �Ŀ� aperture �Ѱ������� Ǯ�����.
		Para.JumpStep = subTool.nJumpStep;
		Para.DrawStepPeriod = subTool.nDrawStepPeriod; 
		Para.StepPeriod = subTool.nJumpStepPeriod;
		// Para.CornerDelay = subTool.nCornerDelay; // ���� ������� ���� : �Ŀ� aperture �Ѱ������� Ǯ�����.
		Para.JumpDelay = subTool.nJumpDelay;
		Para.LineDelay = subTool.nLineDelay;
		Para.LaserOnDelay = subTool.nLaserOnDelay;
		Para.LaserOffDelay = subTool.nLaserOffDelay;
		Para.Frequency = subTool.nFrequency;
		Para.dAOMDelay = subTool.dShotAOMDelay[0] + dMaskAOMDelayOffset;
		Para.dAOMDuty = subTool.dShotAOMDuty[0] + dMaskAOMDutyOffset + dPowerDutyOffset;
		memcpy(Para.cAOMFilePath, subTool.cAOMFilePath[0], 255);
		if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			if(Para.Frequency < 15000 || Para.Frequency > 100000)
				Para.Frequency = 15000;
		}
		if(gSystemINI.m_sHardWare.nLaserType == LASER_UV ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
			Para.dDuty = 5000; // 50%  : UV�� duty ��� ����.
		else
			Para.dDuty = subTool.dShotDuty[0] * 100 + dMaskDutyOffset * 100 + (dPowerDutyOffset * 100.0); // unit 0.01% (0 index ���)

		Para.FPSDelay = subTool.nFPS;
		bResult = SetRunMode(FALSE, Para.DrawStepPeriod, UV_LINE_MODE, 1 /* Line drill not use */, EXCEPT_DSP); 
		if(bResult) bResult = bResult & SetParameter(&Para, dMaskAOMDutyOffset + dPowerDutyOffset, subTool.nMask);
		if(bResult) bResult = bResult & DownloadTCode(nTool, Para.Frequency, 1, 1, subTool.bUseAperture ); // Total shot �׻� 1

		CString str;
		str.Format(_T("%s"), subTool.cFilePath);
		if(subTool.bUseAperture && str.GetLength() > 0)
		{
			if(bResult) bResult = bResult & DownloadOneAperture(str, nTool);
		}

		if(bResult) bResult = bResult & SetInpositionCheckINI(FALSE);

		return bResult;
	}
	else if(subTool.nToolType == FLYING_TYPE)
	{
		Para.LaserOnDelay = 0;
		Para.LaserOffDelay = 0;
		Para.FPSDelay = subTool.nFPS;
		Para.Frequency = subTool.nFrequency;
		Para.dAOMDelay = subTool.dShotAOMDelay[0] + dMaskAOMDelayOffset;
		Para.dAOMDuty = subTool.dShotAOMDuty[0] + dMaskAOMDutyOffset + dPowerDutyOffset;
		memcpy(Para.cAOMFilePath, subTool.cAOMFilePath[0], 255);
		if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			if(Para.Frequency < 15000 || Para.Frequency > 100000)
				Para.Frequency = 15000;
		}
		if(gSystemINI.m_sHardWare.nLaserType == LASER_UV ||
			gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
			Para.dDuty = 5000; // 50%  : UV�� duty ��� ����.
		else
			Para.dDuty = subTool.dShotDuty[0] * 100 + dMaskDutyOffset * 100 + (dPowerDutyOffset * 100.0); // unit 0.01% (0 index ���)

		bResult = TRUE; // SetRunMode(FALSE, Para.DrawStepPeriod, UV_LINE_MODE, 1 /* Line drill not use */); : �߿��� �ϼ��Ǹ� �ؾ���
		if(bResult) bResult = bResult & SetParameter(&Para, dMaskAOMDutyOffset + dPowerDutyOffset, subTool.nMask);

		if(bResult) bResult = bResult & SetInpositionCheckINI(FALSE);
		
		return bResult;
	}
	else
		return FALSE;

	return TRUE;
}

BOOL HEocard5Pusan1::DownloadOneAperture(CString str, int nTool)
{
	if(!m_pDriver) 
		return TRUE;

	#ifndef __NEW_STRUCTURE__
	if(!ApertureDataReset(nTool))
		return FALSE;
	m_MarkingData.RemoveAll();
	MARKING_DATA markingData;
	
	char szBuf[256];
	CString strRead;
	strRead.Format(_T(""));
	CString strXPos, strYPos;
	strXPos.Format(_T("")); strYPos.Format(_T(""));
	int nchar = 0;
	
	FILE* fp;
	errno_t err;
	err = fopen_s(&fp, str, "r");
	if(err != NULL)
	{
		return FALSE;
	}
	
	m_PtnInfo[nTool].nUsedDotCnt = 0;
	
	while(!feof(fp))
	{
		fgets(szBuf, 255, fp);
		strRead = (CString) szBuf;
		strRead.TrimLeft();
		strRead.TrimRight();
		if(strRead.GetAt(0) == _T('P') && strRead.GetAt(2) == _T(';'))
		{
			if(strRead.GetAt(1) == _T('D') || strRead.GetAt(1) == _T('U') || strRead.GetAt(1) == _T('M') || strRead.GetAt(1) == _T('L'))
			{
				if(strRead.Find(_T(',')) == -1)
				{
					break;
				}
				else
				{
					for(nchar = 3; nchar < strRead.Find(_T(',')); ++nchar)
						strXPos += strRead.GetAt(nchar);
					for(nchar = strRead.Find(_T(','))+1; nchar < strRead.GetLength()-1; ++nchar)
						strYPos += strRead.GetAt(nchar);
					
					if(strRead.GetAt(1) == _T('D'))
						markingData.nAction = ONE_STEP_DRAW;//MARK_DRAW;
					else if(strRead.GetAt(1) == _T('M'))
						markingData.nAction = MICRO_STEP_DRAW;//MARK_DRAW;
					else if(strRead.GetAt(1) == _T('L'))
						markingData.nAction = ONE_STEP_JUMP;//_DRAW;
					else
						markingData.nAction = MICRO_STEP_JUMP ; // MARK_JUMP;
					markingData.nPoint.x = (int) (atof(strXPos) * 65535 / (gSystemINI.m_sSystemDevice.dFieldSize.x*1000));
					markingData.nPoint.y = (int) (atof(strYPos) * 65535 / (gSystemINI.m_sSystemDevice.dFieldSize.y*1000));	
					m_MarkingData.Add(markingData);

					m_PtnInfo[nTool].PtnDot[m_PtnInfo[nTool].nUsedDotCnt].dx = (short)markingData.nPoint.x;
					m_PtnInfo[nTool].PtnDot[m_PtnInfo[nTool].nUsedDotCnt].dy = (short)markingData.nPoint.y;
					m_PtnInfo[nTool].PtnDot[m_PtnInfo[nTool].nUsedDotCnt].eMoveCmd = (EDrillMoveCmd)markingData.nAction;
					m_PtnInfo[nTool].nUsedDotCnt++;
					
//					if(!DownloadAperture(nTool, markingData.nPoint.x, markingData.nPoint.y, markingData.nAction))
//					{
//						ApertureDataReset(nTool);
//						fclose(fp);
//						return FALSE;
//					}
					strXPos.Format(_T(""));
					strYPos.Format(_T(""));							
				}						 
			}			
		}
	}
	
	if(!DownloadAperture(nTool, 0, 0, 0))
	{
		ApertureDataReset(nTool);
		fclose(fp);
		return FALSE;
	}
	fclose(fp);
	#endif

	return TRUE;
}

BOOL HEocard5Pusan1::DownloadShotDrillScannerParam(int nJumpDelayPlus)// nJumpDelay 1 = 1 X Draw step Period
{
	if(!m_pDriver) 
		return TRUE;

	if(nJumpDelayPlus == 0)
		m_TDrillParam.nTimeAfterInpos = gSystemINI.m_sSystemDevice.nJumpDelayShot;
	else
		m_TDrillParam.nTimeAfterInpos = nJumpDelayPlus;
#ifndef __PUSAN_LDD__	

		m_TDrillParam.nScannerPreMoveTime_us = gSystemINI.m_sSystemDevice.nPreMove;

#endif
	return m_pDriver->Drill_SetParaAll(&m_TDrillParam);

	//���� 
//////////////////////////////////////
/*	FILE* filestream;
	filestream = fopen_s(strPath, _T("r"));
	if(filestream == NULL)
	{
		return FALSE;
	}
	
	CString str;
	int nCount, nLSB, nDisCount, nDistLevel, nJumpDelay, nScannerLeadTime;//bskim �λ�        2�� 5ȣ��<ScannerPremoveTime_us>
	
	fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
	str.ReleaseBuffer();
	nDisCount = atoi(str);
	fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
	str.ReleaseBuffer();
	
	for(int k = 0; k < 8; k++)
	{
		fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		nDistLevel = atoi(str);
		fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
//		if(!SetMoveProfileLength(k, nDistLevel))
//			return FALSE;
	}
	
//	if(!MoveProfileReset(-1))
//		return FALSE;
	
	for(int k =  0; k < nDisCount; k++)
	{
		fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		nCount = atoi(str);
		fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		
		for(int i = 0; i < nCount; i++)
		{
			fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
			str.ReleaseBuffer();
			nLSB = atoi(str);
//			if(!DownloadProfile(k, nLSB))
//				return FALSE;
		}
		
		fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		nJumpDelay = atoi(str);
		fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();

		if(nJumpDelayPlus == 0)
			m_TDrillParam.nTimeAfterInpos = nJumpDelay;
		else
			m_TDrillParam.nTimeAfterInpos = nJumpDelayPlus;

		fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();					 //bskim �λ� 2�� 5ȣ��<ScannerPremoveTime_us>
		nScannerLeadTime = atoi(str);			//bskim �λ� 2�� 5ȣ��<ScannerPremoveTime_us>
		fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();					 //bskim �λ� 2�� 5ȣ��<ScannerPremoveTime_us>

		m_TDrillParam.nScannerPreMoveTime_us = nScannerLeadTime; //bskim �λ� 2�� 5ȣ��<ScannerPremoveTime_us>

		return m_pDriver->Drill_SetParaAll(&m_TDrillParam);


	}
	fclose(filestream);
	return TRUE;
	*//////////////////////////////////////
}

BOOL HEocard5Pusan1::SetFunction(USHORT Value)
{
	m_usFunction = Value;

	if(!m_pDriver) 
		return TRUE;
	
	unsigned char ucValue = static_cast<unsigned char>(Value);

	m_pDriver->BoardIO_WriteOut(EETSx_WriteOut_INOUT_LaserPower_IF, Value, TRUE);
	
	return TRUE;
}

USHORT HEocard5Pusan1::GetFunction()
{
	return (m_usFunction);
}

BOOL HEocard5Pusan1::GetStatus(WORD *pStat) const
{
	if(!m_pDriver)
		return TRUE;

	int nVal;
	m_pDriver->BoardIO_ReadIn(EETSx_ReadIn_Laser_IF, &nVal);
//	WORD nVal = m_pDriver->ReadInLif(); // 1bit : chiller error feedback, 3bit : shutter status
//	int nReturn = 0;
//	nReturn = (nVal & 0x04) << 2;
//	nReturn = nReturn | ((nVal & 0x01) << 6);
//	*pStat = nReturn; //  ���� 0bit �� 3bit�� �ͼ� ȣȯ�� ���� ����
	*pStat = nVal;
	return TRUE; 
}



BOOL HEocard5Pusan1::SetQuantaParam(int nFPK, int nCurrent)
{
	// ??
	return TRUE;
}

BOOL HEocard5Pusan1::FlyingModeEnable(BOOL bEnable)
{
	// ??
	return TRUE;
}

BOOL HEocard5Pusan1::StatusOK(int nStatus)
{
//	return TRUE;
#ifndef __TEST__
	TRunStatus dData; 
	
	if(nStatus == QUEUEFULL || nStatus == BUSY) // wait until QueueFull or Busy is unlocked
	{
		if(nStatus == QUEUEFULL)
			return FALSE;

		m_pDriver->List_GetRunStatus(&dData);

		while (!dData.bit.Busy) // readStatus() : running --> return 1
		{
			Sleep(0);
			m_pDriver->List_GetRunStatus(&dData);
		}
	}
	else
	{
		m_pDriver->List_GetRunStatus(&dData);

		while ( dData.bit.Busy) // wait until Idle
		{
			Sleep(0);
			m_pDriver->List_GetRunStatus(&dData);
		}
	}
#endif
	return TRUE;
}

BOOL HEocard5Pusan1::FieldPreStart(int nShotNo)
{
	if(!m_pDriver)
		return TRUE;

//	m_TDrillParam.nMinDummyShotCnt = nShotNo;
//	m_TDrillParam.nDummyShotInterval = gSystemINI.m_sSystemDump.nDummyInterval / 20 * 20; 
	BOOL bResult = m_pDriver->Drill_SetParaAll(&m_TDrillParam);

	if(!bResult)
		return FALSE;

	TDrillPara Para;
//	TDrillHoleData HoleData100[100];

	if(gSystemINI.m_sSystemDevice.bCheckHoleData)
	{
		bResult = m_pDriver->Drill_GetPara(&Para);
		if(!bResult)
			return FALSE;
	}

	int nRetry = 0;

	BOOL bVal = TRUE;
	if(m_nDownHoleCount > 0)
	{
		bResult = m_pDriver->Drill_AddHoleData(m_nDownHoleCount, m_ptData);
		if(!bResult)
			return FALSE;

/*		if(gSystemINI.m_sSystemDevice.bCheckHoleData)
		{
			while(nRetry <= 3)
			{
				bResult = m_pDriver->Drill_GetPara(&Para2);
				if(bResult)
				{
					if((Para2.nHoleCount - Para.nHoleCount) == (UINT)m_nDownHoleCount)
						break;
				}
				::Sleep(1);
				nRetry++;
			}
			if(nRetry > 3)
				return FALSE;

			bResult = m_pDriver->Drill_CheckHoleData100(HoleData100);
			if(!bResult)
				return FALSE;
			bResult = IsSameHoleData(HoleData100, m_nDownHoleCount);
		}
*/		m_nDownHoleCount = 0;

//		return bResult;
	}

	nRetry = 0;
	while(TRUE)
	{
		::Sleep(10);// wait for down complete
		int nCount = ReadHoleCount();
		if(nCount == m_nBackupCount)
			return m_pDriver->Drill_PreStart();

		nRetry++;
		if(nRetry >= 3)
			break;

//		ReDownloadHole();	

	}
	return FALSE;
}

BOOL HEocard5Pusan1::ReDownloadHole()
{
	int nCount = 0, nDownTotal = m_nBackupCount;

	TDrillPara Para;
//	TDrillHoleData HoleData100[100];
	BOOL bResult;
	int nRetry = 0;

	m_pDriver->Drill_ResetHole();

	int nOnceDownCount = gSystemINI.m_sSystemDevice.nEocardDownCount;
	if(gSystemINI.m_sSystemDevice.bCheckHoleData)
		nOnceDownCount = 100;

	for(int i = 0; i < nDownTotal; i++)
	{
		m_ptData[nCount].nToolNum = m_pBackUpData[i].nToolNum;
		m_ptData[nCount].HolePos[0].x = m_pBackUpData[i].HolePos[0].x;
		m_ptData[nCount].HolePos[0].y = m_pBackUpData[i].HolePos[0].y;
		m_ptData[nCount].HolePos[1].x = m_pBackUpData[i].HolePos[1].x;
		m_ptData[nCount].HolePos[1].y = m_pBackUpData[i].HolePos[1].y;
		m_ptData[nCount].HolePos[2].x = 32767;
		m_ptData[nCount].HolePos[2].y = 32767;
		m_ptData[nCount].HolePos[3].x = 32767;
		m_ptData[nCount].HolePos[3].y = 32767;

		m_ptData[nCount].nUseAngle = 0;
		m_ptData[nCount].fSine = 0;
		m_ptData[nCount++].fCosine = 1;


		TDrillPara Para;
//		TDrillHoleData HoleData100[100];
		BOOL bResult;
		int nRetry = 0;

		if(m_nDownHoleCount == nOnceDownCount) // 100�� ������ downloading
		{
			nCount = 0;
			if(gSystemINI.m_sSystemDevice.bCheckHoleData)
			{
				bResult = m_pDriver->Drill_GetPara(&Para);
				if(!bResult)
					return FALSE;
			}

			bResult = m_pDriver->Drill_AddHoleData(nOnceDownCount, m_ptData);
			if(!bResult)
				return FALSE;

/*			if(gSystemINI.m_sSystemDevice.bCheckHoleData)
			{
				while(nRetry <= 3)
				{
					bResult = m_pDriver->Drill_GetPara(&Para2);
					if(bResult)
					{
						if((Para2.nHoleCount - Para.nHoleCount) == (UINT)nOnceDownCount)
							break;
					}
					::Sleep(1);
					nRetry++;
				}
				if(nRetry > 3)
					return FALSE;

				bResult = m_pDriver->Drill_CheckHoleData100(HoleData100);
				if(!bResult)
					return FALSE;
				if(!IsSameHoleData(HoleData100, nOnceDownCount))
					return FALSE;
			}
*/		}
	}
	
	if(nCount > 0) 
	{
		nRetry = 0;
		if(gSystemINI.m_sSystemDevice.bCheckHoleData)
		{
			bResult = m_pDriver->Drill_GetPara(&Para);
			if(!bResult)
				return FALSE;
		}

		bResult = m_pDriver->Drill_AddHoleData(nCount, m_ptData);
		if(!bResult)
			return FALSE;

/*		if(gSystemINI.m_sSystemDevice.bCheckHoleData)
		{
			while(nRetry <= 3)
			{
				bResult = m_pDriver->Drill_GetPara(&Para2);
				if(bResult)
				{
					if((Para2.nHoleCount - Para.nHoleCount) == (UINT)nCount)
						break;
				}
				::Sleep(1);
				nRetry++;
			}
			if(nRetry > 3)
				return FALSE;

			bResult = m_pDriver->Drill_CheckHoleData100(HoleData100);
			if(!bResult)
				return FALSE;
			bResult = IsSameHoleData(HoleData100, nCount);
		}
*/		nCount = 0;
		return bResult;
	}
	else
		return TRUE;
}

void HEocard5Pusan1::ResetCO2Laser()
{
	m_cCO2Laser = 0xFF;
	SetFunction(m_cCO2Laser);
}

void HEocard5Pusan1::ReloadDevice()
{
	if(!m_pDriver)
		return;

	m_pDriver->PortClose();

	m_pDriver = new CETSx_API();
	BOOL bOpen = m_pDriver->PortOpen(0); // 0 index card loading

	if(!bOpen)
	{
		::AfxMessageBox(_T("Eocard Port Open Error"), MB_OK);
		delete m_pDriver;
		m_pDriver = NULL;
		return;
	}

	//---------

	m_UsedBeam.v = 0;

	if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_1ST)
		m_UsedBeam.bit.beam1 = TRUE;
	if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_2ND)
		m_UsedBeam.bit.beam2 = TRUE;
	if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_3RD)
		m_UsedBeam.bit.beam3 = TRUE;
	if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_4TH)
		m_UsedBeam.bit.beam4 = TRUE;
	
	m_pDriver->ScanCfg_SetUsedBeam(&m_UsedBeam);

	m_pDriver->Drill_SetParaAll(&m_TDrillParam);

#ifndef __USE_DUALBAND_EOCARD__
		m_TAomParam.bUse_DualAom = FALSE;
#endif
	m_TAomParam.bUse_FirstOrderBeam = TRUE;
	m_pDriver->Drill_SetAomPara(&m_TAomParam);

	//---------
	// ETS5 Initialization
	EChannelCfg scanch[MAX_SCAN_CHANNEL] = {
		OUT_Beam1y, OUT_Beam1x, OUT_Beam2y, OUT_Beam2x,
		OUT_Beam3y, OUT_Beam3x, OUT_Beam4y, OUT_Beam4x
	};

	if(gSystemINI.m_sHardWare.nScannerAxisType == PX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType == NX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType == PX_NY ||
		gSystemINI.m_sHardWare.nScannerAxisType == NX_NY)
	{
		scanch[0] = OUT_Beam1x; scanch[1] = OUT_Beam1y;
//		scanch[2] = OUT_Beam2x; scanch[3] = OUT_Beam2y;
	}

	if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == NX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == PX_NY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == NX_NY)
	{
//		scanch[0] = OUT_Beam1x; scanch[1] = OUT_Beam1y;
		scanch[2] = OUT_Beam2x; scanch[3] = OUT_Beam2y;
	}


	EChannelCfg dach[MAX_DA_CHANNEL] = {
		OUT_AnalogFps, OUT_RfOffLevel, OUT_LaserPower, OUT_Da1
	};
	
	CScanParaCmd Sp; 
//	CScanParaAux SpAux;
//	TLaserPara Lp;
	Sp.Init();
	Sp.fFieldSize_mm = (int)gSystemINI.m_sSystemDevice.dFieldSize.x;

	TLaserType lasertype;	
	lasertype.v = 0;
//	lasertype.bit.Ipg = 0;
#ifdef __KUNSAN_6__
	lasertype.bit.Standby = 0;
#else
	lasertype.bit.StandbyPulse = 0;
#endif
	lasertype.bit.Analog_FPS = 0;

//	m_pDriver->SetLaserType(lasertype);

	m_pDriver->LaserCtrl_SetEnableIO(FALSE);
	
	m_pDriver->BoardIO_SetTopBoard(1);						// Top Board �⺻Type ���� User Mode�� ���

	// Hsif0�� 1�� �ϵ���� �������� �ܶ��Ǿ��ִ�.
	// 0�� 1�� ������ ��ȣ.
//	m_pDriver->BoardIO_SetPinMux(Pin_OUT_HighSpeed_IF, 0, SIG_GATE, 0);
//	m_pDriver->BoardIO_SetPinMux(Pin_OUT_HighSpeed_IF, 1, SIG_GATE, 0);
//	m_pDriver->BoardIO_SetPinMux(Pin_OUT_HighSpeed_IF, 2, SIG_AOM, 0);

	m_pDriver->BoardIO_SetPinMux(Pin_OUT_Laser_IF, 0, SIG_FPS, FALSE);
	m_pDriver->BoardIO_SetPinMux(Pin_OUT_Laser_IF, 1, SIG_LM, FALSE);

	m_pDriver->BoardIO_SetPinMux(Pin_INOUT_LaserPower_IF, 0, SIG_LOAD_DATA0, 0); // laser enable
	m_pDriver->BoardIO_SetPinMux(Pin_INOUT_LaserPower_IF, 1, SIG_LOAD_DATA1, 0); // shutter open/close
	m_pDriver->BoardIO_SetPinMux(Pin_INOUT_LaserPower_IF, 2, SIG_LOAD_DATA2, 0); // laser power on/off


//	m_pDriver->SetIOInversion(0, 0);							//0: OutLif
//	m_pDriver->SetIOInversion(1, 4);							//1: InLif
//	m_pDriver->SetIOInversion(2, 0);							//2: OutHif

	m_pDriver->BoardIO_SetPinMux(Pin_IN_Laser_IF, 2, SIG_INPUT, TRUE);
								
//	m_pDriver->ScanCtrl_SetNumOfBeam(2);						
	m_pDriver->ScanCfg_SetNumOfBeam(2);	// 100825
	m_pDriver->BoardIO_SetChannel(EETSx_Scanner_Channel, scanch); //
	m_pDriver->BoardIO_SetChannel(EETSx_DA_Channel, dach);				//�ϵ���� ä�� ����

	SetFunction(65535); // CO2 high : laser power on  (X)

	m_pDriver->LaserCtrl_SetEnableIO(TRUE);

	BOOL bXReverse, bYReverse, bAxisCange = FALSE;

	if(gSystemINI.m_sHardWare.nScannerAxisType == PX_PY)
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_PY)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PX_NY)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NX_NY)
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_PX) // ------------------------------------
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == NY_PX)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType == PY_NX)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else 
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
//	m_pDriver->ScanCtrl_SetAxis(0, bXReverse, bYReverse, 0, TRUE);
	m_pDriver->ScanCfg_SetAxis(0, bXReverse, bYReverse, 0, TRUE); // 100825

	//---------------------------------------------------------
	if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_PY)
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NX_PY)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_NY)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NX_NY)
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PY_PX) // ------------------------------------
	{
		bXReverse = FALSE; bYReverse = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == NY_PX)
	{
		bXReverse = FALSE; bYReverse = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nScannerAxisType2 == PY_NX)
	{
		bXReverse = TRUE; bYReverse = FALSE;
	}
	else 
	{
		bXReverse = TRUE; bYReverse = TRUE;
	}
//	m_pDriver->ScanCtrl_SetAxis(1, bXReverse, bYReverse, 0, TRUE);
	m_pDriver->ScanCfg_SetAxis(1, bXReverse, bYReverse, 0, TRUE); // 100825

//	m_pDriver->List_ConfigSize(8192,8192);							// ����Ʈ ���� ����
//	m_pDriver->List_SetMode(LISTMODE_Rotary); // m_pDriver->SetListMode(LISTMODE_Rotary); //LISTMODE_Auto_Change);				// ����Ʈ �ڵ� �����Ͽ� ����

	m_pDriver->ScanPara_SetCmdAll(Sp, TRUE);			//��ĳ�� �Ķ���� ����
//	m_pDriver->ScanPara_SetAuxAll(SpAux, TRUE);
//	m_pDriver->LaserPara_SetAll(Lp, TRUE);			//������ �Ķ���� ����
	m_pDriver->Timer_UpdateTime();

	if(!DummyParamSet())
	{
		CString strFile, strLog;
		strFile.Format(_T("ReadHole"));
		strLog.Format(_T("Dump Parameter Set Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		::AfxMessageBox(_T("Error : Dummy shot parameter download Failure"));
	}

	if(!StandbyParamSet())
	{
#ifndef __TEST__
		CString strFile, strLog;
		strFile.Format(_T("ReadHole"));
		strLog.Format(_T("Standby Parameter Set Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		::AfxMessageBox(_T("Error : Standby shot parameter download Failure"));
#endif
	}

}
//first order
BOOL HEocard5Pusan1::DownloadAOMProfile(int nTool, int nSubTool, CString strPath, double dDuty, double dAOMDelay, double dAOMDuty, double dAOMOffset, double dDutyOffsetM, double dDutyOffsetS, double dVolOffsetM, double dVolOffsetS, int nMask)
{
	TDrillAomInfo tempAOMInfo;
	double dTotalTime = 0;

 	m_dAOMOpenLastTime = 0;
	if(!m_pDriver) 
		return TRUE;

#ifdef __3RDAOD__
	#ifndef __USE_DUALBAND_EOCARD__
		for(int k =  0; k < MAX_NUMBER_OF_MODULATION_CYCLE; k++)
		{
			tempAOMInfo.fAOM_CloseTime_us[k] = 0;
			tempAOMInfo.fAOM_OpenTime_us[k] = 0;
		}
	#endif

		if(nTool == -1)
			return m_pDriver->Drill_SetManualAOMInfo(&tempAOMInfo);
		else
		{
			tempAOMInfo.fDA1_percent = 0;
			tempAOMInfo.fDA2_percent = 0;
			return m_pDriver->Drill_SetAOMInfo(nTool * 15 + nSubTool, &tempAOMInfo);
		}
#else

	#ifndef  __KUNSAN_8__
		if(strPath.CompareNoCase("") == 0)
			return TRUE; //cw shot

		if(nTool == -1)
		{
			dAOMDelay = m_Parameter.dAOMDelay;
			dAOMDuty = m_Parameter.dAOMDuty;
			dDuty = m_Parameter.dDuty / 100.;

	#ifndef __PUSAN_OLD_32__
		#ifndef __PUSAN_LDD__
			tempAOMInfo.fDA1_percent = 0;
			tempAOMInfo.fDA2_percent = 0;
		#endif
	#endif
		}

		if(gSystemINI.m_sHardWare.nUseAOD)
		{
			if(nTool == -1)
			{
				dAOMDelay = m_Parameter.dAOMDelay;
				dAOMDuty = m_Parameter.dAOMDuty - dAOMOffset;
				dDuty = m_Parameter.dDuty / 100.;
			}
			else
				dAOMDuty = dAOMDuty - dAOMOffset;
		}

		if(dAOMDelay < 0)
			dAOMDelay = 0;
		if(dAOMDuty < 0 || dDuty <= 0)
		{
			::AfxMessageBox(_T("Error : AOM delay < 0 or Laser Duty  <= 0. Check Offset."));
			return FALSE;
		}

		FILE* filestream;
		errno_t err;
		err = fopen_s(&filestream, strPath, "r");
		if(err != NULL)
		{
			return FALSE;
		}

		CString str;
		int nDisCount; 
		double dVal;

		fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		nDisCount = atoi(str);
		fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		if(nDisCount > 4)
			nDisCount = 4;

		if(gSystemINI.m_sHardWare.nUseAOD)
			nDisCount = 1;


	#ifndef __USE_DUALBAND_EOCARD__
		for(int k =  0; k < MAX_NUMBER_OF_MODULATION_CYCLE; k++)
		{
			tempAOMInfo.fAOM_CloseTime_us[k] = 0;
			tempAOMInfo.fAOM_OpenTime_us[k] = 0;
		}
	#endif
		tempAOMInfo.fAOM_CloseTime_us[0] = dAOMDelay;

		if(nDisCount > 0)
			dAOMOffset = dAOMOffset /nDisCount;

		double dAOMOffsetM, dAOMOffsetS;
		if(nDisCount > 0)
		{
			if(nMask == -1)
			{
				if(gSystemINI.m_sHardWare.nAODMSSelect)
				{
					dAOMOffsetM = dAOMOffset * (double)gSystemINI.m_sSystemDevice.nDualAom1stOffset / 100. + dDutyOffsetM; // aom�� �������� M/s �ٲ�
					dAOMOffsetS = dAOMOffset * (double)gSystemINI.m_sSystemDevice.nDualAom2ndOffset / 100. + dDutyOffsetS; // aom�� �������� M/s �ٲ�
				}
				else
				{
					dAOMOffsetS = dAOMOffset * (double)gSystemINI.m_sSystemDevice.nDualAom1stOffset / 100. + dDutyOffsetM; // aom�� �������� M/s �ٲ�
					dAOMOffsetM = dAOMOffset * (double)gSystemINI.m_sSystemDevice.nDualAom2ndOffset / 100. + dDutyOffsetS; // aom�� �������� M/s �ٲ�
				}
			}
			else
			{
				if(gSystemINI.m_sHardWare.nAODMSSelect)
				{
					dAOMOffsetM = dAOMOffset * (double)gBeamPathINI.m_sBeampath.dPowOffsetAomDual1[nMask] / 100. + dDutyOffsetM; // aom�� �������� M/s �ٲ�
					dAOMOffsetS = dAOMOffset * (double)gBeamPathINI.m_sBeampath.dPowOffsetAomDual2[nMask] / 100. + dDutyOffsetS; // aom�� �������� M/s �ٲ�
				}
				else
				{
					dAOMOffsetS = dAOMOffset * (double)gBeamPathINI.m_sBeampath.dPowOffsetAomDual1[nMask] / 100. + dDutyOffsetM; // aom�� �������� M/s �ٲ�
					dAOMOffsetM = dAOMOffset * (double)gBeamPathINI.m_sBeampath.dPowOffsetAomDual2[nMask] / 100. + dDutyOffsetS; // aom�� �������� M/s �ٲ�
				}
			}
		}

		int nEndDelay = 25;

		if(!gSystemINI.m_sHardWare.nUseAOD)
		{
			for(int k =  0; k < nDisCount; k++)
			{
				fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
				str.ReleaseBuffer();
				dVal = atof(str);
				dTotalTime += dVal;
				if(dTotalTime > dAOMDuty)
				{
					tempAOMInfo.fAOM_OpenTime_us[k] = dVal - (dTotalTime - dAOMDuty);
					tempAOMInfo.fAOM_CloseTime_us[k+1] = (dDuty - dAOMDuty - dAOMDelay) + nEndDelay;
					break;
				}
				else
					tempAOMInfo.fAOM_OpenTime_us[k] = dVal + dAOMOffset;

				fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
				str.ReleaseBuffer();
				dVal = atof(str);
				dTotalTime += dVal;
				tempAOMInfo.fAOM_CloseTime_us[k+1] = dVal;
			
				if(dTotalTime > dAOMDuty)
				{
					tempAOMInfo.fAOM_CloseTime_us[k+1] = (dDuty - dAOMDelay - (dTotalTime - dVal)) + nEndDelay;
					break;
				}
			}
		}
		else
		{
			for(int k =  0; k < 2; k++)
			{
				tempAOMInfo.fAOM_CloseTime_us[k+1] = 2;
				if(k%2 == 0)
					tempAOMInfo.fAOM_OpenTime_us[k] = (dAOMDuty - 2)/2 + dAOMOffsetM;
				else
					tempAOMInfo.fAOM_OpenTime_us[k] = (dAOMDuty - 2)/2 + dAOMOffsetS;
			}
		}

		fclose(filestream);

		for(int k =  0; k < nDisCount; k++)
		{
			if(tempAOMInfo.fAOM_OpenTime_us[k] != 0)
			{
				m_dAOMOpenLastTime += tempAOMInfo.fAOM_CloseTime_us[k];
				m_dAOMOpenLastTime += tempAOMInfo.fAOM_OpenTime_us[k];
			}
		}

		if(nTool == -1)
			return m_pDriver->Drill_SetManualAOMInfo(&tempAOMInfo);
		else
		{
			#ifndef __PUSAN_OLD_32__
				#ifndef __PUSAN_LDD__
					tempAOMInfo.fDA1_percent = dVolOffsetM;
					tempAOMInfo.fDA2_percent = dVolOffsetS;
				#endif
			#endif
			return m_pDriver->Drill_SetAOMInfo(nTool * 15 + nSubTool, &tempAOMInfo);
		}
	#endif
#endif
	return TRUE;
}
//zero order
/*
BOOL HEocard5Pusan1::DownloadAOMProfile(int nTool, int nSubTool, CString strPath, double dDuty, double dAOMDelay, double dAOMDuty, double dAOMOffset, int nMask)
{

	if(!m_pDriver) 
		return TRUE;
	
	if(strPath == _T(""))
		return TRUE; //cw shot
	
	TDrillAomInfo tempAOMInfo;
	double dTotalTime = 0;
#ifdef __3RDAOD__
	for(int k = 0; k < MAX_NUMBER_OF_MODULATION_CYCLE; k++)
	{
		tempAOMInfo.fAOM_CloseTime_us[k] = 0;
		tempAOMInfo.fAOM_OpenTime_us[k] = 0;
	}

	if(nTool == -1)
		return m_pDriver->Drill_SetManualAOMInfo(&tempAOMInfo);
	else
		return m_pDriver->Drill_SetAOMInfo(nTool * 15 + nSubTool, &tempAOMInfo);
#else
	if(nTool == -1)
	{
		dAOMDelay = m_Parameter.dAOMDelay;
		dAOMDuty = m_Parameter.dAOMDuty;
		dDuty = m_Parameter.dDuty / 100.;
	}
	
	if(dAOMDelay < 0)
		dAOMDelay = 0;
	if(dAOMDuty < 0 || dDuty <= 0)
	{
		ErrMessage(_T("Error : AOM delay < 0 or Laser Duty  <= 0. Check Offset."));
		return FALSE;
	}
	//	tempAOMInfo.fAOMDelay_us = dAOMDelay;
	//	tempAOMInfo.fAOM_CloseTime_us = dAOMDuty;
	
	FILE* filestream;
	filestream = fopen_s(strPath, _T("r"));
	if(filestream == NULL)
	{
		return FALSE;
	}
	
	CString str;
	int nDisCount;
	double dVal;
	
	fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
	str.ReleaseBuffer();
	nDisCount = atoi(str);
	fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
	str.ReleaseBuffer();
	if(nDisCount > 4)
		nDisCount = 4;
	
	for(int k = 0; k < MAX_NUMBER_OF_MODULATION_CYCLE; k++)
	{
		tempAOMInfo.fAOM_CloseTime_us[k] = 0;
		tempAOMInfo.fAOM_OpenTime_us[k] = 0;
	}
	
	tempAOMInfo.fAOM_CloseTime_us[0] = 0;
	tempAOMInfo.fAOM_OpenTime_us[0] = dAOMDelay;
	
	if(nDisCount > 0)
		dAOMOffset = dAOMOffset /nDisCount;
	
	int nEndDelay = 25;
	
	for(int k =  0; k < nDisCount; k++)
	{
		fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		dVal = atof(str);
		dTotalTime += dVal;
		if(dTotalTime > dAOMDuty)
		{
			tempAOMInfo.fAOM_CloseTime_us[k+1] = dVal - (dTotalTime - dAOMDuty);
			tempAOMInfo.fAOM_OpenTime_us[k+1] = (dDuty - dAOMDuty - dAOMDelay) + nEndDelay;
			break;
		}
		else
			tempAOMInfo.fAOM_CloseTime_us[k+1] = dVal + dAOMOffset;
		
		fscanf(filestream, _T("%s\n"), str.GetBuffer(256));
		str.ReleaseBuffer();
		dVal = atof(str);
		dTotalTime += dVal;
		tempAOMInfo.fAOM_ModOffTime_us[k+1] = dVal;
		if(dTotalTime > dAOMDuty)
		{
			tempAOMInfo.fAOM_OpenTime_us[k+1] = (dDuty - dAOMDelay - (dTotalTime - dVal)) + nEndDelay;
			break;
		}
	}
	fclose(filestream);
	
	for(int k =  0; k < MAX_NUMBER_OF_MODULATION_CYCLE; k++)
	{
		TRACE(_T("Tool no = %d [%d], On = %.1f, Off = %.1f\n"), nTool, k,
			tempAOMInfo.fAOM_CloseTime_us[k],
			tempAOMInfo.fAOM_OpenTime_us[k]);
	}
	
	if(nTool == -1)
		return m_pDriver->Drill_SetManualAOMInfo(&tempAOMInfo);
	else
		return m_pDriver->Drill_SetAOMInfo(nTool * 15 + nSubTool, &tempAOMInfo);
#endif
}
*/
BOOL HEocard5Pusan1::IsFireCntOK(int& nDownCnt, int& nReadCnt)
{
	if(!m_pDriver)
		return FALSE;
#ifndef __NEW_STRUCTURE__
	int nTotal=0;
	for(int i = 0; i < 31; i++)
	{
		if(m_PtnInfo[i].PtnConfig.bUsePtn == 1)
			nTotal += (m_PtnInfo[i].nUsedDotCnt * m_PtnInfo[i].PtnConfig.nDotTotalShotCnt * m_nHoleCnt[i]);
		else
			nTotal += (m_PtnInfo[i].PtnConfig.nDotTotalShotCnt * m_nHoleCnt[i]);
	}

	nDownCnt = nTotal;
	nReadCnt = -1;

	TDrillMonitor Para; 
	if(!m_pDriver->Drill_GetMonitor(&Para))
	{
		::Sleep(10);
		if(!m_pDriver->Drill_GetMonitor(&Para))
			return FALSE; // false
	}
#ifndef __3RDAOD__
	nReadCnt = Para.nFiredLaserShotCnt;

	if(Para.nFiredLaserShotCnt != (UINT)nTotal)
		return FALSE;
	else
		return TRUE;
#else
	nReadCnt = Para.nFiredLaserShotCnt_Req;

	if(Para.nFiredLaserShotCnt_Req != (UINT)nTotal)
		return FALSE;
	else
		return TRUE;
#endif
#else
	return TRUE;
#endif
	
}


BOOL HEocard5Pusan1::DummyFieldStart(int nShotNo, BOOL bDryRun)
{
	if(!m_pDriver)
		return TRUE;
//	m_TDrillParam.nMinDummyShotCnt = nShotNo;
//	m_TDrillParam.nDummyShotInterval = gSystemINI.m_sSystemDevice.nDummyInterval/20; // 1 --> 20us
//	BOOL bResult = m_pDriver->Drill_SetParaAll(&m_TDrillParam);
	return TRUE;
//	return m_pDriver->Drill_DummyShot_Start(bDryRun);//, &m_DummyPos);
}

BOOL HEocard5Pusan1::DummyStopAndDataShotStart(BOOL bDryRun)
{
	if(!m_pDriver)
		return TRUE;
	return m_pDriver->Drill_Start(bDryRun);
}

BOOL HEocard5Pusan1::DummyParamSet(BOOL bPowervia)
{
	if(!m_pDriver)
		return TRUE;

	BOOL bResult = FALSE;

	m_DummyPos.Pos[0].x = gSystemINI.m_sSystemDump.nPtBeanDumper1.x;
	m_DummyPos.Pos[0].y = gSystemINI.m_sSystemDump.nPtBeanDumper1.y;
	m_DummyPos.Pos[1].x = gSystemINI.m_sSystemDump.nPtBeanDumper2.x;
	m_DummyPos.Pos[1].y = gSystemINI.m_sSystemDump.nPtBeanDumper2.y;
	m_DummyPos.Pos[2].x = 32767;
	m_DummyPos.Pos[2].y = 32767;
	m_DummyPos.Pos[3].x = 32767;
	m_DummyPos.Pos[3].y = 32767;

	return TRUE;

/*	bResult = m_pDriver->Drill_DummyShot_SetPara(&m_DummyPos, 
										(int)(gSystemINI.m_sSystemDump.nDummyInterval/20*20),
										gSystemINI.m_sSystemDump.nDummyShot, 
										gSystemINI.m_sSystemDump.nDummyDuty);

	if(!bResult) 
		return FALSE;

	::Sleep(100);

	TDrillDummyShotPara tempPara;
	bResult = m_pDriver->Drill_GetDummyShotPara(&tempPara);

	if(!bResult) 
		return FALSE;

	if(tempPara.DummyShotData.Pos[0].x != m_DummyPos.Pos[0].x ||
		tempPara.DummyShotData.Pos[0].y != m_DummyPos.Pos[0].y ||
		tempPara.DummyShotData.Pos[1].x != m_DummyPos.Pos[1].x ||
		tempPara.DummyShotData.Pos[1].y != m_DummyPos.Pos[1].y ||
		(int)(gSystemINI.m_sSystemDump.nDummyInterval/20*20) != tempPara.nDummyShotInterval ||
		(UINT)gSystemINI.m_sSystemDump.nDummyDuty != tempPara.nDummyShotDuty_us ||
		(UINT)gSystemINI.m_sSystemDump.nDummyShot != tempPara.nMinDummyShotCnt)
		return FALSE;

	CString strFile, strLog;
	strFile.Format(_T("ReadHole"));

	strLog.Format(_T("Dump1 (%d, %d), Dump2 (%d, %d), DummyShot (%d), Frequency (%d), Interval (%d), Duty (%d), AOMDelay (%d), AOMDuty (%d) "), 
			gSystemINI.m_sSystemDump.nPtBeanDumper1.x,
			gSystemINI.m_sSystemDump.nPtBeanDumper1.y,
			gSystemINI.m_sSystemDump.nPtBeanDumper2.x,
			gSystemINI.m_sSystemDump.nPtBeanDumper2.y,
			gSystemINI.m_sSystemDump.nDummyShot,
			gSystemINI.m_sSystemDump.nDummyFreq,
			gSystemINI.m_sSystemDump.nDummyInterval,
			gSystemINI.m_sSystemDump.nDummyDuty,
			gSystemINI.m_sSystemDump.nDummyAOMDelay,
			gSystemINI.m_sSystemDump.nDummyAOMDuty);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));


	return TRUE;
*/
}

BOOL HEocard5Pusan1::IsSameHoleData(TDrillHoleData* DrillHoleData, int nCount)
{
	for(int i = 0; i < nCount; i++)
	{
		if(m_ptData[i].nToolNum != DrillHoleData[i].nToolNum)
			return FALSE;
		if(m_ptData[i].HolePos[0].x != DrillHoleData[i].HolePos[0].x)
			return FALSE;
		if(m_ptData[i].HolePos[0].y != DrillHoleData[i].HolePos[0].y)
			return FALSE;
		if(m_ptData[i].HolePos[1].x != DrillHoleData[i].HolePos[1].x)
			return FALSE;
		if(m_ptData[i].HolePos[1].y != DrillHoleData[i].HolePos[1].y)
			return FALSE;
	}
	return TRUE;
}

BOOL HEocard5Pusan1::SetInpositionCheckINI(BOOL bUseFile)
{
	if(!m_pDriver)
		return TRUE;

	m_UsedBeam.v = 0;
	m_UsedBeam.bit.beam1 = FALSE;
	m_UsedBeam.bit.beam2 = FALSE;
	m_UsedBeam.bit.beam3 = FALSE;
	m_UsedBeam.bit.beam4 = FALSE;

	if(bUseFile)
	{
		if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_1ST)
			m_UsedBeam.bit.beam1 = TRUE;
		if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_2ND)
			m_UsedBeam.bit.beam2 = TRUE;
		if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_3RD)
			m_UsedBeam.bit.beam3 = TRUE;
		if(gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_4TH)
			m_UsedBeam.bit.beam4 = TRUE;
	}
		

	return m_pDriver->ScanCfg_SetUsedBeam(&m_UsedBeam);

	return TRUE;
}

BOOL HEocard5Pusan1::StandbyParamSet()
{

	if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
	{
#ifndef __USE_DUALBAND_EOCARD__
		m_TDrillParam.nMinLmPeriod_us = 1000000 / gSystemINI.m_sSystemDump.nStandbyMaxFreq;		// shot�� �ּ� �ֱ�.	// 2011-09-28
		m_TDrillParam.nMaxLmPeriod_us = 1000000 / gSystemINI.m_sSystemDump.nStandbyMinFreq;		// shot�� �ִ� �ֱ�.
#endif
		m_TDrillParam.nStandbyLmPeriod_us = 1000000 / gSystemINI.m_sSystemDump.nStandbyInterval;	// standby ���¿��� LM period, �Ϲ������� nStandbyLmPeriod_us = (nMinLmPeriod_us + nMaxLmPeriod_us)/2
		m_TDrillParam.nStandbyLmOntime_us = gSystemINI.m_sSystemDump.nStandbyDuty;	// standby ���¿��� LM ontime
		m_TDrillParam.nError_EstInposTime_us = gSystemINI.m_sSystemDump.nStandbyInpositionTime;
	}
	else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
	{
#ifndef __USE_DUALBAND_EOCARD__
		m_TDrillParam.nMinLmPeriod_us = 1000000 / gSystemINI.m_sSystemDump.nStandbyMaxFreq2;		// shot�� �ּ� �ֱ�.	// 2011-09-28
		m_TDrillParam.nMaxLmPeriod_us = 1000000 / gSystemINI.m_sSystemDump.nStandbyMinFreq2;		// shot�� �ִ� �ֱ�.
#endif
		m_TDrillParam.nStandbyLmPeriod_us = 1000000 / gSystemINI.m_sSystemDump.nStandbyInterval2;	// standby ���¿��� LM period, �Ϲ������� nStandbyLmPeriod_us = (nMinLmPeriod_us + nMaxLmPeriod_us)/2
		m_TDrillParam.nStandbyLmOntime_us = gSystemINI.m_sSystemDump.nStandbyDuty2;	// standby ���¿��� LM ontime
		m_TDrillParam.nError_EstInposTime_us = gSystemINI.m_sSystemDump.nStandbyInpositionTime2;
	}

	m_TDrillParam.DumperPos.Pos[0].x = gSystemINI.m_sSystemDump.nPtBeanDumper1.x;
	m_TDrillParam.DumperPos.Pos[0].y = gSystemINI.m_sSystemDump.nPtBeanDumper1.y;
	m_TDrillParam.DumperPos.Pos[1].x = gSystemINI.m_sSystemDump.nPtBeanDumper2.x;
	m_TDrillParam.DumperPos.Pos[1].y = gSystemINI.m_sSystemDump.nPtBeanDumper2.y;

	if(!m_pDriver)
		return TRUE;

	return m_pDriver->Drill_SetParaAll(&m_TDrillParam);
}

BOOL HEocard5Pusan1::DrillStandbyShotStart(BOOL bStart, BOOL bUserStop)
{
	
	m_bStandbyShotRun = bStart;

	if(!m_pDriver)
		return TRUE;

//	if(gSystemINI.m_sSystemDump.nStandbyTime == 0)
//		return TRUE;

	BOOL bResult;
	bResult =  m_pDriver->Drill_SetStandbyDummyShotMode(bStart);

	if(!bStart)
	{
		bResult = bResult & m_pDriver->Cal_SetEnableEach(0, TRUE);
		bResult = bResult & m_pDriver->Cal_SetEnableEach(1, TRUE);
		if(bUserStop)
			m_StandbyTime.Finish();
	}
	else
	{
		if(bUserStop)
			m_StandbyTime.StartTime();
	}
	return bResult;

}
BOOL HEocard5Pusan1::DrillStandbyShotStartHole(BOOL bStart)
{
#ifndef __3RDAOD__
	return TRUE;
#else
	if(!m_pDriver)
		return TRUE;

	return m_pDriver->Drill_SetHole2HoleDummyShotMode(bStart);
#endif
}
int HEocard5Pusan1::IsStannbyShotRun()
{
	if(!m_pDriver)
		return m_bStandbyShotRun;
#ifndef __3RDAOD__

		BOOL bResult = m_pDriver->Drill_GetMonitor(&m_TMonitor);
		return m_TMonitor.bIsStandbyDummyShotMode;

#else
	BOOL bResult = m_pDriver->Drill_GetDummyShotMode(&m_TDummyMode);
	return m_TDummyMode.bUse_StandbyDummyShot + (m_TDummyMode.bUse_Hole2HoleDummyShot<<1 & 0x02);
#endif
}


BOOL HEocard5Pusan1::StartMarkDummy()
{
	if(gSystemINI.m_sSystemDump.nDummyShot == 0 || !m_pDriver)
		return TRUE;

	if(!m_pDriver->Cal_SetEnableEach(0, FALSE))
		return FALSE;
	if(!m_pDriver->Cal_SetEnableEach(1, FALSE))
		return FALSE;

	m_dDutyBackup = m_Parameter.dDuty;
	m_dAOMDelayBackup = m_Parameter.dAOMDelay;
	m_dAOMDutyBackup = m_Parameter.dAOMDuty;
	m_usFreqBackup = m_Parameter.Frequency;

	CString str;
	str.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	m_Parameter.Frequency = (unsigned int)(1000000 / gSystemINI.m_sSystemDump.nDummyInterval);
	m_Parameter.dDuty = gSystemINI.m_sSystemDump.nDummyDuty * 100;
	m_Parameter.dAOMDelay = gSystemINI.m_sSystemDump.nDummyAOMDelay;
	m_Parameter.dAOMDuty = gSystemINI.m_sSystemDump.nDummyAOMDuty;

	if(!m_pDriver->LaserPara_SetEach(EETSx_LMFreq_Hz, m_Parameter.Frequency, TRUE))
		return FALSE;
	if(!m_pDriver->LaserPara_SetEach(EETSx_LMDuty_us, m_Parameter.dDuty/100., TRUE))
		return FALSE;

	if(!DownloadAOMProfile(-1, -1, str, 0, 0, 0, 0, 0, 0, 0, 0, -1))
		return FALSE;

	TArrayPos3D pt3D;
	pt3D.Pos[0].x = gSystemINI.m_sSystemDump.nPtBeanDumper1.x;
	pt3D.Pos[0].y = gSystemINI.m_sSystemDump.nPtBeanDumper1.y;
	pt3D.Pos[1].x = gSystemINI.m_sSystemDump.nPtBeanDumper2.x;
	pt3D.Pos[1].y = gSystemINI.m_sSystemDump.nPtBeanDumper2.y;
	pt3D.Pos[2].x = gSystemINI.m_sSystemDump.nPtBeanDumper1.x;
	pt3D.Pos[2].y = gSystemINI.m_sSystemDump.nPtBeanDumper1.y;
	pt3D.Pos[3].x = gSystemINI.m_sSystemDump.nPtBeanDumper2.x;
	pt3D.Pos[3].y = gSystemINI.m_sSystemDump.nPtBeanDumper2.y;
	
	if(!m_pDriver->ScanCtrl_aJump4B(&pt3D))
		return FALSE;

	// sleep �ʿ�ġ �ʳ�?	// jhsho

	BOOL bBusy = TRUE;
	while(bBusy)
	{
		bBusy = IsDSPBusy();
	}

	if(!m_pDriver->LaserCtrl_LaserOnOff(TRUE))
	{
		m_pDriver->LaserCtrl_LaserOnOff(FALSE);
		return FALSE;
	}

	return TRUE;
}

BOOL HEocard5Pusan1::EndMarkDummy()
{
	if(gSystemINI.m_sSystemDump.nDummyShot == 0)
		return TRUE;

	if(m_pDriver == NULL)
		return TRUE;

	
	if(!m_pDriver->LaserCtrl_LaserOnOff(FALSE))
	{
		::Sleep(100);
		m_pDriver->LaserCtrl_LaserOnOff(FALSE);
		return FALSE;
	}

	if(m_nToolOldNo != -1)
	{
		if(!DownloadOneSubTool(m_nToolOldNo, m_subToolOld))
			return FALSE;
	}
	// laser qu�� ���� busy check�� �����Ǿ� ���� �����ϱ� sleep�� �ִ°� ����?	// jhsho
/*	CString str;
	str.Format(_T("%s"), m_Parameter.cAOMFilePath);
	m_Parameter.Frequency = m_usFreqBackup;
	m_Parameter.dDuty = m_dDutyBackup;
	m_Parameter.dAOMDelay = m_dAOMDelayBackup;
	m_Parameter.dAOMDuty = m_dAOMDutyBackup;

	if(!m_pDriver->LaserPara_SetEach(EETSx_LMFreq_Hz, m_Parameter.Frequency, TRUE))
		return FALSE;
	if(!m_pDriver->LaserPara_SetEach(EETSx_LMDuty_us, m_Parameter.dDuty/100., TRUE))
		return FALSE;

	if(!DownloadAOMProfile(-1, -1, str, 0, 0, 0, m_nAOMDutyOffsetBackup))
		return FALSE;
*/


	TArrayPos3D pt3D;
	pt3D.Pos[0].x = HALF_LSB;
	pt3D.Pos[0].y = HALF_LSB;
	pt3D.Pos[1].x = HALF_LSB;
	pt3D.Pos[1].y = HALF_LSB;
	pt3D.Pos[2].x = HALF_LSB;
	pt3D.Pos[2].y = HALF_LSB;
	pt3D.Pos[3].x = HALF_LSB;
	pt3D.Pos[3].y = HALF_LSB;
	
	if(!m_pDriver->ScanCtrl_aJump4B(&pt3D))
		return FALSE;

	BOOL bBusy = TRUE;
	while(bBusy)
	{
		bBusy = IsDSPBusy();
	}


	if(!m_pDriver->Cal_SetEnableEach(0, TRUE))
		return FALSE;
	if(!m_pDriver->Cal_SetEnableEach(1, TRUE))
		return FALSE;

/*	CCorrectTime myTime;
	myTime.StartTime();
	while(TRUE)
	{
		double dTime = myTime.PresentTime();
		if(dTime > 0.10)
			break;
	}
*/

	return TRUE;
}

BOOL HEocard5Pusan1::SetParameterCavityDuty(BOOL bShortLine)
{

	if(bShortLine)
		return m_pDriver->LaserPara_SetEach(EETSx_LMDuty_us, m_Parameter.dDuty/100. + gSystemINI.m_sHardWare.nShortLineDutyOffset, FALSE);
	else
		return m_pDriver->LaserPara_SetEach(EETSx_LMDuty_us, m_Parameter.dDuty/100., FALSE);

	return TRUE;
}

BOOL HEocard5Pusan1::SubDownloadReset(int nIndex)
{
	if(!m_pDriver)
		return FALSE;
	
	BOOL ret = m_pDriver->List_LoadSubr(nIndex);
	return ret;
}

BOOL HEocard5Pusan1::SubDownloadStop()
{
	if(!m_pDriver)
		return FALSE;
	
	BOOL ret = m_pDriver->List_SubReturn();
	return ret;
}

BOOL HEocard5Pusan1::SubCallStart(int nIndex, BOOL bDryrun)
{
	if(!m_pDriver)
		return FALSE;
	BOOL ret = m_pDriver->LaserCtrl_SetVirtualMode(bDryrun, FALSE);
	if(!ret)
		return FALSE;
	
	ret = m_pDriver->List_SubCall(nIndex);
	return ret;
}

double HEocard5Pusan1::GetDummyFreeStart()
{
	if(!IsStannbyShotRun())
		return 0;
	return m_StandbyTime.PresentTime();
}

BOOL HEocard5Pusan1::SetApplyCalibrationFile(int nBeam, BOOL bOn)
{	
//	if(!m_pDriver) // dummy free�� ���� �۵� �ȵ�.
		return TRUE;

//	if(GetApplyCalibrationFile(nBeam) == bOn)
//		return TRUE;

//	return m_pDriver->Cal_SetEnableEach(nBeam, bOn);
}	

BOOL HEocard5Pusan1::GetApplyCalibrationFile(int nBeam)
{
//	if(!m_pDriver)
		return TRUE;

//	UINT pBeam[4] = {0,};

//	m_pDriver->Cal_GetCalBeam(pBeam);
	
//	return pBeam[nBeam];

}

BOOL HEocard5Pusan1::SetVoltage(double d1st, double d2nd)
{
#ifdef __3RDAOD__
	return TRUE;
#endif

	if(!m_pDriver)
		return TRUE;

	BOOL bResult;
	
	if(d1st > 100.)
		d1st = 100.;
	else if(d1st < 0)
		d1st = 0;
	
	if(d2nd > 100.)
		d2nd = 100.;
	else if(d2nd < 0)
		d2nd = 0;
	
	bResult = m_pDriver->BoardDA_WriteOut(EETSx_WriteOut_DA2, d2nd);
	bResult = bResult & m_pDriver->BoardDA_WriteOut(EETSx_WriteOut_DA1, d1st);
	Sleep(10);
	return bResult;

}

BOOL HEocard5Pusan1::ChangeScannerAxis()
{
	if(!m_pDriver)
		return TRUE;
	// ETS5 Initialization
	EChannelCfg scanch[MAX_SCAN_CHANNEL] = {
		OUT_Beam1y, OUT_Beam1x, OUT_Beam2y, OUT_Beam2x,
			OUT_Beam3y, OUT_Beam3x, OUT_Beam4y, OUT_Beam4x
	};
	
	if(gSystemINI.m_sHardWare.nScannerAxisType == PX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType == NX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType == PX_NY ||
		gSystemINI.m_sHardWare.nScannerAxisType == NX_NY)
	{
		scanch[0] = OUT_Beam1x; scanch[1] = OUT_Beam1y;
		//		scanch[2] = OUT_Beam2x; scanch[3] = OUT_Beam2y;
	}
	
	if(gSystemINI.m_sHardWare.nScannerAxisType2 == PX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == NX_PY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == PX_NY ||
		gSystemINI.m_sHardWare.nScannerAxisType2 == NX_NY)
	{
		//		scanch[0] = OUT_Beam1x; scanch[1] = OUT_Beam1y;
		scanch[2] = OUT_Beam2x; scanch[3] = OUT_Beam2y;
	}
	

	return m_pDriver->BoardIO_SetChannel(EETSx_Scanner_Channel, scanch);
}

void HEocard5Pusan1::UpdateLPCCalibrationFile(CString strPath)
{
#ifndef __CUNGJU__
	return;
#endif
	CALHEAD calHead;

	TCHAR szSeps[] = _T(" \t\r\n");
	TCHAR *szNext;
	TCHAR szBuf[BUF_SIZE], *token = NULL;
	FILE* fp = NULL;
	CString strFileName(strPath + _T("LPC.table"));
	
	if (NULL == fopen_s(&fp, strFileName, _T("rb")))
	{
		if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
		{
			fclose(fp);
			return;
		}

		if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
		{
			fclose(fp);
			return;
		}
		int nTemp = atoi(token);
		if (nTemp < 2)
		{
			fclose(fp);
			return;
		}

		calHead.nGridX = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
		{
			fclose(fp);
			return;
		}

		nTemp = atoi(token);
		if (nTemp < 2)
		{
			fclose(fp);
			return;
		}

		calHead.nGridY = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
		{
			fclose(fp);
			return;
		}

		double dSize = atof(token);
		if (dSize < 1.0 || dSize > 1000.0)
		{
			fclose(fp);
			return;
		}

		calHead.dGap = dSize;

		DPOINT* dpOffset = NULL;
		TRY
		{
			dpOffset = new DPOINT[calHead.nGridX * calHead.nGridY];
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();

			fclose(fp);
			return;
		}
		END_CATCH

		double dX = 0.0, dY = 0.0, dXPos = 0.0, dYPos = 0.0, dXPosMin = 1000.0, dYPosMin = 1000.0;
		for (int i = 0; i < calHead.nGridX; i++)
		{
			for (int j = 0; j < calHead.nGridY; j++)
			{
				if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}

				if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dXPos = atof(token);

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dYPos = atof(token);

#ifndef __TEST__ 
				if (dXPos < 0.0 || dXPos > 1000.0 || dYPos < 0.0 || dYPos > 1000.0)
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
#endif

				if (dXPos < dXPosMin)	dXPosMin = dXPos;
				if (dYPos < dYPosMin)	dYPosMin = dYPos;

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dX = atof(token);

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return;
				}
				dY = atof(token);

//				if (fabs(dX) > 1.0 || fabs(dY) > 1.0)
//				{
//					fclose(fp);
//					delete [] dpOffset;
//					return;
//				}

				dpOffset[calHead.nGridY * i + j].x = dX;
				dpOffset[calHead.nGridY * i + j].y = dY;
			}
		}

		fclose(fp);

		calHead.dXStart = dXPosMin;
		calHead.dYStart = dYPosMin;
		calHead.dOffset = dpOffset;

		m_CalLPC->SetMatrixToZero();
		m_CalLPC->UpdateCalibration(calHead);
		delete [] dpOffset;
	}
}

#ifndef __LPC_FOR_3RD_AOD__
	TDrill_LPCMonitor* HEocard5Pusan1::GetLPCResult()
	{
	
		if(!m_pDriver)
			return NULL;
	#ifndef __CUNGJU__
		return NULL;
	#endif

		m_pDriver->Drill_GetLPCData(m_pLPC_Monitor);
		return m_pLPC_Monitor;

	}
#else
	TLpc_Buffer* HEocard5Pusan1::GetLPCResult()
	{
		return NULL;
	}
#endif
	
CPoint HEocard5Pusan1::GetDownHoleFirePos(int nIndex)
{
	CPoint cPoint;
	cPoint.x = cPoint.y = INT_MAX;
	return cPoint;
}

BOOL HEocard5Pusan1::SetLPCDataReadReady()
{
	return TRUE;
}

void HEocard5Pusan1::LoadLPCCalibrationFile(CString strPath)
{
#ifndef __CUNGJU__
	return;
#endif
	m_CalLPC->LoadCalibration(strPath);
}

BOOL HEocard5Pusan1::DownloadPowerLevel(unsigned int nToolNo, unsigned int nShotIndex, double dMinVal, double dMAxVal)
{
#ifndef __CUNGJU__
	return TRUE;
#endif
	
	if(!m_pDriver)
		return TRUE;

	#ifndef __NEW_STRUCTURE__
	BOOL bReturnVal;
	m_PtnInfo[nToolNo].PtnConfig.LPC_SetPara[nShotIndex].nLPC_SetMin = (ts16)dMinVal;			// us
	m_PtnInfo[nToolNo].PtnConfig.LPC_SetPara[nShotIndex].nLPC_SetMax = (ts16)dMAxVal;
	bReturnVal = m_pDriver->Drill_SetPtnConfig(nToolNo, &m_PtnInfo[nToolNo].PtnConfig);
	return bReturnVal;
	#else
		return TRUE;
	#endif


}

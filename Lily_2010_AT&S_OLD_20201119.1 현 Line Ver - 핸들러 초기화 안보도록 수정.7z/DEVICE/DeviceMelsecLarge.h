// DeviceMelsecLarge.h: interface for the DeviceMelsec class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVICEMELSECLARGE_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_)
#define AFX_DEVICEMELSECLARGE_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CorrectTime.h"
#include "MMelsecFx.h"

const int HANDLER_AXIS_MAX = 0x02;	

struct PLC_BIT_SIGNAL_FX
{
	//R1050
	WORD	bInputLoadBasket;				// 0 : R1050
	WORD	bOutputLoadBasket;				// 1 : R1051
	WORD	bInputUnlodBasket;				// 2 : R1052
	WORD	bOutputUnloadBasket;			// 3 : R1053
	WORD	bChangeDirection;				// 4 : R1054
	WORD	bDummyR1054;					// 
	WORD	wLoaderPos[2];					// 6 ~ 7 : R1056  
	WORD	wUnloaderPos[2];				// 8 ~ 9 : R1058 

	//R1060
	BYTE	bEStopAlarm:1;						// 0 : R1060.0
	BYTE	bPLCBATAlarm:1;						// 1 : R1060.1
	BYTE	bAirDownAlarm:1;					// 2 : R1060.2
	BYTE	bDoorOpenAlarm:1;					// 3 : R1060.3
	BYTE	bAxis1DriveAlarm:1;					// 4 : R1060.4
	BYTE	bAxis2DriveAlarm:1;					// 5 : R1060.5
	BYTE	bAxis3DriveAlarm:1;					// 6 : R1060.6
	BYTE	bAxis1ControlAlarm:1;				// 7 : R1060.7
	BYTE	bAxis2ControlAlarm:1;				// 8 : R1060.8
	BYTE	bAxis3ControlAlarm:1;				// 9 : R1060.9 
	BYTE	bLoadLeftPicker1UpDownCYLAlarm:1;	// 10 : R1060.A
	BYTE	bLoadLeftPicker2UpDownCYLAlarm:1;	// 11 : R1060.B
	BYTE	bLoadLeftPickerVacuumAlarm:1;		// 12 : R1060.C
	BYTE	bLoadRightPicker1UpDownCYLAlarm:1;	// 13 : R1060.D
	BYTE	bLoadRightPicker2UpDownCYLAlarm:1;	// 14 : R1060.E
	BYTE	bLoadRightPickerVacuumAlam:1;		// 15 : R1060.F

	//R1061
	BYTE	bLoadUnloadCollisionAlarm:1;		// 0 : R1061.0 
	BYTE	bDummyR1061_2:1;					// 1
	BYTE	bLAlignTableForBackAlarm:1;			// 2 : R1061.2
	BYTE	bLAlign1LeftAlarm:1;				// 3 : R1061.3
	BYTE	bLAlign1FrontAlarm:1;				// 4 : R1061.4
	BYTE	bLAlignPalteAlarm:1;				// 5 : R1061.5
	BYTE	bLAlignROnOffAlarm:1;				// 6 : R1061.6
	BYTE	bLCardLockAlarm:1;					// 7 : R1061.7
	BYTE	bLLifterAlarm:1;					// 8 : R1061.8
	BYTE	bDummyR1061_9:1;					// 9
	BYTE	bLNGTableForBackAlarm:1;			// 10 : R1061.A
	BYTE	bLPaperTableForBackAlarm:1;			// 11 : R1061.B
	BYTE	bDummyR1061_12:1;					// 12
	BYTE	bDummyR1061_13:1;					// 13
	BYTE	bUnloadLeftPicker1UpDownCYLAlarm:1;	// 14 : R1061.E
	BYTE	bUnloadLeftPicker2UpDownCYLAlarm:1;	// 15 : R1061.F

	// R1062
	BYTE	bUnloadLeftPickerVacuumAlarm:1;		// 0 : R1062.0
	BYTE	bUnloadRightPicker1UpDownCYLAlarm:1;// 1 : R1062.1
	BYTE	bUnloadRightPicker2UpDownCYLAlarm:1;// 2 : R1062.2
	BYTE	bUnloadRightPickerVacuumAlam:1;		// 3 : R1062.3
	BYTE	bDummyR1062_4:1;					// 4 
	BYTE	bDummyR1062_5:1;					// 5
	BYTE	bUAlignTableForBackAlarm:1;			// 6 : R1062.6
	BYTE	bUAlign1LeftAlarm:1;				// 7 : R1062.7
	BYTE	bUAlign1FrontAlarm:1;				// 8 : R1062.8
	BYTE	bUAlignPalteAlarm:1;				// 9 : R1062.9
	BYTE	bUAlignROnOffAlarm:1;				// 10 : R1062.A
	BYTE	bUCardLockAlarm:1;					// 11 : R1062.B
	BYTE	bULifterAlarm:1;					// 12 : R1062.C
	BYTE	bDummyR1062_13:1;					// 13
	BYTE	bUNGTableForBackAlarm:1;			// 14 : R1061.E
	BYTE	bUPaperTableForBackAlarm:1;			// 15 : R1061.F

	// R1063
	BYTE	bTurnTableForBackAlarm:1;			// 0 : R1063.0
	BYTE	bTurnTableUpDownAlarm:1;			// 1 : R1063.1
	BYTE	bTurnTableVacuumAlarm:1;			// 2 : R1063.2
	BYTE	bLoadLeftPickerPCBAlarm:1;			// 3 : R1063.3
	BYTE	bLoadRightPickerPCBAlarm:1;			// 4 : R1063.4 
	BYTE	bUnloadLeftPickerPCBAlarm:1;		// 5 : R1063.5
	BYTE	bUnloadRightPickerPCBAlarm:1;		// 6 : R1063.6
	BYTE	bLoadPosAlarm:1;					// 7 : R1063.7 
	BYTE	bUnloadPosAlarm:1;					// 8 : R1063.8
	BYTE	bLoadBoxNoExist:1;					// 9 
	BYTE	bUnloadBoxNoExist:1;				// 10
	BYTE	bNoUsePaperLoadPaper:1;				// 11
	BYTE	bNoUsePaperUnloadPaper:1;			// 12
	BYTE	bPaperNoExist:1;					// 13
	BYTE	bPaperBoxFull:1;					// 14
	BYTE	NGBoxFull:1;						// 15

	WORD    wDummyR1064_1069[6];

	WORD	bLoadSafePos;						// R1070
	WORD	bUnloadSafePos;						// R1071
	WORD	bLdElvPCBExist;						// R1072
	WORD	bStartMode;							// R1073
	WORD	bPCBDownDanger;						// R1074
};

class DeviceMelsecLarge : public CWnd  
{
public:
	static  UINT ThreadStatus(LPVOID pParam);
	static UINT ThreadInPosition(LPVOID pParam);
	BOOL Initialize();
	DeviceMelsecLarge();
	virtual ~DeviceMelsecLarge();

protected:
	CWinThread*		m_thdStatus;
	int				m_nAxisMax;
	LONG			m_lErrorHandlerMain;
	LONG			m_lErrorHandlerLoader;
	LONG			m_lErrorHandlerUnloader;
	LONG			m_lErrorHandlerEtc1;
	LONG			m_lStatusBasket;

public:
	BOOL SetNoUseSuction(BOOL bNoUse);
	BOOL Set2DBarcodeTrigger();
	BOOL SetVibration(int nCount);
	BOOL SetNGPanel(int nNG);
	BOOL ResetBasketInfo(BOOL bLoad);
	BOOL SetOutputBasket(BOOL bLoad);
	BOOL SetUseNGBox(BOOL bUse);
	BOOL SetUsePaperBox(BOOL bUse);
	BOOL SetTrunPanel(BOOL bTurn);
	BOOL SetReverseDirection(BOOL bChange);
	BOOL GetUnloadBasketSignal(BOOL bIn);
	BOOL GetLoadBasketSignal(BOOL bIn);
	BOOL GetReverseDirection();
	BYTE GetBasketIn();
	

	BOOL CheckMelsecConnect();
	void ReadStautsOther();
	BOOL IsUPVacuum(BOOL b1st, BOOL bOn);
	BOOL IsLPVacuum(BOOL b1st, BOOL bOn);
	BOOL SetPickerVacuum(BOOL bLoader, BOOL b1st, BOOL bOn);
	BOOL IsHandlerTablePCBExist(BOOL bLoader);
	BOOL IsHandlerPaperTransPCBExist(BOOL bLoader);
	BOOL IsHandlerPartError(BOOL bLoader);

	int GetWritePos(int nAxis);
	int GetCurrentPos(int nAxis);
	void GetBitSiganl(PLC_BIT_SIGNAL_FX* pData);
	int GetAxisMax();
	
	MMelsecFx*		m_pMelsec;

	BOOL IsHandlerBusy(int nAxis);
	BOOL IsHandlerStop(int nAxis);	

	BOOL IsReady(int nAxis = -1);
	int IsInOrigin(int nAxis = -1, BOOL bWait = TRUE);
	int IsInPosition(int nAxis = -1, BOOL bWait = TRUE);
	BOOL InPositionStop();
	BOOL PeekMessage();
	BOOL IsMotorOrigin(int nAxis);
	BOOL IsMoveEnd(int nAxis = -1);
	BOOL IsMotorStop(BOOL bFlag =TRUE);
	BOOL GetPosition(int nAxis, double& dPosition);
	BOOL SetAxisMax(int nAxisMax);
	DWORD GetIntPosition(double dPos, int nAxis);

	void ReadStatus(BOOL bFirst);
	void ReadBasket();
	void ReadPosition();
	void ReadErrorHandlerMain();
	void ReadErrorHandlerLoader();
	void ReadErrorHandlerUnloader();
	void ReadErrorHandlerEtc1();

	
	LONG GetCurrentError(ERRORCOMMAND nError);

	BOOL IsUnloadertoLoadStart();
	BOOL IsAligner(BOOL bStop = TRUE);
	BOOL IsUnload(BOOL bStop = TRUE);
	BOOL IsLoader(BOOL bStop = TRUE);

	BOOL IsLoaderPicker1PCBExist();
	BOOL IsLoaderPicker2PCBExist();
	BOOL IsUnloaderPicker1PCBExist();
	BOOL IsUnloaderPicker2PCBExist();
	BOOL IsResetSwitch();
	BOOL IsSystemDoorBypass(BOOL bLoader);
	BOOL IsAnyMotorRun();
	BOOL IsLoadCartNoPCB();
	BOOL SendLoadCartNoPCB();

	BOOL SetOutPort(BYTE nPortNo, WORD wOnOff);

	BOOL LoaderAlign();
	BOOL LoaderLoading();
	BOOL UnloadUnloading();
	BOOL LoaderInit();
	BOOL UnloaderInit();
	BOOL LoaderAlignLoading();
	
	BOOL MainReset(BOOL bOn);
	BOOL UnloaderPCBReset();
	BOOL LoaderPCBReset();

	BOOL LoaderCarrierElvPos();
	BOOL LoaderCarrierTablePos();
	BOOL UnloaderCarrierElvPos();
	BOOL UnloaderCarrierTablePos();

	BOOL LoaderPickerUpPos(int nNum);
	BOOL UnloaderPickerUpPos(int nNum);

	BOOL UseRoll(BOOL bUse);
	BOOL UsePaper(BOOL bUse);

	// no use func
	BOOL LoaderClampForward();
	BOOL LoaderClampBackward();
	BOOL LoaderTableForward();
	BOOL LoaderTableBackward();
	BOOL LoaderAlignXForward();
	BOOL LoaderAlignXBackward();
	BOOL LoaderAlignYForward();
	BOOL LoaderAlignYBackward();
	BOOL UnloaderClampForward();
	BOOL UnloaderClampBackward();
	BOOL UnloaderTableForward();
	BOOL UnloaderTableBackward();
	BOOL IsLoaderAlignTableForward();
	BOOL IsUnloaderAlignTableForward();
	BOOL IsLoaderCartClamp();
	BOOL IsAlignSheetTableForward();
	BOOL IsAlignGuideForward();
	BOOL IsUnloaderCartClamp();
	BOOL IsUnloaderNGBoxForward();
	BOOL IsUnloaderNGBoxBackward();
	BOOL UnloaderNGBoxForward();
	BOOL UnloaderNGBoxBackward();
	BOOL IsStartMode();
	BOOL m_bStatusStop; // Thread Stop Signal
	PLC_BIT_SIGNAL_FX GetMelsecIOStuct();
	
	PLC_BIT_SIGNAL_FX	m_NewPLCBitSignal;
	PLC_BIT_SIGNAL_FX	m_OldPLCBitSignal;

	long			m_lWritePos[HANDLER_AXIS_MAX];
	BOOL			m_bIsInPosition[HANDLER_AXIS_MAX];
	double			m_dScale[HANDLER_AXIS_MAX];
	BOOL			m_bCommandStop;
	BYTE			m_nInPositionCommand;	// Thread Stop Signal
	int				m_nInPositionAxis;		// Thread InPosition Axis
	int				m_nIsInPosition;		// Thread Stop Signal
	CCorrectTime	m_pStopTime;

	int				m_nInPositionCount;
	int				m_nInPositionError;

	int				m_nInposTimeCount;
	int				m_nPosition[2]; //load unload pos
	BOOL			m_bConnect;
};

#endif // !defined(AFX_DEVICEMELSECLARGE_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_)

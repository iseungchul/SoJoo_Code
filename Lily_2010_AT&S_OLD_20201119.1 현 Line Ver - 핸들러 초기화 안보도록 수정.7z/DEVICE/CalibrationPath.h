// CalibrationPath.h: interface for the CCalibrationPath class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CALIBRATIONPATH_H__F48339EF_F862_486B_841F_C09549F2060F__INCLUDED_)
#define AFX_CALIBRATIONPATH_H__F48339EF_F862_486B_841F_C09549F2060F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

enum emHorDir {emLeft, emRight};
enum emVerDir {emTop, emBottom};
enum emDirection {emHor, emVer};

class CCalibrationPath  
{
public:
	CCalibrationPath();
	virtual ~CCalibrationPath();

	BOOL SetCalibrationGridSize(int nSize);
	BOOL GetClosestLSB(USHORT xPos, USHORT yPos, USHORT& xLSB, USHORT& yLSB);
	int GetClosestLSBIndex(USHORT xPos, USHORT yPos);
	BOOL SetCalibrationGridIndex(int nIndex);
	BOOL SetCalibrationGridIndex(double x, double y);
	BOOL GetFirstLSB(USHORT& x, USHORT& y);
	BOOL GetNextLSB(USHORT& x, USHORT& y);
	//BOOL GetNextLSBXYORDER(USHORT& x, USHORT& y, int nDivision, int nIndex, int nXYORDER); // yhchung 060802
	BOOL GetNextLSBXYORDER_Use_vm(double & x, double& y, int nDivision, int nIndex, int nXYORDER);
	int GetIndex(int nx, int ny);
	BOOL GetIndex(int nIndex, int& nx, int& ny);
	BOOL GetLSB(int nx, int ny, USHORT& x, USHORT& y);

private:
	void InitializeVariable();

	BOOL IsSpecialPoint(int nIndex);
	void SetNextLSBIndexInSpecial();
	BOOL IsTurningPoint(int nIndex);
	void SetNextLSBIndexInTurning();
	void SetNextLSBIndexInNormal();
	double Distance(double x1, double y1, double x2, double y2);

	emDirection m_emDirection;
	emHorDir m_emHorDir;
	emVerDir m_emVerDir;

	USHORT* m_pusVal;
	int m_nCurIndex;
	int m_nMaxIndex;
	int m_nSize;

	int m_nSpecialPointType;
	int m_nTurningPointType;

	bool m_bReady;
};

#endif // !defined(AFX_CALIBRATIONPATH_H__F48339EF_F862_486B_841F_C09549F2060F__INCLUDED_)

// DSysErr.h: interface for the DSysErr class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DSYSERR_H__A8B155CE_CA03_49AF_B6B5_758B1E5BDF2B__INCLUDED_)
#define AFX_DSYSERR_H__A8B155CE_CA03_49AF_B6B5_758B1E5BDF2B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DSysErr  
{
public:
	DSysErr();
	virtual ~DSysErr();

	// M7016. $60210
	BOOL	m_bDoorInterlock;
	BOOL	m_bInitialReq;
	BOOL	m_bSysAirLow;
	BOOL	m_bStageAirLow;
	BOOL	m_bSysVacuumLow;
	BOOL	m_bN2GasLow;
	BOOL	m_bPolygonAirLow;
	BOOL	m_bN2TankAirLow;
	BOOL	m_bMpgOnStatus;
	BOOL	m_bGripperCatch;
	BOOL	m_bLPickerWaferCatch;
	BOOL	m_bBPickerWaferCatch;
	BOOL	m_bWaferExistRailInit;
	BOOL	m_bWaferOverload;
	BOOL	m_bAlignRailWafer;

	// M7017. $60211
	BOOL	m_bCoaterWaferCheck;
	BOOL	m_bStageWaferCheck;
	BOOL	m_bBufferWaferCheck;
	BOOL	m_bOmit8InchCassette;
	BOOL	m_bOmit12InchCassette;
	BOOL	m_bServoPower;
	BOOL	m_bEmgSw;
	BOOL	m_bPolygonAmpFault;
	BOOL	m_bPolygonOpenLoop;
//	BOOL	m_bTableVacuumOn;
//	BOOL	m_bTableVacuumOff;
	BOOL	m_bPickerWafer;
	BOOL	m_bIncorrectPickerWaferSize;
	BOOL	m_bGripperCatchWaferErr;

	// M7096. $60260
	BOOL	m_bGripperCylinderFw;
	BOOL	m_bGripperCylinderBw;
	BOOL	m_bBufferAlignerCylinderFw;
	BOOL	m_bBufferAlignerCylinderBw;
	BOOL	m_bLaserShutterCylinderFw;
	BOOL	m_bLaserShutterCylinderBw;
	BOOL	m_bPickerZCylinderFw;
	BOOL	m_bPickerZCylinderBw;
	BOOL	m_bPickerWaferSizeFw;
	BOOL	m_bPickerWaferSizeBw;

	// M7099. $60263
//	BOOL	m_bCoaterDoorCylinderFw;
//	BOOL	m_bCoaterDoorCylinderBw;

	// M7100. $60264
	BOOL	m_bSpinThetaSpeed;
	BOOL	m_bCoater;
	BOOL	m_bArmMotionErr;
	BOOL	m_bSpinThetaVacuum;
	BOOL	m_bTankEmpty;
	BOOL	m_bCoaterWaterLeak;

	// M7101. $60265
	BOOL	m_bInit;
	BOOL	m_bScanCassette;
	BOOL	m_bCassetteToAligner;
	BOOL	m_bAlignerToCassette;
	BOOL	m_bAlignerToLPicker;
	BOOL	m_bLPickerToCoater;
	BOOL	m_bCoaterToLPicker;
	BOOL	m_bLPickerToChuck;
	BOOL	m_bChuckToLPicker;
	BOOL	m_bLPickerToAligner;
	BOOL	m_bLPickerToBuffer;
	BOOL	m_bBufferToBPicker;
	BOOL	m_bBPickerToChuck;
	BOOL	m_bCoating;
	BOOL	m_bCleaning;

	// M7102. $60266
	BOOL	m_bAlignRailZone;
	BOOL	m_bCoaterZone;
	BOOL	m_bLPickerZone;
	BOOL	m_bBufferZone;
	BOOL	m_bStageZone;
	BOOL	m_bBufferPickerZone;
};

#endif // !defined(AFX_DSYSERR_H__A8B155CE_CA03_49AF_B6B5_758B1E5BDF2B__INCLUDED_)

// DevLaserPower.h: interface for the CDevLaserPower class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVLASERPOWER_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_)
#define AFX_DEVLASERPOWER_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "AsyncComm.h"

class CDevLaserPower : public CAsyncComm  
{
protected:
  	CRITICAL_SECTION	m_csCommunicationSync;

public:
	void FireReceived(void);
	virtual void ProcessMonitor(void);
	char* QueryCommand(char* szCmd);
	virtual void Destroy(void);
	virtual BOOL Create(void);
	CDevLaserPower();
	virtual	~CDevLaserPower();

    CAssEvent FReceiveEvent;

	void SetParameter(int nPortNo, int nBaudRate, int nParity, int nDataBits, int nStopBits, int nFlowControl);

	int m_nPortNo;
	int m_nBaudRate;
	int m_nParity;
	int m_nDataBits;
	int m_nStopBits;
	int m_nFlowControl;
};

#endif // !defined(AFX_DEVLASERPOWER_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_)

// HVisionOmi.cpp: implementation of the HVisionOmi class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "HVisionOmi.h"
#include "..\model\DSystemINI.h"
#include "..\model\DProcessINI.h"
#include "..\device\ClientSock.h"
#include <math.h>
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

// Vision constants
//const short SCREEN_PIXEL_X		= 574;
//const short SCREEN_PIXEL_Y		= 760;
const short CENTER_X			= static_cast<short>(SCREEN_PIXEL_X / 2);
const short CENTER_Y			= static_cast<short>(SCREEN_PIXEL_Y / 2);

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#ifndef USE_VISION_PRO
/*	AcuObjMan		gAcuObjMan(0);

	AcuImage		gAcuImage0(_T("Image00"));
	AcuImage		gAcuImage1(_T("Image01"));
	AcuImage		gAcuImage2(_T("Image02"));
	AcuImage		gAcuImage3(_T("Image03"));

	AcuDisplay		gAcuDisplay0(_T("Display00"));
	AcuDisplay		gAcuDisplay1(_T("Display01"));
	AcuDisplay		gAcuDisplay2(_T("Display02"));
	AcuDisplay		gAcuDisplay3(_T("Display03"));

	AcuOverlay		gAcuOverlay0(_T("Overlay00"));
	AcuOverlay		gAcuOverlay1(_T("Overlay01"));
	AcuOverlay		gAcuOverlay2(_T("Overlay02"));
	AcuOverlay		gAcuOverlay3(_T("Overlay03"));

	AcuArea			gAcuArea0(_T("Area00"));
	AcuArea			gAcuArea1(_T("Area01"));
	AcuArea			gAcuArea2(_T("Area02"));
	AcuArea			gAcuArea3(_T("Area03"));

	AcuFidTool		gAcuFidTool0(_T("FIDTool00"));
	AcuFidTool		gAcuFidTool1(_T("FIDTool01"));
	AcuFidTool		gAcuFidTool2(_T("FIDTool02"));
	AcuFidTool		gAcuFidTool3(_T("FIDTool03"));
*/
#endif
/*
	BOOL	LoadOmiProject(CString strDir);			   == LOMIP@strDir
	void	InitOmiVision();						   == INITV
	void	OnConnectView();						   == OCONV
	void	OnCamChange(int nCamNo);				   == OCAMC@nCamNo
	void	OnAcquire(int nCamNo);					   == OACQR@nCamNo
	void	OnContrast(int nCamNo, double dContrast);									== OCONT@nCamNo@dContrast
	void	OnBrightness(int nCamNo, double dBrightness);								== OBRIT@nCamNo@dBrightness
	void	SaveImg(int nCamNo, CString strFilePathName);								== SAVEI@nCamNo@strFilePathName
	BOOL	GetIsLive()				{ return m_bIsLive; }								== GISLV
	void	OnLive(int nCamNo, BOOL bIsLive);											== OLIVE@nCamNo@bIsLive
	void	OnApplyVisionParam(int nCamNo, SVISIONINFO sVisionInfo);					== OAPVP@nCamNo@sVisionInfo(*)
	void	OnApplyVisionParameter(int nCamNo, VISION_INFO sVisionInfo);				== OAVPM@nCamNo@sVisionInfo(*)
	BOOL	OnFindFiducial(int nCamNo, CString& strMsg);								== OFINF@nCamNo@strMsg
	void	OnLight(int nCamNo, int nType, int nVal);									== OLIGT@nCamNo@nType@nVal
	void	SetVisionZoom(int nCamNo, int nZoom=50);									== SVZUM@nCamNo@nZoom
	void	SetPixel(int nCamNo, DPOINT dPixel);										== SPIXL@nCamNo@dPixel(*)
	
	BOOL	GetRealPos(DPOINT* rPos, int nCam, BOOL bRefresh, double& dSize, char* pChar = NULL);	= GRLPS
	
	void	ShowArea(int nShow);														== SAREA@nShow
	void	SetInspectionArea(int nSize);												== SINPA@nSize
*/
HVisionOmi::HVisionOmi()
{
//	for(int i = 0 ; i < 4 ; i++ )
//	{
//		m_pVisionView[i]			= NULL;
//		m_nZoom[i]					= 50;
//		m_nCross[i]					= -1;
//		m_nLive[i]					= -1;
//	}
//	m_bIsLive				= FALSE;
//	m_dResultSize			= 0.;
//	m_dSizeAMin				= -1.;
//	m_dSizeAMax				= -1.;
//	m_dSizeBMin				= -1.;
//	m_dSizeBMax				= -1.;
//	m_dSizeCMin				= -1.;
//	m_dSizeCMax				= -1.;
//	m_nCam					= 0;
//	m_pLiveThread			= NULL;
//	memset( &m_sVisionInfo, 0, sizeof(m_sVisionInfo) );
	// 0 : 1st Low, 1 : 1st High, 2 : 2nd Low, 3 : 2nd High
/*	memset( &m_dPixel, 0, sizeof(m_dPixel) );
	memset( &m_dPos, 0, sizeof(m_dPos) );

	m_dPixel[0].x	= 0.001051323140748;
	m_dPixel[0].y	= 0.00102964043319;

	m_dPixel[1].x	= 0.0052504013832101;
	m_dPixel[1].y	= 0.0051484632291575;

	m_dPixel[2].x	= 0.0010506041884817;
	m_dPixel[2].y	= 0.0010273003412969;

	m_dPixel[3].x	= 0.0052532614922443;
	m_dPixel[3].y	= 0.0051219471406591;
*/
//	m_evtUseOmiVision.SetEvent();

//	m_clsLamp = NULL;
	m_pClientSock = NULL;
	m_pVisionHndle	= NULL;
	if(CWnd::FindWindowA(NULL, _T("OmiVisionCom_TCP_IP")) == NULL)
	{
		ShellExecute(NULL, _T("open"), _T("D:\\viahole\\OmiVisionCom.exe"), NULL, NULL, SW_HIDE);
		Sleep(300);
	}
	while(m_pVisionHndle == NULL)
	{
		m_pVisionHndle = CWnd::FindWindowA(NULL, _T("OmiVisionCom_TCP_IP"));
		Sleep(100);
	}

	m_pVisionHndle->ShowWindow(SW_HIDE);
	SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
	ConnectOmiVision();
}

HVisionOmi::~HVisionOmi()
{
	if(m_pClientSock != NULL)
	{
		delete m_pClientSock;
		m_pClientSock = NULL;
	}
//	if(m_clsLamp != NULL)
//	{
//		delete m_clsLamp;
//		m_clsLamp = NULL;
//	}

//	if(m_pLiveThread)
//	{
//		::WaitForSingleObject(m_pLiveThread->m_hThread, INFINITE);
//
//		delete m_pLiveThread;
//		m_pLiveThread = NULL;
//	}
}

void HVisionOmi::SetOmiView(int nCamNo, COmiView* pView)
{
	m_pVisionView[nCamNo] = pView;
}

void HVisionOmi::SetPixel(int nCamNo, DPOINT dPixel)
{
//	m_dPixel[nCamNo].x	= dPixel.x;
//	m_dPixel[nCamNo].y	= dPixel.y;
	CString strOrder = _T("");
	strOrder.Format(_T("SPIXL@%d@%f@%f"), nCamNo, dPixel.x, dPixel.y);
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("SPIXL"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("SPIXL"));
		nCount++;
	}
	if(!bReturn)
		ErrMessage(_T("Set Pixel Fail(TCP/IP)"));
}

BOOL HVisionOmi::LoadOmiProject(CString strDir)
{

#ifndef USE_VISION_PRO
/*	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );

	BOOL bRet = 0;

	CString strOmiName;

	strOmiName.Format(_T("%sstandard.omi"), strDir);

	bRet = gAcuObjMan.LoadProject( (LPSTR)(LPCTSTR)strOmiName );

	if( TRUE != bRet )
	{
		//ErrMessage(_T("Can not open omi project file"), MB_ICONSTOP);

		return FALSE;
	}

	m_evtUseOmiVision.SetEvent();
*/
	CString strOrder = _T("LOMIP@") + strDir ;
	m_pClientSock->Send(strOrder, strlen(strOrder));
	return GetTcpIpResult(_T("LOMIP"));
#endif

	return TRUE;
}

void HVisionOmi::InitOmiVision()
{

#ifndef USE_VISION_PRO
/*	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );
	
	if(m_clsLamp == NULL)
	{
		TRY
		{
			m_clsLamp = new MVisionLamp();
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();
			return;
		}
		END_CATCH

		if(gSystemINI.m_sHardWare.nUseLampRS232)
			m_clsLamp->SetComPort(gSystemINI.m_sSystemDevice.nLampComport);
#ifndef __TEST__
		if(gSystemINI.m_sHardWare.nUseLampRS232)
			m_clsLamp->ConectComPort();
#endif
	}

	DPOINT dLivePos;

	// Image0
	gAcuImage0.SetVideoFormatNum(1);
	
	// Zoom 1
	gAcuDisplay0.View.SetZoom( (long)m_nZoom[0] );
	gAcuDisplay0.View.Apply();

	// Overlay 1
	gAcuOverlay0.CreateItem(&m_nCross[0]);
	gAcuOverlay0.CreateItem(&m_nLive[0]);
	gAcuOverlay0.SetCrossItem(m_nCross[0], -9, 0, CENTER_X, CENTER_Y, CENTER_X * 2, CENTER_Y * 2, 0);
	GetLivePos(m_nZoom[0], &dLivePos);
	if( FALSE == m_bIsLive )
		gAcuOverlay0.SetStringItem(m_nLive[0], -11, 0, CENTER_X + dLivePos.x, CENTER_Y, -13, _T(""));
	else
		gAcuOverlay0.SetStringItem(m_nLive[0], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
	///////////////////////////////////////////////////////////////////////////////////////////////////

	// Area 1
	gAcuArea0.SetCoor(0, 0, SCREEN_PIXEL_X, SCREEN_PIXEL_Y);
	gAcuArea0.Show(2);
	////////////////////////////////////////////////////////

	// Image 2
	gAcuImage1.SetVideoFormatNum(1);

	// Zoom 2
	gAcuDisplay1.View.SetZoom( (long)m_nZoom[1] );
	gAcuDisplay1.View.Apply();

	// Overlay 2
	gAcuOverlay1.CreateItem(&m_nCross[1]);
	gAcuOverlay1.CreateItem(&m_nLive[1]);
	gAcuOverlay1.SetCrossItem(m_nCross[1], -9, 0, CENTER_X, CENTER_Y, CENTER_X * 2, CENTER_Y * 2, 0);
	GetLivePos(m_nZoom[1], &dLivePos);
	if( FALSE == m_bIsLive )
		gAcuOverlay1.SetStringItem(m_nLive[1], -11, 0, CENTER_X + dLivePos.x, CENTER_Y, -13, _T(""));
	else
		gAcuOverlay1.SetStringItem(m_nLive[1], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
	///////////////////////////////////////////////////////////////////////////////////////////////////

	// Area 2
	gAcuArea1.SetCoor(SCREEN_PIXEL_X/4, SCREEN_PIXEL_Y/4, SCREEN_PIXEL_X/2, SCREEN_PIXEL_Y/2);
	gAcuArea1.Show(2);
	////////////////////////////////////////////////////////

	// Image 3
	gAcuImage2.SetVideoFormatNum(1);

	// Zoom 3
	gAcuDisplay2.View.SetZoom( m_nZoom[2] );
	gAcuDisplay2.View.Apply();

	// Overlay 3
	gAcuOverlay2.CreateItem(&m_nCross[2]);
	gAcuOverlay2.CreateItem(&m_nLive[2]);
	gAcuOverlay2.SetCrossItem(m_nCross[2], -9, 0, CENTER_X, CENTER_Y, CENTER_X * 2, CENTER_Y * 2, 0);
	GetLivePos(m_nZoom[2], &dLivePos);
	if( FALSE == m_bIsLive )
		gAcuOverlay2.SetStringItem(m_nLive[2], -11, 0, CENTER_X + dLivePos.x, CENTER_Y, -13, _T(""));
	else
		gAcuOverlay2.SetStringItem(m_nLive[2], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
	///////////////////////////////////////////////////////////////////////////////////////////////////

	// Area 3
//	gAcuArea2.SetCoor(SCREEN_PIXEL_X/4, SCREEN_PIXEL_Y/4, SCREEN_PIXEL_X/2, SCREEN_PIXEL_Y/2);
	gAcuArea2.SetCoor(0, 0, SCREEN_PIXEL_X, SCREEN_PIXEL_Y);
	gAcuArea2.Show(2);
	////////////////////////////////////////////////////////

	// Image 4
	gAcuImage3.SetVideoFormatNum(1);

	// Zoom 4
	gAcuDisplay3.View.SetZoom( m_nZoom[3] );
	gAcuDisplay3.Apply();

	// Overlay 4
	gAcuOverlay3.CreateItem(&m_nCross[3]);
	gAcuOverlay3.CreateItem(&m_nLive[3]);
	gAcuOverlay3.SetCrossItem(m_nCross[3], -9, 0, CENTER_X, CENTER_Y, CENTER_X * 2, CENTER_Y * 2, 0);
	GetLivePos(m_nZoom[3], &dLivePos);
	if( FALSE == m_bIsLive )
		gAcuOverlay3.SetStringItem(m_nLive[3], -11, 0, CENTER_X + dLivePos.x, CENTER_Y, -13, _T(""));
	else
		gAcuOverlay3.SetStringItem(m_nLive[3], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
	///////////////////////////////////////////////////////////////////////////////////////////////////

	// Area 4
//	gAcuArea3.SetCoor(0, 0, SCREEN_PIXEL_X, SCREEN_PIXEL_Y);
	gAcuArea3.SetCoor(SCREEN_PIXEL_X/4, SCREEN_PIXEL_Y/4, SCREEN_PIXEL_X/2, SCREEN_PIXEL_Y/2);
	gAcuArea3.Show(2);
	////////////////////////////////////////////////////////
	
	m_evtUseOmiVision.SetEvent();
//	if(m_pLiveThread == NULL)
//		m_pLiveThread = ::AfxBeginThread(LiveThread, this);
*/
	CString strOrder = _T("INITV");
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("INITV"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("INITV"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("OMI Vision Initial Fail(TCP/IP)"));
	}

	
#endif

}

void HVisionOmi::GetLivePos(int nZoom, DPOINT* pPos)
{
	if( 25 == nZoom )
	{
		pPos->x = 200.0f;
		pPos->y = -45.0f;
	}
	else
	{
		pPos->x = ( 50.0 * (CENTER_X - 50.0) / double(nZoom) );
		pPos->y = ( -25.0 * 50.0 / double(nZoom) );
	}
}	

void HVisionOmi::OnConnectView()
{

#ifndef USE_VISION_PRO
/*	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );

	DPOINT dLivePos;

	// Image0
	m_pVisionView[0]->ConnectToView(_T("Display00.View"));
	m_pVisionView[0]->ShowWindow(SW_SHOW);
	gAcuImage0.SetCamera(0);
	
	// Overlay 1
	gAcuOverlay0.SetCrossItem(m_nCross[0], -9, 0, CENTER_X, CENTER_Y, CENTER_X * 2, CENTER_Y * 2, 0);
	GetLivePos(m_nZoom[0], &dLivePos);
	if( FALSE == m_bIsLive )
		gAcuOverlay0.SetStringItem(m_nLive[0], -11, 0, CENTER_X + dLivePos.x, CENTER_Y, -13, _T(""));
	else
		gAcuOverlay0.SetStringItem(m_nLive[0], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
	///////////////////////////////////////////////////////////////////////////////////////////////////

	// Area 1
	gAcuArea0.Show(0);
	gAcuArea0.Show(2);
	////////////////////////////////////////////////////////

	// Fid Tool 1
	gAcuFidTool0.SetWorldOrigin( 0, 0, 0);// m_sVisionInfo.dOrientation );
	gAcuDisplay0.Apply();

	// Image 2
	m_pVisionView[1]->ConnectToView(_T("Display01.View"));
	m_pVisionView[1]->ShowWindow(SW_SHOW);
	gAcuImage1.SetCamera(1);

	// Overlay 2
	gAcuOverlay1.SetCrossItem(m_nCross[1], -9, 0, CENTER_X, CENTER_Y, CENTER_X * 2, CENTER_Y * 2, 0);
	GetLivePos(m_nZoom[1], &dLivePos);
	if( FALSE == m_bIsLive )
		gAcuOverlay1.SetStringItem(m_nLive[1], -11, 0, CENTER_X + dLivePos.x, CENTER_Y, -13, _T(""));
	else
		gAcuOverlay1.SetStringItem(m_nLive[1], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
	///////////////////////////////////////////////////////////////////////////////////////////////////

	// Area 2
	gAcuArea1.Show(0);
	gAcuArea1.Show(2);
	////////////////////////////////////////////////////////

	// Image 3
	m_pVisionView[2]->ConnectToView(_T("Display02.View"));
	m_pVisionView[2]->ShowWindow(SW_SHOW);
	gAcuImage2.SetCamera(2);

	// Overlay 3
	gAcuOverlay2.SetCrossItem(m_nCross[2], -9, 0, CENTER_X, CENTER_Y, CENTER_X * 2, CENTER_Y * 2, 0);
	GetLivePos(m_nZoom[2], &dLivePos);
	if( FALSE == m_bIsLive )
		gAcuOverlay2.SetStringItem(m_nLive[2], -11, 0, CENTER_X + dLivePos.x, CENTER_Y, -13, _T(""));
	else
		gAcuOverlay2.SetStringItem(m_nLive[2], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
	///////////////////////////////////////////////////////////////////////////////////////////////////

	// Area 3
	gAcuArea2.Show(0);
	gAcuArea2.Show(2);
	////////////////////////////////////////////////////////

	// Image 4
	m_pVisionView[3]->ConnectToView(_T("Display03.View"));
	m_pVisionView[3]->ShowWindow(SW_SHOW);
	gAcuImage3.SetCamera(3);

	// Overlay 4
	gAcuOverlay3.SetCrossItem(m_nCross[3], -9, 0, CENTER_X, CENTER_Y, CENTER_X * 2, CENTER_Y * 2, 0);
	GetLivePos(m_nZoom[3], &dLivePos);
	if( FALSE == m_bIsLive )
		gAcuOverlay3.SetStringItem(m_nLive[3], -11, 0, CENTER_X + dLivePos.x, CENTER_Y, -13, _T(""));
	else
		gAcuOverlay3.SetStringItem(m_nLive[3], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
	///////////////////////////////////////////////////////////////////////////////////////////////////

	// Area 4
	gAcuArea3.Show(0);
	gAcuArea3.Show(2);
	////////////////////////////////////////////////////////

	m_evtUseOmiVision.SetEvent();
*/
	CString strOrder = _T("OCONV");
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("OCONV"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("OCONV"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Connect View Fail(TCP/IP)"));
	}
#endif

}

void HVisionOmi::OnCamChange(int nCamNo)
{

#ifndef USE_VISION_PRO
/*	TRACE(_T("*********************************** Start OnCamChange ***********************************\n"));
	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );

	for(int i = 0 ; i < 4 ; i++ )
	{
		if( i == nCamNo )
			m_pVisionView[i]->ShowWindow(SW_SHOW);
		else
			m_pVisionView[i]->ShowWindow(SW_HIDE);
	}

	m_evtUseOmiVision.SetEvent();

	OnContrastAndBrightness(nCamNo, m_sVisionInfo.dContrast[nCamNo], m_sVisionInfo.dBrightness[nCamNo]);
	OnAcquire(nCamNo);
	TRACE(_T("*********************************** End OnCamChange ***********************************\n"));
*/
	CString strOrder = _T("");
	strOrder.Format(_T("OCAMC@%d"), nCamNo);
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("OCAMC"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("OCAMC"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Cam Change Fail(TCP/IP)"));
	}
#endif

}

void HVisionOmi::OnAcquire(int nCamNo)
{

#ifndef USE_VISION_PRO
/*	TRACE(_T("START OnAcquire\n"));

	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );

	switch( nCamNo )
	{
	case 0 : // 1st High
		TRACE(_T("START gAcuImage0.Acquire()\n"));
		gAcuImage0.Acquire();
		//gAcuImage0.StartAcquire();
		//gAcuImage0.CompleteAcquire();
		TRACE(_T("END gAcuImage0.Acquire()\n"));
		TRACE(_T("START gAcuDisplay0.Refresh()\n"));
		gAcuDisplay0.Refresh();
		TRACE(_T("END gAcuDisplay0.Refresh()\n"));
		break;
	case 1 : // 1st Low
		TRACE(_T("START gAcuImage1.Acquire()\n"));
		gAcuImage1.Acquire();
		//gAcuImage1.StartAcquire();
		//gAcuImage1.CompleteAcquire();
		TRACE(_T("END gAcuImage1.Acquire()\n"));
		TRACE(_T("START gAcuDisplay1.Refresh()\n"));
		gAcuDisplay1.Refresh();
		TRACE(_T("END gAcuDisplay1.Refresh()\n"));
		break;
	case 2 : // 2nd High
		TRACE(_T("START gAcuImage2.Acquire()\n"));
		gAcuImage2.Acquire();
		//gAcuImage2.StartAcquire();
		//gAcuImage2.CompleteAcquire();
		TRACE(_T("END gAcuImage2.Acquire()\n"));
		TRACE(_T("START gAcuDisplay2.Refresh()\n"));
		gAcuDisplay2.Refresh();
		TRACE(_T("END gAcuDisplay2.Refresh()\n"));
		break;
	case 3 : // 2nd Low
		TRACE(_T("START gAcuImage3.Acquire()\n"));
		gAcuImage3.Acquire();
		//gAcuImage3.StartAcquire();
		//gAcuImage3.CompleteAcquire();
		TRACE(_T("END gAcuImage3.Acquire()\n"));
		TRACE(_T("START gAcuDisplay3.Refresh()\n"));
		gAcuDisplay3.Refresh();
		TRACE(_T("END gAcuDisplay3.Refresh()\n"));
		break;
	}

	m_evtUseOmiVision.SetEvent();

	TRACE(_T("END OnAcquire\n"));
*/
	CString strOrder = _T("");
	strOrder.Format(_T("OACQR@%d"), nCamNo);
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("OACQR"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("OACQR"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Acquire Fail(TCP/IP)"));
	}
#endif

}

void HVisionOmi::OnContrastAndBrightness(int nCamNo, double dContrast, double dBrightness)
{

#ifndef USE_VISION_PRO
/*	TRACE(_T("START OnContrastAndBrightness\n"));
	
	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );

	m_sVisionInfo.dContrast[nCamNo] = dContrast;
	m_sVisionInfo.dBrightness[nCamNo] = dBrightness;

	switch( nCamNo )
	{
	case 0 :
		gAcuImage0.SetContrast((float)m_sVisionInfo.dContrast[nCamNo]);
		gAcuImage0.SetBrightness((float)m_sVisionInfo.dBrightness[nCamNo]);
		break;
	case 1 :
		gAcuImage1.SetContrast((float)m_sVisionInfo.dContrast[nCamNo]);
		gAcuImage1.SetBrightness((float)m_sVisionInfo.dBrightness[nCamNo]);
		break;
	case 2 :
		gAcuImage2.SetContrast((float)m_sVisionInfo.dContrast[nCamNo]);
		gAcuImage2.SetBrightness((float)m_sVisionInfo.dBrightness[nCamNo]);
		break;
	case 3 :
		gAcuImage3.SetContrast((float)m_sVisionInfo.dContrast[nCamNo]);
		gAcuImage3.SetBrightness((float)m_sVisionInfo.dBrightness[nCamNo]);
		break;
	}

	m_evtUseOmiVision.SetEvent();

	TRACE(_T("END OnContrastAndBrightness\n"));
*/

#endif

}

void HVisionOmi::OnContrast(int nCamNo, double dContrast)
{

#ifndef USE_VISION_PRO
/*	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );

	m_sVisionInfo.dContrast[nCamNo] = dContrast;

	switch( nCamNo )
	{
	case 0 :
		gAcuImage0.SetContrast((float)dContrast);
		break;
	case 1 :
		gAcuImage1.SetContrast((float)dContrast);
		break;
	case 2 :
		gAcuImage2.SetContrast((float)dContrast);
		break;
	case 3 :
		gAcuImage3.SetContrast((float)dContrast);
		break;
	}

	m_evtUseOmiVision.SetEvent();
*/
	CString strOrder = _T("");
	strOrder.Format(_T("OCONT@%d@%.3f"), nCamNo, dContrast);
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("OCONT"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("OCONT"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Contrast Setting Fail(TCP/IP)"));
	}
#endif

}

void HVisionOmi::OnBrightness(int nCamNo, double dBrightness)
{

#ifndef USE_VISION_PRO
/*	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );

	m_sVisionInfo.dBrightness[nCamNo] = dBrightness;

	switch( nCamNo )
	{
	case 0 :
		gAcuImage0.SetBrightness((float)dBrightness);
		break;
	case 1 :
		gAcuImage1.SetBrightness((float)dBrightness);
		break;
	case 2 :
		gAcuImage2.SetBrightness((float)dBrightness);
		break;
	case 3 :
		gAcuImage3.SetBrightness((float)dBrightness);
		break;
	}

	m_evtUseOmiVision.SetEvent();
*/
	CString strOrder = _T("");
	strOrder.Format(_T("OBRIT@%d@%.3f"), nCamNo, dBrightness);
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("OBRIT"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("OBRIT"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Brightness Setting Fail(TCP/IP)"));
	}
#endif

}

void HVisionOmi::SaveImg(int nCamNo, CString strFilePathName)
{

#ifndef USE_VISION_PRO
/*	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );

	switch( nCamNo )
	{
	case 0 :
		gAcuImage0.Save(strFilePathName);
		break;
	case 1 :
		gAcuImage1.Save(strFilePathName);
		break;
	case 2 :
		gAcuImage2.Save(strFilePathName);
		break;
	case 3 :
		gAcuImage3.Save(strFilePathName);
		break;
	}

	m_evtUseOmiVision.SetEvent();
*/
	CString strOrder = _T("");
	strOrder.Format(_T("SAVEI@%d@%s"), nCamNo, strFilePathName);
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("SAVEI"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("SAVEI"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Save Image Fail(TCP/IP)"));
	}
#endif

}

void HVisionOmi::OnLive(int nCamNo, BOOL bIsLive)
{

#ifndef USE_VISION_PRO
/*	TRACE(_T("Start OnLive\n"));
	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );

	DPOINT dLivePos;

	GetLivePos(m_nZoom[nCamNo], &dLivePos);
	SetIsLive( bIsLive );
	m_nCam = nCamNo;
	if( bIsLive ) // Live On
	{
		//gAcuDisplay0.EndLive();
		//gAcuDisplay1.EndLive();
		//gAcuDisplay2.EndLive();
		//gAcuDisplay3.EndLive();

		switch( nCamNo )
		{
		case 0 :
			gAcuDisplay0.StartLive();
			gAcuOverlay0.SetStringItem(m_nLive[0], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
			break;
		case 1 :
			gAcuDisplay1.StartLive();
			gAcuOverlay1.SetStringItem(m_nLive[1], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
			break;
		case 2 :
			gAcuDisplay2.StartLive();
			gAcuOverlay2.SetStringItem(m_nLive[2], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
			break;
		case 3 :
			gAcuDisplay3.StartLive();
			gAcuOverlay3.SetStringItem(m_nLive[3], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
			break;
		}
	}
	else // Live Off
	{
		switch( nCamNo )
		{
		case 0 :
			gAcuDisplay0.EndLive();
			gAcuOverlay0.SetStringItem(m_nLive[0], -11, 0, SCREEN_PIXEL_X + dLivePos.x, CENTER_Y, -13, _T(""));
			break;
		case 1 :
			gAcuDisplay1.EndLive();
			gAcuOverlay1.SetStringItem(m_nLive[1], -11, 0, SCREEN_PIXEL_X + dLivePos.x, CENTER_Y, -13, _T(""));
			break;
		case 2 :
			gAcuDisplay2.EndLive();
			gAcuOverlay2.SetStringItem(m_nLive[2], -11, 0, SCREEN_PIXEL_X + dLivePos.x, CENTER_Y, -13, _T(""));
			break;
		case 3 :
			gAcuDisplay3.EndLive();
			gAcuOverlay3.SetStringItem(m_nLive[3], -11, 0, SCREEN_PIXEL_X + dLivePos.x, CENTER_Y, -13, _T(""));
			break;
		}
	}
	
	m_evtUseOmiVision.SetEvent();
	TRACE(_T("End OnLive\n"));
*/
	CString strOrder = _T("");
	strOrder.Format(_T("OLIVE@%d@%d"), nCamNo, bIsLive);
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("OLIVE"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("OLIVE"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("On Live Fail(TCP/IP)"));
	}
#endif

}

void HVisionOmi::OnApplyVisionParam(int nCamNo, SVISIONINFO sVisionInfo)
{

#ifndef USE_VISION_PRO
/*	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );

	memcpy( &m_sVisionInfo, &sVisionInfo, sizeof(m_sVisionInfo) );

	long nVal=0;

	switch( nCamNo )
	{
	case 0 :
		gAcuFidTool0.SetWorldOrigin(0, 0, 0);// m_sVisionInfo.dOrientation);
		gAcuFidTool0.SetAngularUnc(m_sVisionInfo.dScoreAngle, m_sVisionInfo.dScoreAngle);
		gAcuFidTool0.SetScaleUnc( m_sVisionInfo.dScoreSize, m_sVisionInfo.dScoreSize);
		gAcuFidTool0.SetAspectUnc(m_sVisionInfo.dAspectRatio, 0);
		gAcuFidTool0.FidModel.SetModelType(m_sVisionInfo.nModelType);
		gAcuFidTool0.FidModel.SetPolarity(m_sVisionInfo.nPolarity);
		break;
	case 1 :
		gAcuFidTool1.SetWorldOrigin(0, 0, 0);// m_sVisionInfo.dOrientation);
		gAcuFidTool1.SetAngularUnc(m_sVisionInfo.dScoreAngle, m_sVisionInfo.dScoreAngle);
		gAcuFidTool1.SetScaleUnc( m_sVisionInfo.dScoreSize, m_sVisionInfo.dScoreSize);
		gAcuFidTool1.SetAspectUnc(m_sVisionInfo.dAspectRatio, 0);
		gAcuFidTool1.FidModel.SetModelType(m_sVisionInfo.nModelType);
		gAcuFidTool1.FidModel.SetPolarity(m_sVisionInfo.nPolarity);
		break;
	case 2 :
		gAcuFidTool2.SetWorldOrigin(0, 0, 0);// m_sVisionInfo.dOrientation);
		gAcuFidTool2.SetAngularUnc(m_sVisionInfo.dScoreAngle, m_sVisionInfo.dScoreAngle);
		gAcuFidTool2.SetScaleUnc( m_sVisionInfo.dScoreSize, m_sVisionInfo.dScoreSize);
		gAcuFidTool2.SetAspectUnc(m_sVisionInfo.dAspectRatio, 0);
		gAcuFidTool2.FidModel.SetModelType(m_sVisionInfo.nModelType);
		gAcuFidTool2.FidModel.SetPolarity(m_sVisionInfo.nPolarity);
		break;
	case 3 :
		gAcuFidTool3.SetWorldOrigin(0, 0, 0);// m_sVisionInfo.dOrientation);
		gAcuFidTool3.SetAngularUnc(m_sVisionInfo.dScoreAngle, m_sVisionInfo.dScoreAngle);
		gAcuFidTool3.SetScaleUnc( m_sVisionInfo.dScoreSize, m_sVisionInfo.dScoreSize);
		gAcuFidTool3.SetAspectUnc(m_sVisionInfo.dAspectRatio, 0);
		gAcuFidTool3.FidModel.SetModelType(m_sVisionInfo.nModelType);
		gAcuFidTool3.FidModel.SetPolarity(m_sVisionInfo.nPolarity);
		break;
	}

	double dPixel = 0.0;
	double dSizeA = 0., dSizeB = 0., dSizeC = 0.;
*/
//	if(nCamNo == HIGH_1ST_CAM)
//		dPixel = m_dHighPixel.x;//*/gSystemINI.m_sSystemDevice.d1stHighPixel.x;
//	else if(nCamNo == LOW_1ST_CAM)
//		dPixel = m_dLowPixel.x;//*/gSystemINI.m_sSystemDevice.d1stLowPixel.x;
//	else if(nCamNo == HIGH_2ND_CAM)
//		dPixel = m_dHighPixel.x;//*/gSystemINI.m_sSystemDevice.d2ndHighPixel.x;
//	else 
//		dPixel = m_dLowPixel.x;//*/gSystemINI.m_sSystemDevice.d2ndLowPixel.x;


//	dPixel = ( m_dPixel[nCamNo].x + m_dPixel[nCamNo].y ) / 2.;

/*	dSizeA = ( m_sVisionInfo.dSizeA / dPixel );
	dSizeB = ( m_sVisionInfo.dSizeB / dPixel );
	dSizeC = ( m_sVisionInfo.dSizeC / dPixel );

	UpdateMinMax( dSizeA, dSizeB, dSizeC );

	switch ( m_sVisionInfo.nModelType )
	{
	case 0:
		{
			switch( nCamNo )
			{
			case 0 :
				gAcuFidTool0.FidModel.SetDiameters( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
							 				        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 1 :
				gAcuFidTool1.FidModel.SetDiameters( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
							 				        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 2 :
				gAcuFidTool2.FidModel.SetDiameters( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
							 				        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 3 :
				gAcuFidTool3.FidModel.SetDiameters( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
							 				        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			}
		}
		break;
	case 1:
		{
			switch( nCamNo )
			{
			case 0 :
				gAcuFidTool0.FidModel.SetDiameter((float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax );
				break;
			case 1 :
				gAcuFidTool1.FidModel.SetDiameter((float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax );
				break;
			case 2 :
				gAcuFidTool2.FidModel.SetDiameter((float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax );
				break;
			case 3 :
				gAcuFidTool3.FidModel.SetDiameter((float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax );
				break;
			}
		}
		break;
	case 2:
		{
			switch( nCamNo )
			{
			case 0 :
				gAcuFidTool0.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
												    (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				gAcuFidTool0.FidModel.SetThickness( (float)dSizeC, (float)m_dSizeCMin, (float)m_dSizeCMax );
				break;
			case 1 :
				gAcuFidTool1.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
												    (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				gAcuFidTool1.FidModel.SetThickness( (float)dSizeC, (float)m_dSizeCMin, (float)m_dSizeCMax );
				break;
			case 2 :
				gAcuFidTool2.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
												    (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				gAcuFidTool2.FidModel.SetThickness( (float)dSizeC, (float)m_dSizeCMin, (float)m_dSizeCMax );
				break;
			case 3 :
				gAcuFidTool3.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
												    (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				gAcuFidTool3.FidModel.SetThickness( (float)dSizeC, (float)m_dSizeCMin, (float)m_dSizeCMax );
				break;
			}
		}
		break;
	case 3:
		{
			switch( nCamNo )
			{
			case 0 :
				gAcuFidTool0.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
											        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 1 :
				gAcuFidTool1.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
											        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 2 :
				gAcuFidTool2.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
											        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 3 :
				gAcuFidTool3.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
											        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			}
		}
		break;
	case 4:
		{
			switch( nCamNo )
			{
			case 0 :
				gAcuFidTool0.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, 
													(float)m_dSizeAMax, (float)m_sVisionInfo.dSizeB, 
													(float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 1 :
				gAcuFidTool1.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, 
													(float)m_dSizeAMax, (float)m_sVisionInfo.dSizeB, 
													(float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 2 :
				gAcuFidTool2.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, 
													(float)m_dSizeAMax, (float)m_sVisionInfo.dSizeB, 
													(float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 3 :
				gAcuFidTool3.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, 
													(float)m_dSizeAMax, (float)m_sVisionInfo.dSizeB, 
													(float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			}
		}
		break;
	case 5:
		{
			switch( nCamNo )
			{
			case 0 :
				gAcuFidTool0.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 1 :
				gAcuFidTool1.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 2 :
				gAcuFidTool2.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 3 :
				gAcuFidTool3.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			}
		}
		break;
	case 6:
		{
			switch( nCamNo )
			{
			case 0 :
				gAcuFidTool0.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 1 :
				gAcuFidTool1.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 2 :
				gAcuFidTool2.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 3 :
				gAcuFidTool3.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			}
		}
		break;
	case 7:
		break;
	}

	switch( nCamNo )
	{
	case 0 :
		gAcuFidTool0.FidModel.Untrain();
		gAcuFidTool0.FidModel.Train();
		break;
	case 1 :
		gAcuFidTool1.FidModel.Untrain();
		gAcuFidTool1.FidModel.Train();
		break;
	case 2 :
		gAcuFidTool2.FidModel.Untrain();
		gAcuFidTool2.FidModel.Train();
		break;
	case 3 :
		gAcuFidTool3.FidModel.Untrain();
		gAcuFidTool3.FidModel.Train();
		break;
	}

	m_evtUseOmiVision.SetEvent();

	OnContrastAndBrightness( nCamNo, m_sVisionInfo.dContrast[nCamNo], m_sVisionInfo.dBrightness[nCamNo] );
	OnLightAll(nCamNo, m_sVisionInfo.nCoaxial[nCamNo], m_sVisionInfo.nRing[nCamNo]);
	OnAcquire(nCamNo);
*/
	CString strOrder = _T("");
	strOrder.Format(_T("OAPVP@%d@%d@%d@%.3f@%.3f@%.3f@%d@%d@%d@%d@%d@%d@%d@%d@%.3f@%.3f@%.3f@%.3f@%.3f@%.3f@%.3f@%.3f@%.3f@%.3f@%.3f@%d"),
		nCamNo, sVisionInfo.nModelType, sVisionInfo.nPolarity, sVisionInfo.dSizeA, sVisionInfo.dSizeB, sVisionInfo.dSizeC,
		sVisionInfo.nCoaxial[0], sVisionInfo.nCoaxial[1], sVisionInfo.nCoaxial[2], sVisionInfo.nCoaxial[3], 
		sVisionInfo.nRing[0], sVisionInfo.nRing[1], sVisionInfo.nRing[2], sVisionInfo.nRing[3], 
		sVisionInfo.dContrast[0], sVisionInfo.dContrast[1], sVisionInfo.dContrast[2], sVisionInfo.dContrast[3], 
		sVisionInfo.dBrightness[0], sVisionInfo.dBrightness[1], sVisionInfo.dBrightness[2], sVisionInfo.dBrightness[3], 
		sVisionInfo.dScoreAngle, sVisionInfo.dScoreSize, sVisionInfo.dAspectRatio, sVisionInfo.nThreshold);

	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("OAPVP"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("OAPVP"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Apply Vision Parameter Fail(TCP/IP)"));
	}
#endif

}

void HVisionOmi::OnApplyVisionParameter(int nCamNo, VISION_INFO sVisionInfo)
{

#ifndef USE_VISION_PRO
/*	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );

	memcpy( &m_sVisionInfo, &sVisionInfo, sizeof(m_sVisionInfo) );

	long nVal=0;

	switch( nCamNo )
	{
	case 0 :
		gAcuFidTool0.SetWorldOrigin(0, 0, 0);// m_sVisionInfo.dOrientation);
		gAcuFidTool0.SetAngularUnc(m_sVisionInfo.dScoreAngle, m_sVisionInfo.dScoreAngle);
		gAcuFidTool0.SetScaleUnc( m_sVisionInfo.dScoreSize, m_sVisionInfo.dScoreSize);
		gAcuFidTool0.SetAspectUnc(m_sVisionInfo.dAspectRatio, 0);
		gAcuFidTool0.FidModel.SetModelType(m_sVisionInfo.nModelType);
		gAcuFidTool0.FidModel.SetPolarity(m_sVisionInfo.nPolarity);
		break;
	case 1 :
		gAcuFidTool1.SetWorldOrigin(0, 0, 0);// m_sVisionInfo.dOrientation);
		gAcuFidTool1.SetAngularUnc(m_sVisionInfo.dScoreAngle, m_sVisionInfo.dScoreAngle);
		gAcuFidTool1.SetScaleUnc( m_sVisionInfo.dScoreSize, m_sVisionInfo.dScoreSize);
		gAcuFidTool1.SetAspectUnc(m_sVisionInfo.dAspectRatio, 0);
		gAcuFidTool1.FidModel.SetModelType(m_sVisionInfo.nModelType);
		gAcuFidTool1.FidModel.SetPolarity(m_sVisionInfo.nPolarity);
		break;
	case 2 :
		gAcuFidTool2.SetWorldOrigin(0, 0, 0);// m_sVisionInfo.dOrientation);
		gAcuFidTool2.SetAngularUnc(m_sVisionInfo.dScoreAngle, m_sVisionInfo.dScoreAngle);
		gAcuFidTool2.SetScaleUnc( m_sVisionInfo.dScoreSize, m_sVisionInfo.dScoreSize);
		gAcuFidTool2.SetAspectUnc(m_sVisionInfo.dAspectRatio, 0);
		gAcuFidTool2.FidModel.SetModelType(m_sVisionInfo.nModelType);
		gAcuFidTool2.FidModel.SetPolarity(m_sVisionInfo.nPolarity);
		break;
	case 3 :
		gAcuFidTool3.SetWorldOrigin(0, 0, 0);// m_sVisionInfo.dOrientation);
		gAcuFidTool3.SetAngularUnc(m_sVisionInfo.dScoreAngle, m_sVisionInfo.dScoreAngle);
		gAcuFidTool3.SetScaleUnc( m_sVisionInfo.dScoreSize, m_sVisionInfo.dScoreSize);
		gAcuFidTool3.SetAspectUnc(m_sVisionInfo.dAspectRatio, 0);
		gAcuFidTool3.FidModel.SetModelType(m_sVisionInfo.nModelType);
		gAcuFidTool3.FidModel.SetPolarity(m_sVisionInfo.nPolarity);
		break;
	}

	double dPixel = 0.0;
	double dSizeA = 0., dSizeB = 0., dSizeC = 0.;

	if(nCamNo == HIGH_1ST_CAM)
		dPixel = m_dHighPixel.x;
	else if(nCamNo == LOW_1ST_CAM)
		dPixel = m_dLowPixel.x;
	else if(nCamNo == HIGH_2ND_CAM)
		dPixel = m_dHighPixel.x;
	else 
		dPixel = m_dLowPixel.x;


//	dPixel = ( m_dPixel[nCamNo].x + m_dPixel[nCamNo].y ) / 2.;

	dSizeA = ( m_sVisionInfo.dSizeA / dPixel );
	dSizeB = ( m_sVisionInfo.dSizeB / dPixel );
	dSizeC = ( m_sVisionInfo.dSizeC / dPixel );

	UpdateMinMax( dSizeA, dSizeB, dSizeC );

	switch ( m_sVisionInfo.nModelType )
	{
	case 0:
		{
			switch( nCamNo )
			{
			case 0 :
				gAcuFidTool0.FidModel.SetDiameters( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
							 				        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 1 :
				gAcuFidTool1.FidModel.SetDiameters( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
							 				        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 2 :
				gAcuFidTool2.FidModel.SetDiameters( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
							 				        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 3 :
				gAcuFidTool3.FidModel.SetDiameters( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
							 				        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			}
		}
		break;
	case 1:
		{
			switch( nCamNo )
			{
			case 0 :
				gAcuFidTool0.FidModel.SetDiameter((float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax );
				break;
			case 1 :
				gAcuFidTool1.FidModel.SetDiameter((float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax );
				break;
			case 2 :
				gAcuFidTool2.FidModel.SetDiameter((float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax );
				break;
			case 3 :
				gAcuFidTool3.FidModel.SetDiameter((float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax );
				break;
			}
		}
		break;
	case 2:
		{
			switch( nCamNo )
			{
			case 0 :
				gAcuFidTool0.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
												    (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				gAcuFidTool0.FidModel.SetThickness( (float)dSizeC, (float)m_dSizeCMin, (float)m_dSizeCMax );
				break;
			case 1 :
				gAcuFidTool1.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
												    (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				gAcuFidTool1.FidModel.SetThickness( (float)dSizeC, (float)m_dSizeCMin, (float)m_dSizeCMax );
				break;
			case 2 :
				gAcuFidTool2.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
												    (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				gAcuFidTool2.FidModel.SetThickness( (float)dSizeC, (float)m_dSizeCMin, (float)m_dSizeCMax );
				break;
			case 3 :
				gAcuFidTool3.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
												    (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				gAcuFidTool3.FidModel.SetThickness( (float)dSizeC, (float)m_dSizeCMin, (float)m_dSizeCMax );
				break;
			}
		}
		break;
	case 3:
		{
			switch( nCamNo )
			{
			case 0 :
				gAcuFidTool0.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
											        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 1 :
				gAcuFidTool1.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
											        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 2 :
				gAcuFidTool2.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
											        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 3 :
				gAcuFidTool3.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
											        (float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			}
		}
		break;
	case 4:
		{
			switch( nCamNo )
			{
			case 0 :
				gAcuFidTool0.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, 
													(float)m_dSizeAMax, (float)m_sVisionInfo.dSizeB, 
													(float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 1 :
				gAcuFidTool1.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, 
													(float)m_dSizeAMax, (float)m_sVisionInfo.dSizeB, 
													(float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 2 :
				gAcuFidTool2.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, 
													(float)m_dSizeAMax, (float)m_sVisionInfo.dSizeB, 
													(float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 3 :
				gAcuFidTool3.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, 
													(float)m_dSizeAMax, (float)m_sVisionInfo.dSizeB, 
													(float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			}
		}
		break;
	case 5:
		{
			switch( nCamNo )
			{
			case 0 :
				gAcuFidTool0.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 1 :
				gAcuFidTool1.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 2 :
				gAcuFidTool2.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 3 :
				gAcuFidTool3.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			}
		}
		break;
	case 6:
		{
			switch( nCamNo )
			{
			case 0 :
				gAcuFidTool0.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 1 :
				gAcuFidTool1.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 2 :
				gAcuFidTool2.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			case 3 :
				gAcuFidTool3.FidModel.SetDimension( (float)dSizeA, (float)m_dSizeAMin, (float)m_dSizeAMax, 
													(float)dSizeB, (float)m_dSizeBMin, (float)m_dSizeBMax );
				break;
			}
		}
		break;
	case 7:
		break;
	}

	switch( nCamNo )
	{
	case 0 :
		gAcuFidTool0.FidModel.Untrain();
		gAcuFidTool0.FidModel.Train();
		break;
	case 1 :
		gAcuFidTool1.FidModel.Untrain();
		gAcuFidTool1.FidModel.Train();
		break;
	case 2 :
		gAcuFidTool2.FidModel.Untrain();
		gAcuFidTool2.FidModel.Train();
		break;
	case 3 :
		gAcuFidTool3.FidModel.Untrain();
		gAcuFidTool3.FidModel.Train();
		break;
	}

	m_evtUseOmiVision.SetEvent();

	OnContrastAndBrightness( nCamNo, m_sVisionInfo.dContrast[nCamNo], m_sVisionInfo.dBrightness[nCamNo] );
	OnLightAll(nCamNo, m_sVisionInfo.nCoaxial[nCamNo], m_sVisionInfo.nRing[nCamNo]);
	OnAcquire(nCamNo);
*/
	CString strOrder = _T("");
	strOrder.Format(_T("OAVPM@%d@%d@%d@%.3f@%.3f@%.3f@%d@%d@%d@%d@%d@%d@%d@%d@%.3f@%.3f@%.3f@%.3f@%.3f@%.3f@%.3f@%.3f@%.3f@%.3f@%.3f"),
		nCamNo, sVisionInfo.nModelType, sVisionInfo.nPolarity, sVisionInfo.dSizeA, sVisionInfo.dSizeB, sVisionInfo.dSizeC,
		sVisionInfo.nCoaxial[0], sVisionInfo.nCoaxial[1], sVisionInfo.nCoaxial[2], sVisionInfo.nCoaxial[3], 
		sVisionInfo.nRing[0], sVisionInfo.nRing[1], sVisionInfo.nRing[2], sVisionInfo.nRing[3], 
		sVisionInfo.dContrast[0], sVisionInfo.dContrast[1], sVisionInfo.dContrast[2], sVisionInfo.dContrast[3], 
		sVisionInfo.dBrightness[0], sVisionInfo.dBrightness[1], sVisionInfo.dBrightness[2], sVisionInfo.dBrightness[3], 
		sVisionInfo.dScoreAngle, sVisionInfo.dScoreSize, sVisionInfo.dAspectRatio);

	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("OAVPM"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("OAVPM"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Apply Vision Parameter Fail(TCP/IP)"));
	}
#endif

}

void HVisionOmi::UpdateMinMax(double dSizeA, double dSizeB, double dSizeC)
{
	m_dSizeAMin	= ( dSizeA * ( 1.0 - m_sVisionInfo.dScoreSize / 100.0 ) );
	m_dSizeAMax	= ( dSizeA * ( 1.0 + m_sVisionInfo.dScoreSize / 100.0 ) );

	if( m_dSizeAMin < 0. )
		m_dSizeAMin = -1.;
	if( m_dSizeAMax < 0. )
		m_dSizeAMax = -1.;
	if( m_dSizeAMin >= m_dSizeAMax )
		m_dSizeAMin = m_dSizeAMax = -1.;

	m_dSizeBMin	= ( dSizeB * ( 1.0 - m_sVisionInfo.dScoreSize / 100.0 ) );
	m_dSizeBMax	= ( dSizeB * ( 1.0 + m_sVisionInfo.dScoreSize / 100.0 ) );

	if( m_dSizeBMin < 0. )
		m_dSizeBMin = -1.;
	if( m_dSizeBMax < 0. )
		m_dSizeBMax = -1.;
	if( m_dSizeBMin >= m_dSizeBMax )
		m_dSizeBMin = m_dSizeBMax = -1.;

	m_dSizeCMin	= ( dSizeC * ( 1.0 - m_sVisionInfo.dScoreSize / 100.0 ) );
	m_dSizeCMax	= ( dSizeC * ( 1.0 + m_sVisionInfo.dScoreSize / 100.0 ) );

	if( m_dSizeCMin < 0. )
		m_dSizeCMin = -1.;
	if( m_dSizeCMax < 0. )
		m_dSizeCMax = -1.;
	if( m_dSizeCMin >= m_dSizeCMax )
		m_dSizeCMin = m_dSizeCMax = -1.;
}

BOOL HVisionOmi::OnFindFiducial(int nCamNo, CString& strMsg)
{

#ifndef USE_VISION_PRO
/*	if(GetIsLive())
	{
		OnLive(nCamNo, FALSE);
	}
	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );

	switch( nCamNo )
	{
	case 0 :
		gAcuFidTool0.Show(0);
		gAcuFidTool0.SetWorldOrigin(0, 0, 0);// m_sVisionInfo.dOrientation);
		gAcuImage0.Acquire();
		gAcuDisplay0.Refresh();
		gAcuFidTool0.Find();
		gAcuFidTool0.Show(1);
		break;
	case 1 :
		gAcuFidTool1.Show(0);
		gAcuFidTool1.SetWorldOrigin(0, 0, 0);// m_sVisionInfo.dOrientation);
		gAcuImage1.Acquire();
		gAcuDisplay1.Refresh();
		gAcuFidTool1.Find();
		gAcuFidTool1.Show(1);
		break;
	case 2 :
		gAcuFidTool2.Show(0);
		gAcuFidTool2.SetWorldOrigin(0, 0, 0);// m_sVisionInfo.dOrientation);
		gAcuImage2.Acquire();
		gAcuDisplay2.Refresh();
		gAcuFidTool2.Find();
		gAcuFidTool2.Show(1);
		break;
	case 3 :
		gAcuFidTool3.Show(0);
		gAcuFidTool3.SetWorldOrigin(0, 0, 0);// m_sVisionInfo.dOrientation);
		gAcuImage3.Acquire();
		gAcuDisplay3.Refresh();
		gAcuFidTool3.Find();
		gAcuFidTool3.Show(1);
		break;
	}

	double dOffsetX = 0.0, dOffsetY = 0.0;
	long nFound;
	char szBuf[100], szTemp[100];
	long res = 0;

	switch( nCamNo )
	{
	case 0 :
		res = gAcuFidTool0.GetNFound(&nFound);
		break;
	case 1 :
		res = gAcuFidTool1.GetNFound(&nFound);
		break;
	case 2 :
		res = gAcuFidTool2.GetNFound(&nFound);
		break;
	case 3 :
		res = gAcuFidTool3.GetNFound(&nFound);
		break;
	}

	if( res != 1 || nFound < 1 )
	{
		CString strVal;
		strVal.LoadString(IDS_TEXT_INSPECTION_FAIL);
		lstrcpy(szBuf, (LPCTSTR)strVal);
		lstrcpy(szTemp, szBuf);
		m_dPos.x = 999;
		m_dPos.y = 999;

		strMsg.Format(_T("%s"), szTemp);
		m_evtUseOmiVision.SetEvent();

		return FALSE;
	}
	
	AcuFIDResult *pFidRes = NULL;

	pFidRes = new AcuFIDResult[nFound];

	switch( nCamNo )
	{
	case 0 :
		gAcuFidTool0.GetFIDResult(0, pFidRes);
		break;
	case 1 :
		gAcuFidTool1.GetFIDResult(0, pFidRes);
		break;
	case 2 :
		gAcuFidTool2.GetFIDResult(0, pFidRes);
		break;
	case 3 :
		gAcuFidTool3.GetFIDResult(0, pFidRes);
		break;
	}

	double dPixelX, dPixelY;
	if(nCamNo == HIGH_1ST_CAM)
	{
		m_2DTrans[HIGH_1ST_CAM].TransformPoint((double)pFidRes[0].y, (double)pFidRes[0].x, dPixelX, dPixelY);
	}
	else if(nCamNo == LOW_1ST_CAM)
	{
		m_2DTrans[LOW_1ST_CAM].TransformPoint((double)pFidRes[0].y, (double)pFidRes[0].x, dPixelX, dPixelY);
	}
	else if(nCamNo == HIGH_2ND_CAM)
	{
		m_2DTrans[HIGH_2ND_CAM].TransformPoint((double)pFidRes[0].y, (double)pFidRes[0].x, dPixelX, dPixelY);
	}
	else 
	{
		m_2DTrans[LOW_2ND_CAM].TransformPoint((double)pFidRes[0].y, (double)pFidRes[0].x, dPixelX, dPixelY);
	}
	double dPixel;
	if(nCamNo == HIGH_1ST_CAM)
		dPixel = m_dHighPixel.x;
	else if(nCamNo == LOW_1ST_CAM)
		dPixel = m_dLowPixel.x;
	else if(nCamNo == HIGH_2ND_CAM)
		dPixel = m_dHighPixel.x;
	else 
		dPixel = m_dLowPixel.x;

	dOffsetX = dPixelX;///(CENTER_X - dPixelY) * dPixel;// * m_dPixel[nCamNo].y;  // pixel.x -> y
	dOffsetY = dPixelY;//-(CENTER_Y - dPixelX) * dPixel;// * m_dPixel[nCamNo].x; // pixel.y -> x

// 	dOffsetY = (CENTER_X - (double)pFidRes[0].x) * m_dPixel[nCamNo].y;  // pixel.x -> y
// 	dOffsetX = -(CENTER_Y - (double)pFidRes[0].y) * m_dPixel[nCamNo].x; // pixel.y -> x

	if( 1 != pFidRes[0].isPoseValid )
	{
		delete[] pFidRes;

		CString strVal;
		strVal.LoadString(IDS_TEXT_POSITION_INVALID);
		lstrcpy(szBuf, (LPCTSTR)strVal);
		lstrcpy(szTemp, szBuf);
		m_dPos.x = 999;
		m_dPos.y = 999;

		strMsg.Format(_T("%s"), szTemp);
		m_evtUseOmiVision.SetEvent();

		return FALSE;
	}

	sprintf_s(szBuf, 100, _T("X : %.3f, Y : %.3f"), dOffsetX, dOffsetY);
	m_dPos.x = dOffsetX;
	m_dPos.y = dOffsetY;

	long nCount;

	switch( nCamNo )
	{
	case 0 :
		gAcuFidTool0.GetDimensionResultCount(0, &nCount);
		break;
	case 1 :
		gAcuFidTool1.GetDimensionResultCount(0, &nCount);
		break;
	case 2 :
		gAcuFidTool2.GetDimensionResultCount(0, &nCount);
		break;
	case 3 :
		gAcuFidTool3.GetDimensionResultCount(0, &nCount);
		break;
	}

	if( nCount < 1 )
	{
		CString strVal;
		strVal.LoadString(IDS_TEXT_INSPECTION_FAIL);
		lstrcpy(szBuf, (LPCTSTR)strVal);
		lstrcpy(szTemp, szBuf);
		m_dPos.x = 999;
		m_dPos.y = 999;

		strMsg.Format(_T("%s"), szTemp);
		m_evtUseOmiVision.SetEvent();

		return FALSE;
	}

	AcuFIDDimResult *pDim = NULL;

	pDim = new AcuFIDDimResult[nCount];

	int nResult;

	switch( nCamNo )
	{
	case 0 :
		nResult = gAcuFidTool0.GetDimensionResult(0, 0, pDim);
		break;
	case 1 :
		nResult = gAcuFidTool1.GetDimensionResult(0, 0, pDim);
		break;
	case 2 :
		nResult = gAcuFidTool2.GetDimensionResult(0, 0, pDim);
		break;
	case 3 :
		nResult = gAcuFidTool3.GetDimensionResult(0, 0, pDim);
		break;
	}

	if (nResult == 1)
	{
	//	m_dResultSize = pDim[0].measuredValue * (m_dPixel[nCamNo].x+m_dPixel[nCamNo].y) / 2.;
		m_dResultSize = pDim[0].measuredValue * (dPixel);
		sprintf_s(szTemp, 100, _T("%s, (%.3f)"), szBuf, m_dResultSize);
	}
	else
	{
		CString strVal;
		strVal.LoadString(IDS_TEXT_INSPECTION_FAIL);
		lstrcpy(szBuf, (LPCTSTR)strVal);
		lstrcpy(szTemp, szBuf);
		m_dPos.x = 999;
		m_dPos.y = 999;
	}

	delete [] pDim;
	delete [] pFidRes;

	strMsg.Format(_T("%s"), szTemp);
	m_evtUseOmiVision.SetEvent();
*/
	CString strOrder = _T("");
	strOrder.Format(_T("OFINF@%d@%s"), nCamNo, strMsg);
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpFindFiducial(strMsg);
	int nCount  = 0;
	while(bReturn == 2 && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpFindFiducial(strMsg);
		nCount++;
	}
	return bReturn;
#endif

	return TRUE;
}


void HVisionOmi::OnLightAll(int nCamNo, int nCoaxial, int nRing)
{
	m_sVisionInfo.nCoaxial[nCamNo] = nCoaxial;
	m_sVisionInfo.nRing[nCamNo] = nRing;

	if(!gSystemINI.m_sHardWare.nUseLampRS232)
		return;

	switch( nCamNo )
	{
	case 0 :
		m_clsLamp->LampOut(0, nCoaxial);
		m_clsLamp->LampOut(1, nRing);
		break;
	case 1 :
		m_clsLamp->LampOut(2, nCoaxial);
		m_clsLamp->LampOut(3, nRing);
		break;
	case 2 :
		m_clsLamp->LampOut(4, nCoaxial);
		m_clsLamp->LampOut(5, nRing);
		break;
	case 3 :
		m_clsLamp->LampOut(6, nCoaxial);
		m_clsLamp->LampOut(7, nRing);
		break;
	}
}

void HVisionOmi::OnLight(int nCamNo, int nType, int nVal)
{
/*	if( 0 == nType ) // Coaxial
	{
		m_sVisionInfo.nCoaxial[nCamNo] = nVal;
		if(!gSystemINI.m_sHardWare.nUseLampRS232)
			return;
		switch( nCamNo )
		{
		case 0 :
			m_clsLamp->LampOut(0, nVal);
			break;
		case 1 :
			m_clsLamp->LampOut(2, nVal);
			break;
		case 2 :
			m_clsLamp->LampOut(4, nVal);
			break;
		case 3 :
			m_clsLamp->LampOut(6, nVal);
			break;
		}
	}
	else  // Ring
	{
		m_sVisionInfo.nRing[nCamNo] = nVal;
		if(!gSystemINI.m_sHardWare.nUseLampRS232)
			return;
		switch( nCamNo )
		{
		case 0 :
			m_clsLamp->LampOut(1, nVal);
			break;
		case 1 :
			m_clsLamp->LampOut(3, nVal);
			break;
		case 2 :
			m_clsLamp->LampOut(5, nVal);
			break;
		case 3 :
			m_clsLamp->LampOut(7, nVal);
			break;
		}
	}
*/
	CString strOrder = _T("");
	strOrder.Format(_T("OLIGT@%d@%d@%d"), nCamNo, nType, nVal);
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("OLIGT"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("OLIGT"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("On Light Fail(TCP/IP)"));
	}
}

void HVisionOmi::SetVisionZoom(int nCamNo, int nZoom)
{

#ifndef USE_VISION_PRO
/*	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );

	m_nZoom[nCamNo] = nZoom;

	AcuView* pAcuView = NULL;
	
	switch( nCamNo )
	{
	case 0 :
		pAcuView = &(gAcuDisplay0.View);
		break;
	case 1 :
		pAcuView = &(gAcuDisplay1.View);
		break;
	case 2 :
		pAcuView = &(gAcuDisplay2.View);
		break;
	case 3 :
		pAcuView = &(gAcuDisplay3.View);
		break;
	}

	pAcuView->SetZoom( nZoom );
	pAcuView->Apply();

	DPOINT dLivePos;

	GetLivePos(m_nZoom[nCamNo], &dLivePos);

	switch( nCamNo )
	{
	case 0 :
		if( FALSE == m_bIsLive )
			gAcuOverlay0.SetStringItem(m_nLive[0], -11, 0, CENTER_X + dLivePos.x, CENTER_Y, -13, _T(""));
		else
			gAcuOverlay0.SetStringItem(m_nLive[0], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
		break;
	case 1 :
		if( FALSE == m_bIsLive )
			gAcuOverlay1.SetStringItem(m_nLive[1], -11, 0, CENTER_X + dLivePos.x, CENTER_Y, -13, _T(""));
		else
			gAcuOverlay1.SetStringItem(m_nLive[1], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
		break;
	case 2 :
		if( FALSE == m_bIsLive )
			gAcuOverlay2.SetStringItem(m_nLive[2], -11, 0, CENTER_X + dLivePos.x, CENTER_Y, -13, _T(""));
		else
			gAcuOverlay2.SetStringItem(m_nLive[2], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
		break;
	case 3 :
		if( FALSE == m_bIsLive )
			gAcuOverlay3.SetStringItem(m_nLive[3], -11, 0, CENTER_X + dLivePos.x, CENTER_Y, -13, _T(""));
		else
			gAcuOverlay3.SetStringItem(m_nLive[3], -11, 0, CENTER_X + dLivePos.x, CENTER_Y + dLivePos.y, -13, _T("LIVE"));
		break;
	}

	m_evtUseOmiVision.SetEvent();

	OnAcquire(nCamNo);
*/
	CString strOrder = _T("");
	strOrder.Format(_T("SVZUM@%d@%d"), nCamNo, nZoom);
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("SVZUM"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
	    bReturn = GetTcpIpResult(_T("SVZUM"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Set Vision Zoom Fail(TCP/IP)"));
	}
#endif

}

BOOL HVisionOmi::GetRealPos(DPOINT* rPos, int nCam, BOOL bRefresh, double& dSize, char* pChar)
{
/*	CString strMsg;
	
	if(gSystemINI.m_sSystemDevice.nNoUseVision)
	{
		if(pChar != NULL)
		{
			strMsg.Format(_T(_T("X : 0.000, Y : 0.000")));
			memcpy(pChar, strMsg, strMsg.GetLength()+1);
		}
		rPos->x = 0.0;
		rPos->y = 0.0;
		return TRUE;
	}

	if(bRefresh)
		OnCamChange(nCam);

	OnFindFiducial(nCam, strMsg);
	dSize = m_dResultSize;
	if(pChar != NULL)
	{
		memcpy(pChar, strMsg, strMsg.GetLength()+1);
	}

	rPos->x = m_dPos.x;
	rPos->y = m_dPos.y;	

#ifdef __TEST__
	rPos->x = m_dPos.x = 0.0;
	rPos->y = m_dPos.y = 0.0;
#endif

	if (m_dPos.y == 999 || m_dPos.x == 999)
		return FALSE;

	return TRUE;
*/
	CString strOrder = _T("");
	strOrder.Format(_T("GRLPS@%d@%d"), nCam, bRefresh);
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpRealPos(rPos, dSize, pChar);
	int nCount  = 0;
	while(bReturn == 2 && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpRealPos(rPos, dSize, pChar);
		nCount++;
	}
	return bReturn;

}

void HVisionOmi::ShowArea(int nShow)
{

#ifndef USE_VISION_PRO
/*	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );
	
	gAcuArea0.Show(nShow);
	gAcuArea1.Show(nShow);
	gAcuArea2.Show(nShow);
	gAcuArea3.Show(nShow);
	
	m_evtUseOmiVision.SetEvent();
*/
	CString strOrder = _T("");
	strOrder.Format(_T("SAREA@%d"), nShow);
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("SAREA"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("SAREA"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Show Area Fail(TCP/IP)"));
	}
#endif

}

void HVisionOmi::SetInspectionArea(int nSize)
{

#ifndef USE_VISION_PRO
/*	::WaitForSingleObject( m_evtUseOmiVision, INFINITE );
	
	if (nSize == -1 || nSize < 2 || nSize > SCREEN_PIXEL_X - 2)
	{
		gAcuArea0.SetCoor(0, 0, SCREEN_PIXEL_X, SCREEN_PIXEL_Y);
		gAcuArea1.SetCoor(0, 0, SCREEN_PIXEL_X, SCREEN_PIXEL_Y);
		gAcuArea2.SetCoor(0, 0, SCREEN_PIXEL_X, SCREEN_PIXEL_Y);
		gAcuArea3.SetCoor(0, 0, SCREEN_PIXEL_X, SCREEN_PIXEL_Y);
	}
	else
	{
		gAcuArea0.SetCoor((SCREEN_PIXEL_X - nSize) / 2, (SCREEN_PIXEL_Y - nSize) / 2, nSize, nSize);
		gAcuArea1.SetCoor((SCREEN_PIXEL_X - nSize) / 2, (SCREEN_PIXEL_Y - nSize) / 2, nSize, nSize);
		gAcuArea2.SetCoor((SCREEN_PIXEL_X - nSize) / 2, (SCREEN_PIXEL_Y - nSize) / 2, nSize, nSize);
		gAcuArea3.SetCoor((SCREEN_PIXEL_X - nSize) / 2, (SCREEN_PIXEL_Y - nSize) / 2, nSize, nSize);
	}
	
	m_evtUseOmiVision.SetEvent();
*/
	CString strOrder = _T("");
	strOrder.Format(_T("SINPA@%d"), nSize);
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("SINPA"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("SINPA"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Set Inspection Fail(TCP/IP)"));
	}
#endif

}

void HVisionOmi::InitVisionPixelData(int nCam)
{
/*	gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][0].x = 0; gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][0].y = 0;
	gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][0].x = 0; gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][0].y = 0;
	
	gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][1].x = gSystemINI.m_sSystemDevice.nCameraPixelX; gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][1].y = 0;
	gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][1].x = gSystemINI.m_sSystemDevice.nCameraPixelX; gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][1].y = 0;
	
	gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][2].x = 0; gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][2].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
	gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][2].x = 0; gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][2].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
	
	gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][3].x = gSystemINI.m_sSystemDevice.nCameraPixelX; gSystemINI.m_sSystemDevice.dVisionPixcel1[nCam][3].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
	gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][3].x = gSystemINI.m_sSystemDevice.nCameraPixelX; gSystemINI.m_sSystemDevice.dVisionPixcel2[nCam][3].y = gSystemINI.m_sSystemDevice.nCameraPixelY;
	
	TransformPixel();
	CalPixelDistance();
*/
	CString strOrder = _T("");
	strOrder.Format(_T("IVPXD@%d"), nCam);
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("IVPXD"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("IVPXD"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Init Vision Pixel Data Fail(TCP/IP)"));
	}
}

void HVisionOmi::TransformPixel()
{
/*	for(int i = 0 ; i < MAX_CAMERA ; i ++ )
	{
		m_2DTrans[i].SetNumPoint(4);
		
		m_2DTrans[i].SetReferencePoint(gSystemINI.m_sSystemDevice.dVisionPixcel1[i][0].x, gSystemINI.m_sSystemDevice.dVisionPixcel1[i][0].y, 0);
		m_2DTrans[i].SetTransformedPoint(gSystemINI.m_sSystemDevice.dVisionPixcel2[i][0].x, gSystemINI.m_sSystemDevice.dVisionPixcel2[i][0].y, 0);
		
		m_2DTrans[i].SetReferencePoint(gSystemINI.m_sSystemDevice.dVisionPixcel1[i][1].x, gSystemINI.m_sSystemDevice.dVisionPixcel1[i][1].y, 1);
		m_2DTrans[i].SetTransformedPoint(gSystemINI.m_sSystemDevice.dVisionPixcel2[i][1].x, gSystemINI.m_sSystemDevice.dVisionPixcel2[i][1].y, 1);
		
		m_2DTrans[i].SetReferencePoint(gSystemINI.m_sSystemDevice.dVisionPixcel1[i][2].x, gSystemINI.m_sSystemDevice.dVisionPixcel1[i][2].y, 2);
		m_2DTrans[i].SetTransformedPoint(gSystemINI.m_sSystemDevice.dVisionPixcel2[i][2].x, gSystemINI.m_sSystemDevice.dVisionPixcel2[i][2].y, 2);
		
		m_2DTrans[i].SetReferencePoint(gSystemINI.m_sSystemDevice.dVisionPixcel1[i][3].x, gSystemINI.m_sSystemDevice.dVisionPixcel1[i][3].y, 3);
		m_2DTrans[i].SetTransformedPoint(gSystemINI.m_sSystemDevice.dVisionPixcel2[i][3].x, gSystemINI.m_sSystemDevice.dVisionPixcel2[i][3].y, 3);
		
		m_2DTrans[i].Transform();
	}
*/
	CString strOrder = _T("");
	strOrder.Format(_T("TFPXL"));
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("TFPXL"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("TFPXL"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Transform Pixel Fail(TCP/IP)"));
	}
}

void HVisionOmi::CalPixelDistance()
{
/*	double dHighCamPixelX, dHighCamPixelY, dLowCamPixelX, dLowCamPixelY;
	double dHighFOVX, dHighFOVY, dLowFOVX, dLowFOVY;
	if(gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].x != gSystemINI.m_sSystemDevice.dVisionPixcel2[0][1].x)
	{
		dHighCamPixelX = gSystemINI.m_sSystemDevice.dVisionPixcel1[0][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel1[0][1].x;
		dHighFOVX = gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel2[0][1].x; 
		m_dHighPixel.x = fabs(dHighFOVX / dHighCamPixelX);
	}
	else if(gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].x != gSystemINI.m_sSystemDevice.dVisionPixcel2[0][2].x)
	{
		dHighCamPixelX = gSystemINI.m_sSystemDevice.dVisionPixcel1[0][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel1[0][2].x;
		dHighFOVX = gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel2[0][2].x; 
		m_dHighPixel.x = fabs(dHighFOVX / dHighCamPixelX);
	}
	else
	{
		m_dHighPixel.x = m_dHighPixel.y = 1; // �����ȵǴ� ū �� : ����ڰ� �˾�������� �ǹ�
	}
	
	if(gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].y != gSystemINI.m_sSystemDevice.dVisionPixcel2[0][1].y)
	{
		dHighCamPixelY = gSystemINI.m_sSystemDevice.dVisionPixcel1[0][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel1[0][1].y;
		dHighFOVY = gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel2[0][1].y;
		m_dHighPixel.y = fabs(dHighFOVY / dHighCamPixelY);
	}
	else if(gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].y != gSystemINI.m_sSystemDevice.dVisionPixcel2[0][2].y)
	{
		dHighCamPixelY = gSystemINI.m_sSystemDevice.dVisionPixcel1[0][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel1[0][2].y;
		dHighFOVY = gSystemINI.m_sSystemDevice.dVisionPixcel2[0][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel2[0][2].y;
		m_dHighPixel.y = fabs(dHighFOVY / dHighCamPixelY);
	}
	else
	{
		m_dHighPixel.x = m_dHighPixel.y = 1; // �����ȵǴ� ū �� : ����ڰ� �˾�������� �ǹ�
	}
	
	if(gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].x != gSystemINI.m_sSystemDevice.dVisionPixcel2[1][1].x)
	{
		dLowCamPixelX = gSystemINI.m_sSystemDevice.dVisionPixcel1[1][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel1[1][1].x;
		dLowFOVX = gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel2[1][1].x; 
		m_dLowPixel.x = fabs(dLowFOVX / dLowCamPixelX);
	}
	else if(gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].x != gSystemINI.m_sSystemDevice.dVisionPixcel2[1][2].x)
	{
		dLowCamPixelX = gSystemINI.m_sSystemDevice.dVisionPixcel1[1][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel1[1][2].x;
		dLowFOVX = gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].x - gSystemINI.m_sSystemDevice.dVisionPixcel2[1][2].x; 
		m_dLowPixel.x = fabs(dLowFOVX / dLowCamPixelX);
	}
	else
	{
		m_dLowPixel.x = m_dLowPixel.y = 1; // �����ȵǴ� ū �� : ����ڰ� �˾�������� �ǹ�
	}
	
	if(gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].y != gSystemINI.m_sSystemDevice.dVisionPixcel2[1][1].y)
	{
		dLowCamPixelY = gSystemINI.m_sSystemDevice.dVisionPixcel1[1][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel1[1][1].y;
		dLowFOVY = gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel2[1][1].y;
		m_dLowPixel.y = fabs(dLowFOVY / dLowCamPixelY);
	}
	else if(gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].y != gSystemINI.m_sSystemDevice.dVisionPixcel2[1][2].y)
	{
		dLowCamPixelY = gSystemINI.m_sSystemDevice.dVisionPixcel1[1][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel1[1][2].y;
		dLowFOVY = gSystemINI.m_sSystemDevice.dVisionPixcel2[1][0].y - gSystemINI.m_sSystemDevice.dVisionPixcel2[1][2].y;
		m_dLowPixel.y = fabs(dLowFOVY / dLowCamPixelY);
	}
	else
	{
		m_dLowPixel.x = m_dLowPixel.y = 1; // �����ȵǴ� ū �� : ����ڰ� �˾�������� �ǹ�
	}
*/
	CString strOrder = _T("");
	strOrder.Format(_T("CPDIS"));
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("CPDIS"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("CPDIS"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Cal Pixel Distance Fail(TCP/IP)"));
	}

}

void HVisionOmi::InitDistancePerPixel()
{
/*	m_dHighPixel.x = fabs(gSystemINI.m_sSystemDevice.dHighFOVX / gSystemINI.m_sSystemDevice.nCameraPixelX);
	m_dHighPixel.y = fabs(gSystemINI.m_sSystemDevice.dHighFOVY / gSystemINI.m_sSystemDevice.nCameraPixelY);
	m_dLowPixel.x = fabs(gSystemINI.m_sSystemDevice.dLowFOVX / gSystemINI.m_sSystemDevice.nCameraPixelX);
	m_dLowPixel.y = fabs(gSystemINI.m_sSystemDevice.dLowFOVY / gSystemINI.m_sSystemDevice.nCameraPixelY);
*/
	CString strOrder = _T("");
	strOrder.Format(_T("IDPPX"));
	m_pClientSock->Send(strOrder, strlen(strOrder));
	BOOL bReturn = GetTcpIpResult(_T("IDPPX"));
	int nCount  = 0;
	while(!bReturn && nCount < 5)
	{
		SendMessage(m_pVisionHndle->m_hWnd, UM_OMI_RECONNECT , NULL, NULL);
		Sleep(100);
		ConnectOmiVision();
		Sleep(100);
		m_pClientSock->Send(strOrder, strlen(strOrder));
		bReturn = GetTcpIpResult(_T("IDPPX"));
		nCount++;
	}
	if(!bReturn)
	{
		ErrMessage(_T("Init Distance Per Pixel Fail(TCP/IP)"));
	}
}
UINT HVisionOmi::LiveThread(LPVOID pParam)
{
	HVisionOmi *pRun = (HVisionOmi *)pParam;

/*	while(TRUE)
	{
		Sleep(50);
		if(pRun->m_bIsLive)
		{
			pRun->OnAcquire(pRun->m_nCam);
		}
	}
	*/
	return 1;
}

BOOL HVisionOmi::GetTcpIpResult(CString strOrder)
{
	if(CWnd::FindWindowA(NULL, _T("OmiVisionCom_TCP_IP")) == NULL)
		return FALSE;

	char strBuf[255];
	char chReturnValue[255];
	CString strReturn = _T("");
	ZeroMemory(strBuf, sizeof(strBuf));
	ZeroMemory(chReturnValue, sizeof(chReturnValue));
	m_pClientSock->Receive(strBuf, 255);

	char* pToken;
	char* strData[100];
	//	char* strGubun[100];
	CString strToken = _T("");
	CString strOffset = _T("");
	int nCount = 0;
	int nTimeOut = 0;
	
	for(int i = 0; i < 100; i++)
	{
		strData[i] = _T("");
	}
	pToken = strtok(strBuf, _T("@"));

	while(TRUE)
	{
		while(pToken != NULL)
		{
			strData[nCount] = pToken;
			pToken = strtok(NULL, _T("@"));
			nCount++;
		}
		
		if(strcmp(strData[0], strOrder) == 0)
		{
			if(strcmp(strOrder, _T("INITV")) == 0 ||
			   strcmp(strOrder, _T("OCONV")) == 0 ||
			   strcmp(strOrder, _T("OCAMC")) == 0 ||
			   strcmp(strOrder, _T("OACQR")) == 0 ||
			   strcmp(strOrder, _T("OCONT")) == 0 ||
			   strcmp(strOrder, _T("OBRIT")) == 0 ||
			   strcmp(strOrder, _T("SAVEI")) == 0 ||
			   strcmp(strOrder, _T("OLIVE")) == 0 ||
			   strcmp(strOrder, _T("OAPVP")) == 0 ||
			   strcmp(strOrder, _T("OAVPM")) == 0 ||
			   strcmp(strOrder, _T("OLIGT")) == 0 ||
			   strcmp(strOrder, _T("SVZUM")) == 0 ||
			   strcmp(strOrder, _T("SPIXL")) == 0 ||
			   strcmp(strOrder, _T("SAREA")) == 0 ||
			   strcmp(strOrder, _T("SINPA")) == 0 ||
			   strcmp(strOrder, _T("IDPPX")) == 0 ||
			   strcmp(strOrder, _T("CPDIS")) == 0 ||
			   strcmp(strOrder, _T("TFPXL")) == 0 ||
			   strcmp(strOrder, _T("IVPXD")) == 0 )
			{
				if(strcmp(strData[1],_T("ACK")) == 0)
				{
					return TRUE;
				}
			}
			else if(strcmp(strOrder, _T("LOMIP")) == 0 ||
					strcmp(strOrder, _T("GISLV")) == 0 )
			{
				if(strcmp(strData[1],_T("TRUE")) == 0)
				{
					return TRUE;
				}
				else if(strcmp(strData[1],_T("FALSE")) == 0)
				{
					return FALSE;
				}
			}
		}

		ZeroMemory(strBuf, sizeof(strBuf));
		m_pClientSock->Receive(strBuf, 255);
		pToken = strtok(strBuf, _T("@"));
		nCount = 0;
		nTimeOut++;
		Sleep(10);
		if(nTimeOut > 500)
		{
			return FALSE;
		}
	}

}

BOOL HVisionOmi::GetTcpIpFindFiducial(CString& strMsg)
{
	char strBuf[255];
	char chReturnValue[255];
	CString strReturn = _T("");
	ZeroMemory(strBuf, sizeof(strBuf));
	ZeroMemory(chReturnValue, sizeof(chReturnValue));
	m_pClientSock->Receive(strBuf, 255);

	char* pToken;
	char* strData[100];
	//	char* strGubun[100];
	CString strToken = _T("");
	CString strOffset = _T("");
	int nCount = 0;
	int nTimeOut = 0;
	
	for(int i = 0; i < 100; i++)
	{
		strData[i] = _T("");
	}
	pToken = strtok(strBuf, _T("@"));

	while(TRUE)
	{
		while(pToken != NULL)
		{
			strData[nCount] = pToken;
			pToken = strtok(NULL, _T("@"));
			nCount++;
		}
		
		if(strcmp(strData[0], _T("OFINF")) == 0)
		{
			strMsg.Format("%s", strData[1]);

			if(strcmp(strData[2], _T("TRUE")) == 0)
			{
				return TRUE;
			}
			else if(strcmp(strData[2], _T("FALSE")) == 0)
			{
				return FALSE;
			}
		}

		ZeroMemory(strBuf, sizeof(strBuf));
		m_pClientSock->Receive(strBuf, 255);
		pToken = strtok(strBuf, _T("@"));
		nCount = 0;
		nTimeOut++;
		Sleep(10);
		if(nTimeOut > 100)
		{
			return 2;
		}
	}
}

BOOL HVisionOmi::GetTcpIpRealPos(DPOINT* rPos, double& dSize, char* pChar)
{
	char strBuf[255];
	char chReturnValue[255];
	CString strReturn = _T("");
	ZeroMemory(strBuf, sizeof(strBuf));
	ZeroMemory(chReturnValue, sizeof(chReturnValue));
	m_pClientSock->Receive(strBuf, 255);

	char* pToken;
	char* strData[100];
	//	char* strGubun[100];
	CString strToken = _T("");
	CString strOffset = _T("");
	int nCount = 0;
	int nTimeOut = 0;
	
	for(int i = 0; i < 100; i++)
	{
		strData[i] = _T("");
	}
	pToken = strtok(strBuf, _T("@"));

	while(TRUE)
	{
		while(pToken != NULL)
		{
			strData[nCount] = pToken;
			pToken = strtok(NULL, _T("@"));
			nCount++;
		}
		
		if(strcmp(strData[0], _T("GRLPS")) == 0)
		{
			rPos->x = atof(strData[1]);
			rPos->y = atof(strData[2]);
			dSize = atof(strData[3]);	
			if(strData[4] != NULL && pChar != NULL)
			{
				memcpy(pChar, strData[4], strlen(strData[4]) + 1);
			}

			if(strcmp(strData[5], _T("TRUE")) == 0)
			{
				return TRUE;
			}
			else if(strcmp(strData[5], _T("FALSE")) == 0)
			{
				return FALSE;
			}
		}

		ZeroMemory(strBuf, sizeof(strBuf));
		m_pClientSock->Receive(strBuf, 255);
		pToken = strtok(strBuf, _T("@"));
		nCount = 0;
		nTimeOut++;
		Sleep(10);
		if(nTimeOut > 100)
		{
			return 2;
		}
	}
}
void HVisionOmi::ConnectOmiVision()
{
	if(m_pClientSock != NULL)
	{
		m_pClientSock->Close();
		delete m_pClientSock;
		m_pClientSock = NULL;
	}
	if(m_pClientSock == NULL)
	{
		AfxSocketInit();
 		m_pClientSock = new CClientSock();
 		m_pClientSock->Create();
	}

	if(!m_pClientSock->Connect(_T("127.0.0.1"), 5252))
	{
		m_pClientSock->m_bConnect = FALSE;
	}
	else
	{
		m_pClientSock->m_bConnect = TRUE;
	}
}
BOOL HVisionOmi::CheckOmiHandle()
{
	if(m_pVisionHndle == NULL)
		return FALSE;
	else
		return TRUE;
}
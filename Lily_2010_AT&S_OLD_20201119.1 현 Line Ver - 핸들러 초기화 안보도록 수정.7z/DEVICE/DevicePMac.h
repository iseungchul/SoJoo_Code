// DevicePMac.h: interface for the DevicePMac class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVICEPMAC_H__DF007769_11D6_4EBA_B4C7_526A4ABFC83F__INCLUDED_)
#define AFX_DEVICEPMAC_H__DF007769_11D6_4EBA_B4C7_526A4ABFC83F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CorrectTime.h"

#define ScaleX 5000
#define ScaleY 5000
#define ScaleZ 1000

typedef struct {
	///////////////////////////////////////// PLC -> PC  ////////////////////////////////////////////
	//$61000 ?
	UINT m_bStartLamp:1;				// 0
	UINT m_bStopLamp:1;					// 1 
	UINT m_bResetLamp:1;				// 2
	UINT m_bInitialLamp:1;				// 3
	UINT m_bOPKeyboardLamp:1;			// 4
	UINT m_bVIKeyboardLamp:1;			// 5
	UINT m_bClampLamp:1;				// 6
	UINT m_bUnclampLamp:1;				// 7
	UINT m_bMpgLed:1;					// 8
	UINT m_bClampOpenClose:1;			// 9
	UINT m_bOPDoorOpenClose:1;			// 10
	UINT m_bOPSlideExtRet:1;			// 11
	UINT m_bVIDoorOpenClose:1;			// 12
	UINT m_bVISlideExtRet:1;			// 13
	UINT m_bAirBlowSol:1;				// 14
	UINT m_bSpare61000:17;				// 15 ~ 31

	//$61001 ?
	UINT m_bMarkStart:1;				// 0
	UINT m_bHandlerReady1:1;			// 1 
	UINT m_bHandlerError1:1;			// 2
	UINT m_bSpare61001_3:1;				// 3
	UINT m_bHandlerReady2:1;			// 4
	UINT m_bHandlerError2:1;			// 5 
	UINT m_bVisionStart1:1;				// 6
	UINT m_bVisionStart2:1;				// 7
	UINT m_bVisionStart3:1;				// 8
	UINT m_bVisionStart4:1;				// 9 
	UINT m_bSpare61001:22;				// 10 ~ 31
	
} DpramReadPosition1;

typedef struct {
	///////////////////////////////////////// PLC -> PC  ////////////////////////////////////////////
	//$60EFE
	UINT m_bSpare60EFE_0:1;				// 0
	UINT m_bXStop:1;					// 1 
	UINT m_bYStop:1;					// 2
	UINT m_bCStop:1;					// 3
	UINT m_bZStop:1;					// 4
	UINT m_bSpare60EFE:27;				// 5 ~ 31
	
	//$60EFF
	UINT m_bSystemInitial:1;			// 0
	UINT m_bXinitial:1;					// 1 
	UINT m_bYinitial:1;					// 2
	UINT m_bCinitial:1;					// 3
	UINT m_bZinitial:1;					// 4
	UINT m_bSpare60EFF_5:1;				// 5
	UINT m_bSpare60EFF_6:1;				// 6
	UINT m_bLogicError:1;				// 7
	UINT m_bHandlerAlarm:1;				// 8
	UINT m_bPlcReady:1;					// 9
	UINT m_bMPGreset:1;					// 10
	UINT m_bAutoStart:1;				// 11
	UINT m_bAutoStop:1;					// 12
	UINT m_bErrorReset:1;				// 13
	UINT m_bSpare60EFF:18;				// 14 ~ 31
	
} DpramReadPosition2;

class DevicePMac : public CWnd
{
public:
	static UINT ThreadPMacStatus(LPVOID pParam);
	static UINT ThreadPMacInPosition(LPVOID pParam);
	BOOL Initialize();
	DevicePMac();
	virtual ~DevicePMac();

	int	m_nAxisMax;

	void ReadStatus(BOOL bFirst);
	BOOL m_bStatusStop;			// Thread Stop Signal

	void ReadStatusIO1();
	void ReadStatusIO2();
	void ReadStatusIO3();
	void ReadStatusIO4();

	BOOL PeekMessage();
	BOOL IsMoveEnd(int nAxis = -1);
	BOOL IsInPositionThread(int nAxis, BYTE nCommand);
	void ReadPosition();
	BOOL GetPosition(int nAxis, double& dPosition);
	int  IsInPosition(int nAxis = -1, BOOL bWait = TRUE);
	BOOL InPositionIO(int nAxis);

	BOOL MotorMoveAxis(int nAxis, double dPosition);
	BOOL MotorMoveXY(double dPosX, double dPosY);
	BOOL MotorMoveZ(double dPosZ);
	BOOL MotorMoveXYZ(double dPosX, double dPosY, double dPosZ);

	BOOL SetOutPort(BYTE nPortNo, WORD wOnOff);
	
	BOOL SetSpeed(int nAxis, long lSpeed);

	LONG m_lStatusIO1;
	LONG m_lStatusIO2;
	LONG m_lStatusIO3;
	LONG m_lStatusIO4;

	DpramReadPosition1 m_OldStatus1;
	DpramReadPosition1 m_NewStatus1;

	DpramReadPosition2 m_OldStatus2;
	DpramReadPosition2 m_NewStatus2;

	double	m_dActualPosX;
	double	m_dActualPosY;
	double	m_dActualPosZ;

	double			m_dWritePos[3];
	BOOL			m_bIsInPosition[3];
	BOOL			m_bCommandStop;
	BYTE			m_nInPositionCommand;	// Thread Stop Signal
	int				m_nInPositionAxis;		// Thread InPosition Axis
	int				m_nIsInPosition;		// Thread Stop Signal
	CCorrectTime	m_pStopTime;
	BOOL			m_bPositionStop;		// Thread Stop Signal
	int				m_nInPositionCount;
	int				m_nInPositionError;

protected:
	CWinThread*		m_thdStatus;
	CWinThread*		m_thdInPosition;		// Window Thread Inposition
};

#endif // !defined(AFX_DEVICEPMAC_H__DF007769_11D6_4EBA_B4C7_526A4ABFC83F__INCLUDED_)

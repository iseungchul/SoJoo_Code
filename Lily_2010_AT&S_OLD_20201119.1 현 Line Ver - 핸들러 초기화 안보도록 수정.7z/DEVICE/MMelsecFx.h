// MMelsecFx.h: interface for the MMelsec class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MMELSECFX_H__1AD6C67C_B47B_4101_AA91_1EE0C4FB8457__INCLUDED_)
#define AFX_MMELSECFX_H__1AD6C67C_B47B_4101_AA91_1EE0C4FB8457__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#pragma comment(lib, "ws2_32.lib")

//#include <winsock2.h>

const int MAXBUFSIZE = 256;
#define MAX_DATA_SIZE		512

const WORD  CMD_TOTAL_READ_BIT	= 0x00;
const WORD  CMD_TOTAL_READ_WORD	= 0x01;
const WORD  CMD_TOTAL_WRITE_BIT	= 0x02;
const WORD  CMD_TOTAL_WRITE_WORD= 0x03;
const WORD  CMD_RANDOM_WRITE_BIT= 0x04;
const WORD  CMD_RANDOM_WRITE_WORD= 0x04;

const BYTE	CMD_DEVICE_NAME_H = 0x52; // R �޸� 
const BYTE	CMD_DEVICE_NAME_L = 0x20;

const WORD  SUBCMD_BIT			= 0x0001;
const WORD  SUBCMD_WORD			= 0x0000;

const BYTE  INTERNALRELAY		= 0x90;
const BYTE  DATAREGISTER		= 0xA8;

#define BASE_READ_ADDRESS		1050
#define BASE_WRITE_ADDRESS		1000
#define REC_DATA_DEVICE_NO_POS	4
#define REC_DATA_HEAD_LENG		6
#define EXCEPT_CHAR_LENG		9
#define SIZE_WAIT_TIME			2
struct QRESPONSE_DATA
{
	BYTE cSubHeader;
	BYTE cCompleateCode;
	BYTE cData[MAX_DATA_SIZE];	// real data
};

struct QCOMMAND_HEADER
{
	BYTE	cSubHeader1;			// sub-header no
	BYTE	cPCNo1;
	BYTE	wCPUWaitTime[2];		// CPU Waiting time
};


struct QCOMMAND_DATA
{
	QCOMMAND_HEADER	sHeader;				// QSEND_HEADER
	BYTE			cData[MAX_DATA_SIZE];	// real data
};



class MMelsecFx
{
public:
	MMelsecFx();
	virtual ~MMelsecFx();
	
	// Operations
public :
	BOOL WriteMemsbyWord(WORD *wData, WORD wAddress, WORD nSize);
	BOOL ReadMemsbyWord(WORD* wData, WORD wAddress, WORD nSize);
	void InitCommand();
	BOOL			Create();
	BOOL			InitWinSock();
	BOOL			Connect();
	void			CloseWinSock();
	
	int				SendMsg(char* pData, int nDataSize);
	int				RecvMsg(char* pData, int nDataSize);
	
	void			ShowErrMsg(CString strMsg);
	
	BOOL			IsConnect();
	
	int				GetCommErrorCount()		{ return m_nCommErrorCount; }
	
	//Attributes
protected :
	QCOMMAND_DATA	m_qSendData;
	QCOMMAND_DATA	m_qRecieveData;
	QRESPONSE_DATA  m_qResponse;
	CRITICAL_SECTION	m_CritSocket;
	SOCKET			m_hLocalSocket;
	
	USHORT			m_nDestPortNo;
	CString			m_strDestAddr;
	SOCKADDR_IN		m_sDestAddr;
	
	USHORT			m_nLocalPortNo;
	CString			m_strLocalAddr;
	SOCKADDR_IN		m_sLocalAddr;
	
	int				m_nCommErrorCount;

	int				m_nTimeOut;
};

#endif // !defined(AFX_MMELSECFX_H__1AD6C67C_B47B_4101_AA91_1EE0C4FB8457__INCLUDED_)

// Calibration.cpp: implementation of the CCalibration class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "Calibration.h"
#include "..\MODEL\DSystemINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const char WHOLE_TABLE_CALIBRATION_FILE[] = _T("xy.calibration");
const char WHOLE_TABLE_CALIBRATION_FILE_SLAVE[] = _T("xy.Scalibration");

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCalibration::CCalibration()
{
	Clear();
}

CCalibration::~CCalibration()
{
//	SaveCalibration();

	delete [] m_Offset;
	m_Offset = NULL;
}

void CCalibration::Clear()
{
	m_bIsSet = FALSE;
	m_bFirst = TRUE;
	m_nGridX = 0;
	m_nGridY = 0;
	m_dGap = 0.0;
	m_dXStart = 0.0;
	m_dXEnd = 0.0;
	m_dYStart = 0.0;
	m_dYEnd = 0.0;
	
	m_Offset = NULL;
	m_b1stPanel = TRUE;
}

void CCalibration::SetMatrixToZero()
{
	for (int i = 0; i < MAX_TABLE_SIZE; i++)
	{
		for (int j = 0; j < MAX_TABLE_SIZE; j++)
		{
			m_Matrix[i][j].x = 0.0f;
			m_Matrix[i][j].y = 0.0f;
		}
	}
}

void CCalibration::SaveCalibration()
{
	FILE *fp = NULL;
	if (NULL == fopen_s(&fp, m_strPath, "wb"))
	{
		size_t numWrite = fwrite(m_Matrix, sizeof(FLOATPOINT), MAX_TABLE_SIZE * MAX_TABLE_SIZE, fp);
		ASSERT(numWrite == MAX_TABLE_SIZE * MAX_TABLE_SIZE);
		fclose(fp);
	}
}

void CCalibration::LoadCalibration(CString strPath)
{
	if (m_bFirst)
	{
		m_strPath = strPath;
		m_bFirst = FALSE;
	}

	FILE* fp = NULL;
	CString strError;
	if (NULL == fopen_s(&fp, m_strPath, "rb"))
	{
		size_t numRead = fread(m_Matrix, sizeof(FLOATPOINT), MAX_TABLE_SIZE * MAX_TABLE_SIZE, fp);
		if (numRead != MAX_TABLE_SIZE * MAX_TABLE_SIZE)
		{
#ifndef __TEST__
			if(gSystemINI.m_sHardWare.bLaserCalAlarm)
			{
				int nResult;
				CString strString;
				strString.LoadString(IDS_ERR_NO_FILE);
				strError.Format(strString, m_strPath);
				do 
				{
					nResult = ErrMessage(strError, MB_OK);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strError));

				} while(nResult != IDOK);
			}
#endif
			SetMatrixToZero();
		}

		fclose(fp);
	}
	else
	{
#ifndef __TEST__
		if(gSystemINI.m_sHardWare.bLaserCalAlarm)
		{
			int nResult;
			CString strString;
			strString.LoadString(IDS_ERR_NO_FILE);
			strError.Format(strString, m_strPath);
			do 
			{
				nResult = ErrMessage(strError, MB_OK);	
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strError));
			} while(nResult != IDOK);
		}
#endif
		SetMatrixToZero();
	}


/*	for(int i = 0; i < MAX_TABLE; i++)
	{
		for(int j = MAX_TABLE - 1 - 10; j >= -10; j--)
		{
			if(j >=0)
			{
				m_Matrix[i][j + 10].x = m_Matrix[i][j].x;
				m_Matrix[i][j + 10].y = m_Matrix[i][j].y;
			}
			else
			{
				m_Matrix[i][j + 10].x = m_Matrix[i][0].x;
				m_Matrix[i][j + 10].y = m_Matrix[i][0].y;
			}
		}
	}
	SaveCalibration();
*/
/*	FILE* fpSave = NULL;
	CString str;
	double dXOffset, dYOffset;
	str.Format(_T("%s.txt"), strFileName);
	fpSave = fopen_s(str, "w");
	for(int i = 0; i < 100; i++)
	{
		for(int j = 0; j < 100; j++)
		{
			GetCalibrationOffset(i*10, j*10, dXOffset, dYOffset);
			fprintf(fpSave, _T("X\t%d\tY\t%d\tdx\t%.3f\tdy\t%.3f\n") ,i*10, j*10, dXOffset, dYOffset);
		}
	}
	fclose(fpSave);
*/
}

void CCalibration::UpdateCalibration(const CALHEAD& calHead)
{
	m_nGridX = calHead.nGridX;
	m_nGridY = calHead.nGridY;
	m_dGap = calHead.dGap;
	m_dXStart = calHead.dXStart;
	m_dXEnd = m_dXStart + m_dGap * (m_nGridX - 1);
	m_dYStart = calHead.dYStart;
	m_dYEnd = m_dYStart + m_dGap * (m_nGridY - 1);

	TRY
	{
		delete [] m_Offset;
		m_Offset = NULL;
		m_Offset = new DPOINT[m_nGridX * m_nGridY];
		memcpy(m_Offset, calHead.dOffset, sizeof(DPOINT) * m_nGridX * m_nGridY);
		m_bIsSet = TRUE;
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		Clear();
		return;
	}
	END_CATCH

	UpdateWholeCalibration();
	SaveCalibration();
}

BOOL CCalibration::IsPartialInside(double dX, double dY)
{
	if (dX >= m_dXStart && dX <= m_dXEnd && dY >= m_dYStart && dY <= m_dYEnd)
		return TRUE;
	else
		return FALSE;
}

BOOL CCalibration::IsInside(double& dX, double& dY)
{
	if (dX >= MIN_TABLE && dX <= MAX_TABLE && dY >= MIN_TABLE && dY <= MAX_TABLE)
		return TRUE;
	else
	{
		if(dX < MIN_TABLE)
			dX = MIN_TABLE;
		if(dX > MAX_TABLE)
			dX = MAX_TABLE;

		if(dY < MIN_TABLE)
			dY = MIN_TABLE;
		if(dY > MAX_TABLE)
			dY = MAX_TABLE;

		return TRUE;
	}
}

void CCalibration::GetCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset)
{
	if (IsInside(dX, dY))
	{
		// index = m_nGridY * nX + nY
		int nX = static_cast<int>(dX - MIN_TABLE);
		int nY = static_cast<int>(dY - MIN_TABLE);
		
		double dXDist = dX - MIN_TABLE - nX;
		double dYDist = dY - MIN_TABLE - nY;
		
		double ax, bx, ay, by;
		
		if (nX == MAX_TABLE_SIZE - 1)
			ax = m_Matrix[nX][nY].x;
		else
			ax = m_Matrix[nX][nY].x + (m_Matrix[nX + 1][nY].x - m_Matrix[nX][nY].x) * dXDist;
		
		if (nY == MAX_TABLE_SIZE - 1)
			bx = ax;
		else if (nX == MAX_TABLE_SIZE - 1 && nY != MAX_TABLE_SIZE - 1)
			bx = m_Matrix[nX][nY + 1].x;
		else
			bx = m_Matrix[nX][nY + 1].x + (m_Matrix[nX + 1][nY + 1].x - m_Matrix[nX][nY + 1].x) * dXDist;
		
		if (nY == MAX_TABLE_SIZE - 1)
			ay = m_Matrix[nX][nY].y;
		else
			ay = m_Matrix[nX][nY].y + (m_Matrix[nX][nY + 1].y - m_Matrix[nX][nY].y) * dYDist;
		
		if (nX == MAX_TABLE_SIZE - 1)
			by = ay;
		else if (nX != MAX_TABLE_SIZE - 1 && nY == MAX_TABLE_SIZE - 1)
			by = m_Matrix[nX + 1][nY].y;
		else
			by = m_Matrix[nX + 1][nY].y + (m_Matrix[nX + 1][nY + 1].y - m_Matrix[nX + 1][nY].y) * dYDist;
		
		dXOffset = ax + (bx - ax) * dYDist;
		dYOffset = ay + (by - ay) * dXDist;
	}
	else
	{
		dXOffset = dYOffset = 0.0;
	}
}

void CCalibration::SetMaster(BOOL bMaster)
{
	m_b1stPanel = bMaster;
}
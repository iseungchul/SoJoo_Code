// HVision2DBarcodeSock.cpp : implementation file
//

#include "stdafx.h"
#include "HVision2DBarcodeSock.h"
#include "..\EasyDriller.h"
#include "..\Model\Glyph.h"
#include "..\EasyDrillerDlg.h"
#include "..\Model\DProcessINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	RECEIVE_STATUS_INIT				0
#define RECEIVED_MASTER_DX_DATA			1
#define RECEIVED_MASTER_DY_DATA			2
#define RECEIVED_MASTER_THETA_DATA		3

/////////////////////////////////////////////////////////////////////////////
// HVision2DBarcodeSock

HVision2DBarcodeSock::HVision2DBarcodeSock()
{
	m_bConnect = FALSE;
	memset(m_szRecv, 0, sizeof(m_szRecv));
}

HVision2DBarcodeSock::~HVision2DBarcodeSock()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(HVision2DBarcodeSock, CAsyncSocket)
	//{{AFX_MSG_MAP(HVision2DBarcodeSock)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CClientSock member functions

void HVision2DBarcodeSock::OnConnect(int nErrorCode) 
{
	m_bConnect = TRUE;
	CAsyncSocket::OnConnect(nErrorCode);
}

void HVision2DBarcodeSock::OnReceive(int nErrorCode) 
{
	ReceiveData();
	CAsyncSocket::OnReceive(nErrorCode);
}

void HVision2DBarcodeSock::OnClose(int nErrorCode) 
{
	m_bConnect = FALSE;
	CAsyncSocket::OnClose(nErrorCode);
}

BOOL HVision2DBarcodeSock::Connect(LPCTSTR lpszHostAddress, UINT nHostPort)
{
	BOOL bResult = CAsyncSocket::Connect(lpszHostAddress, nHostPort);
	
	if(bResult == FALSE)
	{
		int nErrorCode = CAsyncSocket::GetLastError();
		
		switch(nErrorCode)
		{
		case WSANOTINITIALISED:
		case WSAENETDOWN:
		case WSAEADDRINUSE:
		case WSAEINPROGRESS:
		case WSAEAFNOSUPPORT:
		case WSAECONNREFUSED:
		case WSAEDESTADDRREQ:
		case WSAEFAULT:
		case WSAEINVAL:
		case WSAEISCONN:
		case WSAEMFILE:
		case WSAENOBUFS:
		case WSAENOTSOCK:
		case WSAETIMEDOUT:
			TRACE(_T("Connection Failure.\n"));
			m_bConnect = FALSE;
			return FALSE;
			break;
		case WSAEWOULDBLOCK:
			// If an error code is WSAWOULDBLOCK, and your application
			// is using the override callbacks,
			// your application will receive an OnConnect message
			// when the connect operation is complete. -> refer to MSDN.
			TRACE(_T("Connection Success.\n"));
			m_bConnect = TRUE;
			return TRUE;
		default:
			TRACE(_T("Connection Failure.\n"));
			m_bConnect = FALSE;
			return FALSE;
		}
		return FALSE;
	}
	
	TRACE(_T("Connection Success.\n"));
	
	m_bConnect = TRUE;
	return (TRUE);
}

void HVision2DBarcodeSock::ReceiveData()
{
	char szTemp[256];
	memset(szTemp, 0, sizeof(szTemp));
	int nCount = 0;
	do
	{
		if(nCount >= 100)
			break;

		Receive(szTemp, 65535);
		Sleep(10);
		nCount++;

	}while(strcmp(szTemp, "") == 0);

	strcpy(m_szRecv, szTemp);
	return;

}
BOOL HVision2DBarcodeSock::SendData(CString strCmd)
{
//	strCmd = strCmd.TrimRight();
	int nSize = strCmd.GetLength();
	char szTemp2[256];
	memset(szTemp2,0, sizeof(szTemp2));
	strcpy(szTemp2, strCmd);
//	sprintf_s(szTemp2, 256, _T("%s\r\n"), strCmd); 
	return Send(szTemp2, nSize+1);

}
BOOL HVision2DBarcodeSock::GetTrigger()
{
	CString strCmd;
	strCmd.Format(_T("GET TRIGGER")); //get trigger 
	if(!SendData(strCmd))
		return FALSE;

	WaitRecv();

	if(strcmp(m_szRecv, "1") == 0)
		return TRUE;
	else
		return FALSE;
}

BOOL HVision2DBarcodeSock::SetTrigger(BOOL bOn)
{
	CString strCmd;
	BOOL bStatus = GetTrigger();
	if((bOn && bStatus) || (!bOn && !bStatus))
		return TRUE;

	strCmd.Format(_T("TRIGGER"));
	if(!SendData(strCmd))
		return FALSE;

	Sleep(100);
	bStatus = GetTrigger();

	if(bStatus == bOn)
		return TRUE;
	else
		return FALSE;
}
BOOL HVision2DBarcodeSock::ResultEncoding()
{
	CString strCmd;
	strCmd.Format(_T("SET DATA.RESULT-ENCODING 1")); 
	if(!SendData(strCmd))
		return FALSE;

	return TRUE;
}
void HVision2DBarcodeSock::WaitRecv()
{
	int nCount = 0;
	while(strcmp(m_szRecv, "") == 0)
	{
		if(nCount > 50)
			break;
	
		MessageLoopWait(100);

		nCount++;
	}
}
CString HVision2DBarcodeSock::GetResult()
{
	CString strCmd;
	memset(m_szRecv, 0, sizeof(m_szRecv));
	strCmd.Format(_T("||>TRIGGER ON\r\n")); // get data 
	if(!SendData(strCmd))
		return _T("");

	WaitRecv();

	strCmd.Format(_T("%s"), m_szRecv);

	return strCmd;

}
CString HVision2DBarcodeSock::GetBarcodeID()
{
 	return GetResult();
}

#include "stdafx.h"
#include "DevMCCDaq.h"
#include "cbw.h"
#include "math.h"

#define UM_WRITE_LOG		WM_USER+222


CDevMCCDaq::CDevMCCDaq(void)
{
	m_bPortOpen = FALSE;
	m_dTemperDiff = 0.2;
	memset(m_dTemperature, 0, sizeof(m_dTemperature));
	memset(m_dOldTemperature, 0, sizeof(m_dOldTemperature));

	m_dTemperMinLimit = 10;
	m_dTemperMaxLimit = 40;
	m_dTemperDeltaTLimit = 0.2;

	for(int i = 0; i < 5; i++)
	{
		for(int j = 0; j< 10; j++)
			m_dOldTemperature[i][j] = -999;
	}
	InitializeCriticalSection(&m_csCommunicationSync);
}

CDevMCCDaq::~CDevMCCDaq(void)
{
}

void CDevMCCDaq::SetParameter(int nPortNo, int nBaudRate, int nParity, int nDataBits, int nStopBits, int nFlowControl)
{
}

void CDevMCCDaq::SetChannelIndex(int nMTC1, int nMTC2, int nMSB1, int nMSB2, int nSTC1, int nSTC2, int nSSB1, int nSSB2)
{
	if(nMTC1 < 0 || nMTC1 > 9)
		nMTC1 = -1;
	if(nMTC2 < 0 || nMTC2 > 9)
		nMTC2 = -1;
	if(nMSB1 < 0 || nMSB1 > 9)
		nMSB1 = -1;
	if(nMSB2 < 0 || nMSB2 > 9)
		nMSB2 = -1;

	if(nSTC1 < 0 || nSTC1 > 9)
		nSTC1 = -1;
	if(nSTC2 < 0 || nSTC2 > 9)
		nSTC2 = -1;
	if(nSSB1 < 0 || nSSB1 > 9)
		nSSB1 = -1;
	if(nSSB2 < 0 || nSSB2 > 9)
		nSSB2 = -1;

	m_nTCMasterCH1 = nMTC1;
	m_nTCMasterCH2 = nMTC2;
	m_nTCSlaveCH1 = nSTC1;
	m_nTCSlaveCH2 = nSTC2;
	m_nSBMasterCH1 = nMSB1 ;
	m_nSBMasterCH2 =nMSB2 ;
	m_nSBSlaveCH1 = nSSB1;
	m_nSBSlaveCH2 = nSSB2 ;
}

void CDevMCCDaq::SetTemperLimit(double dDiff, double dMin, double dMax, double dDelta)
{
	m_dTemperDiff = dDiff;
	m_dTemperMinLimit = dMin;
	m_dTemperMaxLimit = dMax;
	m_dTemperDeltaTLimit = dDelta;
}

BOOL CDevMCCDaq::PortOpened()
{
	return m_bPortOpen;
}

BOOL CDevMCCDaq::Create()
{
	/* Declare UL Revision Level */
	int BoardNum = 0;
	int nUsesEXPs = 0;
	float    RevLevel = (float)CURRENTREVNUM;
    int ULStat = cbDeclareRevision(&RevLevel);

    /* Initiate error handling
       Parameters:
            PRINTALL :all warnings and errors encountered will be printed
            DONTSTOP :program will continue even if error occurs.
                     Note that STOPALL and STOPFATAL are only effective in 
                     Windows applications, not Console applications. 
   */
    cbErrHandling (PRINTALL, DONTSTOP);

	/* 
	   Determine if board uses expansiong boards for temperature measurements
	   Some boards, such as the CIO-DAS-TC, cannot use EXP expansion boards
	*/
/*	InfoType = BOARDINFO;
	DevNum = 0;
	ConfigItem = BIUSESEXPS;
	ULStat = cbGetConfig(InfoType, BoardNum, DevNum, ConfigItem, &nUsesEXPs);
	if (ULStat) nUsesEXPs = 0;
*/
	if(ULStat)
		return FALSE;
	else 
	{
		m_bPortOpen = TRUE;
		return TRUE;
	}
}

void CDevMCCDaq::Destroy()
{
}

void CDevMCCDaq::ReadTemperature()
{
 	if (!PortOpened())
		return;

	float dTemper[10];

	EnterCriticalSection(&m_csCommunicationSync);

	// Get Data
	int ULStat = cbTInScan (0, 0, 3, CELSIUS, &dTemper[0], 0); //BoardNum, LowChan, HighChan, Scale, &DataBuffer[0], Options);

	if (ULStat == 0)
	{
		// ���� ä�� ��
		if(m_nTCMasterCH1 != -1 && m_nTCMasterCH2 != -1) // �Ѵ� ���Ǵ� ä���̶��
		{
			if(fabs(dTemper[m_nTCMasterCH1] - dTemper[m_nTCMasterCH2]) > m_dTemperDiff)
			{
				CString strFile, str;
				strFile.Format(_T("TemperBad"));
				str.Format(_T("Diff error %d\t%.1f\t%.1f"), m_nTCMasterCH1, dTemper[m_nTCMasterCH1], dTemper[m_nTCMasterCH2]);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
				dTemper[m_nTCMasterCH1] = dTemper[m_nTCMasterCH2] = -999;
			}
		}
		if(m_nTCSlaveCH1 != -1 && m_nTCSlaveCH2 != -1) // �Ѵ� ���Ǵ� ä���̶��
		{
			if(fabs(dTemper[m_nTCSlaveCH1] - dTemper[m_nTCSlaveCH2]) > m_dTemperDiff)
			{
				CString strFile, str;
				strFile.Format(_T("TemperBad"));
				str.Format(_T("Diff error %d\t%.1f\t%.1f"), m_nTCSlaveCH1, dTemper[m_nTCSlaveCH1], dTemper[m_nTCSlaveCH2]);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
				dTemper[m_nTCSlaveCH1] = dTemper[m_nTCSlaveCH2] = -999;
			}
		}
		if(m_nSBMasterCH1 != -1 && m_nSBMasterCH2 != -1) // �Ѵ� ���Ǵ� ä���̶��
		{
			if(fabs(dTemper[m_nSBMasterCH1] - dTemper[m_nSBMasterCH2]) > m_dTemperDiff)
			{
				CString strFile, str;
				strFile.Format(_T("TemperBad"));
				str.Format(_T("Diff error %d\t%.1f\t%.1f"), m_nSBMasterCH1, dTemper[m_nSBMasterCH1], dTemper[m_nSBMasterCH2]);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
				dTemper[m_nSBMasterCH1] = dTemper[m_nSBMasterCH2] = -999;
			}
		}
		if(m_nSBSlaveCH1 != -1 && m_nSBSlaveCH2 != -1) // �Ѵ� ���Ǵ� ä���̶��
		{
			if(fabs(dTemper[m_nSBSlaveCH1] - dTemper[m_nSBSlaveCH2]) > m_dTemperDiff)
			{
				CString strFile, str;
				strFile.Format(_T("TemperBad"));
				str.Format(_T("Diff error %d\t%.1f\t%.1f"), m_nSBSlaveCH1, dTemper[m_nSBSlaveCH1], dTemper[m_nSBSlaveCH2]);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
				dTemper[m_nSBSlaveCH1] = dTemper[m_nSBSlaveCH2] = -999;
			}
		}
				
		for(int i = 0; i < 10; i++)
		{
			if(m_nTCMasterCH1 != i && m_nTCMasterCH2 != i && 
				m_nTCSlaveCH1 != i && m_nTCSlaveCH2 != i && 
				m_nSBMasterCH1 != i && m_nSBMasterCH2 != i && 
				m_nSBSlaveCH1 != i && m_nSBSlaveCH2 != i)
			{
				m_dTemperature[i] = 0;
				continue;
			}
			// ������ ó�� ��ƾ
			if(dTemper[i] < m_dTemperMinLimit || dTemper[i] > m_dTemperMaxLimit) // min max ����ó��
			{
				CString strFile, str;
				strFile.Format(_T("TemperBad"));
				str.Format(_T("%d\t%.1f"), i, dTemper[i]);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
				continue;
			}

			// ������ ó�� ��ƾ
			if(m_dOldTemperature[3][i] == -999) // �ι� ���� ���� ���̸�
			{
			}
			else
			{
				if(fabs(m_dOldTemperature[3][i] - dTemper[i]) > m_dTemperDeltaTLimit)
				{
					if(fabs(m_dOldTemperature[4][i] - dTemper[i]) <= 0.05) // �ι� ���� Ƣ�� ���� ������ ����
					{
					}
					else
					{
						CString strFile, str;
						strFile.Format(_T("TemperBad"));
						str.Format(_T("%d\tOld1\t%.1f\tOld2\t%.1f\tOld3\t%.1f\tOld4\t%.1f\tOld5\t%.1f\tCurr\t%.1f"), i, m_dOldTemperature[0][i], m_dOldTemperature[1][i], m_dOldTemperature[2][i], m_dOldTemperature[3][i], m_dOldTemperature[4][i], dTemper[i]);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
						continue;
					}
				}
				else
				{
				}
			}
			for(int kk = 0; kk < 4; kk++)
				m_dOldTemperature[kk][i] = m_dOldTemperature[kk + 1][i];
			m_dOldTemperature[4][i] = dTemper[i];
			time(&m_TemperatureSaveTime[i]);
			m_dTemperature[i] = dTemper[i];
		}
		// ������ ó�� ��ƾ end
	}
	else
	{
    	LeaveCriticalSection(&m_csCommunicationSync);
		return;
	}

	LeaveCriticalSection(&m_csCommunicationSync);

}

double CDevMCCDaq::GetTemperature(int nMainIndex)
{
	if(nMainIndex < 0 || nMainIndex >= 10)
		return -999;

	time_t currtime;
	time(&currtime);
	double dTime = difftime(currtime, m_TemperatureSaveTime[nMainIndex]);
	if(dTime > 10) // 10sec ���� �����ʹ� ������� �ν��Ѵ�.
		return -999;
	
	return m_dTemperature[nMainIndex];
}

BOOL CDevMCCDaq::GetTemperature(double* pdTempVal)
{
	time_t currtime;
	time(&currtime);

	memcpy(pdTempVal, m_dTemperature, sizeof(m_dTemperature));
	return TRUE;
}

void CDevMCCDaq::ReadAddress()
{

}


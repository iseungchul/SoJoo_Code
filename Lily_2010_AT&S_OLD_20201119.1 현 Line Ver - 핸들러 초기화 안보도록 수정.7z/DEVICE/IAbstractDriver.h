// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_IABSTRACTDRIVER_3E8D36BB00CB_INCLUDED
#define _INC_IABSTRACTDRIVER_3E8D36BB00CB_INCLUDED

//##ModelId=4034007F0062
class IAbstractDriver 
{
public:
	//##ModelId=4034007F006D
	virtual bool writeIFCard(const ULONG port, const ULONG data, const char type = _T('b'));

	//##ModelId=4034007F007D
	virtual bool readIFCard(ULONG port, ULONG& data, const char type = _T('b'));

	//##ModelId=4034007F0082
	IAbstractDriver();

	//##ModelId=4034007F0083
	virtual ~IAbstractDriver();

};

#endif /* _INC_IABSTRACTDRIVER_3E8D36BB00CB_INCLUDED */

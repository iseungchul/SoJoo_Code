#ifndef __INC_ATTENUATOR_MODULE_INTERFACE_HDR__
#define __INC_ATTENUATOR_MODULE_INTERFACE_HDR__

#define DLLAPI	extern "C" __declspec( dllexport )

namespace EOATTENUATOR
{
	// Initialize EO Attenuator
	DLLAPI BOOL InitializeEOAttenuator();

	// Destroy EO Attenuator
	DLLAPI void	DestroyEOAttenuator();

	// Change EO Attenuator Serial Port
	DLLAPI BOOL ChangeEOAttenuatorPort();

	// Set background thread query  hold
	// TRUE : Background thread hold
	// FALSE : Background thread running
	// When machine start auto run, background thread hold.
	// When machine stop auto run, background thread running.
	DLLAPI void SetBackgroundQueryHold(BOOL bHold);

	// Get Current Attenuator Status
	// return Value
	// -1 : Timeout, 0 : Moving, 1 : Out of position, 2 : Over speed / dynamic braking
	// 3 : Overload, 8 : Done, 16 : Motor free, 31 : Under dynamic braking,
	// 40 : Dynamic braking done, 128 : Abnormal temperature, 255 : Emergency stop
	DLLAPI int GetCurrentEOAttenuatorStatus();

	// Get Current Attenuator Position
	DLLAPI int GetCurrentEOAttenuatorPosition();

	// Homing Attenuator
	DLLAPI BOOL OnEOAttenuatorHoming();

	// Set EO Attenuator Position, Speed, Acceleration Data
	// Position Array Max Size : 1(Min) ~ 7(Max)
	DLLAPI BOOL SetEOAttenuatorBankData(int* pnPosData, int nSize, int s1, int a1);

	// Move EO Attenuator(Using Bank Program)
	// nWorkType
	// 0 : Send, Receive together, 1 : Only Send, 2 : Only Receive
	DLLAPI BOOL OnEOAttenuatorBankRun(int nBankID, int nWorkType, char* psResponse=NULL);

	// Get Current Motor Status Direct(No use background query data)
	DLLAPI BOOL OnEOAttenuatorMotorStatusDirect(int* pnStatus);

	// Move EO Attenuator(Using jog(direct) command.)
	// This function is not check inposition.
	DLLAPI BOOL SetEOAttenuatorManualMove(int s0, int a0, int p0);

	// Stop Motor
	DLLAPI BOOL SetEOAttenuatorMoveStop();

	// This function only use test.
	// hTarget : Response data feedback.
	// pszCmd : Max size 256 bytes
	DLLAPI BOOL	OnEOAttenuatorUserCmdQuery(char* pszCmd, HWND hTarget);
}

using namespace EOATTENUATOR;

#endif // __INC_ATTENUATOR_MODULE_INTERFACE_HDR__
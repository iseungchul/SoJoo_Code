// ScannerCalibration.cpp: implementation of the CScannerCalibration class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ScannerCalibration.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CScannerCalibration::CScannerCalibration()
{
	Clear();
}

CScannerCalibration::~CScannerCalibration()
{
	if(m_Offset)
	{
		delete [] m_Offset;
		m_Offset = NULL;
	}
}

void CScannerCalibration::Clear()
{
	m_bIsSet = FALSE;
	m_bFirst = TRUE;
	m_nGridX = 0;
	m_nGridY = 0;
	m_dGap = 0.0;
	m_dXStart = 0.0;
	m_dXEnd = 0.0;
	m_dYStart = 0.0;
	m_dYEnd = 0.0;
	
	m_Offset = NULL;
	SetMatrixToZero();
}

void CScannerCalibration::SetMatrixToZero()
{
	for (int i = 0; i < MAX_SIZE; i++)
	{
		for (int j = 0; j < MAX_SIZE; j++)
		{
			m_Matrix[i][j].x = 0.0f;
			m_Matrix[i][j].y = 0.0f;
		}
	}
}

void CScannerCalibration::UpdateCalibration(const CALHEAD& calHead)
{
	m_nGridX = calHead.nGridX;
	m_nGridY = calHead.nGridY;
	m_dGap = calHead.dGap;
	m_dXStart = calHead.dXStart;
	m_dXEnd = m_dXStart + m_dGap * (m_nGridX - 1);
	m_dYStart = calHead.dYStart;
	m_dYEnd = m_dYStart + m_dGap * (m_nGridY - 1);

	TRY
	{
		delete [] m_Offset;
		m_Offset = NULL;
		m_Offset = new DPOINT[m_nGridX * m_nGridY];
		memcpy(m_Offset, calHead.dOffset, sizeof(DPOINT) * m_nGridX * m_nGridY);
		m_bIsSet = TRUE;
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		Clear();
		return;
	}
	END_CATCH

	UpdateWholeCalibration();
}

BOOL CScannerCalibration::IsInside(double dX, double dY)
{
	if (dX >= MIN_FIELD && dX <= MAX_FIELD && dY >= MIN_FIELD && dY <= MAX_FIELD)
		return TRUE;
	else
		return FALSE;
}

void CScannerCalibration::GetCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset)
{
	if (IsInside(dX, dY))
	{
		// index = m_nGridY * nX + nY
		int nX = static_cast<int>(dX);
		int nY = static_cast<int>(dY);
		
		dXOffset = m_Matrix[nX][nY].x;
		dYOffset = m_Matrix[nX][nY].y;
	}
	else
	{
		dXOffset = dYOffset = 0.0;
	}
}

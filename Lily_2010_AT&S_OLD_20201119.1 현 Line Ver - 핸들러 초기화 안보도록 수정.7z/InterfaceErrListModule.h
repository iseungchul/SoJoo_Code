
#define DLLAPI	extern "C" __declspec( dllexport )

namespace ERRLIST
{
	DLLAPI	BOOL InitErrListDll();
	DLLAPI	void ShowErrListDlg();
	DLLAPI	BOOL GetErrMsg(int nID, char* pErrCode, char* pErrReason, char* pErrSolution);
}

using namespace ERRLIST;
#include "stdafx.h"
#include "memorystream.h"





HRESULT StreamResetPointer (LPSTREAM lpStream)
{
  LARGE_INTEGER liBeggining = { 0 };
  HRESULT hrRet = S_OK;

  hrRet = lpStream -> Seek(liBeggining, STREAM_SEEK_SET, NULL);

  return hrRet;
}





HRESULT StreamStringCopy (LPSTREAM lpStream, LPCTSTR lpString)
{
  ULONG ulBytesWritten = 0;
  ULONG ulSize = 0;
  ULARGE_INTEGER uliSize = { 0 };
  HRESULT hrRetTemp = S_OK;
  HRESULT hrRet = S_OK;

  hrRetTemp = StreamResetPointer ((LPSTREAM)lpStream);
  if (hrRetTemp != S_OK)
  {
    hrRet = hrRetTemp;
	goto StreamStringCopy_0;
  }

  hrRetTemp = lpStream -> SetSize (uliSize);
  if (hrRetTemp != S_OK)
  {
    hrRetTemp = hrRet;
	goto StreamStringCopy_0;
  }

  ulSize = (ULONG)strlen(lpString);
  
  hrRetTemp = lpStream -> Write((void const*)lpString, (ULONG)ulSize, (ULONG*)&ulBytesWritten);
  if (hrRetTemp != S_OK)
  {
    hrRet = hrRetTemp;
	goto StreamStringCopy_0;
  }

  if (ulSize == ulBytesWritten)
  {
    hrRet = S_OK;
  }
  else
  {
    hrRet = S_FALSE;
  }

StreamStringCopy_0:

  return hrRet;
}





HRESULT StreamStringCat (LPSTREAM lpStream, LPCTSTR lpString)
{
  ULONG ulBytesWritten = 0;
  ULONG ulSize = 0;
  HRESULT hrRetTemp = S_OK;
  HRESULT hrRet = S_OK;

  ulSize = strlen(lpString);
  
  hrRetTemp = lpStream -> Write((void const*)lpString, (ULONG)ulSize, (ULONG*)&ulBytesWritten);
  if (hrRetTemp != S_OK)
  {
    hrRet = hrRetTemp;
	goto StreamStringCat_0;
  }

  if (ulSize == ulBytesWritten)
  {
    hrRet = S_OK;
  }
  else
  {
    hrRet = S_FALSE;
  }

StreamStringCat_0:

  return hrRet;
}





HRESULT StreamStringRead (LPSTREAM lpStream, LPTSTR lpszReceiver, ULONG* lpulSizeReceiver)
{
  STATSTG statstg;
  HRESULT hrRetTemp = S_OK;
  HRESULT hrRet = S_OK;

  hrRetTemp = StreamResetPointer ((LPSTREAM)lpStream);
  if (hrRetTemp != S_OK)
  {
    hrRet = hrRetTemp;
    goto StreamStringRead_0;
  }

  memset (&statstg, 0, sizeof(statstg));
  hrRetTemp = lpStream -> Stat(&statstg, STATFLAG_NONAME);
  if (hrRetTemp != S_OK)
  {
    hrRet = hrRetTemp;
	goto StreamStringRead_0;
  }

  if ((ULONG*)lpulSizeReceiver)
  {
    *((ULONG*)lpulSizeReceiver) = statstg.cbSize.LowPart;
  }

  if ((void*)lpszReceiver)
  {
    memset ((void*)lpszReceiver, 0, statstg.cbSize.LowPart + sizeof(char));
    lpStream -> Read((void*)lpszReceiver, statstg.cbSize.LowPart, NULL);
  }

StreamStringRead_0:

  return hrRet;
}




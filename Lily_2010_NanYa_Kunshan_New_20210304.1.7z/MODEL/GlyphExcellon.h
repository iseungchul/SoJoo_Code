// GlyphExcellon.h: interface for the GlyphExcellon class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GLYPHEXCELLON_H__CA36A82B_FC34_4379_A20A_84801935FA09__INCLUDED_)
#define AFX_GLYPHEXCELLON_H__CA36A82B_FC34_4379_A20A_84801935FA09__INCLUDED_

#include "DFidData.h"	// Added by ClassView
#include "DPoint.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_FID_KIND_NO		2  //���� ���� - �Ǵ� ��� �Ϻ�
#define MAX_FID_NO			20
#define MAX_FID_BLOCK		50 

#define FID_FILE_USE		1
#define FID_FILE_NOT_USE	2
#define FID_DATA_GET		3

#define SCREEN_X 1280
#define SCREEN_Y 1024

#include "Glyph.h"
#include <afxtempl.h>
#include "DFidData.h"
#include "DUnit.h"
#include "..\device\HVisionOmi.h"

#define MOVE_LEFT		0
#define MOVE_RIGHT		1
#define MOVE_UP			2
#define MOVE_DOWN		3

typedef	DUnit*	LPDUNIT;
typedef CTypedPtrList <CPtrList, LPDUNIT>	UnitList;

struct MemoryInfo {
	int			nOrigin;
	LPLINEDATA	pData;
};
struct FID_SORT_DATA {
	LPFIDDATA	pFidData;
	BOOL		bUsed;
	int			nSortIndex;
	int			nOriginIndex;
};

class GlyphExcellon : public Glyph  
{
public:
	int GetSameBlockIndex(DBlock* pBlock, double& dDistX, double& dDistY);
	BOOL MakeUnitsForContinuousLine(DUnit* pUnit);

	LPFIDDATA GetUsedFiducialData(int nFidKind, int nIndex, int nAddProp, int nDelProp, int nFidBlock);
	int GetUseFidCount(int nFidKind, int nAddProp, int nDelProp, int nFidBlock);
	BOOL GetUseFidSelect(int nFidKind, int nIndex);
	void UnSelectAllFid();
	BOOL SetUseFidSelect(int nFidKind, int nIndex, BOOL bSelect);
	BOOL GetRefFidPos(int& nX, int& nY); //20091029
	BOOL IsValidTool(DUnit* pUnit);
	DUnit* GetUnit(int nIndex);
	BOOL TransformAllFidCal(int nFidKind, BOOL b1st, BOOL b2nd, int nFindMethod);
	void ChangeOneFindFid(int nFidIndex, int nVal);
	void ChangeAllFindFid(int nVal);
	void ChangeFindFidList(int* nVal);
	void ResetFindFidList();
	BOOL IsValidFiducial();
	BOOL RemoveSelectUnitAllSubFiducial();
	BOOL IsSelectedFid(int nIndex);
	BOOL AddSubFiducial(int nIndex);
	int IsThereFid(CPoint& pt, int nTol);
	void ReCalRect(BOOL bFidContain);
	BOOL DisunifyUnit(CPoint pt1, CPoint pt2);
	void MergeUnit();
	BOOL IsMultiSelected();
	BOOL GetUnitPos(CPoint& ptPoint);
	void AddMoveUnitsToUndoList();
	void MoveFiducial(CPoint ptPoint, CPoint ptMove, int nTolerence);
	void RemoveAllSubFiducial(int nIndex);
	void ArrayCopy(int nCopyType, int nShape, int nR, int &nCOffsetX, int &nCOffsetY, int nX, int nY);
	BOOL DeleteSelectUnit();
	void UnSelectAllUnit();
	BOOL IsPickUnit(CPoint ptPoint, int nTol);
	BOOL MoveUnit(int nX, int nY);
	BOOL MoveUnit(int nDirection);
	void DrawUnit(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList** pToolCodes, int nMode);
	BOOL SaveFileUnit10000(CArchiveMark &ar, int nVersion);
	BOOL LoadFileUnit10000(CArchiveMark &ar, int nVersion);
	void RemoveAllUnit();
	int GetTotalHoleCount();
	BOOL IsLineData(int nTool);
	BOOL IsDotData(int nTool);
	void ReMoveAllLineData();
	void RemoveAllHoleData();
	BOOL AddLineData(LINEDATA* pLine, int nUnitNo);
	HOLEDATA* AddHoleData(HOLEDATA dataHole, int nUnitNo);
	UnitList m_Units;
	//  pattern blocks
	void SetBlockInfoToToolInfo(CToolCodeList** pToolCodes);
	void GetProjectMinMaxValue(double &MinX, double &MaxX, double &MinY, double &MaxY);
	BOOL IsDrawData(int nMode, int nX, int nY, int nStartX, int nStartY, int nEndX, int nEndY, int nBlockName);
	BOOL IsDrawData(int nMode, CPoint ptStart, CPoint ptEnd, int nStartX, int nStartY, int nEndX, int nEndY, int nBlockName);

	void SortOriginBlockHole();
	void BlockFirstPositionToZero();

	void DisplayBlockDots(CDC* pDC, int x, int y, int nBlockName, COLORREF pColor, int nMode, double dStartX, double dStartY, double dEndX, double dEndY, double dScale, int nSkipNo);

	LPDBLOCK GetBlock(int nBlockName);
	
	int GetHoleDataBlockCount(int nBlockName);
	void RemoveAllBlock();
	BlockList m_Blocks;
	//-------------------
	DFidData m_FiducialData[MAX_FID_KIND_NO];
	DFidData m_CopyFidData;
	FID_DATA m_HoleFindData;
	CDPoint GetUseFidPoint(int nFidKind, int nIndex);
	void ResetFidOffset();
	BOOL SaveFileFid10000(CArchiveMark &ar, int nVersion);
	BOOL LoadFileFid10000(CArchiveMark &ar, int nVersion, SVISIONINFO pVisionInfo[] = NULL);
	void GetXY(int nMode, int nX, int nY, int &nTransX, int &nTransY);
	void ChangeDataWithAxis(int nMode);
	virtual BOOL OnSetRefFid(CPoint pt, int nTolerence);
	BOOL SetRefFidLeftBottom(int nAxisMode);
 	void SkvingSkip();
   	void ApplyManualScale(CDPoint dScale);
	BOOL IsDrawData(int nMode, int nX, int nY, int nStartX, int nStartY, int nEndX, int nEndY);
	void GetXY(int nMode, int nX, int nY, int &nTransX, int &nTransY, double dStartX, double dStartY, double dScale);
	void operator=( GlyphExcellon& myDProject );
	BOOL SaveFile10000(CArchiveMark &ar, int nVersion);
	BOOL LoadFile10000(CArchiveMark &ar, int nVersion);
	CArray <MemoryInfo, MemoryInfo>  m_FileMemoryInfo;
	int GetUseFidRealIndex(int nFidKind, int nIndex);
	BOOL SetFidIntOffset(int nFidKind, int nIndex, BOOL b1stPanel, double dx, double dy);
	CDPoint GetUseFidIntOffset(int nFidKind, int nIndex, BOOL b1stPanel);
	CDPoint GetFidIntOffset(int nFidKind, int nIndex, BOOL b1stPanel);
	BOOL SetUseFidOffset(int nFidKind, int nIndex, BOOL b1stPanel, double dx, double dy);
	CDPoint GetUseFidOffset(int nFidKind, int nIndex, BOOL b1stPanel);
	void GetRefPosition(double& dx, double& dy);
	BOOL GetIsDelPoint (int nFidKind, int nIndex);
	BOOL SortFiducial(int nFidKind);
	BOOL SortFiducial4UnderPrimary(int nFidKind, int nCountPrimary, int nCountSecondary);
	BOOL SortFiducial4UnderSecondary(int nFidKind, int nCountPrimary, int nCountSecondary);
	BOOL SortFiducialPrimary(int nFidKind, int nCountPrimary, int nCountSecondary);
	BOOL SortFiducialSecondary(int nFidKind, int nCountPrimary, int nCountSecondary);
	void DrawFiducialOnly(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList** pToolCodes, int nMode, BOOL bDrawSortIndex, BOOL bSelectMode, int nStartFidBlock, int m_nMaxFidBlock, double dScaleMin, double dScaleMax, BOOL bResult = FALSE, int nPanelNo = -1);
	CPoint GetFidPoint(int nFidKind, int nIndex);
	int GetFidCount(int nFidKind);
	CPoint GetUseFidIntPoint(int nFidKind, int nIndex);
	CPoint GetFidIntPoint(int nFidKind, int nIndex);
	int	GetUseFidFindStatus(int nFidKind, int nIndex);
	int	GetFidFindStatus(int nFidKind, int nIndex);
	int GetFidBlockStatus(int nFidKind, int nIndex);
	int GetUseFidCount(int nFidKind, int nFidRank = 0);
	virtual BOOL DelFiducial(CPoint pt, int nTolerence);
	virtual BOOL AddFiducial(CPoint pt, int nTolerence, int nFidKind);
	BOOL AddRandomFiducial(CPoint pt);
	BOOL AddSubFiducial(CPoint pt);
	BOOL ChangeBlock(int nNewFidBlock);
	virtual BOOL IsFidHoleGet(BOOL &bFidList, CPoint& pt, int nTolerence, BOOL &bSkiving);
	virtual void Rotate(double dDeg);
	virtual void Flip(BOOL bX);
	virtual BOOL IsSelect(CPoint point, int nTolerence, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
	virtual BOOL IsSelect(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
	virtual int SelectData(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
	virtual void SetFiducial(int nIndex, BOOL bSubFid);
	virtual void ResetOneFiducial(int nIndex, BOOL bSubFid);
	virtual void ResetAllFiducial(BOOL bSubFid);
	void DisplayAreaDot(CDC* pDC, int x, int y, COLORREF pColor);
	void DisplayAreaEllipse(CDC* pDC, int x, int y, int nSize, COLORREF pColor);
	virtual void DrawSelectOnly(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList** pToolCodes, int nSkipNo, int nMode, BOOL bDrawSortIndex);
	virtual void Draw(CDC *pDC, CRect rc, double dScale, double dDrawStartX, double dDrawStartY, CToolCodeList** pToolCodes, int nSkipNo, int nMode, BOOL bDrawSortIndex);
	DECLARE_SERIAL( GlyphExcellon );

//	FID_DATA		m_FidData[MAX_FID_KIND_NO];
	GlyphExcellon();
	virtual ~GlyphExcellon();

	int GetFiducialIndex(CPoint pt, int nTolerance);
	void SetDisplayFidIndex(int nIndex, BOOL bClear = FALSE);

//	BOOL m_bDrawn[1][1];

	BOOL m_bShowSelectionFid;
	void UnSelectAllData();

	BOOL IsUseFidInArea(int nIndex, BOOL bSubFid); // ������ ���Ǵ� fiducial���� Ȯ��

//	BOOL m_bSelectionPlus;
	int m_nFidIndex;

	// 20130419 fiducial ������, block �� ���� �����ϱ� ����
	COLORREF m_cColorFid[MAX_FID_BLOCK];
	
	BOOL GetFidAcquireRet(int nFidKind, int nIndex, BOOL b2ndPanel, int nFidRank); // panel�� fiducial �ν� ���
	BOOL SetFidAcquireRet(int nFidKind, int nIndex, BOOL bAcquire, BOOL b2ndPanel = FALSE); // ���帶�� panel���� fiducial �ν� ��� ����
	BOOL ResetFidAcquireRet(int nFidKind, BOOL bAcquire = FALSE);
	LPFIDDATA GetFiducialData(int nFidKind, int nIndex);
	
	BOOL GetBigFidIndex(int* nIndexFid, int nFidKind, BOOL b1st, int nFidRank); // Data�� ���õ��� ����, ����ϴ� ��� ��üFiducial �������� index����
	
	BOOL GetFidIndex(int* nIndexFid, int nFidKind, BOOL b1st, int nFidRank); // Data�� ���õ��� ����, ����ϴ� ��� ��üFiducial �������� index����

	// 4 head
	void ChangeBlockWithPosition(int* nChangeBlock);
};

#endif // !defined(AFX_GLYPHEXCELLON_H__CA36A82B_FC34_4379_A20A_84801935FA09__INCLUDED_)
// DUnit.cpp: implementation of the DUnit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DUnit.h"
#include "..\EasyDriller.h"
#include "math.h"
#include "DOriginLineSort.h"
#include "dprocessini.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DUnit::DUnit()
{
	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;
	m_bSelect	= FALSE;
}

DUnit::~DUnit()
{
	RemoveAllMemory();
}

void DUnit::RemoveAllMemory()
{
	ReMoveAllHoleData();
	ReMoveAllLineData();

	int* pIndex;
	POSITION pos = m_SubFidIndexData.GetHeadPosition();
	while (pos) 
	{
		pIndex = m_SubFidIndexData.GetNext(pos);
		delete pIndex;
	}
	m_SubFidIndexData.RemoveAll();
}

BOOL DUnit::SaveFile10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			if(nVersion < 10008)
			{
				ar << _T("SubIndexNo = ") << m_SubFidIndexData.GetCount() << _T("\n");
				POSITION pos;
				int* pIndex;
				pos = m_SubFidIndexData.GetHeadPosition();
				while (pos) 
				{
					pIndex = m_SubFidIndexData.GetNext(pos);
					ar << _T("= ") << *pIndex << _T("\n");
				}
			}

			ar << _T("MinX = ") << m_nMinX << _T("\n");
			ar << _T("MinY = ") << m_nMinY << _T("\n");
			ar << _T("MaxX = ") << m_nMaxX << _T("\n");
			ar << _T("MaxY = ") << m_nMaxY << _T("\n");

			ar << _T("HoleNo = ") << m_HoleData.GetCount() << _T("\n");
			LPHOLEDATA pOriHole;
			POSITION pos;
			pos = m_HoleData.GetHeadPosition();
			while (pos) 
			{
				pOriHole = m_HoleData.GetNext(pos);
				ar << _T("= ") << pOriHole->nToolNo << _T("\n");
				ar << _T("= ") << pOriHole->npPos.x << _T("\n");
				ar << _T("= ") << pOriHole->npPos.y << _T("\n");
				ar << _T("= ") << pOriHole->nUnitIndex << _T("\n");
				ar << _T("= ") << pOriHole->nRotate << _T("\n");	
				if(nVersion > 10007)
				{
					for(int m=0; m<4; m++)
					{
						for(int n=0; n<2; n++)
						{
							ar << _T("= ") << pOriHole->nFidIndex[m][n] << _T("\n");
						}
					}
				}
			}
			
			ar << _T("LineNo = ") << m_LineData.GetCount() << _T("\n");
			LPLINEDATA pOriginLine;
			pos = m_LineData.GetHeadPosition();
			while (pos) 
			{
				pOriginLine = m_LineData.GetNext(pos);
				ar << _T("= ") << pOriginLine->nToolNo << _T("\n");
				ar << _T("= ") << pOriginLine->npStartPos.x << _T("\n");
				ar << _T("= ") << pOriginLine->npStartPos.y << _T("\n");
				ar << _T("= ") << pOriginLine->npEndPos.x << _T("\n");
				ar << _T("= ") << pOriginLine->npEndPos.y << _T("\n");
				ar << _T("= ") << pOriginLine->nUnitIndex << _T("\n");

				if(nVersion > 10007)
				{
					for(int m=0; m<4; m++)
					{
						for(int n=0; n<2; n++)
						{
							ar << _T("= ") << pOriginLine->nFidIndex[m][n] << _T("\n");
						}
					}
				}
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL DUnit::LoadFile10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	int nCount;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code

			if(nVersion < 10002)
			{

			}
			else
			{
				if(nVersion < 10008)
				{
					ar >> nCount;
					int* pIndex;
					for(int i = 0; i < nCount; i++)
					{
						pIndex = new int;
						ar >> *pIndex;
						m_SubFidIndexData.AddTail(pIndex);
					}
				}

				ar >> m_nMinX; 
				ar >> m_nMinY;
				ar >> m_nMaxX;
				ar >> m_nMaxY;
			}

			ar >> nCount;
			HOLEDATA OriHole;
			for(int i = 0; i < nCount; i++)
			{
				ar >> OriHole.nToolNo;
				ar >> OriHole.npPos.x;
				ar >> OriHole.npPos.y;
				ar >> OriHole.nUnitIndex;
				if(nVersion >= 10015)
					ar >> OriHole.nRotate;
				else
					OriHole.nRotate = 0;




				if(nVersion > 10007)
				{
					for(int m=0; m<4; m++)
					{
						for(int n=0; n<2; n++)
						{
							ar >> OriHole.nFidIndex[m][n];
						}
					}
				}
				m_HoleData.AddTail(OriHole);
			}
			
			LPLINEDATA pOriLine; 
			ar >> nCount;
			for(int i = 0; i < nCount; i++)
			{
				pOriLine = new LINEDATA;
				ar >> pOriLine->nToolNo;
				ar >> pOriLine->npStartPos.x;
				ar >> pOriLine->npStartPos.y;
				ar >> pOriLine->npEndPos.x;
				ar >> pOriLine->npEndPos.y;
				ar >> pOriLine->nUnitIndex;		
//				pOriLine->bSelect = FALSE;
				pOriLine->nRefNo = 1;

				if(nVersion > 10007)
				{
					for(int m=0; m<4; m++)
					{
						for(int n=0; n<2; n++)
						{
							ar >> pOriLine->nFidIndex[m][n];
						}
					}
				}
				m_LineData.AddTail(pOriLine);
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL DUnit::SaveFileRect10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			
			if(nVersion < 10008)
			{
				ar << _T("SubIndexNo = ") << m_SubFidIndexData.GetCount() << _T("\n");
				POSITION pos;
				int* pIndex;
				pos = m_SubFidIndexData.GetHeadPosition();
				while (pos) 
				{
					pIndex = m_SubFidIndexData.GetNext(pos);
					ar << _T("= ") << *pIndex << _T("\n");
				}
			}

			ar << _T("MinX = ") << m_nMinX << _T("\n");
			ar << _T("MinY = ") << m_nMinY << _T("\n");
			ar << _T("MaxX = ") << m_nMaxX << _T("\n");
			ar << _T("MaxY = ") << m_nMaxY << _T("\n");
			// ver 10002 end
			
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL DUnit::LoadFileRect10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	int nCount;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code
			
			if(nVersion < 10002)
			{

			}
			else
			{
				if(nVersion < 10008)
				{
					ar >> nCount;
					int* pIndex;
					for(int i = 0; i < nCount; i++)
					{
						pIndex = new int;
						ar >> *pIndex;
						m_SubFidIndexData.AddTail(pIndex);
					}
				}

				ar >> m_nMinX; 
				ar >> m_nMinY;
				ar >> m_nMaxX;
				ar >> m_nMaxY;
			}

		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL DUnit::IsSelect(CPoint point, int nTolerence, CToolCodeList **pToolCodes, BOOL bSelectOnlyView)
{
	if(m_nMaxX < point.x) return FALSE;
	if(m_nMinX > point.x) return FALSE;
	if(m_nMaxY < point.y) return FALSE;
	if(m_nMinY > point.y) return FALSE;
	
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(!(*(pToolCodes + pHole->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pHole->bSelect)
			continue;
		
		if (point.x < pHole->npPos.x - nTolerence ||
			point.x > pHole->npPos.x + nTolerence ||
			point.y < pHole->npPos.y - nTolerence ||
			point.y > pHole->npPos.y + nTolerence)
			continue;
		else
		{
			return TRUE;
		}
	}
	
	int a, b, c;
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(!(*(pToolCodes + pLine->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pLine->bSelect)
			continue;
		
		if (point.x < min(pLine->npStartPos.x, pLine->npEndPos.x) - nTolerence ||
			point.x > max(pLine->npStartPos.x, pLine->npEndPos.x) + nTolerence ||
			point.y < min(pLine->npStartPos.y, pLine->npEndPos.y) - nTolerence ||
			point.y > max(pLine->npStartPos.y, pLine->npEndPos.y) + nTolerence)
			continue;
		
		a = pLine->npStartPos.y - pLine->npEndPos.y;
		b = pLine->npEndPos.x - pLine->npStartPos.x;
		c = pLine->npStartPos.x*pLine->npEndPos.y - pLine->npStartPos.y*pLine->npEndPos.x;
		
		if(pow((double)nTolerence, 2)*(pow((double)a, 2) + pow((double)b, 2)) >= pow((double)a*point.x + b*point.y + c, 2))
		{
			return TRUE;
		}
	}
	return FALSE;
}

BOOL DUnit::IsSelect(CPoint point1, CPoint point2, CToolCodeList **pToolCodes, BOOL bSelectOnlyView)
{
	if(m_nMaxX < point1.x) return FALSE;
	if(m_nMaxY < point1.y) return FALSE;
	
	if(m_nMinX > point2.x) return FALSE;
	if(m_nMinY > point2.y) return FALSE;

	BOOL bIn = FALSE;
	
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(!(*(pToolCodes + pHole->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pHole->bSelect)
			continue;

		bIn = TRUE;
		
		if (point1.x > pHole->npPos.x || pHole->npPos.x > point2.x ||
			point1.y > pHole->npPos.y || pHole->npPos.y > point2.y)
		{
			return FALSE;
		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(!(*(pToolCodes + pLine->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pLine->bSelect)
			continue;

		bIn = TRUE;
		
		if (point1.x > pLine->npStartPos.x || pLine->npStartPos.x > point2.x ||
			point1.y > pLine->npStartPos.y || pLine->npStartPos.y > point2.y ||
			point1.x > pLine->npEndPos.x || pLine->npEndPos.x > point2.x ||
			point1.y > pLine->npEndPos.y || pLine->npEndPos.y > point2.y)
		{
			return FALSE;
		}
	}
	if(bIn)
		return TRUE;
	else
		return FALSE;
}

void DUnit::UnSelectData()
{
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		pHole->bSelect = FALSE;
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		pLine->bSelect = FALSE;
	}
}

BOOL DUnit::IsAnySelectedData(CToolCodeList **pToolCodes, BOOL bSelectOnlyView)
{
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(!(*(pToolCodes + pHole->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pHole->bSelect)
			continue;
		
		if(pHole->bSelect)// && !bSelectionPlus) // bSelectionPlus�� ������� ������Ų�� (���� �ʿ��ϸ� �ּ� Ǯ��)
			return TRUE;
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(!(*(pToolCodes + pLine->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pLine->bSelect)
			continue;
		
		if(pLine->bSelect)// && !bSelectionPlus)
			return TRUE;
	}

	return FALSE;
}

BOOL DUnit::SelectData(CPoint point1, CPoint point2, CToolCodeList **pToolCodes, BOOL bSelectOnlyView)//, BOOL bSelectionPlus)
{
	if(m_nMaxX < point1.x) return FALSE;
	if(m_nMaxY < point1.y) return FALSE;
	
	if(m_nMinX > point2.x) return FALSE;
	if(m_nMinY > point2.y) return FALSE;
	
	BOOL bIn = FALSE;
	
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(!(*(pToolCodes + pHole->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pHole->bSelect)
			continue;
		
		bIn = TRUE;

		if(point1.x <= pHole->npPos.x && pHole->npPos.x <= point2.x &&
			point1.y <= pHole->npPos.y && pHole->npPos.y <= point2.y)
		{
			if(pHole->bSelect)// && !bSelectionPlus) // bSelectionPlus�� ������� ������Ų�� (���� �ʿ��ϸ� �ּ� Ǯ��)
				pHole->bSelect = FALSE;
			else
				pHole->bSelect = TRUE;
		}
//		else
//		{
//			if(!bSelectionPlus)
//				pHole->bSelect = FALSE;
//		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(!(*(pToolCodes + pLine->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pLine->bSelect)
			continue;
		
		bIn = TRUE;

		if(point1.x <= pLine->npStartPos.x && pLine->npStartPos.x <= point2.x &&
			point1.x <= pLine->npEndPos.x && pLine->npEndPos.x <= point2.x &&
			point1.y <= pLine->npStartPos.y && pLine->npStartPos.x <= point2.y &&
			point1.y <= pLine->npEndPos.y && pLine->npEndPos.x <= point2.y)
		{
			if(pLine->bSelect)// && !bSelectionPlus)
				pLine->bSelect = FALSE;
			else
				pLine->bSelect = TRUE;
		}
//		else
//		{
//			if(!bSelectionPlus)
//				pLine->bSelect = FALSE;
//		}
	}
	if(bIn)
		return TRUE;
	else
		return FALSE;
}

void DUnit::Flip(BOOL bX, int nMinX, int nMaxX, int nMinY, int nMaxY)
{
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	if(bX)
	{
		while (pos) 
		{
			pHole = m_HoleData.GetNext(pos);
			pHole->npPos.x = nMaxX + nMinX - pHole->npPos.x;
		}
	}
	else
	{
		while (pos) 
		{
			pHole = m_HoleData.GetNext(pos);
			pHole->npPos.y = nMaxY + nMinY - pHole->npPos.y;
		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	if(bX)
	{
		while (pos) 
		{
			pLine = m_LineData.GetNext(pos);
			pLine->npStartPos.x = nMaxX + nMinX - pLine->npStartPos.x;
			pLine->npEndPos.x = nMaxX + nMinX - pLine->npEndPos.x;
		}
	}
	else
	{
		while (pos) 
		{
			pLine = m_LineData.GetNext(pos);
			pLine->npStartPos.y = nMaxY + nMinY - pLine->npStartPos.y;
			pLine->npEndPos.y = nMaxY + nMinY - pLine->npEndPos.y;
		}
	}
}

void DUnit::Rotate(double dDeg, int& nMinX, int& nMaxX, int& nMinY, int& nMaxY)
{
	CPoint nCenterP;
	int nX;
	double cosTheta, sinTheta;
	
	nCenterP.x = (nMaxX + nMinX) / 2;
	nCenterP.y = (nMaxY + nMinY) / 2;
	
	nMinX		= INT_MAX;
	nMinY		= INT_MAX;
	nMaxX		= INT_MIN;
	nMaxY		= INT_MIN;
	
	dDeg = dDeg * M_PI / 180; // deg to rad
	cosTheta = cos(dDeg);
	sinTheta = sin(dDeg);
	
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		nX = (int)(cosTheta*(pHole->npPos.x - nCenterP.x) - sinTheta*(pHole->npPos.y - nCenterP.y) + nCenterP.x);
		pHole->npPos.y = (int)(sinTheta*(pHole->npPos.x - nCenterP.x) + cosTheta*(pHole->npPos.y - nCenterP.y) + nCenterP.y);
		pHole->npPos.x = nX;
		
		if(nMaxX < pHole->npPos.x) nMaxX = pHole->npPos.x;
		if(nMinX > pHole->npPos.x) nMinX = pHole->npPos.x;
		if(nMaxY < pHole->npPos.y) nMaxY = pHole->npPos.y;
		if(nMinY > pHole->npPos.y) nMinY = pHole->npPos.y;
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		nX = (int)(cosTheta*(pLine->npStartPos.x - nCenterP.x) - sinTheta*(pLine->npStartPos.y - nCenterP.y) + nCenterP.x);
		pLine->npStartPos.y = (int)(sinTheta*(pLine->npStartPos.x - nCenterP.x) + cosTheta*(pLine->npStartPos.y - nCenterP.y) + nCenterP.y);
		pLine->npStartPos.x = nX;
		
		nX = (int)(cosTheta*(pLine->npEndPos.x - nCenterP.x) - sinTheta*(pLine->npEndPos.y - nCenterP.y) + nCenterP.x);
		pLine->npEndPos.y = (int)(sinTheta*(pLine->npEndPos.x - nCenterP.x) + cosTheta*(pLine->npEndPos.y - nCenterP.y) + nCenterP.y);
		pLine->npEndPos.x = nX;
		
		if(nMaxX < pLine->npStartPos.x) nMaxX = pLine->npStartPos.x;
		if(nMinX > pLine->npStartPos.x) nMinX = pLine->npStartPos.x;
		if(nMaxY < pLine->npStartPos.y) nMaxY = pLine->npStartPos.y;
		if(nMinY > pLine->npStartPos.y) nMinY = pLine->npStartPos.y;
		
		if(nMaxX < pLine->npEndPos.x) nMaxX = pLine->npEndPos.x;
		if(nMinX > pLine->npEndPos.x) nMinX = pLine->npEndPos.x;
		if(nMaxY < pLine->npEndPos.y) nMaxY = pLine->npEndPos.y;
		if(nMinY > pLine->npEndPos.y) nMinY = pLine->npEndPos.y;
	}
}

void DUnit::ReMoveAllLineData()
{
	LPLINEDATA pLine;
	POSITION pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		if(pLine->nRefNo == 1)
			delete pLine;
		else
			pLine->nRefNo--;
	}
	m_LineData.RemoveAll();
}

void DUnit::ReMoveAllHoleData()
{
/*	POSITION pos = m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	
	while (pos) 
	{
		pData = m_HoleData.GetNext(pos);
		if(pData->nRefNo == 1)
			delete pData;
		else
			pData->nRefNo--;
	}
*/	m_HoleData.RemoveAll();
}

BOOL DUnit::IsDotData(int nTool)
{
	POSITION pos = m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	
	while (pos) 
	{
		pData = m_HoleData.GetNext(pos);
		if(pData->nToolNo == nTool)
			return TRUE;
	}
	return FALSE;
}

BOOL DUnit::IsLineData(int nTool)
{
	POSITION pos = m_LineData.GetHeadPosition();
	LPLINEDATA pData;
	
	while (pos) 
	{
		pData = m_LineData.GetNext(pos);
		if(pData->nToolNo == nTool)
			return TRUE;
	}
	return FALSE;
}

void DUnit::Copy(DUnit *pUnit)
{
	POSITION pos = pUnit->m_HoleData.GetHeadPosition();
	LPHOLEDATA pData = NULL;
/*	HOLEDATA HoleData;
	while (pos) 
	{
		pData = pUnit->m_HoleData.GetNext(pos);
		memcpy(&HoleData, pData, sizeof(HOLEDATA));
//		pData->nRefNo++;
		m_HoleData.AddTail(HoleData);
	}
*/	
	LPLINEDATA pLine;
	pos = pUnit->m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = pUnit->m_LineData.GetNext(pos);
		pLine->nRefNo++;
		m_LineData.AddTail(pLine);
	}

	int* pIndex;
	int* pNewIndex;
	pos = pUnit->m_SubFidIndexData.GetHeadPosition();
	while (pos) 
	{
		pIndex = pUnit->m_SubFidIndexData.GetNext(pos);
		pNewIndex = new int;
		*pNewIndex = *pIndex;
		m_SubFidIndexData.AddTail(pNewIndex);
	}

	m_nMinX = pUnit->m_nMinX;
	m_nMaxX = pUnit->m_nMaxX;
	m_nMinY = pUnit->m_nMinY;
	m_nMaxY = pUnit->m_nMaxY;
}

void DUnit::SetSelect()
{
	if(m_bSelect)
		m_bSelect = FALSE;
	else
		m_bSelect = TRUE;
}

void DUnit::Move(int nX, int nY)
{
	POSITION pos = m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	while (pos) 
	{
		pData = m_HoleData.GetNext(pos);
		pData->npPos.x += nX;
		pData->npPos.y += nY;
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		pLine->npStartPos.x += nX;
		pLine->npStartPos.y += nY;
		pLine->npEndPos.x += nX;
		pLine->npEndPos.y += nY;
	}
	
	m_nMinX += nX;
	m_nMaxX += nX;
	m_nMinY += nY;
	m_nMaxY += nY;
}

void DUnit::Copy(DUnit *pUnit, int nOffsetX, int nOffsetY)
{
	POSITION pos = pUnit->m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	HOLEDATA NewData;
	while (pos) 
	{
		pData = pUnit->m_HoleData.GetNext(pos);
		NewData.npPos.x = pData->npPos.x + nOffsetX;
		NewData.npPos.y = pData->npPos.y + nOffsetY;

		NewData.nToolNo = pData->nToolNo;
		NewData.nUnitIndex = pData->nUnitIndex;
		NewData.nBlockName2= pData->nBlockName2;
        NewData.cIsPattern= pData->cIsPattern;



		for(int i=0; i<4; i++)
		{
			for(int j=0; j<2; j++)
			{
				NewData.nFidIndex[i][j] = pData->nFidIndex[i][j];
			}
		}
		m_HoleData.AddTail(NewData);
	}
	
	LPLINEDATA pLine, pNewLine;
	pos = pUnit->m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = pUnit->m_LineData.GetNext(pos);
		pNewLine = new LINEDATA;
		pNewLine->npStartPos.x = pLine->npStartPos.x + nOffsetX;
		pNewLine->npStartPos.y = pLine->npStartPos.y + nOffsetY;
		pNewLine->npEndPos.x = pLine->npEndPos.x + nOffsetX;
		pNewLine->npEndPos.y = pLine->npEndPos.y + nOffsetY;
		pNewLine->nUnitIndex = pLine->nUnitIndex;
		pNewLine->nRefNo = 1;
		pNewLine->nToolNo = pLine->nToolNo;

		for(int i=0; i<4; i++)
		{
			for(int j=0; j<2; j++)
			{
				pNewLine->nFidIndex[i][j] = pLine->nFidIndex[i][j];
			}
		}
		
		m_LineData.AddTail(pNewLine);
	}
	
/*	int* pIndex;
	int* pNewIndex;
	pos = pUnit->m_SubFidIndexData.GetHeadPosition();
	while (pos) 
	{
		pIndex = pUnit->m_SubFidIndexData.GetNext(pos);
		pNewIndex = new int;
		*pNewIndex = *pIndex;
		m_SubFidIndexData.AddTail(pNewIndex);
	}
*/ // �߰� �ؾ���. --> ��� �������� �����	
	m_nMinX = pUnit->m_nMinX + nOffsetX;
	m_nMaxX = pUnit->m_nMaxX + nOffsetX;
	m_nMinY = pUnit->m_nMinY + nOffsetY;
	m_nMaxY = pUnit->m_nMaxY + nOffsetY;
}

void DUnit::Merge(DUnit *pUnit)
{
	POSITION pos = pUnit->m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	HOLEDATA HoleData;
	while (pos) 
	{
		pData = pUnit->m_HoleData.GetNext(pos);
		memcpy(&HoleData, pData, sizeof(HOLEDATA));
//		pData->nRefNo++;
		m_HoleData.AddTail(HoleData);
	}
	
	LPLINEDATA pLine;
	pos = pUnit->m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = pUnit->m_LineData.GetNext(pos);
		pLine->nRefNo++;
		m_LineData.AddTail(pLine);
	}
	
	if(m_nMinX > pUnit->m_nMinX)
		m_nMinX = pUnit->m_nMinX;
	if(m_nMaxX < pUnit->m_nMaxX)
		m_nMaxX = pUnit->m_nMaxX;
	if(m_nMinY > pUnit->m_nMinY)
		m_nMinY = pUnit->m_nMinY;
	if(m_nMaxY < pUnit->m_nMaxY)
		m_nMaxY = pUnit->m_nMaxY;
}

void DUnit::DelInRect(CPoint point1, CPoint point2, BOOL bReverse)
{
	LPHOLEDATA pHole;
	POSITION posBefore, pos = m_HoleData.GetHeadPosition();
	posBefore = pos;
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if (point1.x > pHole->npPos.x || pHole->npPos.x > point2.x ||
			point1.y > pHole->npPos.y || pHole->npPos.y > point2.y) // outer hole
		{
			if(bReverse)
			{
//				if(pHole->nRefNo == 1)
//					delete pHole;
//				else
//					pHole->nRefNo--;

				m_HoleData.RemoveAt(posBefore);
			}
		}
		else
		{
			if(!bReverse)
			{
//				if(pHole->nRefNo == 1)
//					delete pHole;
//				else
//					pHole->nRefNo--;
				
				m_HoleData.RemoveAt(posBefore);
			}
		}

		posBefore = pos;
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	posBefore = pos;
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if (point1.x > pLine->npStartPos.x || pLine->npStartPos.x > point2.x ||
			point1.y > pLine->npStartPos.y || pLine->npStartPos.y > point2.y ||
			point1.x > pLine->npEndPos.x || pLine->npEndPos.x > point2.x ||
			point1.y > pLine->npEndPos.y || pLine->npEndPos.y > point2.y) // outer line
		{
			if(bReverse)
			{
				if(pLine->nRefNo == 1)
					delete pLine;
				else
					pLine->nRefNo--;
				
				m_LineData.RemoveAt(posBefore);
			}
		}
		else
		{
			if(!bReverse)
			{
				if(pLine->nRefNo == 1)
					delete pLine;
				else
					pLine->nRefNo--;
				
				m_LineData.RemoveAt(posBefore);
			}
		}
		posBefore = pos;
	}
}

BOOL DUnit::IsAnyData()
{
	if(m_HoleData.GetCount() != 0 ||
		m_LineData.GetCount() != 0)
		return TRUE;
	else
		return FALSE;
}

void DUnit::ReCalRect(BlockList* pBlocks)
{
	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;

	DBlock* pBlock, *pFindBlock;
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(pHole->nBlockName2 != 0)
		{
			POSITION posBlock = pBlocks->GetHeadPosition();
			pFindBlock = NULL;
			while(posBlock)
			{
				pBlock = pBlocks->GetNext(posBlock);
				if(pBlock->m_nBlockName == pHole->nBlockName2)
				{
					pFindBlock = pBlock;
					break;
				}
			}
			if(pFindBlock)
			{
				if(m_nMaxX < pHole->npPos.x + pFindBlock->m_nMaxX) m_nMaxX = pHole->npPos.x + pFindBlock->m_nMaxX;
				if(m_nMinX > pHole->npPos.x + pFindBlock->m_nMinX) m_nMinX = pHole->npPos.x + pFindBlock->m_nMinX;
				if(m_nMaxY < pHole->npPos.y + pFindBlock->m_nMaxY) m_nMaxY = pHole->npPos.y + pFindBlock->m_nMaxY;
				if(m_nMinY > pHole->npPos.y + pFindBlock->m_nMinY) m_nMinY = pHole->npPos.y + pFindBlock->m_nMinY;
			}
		}
		else
		{
			if(m_nMaxX < pHole->npPos.x) m_nMaxX = pHole->npPos.x;
			if(m_nMinX > pHole->npPos.x) m_nMinX = pHole->npPos.x;
			if(m_nMaxY < pHole->npPos.y) m_nMaxY = pHole->npPos.y;
			if(m_nMinY > pHole->npPos.y) m_nMinY = pHole->npPos.y;
		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(m_nMaxX < pLine->npStartPos.x) m_nMaxX = pLine->npStartPos.x;
		if(m_nMinX > pLine->npStartPos.x) m_nMinX = pLine->npStartPos.x;
		if(m_nMaxY < pLine->npStartPos.y) m_nMaxY = pLine->npStartPos.y;
		if(m_nMinY > pLine->npStartPos.y) m_nMinY = pLine->npStartPos.y;
		
		if(m_nMaxX < pLine->npEndPos.x) m_nMaxX = pLine->npEndPos.x;
		if(m_nMinX > pLine->npEndPos.x) m_nMinX = pLine->npEndPos.x;
		if(m_nMaxY < pLine->npEndPos.y) m_nMaxY = pLine->npEndPos.y;
		if(m_nMinY > pLine->npEndPos.y) m_nMinY = pLine->npEndPos.y;
	}
}

void DUnit::ResetAllFiducial(BOOL bSubFid)
{
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(pHole->bSelect)
		{
			for(int i=0; i<4; i++)
				pHole->nFidIndex[i][bSubFid] = -1;
		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(pLine->bSelect)
		{
			for(int i=0; i<4; i++)
				pLine->nFidIndex[i][bSubFid] = -1;
		}
	}
}

void DUnit::SetFiducial(int nIndex, BOOL bSubFid)
{
	if(nIndex < 0)
		return;

	int nFind;
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		nFind = 0;
		pHole = m_HoleData.GetNext(pos);
		
		if(pHole->bSelect)
		{
			for(int i=0; i<4; i++)
			{
				if(pHole->nFidIndex[i][bSubFid] != -1)
					nFind++;
			}

			if(nFind < 4)
			{
				for(int i=0; i<4; i++)
				{
					if(pHole->nFidIndex[i][bSubFid] == nIndex)
					{
						ErrMessage(_T("This is Selected Fiducial"));
						return;
					}

					if(pHole->nFidIndex[i][bSubFid] == -1)
					{
						pHole->nFidIndex[i][bSubFid] = nIndex;
						break;
					}
				}
			}
			else
			{
				ErrMessage("Data must be able to Select Maximum 4 Fiducial\n if new set, reset old Fiducial Info");
				return;
			}
		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		nFind = 0;
		pLine = m_LineData.GetNext(pos);
		
		if(pLine->bSelect)
		{
			for(int i=0; i<4; i++)
			{
				if(pLine->nFidIndex[i][bSubFid] != -1)
					nFind++;
			}

			if(nFind < 4)
			{
				for(int i=0; i<4; i++)
				{
					if(pLine->nFidIndex[i][bSubFid] == nIndex)
					{
						ErrMessage(_T("This is Selected Fiducial"));
						return;
					}
					
					if(pLine->nFidIndex[i][bSubFid] == -1)
					{
						pLine->nFidIndex[i][bSubFid] = nIndex;
						break;
					}	
				}
			}
			else
			{
				ErrMessage("Data must be able to Select Maximum 4 Fiducial\n if new set, reset old Fiducial Info");
				return;
			}
		}
	}
}

void DUnit::ResetOneFiducial(int nIndex, BOOL bSubFid)
{
	if(nIndex < 0)
		return;
	int nFind = 0;
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(pHole->bSelect)
		{
			for(int i=0; i<4; i++)
			{
				if(pHole->nFidIndex[i][bSubFid] == nIndex)
				{
					pHole->nFidIndex[i][bSubFid] = -1;
					nFind++;
					break;
				}
			}
		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(pLine->bSelect)
		{
			for(int i=0; i<4; i++)
			{
				if(pLine->nFidIndex[i][bSubFid] == nIndex)
				{
					pLine->nFidIndex[i][bSubFid] = -1;
					nFind++;
					break;
				}
			}
		}
	}

	if(nFind == 0)
		ErrMessage(_T("There is no Fiducial for reset"));
}

BOOL DUnit::IsUseFidInArea(int nIndex, BOOL bSubFid)
{
	if(nIndex < 0)
		return FALSE;
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(pHole->bSelect)
		{
			for(int i=0; i<4; i++)
			{
				if(pHole->nFidIndex[i][bSubFid] == nIndex)
				{
					return TRUE;
				}
			}
		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(pLine->bSelect)
		{
			for(int i=0; i<4; i++)
			{
				if(pLine->nFidIndex[i][bSubFid] == nIndex)
				{
					return TRUE;
				}
			}
		}
	}
	return FALSE;
}


void DUnit::BlockFirstPositionToZero(CPoint ptOffset, int nBlockName)
{
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		if(pHole->nBlockName2 == nBlockName)
			pHole->npPos += ptOffset;
	}

	m_nMinX += ptOffset.x;
	m_nMaxX += ptOffset.x;
	m_nMinY += ptOffset.y;
	m_nMaxY += ptOffset.y;
}
void DUnit::SetBlockInfoToToolInfo(CToolCodeList** pToolCodes)
{
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		if(pHole->nBlockName2 != 0)
			pToolCodes[pHole->nToolNo]->m_bContainBlockData = TRUE;

		pToolCodes[pHole->nToolNo]->m_nTempToolIsHole = 1;
	}

}
void DUnit::InitIsPatternFlag()
{
	LPHOLEDATA pHoleData;
	POSITION pos =  m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHoleData = m_HoleData.GetNext(pos);
		pHoleData->cIsPattern = 0;
	}

}

#define MAX_RESULT_NO		1000
#define MAX_TABLE_SIZE_UM		1000000
#define MAX_TABLE_MM		1000
#define MAX_ONELINE_DATA		10000 // 1000mm ������ ���� �����ϰ� 100um �������� �־ Ŀ�� ����
#define MAX_PATTERN_NO		200 // 5mm �����̸� 1000mm ���̺����� 200���� �ƽ���
#define DATA_HOLE_TYPE			1
#define DATA_LINE_TYPE			2
BOOL DUnit::FindPattern(CPoint ptStart, CPoint ptEnd, GlyphExcellon* pGlyphExcellon)
{

#ifdef			USER_SELECT_PATTERN
	m_nPatternStartP.x = ptStart.x - m_nMinX;
	m_nPatternStartP.y = ptStart.y - m_nMinY;
	m_nPatternEndP.x = ptEnd.x - m_nMinX;
	m_nPatternEndP.y = ptEnd.y - m_nMinY;
#else
	int nSizeXum = ptEnd.x - ptStart.x;
	int nSizeYum = ptEnd.y - ptStart.y;
	m_nPatternMinSizeX = nSizeXum;
	if(m_nPatternMinSizeX < 5000) m_nPatternMinSizeX = 5000;
	m_nPatternMinSizeY = nSizeYum;
	if(m_nPatternMinSizeY < 5000) m_nPatternMinSizeY = 5000;
#endif

	m_pGlyphExcellon = pGlyphExcellon;
	InitIsPatternFlag();




	PATTERN_HOLE_LIST pPatternXHoleList[MAX_TABLE_MM];
	PATTERN_LINE_LIST pPatternXLineList[MAX_TABLE_MM];
	PATTERN_HOLE_LIST pPatternYHoleList[MAX_TABLE_MM];
	PATTERN_LINE_LIST pPatternYLineList[MAX_TABLE_MM];

	PATTERN_HOLE_LIST* pPatternHoleList;
	PATTERN_LINE_LIST* pPatternLineList;
	pPatternHoleList = new PATTERN_HOLE_LIST[MAX_TABLE_MM*MAX_TABLE_MM]; // 1mm ����
	pPatternLineList = new PATTERN_LINE_LIST[MAX_TABLE_MM*MAX_TABLE_MM]; // 1mm ����

	int nPatternXCnt = 0, nPatternYCnt = 0;
	int nPatternDistX[100][MAX_PATTERN_NO], nPatternDistY[100][MAX_PATTERN_NO];
	int nPatternCntX[100], nPatternCntY[100], nPatternStartUmX[100], nPatternStartUmY[100];
	int nDataType;
	BOOL bPatternFound = FALSE;

	for(int nTool = 0; nTool < MAX_TOOL_NO; nTool++)
	{
		for(int i = 0; i < MAX_TABLE_MM; i++)
		{
			pPatternXHoleList[i].RemoveAll();
			pPatternXLineList[i].RemoveAll();
			pPatternYHoleList[i].RemoveAll();
			pPatternYLineList[i].RemoveAll();
		}
		nDataType = DivideDataForXYDirect(pPatternXHoleList, 	pPatternXLineList, pPatternYHoleList, pPatternYLineList, nTool);
		if(nDataType)
		{
			GetDistanceCandidate(pPatternXHoleList, pPatternXLineList, nTool, TRUE, nDataType, nPatternDistX[0], nPatternXCnt, nPatternCntX, nPatternStartUmX);
			GetDistanceCandidate(pPatternYHoleList, pPatternYLineList, nTool, FALSE, nDataType, nPatternDistY[0], nPatternYCnt, nPatternCntY, nPatternStartUmY);
			if(nPatternXCnt && nPatternYCnt)
				Make1mmGridDataMap(pPatternHoleList, pPatternLineList, nTool, nDataType);
			for(int nX = 0; nX < nPatternXCnt; nX++)
			{
				for(int nY = 0; nY < nPatternYCnt; nY++)
				{
					if(ApplyToOrigin(pPatternHoleList, pPatternLineList, nTool,
						nPatternDistX[nX], nPatternCntX[nX], nPatternStartUmX[nX],
						nPatternDistY[nY], nPatternCntY[nY], nPatternStartUmY[nY], nDataType))
					{
						nX = nY = MAX_RESULT_NO; // ����� �����ϴ� ���� ����.
						bPatternFound = TRUE;
						break;
					}
				}
			}
		}
	}

	delete [] pPatternHoleList;
	delete [] pPatternLineList;
	return bPatternFound;

}
BOOL DUnit::ApplyToOrigin(PATTERN_HOLE_LIST* pPatternHoleList, PATTERN_LINE_LIST* pPatternLineList, int nTool,
											int* nPatternDistX, int nPatternCntX, int nPatternStartUmX,
											int* nPatternDistY, int nPatternCntY, int nPatternStartUmY, int nDataType)
{
	// origin ��ġ �����ϱ�
	int nStartX, nEndX, nStartY, nEndY;
	GetOriginIndex(nPatternDistX, nPatternCntX, nPatternStartUmX - m_nMinX, nStartX, nEndX);
	GetOriginIndex(nPatternDistY, nPatternCntY, nPatternStartUmY - m_nMinY, nStartY, nEndY);
	
	// ���Ͽ� ���ԵǴ� Ȧ, ���� ã��
	POSITION pos;
	LPHOLEDATA pHoleData = NULL, pRepeatHoleData = NULL;
	LPLINEDATA pLineData = NULL, pRepeatLineData = NULL;
	PATTERN_HOLE_LIST  TempHoleBlock, tempHolePatterns;

	int nNextXUM, nNextXIndex, nNextYUM, nNextYIndex, nTotalPattLengX, nTotalPattLengY;
	int nFidBlockIndex[MAX_PATTERN_NO][MAX_PATTERN_NO];
	BOOL bIsPattern;
	for(int i = nStartX; i <= nEndX; i++)
	{
		for(int j = nStartY; j <= nEndY; j++)
		{
			if(nDataType == DATA_HOLE_TYPE)
			{
				pos = pPatternHoleList[i*MAX_TABLE_MM +j].GetHeadPosition();
				while(pos)
				{
					pHoleData = pPatternHoleList[i*MAX_TABLE_MM +j].GetNext(pos);
					if(pHoleData->nToolNo != nTool || pHoleData->cIsPattern != 0 || pHoleData->nBlockName2 != 0)
						continue;
					// pHoleData�� ���Ͽ� �����ϴ°�?
					bIsPattern = TRUE;
					// x y���� �˻�
					nNextXUM = pHoleData->npPos.x - m_nMinX;
					nTotalPattLengX = 0;
					for(int nRepeatX = -1; nRepeatX < nPatternCntX; nRepeatX++)
					{
						if(nRepeatX != -1)
						{
							nNextXUM += nPatternDistX[nRepeatX];
							nTotalPattLengX += nPatternDistX[nRepeatX];
						}
						nNextYUM = pHoleData->npPos.y - m_nMinY;
						nTotalPattLengY = 0;
						for(int nRepeatY = -1; nRepeatY < nPatternCntY; nRepeatY++)
						{
							if(nRepeatX == -1 && nRepeatY == -1)
								continue;
							if(nRepeatY != -1)
							{
								nNextYUM += nPatternDistY[nRepeatY];
								nTotalPattLengY += nPatternDistY[nRepeatY];
							}
							nNextXIndex = nNextXUM/1000;
							nNextYIndex = nNextYUM/1000;
							pRepeatHoleData = GetRepeatHoleData(pPatternHoleList, nNextXIndex, nNextYIndex, pHoleData, nTotalPattLengX, nTotalPattLengY, nTool);
							if(pRepeatHoleData == NULL) // ��ã�Ҵٸ�
							{
								nRepeatX = nRepeatY = 100000; // ����� Ŀ�� for�� ����
								bIsPattern = FALSE;
								tempHolePatterns.RemoveAll();
								break;
							}
							nFidBlockIndex[nRepeatX+1][nRepeatY+1] = pRepeatHoleData->nFidBlock;
							tempHolePatterns.AddTail(pRepeatHoleData);
						}
					}
					// 
					if(bIsPattern) // �����̸�
					{
						pHoleData->cIsPattern = 1;
						TempHoleBlock.AddTail(pHoleData);
						POSITION posPatterns;
						posPatterns = tempHolePatterns.GetHeadPosition();
						while(posPatterns)
						{
							pRepeatHoleData = tempHolePatterns.GetNext(posPatterns);
							pRepeatHoleData->cIsPattern = 1;
						}
						tempHolePatterns.RemoveAll();
					}
				}
			}

		}
	}

	//Make block and delete origin data
	if(TempHoleBlock.GetCount() > 0)
	{
		DBlock* pBlock = new DBlock();
		int nBlockName = m_pGlyphExcellon->m_Blocks.GetCount() + 1;
		pBlock->m_nBlockName = nBlockName;
		POSITION posPatterns;
		posPatterns = TempHoleBlock.GetHeadPosition();
		while(posPatterns)
		{
			pRepeatHoleData = TempHoleBlock.GetNext(posPatterns);
			nFidBlockIndex[0][0] = pRepeatHoleData->nFidBlock;
			pBlock->m_HoleData.AddTail(*pRepeatHoleData);
		}
		pBlock->ReCalRect();
		m_pGlyphExcellon->m_Blocks.AddTail(pBlock);

		DUnit* pNewUnit = new DUnit();
		pNewUnit->MovePattern(this);

		//
		nTotalPattLengX = 0;
		for(int nRepeatX = -1; nRepeatX < nPatternCntX; nRepeatX++)
		{
			if(nRepeatX != -1)
				nTotalPattLengX += nPatternDistX[nRepeatX];

			nTotalPattLengY = 0;
			for(int nRepeatY = -1; nRepeatY < nPatternCntY; nRepeatY++)
			{
				if(nRepeatY != -1)
					nTotalPattLengY += nPatternDistY[nRepeatY];
			// Add hole data
				HOLEDATA drData;
				drData.npPos.x = nTotalPattLengX;
				drData.npPos.y = nTotalPattLengY;
				drData.nToolNo = nTool; 
				drData.nFidBlock = nFidBlockIndex[nRepeatX+1][nRepeatY+1];
				drData.nBlockName2 = nBlockName;
				drData.cIsPattern = 0;
				pNewUnit->m_HoleData.AddTail(drData);
			}
		}
		RemoveAllMemory();
		MovePattern(pNewUnit);
		delete pNewUnit;
	}
	else
		return FALSE;

	return TRUE;
}

void DUnit::MovePattern(DUnit *pUnit)
{
	POSITION pos = pUnit->m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	while (pos) 
	{
		pData = pUnit->m_HoleData.GetNext(pos);
		if(pData->cIsPattern == 0)
			m_HoleData.AddTail(*pData);
	}
	

	int* pIndex;
	int* pNewIndex;
	pos = pUnit->m_SubFidIndexData.GetHeadPosition();
	while (pos) 
	{
		pIndex = pUnit->m_SubFidIndexData.GetNext(pos);
		pNewIndex = new int;
		*pNewIndex = *pIndex;
		m_SubFidIndexData.AddTail(pNewIndex);
	}

	m_nMinX = pUnit->m_nMinX;
	m_nMaxX = pUnit->m_nMaxX;
	m_nMinY = pUnit->m_nMinY;
	m_nMaxY = pUnit->m_nMaxY;
}

LPHOLEDATA DUnit::GetRepeatHoleData(PATTERN_HOLE_LIST* pPatternHoleList, int nXIndex, int nYIndex, LPHOLEDATA pHoleOrigin, int nTotalPattLengX, int nTotalPattLengY, int nTool)
{
	LPHOLEDATA pHole;
	POSITION pos;
	int nXDist, nYDist;
	pos = pPatternHoleList[nXIndex*MAX_TABLE_MM +nYIndex].GetHeadPosition();
	while(pos)
	{
		pHole = pPatternHoleList[nXIndex*MAX_TABLE_MM +nYIndex].GetNext(pos);
		if(pHole->nToolNo != nTool || pHole->cIsPattern != 0 || pHole->nBlockName2 != 0)
					continue;

		nXDist = abs(pHole->npPos.x - nTotalPattLengX - pHoleOrigin->npPos.x);
		nYDist = abs(pHole->npPos.y  - nTotalPattLengY - pHoleOrigin->npPos.y);
		if(nXDist < PATTERN_DIFF_VAL && nYDist <PATTERN_DIFF_VAL)
		{
			return pHole;
		}
	}
	return NULL;
}

void DUnit::GetOriginIndex(int* nPatternDist, int nPatternCnt, int nPatternStartUm, int& nStartI, int& nEndI)
{
	int nPatternMaxSize = INT_MAX;
	if(nPatternCnt == 0)
	{
		nStartI = 0;
		nEndI = MAX_TABLE_MM - 1;
		return;
	}
	for(int i = 0; i < nPatternCnt; i++)
	{
		if(nPatternMaxSize > nPatternDist[i])
			nPatternMaxSize = nPatternDist[i];
	}
	int nStartum, nEndum;
	nStartum = max(nPatternStartUm - nPatternMaxSize, 0);
	nEndum = nPatternStartUm + nPatternMaxSize;
	nStartI = nStartum/1000;
	nEndI = nEndum/1000;
}

void DUnit::Make1mmGridDataMap(PATTERN_HOLE_LIST* pPatternHoleList, PATTERN_LINE_LIST* pPatternLineList, int nTool, int nDataType)
{
	int nX, nX2, nY, nY2;
	for(int i = 0; i < MAX_TABLE_MM * MAX_TABLE_MM; i++)
	{
			pPatternHoleList[i].RemoveAll();
			pPatternLineList[i].RemoveAll();
	}
	if(nDataType == DATA_HOLE_TYPE) 
	{
		LPHOLEDATA pHoleData;
		POSITION pos =  m_HoleData.GetHeadPosition();
		while (pos) 
		{
			pHoleData = m_HoleData.GetNext(pos);
			if(pHoleData->nToolNo != nTool || pHoleData->nBlockName2 > 0)
				continue;

			nX = (pHoleData->npPos.x - m_nMinX - PATTERN_DIFF_VAL)/1000; 
			nX2 = (pHoleData->npPos.x - m_nMinX + PATTERN_DIFF_VAL)/1000; 

			nY = (pHoleData->npPos.y - m_nMinY - PATTERN_DIFF_VAL)/1000; 
			nY2 = (pHoleData->npPos.y - m_nMinY + PATTERN_DIFF_VAL)/1000; 
			for(int i = nX; i <= nX2; i++)
			{
				for(int j = nY; j <= nY2; j++)
					pPatternHoleList[MAX_TABLE_MM*i + j].AddTail(pHoleData);
			}
		}
	}

}
int DUnit::DivideDataForXYDirect(PATTERN_HOLE_LIST* pPatternXHoleList, 
													PATTERN_LINE_LIST* pPatternXLineList, 
													PATTERN_HOLE_LIST* pPatternYHoleList, 
													PATTERN_LINE_LIST* pPatternYLineList, int nTool)
{
	int nDataType = 0;
	int nX, nX2, nY, nY2;

	LPHOLEDATA pHoleData;
	POSITION pos =  m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHoleData = m_HoleData.GetNext(pos);
		if(pHoleData->nToolNo != nTool || pHoleData->nBlockName2 > 0)
			continue;

		nDataType = DATA_HOLE_TYPE;
		nX = (pHoleData->npPos.x - m_nMinX - PATTERN_DIFF_VAL)/1000; 
		pPatternYHoleList[nX].AddTail(pHoleData);

		nX2 = (pHoleData->npPos.x - m_nMinX + PATTERN_DIFF_VAL)/1000; 
		if(nX != nX2)
			pPatternYHoleList[nX2].AddTail(pHoleData);

		nY = (pHoleData->npPos.y - m_nMinY - PATTERN_DIFF_VAL)/1000; 
		pPatternXHoleList[nY].AddTail(pHoleData);
		nY2 = (pHoleData->npPos.y - m_nMinY + PATTERN_DIFF_VAL)/1000; 
		if(nY != nY2)
			pPatternXHoleList[nY2].AddTail(pHoleData);
	}
	if(nDataType == 0) // hole �� �ƴϸ�
	{
		LPLINEDATA pLineData;
		POSITION pos =  m_LineData.GetHeadPosition();
		while (pos) 
		{
			pLineData = m_LineData.GetNext(pos);
			if(pLineData->nToolNo != nTool)
				continue;

			nDataType = DATA_LINE_TYPE;
			nX = (pLineData->npStartPos.x - m_nMinX - PATTERN_DIFF_VAL)/1000; 
			pPatternYLineList[nX].AddTail(pLineData);
			nX2 =(pLineData->npStartPos.x - m_nMinX + PATTERN_DIFF_VAL)/1000; 
			if(nX != nX2)
				pPatternYLineList[nX2].AddTail(pLineData);

			nY = (pLineData->npStartPos.y - m_nMinY - PATTERN_DIFF_VAL)/1000; 
			pPatternXLineList[nY].AddTail(pLineData);
			nY2 =(pLineData->npStartPos.y - m_nMinY + PATTERN_DIFF_VAL)/1000; 
			if(nY != nY2)
				pPatternXLineList[nY2].AddTail(pLineData);
		}
	}

	return nDataType;
}

BOOL DUnit::GetDistanceCandidate(PATTERN_HOLE_LIST* pPatternHoleList, PATTERN_LINE_LIST* pPatternLineList, int nTool, BOOL bXDirect, int nDataType,
															int* nPatternDist, int& nCntCandidateNo, int* nPatternCount, int* nPatternStartUm)
{
	int nDist[MAX_RESULT_NO] = {0,}, nCount[MAX_RESULT_NO] = {0,};
	CPoint ptFResultPoint[MAX_RESULT_NO]; // x : distance (um), y : match hole count
	int  nFileLengthUM;
	int* pn1LineCount, nHolespos[MAX_ONELINE_DATA], nHoleDist[MAX_ONELINE_DATA], nPatternStartIndex[MAX_PATTERN_NO];
	int nPatternPercent[100], nNewPatternPercent[100];
	int nFResultCnt = 0, nPatternTotalNo = 0, nVerticalSkipum, nTempPatternRatio;
	int nTempPatternDist[100][MAX_PATTERN_NO], nTempPatternCount[100], nTempPatternStartUm[100];

	if(bXDirect)
	{
		nFileLengthUM = (m_nMaxX - m_nMinX);
		nVerticalSkipum = (m_nMaxY - m_nMinY)/20000; // 20�� ������ ����
	}
	else
	{
		nFileLengthUM = (m_nMaxY - m_nMinY);
		nVerticalSkipum = (m_nMaxX - m_nMinX)/20000; // 20�� ������ ����
	}

	pn1LineCount = new int[MAX_TABLE_SIZE_UM]; // 1um ���� (1000mm ���� Ŀ���� : ���̺��� 1000 ������ ���)

	memset(nPatternDist, -1, sizeof(int)*100*MAX_PATTERN_NO);
	memset(nTempPatternDist, -1, sizeof(int)*100*MAX_PATTERN_NO);
	memset(nPatternPercent, 0, sizeof(int)*100);
	LPHOLEDATA pHoleData = NULL, pFirstHoleData= NULL;
	LPLINEDATA pLineData= NULL, pFirstLineData= NULL;
	for(int i = 0 ; i < MAX_TABLE_MM; i++) // 20�� ������ ���� : ���� ���ø� 
	{
		memset(pn1LineCount, 0, sizeof(int)*MAX_TABLE_SIZE_UM);
		if(nDataType == DATA_HOLE_TYPE) 
		{
			pFirstHoleData = NULL;
			POSITION pos1stHole = pPatternHoleList[i].GetHeadPosition();
			while(pos1stHole)
			{
				pHoleData = pPatternHoleList[i].GetNext(pos1stHole);

				if(bXDirect)
				{
					if(pFirstHoleData != NULL && abs(pHoleData->npPos.y - pFirstHoleData->npPos.y) >= PATTERN_DIFF_VAL) // ���� ���̸� �ʿ��ϴ�.
						continue;
					pn1LineCount[pHoleData->npPos.x - m_nMinX]++;
				}
				else
				{
					if(pFirstHoleData != NULL && abs(pHoleData->npPos.x - pFirstHoleData->npPos.x) >= PATTERN_DIFF_VAL) // ���� ���̸� �ʿ��ϴ�.
						continue;
					pn1LineCount[pHoleData->npPos.y - m_nMinY]++;
				}
				if(pFirstHoleData == NULL)
					pFirstHoleData = pHoleData;
			}
		}

		// pattern find
		int nHoleCnt = 0, nDistIndex = 0;
		for(int j = 0; j < MAX_TABLE_SIZE_UM; j++)
		{
			if(pn1LineCount[j])
			{
				nHolespos[nHoleCnt] = j;
				if(nHoleCnt > 0)
				{
					nHoleDist[nDistIndex++] = nHolespos[nHoleCnt] - nHolespos[nHoleCnt-1];
				}
				nHoleCnt++;
				if(nHoleCnt >= MAX_ONELINE_DATA)
				{
					::AfxMessageBox("There are so many data on the same Y position");
					break;
				}
			}
		}
		if(nHoleCnt == 0) // �����Ͱ� �����Ƿ� �Ʒ��� �� �ʿ䰡 ����.
			continue; 
		//
#ifdef			USER_SELECT_PATTERN
		int nUserPatStartI, nUserPatEndI;
		if(0 == GetUserPatternIndex(nHolespos, nHoleDist, nHoleCnt, nUserPatStartI, nUserPatEndI, bXDirect))
			continue;

		int nResultCnt = GetPatternStartPos(nHolespos, nHoleDist, nUserPatStartI, nUserPatEndI, nHoleCnt, nPatternStartIndex, nPatternTotalNo);
		nTempPatternRatio = nPatternTotalNo * 100 /nHoleCnt; // ���� ������ Ȯ��
		if(nTempPatternRatio > 30) // ������ 30% �̻��̸� ����� ����
		{
			GetPatternDistance(nHolespos, nPatternStartIndex, nResultCnt, nTempPatternDist[nFResultCnt]);
			nTempPatternCount[nFResultCnt] = nResultCnt -1;
			nPatternPercent[nFResultCnt] = nTempPatternRatio;
			if(bXDirect)
				nTempPatternStartUm[nFResultCnt] = nHolespos[nPatternStartIndex[0]] + m_nMinX;
			else
				nTempPatternStartUm[nFResultCnt] = nHolespos[nPatternStartIndex[0]] + m_nMinY;
			nFResultCnt++;
		}

#else
		int nOneLineGetNo = 0;
		for(int j = 0; j < nHoleCnt/2 ; j++) // ������ �ִٸ� ���� �ȿ����� �����ؾ� �Ѵ�.
		{ 
			int nMinSizeIndex = GetMinPatternSizeEndI(nHoleDist, j, nHoleCnt, bXDirect);
			if(nMinSizeIndex == -1)
				break;
			int nResultCnt = GetPatternStartPos(nHolespos, nHoleDist, j, nMinSizeIndex, nMinSizeIndex+1, nHoleCnt, nPatternStartIndex, nPatternTotalNo);
			nTempPatternRatio = nPatternTotalNo * 100 /nHoleCnt; // ���� ������ Ȯ��
			if(nTempPatternRatio > 30) // ������ 30% �̻��̸� ����� ����
//			nTempPatternRatio = nPatternTotalNo * 100 /nFileLengthUM;
//			if(nResultCnt >= 2) 
			{
				GetPatternDistance(nHolespos, nPatternStartIndex, nResultCnt, nTempPatternDist[nFResultCnt]);
				nTempPatternCount[nFResultCnt] = nResultCnt -1;
				nPatternPercent[nFResultCnt] = nTempPatternRatio;
				nTempPatternStartUm[nFResultCnt] = nHolespos[j];
				nFResultCnt++;
				nOneLineGetNo++;
				if(nFResultCnt >= 100)
				{
					::AfxMessageBox("There are so many Pattern candidates");
					goto CalEndLine;
				}
				if(nTempPatternRatio > 50 || nOneLineGetNo >=5) // 80% �̻��̸� �� ���ο����� ���̻� �������� �ʴ´�.
					break;
			}
		}
#endif
		i += nVerticalSkipum;
		// pattern find end
	}

CalEndLine:
	delete [] pn1LineCount;

	nCntCandidateNo = nFResultCnt;
	// ������ % �� ���� ������ sort�ϰ� ��������. (���� ��ø���� ������, ���� ��ġ�� ���� ���� ���� �켱��)
	memset(nNewPatternPercent, 0, sizeof(int)*100);
	memset(nPatternStartUm, INT_MAX, sizeof(int)*100);
	for(int i = 0; i < nFResultCnt; i++)
	{
		for(int j = 0; j < nFResultCnt; j++)
		{
			if(nPatternPercent[i] >= nNewPatternPercent[j])
			{
				if(nPatternPercent[i] == nNewPatternPercent[j] && nTempPatternStartUm[i]  > nPatternStartUm[j])	
					continue;
				for(int nShift = nFResultCnt - 2; nShift >=j; nShift--)
				{
					nNewPatternPercent[nShift+1] = nNewPatternPercent[nShift];
					for(int nArray = 0; nArray < MAX_PATTERN_NO; nArray++)
						nPatternDist[(nShift+1)*MAX_PATTERN_NO + nArray] = nPatternDist[nShift*MAX_PATTERN_NO + nArray];
					nPatternCount[nShift+1] = nPatternCount[nShift];
					nPatternStartUm[nShift+1] = nPatternStartUm[nShift];
				}
				nNewPatternPercent[j] = nPatternPercent[i];
				for(int nArray = 0; nArray < MAX_PATTERN_NO; nArray++)
					nPatternDist[j*MAX_PATTERN_NO + nArray] = nTempPatternDist[i][nArray];
				nPatternCount[j] = nTempPatternCount[i];
				nPatternStartUm[j] = nTempPatternStartUm[i];
				break;
			}
		}
	}

	// log file ����
	CString strFileName, strMessage, strTemp;
	strFileName.Format(_T("MakePattern"));
	strMessage.Format(_T("Tool = %d Xdirect = %d "), nTool, bXDirect);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFileName), reinterpret_cast<WPARAM>(&strMessage));

	for(int j = -2; j < MAX_PATTERN_NO; j++)
	{
		for(int i = 0; i < nFResultCnt; i++)
		{
			if(i == 0)
			{
					strMessage.Format(_T("\t%d"), j);
					if(j == -2) 
						strTemp.Format(_T("\t%d"), nNewPatternPercent[i]);
					else if(j == -1) 
						strTemp.Format(_T("\t%d"), nPatternStartUm[i]);
					else 
						strTemp.Format(_T("\t%d"), nPatternDist[i*MAX_PATTERN_NO + j]);
					strMessage += strTemp;
			}
			else
			{
				if(j == -2) 
					strTemp.Format(_T("\t%d"), nNewPatternPercent[i]);
				else if(j == -1) 
					strTemp.Format(_T("\t%d"), nPatternStartUm[i]);
				else 
					strTemp.Format(_T("\t%d"), nPatternDist[i*MAX_PATTERN_NO + j]);
				strMessage += strTemp;
			}
		}
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFileName), reinterpret_cast<WPARAM>(&strMessage));
	}
	return TRUE;
}

int DUnit::GetPatternDistance(int*nHolespos, int* nPatternStart, int nCount, int* nResultPatternDist)
{
	for(int i = 0; i < nCount-1; i++)
	{
		nResultPatternDist[i] = nHolespos[nPatternStart[i+1]] - nHolespos[nPatternStart[i]];
	}
	return nCount;
}

void DUnit::GetMatchHoleCountAndDist(CPoint& ptFResultPoint, int* pnRawDataUm, int* nHolespos, int n1stStart, int n2ndStart)
{
	ptFResultPoint.y = 0;
	int nDistance = nHolespos[n2ndStart] - nHolespos[n1stStart];
	int nCount = 0;
	for(int i = n1stStart; i < n2ndStart; i++)
	{
		if(pnRawDataUm [nHolespos[i] + nDistance])
			nCount++;
	}
	ptFResultPoint.x = nDistance;
	ptFResultPoint.y = nCount;
}


#ifdef			USER_SELECT_PATTERN
int DUnit::GetUserPatternIndex(int*nHolespos, int*nHoleDist, int nHoleNo, int& nStartIndex, int& nEndIndex, BOOL bXDirect)
{
	nStartIndex = nEndIndex = - 1;
	int nDataStartUm = nHolespos[0], nCurrentPosUm;
	int nUserPatternStart, nUserPatternEnd;
	
	if(bXDirect)
	{
		nUserPatternStart = m_nPatternStartP.x;
		nUserPatternEnd = m_nPatternEndP.x;
	}
	else
	{
		nUserPatternStart = m_nPatternStartP.y;
		nUserPatternEnd = m_nPatternEndP.y;
	}
	nCurrentPosUm = nDataStartUm;
	for(int i = 0; i < nHoleNo; i++)
	{
		if(nCurrentPosUm >= nUserPatternStart  && nCurrentPosUm <= nUserPatternEnd && nStartIndex == -1)
		{
			nStartIndex = i;
		}
		nCurrentPosUm += nHoleDist[i];
		if(nCurrentPosUm >= nUserPatternStart  && nCurrentPosUm <= nUserPatternEnd)
		{
			nEndIndex = i;
		}
	}
	if(nStartIndex == -1 || nEndIndex == -1)
		return 0;
	if(nStartIndex > nEndIndex)
		return 0;

	return 1;
}
int DUnit::GetPatternStartPos(int*nHolespos, int*nHoleDist, int nPatternStart, int nPatternEnd, int nHoleNo, int* nResultPatterndStart, int& nPatternTotalNo)
{
	// find patterns
	int nDist1, nDist2, nFinalPatternLength = nPatternEnd - nPatternStart;
	int nReturnCnt = 0;
	BOOL bPattern;
	for(int i = 0; i < nHoleNo; i++) 
	{
		bPattern = TRUE;
		for(int j = 0; j <= nFinalPatternLength; j++)
		{
			nDist2 = nHoleDist[i+j];
			nDist1 = nHoleDist[j+nPatternStart];
			if(abs(nDist2 - nDist1) > PATTERN_DIFF_VAL)
			{
				bPattern = FALSE;
				break;
			}
		}
		// �����̸�
		if(bPattern)
		{
			nResultPatterndStart[nReturnCnt++] = i;
			i = i + nFinalPatternLength;
		}
	}
	nPatternTotalNo = nReturnCnt * (nFinalPatternLength + 1); // ���� ������ Ȯ��// ���� ������ Ȯ��
	return nReturnCnt;
}

#else
int DUnit::GetMinPatternSizeEndI(int*nHoleDist, int nStartIndex, int nHoleNo, BOOL bXDirect)
{
	// min size 5000um
	int nSize = 0, nMinSizeIndex = -1;
	for(int i = nStartIndex; i < nHoleNo * 3/4; i++)
	{
		nSize += nHoleDist[i];
		if(nSize >= 4000 && nMinSizeIndex == -1)
			nMinSizeIndex = i - nStartIndex;
		if(bXDirect)
		{
			if(nSize > m_nPatternMinSizeX)// less than pattern size
				return max(nMinSizeIndex, i-1 - nStartIndex);
		}
		else
		{
			if(nSize > m_nPatternMinSizeY)// less than pattern size
				return max(nMinSizeIndex, i-1 - nStartIndex);
		}
	}
	return -1;
}

int DUnit::GetPatternStartPos(int*nHolespos, int*nHoleDist, int n1stStart, int n1stMinEnd, int n2ndStart, int n2ndEnd, int* nResultPatterndStart, int& nPatternTotalNo)
{ 
	int nDist1, nDist2, nReturnCnt = 0;
	int nBeforePatternLeng = 0;
	if(n1stStart != 0)
		nBeforePatternLeng = nHoleDist[n1stStart-1];
	BOOL bPattern;
	int nFinalPatternLength = 0, nPatternLengthUM = 0;
	nResultPatterndStart[nReturnCnt++] = n1stStart; // ù ���ϵ� �ִ´�.
	nPatternTotalNo = 0;
	// ������ ���� �� �ִ� �ִ� �Ÿ��� n1stMinEnd �� ���ϱ�
	for(int i = n2ndStart; i < n2ndEnd; i++) 
	{
		bPattern = TRUE;
		for(int j = 0; j <= n1stMinEnd; j++)
		{
			nDist2 = nHoleDist[i+j+n1stStart];
			nDist1 = nHoleDist[j+n1stStart];
			if(abs(nDist2 - nDist1) > PATTERN_DIFF_VAL)
			{
				bPattern = FALSE;
				break;
			}
		}
		// �����̸�
		if(bPattern)
		{
			for(int j = 0; j <= i-1; j++) // i+n1stStart-1 : �ִ밡 �� �� �ִ� ������ ���� : �ι�° ���� �ٷ� ����
			{
				nDist2 = nHoleDist[i+j+n1stStart];
				nDist1 = nHoleDist[j+n1stStart];
				if(abs(nDist2 - nDist1) > PATTERN_DIFF_VAL)
				{
					bPattern = FALSE;
					break;
				}
				if(nPatternLengthUM + nBeforePatternLeng + nDist1 > m_nPatternMinSizeX)
					break;

				nFinalPatternLength = j;
				nPatternLengthUM += nDist1;
			}
			n2ndStart = i; // �˻��� �� �ִ� ���۵� �ٲ۴�.
			break;
		}
	}
	if(nFinalPatternLength == 0) // ������ ���� �־�� �Ѵ�.
		return 0;
	// find patterns
	for(int i = n2ndStart; i < n2ndEnd; i++) 
	{
		bPattern = TRUE;
		for(int j = 0; j <= nFinalPatternLength; j++)
		{
			nDist2 = nHoleDist[i+j+n1stStart];
			nDist1 = nHoleDist[j+n1stStart];
			if(abs(nDist2 - nDist1) > PATTERN_DIFF_VAL)
			{
				bPattern = FALSE;
				break;
			}
		}
		// �����̸�
		if(bPattern)
		{
			nResultPatterndStart[nReturnCnt++] = i+n1stStart;
			i = i + nFinalPatternLength;
		}
	}
	nPatternTotalNo = nReturnCnt * (nFinalPatternLength + 1); // ���� ������ Ȯ��// ���� ������ Ȯ��
//	nPatternTotalNo = nReturnCnt * nPatternLengthUM; 
	return nReturnCnt;
}
#endif







int DUnit::CalMappingIndex(int& nYCount)
{
	int nTempYCount = 0;
	PATTERN_HOLE_LIST* pPatternHoleList;
	pPatternHoleList = new PATTERN_HOLE_LIST[MAX_TABLE_MM*MAX_TABLE_MM]; // 1mm ����
	int nResultCount = 0, nIndex;
	nIndex = 0;
	for(int nTool = 0; nTool < MAX_TOOL_NO; nTool++)
	{
		if(!Make1mmGridDataMap(pPatternHoleList, nTool))
			continue;
		// 
		nIndex = SetMapping(pPatternHoleList, nTempYCount);
		nResultCount = max(nResultCount, nIndex);
		nYCount = max(nYCount, nTempYCount);
	}

	delete [] pPatternHoleList;
	return nResultCount;
}

int DUnit::SetMapping(PATTERN_HOLE_LIST* pPatternHoleList, int& nYCount)
{
	int nMaxIndex = 0;
	return nMaxIndex;
}

BOOL DUnit::Make1mmGridDataMap(PATTERN_HOLE_LIST* pPatternHoleList, int nTool)
{
	BOOL bAdd = FALSE;
	int nX = 0, nX2 = 0, nY = 0, nY2 = 0;
	for(int i = 0; i < MAX_TABLE_MM * MAX_TABLE_MM; i++)
	{
			pPatternHoleList[i].RemoveAll();
	}

	LPHOLEDATA pHoleData;
	POSITION pos =  m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHoleData = m_HoleData.GetNext(pos);
		if(pHoleData->nToolNo != nTool || pHoleData->nBlockName2 > 0)
			continue;

		nX = (pHoleData->npPos.x - m_nMinX)/1000; 
		nY = (pHoleData->npPos.y - m_nMinY)/1000; 
		pPatternHoleList[MAX_TABLE_MM*nX + nY].AddTail(pHoleData);
		bAdd = TRUE;
	}
	return bAdd;
}

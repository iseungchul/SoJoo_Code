// SystemINIFile.h: interface for the CSystemINIFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SYSTEMINIFILE_H__FF97ADC7_9C37_49FC_8A63_8F44D1A2B82E__INCLUDED_)
#define AFX_SYSTEMINIFILE_H__FF97ADC7_9C37_49FC_8A63_8F44D1A2B82E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DSystemINI;

class CSystemINIFile  
{
public:

	CSystemINIFile();
	virtual ~CSystemINIFile();

	BOOL	OpenSystemINIFile(CString strFilePath, DSystemINI& clsSystemINI);
	BOOL	ParsingSystemHardware(CStdioFile& sFile, DSystemINI& clsSystemINI);
	BOOL	ParsingSystemDevice(CStdioFile& sFile, DSystemINI& clsSystemINI);
	BOOL	ParsingSystemCollimator(CStdioFile& sFile, DSystemINI& clsSystemINI);
	BOOL	ParsingSystemTophat(CStdioFile& sFile, DSystemINI& clsSystemINI);
	BOOL	ParsingAxisInfo(CStdioFile& sFile, DSystemINI& clsSystemINI);
	BOOL	ParsingComponent(CStdioFile& sFile, DSystemINI& clsSystemINI);

	BOOL	SaveSystemINIFile(CString strFilePath, DSystemINI clsSystemINI);
	BOOL	SaveHardware(CStdioFile& sFile, DSystemINI clsSystemINI);
	BOOL	SaveSystemDevice(CStdioFile& sFile, DSystemINI clsSystemINI);
	BOOL	SaveSystemCollimator(CStdioFile& sFile, DSystemINI clsSystemINI);
	BOOL	SaveSystemTophat(CStdioFile& sFile, DSystemINI clsSystemINI);
	BOOL	SaveAxisInfo(CStdioFile& sFile, DSystemINI clsSystemINI);
	BOOL	SaveComponent(CStdioFile& sFile, DSystemINI clsSystemINI);

	void	WriteLog(CString strLog);
};

#endif // !defined(AFX_SYSTEMINIFILE_H__FF97ADC7_9C37_49FC_8A63_8F44D1A2B82E__INCLUDED_)

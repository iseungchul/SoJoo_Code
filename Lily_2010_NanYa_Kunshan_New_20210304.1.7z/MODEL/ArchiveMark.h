// ArchiveMark.h: interface for the CArchiveMark class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ARCHIVEMARK_H__320161D5_EFE5_4195_9DD5_DF68BC29CE28__INCLUDED_)
#define AFX_ARCHIVEMARK_H__320161D5_EFE5_4195_9DD5_DF68BC29CE28__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDPoint;
class CDRect;
class CDPLTPoint;

//##ModelId=403400C903B9
class CArchiveMark
{
public:
	// Flag values
	//##ModelId=403400CA00DA
	enum Mode { store = 0, load = 1, bNoFlushOnDelete = 2};

	//##ModelId=403400C903C8
	CArchiveMark(CStdioFile* pFile, UINT nMode, int nBufSize = 4096, LPTSTR lpszBuf = NULL);
	//##ModelId=403400C903CD
	virtual ~CArchiveMark();

	// Attributes
	//##ModelId=403400C903D8
	BOOL IsLoading() const { return (m_nMode & CArchiveMark::load) != 0; }
	//##ModelId=403400C903DA
	BOOL IsStoring() const { return (m_nMode & CArchiveMark::load) == 0; }
	//##ModelId=403400C903DC
	CStdioFile* GetFile() const { return m_pFile; };

	// Operations
	//##ModelId=403400C903DE
	void Flush();
	//##ModelId=403400C903DF
	void Close();
	//##ModelId=403400CA0000
	void Abort();   // close and shutdown without exceptions
	
	// reading and writing strings
	//##ModelId=403400CA0001
	void WriteString(LPCTSTR lpsz);
	//##ModelId=403400CA0003
	LPTSTR ReadString(LPTSTR lpsz, UINT nMax);
	//##ModelId=403400CA0011
	BOOL ReadString(CString& rString);

public:
	// insertion operations
	//##ModelId=403400CA0013
	CArchiveMark& operator<<(BYTE by);
	//##ModelId=403400CA001F
	CArchiveMark& operator<<(WORD w);
	//##ModelId=403400CA0021
	CArchiveMark& operator<<(LONG l);
	//##ModelId=403400CA0023
	CArchiveMark& operator<<(DWORD dw);
	//##ModelId=403400CA0025
	CArchiveMark& operator<<(float f);
	//##ModelId=403400CA003E
	CArchiveMark& operator<<(double d);
	//##ModelId=403400CA0040
	CArchiveMark& operator<<(int i);
	//##ModelId=403400CA0042
	CArchiveMark& operator<<(short w);
	//##ModelId=403400CA0044
	CArchiveMark& operator<<(TCHAR ch);
	//##ModelId=403400CA004F
	CArchiveMark& operator<<(unsigned u);
	//##ModelId=403400CA0051
	CArchiveMark& operator<<(LPCTSTR lpsz);
	//##ModelId=403400CA0053
	CArchiveMark& operator<<(CDPoint pt);
	//##ModelId=403400CA005D
	CArchiveMark& operator<<(CPoint pt);
	//##ModelId=403400CA006D
	CArchiveMark& operator<<(bool b);
	//##ModelId=403400CA006F
	CArchiveMark& operator<<(__int64 i64);
	
	// extraction operations
	//##ModelId=403400CA0071
	CArchiveMark& operator>>(BYTE& by);
	//##ModelId=403400CA0073
	CArchiveMark& operator>>(WORD& w);
	//##ModelId=403400CA007E
	CArchiveMark& operator>>(DWORD& dw);
	//##ModelId=403400CA0080
	CArchiveMark& operator>>(LONG& l);
	//##ModelId=403400CA0082
	CArchiveMark& operator>>(float& f);
	//##ModelId=403400CA0084
	CArchiveMark& operator>>(double& d);
	//##ModelId=403400CA008D
	CArchiveMark& operator>>(int& i);
	//##ModelId=403400CA008F
	CArchiveMark& operator>>(short& w);
	//##ModelId=403400CA0091
	CArchiveMark& operator>>(TCHAR& ch);
	//##ModelId=403400CA009C
	CArchiveMark& operator>>(unsigned& u);
	//##ModelId=403400CA009E
	CArchiveMark& operator>>(CString& rString);
	//##ModelId=403400CA00A0
	CArchiveMark& operator>>(CDPoint& pt);
	//##ModelId=403400CA00A2
	CArchiveMark& operator>>(CPoint& pt);
	//##ModelId=403400CA00B2
	CArchiveMark& operator>>(bool b);
	//##ModelId=403400CA00BC
	CArchiveMark& operator>>(__int64& i64);
	
protected:
	//##ModelId=403400CA00BE
	BOOL m_nMode;
	//##ModelId=403400CA00BF
	BOOL m_bUserBuf;
	//##ModelId=403400CA00C0
	int m_nBufSize;
	//##ModelId=403400CA00CC
	CStdioFile* m_pFile;
	//##ModelId=403400CA00D0
	LPTSTR m_lpszBuf;
};

#endif // !defined(AFX_ARCHIVEMARK_H__320161D5_EFE5_4195_9DD5_DF68BC29CE28__INCLUDED_)

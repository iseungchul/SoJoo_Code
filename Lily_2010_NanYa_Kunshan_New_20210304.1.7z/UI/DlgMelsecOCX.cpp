// Device\DlgMelsecOCX.cpp : implementation file
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "..\ui\DlgMelsecOCX.h"
#include "afxdialogex.h"


// CDlgMelsecOCX dialog

IMPLEMENT_DYNAMIC(CDlgMelsecOCX, CDialog)

CDlgMelsecOCX::CDlgMelsecOCX(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgMelsecOCX::IDD, pParent)
{
}

CDlgMelsecOCX::~CDlgMelsecOCX()
{
}

void CDlgMelsecOCX::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ACTQJ71E71TCP1, m_MelsecQ);
	DDX_Control(pDX, IDC_ACTSUPPORT1, m_ctrlMelsecSupport);
	DDX_Control(pDX, IDC_ACTQNUDECPUTCP1, m_MelsecQCPU);
}


BEGIN_MESSAGE_MAP(CDlgMelsecOCX, CDialog)
END_MESSAGE_MAP()


// CDlgMelsecOCX message handlers


BOOL CDlgMelsecOCX::DestroyWindow()
{
	// TODO: Add your specialized code here and/or call the base class
	m_MelsecQ.Close();
	return CDialog::DestroyWindow();
}

long CDlgMelsecOCX::GetErrorFromMelsecQ(long lErrorCode)
{
	BSTR bstrErrMsg = 0;

	long lRet = m_ctrlMelsecSupport.GetErrorMessage( lErrorCode, &bstrErrMsg );

	CString strErrMsg;

	if( 0 != lRet )
		strErrMsg.Format("Get Error Message Function Fail : %.x", lRet);
	else
		strErrMsg = bstrErrMsg;
	//strErrMsg.Format("%s", bstrErrMsg);

	::SysFreeString( bstrErrMsg );

	::AfxMessageBox( (LPCTSTR)strErrMsg, MB_ICONERROR );
	return 0U;
}

BOOL CDlgMelsecOCX::Create(CWnd* pParentWnd) 
{
	// TODO: Add your specialized code here and/or call the base class

	return CDialog::Create(IDD, pParentWnd);
}

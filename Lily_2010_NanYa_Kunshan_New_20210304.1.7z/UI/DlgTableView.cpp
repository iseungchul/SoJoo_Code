// ui\DlgTableView.cpp : implementation file
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "ui\DlgTableView.h"
#include "afxdialogex.h"
#include "..\MODEL\DSystemINI.h"
#include "..\MODEL\DProcessINI.h"
#include "..\DEVICE\HDeviceFactory.h"
#include "..\Device\DeviceMotor.h"

// CDlgTableView dialog

IMPLEMENT_DYNAMIC(CDlgTableView, CDialog)

CDlgTableView::CDlgTableView(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgTableView::IDD, pParent)
{
	m_nTimer = -1;
	m_nMode = TABLE_AUTOSCAL;
	m_nCam = HIGH_1ST_CAM;
	m_bDisplayOn = FALSE;
}

CDlgTableView::~CDlgTableView()
{
	if(m_nTimer != -1)
	{
		KillTimer(m_nTimer);
		m_nTimer = -1;
	}
}


void CDlgTableView::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgTableView, CDialog)
	ON_WM_TIMER()
	ON_WM_PAINT()
	ON_WM_DESTROY()
END_MESSAGE_MAP()


// CDlgTableView message handlers


BOOL CDlgTableView::OnInitDialog() 
{
	CDialog::OnInitDialog();
	if(m_nTimer == -1)
		m_nTimer = SetTimer(1234, 500, NULL);
	
	return TRUE;
}
void CDlgTableView::DrawTable()
{
	double dScale = 0.5;
 	double dHalf = gSystemINI.m_sSystemDevice.dFieldSize.x/2 * dScale;
	double dTableX = gSystemINI.m_sSystemDevice.dTableSizeX * dScale;
	double dTableY = gSystemINI.m_sSystemDevice.dTableSizeY * dScale;
	double dAcrAreaX = gSystemINI.m_sSystemDevice.dTableAcrSizeX * dScale;
	double dAcrAreaY = gSystemINI.m_sSystemDevice.dTableAcrSizeY * dScale;
	double dSCalAreaMinX = gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX * dScale;
	double dSCalAreaMaxX = gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX * dScale;
	double dSCalAreaMinY = gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY * dScale;
	double dSCalAreaMaxY = gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY * dScale;
	double dSCalAreaMinXEx = dSCalAreaMinX - dHalf;
	double dSCalAreaMaxXEx = dSCalAreaMaxX + dHalf;
	double dSCalAreaMinYEx = dSCalAreaMinY - dHalf;
	double dSCalAreaMaxYEx = dSCalAreaMaxY + dHalf;
	double dX, dY;
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dX, TRUE);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dY, TRUE);

	dX = (gSystemINI.m_sSystemDevice.dTableSizeX - dX) * dScale;
	dY = (dY) * dScale;

	if(m_nMode == TABLE_ONEHOLE)
	{
		if(m_nCam == HIGH_1ST_CAM)
		{
			dX += gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x * dScale;
			dY -= gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y * dScale;
		}
		else if(m_nCam == LOW_1ST_CAM)
		{
			dX += gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x * dScale;
			dY -= gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y * dScale;
		}
		else if(m_nCam == HIGH_2ND_CAM)
		{
			dX += gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x * dScale;
			dY -= gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y * dScale;
		}
		else if(m_nCam == LOW_2ND_CAM)
		{
			dX += gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x * dScale;
			dY -= gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y * dScale;
		}
	}

	if(dX < 0)
		dX = 0;
	if(dY < 0)
		dY = 0;
	if(dX > dTableX)
		dX = dTableX;
	if(dY > dTableY)
		dY = dTableY;
	if(dSCalAreaMinXEx < 0)
		dSCalAreaMinXEx = 0;
	if(dSCalAreaMinYEx < 0)
		dSCalAreaMinYEx = 0;
	if(dSCalAreaMaxXEx > dTableX)
		dSCalAreaMaxXEx = dTableX;
	if(dSCalAreaMaxYEx > dTableY)
		dSCalAreaMaxYEx = dAcrAreaY;
	
	CString strPos;
	//set tight size
	CDC BufferDC;
	CRect cRect, cWndRect;
	cRect.top = 0;
	cRect.bottom = (LONG)dTableY +5 ;//������
	cRect.left = 0; 
	cRect.right = (LONG)dTableX+5;
	
	this->GetWindowRect(cWndRect);
	cWndRect.right =(LONG)(cWndRect.left + cRect.right);
	cWndRect.bottom = (LONG)(cWndRect.top + cRect.bottom);
	this->MoveWindow(cWndRect);

	GetDlgItem(IDC_STATIC_TABLE_VIEW)->MoveWindow( cRect );
	
	//draw start
	CClientDC dc(GetDlgItem(IDC_STATIC_TABLE_VIEW));
	GetDlgItem(IDC_STATIC_TABLE_VIEW)->GetClientRect(&cRect);
	BufferDC.CreateCompatibleDC(&dc);

	CBitmap bmpBuffer;
	bmpBuffer.CreateCompatibleBitmap(&dc,cRect.Width(), cRect.Height());
	if(bmpBuffer.m_hObject == NULL)
		return;

	CBitmap *pOldBitmap = (CBitmap*)BufferDC.SelectObject(&bmpBuffer);

	CBrush cBr(RGB(0, 0, 0));
	BufferDC.FrameRect(&cRect, &cBr);
	BufferDC.FillSolidRect(&cRect, RGB(255, 255, 255));

	CRgn cRgn;
	cRgn.CreateRectRgnIndirect(&cRect);
	BufferDC.SelectClipRgn(&cRgn);

	int nPenSize = 1;

	CPen pen, pen1, pen2, pen3, pen4, pen5, pen6;
	CPen* pOldPen;
	CBrush cBr2, cBr3, cBr4;
	CBrush* pOldBrush;

	cBr2.CreateSolidBrush(RGB(255, 255, 255));
	pOldBrush = BufferDC.SelectObject(&cBr2);

	//draw table 
	pen.CreatePen(PS_SOLID, nPenSize, RGB(230, 230, 230));
	pOldPen = BufferDC.SelectObject(&pen);
	BufferDC.Rectangle(0, 0, (int)dTableX, (int)dTableY);

	if(pOldBrush != NULL)
	{
		BufferDC.SelectObject(pOldBrush);
		pOldBrush = NULL;
	}
	if(pOldPen != NULL)
	{
		BufferDC.SelectObject(pOldPen);
		pOldPen = NULL;
	}
	if(pen.m_hObject != NULL)
		pen.DeleteObject();

	//draw acr table 
	//pen1.CreatePen(PS_DASHDOTDOT, nPenSize, RGB(128,128,128));
	//pOldPen = BufferDC.SelectObject(&pen1);
	//BufferDC.Rectangle(0,0,(int)dAcrAreaX, (int)dAcrAreaY);

	//draw protect area 
	CRect cRect2;
	cRect2.left = (int)dTableX - (int)dSCalAreaMinXEx;
	cRect2.right = (int)dTableX - (int)dSCalAreaMaxXEx;
	cRect2.top =  (int)dSCalAreaMinYEx;
	cRect2.bottom = (int)dSCalAreaMaxYEx;

	cBr3.CreateHatchBrush(HS_BDIAGONAL,  RGB(255, 191, 0));
	pOldBrush = BufferDC.SelectObject(&cBr3);
	BufferDC.FillRect(cRect2, &cBr3);
	pen2.CreatePen(PS_SOLID, nPenSize, RGB(255, 191, 0));
	pOldPen = BufferDC.SelectObject(&pen2);
	BufferDC.Rectangle(cRect2);
	
	if(pOldBrush != NULL)
	{
		BufferDC.SelectObject(pOldBrush);
		pOldBrush = NULL;
	}
	if(pOldPen != NULL)
	{
		BufferDC.SelectObject(pOldPen);
		pOldPen = NULL;
	}
	if(pen2.m_hObject != NULL)
		pen2.DeleteObject();

	//draw scal area
	CRect cRect3;
	cRect3.left = (int)dTableX - (int)dSCalAreaMinX;
	cRect3.right = (int)dTableX - (int)dSCalAreaMaxX;
	cRect3.top =  (int)dSCalAreaMinY;
	cRect3.bottom = (int)dSCalAreaMaxY;
	cBr4.CreateSolidBrush( RGB(255, 0, 0));
	pOldBrush = BufferDC.SelectObject(&cBr4);
	BufferDC.FillRect(cRect3, &cBr4);

	pen4.CreatePen(PS_SOLID, nPenSize, RGB(255, 0, 0));
 	pOldPen = BufferDC.SelectObject(&pen4);
	BufferDC.Rectangle(cRect3);
	BufferDC.SetTextColor(RGB(255,255,255));
	BufferDC.SetBkColor(RGB(255,0,0));
	BufferDC.TextOut(cRect3.right + (abs(cRect3.Width())/2), cRect3.bottom - (abs(cRect3.Height())/2), "Auto Scal Area");

	if(pOldBrush != NULL)
	{
		BufferDC.SelectObject(pOldBrush);
		pOldBrush = NULL;
	}
	if(pOldPen != NULL)
	{
		BufferDC.SelectObject(pOldPen);
		pOldPen = NULL;
	}
	if(pen4.m_hObject != NULL)
		pen4.DeleteObject();
		//draw pos
	//protect pos 
	BufferDC.SetBkMode(TRANSPARENT);
	BufferDC.SetTextColor(RGB(128,128,128));
	strPos.Format("%.0f, %.0f", gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX - gSystemINI.m_sSystemDevice.dFieldSize.x/2,
								gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY - gSystemINI.m_sSystemDevice.dFieldSize.x/2 ); 
	BufferDC.TextOut( cRect2.left - 60,cRect2.top,strPos);
	strPos.Format("%.0f, %.0f",gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX - gSystemINI.m_sSystemDevice.dFieldSize.x/2,
								gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY + gSystemINI.m_sSystemDevice.dFieldSize.x/2);
	BufferDC.TextOut(  cRect2.left - 60,cRect2.bottom ,strPos);
	strPos.Format("%.0f, %.0f", gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + gSystemINI.m_sSystemDevice.dFieldSize.x/2,
								gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY - gSystemINI.m_sSystemDevice.dFieldSize.x/2); 
	BufferDC.TextOut( cRect2.right,cRect2.top,strPos);
	strPos.Format("%.0f, %.0f", gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX + gSystemINI.m_sSystemDevice.dFieldSize.x/2,
								gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY + gSystemINI.m_sSystemDevice.dFieldSize.x/2);
	BufferDC.TextOut(  cRect2.right,cRect2.bottom ,strPos);


	//auto area
	BufferDC.SetTextColor(RGB(0,0,0));
	strPos.Format("%.0f, %.0f", gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX,gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY  ); 
	BufferDC.TextOut( cRect3.left - 60,cRect3.top,strPos);
	strPos.Format("%.0f, %.0f",gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosX,gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY );
	BufferDC.TextOut(  cRect3.left - 60,cRect3.bottom ,strPos);
	strPos.Format("%.0f, %.0f", gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX,gProcessINI.m_sProcessAutoSetting.dAutoCalMinTablePosY ); 
	BufferDC.TextOut( cRect3.right,cRect3.top,strPos);
	strPos.Format("%.0f, %.0f", gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosX,gProcessINI.m_sProcessAutoSetting.dAutoCalMaxTablePosY );
	BufferDC.TextOut(  cRect3.right,cRect3.bottom ,strPos);


	//current Pos
	if(m_nMode == TABLE_MANUALSCAL)
	{
		pen5.CreatePen(PS_DOT, nPenSize, RGB(4,233,136));
		pOldPen = BufferDC.SelectObject(&pen5);
		BufferDC.SelectStockObject(NULL_BRUSH);
		BufferDC.Rectangle((int)(dTableX - (gProcessINI.m_sProcessScannerCal.dManualStart.x * dScale) - dHalf), (int)((gProcessINI.m_sProcessScannerCal.dManualStart.y * dScale) - dHalf), 
							(int)(dTableX - (gProcessINI.m_sProcessScannerCal.dManualStart.x * dScale) + dHalf), (int)((gProcessINI.m_sProcessScannerCal.dManualStart.y * dScale) + dHalf));

		if(pOldPen != NULL)
		{
			BufferDC.SelectObject(pOldPen);
			pOldPen = NULL;
		}
		if(pen5.m_hObject != NULL)
			pen5.DeleteObject();
	}

	pen6.CreatePen(PS_SOLID, nPenSize*3, RGB(0,255,0));
	pOldPen = BufferDC.SelectObject(&pen6);
	BufferDC.Ellipse((int)dX-2, (int)dY-2, (int)dX+2, (int)dY+2);

	if(pOldPen != NULL)
	{
		BufferDC.SelectObject(pOldPen);
		pOldPen = NULL;
	}
	if(pen6.m_hObject != NULL)
		pen6.DeleteObject();

	//	GetDlgItem(IDC_STATIC_DRAW)->GetWindowRect(&cRect);
	dc.BitBlt(0,0,cRect.Width(),cRect.Height(),&BufferDC,0,0,SRCCOPY);

	BufferDC.SelectObject(pOldBitmap);
}

void CDlgTableView::SetDisplayOn(BOOL bOn)
{
	m_bDisplayOn = bOn;
}

void CDlgTableView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent == m_nTimer)
	{
		if(m_bDisplayOn)
			DrawTable();
	}
	CDialog::OnTimer(nIDEvent);
}


void CDlgTableView::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: Add your message handler code here
	// Do not call CDialog::OnPaint() for painting messages
}


void CDlgTableView::OnDestroy()
{
	CDialog::OnDestroy();
	if(m_nTimer != -1)
	{
		KillTimer(m_nTimer);
		m_nTimer = -1;
	}
	// TODO: Add your message handler code here
}

void CDlgTableView::SetMode(int nType, int nCam)
{
	m_nMode = nType;
	m_nCam = nCam;
}
#if !defined(AFX_PANEPROCESSSETUP_H__1B682B34_DF18_47D2_B7C6_9CA01D07C896__INCLUDED_)
#define AFX_PANEPROCESSSETUP_H__1B682B34_DF18_47D2_B7C6_9CA01D07C896__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneProcessSetup.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetup form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "USimpleTab.h"

class CPaneProcessSetupLaserScanner;
class CPaneProcessSetupProcessLarge;

class CPaneProcessSetupSysSetting;
class CPaneProcessSetupFiducial;
class CPaneProcessSetupOption;
class CPaneProcessSetupOption2;

class CPaneProcessSetup : public CFormView
{
protected:
	CPaneProcessSetup();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneProcessSetup)

// Form Data
public:
	//{{AFX_DATA(CPaneProcessSetup)
	enum { IDD = IDD_DLG_PROCESS_SETUP };
	USimpleTab	m_tabProcessSetup;
	//}}AFX_DATA

// Attributes
public:
	CPaneProcessSetupLaserScanner*	m_pLaserScanner;
	CPaneProcessSetupProcessLarge*		m_pProcess;

	CPaneProcessSetupSysSetting*	m_pSysSetting;
	CPaneProcessSetupFiducial*		m_pFiducial;
	CPaneProcessSetupOption*		m_pOption;
	CPaneProcessSetupOption2*		m_pOption2;

// Operations
public:
	void UpdateIniUI(int nVal);
	void ShowTabPane(int nPaneNo);
	void ChangeTab();
	void InitTabControl();
	void OnApply();
	
	void SetAuthorityByLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneProcessSetup)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneProcessSetup();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntTab;

	// Generated message map functions
	//{{AFX_MSG(CPaneProcessSetup)
	afx_msg void OnDestroy();
	afx_msg void OnClickTabProcessSetup(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEPROCESSSETUP_H__1B682B34_DF18_47D2_B7C6_9CA01D07C896__INCLUDED_)

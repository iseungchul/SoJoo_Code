// CTestThumnailView.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "TestThumnailView.h"

#include "DlgInformationBox.h"

#include "NAxis.h"

#pragma warning (disable:4189)

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestThumnailView

IMPLEMENT_DYNCREATE(CTestThumnailView, CScrollView)

CTestThumnailView::CTestThumnailView()
{
	m_nPositionX = -1;
	m_nPositionY = -1;
	m_nAxis = NAxis::axis_270;

	m_nOffsetX = 10;
	m_nOffsetY = 10;

	m_clrMovePosition = RGB(255, 0, 0);

	m_PenMovePosition.CreatePen(
		PS_SOLID,
		0,
		m_clrMovePosition
		);
}

CTestThumnailView::~CTestThumnailView()
{
}


BEGIN_MESSAGE_MAP(CTestThumnailView, CScrollView)
	//{{AFX_MSG_MAP(CTestThumnailView)
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestThumnailView drawing

void CTestThumnailView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	// TODO: calculate the total size of this view
	CRect rectClient;
	GetClientRect(rectClient);

	sizeTotal.cx = rectClient.Width();
	sizeTotal.cy = rectClient.Height();

	SetScrollSizes(MM_TEXT, sizeTotal);
}

void CTestThumnailView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here

	CRect rectClient;
	GetClientRect(rectClient);

	pDC->DPtoLP(rectClient);

	CRect rectField;
	rectField.left = rectClient.left + m_nOffsetX;
	rectField.top = rectClient.top + m_nOffsetY;
	rectField.right = rectClient.right - m_nOffsetX;
	rectField.bottom = rectClient.bottom - m_nOffsetY;
	
	pDC->MoveTo(rectField.left, rectField.top);
	pDC->LineTo(rectField.right, rectField.top);
	pDC->LineTo(rectField.right, rectField.bottom);
	pDC->LineTo(rectField.left, rectField.bottom);
	pDC->LineTo(rectField.left, rectField.top);
	
	pDC->SetWindowOrg(-m_nOffsetX, -m_nOffsetY);
	
	switch(m_nAxis)
	{
	case NAxis::axis_0:
		DrawMovePosition_0(pDC, rectField);
		break;
	case NAxis::axis_90:
		DrawMovePosition_90(pDC, rectField);
		break;
	case NAxis::axis_180:
		DrawMovePosition_180(pDC, rectField);
		break;
	case NAxis::axis_270:
		DrawMovePosition_270(pDC, rectField);
		break;
	case NAxis::axis_left_0:
		DrawMovePosition_Left_0(pDC, rectField);
		break;
	case NAxis::axis_left_90:
		DrawMovePosition_Left_90(pDC, rectField);
		break;
	case NAxis::axis_left_180:
		DrawMovePosition_Left_180(pDC, rectField);
		break;
	case NAxis::axis_left_270:
		DrawMovePosition_Left_270(pDC, rectField);
		break;
	}

}

/////////////////////////////////////////////////////////////////////////////
// CTestThumnailView diagnostics

#ifdef _DEBUG
void CTestThumnailView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CTestThumnailView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestThumnailView message handlers

BOOL CTestThumnailView::RegisterTestThumnailViewClass(HINSTANCE hInstance)
{
	WNDCLASS wc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hbrBackground = (HBRUSH) ::GetStockObject(WHITE_BRUSH);
	wc.hCursor = (HCURSOR) ::LoadCursor(NULL, IDC_CROSS);
	wc.hIcon = NULL;
	wc.hInstance = hInstance;
	wc.lpfnWndProc = (WNDPROC) CTestThumnailView::WindowProcedure;
	wc.lpszClassName = _T("TestThumnailViewClass");
	wc.lpszMenuName = NULL;
	wc.style = CS_GLOBALCLASS;

	BOOL bResult = (::RegisterClass(&wc) != 0);

	return bResult;
}

LRESULT CALLBACK CTestThumnailView::WindowProcedure(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	CTestThumnailView *pView = (CTestThumnailView *) CWnd::FromHandlePermanent(hWnd);
	if(pView == NULL)
	{
		pView = new CTestThumnailView;
		pView->Attach(hWnd);
	}

	VERIFY(pView);

	LRESULT lResult = AfxCallWndProc(pView, hWnd, nMsg, wParam, lParam);

	return lResult;

	return 0L;

}

void CTestThumnailView::DisplayMovePosition(int nPositionX, int nPositionY)
{
	m_nPositionX = nPositionX;
	m_nPositionY = nPositionY;

	TRACE(_T("Move Position: %d, %d\n"),
		m_nPositionX,
		m_nPositionY
		);

	Invalidate();
}

void CTestThumnailView::DrawMovePosition_0(CDC *pDC, CRect rectField)
{
	// rectField ���� �� Window Org�� OnDraw()���� �Ѵ�. */

	int nX = int(double(rectField.Width()) * (double(m_nPositionX) / 65535.0));
	int nY = int(double(rectField.Height()) *
		(1.0 - (double(m_nPositionY) / 65535.0)));

	CPen *pPenOld = pDC->SelectObject(&m_PenMovePosition);

	pDC->MoveTo(nX - 10, nY);
	pDC->LineTo(nX + 10, nY);
	pDC->MoveTo(nX, nY - 10);
	pDC->LineTo(nX, nY + 10);

	pDC->SelectObject(pPenOld);

}

void CTestThumnailView::DrawMovePosition_90(CDC *pDC, CRect rectField)
{
	// rectField ���� �� Window Org�� OnDraw()���� �Ѵ�. */

	int nX = int(double(rectField.Width()) * (double(m_nPositionY) / 65535.0));
	int nY = int(double(rectField.Height()) * (double(m_nPositionX) / 65535.0));

	CPen *pPenOld = pDC->SelectObject(&m_PenMovePosition);

	pDC->MoveTo(nX - 10, nY);
	pDC->LineTo(nX + 10, nY);
	pDC->MoveTo(nX, nY - 10);
	pDC->LineTo(nX, nY + 10);

	pDC->SelectObject(pPenOld);
}

void CTestThumnailView::DrawMovePosition_180(CDC *pDC, CRect rectField)
{
	// rectField ���� �� Window Org�� OnDraw()���� �Ѵ�. */

	int nX = int(double(rectField.Width()) *
		(1.0 - (double(m_nPositionX) / 65535.0)));
	int nY = int(double(rectField.Height()) * (double(m_nPositionY) / 65535.0));

	CPen *pPenOld = pDC->SelectObject(&m_PenMovePosition);

	pDC->MoveTo(nX - 10, nY);
	pDC->LineTo(nX + 10, nY);
	pDC->MoveTo(nX, nY - 10);
	pDC->LineTo(nX, nY + 10);

	pDC->SelectObject(pPenOld);
}

void CTestThumnailView::DrawMovePosition_270(CDC *pDC, CRect rectField)
{
	// rectField ���� �� Window Org�� OnDraw()���� �Ѵ�. */

	int nX = int(double(rectField.Width()) *
		(1.0 - (double(m_nPositionY) / 65535.0)));
	int nY = int(double(rectField.Height()) *
		(1.0 - (double(m_nPositionX) / 65535.0)));

	CPen *pPenOld = pDC->SelectObject(&m_PenMovePosition);

	pDC->MoveTo(nX - 10, nY);
	pDC->LineTo(nX + 10, nY);
	pDC->MoveTo(nX, nY - 10);
	pDC->LineTo(nX, nY + 10);

	pDC->SelectObject(pPenOld);

}

void CTestThumnailView::DrawMovePosition_Left_0(CDC *pDC, CRect rectField)
{
	// rectField ���� �� Window Org�� OnDraw()���� �Ѵ�. */

	int nX = int(double(rectField.Width()) * (double(m_nPositionY) / 65535.0));
	int nY = int(double(rectField.Height()) *
		(1.0 - (double(m_nPositionX) / 65535.0)));

	CPen *pPenOld = pDC->SelectObject(&m_PenMovePosition);

	pDC->MoveTo(nX - 10, nY);
	pDC->LineTo(nX + 10, nY);
	pDC->MoveTo(nX, nY - 10);
	pDC->LineTo(nX, nY + 10);

	pDC->SelectObject(pPenOld);
}

void CTestThumnailView::DrawMovePosition_Left_90(CDC *pDC, CRect rectField)
{
	// rectField ���� �� Window Org�� OnDraw()���� �Ѵ�. */

	int nX = int(double(rectField.Width()) * (double(m_nPositionX) / 65535.0));
	int nY = int(double(rectField.Height()) * (double(m_nPositionY) / 65535.0));

	CPen *pPenOld = pDC->SelectObject(&m_PenMovePosition);

	pDC->MoveTo(nX - 10, nY);
	pDC->LineTo(nX + 10, nY);
	pDC->MoveTo(nX, nY - 10);
	pDC->LineTo(nX, nY + 10);

	pDC->SelectObject(pPenOld);

}

void CTestThumnailView::DrawMovePosition_Left_180(CDC *pDC, CRect rectField)
{
	// rectField ���� �� Window Org�� OnDraw()���� �Ѵ�. */

	int nX = int(double(rectField.Width()) *
		(1.0 - (double(m_nPositionY) / 65535.0)));
	int nY = int(double(rectField.Height()) * (double(m_nPositionX) / 65535.0));

	CPen *pPenOld = pDC->SelectObject(&m_PenMovePosition);

	pDC->MoveTo(nX - 10, nY);
	pDC->LineTo(nX + 10, nY);
	pDC->MoveTo(nX, nY - 10);
	pDC->LineTo(nX, nY + 10);

	pDC->SelectObject(pPenOld);

}

void CTestThumnailView::DrawMovePosition_Left_270(CDC *pDC, CRect rectField)
{
	// rectField ���� �� Window Org�� OnDraw()���� �Ѵ�. */

	int nX = int(double(rectField.Width()) *
		(1.0 - (double(m_nPositionX) / 65535.0)));
	int nY = int(double(rectField.Height()) *
		(1.0 - (double(m_nPositionY) / 65535.0)));

	CPen *pPenOld = pDC->SelectObject(&m_PenMovePosition);

	pDC->MoveTo(nX - 10, nY);
	pDC->LineTo(nX + 10, nY);
	pDC->MoveTo(nX, nY - 10);
	pDC->LineTo(nX, nY + 10);

	pDC->SelectObject(pPenOld);

}



void CTestThumnailView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CClientDC dc(this);

	OnPrepareDC(&dc);

	CRect rectClient;
	GetClientRect(rectClient);

	dc.DPtoLP(rectClient);

	CRect rectField;
	rectField.left = rectClient.left + m_nOffsetX;
	rectField.top = rectClient.top + m_nOffsetY;
	rectField.right = rectClient.right - m_nOffsetX;
	rectField.bottom = rectClient.bottom - m_nOffsetY;
	
	dc.SetWindowOrg(-m_nOffsetX, -m_nOffsetY);

	CPoint ptPoint = point;
	dc.DPtoLP(&ptPoint);

	int nTempPosX = 0;
	int nTempPosY = 0;

	switch(m_nAxis)
	{
	case NAxis::axis_0:
		nTempPosX = int(65535 * double(ptPoint.x) / double(rectField.Width()));
		nTempPosY = 65535 - int(65535 * double(ptPoint.y) / double(rectField.Height()));
		break;
	case NAxis::axis_90:
		nTempPosX = int(65535 * double(ptPoint.y) / double(rectField.Height()));
		nTempPosY = int(65535 * double(ptPoint.x) / double(rectField.Width()));
		break;
	case NAxis::axis_180:
		nTempPosX = 65535 - int(65535 * double(ptPoint.x) / double(rectField.Width()));
		nTempPosY = int(65535 * double(ptPoint.y) / double(rectField.Height()));
		break;
	case NAxis::axis_270:
		nTempPosX = 65535 - int(65535 * double(ptPoint.y) / double(rectField.Height()));
		nTempPosY = 65535 - int(65535 * double(ptPoint.x) / double(rectField.Width()));
		break;
	case NAxis::axis_left_0:
		nTempPosX = 65535 - int(65535 * double(ptPoint.y) / double(rectField.Height()));
		nTempPosY = int(65535 * double(ptPoint.x) / double(rectField.Width()));
		break;
	case NAxis::axis_left_90:
		nTempPosX = int(65535 * double(ptPoint.x) / double(rectField.Width()));
		nTempPosY = int(65535 * double(ptPoint.y) / double(rectField.Height()));
		break;
	case NAxis::axis_left_180:
		nTempPosX = int(65535 * double(ptPoint.y) / double(rectField.Height()));
		nTempPosY = 65535 - int(65535 * double(ptPoint.x) / double(rectField.Width()));
		break;
	case NAxis::axis_left_270:
		nTempPosX = 65535 - int(65535 * double(ptPoint.x) / double(rectField.Width()));
		nTempPosY = 65535 - int(65535 * double(ptPoint.y) / double(rectField.Height()));
		break;
	}

	if(nTempPosX < 0 || nTempPosX > 65535)
	{
		CDlgInformationBox dlgInformationBox;

		dlgInformationBox.SetTitleContent(
			"ERROR",
			"Overflow in scanner position."
			);

		dlgInformationBox.DoModal();

		return;
	}

	if(nTempPosY < 0 || nTempPosY > 65535)
	{
		CDlgInformationBox dlgInformationBox;

		dlgInformationBox.SetTitleContent(
			"ERROR",
			"Overflow in scanner position."
			);

		dlgInformationBox.DoModal();

		return;
	}

	m_nPositionX = nTempPosX;
	m_nPositionY = nTempPosY;

	CScrollView::OnLButtonDown(nFlags, point);
}

void CTestThumnailView::setAxis(int nAxis)
{
	m_nAxis = nAxis;
}

void CTestThumnailView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CClientDC dc(this);

	OnPrepareDC(&dc);

	CRect rectClient;
	GetClientRect(rectClient);

	dc.DPtoLP(rectClient);

	CRect rectField;
	rectField.left = rectClient.left + m_nOffsetX;
	rectField.top = rectClient.top + m_nOffsetY;
	rectField.right = rectClient.right - m_nOffsetX;
	rectField.bottom = rectClient.bottom - m_nOffsetY;
	
	dc.SetWindowOrg(-m_nOffsetX, -m_nOffsetY);

	CPoint ptPoint = point;
	dc.DPtoLP(&ptPoint);

	int nTempPosX = 0, nTempPosY = 0;

	switch(m_nAxis)
	{
	case NAxis::axis_0:
		nTempPosX = int(65535 * double(ptPoint.x) / double(rectField.Width()));
		nTempPosY = 65535 - int(65535 * double(ptPoint.y) / double(rectField.Height()));
		break;
	case NAxis::axis_90:
		nTempPosX = int(65535 * double(ptPoint.y) / double(rectField.Height()));
		nTempPosY = int(65535 * double(ptPoint.x) / double(rectField.Width()));
		break;
	case NAxis::axis_180:
		nTempPosX = 65535 - int(65535 * double(ptPoint.x) / double(rectField.Width()));
		nTempPosY = int(65535 * double(ptPoint.y) / double(rectField.Height()));
		break;
	case NAxis::axis_270:
		nTempPosX = 65535 - int(65535 * double(ptPoint.y) / double(rectField.Height()));
		nTempPosY = 65535 - int(65535 * double(ptPoint.x) / double(rectField.Width()));
		break;
	case NAxis::axis_left_0:
		nTempPosX = 65535 - int(65535 * double(ptPoint.y) / double(rectField.Height()));
		nTempPosY = int(65535 * double(ptPoint.x) / double(rectField.Width()));
		break;
	case NAxis::axis_left_90:
		nTempPosX = int(65535 * double(ptPoint.x) / double(rectField.Width()));
		nTempPosY = int(65535 * double(ptPoint.y) / double(rectField.Height()));
		break;
	case NAxis::axis_left_180:
		nTempPosX = int(65535 * double(ptPoint.y) / double(rectField.Height()));
		nTempPosY = 65535 - int(65535 * double(ptPoint.x) / double(rectField.Width()));
		break;
	case NAxis::axis_left_270:
		nTempPosX = 65535 - int(65535 * double(ptPoint.x) / double(rectField.Width()));
		nTempPosY = 65535 - int(65535 * double(ptPoint.y) / double(rectField.Height()));
		break;
	}

	if(nTempPosX < 0 || nTempPosX > 65535)
	{
		CDlgInformationBox dlgInformationBox;

		dlgInformationBox.SetTitleContent(
			"ERROR",
			"Overflow in scanner position."
			);

		dlgInformationBox.DoModal();

		return;
	}

	if(nTempPosY < 0 || nTempPosY > 65535)
	{
		CDlgInformationBox dlgInformationBox;

		dlgInformationBox.SetTitleContent(
			"ERROR",
			"Overflow in scanner position."
			);

		dlgInformationBox.DoModal();

		return;
	}

	m_nPositionX = nTempPosX;
	m_nPositionY = nTempPosY;

	CScrollView::OnRButtonDown(nFlags, point);
}

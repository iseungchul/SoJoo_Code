#if !defined(AFX_DLGVACUUMVIEWER_H__ABBCFE51_6392_4654_9866_0F04D6F4144A__INCLUDED_)
#define AFX_DLGVACUUMVIEWER_H__ABBCFE51_6392_4654_9866_0F04D6F4144A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgVacuumViewer.h : header file
//

#include "..\device\devicemotor.h"
#include "ColorEdit.h"
#include "ColorStatic.h"
#include "UEasyButtonEx.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgVacuumViewer dialog

class CDlgVacuumViewer : public CDialog
{
// Construction
public:
	CDlgVacuumViewer(CWnd* pParent = NULL);   // standard constructor

	DeviceMotor* m_pMotor;
	void SetMotor(DeviceMotor* pMotor) {m_pMotor = pMotor;}

	CFont m_fntStatic;
	CFont m_fntBtn;

	void InitStaticControl();
	void InitBtnControl();
	void DispValue();

	void InitTimer();
	void DestroyTimer();

	BOOL m_bTimer;
	int	 m_nTimerID;

// Dialog Data
	//{{AFX_DATA(CDlgVacuumViewer)
	enum { IDD = IDD_DLG_VACUUM_VIEWER };
	CColorStatic m_stcVacuumA1;
	CColorStatic m_stcVacuumB1;
	CColorStatic m_stcVacuumC1;
	CColorStatic m_stcVacuumD1;
	CColorStatic m_stcVacuumA2;
	CColorStatic m_stcVacuumB2;
	CColorStatic m_stcVacuumC2;
	CColorStatic m_stcVacuumD2;
	UEasyButtonEx m_btnClose;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgVacuumViewer)
	public:
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgVacuumViewer)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGVACUUMVIEWER_H__ABBCFE51_6392_4654_9866_0F04D6F4144A__INCLUDED_)

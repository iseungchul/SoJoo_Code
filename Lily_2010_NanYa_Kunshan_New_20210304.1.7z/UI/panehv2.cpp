// panehv2.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "panehv2.h"
#include "..\model\DSystemINI.h"
#include "..\EasyDrillerDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneHV2

IMPLEMENT_DYNCREATE(CPaneHV2, CFormView)

CPaneHV2::CPaneHV2()
	: CFormView(CPaneHV2::IDD)
{
	//{{AFX_DATA_INIT(CPaneHV2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneHV2::~CPaneHV2()
{
}

void CPaneHV2::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneHV2)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneHV2, CFormView)
	//{{AFX_MSG_MAP(CPaneHV2)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneHV2 diagnostics

#ifdef _DEBUG
void CPaneHV2::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneHV2::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneHV2 message handlers

void CPaneHV2::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
#ifdef USE_VISION_PRO
	gVPro.SetDisplayWindow( 2, GetDlgItem(IDC_VISIONPRO_2H) );
#endif
}

BEGIN_EVENTSINK_MAP(CPaneHV2, CFormView)
    //{{AFX_EVENTSINK_MAP(CPaneHV2)
	ON_EVENT(CPaneHV2, IDC_VISIONPRO_2H, 5208 /* DblClick */, OnDblClickVisionpro2h, VTS_NONE)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CPaneHV2::OnDblClickVisionpro2h() 
{
	// TODO: Add your control notification handler code here
/*	if(gSystemINI.m_sHardWare.bUseWideMonitor)
	{
		BOOL bIsSize = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetSideStatus();
		if(bIsSize)
			::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);
		else
			::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, TRUE);
		
		
	}
*/
}

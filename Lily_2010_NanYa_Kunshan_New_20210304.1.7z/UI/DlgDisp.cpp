// DlgDisp.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgDisp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgDisp dialog


CDlgDisp::CDlgDisp(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgDisp::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgDisp)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_bFlag		= FALSE;
}


void CDlgDisp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgDisp)
	DDX_Control(pDX, IDC_STATIC_DISP, m_stcDisp);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgDisp, CDialog)
	//{{AFX_MSG_MAP(CDlgDisp)
	ON_WM_TIMER()
	ON_WM_NCHITTEST()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgDisp message handlers

void CDlgDisp::OnOK() 
{

}

void CDlgDisp::OnCancel() 
{

}

BOOL CDlgDisp::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	Init_Control();
	
//	m_nTimerID = SetTimer(101, 1000, NULL);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgDisp::Init_Control()
{
	m_fntStatic.CreatePointFont(270, "Arial Bold");
	m_stcDisp.SetForeColor(RGB(255,0,0));
	m_stcDisp.SetBackColor(RGB(0,0,0));
}

void CDlgDisp::ShowDlg(BOOL bFlag, CString strMsg)
{
	m_stcDisp.SetWindowText( strMsg );

	if( TRUE == bFlag )
	{
		m_nTimerID = SetTimer(101, 1000, NULL);
		this->ShowWindow(SW_SHOW);
	}
	else
	{
		KillTimer(m_nTimerID);
		this->ShowWindow(SW_HIDE);
	}
}

void CDlgDisp::SetDispMsg(CString strMsg)
{
	m_stcDisp.SetWindowText( strMsg );
}

CString CDlgDisp::GetDispMsg()
{
	CString strMsg;

	m_stcDisp.GetWindowText( strMsg );

	return strMsg;
}

BOOL CDlgDisp::Create(CWnd* pParentWnd) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::Create(IDD, pParentWnd);
}

void CDlgDisp::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if( this->IsWindowVisible() )
	{
		DispMsg(m_bFlag);
		m_bFlag = !m_bFlag;
	}

	CDialog::OnTimer(nIDEvent);
}

void CDlgDisp::DispMsg(BOOL bFlag)
{
	if( FALSE == bFlag )
	{
		m_stcDisp.SetForeColor(RGB(255,0,0));
		m_stcDisp.SetBackColor(RGB(0,0,0));
	}
	else
	{
		m_stcDisp.SetForeColor(RGB(0,0,0));
		m_stcDisp.SetBackColor(RGB(255,0,0));
	}
	Invalidate();
}


LRESULT CDlgDisp::OnNcHitTest(CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	UINT nHitTest = CDialog::OnNcHitTest(point);
	return (nHitTest == HTCLIENT) ? HTCAPTION : nHitTest;
//	return CDialog::OnNcHitTest(point);
}

#if !defined(AFX_PANESYSSETUPMGC_H__066C01C0_BFAE_45F3_91B7_D2B1729AAE2A__INCLUDED_)
#define AFX_PANESYSSETUPMGC_H__066C01C0_BFAE_45F3_91B7_D2B1729AAE2A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupMGC.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupMGC form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"

class CPaneSysSetupMGC : public CFormView
{
protected:
	CPaneSysSetupMGC();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupMGC)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupMGC)
	enum { IDD = IDD_DLG_SYS_SETUP_MGC };
	UEasyButtonEx	m_btnApply;
	UEasyButtonEx	m_btnSelectAll;
	UEasyButtonEx	m_btnDeselectAll;
	UEasyButtonEx	m_btnReverse;
	UEasyButtonEx	m_btnReset;
	UEasyButtonEx	m_btnChangeField;
	UEasyButtonEx	m_btnChangeAxis;
	//}}AFX_DATA

// Attributes
public:
	double	m_dDeltaX;
	double	m_dDeltaY;
	int		m_nGrid;

	CFont m_dlgFont;
	CFont m_editFont;
	CFont m_fontBtn;
	CFont m_fntStatic;

	int m_nTestMarkUnit;
	int m_nTestMarkDraw;
	int m_nTestMarkTestType;
	int m_nTestMarkHead;
	int m_nBackupFileNumber;
	int m_nAxis;	
	int m_nNumberOfTempFile;	
	double m_dFieldSizeX;
	double m_dFieldSizeY;
	BOOL m_bEnableZoomAll;
	BOOL m_bEnableZoomOut;
	BOOL m_bEnableZoomIn;
	BOOL m_bEnableCalView;
	BOOL m_bEnableUndo;
	BOOL m_bEnableRedo;
	BOOL m_bInitDSPEoCard;
	CString m_strAscTempFileDirectory;	
	CString m_strAscTempFileNameHead;
	CString m_strAscTempFileName;
	CString m_strAscFilePath;
	CString m_strAscDirectory;
	CString m_strAppTitle;
	CToolBar m_MainToolBar;	

// Operations
public:
	void EnableZoomAll(BOOL bEnableZoomAll);
	void EnableZoomOut(BOOL bEnableZoomOut);
	void EnableZoomIn(BOOL bEnableZoomIn);
	void EnableCalView(BOOL bEnableCalView);
	void ApplyDelta();
	void SetButtonFont();
	void SetDlgFont();
	void ChangeAxis();
	void BackupAscFile();
	bool IsDirectory(const CString &strFilePath);
	bool IsFileExist(const CString &strFileName);
	bool IsTempFileDirectoryExist();
	void InitToolBar();
	void EnableUndoRedoButton();
	int saveDataBeforeChangeSetting();
	void DeleteAscTempFiles();
	void CheckAscTempFileDirectory();
	void InitTempFileName();
	void FindPrevTempFile();
	void FindNextTempFile();
	void ChangeField();
	void ChangeGrid();

	void EnableControl(BOOL bUse);
	void SetAuthorityByLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupMGC)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupMGC();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupMGC)
	afx_msg void OnPaint();
	afx_msg void OnSelchangeCmbGrid();
	afx_msg void OnBtnSelectAll();
	afx_msg void OnBtnUnselectAll();
	afx_msg void OnBtnInvert();
	afx_msg void OnBtnReset();
	afx_msg void OnBtnApply();
	afx_msg void OnDestroy();
	afx_msg void OnBtnChangeAxis();
	afx_msg void OnBtnChangeField();
	afx_msg void OnZoomIn();
	afx_msg void OnZoomOut();
	afx_msg void OnZoomAll();
	afx_msg void OnCalibration();
	afx_msg void OnUndo();
	afx_msg void OnFileOpen();
	afx_msg void OnFileSave();
	afx_msg void OnFileSaveAs();
	afx_msg void OnRedo();
	afx_msg void OnUpdateRedo(CCmdUI* pCmdUI);
	afx_msg void OnUpdateUndo(CCmdUI* pCmdUI);
	afx_msg void OnUpdateZoomIn(CCmdUI* pCmdUI);
	afx_msg void OnUpdateZoomOut(CCmdUI* pCmdUI);
	afx_msg void OnUpdateZoomAll(CCmdUI* pCmdUI);
	afx_msg void OnUpdateCalibration(CCmdUI* pCmdUI);
	afx_msg BOOL OnToolTipText(UINT id, NMHDR *pTTStruct, LRESULT *pResult);
	afx_msg LRESULT OnKickIdle(WPARAM wParam, LPARAM lParam);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPMGC_H__066C01C0_BFAE_45F3_91B7_D2B1729AAE2A__INCLUDED_)

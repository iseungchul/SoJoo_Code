// PaneSysSetupVacuum.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetupVacuum.h"

#include "..\model\DSystemINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupVacuum

IMPLEMENT_DYNCREATE(CPaneSysSetupVacuum, CFormView)

CPaneSysSetupVacuum::CPaneSysSetupVacuum()
	: CFormView(CPaneSysSetupVacuum::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupVacuum)
	memset( &m_sSystemVacuum, 0, sizeof(m_sSystemVacuum) );
	//}}AFX_DATA_INIT
}

CPaneSysSetupVacuum::~CPaneSysSetupVacuum()
{
}	

void CPaneSysSetupVacuum::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupVacuum)
	DDX_Control(pDX, IDC_EDIT_VACUUM_A_1ST, m_edtVacuumA1);
	DDX_Control(pDX, IDC_EDIT_VACUUM_B_1ST, m_edtVacuumB1);
	DDX_Control(pDX, IDC_EDIT_VACUUM_C_1ST, m_edtVacuumC1);
	DDX_Control(pDX, IDC_EDIT_VACUUM_D_1ST, m_edtVacuumD1);
	DDX_Control(pDX, IDC_EDIT_VACUUM_A_2ND, m_edtVacuumA2);
	DDX_Control(pDX, IDC_EDIT_VACUUM_B_2ND, m_edtVacuumB2);
	DDX_Control(pDX, IDC_EDIT_VACUUM_C_2ND, m_edtVacuumC2);
	DDX_Control(pDX, IDC_EDIT_VACUUM_D_2ND, m_edtVacuumD2);
	DDX_Control(pDX, IDC_EDIT_VACUUM_OFFSET, m_edtVacuumOffset);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupVacuum, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupVacuum)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupVacuum diagnostics

#ifdef _DEBUG
void CPaneSysSetupVacuum::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupVacuum::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupVacuum message handlers
void CPaneSysSetupVacuum::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitEditControl();

	DispValue();
}

BOOL CPaneSysSetupVacuum::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneSysSetupVacuum::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130,_T("Arial Bold"));

	GetDlgItem(IDC_STATIC_TABLE_VACUUM_LIMIT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TABLE_1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TABLE_2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VACUUM_A)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VACUUM_B)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VACUUM_C)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VACUUM_D)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TABLE_VACUUM_OFFSET)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VACUUM_OFFSET)->SetFont( &m_fntStatic );
}

void CPaneSysSetupVacuum::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150,_T("Arial Bold"));

	m_edtVacuumA1.SetFont( &m_fntEdit );
	m_edtVacuumA1.SetForeColor( BLACK_COLOR );
	m_edtVacuumA1.SetBackColor( WHITE_COLOR );
	m_edtVacuumA1.SetReceivedFlag( 1 );
	m_edtVacuumA1.SetWindowText( _T("50") );

	m_edtVacuumB1.SetFont( &m_fntEdit );
	m_edtVacuumB1.SetForeColor( BLACK_COLOR );
	m_edtVacuumB1.SetBackColor( WHITE_COLOR );
	m_edtVacuumB1.SetReceivedFlag( 1 );
	m_edtVacuumB1.SetWindowText( _T("50") );

	m_edtVacuumC1.SetFont( &m_fntEdit );
	m_edtVacuumC1.SetForeColor( BLACK_COLOR );
	m_edtVacuumC1.SetBackColor( WHITE_COLOR );
	m_edtVacuumC1.SetReceivedFlag( 1 );
	m_edtVacuumC1.SetWindowText( _T("50") );

	m_edtVacuumD1.SetFont( &m_fntEdit );
	m_edtVacuumD1.SetForeColor( BLACK_COLOR );
	m_edtVacuumD1.SetBackColor( WHITE_COLOR );
	m_edtVacuumD1.SetReceivedFlag( 1 );
	m_edtVacuumD1.SetWindowText( _T("50") );

	m_edtVacuumA2.SetFont( &m_fntEdit );
	m_edtVacuumA2.SetForeColor( BLACK_COLOR );
	m_edtVacuumA2.SetBackColor( WHITE_COLOR );
	m_edtVacuumA2.SetReceivedFlag( 1 );
	m_edtVacuumA2.SetWindowText( _T("50") );
	
	m_edtVacuumB2.SetFont( &m_fntEdit );
	m_edtVacuumB2.SetForeColor( BLACK_COLOR );
	m_edtVacuumB2.SetBackColor( WHITE_COLOR );
	m_edtVacuumB2.SetReceivedFlag( 1 );
	m_edtVacuumB2.SetWindowText( _T("50") );
	
	m_edtVacuumC2.SetFont( &m_fntEdit );
	m_edtVacuumC2.SetForeColor( BLACK_COLOR );
	m_edtVacuumC2.SetBackColor( WHITE_COLOR );
	m_edtVacuumC2.SetReceivedFlag( 1 );
	m_edtVacuumC2.SetWindowText( _T("50") );
	
	m_edtVacuumD2.SetFont( &m_fntEdit );
	m_edtVacuumD2.SetForeColor( BLACK_COLOR );
	m_edtVacuumD2.SetBackColor( WHITE_COLOR );
	m_edtVacuumD2.SetReceivedFlag( 1 );
	m_edtVacuumD2.SetWindowText( _T("50") );

	m_edtVacuumOffset.SetFont( &m_fntEdit );
	m_edtVacuumOffset.SetForeColor( BLACK_COLOR );
	m_edtVacuumOffset.SetBackColor( WHITE_COLOR );
	m_edtVacuumOffset.SetReceivedFlag( 1 );
	m_edtVacuumOffset.SetWindowText( _T("50") );
}

HBRUSH CPaneSysSetupVacuum::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_TABLE_VACUUM_LIMIT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TABLE_VACUUM_OFFSET)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneSysSetupVacuum::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntEdit.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneSysSetupVacuum::SetSystemVacuum(SSYSTEMVACUUM sSystemVacuum)
{
	memcpy( &m_sSystemVacuum, &sSystemVacuum, sizeof(m_sSystemVacuum) );

	DispValue();
}

void CPaneSysSetupVacuum::GetSystemVacuum(SSYSTEMVACUUM* pSystemVacuum)
{
	memcpy( pSystemVacuum, &m_sSystemVacuum, sizeof(m_sSystemVacuum) );
}

void CPaneSysSetupVacuum::OnApply()
{
	CString strData;

	m_edtVacuumA1.GetWindowText( strData );
	m_sSystemVacuum.dTable1Vacuum[VACUUM_A] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtVacuumB1.GetWindowText( strData );
	m_sSystemVacuum.dTable1Vacuum[VACUUM_B] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtVacuumC1.GetWindowText( strData );
	m_sSystemVacuum.dTable1Vacuum[VACUUM_C] = atof( (LPSTR)(LPCTSTR)strData );

	m_edtVacuumD1.GetWindowText( strData );
	m_sSystemVacuum.dTable1Vacuum[VACUUM_D] = atof( (LPSTR)(LPCTSTR)strData );


	m_edtVacuumA2.GetWindowText( strData );
	m_sSystemVacuum.dTable2Vacuum[VACUUM_A] = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtVacuumB2.GetWindowText( strData );
	m_sSystemVacuum.dTable2Vacuum[VACUUM_B] = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtVacuumC2.GetWindowText( strData );
	m_sSystemVacuum.dTable2Vacuum[VACUUM_C] = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtVacuumD2.GetWindowText( strData );
	m_sSystemVacuum.dTable2Vacuum[VACUUM_D] = atof( (LPSTR)(LPCTSTR)strData );


	m_edtVacuumOffset.GetWindowText( strData );
	m_sSystemVacuum.dVacuumOffset = atof( (LPSTR)(LPCTSTR)strData );
}

CString CPaneSysSetupVacuum::GetChangeValueStr()
{
	CString strMessage, strTemp, strId1, strId2;
	strMessage.Format(_T(""));

	int nBase = VACUUM_A;
	for(int i=0; i<4; i++)
	{
		if(m_sSystemVacuum.dTable1Vacuum[nBase+i] != gSystemINI.m_sSystemVacuum.dTable1Vacuum[nBase+i])
		{
			strTemp.Format(_T("| 1st VACUUM #%d : %d "), i+1, m_sSystemVacuum.dTable1Vacuum[nBase+i]);
			strMessage += strTemp;
		}
	}

	for(int i = 0; i<4; i++)
	{
		if(m_sSystemVacuum.dTable2Vacuum[nBase+i] != gSystemINI.m_sSystemVacuum.dTable2Vacuum[nBase+i])
		{
			strTemp.Format(_T("| 2nd VACUUM #%d : %d "), i+1, m_sSystemVacuum.dTable2Vacuum[nBase+i]);
			strMessage += strTemp;
		}
	}

	return strMessage;
}

void CPaneSysSetupVacuum::DispValue()
{
	CString strData;
	
	strData.Format(_T("%.2f"), m_sSystemVacuum.dTable1Vacuum[VACUUM_A]);
	m_edtVacuumA1.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemVacuum.dTable1Vacuum[VACUUM_B]);
	m_edtVacuumB1.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemVacuum.dTable1Vacuum[VACUUM_C]);
	m_edtVacuumC1.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sSystemVacuum.dTable1Vacuum[VACUUM_D]);
	m_edtVacuumD1.SetWindowText( (LPCTSTR)strData );


	strData.Format(_T("%.2f"), m_sSystemVacuum.dTable2Vacuum[VACUUM_A]);
	m_edtVacuumA2.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.2f"), m_sSystemVacuum.dTable2Vacuum[VACUUM_B]);
	m_edtVacuumB2.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.2f"), m_sSystemVacuum.dTable2Vacuum[VACUUM_C]);
	m_edtVacuumC2.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.2f"), m_sSystemVacuum.dTable2Vacuum[VACUUM_D]);
	m_edtVacuumD2.SetWindowText( (LPCTSTR)strData );


	strData.Format(_T("%.2f"), m_sSystemVacuum.dVacuumOffset);
	m_edtVacuumOffset.SetWindowText( (LPCTSTR)strData );
}

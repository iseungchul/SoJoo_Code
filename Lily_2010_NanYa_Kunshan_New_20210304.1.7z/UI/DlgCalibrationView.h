#if !defined(AFX_DLGCALIBRATIONVIEW_H__3D5DD3DC_3032_439D_9605_520DFD7739F0__INCLUDED_)
#define AFX_DLGCALIBRATIONVIEW_H__3D5DD3DC_3032_439D_9605_520DFD7739F0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgCalibrationView.h : header file
//

#include "MGCView.h"

const int Hole_Num	= 65;

/////////////////////////////////////////////////////////////////////////////
// CDlgCalibrationView dialog

class CDlgCalibrationView : public CDialog
{
// Construction
public:
	CDlgCalibrationView(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgCalibrationView)
	enum { IDD = IDD_CALIBRATION_VIEW };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	CMGCView* m_pMGCView;
	int m_nAxis;
	double m_dFieldSizeX;
	double m_dFieldSizeY;
	int m_nXMax;
	int m_nXMin;
	int m_nYMax;
	int m_nYMin;
	int m_nDistanceMax;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgCalibrationView)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgCalibrationView)
	virtual void OnCancel();
	afx_msg void OnPaint();
	virtual BOOL OnInitDialog();
	afx_msg void OnLayOut();
	afx_msg void OnXDeviation();
	afx_msg void OnYDeviation();
	afx_msg void OnDisDeviation();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void DrawColorRef(CDC * pDC);
	int ExtractColorIndex(int value, int Max, int Min);
	void SetColorBand();
	void DrawXDevGrid(CDC *pDC);
	void DrawYDevGrid(CDC *pDC);
	void DrawDistanceGrid(CDC *pDC);
	void CalcuLeastSquare();
	void DrawBasisRect(CDC *pDC);
	void CalcuBeforeCal();
	void DrawCalibration(CDC *pDC);
	void SetDlgFont();
	
	CFont m_btnFont;
	CRect m_canvasRect;
	double m_nXBottomData[Hole_Num];
	double m_nYBottomData[Hole_Num];
	double m_nXTopData[Hole_Num];
	double m_nYTopData[Hole_Num];
	double m_nXLeftData[Hole_Num];
	double m_nYLeftData[Hole_Num];
	double m_nXRightData[Hole_Num];
	double m_nYRightData[Hole_Num];
	double m_dXAxisSlope;
	double m_dYAxisSlope;
	double m_dXIntercept;
	double m_dYIntercept;
	double m_dYAxisXVaule;
	double m_dXAxisYVaule;
	double m_dXIntersection;
	double m_dYIntersection;
	bool m_bIsparallelYAxis;
	bool m_bIsparallelXAxis;
	CPoint m_ptXAxis_1;
	CPoint m_ptXAxis_2;
	CPoint m_ptYAxis_1;
	CPoint m_ptYAxis_2;
	int m_nSelect;
	COLORREF m_colorBand[1024];
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCALIBRATIONVIEW_H__3D5DD3DC_3032_439D_9605_520DFD7739F0__INCLUDED_)

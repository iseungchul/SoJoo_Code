// PaneManualControlIOMonitorInputSub1Pusan1.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlIOMonitorInputSub1Pusan1.h"
#include "..\device\HDeviceFactory.h"
#include "..\Model\DSystemINI.h"
#include "..\Model\DEasyDrillerINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub1Pusan1

IMPLEMENT_DYNCREATE(CPaneManualControlIOMonitorInputSub1Pusan1, CFormView)

CPaneManualControlIOMonitorInputSub1Pusan1::CPaneManualControlIOMonitorInputSub1Pusan1()
	: CFormView(CPaneManualControlIOMonitorInputSub1Pusan1::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlIOMonitorInputSub1Pusan1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nTimerID = 0;
	m_lStatus1 = m_lStatus1Old = 0;
	m_lStatus2 = m_lStatus2Old = 0;
	m_lStatus3 = m_lStatus3old = 0;
	m_lStatus4 = m_lstatus4Old = 0;
	m_lStatus7 = m_lstatus7Old = 0;
	m_lTableLimit = m_lTableLimitOld = 0;
	m_lTableError = m_lTableErrorOld = 0;
}

CPaneManualControlIOMonitorInputSub1Pusan1::~CPaneManualControlIOMonitorInputSub1Pusan1()
{
}

void CPaneManualControlIOMonitorInputSub1Pusan1::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlIOMonitorInputSub1Pusan1)
	DDX_Control(pDX, IDC_CHECK_MAIN_MOTOR_READY, m_ledMainMotorReady);
	DDX_Control(pDX, IDC_CHECK_PLC_ALIVE_PULSE, m_ledPLCalivePulse);
	DDX_Control(pDX, IDC_CHECK_MACHINE_RUNNING, m_ledMachineRun);
	DDX_Control(pDX, IDC_CHECK_SAFETY_MODE, m_ledSafetyMode);
	DDX_Control(pDX, IDC_CHECK_DOOR_INTERLOCK_BYPASS, m_ledDoorByPass);
	DDX_Control(pDX, IDC_CHECK_LEFT_TABEL_PCB_EXIST, m_ledTable1PCB);
	DDX_Control(pDX, IDC_CHECK_LIGHT_CURTAIN_ON, m_ledLightCurtainOn);


	DDX_Control(pDX, IDC_CHECK_RIGHT_TABLE_PCB_EXIST, m_ledTable2PCB);
	DDX_Control(pDX, IDC_CHECK_MAIN_STATION_INITIAL_COMPLETE, m_ledMainInitComplete);
	DDX_Control(pDX, IDC_CHECK_MAIN_STATION_ALARM, m_ledMainAlarm);
	DDX_Control(pDX, IDC_CHECK_MAIN_STATION_INITIALIZING, m_ledMainInitializing);
	DDX_Control(pDX, IDC_CHECK_X_INITIAL_COMPLETE, m_ledXInitComplete);
	DDX_Control(pDX, IDC_CHECK_X_INITIALIZING, m_ledXInitializing);
	DDX_Control(pDX, IDC_CHECK_X_INPOSITION, m_ledXInposition);
	DDX_Control(pDX, IDC_CHECK_X_MOTION_RUN, m_ledXRun);
	DDX_Control(pDX, IDC_CHECK_Y_INITIAL_COMPLETE, m_ledYInitComplete);
	DDX_Control(pDX, IDC_CHECK_Y_INITIALIZING, m_ledYInitializing);
	DDX_Control(pDX, IDC_CHECK_Y_INPOSITION, m_ledYInposition);
	DDX_Control(pDX, IDC_CHECK_Y_MOTION_RUN, m_ledYRun);
	DDX_Control(pDX, IDC_CHECK_Z1_INITIAL_COMPLETE, m_ledZ1InitComplete);
	DDX_Control(pDX, IDC_CHECK_Z1_INITIALIZING, m_ledZ1Initializing);
	DDX_Control(pDX, IDC_CHECK_Z1_INPOSITION, m_ledZ1Inposition);
	DDX_Control(pDX, IDC_CHECK_Z1_MOTION_RUN, m_ledZ1Run);
	DDX_Control(pDX, IDC_CHECK_Z2_INITIAL_COMPLETE, m_ledZ2InitComplete);
	DDX_Control(pDX, IDC_CHECK_Z2_INITIALIZING, m_ledZ2Initializing);
	DDX_Control(pDX, IDC_CHECK_Z2_INPOSITION, m_ledZ2Inposition);
	DDX_Control(pDX, IDC_CHECK_Z2_MOTION_RUN, m_ledZ2Run);
	DDX_Control(pDX, IDC_CHECK_M_INITIAL_COMPLETE, m_ledMInitComplete);
	DDX_Control(pDX, IDC_CHECK_M_INITIALIZING, m_ledMInitializing);
	DDX_Control(pDX, IDC_CHECK_M_INPOSITION, m_ledMInposition);
	DDX_Control(pDX, IDC_CHECK_M_MOTION_RUN, m_ledMRun);
	DDX_Control(pDX, IDC_CHECK_M_INITIAL_COMPLETE2, m_ledM2InitComplete);
	DDX_Control(pDX, IDC_CHECK_M_INITIALIZING2, m_ledM2Initializing);
	DDX_Control(pDX, IDC_CHECK_M_INPOSITION2, m_ledM2Inposition);
	DDX_Control(pDX, IDC_CHECK_M_MOTION_RUN2, m_ledM2Run);
	DDX_Control(pDX, IDC_CHECK_C_INITIAL_COMPLETE, m_ledCInitComplete);
	DDX_Control(pDX, IDC_CHECK_C_INITIALIZING, m_ledCInitializing);
	DDX_Control(pDX, IDC_CHECK_C_INPOSITION, m_ledCInposition);
	DDX_Control(pDX, IDC_CHECK_C_MOTION_RUN, m_ledCRun);
	DDX_Control(pDX, IDC_CHECK_C2_INITIAL_COMPLETE, m_ledC2InitComplete);
	DDX_Control(pDX, IDC_CHECK_C2_INITIALIZING, m_ledC2Initializing);
	DDX_Control(pDX, IDC_CHECK_C2_INPOSITION, m_ledC2Inposition);
	DDX_Control(pDX, IDC_CHECK_C2_MOTION_RUN, m_ledC2Run);
	DDX_Control(pDX, IDC_CHECK_MASTER_SHUTTER_EXTEND, m_ledMasterShtExt);
	DDX_Control(pDX, IDC_CHECK_MASTER_SHUTTER_RETRACT, m_ledMasterShtRet);
	DDX_Control(pDX, IDC_CHECK_SLAVE_SHUTTER_EXTEND, m_ledSlaveShtExt);
	DDX_Control(pDX, IDC_CHECK_SLAVE_SHUTTER_RETRACT, m_ledSlaveShtRet);
	DDX_Control(pDX, IDC_CHECK_HEIGHT_SENSOR_UP, m_ledHeightSensorUp);
	DDX_Control(pDX, IDC_CHECK_HEIGHT_SENSOR_DOWN, m_ledHeightSensorDown);
	DDX_Control(pDX, IDC_CHECK_HEIGHT_SENSOR_UP2, m_ledHeightSensorUp2);
	DDX_Control(pDX, IDC_CHECK_HEIGHT_SENSOR_DOWN2, m_ledHeightSensorDown2);
	DDX_Control(pDX, IDC_CHECK_POWER_DETECTOR_FORWARD, m_ledPowerDetectorFwd);
	DDX_Control(pDX, IDC_CHECK_POWER_DETECTOR_BACKWARD, m_ledPowerDetectorBwd);
	DDX_Control(pDX, IDC_CHECK_VACUUM_MOTOR, m_ledVacuumMotorOn);
	DDX_Control(pDX, IDC_CHECK_TABLE_CLAMP1, m_ledTableClamp1);
	DDX_Control(pDX, IDC_CHECK_TABLE_UNCLAMP1, m_ledTableUnclamp1);
	DDX_Control(pDX, IDC_CHECK_TABLE_CLAMP2, m_ledTableClamp2);
	DDX_Control(pDX, IDC_CHECK_TABLE_UNCLAMP2, m_ledTableUnclamp2);
	DDX_Control(pDX, IDC_CHECK_SYSTEM_AIR, m_ledSystemAir);
	DDX_Control(pDX, IDC_CHECK_LOADING_SHUTTER_OPEN, m_ledLoadingShutterOpen);
	DDX_Control(pDX, IDC_CHECK_FRONT_DOOR_OPEN, m_ledFrontDoor);
	DDX_Control(pDX, IDC_CHECK_LEFT_DOOR_OPEN, m_ledLeftDoor);
	DDX_Control(pDX, IDC_CHECK_REAR1_DOOR_OPEN, m_ledRear1Door);
	DDX_Control(pDX, IDC_CHECK_REAR2_DOOR_OPEN, m_ledRear2Door);
	DDX_Control(pDX, IDC_CHECK_RIGHT_DOOR_OPEN, m_ledRightDoor);
	DDX_Control(pDX, IDC_CHECK_START_SW, m_ledStartSW);
	DDX_Control(pDX, IDC_CHECK_STOP_SW, m_ledStopSW);
	DDX_Control(pDX, IDC_CHECK_RESET_SW, m_ledResetSW);
	DDX_Control(pDX, IDC_CHECK_BRUSH_UP, m_ledBrushUp);
	DDX_Control(pDX, IDC_CHECK_BRUSH_DOWN, m_ledBrushDown);
	DDX_Control(pDX, IDC_CHECK_LASER_BEAM_PASS_UP, m_ledLaserBeamPassUp);
	DDX_Control(pDX, IDC_CHECK_LASER_BEAM_PASS_DOWN, m_ledLaserBeamPassDown);

	DDX_Control(pDX, IDC_CHECK_LASER_BEAM_PASS_UP2, m_ledLaserBeamPassFwd);
	DDX_Control(pDX, IDC_CHECK_LASER_BEAM_PASS_DOWN2, m_ledLaserBeamPassBwd);
	DDX_Control(pDX, IDC_CHECK_AOM_POWER, m_ledAomPower);
	DDX_Control(pDX, IDC_CHECK_SUCTION_OPEN1, m_ledSuctionHood1Open);
	DDX_Control(pDX, IDC_CHECK_SUCTION_CLOSE1, m_ledSuctionHood1Close);
	DDX_Control(pDX, IDC_CHECK_SUCTION_OPEN2, m_ledSuctionHood2Open);
	DDX_Control(pDX, IDC_CHECK_SUCTION_CLOSE2, m_ledSuctionHood2Close);

	DDX_Control(pDX, IDC_CHECK_A_INITIAL_COMPLETE, m_ledA1InitComplete);
	DDX_Control(pDX, IDC_CHECK_A_INITIALIZING, m_ledA1Initializing);
	DDX_Control(pDX, IDC_CHECK_A_INPOSITION, m_ledA1Inposition);
	DDX_Control(pDX, IDC_CHECK_A_MOTION_RUN, m_ledA1Run);
	DDX_Control(pDX, IDC_CHECK_A_INITIAL_COMPLETE2, m_ledA2InitComplete);
	DDX_Control(pDX, IDC_CHECK_A_INITIALIZING2, m_ledA2Initializing);
	DDX_Control(pDX, IDC_CHECK_A_INPOSITION2, m_ledA2Inposition);
	DDX_Control(pDX, IDC_CHECK_A_MOTION_RUN2, m_ledA2Run);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlIOMonitorInputSub1Pusan1, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlIOMonitorInputSub1Pusan1)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub1Pusan1 diagnostics

#ifdef _DEBUG
void CPaneManualControlIOMonitorInputSub1Pusan1::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlIOMonitorInputSub1Pusan1::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub1Pusan1 message handlers

void CPaneManualControlIOMonitorInputSub1Pusan1::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	
	if(gSystemINI.m_sHardWare.nTableClamp == 0)
	{
		m_ledTableClamp1.ShowWindow(SW_HIDE);
		m_ledTableUnclamp1.ShowWindow(SW_HIDE);
		m_ledTableClamp2.ShowWindow(SW_HIDE);
		m_ledTableUnclamp2.ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nTableClamp == 1)
	{
		m_ledTableClamp1.ShowWindow(SW_SHOW);
		m_ledTableUnclamp1.ShowWindow(SW_SHOW);
		m_ledTableClamp2.ShowWindow(SW_HIDE);
		m_ledTableUnclamp2.ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nTableClamp == 2)
	{
		m_ledTableClamp1.ShowWindow(SW_SHOW);
		m_ledTableUnclamp1.ShowWindow(SW_SHOW);
		m_ledTableClamp2.ShowWindow(SW_SHOW);
		m_ledTableUnclamp2.ShowWindow(SW_SHOW);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		m_ledZ2InitComplete.ShowWindow(SW_HIDE);
		m_ledZ2Initializing.ShowWindow(SW_HIDE);
		m_ledZ2Inposition.ShowWindow(SW_HIDE);
		m_ledZ2Run.ShowWindow(SW_HIDE);
		m_ledSlaveShtExt.ShowWindow(SW_HIDE);
		m_ledSlaveShtRet.ShowWindow(SW_HIDE);
	}
	
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0)
	{
		m_ledZ2InitComplete.ShowWindow(SW_HIDE);
		m_ledZ2Initializing.ShowWindow(SW_HIDE);
		m_ledZ2Inposition.ShowWindow(SW_HIDE);
		m_ledZ2Run.ShowWindow(SW_HIDE);
		
		m_ledMInitComplete.ShowWindow(SW_HIDE);
		m_ledMInitializing.ShowWindow(SW_HIDE);
		m_ledMInposition.ShowWindow(SW_HIDE);
		m_ledMRun.ShowWindow(SW_HIDE);
		
		m_ledCInitComplete.ShowWindow(SW_HIDE);
		m_ledCInitializing.ShowWindow(SW_HIDE);
		m_ledCInposition.ShowWindow(SW_HIDE);
		m_ledCRun.ShowWindow(SW_HIDE);	

		if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		{
			m_ledZ1InitComplete.ShowWindow(SW_HIDE);
			m_ledZ1Initializing.ShowWindow(SW_HIDE);
			m_ledZ1Inposition.ShowWindow(SW_HIDE);
			m_ledZ1Run.ShowWindow(SW_HIDE);
		}
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 0)
		m_ledTable2PCB.ShowWindow(SW_HIDE);

	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 0)
	{
		m_ledPowerDetectorFwd.ShowWindow(SW_HIDE);
		m_ledPowerDetectorBwd.ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 1)
	{
		m_ledHeightSensorUp.ShowWindow(SW_HIDE);
		m_ledHeightSensorDown.ShowWindow(SW_HIDE);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 2)
	{
//		m_ledHeightSensorUp2.ShowWindow(SW_HIDE);
//		m_ledHeightSensorDown2.ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_COMIZOA)
	{
		m_ledSystemAir.ShowWindow(SW_HIDE);
		m_ledLoadingShutterOpen.ShowWindow(SW_HIDE);
		m_ledFrontDoor.ShowWindow(SW_HIDE);
		m_ledLeftDoor.ShowWindow(SW_HIDE);
		m_ledRear1Door.ShowWindow(SW_HIDE);
		m_ledRear2Door.ShowWindow(SW_HIDE);
		m_ledRightDoor.ShowWindow(SW_HIDE);
		m_ledStartSW.ShowWindow(SW_HIDE);
		m_ledStopSW.ShowWindow(SW_HIDE);
		m_ledResetSW.ShowWindow(SW_HIDE);
		m_ledBrushUp.ShowWindow(SW_HIDE);
		m_ledBrushDown.ShowWindow(SW_HIDE);
	}
	else
	{
		m_ledTableClamp2.SetWindowText("Chuck Clamp");
		m_ledTableClamp2.ShowWindow(SW_SHOW);
		m_ledTableUnclamp2.SetWindowText("Chuck Unclamp");
		m_ledTableUnclamp2.ShowWindow(SW_SHOW);

		m_ledXInitializing.SetWindowText("Axis-X Ready");
		m_ledXInitializing.ShowWindow(SW_SHOW);
		m_ledXInposition.SetWindowText("Axis-X Alarm");
		m_ledXInposition.ShowWindow(SW_SHOW);
		m_ledXRun.SetWindowText("Axis-X Limit");
		m_ledXRun.ShowWindow(SW_SHOW);

		m_ledYInitializing.SetWindowText("Axis-Y Ready");
		m_ledYInitializing.ShowWindow(SW_SHOW);
		m_ledYInposition.SetWindowText("Axis-Y Alarm");
		m_ledYInposition.ShowWindow(SW_SHOW);
		m_ledYRun.SetWindowText("Axis-Y Limit");
		m_ledYRun.ShowWindow(SW_SHOW);

		m_ledMainMotorReady.ShowWindow(SW_HIDE);
		m_ledMachineRun.ShowWindow(SW_HIDE);
		m_ledMainInitComplete.ShowWindow(SW_HIDE);
		m_ledMainInitializing.ShowWindow(SW_HIDE);
		m_ledMainAlarm.ShowWindow(SW_HIDE);
		m_ledDoorByPass.ShowWindow(SW_HIDE);
		m_ledSafetyMode.ShowWindow(SW_HIDE);

		m_ledTable1PCB.SetWindowText("Table PCB Exist");

		m_ledMasterShtExt.ShowWindow(SW_HIDE);
		m_ledMasterShtRet.ShowWindow(SW_HIDE);
		m_ledSlaveShtExt.ShowWindow(SW_HIDE);
		m_ledSlaveShtRet.ShowWindow(SW_HIDE);
		m_ledPLCalivePulse.ShowWindow(SW_HIDE);
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		m_ledMInitComplete.SetWindowText("Axis-T Init.Complete");
		m_ledMInitializing.SetWindowText("Axis-T Initializing");
		m_ledLeftDoor.SetWindowText("Loading Door Open");
	}

}

void CPaneManualControlIOMonitorInputSub1Pusan1::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(95, "Arial Bold");

	m_ledMainMotorReady.SetFont( &m_fntBtn );
	m_ledMainMotorReady.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMainMotorReady.Depress( TRUE );

	m_ledPLCalivePulse.SetFont( &m_fntBtn );
	m_ledPLCalivePulse.SetImage( IDB_LEDCOLOR, 15 );
	m_ledPLCalivePulse.Depress( TRUE );

	m_ledMachineRun.SetFont( &m_fntBtn );
	m_ledMachineRun.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMachineRun.Depress( TRUE );
	
	m_ledSafetyMode.SetFont( &m_fntBtn );
	m_ledSafetyMode.SetImage( IDB_LEDCOLOR, 15 );
	m_ledSafetyMode.Depress( TRUE );
	
	m_ledDoorByPass.SetFont( &m_fntBtn );
	m_ledDoorByPass.SetImage( IDB_LEDCOLOR, 15 );
	m_ledDoorByPass.Depress( TRUE );
	
	m_ledTable1PCB.SetFont( &m_fntBtn );
	m_ledTable1PCB.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTable1PCB.Depress( TRUE );
	
	m_ledLightCurtainOn.SetFont( &m_fntBtn );
	m_ledLightCurtainOn.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLightCurtainOn.Depress( TRUE );


	m_ledTable2PCB.SetFont( &m_fntBtn );
	m_ledTable2PCB.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTable2PCB.Depress( TRUE );
	
	m_ledMainInitComplete.SetFont( &m_fntBtn );
	m_ledMainInitComplete.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMainInitComplete.Depress( TRUE );
	
	m_ledMainAlarm.SetFont( &m_fntBtn );
	m_ledMainAlarm.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMainAlarm.Depress( TRUE );
	
	m_ledMainInitializing.SetFont( &m_fntBtn );
	m_ledMainInitializing.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMainInitializing.Depress( TRUE );
	
	m_ledXInitComplete.SetFont( &m_fntBtn );
	m_ledXInitComplete.SetImage( IDB_LEDCOLOR, 15 );
	m_ledXInitComplete.Depress( TRUE );
	
	m_ledXInitializing.SetFont( &m_fntBtn );
	m_ledXInitializing.SetImage( IDB_LEDCOLOR, 15 );
	m_ledXInitializing.Depress( TRUE );
	
	m_ledXInposition.SetFont( &m_fntBtn );
	m_ledXInposition.SetImage( IDB_LEDCOLOR, 15 );
	m_ledXInposition.Depress( TRUE );
	
	m_ledXRun.SetFont( &m_fntBtn );
	m_ledXRun.SetImage( IDB_LEDCOLOR, 15 );
	m_ledXRun.Depress( TRUE );
	
	m_ledYInitComplete.SetFont( &m_fntBtn );
	m_ledYInitComplete.SetImage( IDB_LEDCOLOR, 15 );
	m_ledYInitComplete.Depress( TRUE );
	
	m_ledYInitializing.SetFont( &m_fntBtn );
	m_ledYInitializing.SetImage( IDB_LEDCOLOR, 15 );
	m_ledYInitializing.Depress( TRUE );
	
	m_ledYInposition.SetFont( &m_fntBtn );
	m_ledYInposition.SetImage( IDB_LEDCOLOR, 15 );
	m_ledYInposition.Depress( TRUE );
	
	m_ledYRun.SetFont( &m_fntBtn );
	m_ledYRun.SetImage( IDB_LEDCOLOR, 15 );
	m_ledYRun.Depress( TRUE );
	
	m_ledZ1InitComplete.SetFont( &m_fntBtn );
	m_ledZ1InitComplete.SetImage( IDB_LEDCOLOR, 15 );
	m_ledZ1InitComplete.Depress( TRUE );
	
	m_ledZ1Initializing.SetFont( &m_fntBtn );
	m_ledZ1Initializing.SetImage( IDB_LEDCOLOR, 15 );
	m_ledZ1Initializing.Depress( TRUE );
	
	m_ledZ1Inposition.SetFont( &m_fntBtn );
	m_ledZ1Inposition.SetImage( IDB_LEDCOLOR, 15 );
	m_ledZ1Inposition.Depress( TRUE );
	
	m_ledZ1Run.SetFont( &m_fntBtn );
	m_ledZ1Run.SetImage( IDB_LEDCOLOR, 15 );
	m_ledZ1Run.Depress( TRUE );
	
	m_ledZ2InitComplete.SetFont( &m_fntBtn );
	m_ledZ2InitComplete.SetImage( IDB_LEDCOLOR, 15 );
	m_ledZ2InitComplete.Depress( TRUE );
	
	m_ledZ2Initializing.SetFont( &m_fntBtn );
	m_ledZ2Initializing.SetImage( IDB_LEDCOLOR, 15 );
	m_ledZ2Initializing.Depress( TRUE );
	
	m_ledZ2Inposition.SetFont( &m_fntBtn );
	m_ledZ2Inposition.SetImage( IDB_LEDCOLOR, 15 );
	m_ledZ2Inposition.Depress( TRUE );
	
	m_ledZ2Run.SetFont( &m_fntBtn );
	m_ledZ2Run.SetImage( IDB_LEDCOLOR, 15 );
	m_ledZ2Run.Depress( TRUE );
	
	m_ledMInitComplete.SetFont( &m_fntBtn );
	m_ledMInitComplete.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMInitComplete.Depress( TRUE );
	
	m_ledMInitializing.SetFont( &m_fntBtn );
	m_ledMInitializing.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMInitializing.Depress( TRUE );
	
	m_ledMInposition.SetFont( &m_fntBtn );
	m_ledMInposition.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMInposition.Depress( TRUE );
	
	m_ledMRun.SetFont( &m_fntBtn );
	m_ledMRun.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMRun.Depress( TRUE );
	
	m_ledM2InitComplete.SetFont( &m_fntBtn );
	m_ledM2InitComplete.SetImage( IDB_LEDCOLOR, 15 );
	m_ledM2InitComplete.Depress( TRUE );
	
	m_ledM2Initializing.SetFont( &m_fntBtn );
	m_ledM2Initializing.SetImage( IDB_LEDCOLOR, 15 );
	m_ledM2Initializing.Depress( TRUE );
	
	m_ledM2Inposition.SetFont( &m_fntBtn );
	m_ledM2Inposition.SetImage( IDB_LEDCOLOR, 15 );
	m_ledM2Inposition.Depress( TRUE );
	
	m_ledM2Run.SetFont( &m_fntBtn );
	m_ledM2Run.SetImage( IDB_LEDCOLOR, 15 );
	m_ledM2Run.Depress( TRUE );

	m_ledCInitComplete.SetFont( &m_fntBtn );
	m_ledCInitComplete.SetImage( IDB_LEDCOLOR, 15 );
	m_ledCInitComplete.Depress( TRUE );
	
	m_ledCInitializing.SetFont( &m_fntBtn );
	m_ledCInitializing.SetImage( IDB_LEDCOLOR, 15 );
	m_ledCInitializing.Depress( TRUE );
	
	m_ledCInposition.SetFont( &m_fntBtn );
	m_ledCInposition.SetImage( IDB_LEDCOLOR, 15 );
	m_ledCInposition.Depress( TRUE );
	
	m_ledCRun.SetFont( &m_fntBtn );
	m_ledCRun.SetImage( IDB_LEDCOLOR, 15 );
	m_ledCRun.Depress( TRUE );

	m_ledC2InitComplete.SetFont( &m_fntBtn );
	m_ledC2InitComplete.SetImage( IDB_LEDCOLOR, 15 );
	m_ledCInitComplete.Depress( TRUE );
	
	m_ledC2Initializing.SetFont( &m_fntBtn );
	m_ledC2Initializing.SetImage( IDB_LEDCOLOR, 15 );
	m_ledC2Initializing.Depress( TRUE );
	
	m_ledC2Inposition.SetFont( &m_fntBtn );
	m_ledC2Inposition.SetImage( IDB_LEDCOLOR, 15 );
	m_ledC2Inposition.Depress( TRUE );
	
	m_ledC2Run.SetFont( &m_fntBtn );
	m_ledC2Run.SetImage( IDB_LEDCOLOR, 15 );
	m_ledC2Run.Depress( TRUE );
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		m_ledMInitComplete.SetWindowText("Axis-A1 Init.Complete");
		m_ledMInitializing.SetWindowText("Axis-A1 Initializing");
		m_ledMInposition.SetWindowText("Axis-A1 InPosition");
		m_ledMRun.SetWindowText("Axis-A1 Motion Run");
		m_ledCInitComplete.SetWindowText("Axis-A2 Init.Complete");
		m_ledCInitializing.SetWindowText("Axis-A2 Initializing");
		m_ledCInposition.SetWindowText("Axis-A2 InPosition");
		m_ledCRun.SetWindowText("Axis-A2 Motion Run");
	}
	
	m_ledMasterShtExt.SetFont( &m_fntBtn );
	m_ledMasterShtExt.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMasterShtExt.Depress( TRUE );
	
	m_ledMasterShtRet.SetFont( &m_fntBtn );
	m_ledMasterShtRet.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMasterShtRet.Depress( TRUE );
	
	m_ledSlaveShtExt.SetFont( &m_fntBtn );
	m_ledSlaveShtExt.SetImage( IDB_LEDCOLOR, 15 );
	m_ledSlaveShtExt.Depress( TRUE );
	
	m_ledSlaveShtRet.SetFont( &m_fntBtn );
	m_ledSlaveShtRet.SetImage( IDB_LEDCOLOR, 15 );
	m_ledSlaveShtRet.Depress( TRUE );
	
	m_ledHeightSensorUp.SetFont( &m_fntBtn );
	m_ledHeightSensorUp.SetImage( IDB_LEDCOLOR, 15 );
	m_ledHeightSensorUp.Depress( TRUE );
	
	m_ledHeightSensorDown.SetFont( &m_fntBtn );
	m_ledHeightSensorDown.SetImage( IDB_LEDCOLOR, 15 );
	m_ledHeightSensorDown.Depress( TRUE );
	
	m_ledHeightSensorUp2.SetFont( &m_fntBtn );
	m_ledHeightSensorUp2.SetImage( IDB_LEDCOLOR, 15 );
	m_ledHeightSensorUp2.Depress( TRUE );
	
	m_ledHeightSensorDown2.SetFont( &m_fntBtn );
	m_ledHeightSensorDown2.SetImage( IDB_LEDCOLOR, 15 );
	m_ledHeightSensorDown2.Depress( TRUE );

	m_ledPowerDetectorFwd.SetFont( &m_fntBtn );
	m_ledPowerDetectorFwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledPowerDetectorFwd.Depress( TRUE );
	
	m_ledPowerDetectorBwd.SetFont( &m_fntBtn );
	m_ledPowerDetectorBwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledPowerDetectorBwd.Depress( TRUE );
	
	m_ledVacuumMotorOn.SetFont( &m_fntBtn );
	m_ledVacuumMotorOn.SetImage( IDB_LEDCOLOR, 15 );
	m_ledVacuumMotorOn.Depress( TRUE );
	
	m_ledTableClamp1.SetFont( &m_fntBtn );
	m_ledTableClamp1.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTableClamp1.Depress( TRUE );
	
	m_ledTableUnclamp1.SetFont( &m_fntBtn );
	m_ledTableUnclamp1.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTableUnclamp1.Depress( TRUE );
	
	m_ledTableClamp2.SetFont( &m_fntBtn );
	m_ledTableClamp2.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTableClamp2.Depress( TRUE );
	
	m_ledTableUnclamp2.SetFont( &m_fntBtn );
	m_ledTableUnclamp2.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTableUnclamp2.Depress( TRUE );

	m_ledSystemAir.SetFont( &m_fntBtn );
	m_ledSystemAir.SetImage( IDB_LEDCOLOR, 15 );
	m_ledSystemAir.Depress( TRUE );

	m_ledLoadingShutterOpen.SetFont( &m_fntBtn );
	m_ledLoadingShutterOpen.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLoadingShutterOpen.Depress( TRUE );

	m_ledFrontDoor.SetFont( &m_fntBtn );
	m_ledFrontDoor.SetImage( IDB_LEDCOLOR, 15 );
	m_ledFrontDoor.Depress( TRUE );

	m_ledLeftDoor.SetFont( &m_fntBtn );
	m_ledLeftDoor.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLeftDoor.Depress( TRUE );

	m_ledRear1Door.SetFont( &m_fntBtn );
	m_ledRear1Door.SetImage( IDB_LEDCOLOR, 15 );
	m_ledRear1Door.Depress( TRUE );

	m_ledRear2Door.SetFont( &m_fntBtn );
	m_ledRear2Door.SetImage( IDB_LEDCOLOR, 15 );
	m_ledRear2Door.Depress( TRUE );

	m_ledRightDoor.SetFont( &m_fntBtn );
	m_ledRightDoor.SetImage( IDB_LEDCOLOR, 15 );
	m_ledRightDoor.Depress( TRUE );

	m_ledStartSW.SetFont( &m_fntBtn );
	m_ledStartSW.SetImage( IDB_LEDCOLOR, 15 );
	m_ledStartSW.Depress( TRUE );

	m_ledStopSW.SetFont( &m_fntBtn );
	m_ledStopSW.SetImage( IDB_LEDCOLOR, 15 );
	m_ledStopSW.Depress( TRUE );

	m_ledResetSW.SetFont( &m_fntBtn );
	m_ledResetSW.SetImage( IDB_LEDCOLOR, 15 );
	m_ledResetSW.Depress( TRUE );
	
	m_ledBrushUp.SetFont( &m_fntBtn );
	m_ledBrushUp.SetImage( IDB_LEDCOLOR, 15 );
	m_ledBrushUp.Depress( TRUE );
	
	m_ledBrushDown.SetFont( &m_fntBtn );
	m_ledBrushDown.SetImage( IDB_LEDCOLOR, 15 );
	m_ledBrushDown.Depress( TRUE );

	m_ledLaserBeamPassUp.SetFont( &m_fntBtn );
	m_ledLaserBeamPassUp.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLaserBeamPassUp.Depress( TRUE );
	
	m_ledLaserBeamPassDown.SetFont( &m_fntBtn );
	m_ledLaserBeamPassDown.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLaserBeamPassDown.Depress( TRUE );
	
	//
	m_ledLaserBeamPassFwd.SetFont( &m_fntBtn );
	m_ledLaserBeamPassFwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLaserBeamPassFwd.Depress( TRUE );

	m_ledLaserBeamPassBwd.SetFont( &m_fntBtn );
	m_ledLaserBeamPassBwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLaserBeamPassBwd.Depress( TRUE );

	m_ledAomPower.SetFont( &m_fntBtn );
	m_ledAomPower.SetImage( IDB_LEDCOLOR, 15 );
	m_ledAomPower.Depress( TRUE );

	m_ledSuctionHood1Open.SetFont( &m_fntBtn );
	m_ledSuctionHood1Open.SetImage( IDB_LEDCOLOR, 15 );
	m_ledSuctionHood1Open.Depress( TRUE );

	m_ledSuctionHood1Close.SetFont( &m_fntBtn );
	m_ledSuctionHood1Close.SetImage( IDB_LEDCOLOR, 15 );
	m_ledSuctionHood1Close.Depress( TRUE );

	m_ledSuctionHood2Open.SetFont( &m_fntBtn );
	m_ledSuctionHood2Open.SetImage( IDB_LEDCOLOR, 15 );
	m_ledSuctionHood2Open.Depress( TRUE );

	m_ledSuctionHood2Close.SetFont( &m_fntBtn );
	m_ledSuctionHood2Close.SetImage( IDB_LEDCOLOR, 15 );
	m_ledSuctionHood2Close.Depress( TRUE );

	m_ledA1InitComplete.SetFont( &m_fntBtn );
	m_ledA1InitComplete.SetImage( IDB_LEDCOLOR, 15 );
	m_ledA1InitComplete.Depress( TRUE );
	
	m_ledA1Initializing.SetFont( &m_fntBtn );
	m_ledA1Initializing.SetImage( IDB_LEDCOLOR, 15 );
	m_ledA1Initializing.Depress( TRUE );
	
	m_ledA1Inposition.SetFont( &m_fntBtn );
	m_ledA1Inposition.SetImage( IDB_LEDCOLOR, 15 );
	m_ledA1Inposition.Depress( TRUE );
	
	m_ledA1Run.SetFont( &m_fntBtn );
	m_ledA1Run.SetImage( IDB_LEDCOLOR, 15 );
	m_ledA1Run.Depress( TRUE );

	m_ledA2InitComplete.SetFont( &m_fntBtn );
	m_ledA2InitComplete.SetImage( IDB_LEDCOLOR, 15 );
	m_ledA2InitComplete.Depress( TRUE );
	
	m_ledA2Initializing.SetFont( &m_fntBtn );
	m_ledA2Initializing.SetImage( IDB_LEDCOLOR, 15 );
	m_ledA2Initializing.Depress( TRUE );
	
	m_ledA2Inposition.SetFont( &m_fntBtn );
	m_ledA2Inposition.SetImage( IDB_LEDCOLOR, 15 );
	m_ledA2Inposition.Depress( TRUE );
	
	m_ledA2Run.SetFont( &m_fntBtn );
	m_ledA2Run.SetImage( IDB_LEDCOLOR, 15 );
	m_ledA2Run.Depress( TRUE );

#ifndef __KUNSAN_SAMSUNG_LARGE__
	m_ledA1InitComplete.ShowWindow(SW_HIDE);
	m_ledA1Initializing.ShowWindow(SW_HIDE);
	m_ledA1Inposition.ShowWindow(SW_HIDE);
	m_ledA1Run.ShowWindow(SW_HIDE);
	m_ledA2InitComplete.ShowWindow(SW_HIDE);
	m_ledA2Initializing.ShowWindow(SW_HIDE);
	m_ledA2Inposition.ShowWindow(SW_HIDE);
	m_ledA2Run.ShowWindow(SW_HIDE);
#endif
}


void CPaneManualControlIOMonitorInputSub1Pusan1::UpdateStatus()
{
	if(m_lStatus1 != m_lStatus1Old)
	{
		m_lStatus1Old = m_lStatus1;

		if(m_lStatus1 & 0x0001)
			m_ledMainMotorReady.Depress( FALSE );
		else
			m_ledMainMotorReady.Depress( TRUE );
		
		if(m_lStatus1 & 0x0002)
			m_ledHeightSensorDown2.Depress( FALSE );
		else
			m_ledHeightSensorDown2.Depress( TRUE );
		
		if(m_lStatus1 & 0x10000)
			m_ledHeightSensorUp2.Depress( FALSE );
		else
			m_ledHeightSensorUp2.Depress( TRUE );

		if(m_lStatus1 & 0x0004)
			m_ledMachineRun.Depress( FALSE );
		else
			m_ledMachineRun.Depress( TRUE );

		if(m_lStatus1 & 0x0008)
			m_ledSafetyMode.Depress( FALSE );
		else
			m_ledSafetyMode.Depress( TRUE );

		if(m_lStatus1 & 0x0010)
			m_ledDoorByPass.Depress( FALSE );
		else
			m_ledDoorByPass.Depress( TRUE );

		if(m_lStatus1 & 0x0020)
			m_ledTable1PCB.Depress( FALSE );
		else
			m_ledTable1PCB.Depress( TRUE );

		if(m_lStatus1 & 0x0040)
			m_ledTable2PCB.Depress( FALSE );
		else
			m_ledTable2PCB.Depress( TRUE );

		if(m_lStatus1 & 0x0080)
			m_ledMainInitComplete.Depress( FALSE );
		else
			m_ledMainInitComplete.Depress( TRUE );

		if(m_lStatus1 & 0x0100)
			m_ledMainInitializing.Depress( FALSE );
		else
			m_ledMainInitializing.Depress( TRUE );

		if(m_lStatus1 & 0x0200)
			m_ledMainAlarm.Depress( FALSE );
		else
			m_ledMainAlarm.Depress( TRUE );

		if(m_lStatus1 & 0x0400)
			m_ledXInitComplete.Depress( FALSE );
		else
			m_ledXInitComplete.Depress( TRUE );

		if(m_lStatus1 & 0x0800)
			m_ledXInitializing.Depress( FALSE );
		else
			m_ledXInitializing.Depress( TRUE );

		if(m_lStatus1 & 0x1000)
			m_ledXInposition.Depress( FALSE );
		else
			m_ledXInposition.Depress( TRUE );

		if(m_lStatus1 & 0x2000)
			m_ledXRun.Depress( FALSE );
		else
			m_ledXRun.Depress( TRUE );

		if(m_lStatus1 & 0x4000)
			m_ledYInitComplete.Depress( FALSE );
		else
			m_ledYInitComplete.Depress( TRUE );

		if(m_lStatus1 & 0x8000)
			m_ledYInitializing.Depress( FALSE );
		else
			m_ledYInitializing.Depress( TRUE );
	}

	if(m_lStatus2 != m_lStatus2Old)
	{
		m_lStatus2Old = m_lStatus2;
	
		if(m_lStatus2 & 0x0001)
			m_ledYInposition.Depress( FALSE );
		else
			m_ledYInposition.Depress( TRUE );

		if(m_lStatus2 & 0x0002)
			m_ledYRun.Depress( FALSE );
		else
			m_ledYRun.Depress( TRUE );

		if(m_lStatus2 & 0x0004)
			m_ledZ1InitComplete.Depress( FALSE );
		else
			m_ledZ1InitComplete.Depress( TRUE );

		if(m_lStatus2 & 0x0008)
			m_ledZ1Initializing.Depress( FALSE );
		else
			m_ledZ1Initializing.Depress( TRUE );

		if(m_lStatus2 & 0x0010)
			m_ledZ1Inposition.Depress( FALSE );
		else
			m_ledZ1Inposition.Depress( TRUE );

		if(m_lStatus2 & 0x0020)
			m_ledZ1Run.Depress( FALSE );
		else
			m_ledZ1Run.Depress( TRUE );

		if(m_lStatus2 & 0x0040)
			m_ledZ2InitComplete.Depress( FALSE );
		else
			m_ledZ2InitComplete.Depress( TRUE );

		if(m_lStatus2 & 0x0080)
			m_ledZ2Initializing.Depress( FALSE );
		else
			m_ledZ2Initializing.Depress( TRUE );

		if(m_lStatus2 & 0x0100)
			m_ledZ2Inposition.Depress( FALSE );
		else
			m_ledZ2Inposition.Depress( TRUE );

		if(m_lStatus2 & 0x0200)
			m_ledZ2Run.Depress( FALSE );
		else
			m_ledZ2Run.Depress( TRUE );

		if(m_lStatus2 & 0x0400)
			m_ledMInitComplete.Depress( FALSE );
		else
			m_ledMInitComplete.Depress( TRUE );

		if(m_lStatus2 & 0x0800)
			m_ledMInitializing.Depress( FALSE );
		else
			m_ledMInitializing.Depress( TRUE );

		if(m_lStatus2 & 0x1000)
			m_ledMInposition.Depress( FALSE );
		else
			m_ledMInposition.Depress( TRUE );

		if(m_lStatus2 & 0x2000)
			m_ledMRun.Depress( FALSE );
		else
			m_ledMRun.Depress( TRUE );

		if(m_lStatus2 & 0x4000)
			m_ledCInitComplete.Depress( FALSE );
		else
			m_ledCInitComplete.Depress( TRUE );

		if(m_lStatus2 & 0x8000)
			m_ledCInitializing.Depress( FALSE );
		else
			m_ledCInitializing.Depress( TRUE );

		if(m_lStatus2 & 0x10000 )
			m_ledA1InitComplete.Depress( FALSE );
		else
			m_ledA1InitComplete.Depress( TRUE );

		if(m_lStatus2 & 0x20000 )
			m_ledA1Initializing.Depress( FALSE );
		else
			m_ledA1Initializing.Depress( TRUE );

		if(m_lStatus2 & 0x40000 )
			m_ledA1Inposition.Depress( FALSE );
		else
			m_ledA1Inposition.Depress( TRUE );

		if(m_lStatus2 & 0x80000 )
			m_ledA1Run.Depress( FALSE );
		else
			m_ledA1Run.Depress( TRUE );
	}
		
	if(m_lStatus3 != m_lStatus3old)
	{
		m_lStatus3old = m_lStatus3;

		if(m_lStatus3 & 0x0001)
			m_ledCInposition.Depress( FALSE );
		else
			m_ledCInposition.Depress( TRUE );

		if(m_lStatus3 & 0x0002)
			m_ledCRun.Depress( FALSE );
		else
			m_ledCRun.Depress( TRUE );
	
		if(m_lStatus3 & 0x0004)
			m_ledMasterShtExt.Depress( FALSE );
		else
			m_ledMasterShtExt.Depress( TRUE );

		if(m_lStatus3 & 0x0008)
			m_ledMasterShtRet.Depress( FALSE );
		else
			m_ledMasterShtRet.Depress( TRUE );

		if(m_lStatus3 & 0x0010)
			m_ledSlaveShtExt.Depress( FALSE );
		else
			m_ledSlaveShtExt.Depress( TRUE );

		if(m_lStatus3 & 0x0020)
			m_ledSlaveShtRet.Depress( FALSE );
		else
			m_ledSlaveShtRet.Depress( TRUE );

		if(m_lStatus3 & 0x0040)
			m_ledHeightSensorUp.Depress( FALSE );
		else
			m_ledHeightSensorUp.Depress( TRUE );

		if(m_lStatus3 & 0x0080)
			m_ledHeightSensorDown.Depress( FALSE );
		else
			m_ledHeightSensorDown.Depress( TRUE );

		if(m_lStatus3 & 0x0100)
			m_ledPowerDetectorFwd.Depress( FALSE );
		else
			m_ledPowerDetectorFwd.Depress( TRUE );

		if(m_lStatus3 & 0x0200)
			m_ledPowerDetectorBwd.Depress( FALSE );
		else
			m_ledPowerDetectorBwd.Depress( TRUE );


		if(m_lStatus3 & 0x0400) 
			m_ledC2InitComplete.Depress( FALSE );
		else
			m_ledC2InitComplete.Depress( TRUE );

		
		if(m_lStatus3 & 0x8000) 
			m_ledC2Initializing.Depress( FALSE );
		else
			m_ledC2Initializing.Depress( TRUE );

		
		if(m_lStatus3 & 0x0004) 
			m_ledC2Inposition.Depress( FALSE );
		else
			m_ledC2Inposition.Depress( TRUE );

		
		if(m_lStatus3 & 0x0008) 
			m_ledC2Run.Depress( FALSE );
		else
			m_ledC2Run.Depress( TRUE );

		if(m_lStatus3 & 0x40000  )
			m_ledA2InitComplete.Depress( FALSE );
		else
			m_ledA2InitComplete.Depress( TRUE );

		if(m_lStatus3 & 0x80000 )
			m_ledA2Initializing.Depress( FALSE );
		else
			m_ledA2Initializing.Depress( TRUE );

		if(m_lStatus3 & 0x100000  )
			m_ledA2Inposition.Depress( FALSE );
		else
			m_ledA2Inposition.Depress( TRUE );

		if(m_lStatus3 & 0x200000 )
			m_ledA2Run.Depress( FALSE );
		else
			m_ledA2Run.Depress( TRUE );
//		if(m_lStatus3 & 0x0400)
//			m_ledVacuumMotorOn.Depress( FALSE );
//		else
//			m_ledVacuumMotorOn.Depress( TRUE );

/*
		if(gSystemINI.m_sHardWare.nTableClamp > 0)
		{
			if(m_lStatus3 & 0x0800)
				m_ledTableClamp1.Depress( FALSE );
			else
				m_ledTableClamp1.Depress( TRUE );

			if(m_lStatus3 & 0x1000)
				m_ledTableUnclamp1.Depress( FALSE );
			else
				m_ledTableUnclamp1.Depress( TRUE );
		}

		if(gSystemINI.m_sHardWare.nTableClamp > 1)
		{
			if(m_lStatus3 & 0x2000)
				m_ledTableClamp2.Depress( FALSE );
			else
				m_ledTableClamp2.Depress( TRUE );

			if(m_lStatus3 & 0x4000)
				m_ledTableUnclamp2.Depress( FALSE );
			else
				m_ledTableUnclamp2.Depress( TRUE );
		}
*/
	}

	if(m_lStatus4 != m_lstatus4Old)
	{
		m_lstatus4Old = m_lStatus4;
		if((m_lStatus4 & 0x0010))
			m_ledLaserBeamPassUp.Depress( FALSE );
		else
			m_ledLaserBeamPassUp.Depress( TRUE );
		
		if((m_lStatus4 & 0x0020))
			m_ledLaserBeamPassDown.Depress( FALSE );
		else
			m_ledLaserBeamPassDown.Depress( TRUE );

		if((m_lStatus4 & 0x0001)  && (m_lStatus4 & 0x0004))
			m_ledLaserBeamPassFwd.Depress( FALSE );
		else
			m_ledLaserBeamPassFwd.Depress( TRUE );
		
		if((m_lStatus4 & 0x0002)  && (m_lStatus4 & 0x0008))
			m_ledLaserBeamPassBwd.Depress( FALSE );
		else
			m_ledLaserBeamPassBwd.Depress( TRUE );

		//if(m_lStatus4 & 0x0010)//20171227
		//	m_ledLightCurtainOn.Depress( FALSE );
		//else
		//	m_ledLightCurtainOn.Depress( TRUE );

		if(m_lStatus4 & 0x40000)
			m_ledAomPower.Depress( FALSE );
		else
			m_ledAomPower.Depress( TRUE );

		if(m_pMotor->GetCurrentMotorSol())
			m_ledVacuumMotorOn.Depress( FALSE );
		else
			m_ledVacuumMotorOn.Depress( TRUE );

		if(m_lStatus4 & 0x100000)
			m_ledSuctionHood1Open.Depress( FALSE );
		else
			m_ledSuctionHood1Open.Depress( TRUE );

		if(m_lStatus4 & 0x200000)
			m_ledSuctionHood1Close.Depress( FALSE );
		else
			m_ledSuctionHood1Close.Depress( TRUE );

		if(m_lStatus4 & 0x400000)
			m_ledSuctionHood2Open.Depress( FALSE );
		else
			m_ledSuctionHood2Open.Depress( TRUE );

		if(m_lStatus4 & 0x800000)
			m_ledSuctionHood2Close.Depress( FALSE );
		else
			m_ledSuctionHood2Close.Depress( TRUE );
		

		if(m_lStatus4 & 0x0004)
			m_ledM2Inposition.Depress( FALSE );
		else
			m_ledM2Inposition.Depress( TRUE );

		if(m_lStatus4 & 0x0008)
			m_ledM2Run.Depress( FALSE );
		else
			m_ledM2Run.Depress( TRUE );

		if(m_lStatus4 & 0x4000)
			m_ledM2InitComplete.Depress( FALSE );
		else
			m_ledM2InitComplete.Depress( TRUE );

		if(m_lStatus4 & 0x8000)
			m_ledM2Initializing.Depress( FALSE );
		else
			m_ledM2Initializing.Depress( TRUE );


		if(gSystemINI.m_sHardWare.nTableClamp > 0)
		{
			if(m_lStatus4 & 0x0040)
				m_ledTableClamp1.Depress( TRUE );
			else
				m_ledTableClamp1.Depress( FALSE );
			
			if(m_lStatus4 & 0x0080)
				m_ledTableUnclamp1.Depress( TRUE );
			else
				m_ledTableUnclamp1.Depress( FALSE );
		}
		
		if(gSystemINI.m_sHardWare.nTableClamp > 1)
		{
			if(m_lStatus4 & 0x0100)
				m_ledTableClamp2.Depress( TRUE );
			else
				m_ledTableClamp2.Depress( FALSE );
			
			if(m_lStatus4 & 0x0200)
				m_ledTableUnclamp2.Depress( TRUE );
			else
				m_ledTableUnclamp2.Depress( FALSE );
		}
	}

	if(m_lStatus7 != m_lstatus7Old)
	{
		m_lstatus7Old = m_lStatus7;

		if(m_lStatus7 & 0x0008)
			m_ledLightCurtainOn.Depress( FALSE );
		else
			m_ledLightCurtainOn.Depress( TRUE );
	}

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{		
		
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
	}
}

void CPaneManualControlIOMonitorInputSub1Pusan1::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default

	m_lStatus1 = m_pMotor->GetCurrentError(STATUS_IO1);
	m_lStatus2 = m_pMotor->GetCurrentError(STATUS_IO2);
	m_lStatus3 = m_pMotor->GetCurrentError(STATUS_IO3);
	m_lStatus4 = m_pMotor->GetCurrentError(STATUS_IO4);
	m_lStatus7 = m_pMotor->GetCurrentError(STATUS_IO7);

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_lTableLimit = m_pMotor->GetCurrentError(ERROR_TABLELIMIT);
		m_lTableError = m_pMotor->GetCurrentError(ERROR_TABLE);
	}

	UpdateStatus();
	
	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlIOMonitorInputSub1Pusan1::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_nTimerID = SetTimer(9971, 300, NULL);

		m_pMotor = gDeviceFactory.GetMotor();

	}
}

void CPaneManualControlIOMonitorInputSub1Pusan1::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;

		m_lStatus1 = m_lStatus1Old = 0;
		m_lStatus2 = m_lStatus2Old = 0;
		m_lStatus3 = m_lStatus3old = 0;
		m_lStatus4 = m_lstatus4Old = 0;
		m_lStatus7 = m_lstatus7Old = 0;
		m_lTableLimit = m_lTableLimitOld = 0;
		m_lTableError = m_lTableErrorOld = 0;
	}
}
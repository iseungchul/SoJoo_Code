#if !defined(AFX_PANEAUTORUNVIEWPREWORK_H__6D2C1DE9_C63C_480D_A8A1_512490965A78__INCLUDED_)
#define AFX_PANEAUTORUNVIEWPREWORK_H__6D2C1DE9_C63C_480D_A8A1_512490965A78__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneAutoRunViewPrework.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewPrework form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif
#include "USimpleTab.h"
class CPaneAutoRunViewPreworkHeat;
class CPaneAutoRunViewPreworkPower;
class CPaneAutoRunViewPreworkScanner;

class CPaneAutoRunViewPrework : public CFormView
{
protected:
	CPaneAutoRunViewPrework();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneAutoRunViewPrework)

// Form Data
public:
	//{{AFX_DATA(CPaneAutoRunViewPrework)
	enum { IDD = IDD_DLG_AUTORUN_VIEW_PREWORK };
	//}}AFX_DATA

// Attributes
public:

	USimpleTab	m_tabPrework;
	CFont		m_fntTab;
	CFont		m_fntStatic;
	int			m_nTimer;
	CPaneAutoRunViewPreworkHeat* m_pPreHeat;
	CPaneAutoRunViewPreworkPower* m_pPower;
	CPaneAutoRunViewPreworkScanner* m_pScanner;

	BOOL m_bDoPreheat;
	BOOL m_bDoScanner;
	BOOL m_bDoPower;
	BOOL m_bDoDrill;
	BOOL m_bChangeDisplay;
	BOOL m_bPreheat;
	BOOL m_bScanner;
	BOOL m_bPower;
// Operations
public:
	void ActiveStaticForKeyboardError();
	void SetPreworkInfo(BOOL bPreheat, BOOL bPower, BOOL bScanner);
	void SetPreworkStatus(BOOL bPreHeat, BOOL bPower, BOOL bScanner, BOOL bDrill);
	void ChangeView(int nChangePane);
	void DestroyTimer();
	void InitTimer();
	void DrawDoingPrework();
	void DrawChart();
	void InitStatic();
	void InitTabControl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneAutoRunViewPrework)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneAutoRunViewPrework();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneAutoRunViewPrework)
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnClickTabPrework(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEAUTORUNVIEWPREWORK_H__6D2C1DE9_C63C_480D_A8A1_512490965A78__INCLUDED_)


#define DLLAPI	extern "C" __declspec( dllexport )

namespace ERRLIST
{
	DLLAPI	BOOL InitErrListDll(int nLanguageType = 0);
	DLLAPI	void ShowErrListDlg();
	DLLAPI	BOOL GetErrMsg(int nID, char* pErrCode, char* pErrReason, char* pErrSolution, int nLanguage = 2);  // Language : 0 �ѱ� 1 ���� 2 �߹�
}

using namespace ERRLIST;
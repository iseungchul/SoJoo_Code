
#define DLLAPI	extern "C" __declspec( dllexport )

namespace ERRLIST
{
	DLLAPI	BOOL InitErrListDll(int nLanguageType = 0);
	DLLAPI	void ShowErrListDlg();
	DLLAPI	BOOL GetErrMsg(int nID, char* pErrCode, char* pErrReason, char* pErrSolution);
}

using namespace ERRLIST;
// HDeviceFactory.h: interface for the HDeviceFactory class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HDEVICEFACTORY_H__5B89E086_8632_4395_81EF_97E89196EE80__INCLUDED_)
#define AFX_HDEVICEFACTORY_H__5B89E086_8632_4395_81EF_97E89196EE80__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifdef __MP920_MOTOR__
	class HMotor;
#else
	class DeviceMotor;
#endif

class CComiMotion;
class CComiDaq;

class HVision;
class HHeightSensor;
class HEocard;
class HLaser;
class HLaserAttenuator;
class DTemperCompensation;
class DPowerAttenCompensation;

class HDeviceFactory  
{
public:
	HDeviceFactory();
	virtual ~HDeviceFactory();

// Operation
public :
	BOOL			InitializeDevice(CComiMotion* pMotion, CComiDaq* pDaq);
	void			DestroyDevice();

	BOOL IsOkAOM(BOOL bShowMsg = FALSE);

#ifdef __MP920_MOTOR__
	HMotor*			GetMotor();
#else
	DeviceMotor*    GetMotor();
#endif

	HVision*		GetVision();
	HHeightSensor*	GetHeightSensor();
	HEocard*		GetEocard();
	HLaser*			GetLaser();

	DTemperCompensation* Get1stTemperCompen();
	DTemperCompensation* Get2ndTemperCompen();
	DPowerAttenCompensation* GetPwrAttenCompen();

// Attributes
protected :
#ifdef __MP920_MOTOR__
	HMotor*			m_pMotor;
#else
	DeviceMotor*	m_pMotor;
#endif

	HVision*		m_pVision;
	HHeightSensor*	m_pHeightSensor;
	HEocard*		m_pEocard;
	HLaser*			m_pLaser;

	DTemperCompensation* m_p1stTemperCompen;
	DTemperCompensation* m_p2ndTemperCompen;
	DPowerAttenCompensation* m_pPwrAttenCompen;
};

extern HDeviceFactory gDeviceFactory;

#endif // !defined(AFX_HDEVICEFACTORY_H__5B89E086_8632_4395_81EF_97E89196EE80__INCLUDED_)

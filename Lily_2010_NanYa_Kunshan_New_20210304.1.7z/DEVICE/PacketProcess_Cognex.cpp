// PacketProcess_Cognex.cpp: implementation of the CPacketProcess_Cognex class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PacketProcess_Cognex.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPacketProcess_Cognex::CPacketProcess_Cognex()
{
	ClearInPacket();
	ClearOutPacket();
	memset(m_cSubData, 0, MAX_SIZE2);
}

CPacketProcess_Cognex::~CPacketProcess_Cognex()
{
}

void CPacketProcess_Cognex::ClearInPacket()
{
	m_stInPacket.sSTX = 0;
	memset(m_stInPacket.sCMD, 0, CMD_SIZE);
	memset(m_stInPacket.sData, 0, MAX_SIZE1);
	memset(m_stInPacket.sData2, 0, MAX_SIZE2);
	m_stInPacket.sETX = 0;
}

void CPacketProcess_Cognex::ClearOutPacket()
{
	m_stOutPacket.sSTX = 0;
	memset(m_stOutPacket.sCMD, 0, CMD_SIZE);
	memset(m_stOutPacket.sData, 0, MAX_SIZE1);
	memset(m_stOutPacket.sData2, 0, MAX_SIZE2);
	m_stOutPacket.sETX = 0;
}

void * CPacketProcess_Cognex::MakePacket(char *pCMD, char *pData1)
{
	// Header
	m_stOutPacket.sSTX = STX;
	strncpy(m_stOutPacket.sCMD, pCMD, CMD_SIZE);
	strncpy(m_stOutPacket.sData, pData1, MAX_SIZE1);
	m_stOutPacket.sETX = ETX;
	return &m_stOutPacket;
}

int CPacketProcess_Cognex::ParsePacket(char *pPacket)
{
	// STX
	if ( pPacket[0] != STX )
	{
		m_strMsg.Format(_T("STX is wrong [%c]"), pPacket[0]);
//		m_Log.SaveLog(m_strMsg);
		ClearInPacket();
		return RECEIVE_WRONG_MSG;
	}


	// Command
	strncpy(m_stInPacket.sCMD, pPacket + 1, CMD_SIZE);


	if((strcmp(m_stInPacket.sCMD, _T("ACK")) != 0) &&
		(strcmp(m_stInPacket.sCMD, _T("NAK")) != 0) &&
		(strcmp(m_stInPacket.sCMD, _T("R10")) != 0) &&
		(strcmp(m_stInPacket.sCMD, _T("R15")) != 0) &&
		(strcmp(m_stInPacket.sCMD, _T("R18")) != 0) &&
		(strcmp(m_stInPacket.sCMD, _T("R21")) != 0) 
		)
	{
		m_strMsg.Format(_T("Command is wrong [%s]"), m_stInPacket.sCMD);
//		m_Log.SaveLog(m_strMsg);
		ClearInPacket();
		return RECEIVE_WRONG_MSG;
	}

	// Get Data
	memset(m_stInPacket.sData, 0, MAX_SIZE1);
	strncpy(m_stInPacket.sData, pPacket + (1 + CMD_SIZE), MAX_SIZE1);

	memset(m_cSubData, 0, MAX_SIZE2);
	CopyMemory(m_cSubData,pPacket + (1 + CMD_SIZE + MAX_SIZE1),MAX_SIZE2);

	if ( pPacket[MAX_TOTAL_SIZE -1] != ETX)
	{
		m_strMsg.Format(_T("ETX is wrong [%s]"), m_stInPacket.sData);
		//		m_Log.SaveLog(m_strMsg);
		ClearInPacket();
		return RECEIVE_WRONG_MSG;
	}


	if (strncmp(m_stInPacket.sCMD, _T("ACK"), 3) == 0)
	{
		return RECEIVE_ACK_MSG;
	}
	else if (strncmp(m_stInPacket.sCMD, _T("R10"), 3) == 0)
	{
		return RECEIVE_10_MSG;
	}
	else if (strncmp(m_stInPacket.sCMD, _T("R15"), 3) == 0)
	{
		return RECEIVE_15_MSG;
	}
	else if (strncmp(m_stInPacket.sCMD, _T("R18"), 3) == 0)
	{
		return RECEIVE_18_MSG;
	}
	else if (strncmp(m_stInPacket.sCMD, _T("R21"), 3) == 0)
	{
		return RECEIVE_21_MSG;
	}
	else if (strncmp(m_stInPacket.sCMD, _T("NAK"), 3) == 0)
	{
		return RECEIVE_NAK_MSG;
	}


	return RECEIVE_WRONG_MSG;
}


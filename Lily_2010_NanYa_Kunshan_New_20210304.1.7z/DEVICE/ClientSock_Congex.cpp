// ClientSock_Cognex.cpp : implementation file
//

#include "stdafx.h"
#include "ClientSock_Cognex.h"
#include "..\EasyDriller.h"
#include "..\Model\Glyph.h"
#include "..\EasyDrillerDlg.h"
#include "..\Model\DProcessINI.h"
#include "..\model\GlobalVariable.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	RECEIVE_STATUS_INIT				0
#define RECEIVED_MASTER_DX_DATA			1
#define RECEIVED_MASTER_DY_DATA			2
#define RECEIVED_MASTER_THETA_DATA		3

/////////////////////////////////////////////////////////////////////////////
// CClientSock_Cognex

CClientSock_Cognex::CClientSock_Cognex()
{
	m_bConnect = FALSE;
	m_hWnd = NULL;
}

CClientSock_Cognex::~CClientSock_Cognex()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CClientSock_Cognex, CAsyncSocket)
	//{{AFX_MSG_MAP(CClientSock_Cognex)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CClientSock_Cognex member functions
void CClientSock_Cognex::SetWnd(HWND hWnd)
{
	m_hWnd = hWnd;
}

void CClientSock_Cognex::OnConnect(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_hWnd)
		SendMessage(m_hWnd, WM_CLIENT_CONNECT, 1, nErrorCode);
	
	if(nErrorCode == 0)
		m_bConnect = TRUE;
	else
		m_bConnect = FALSE;

	CAsyncSocket::OnConnect(nErrorCode);
}

void CClientSock_Cognex::OnReceive(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_hWnd)
		SendMessage(m_hWnd, WM_CLIENT_RECEIVE, 2, nErrorCode);

	CAsyncSocket::OnReceive(nErrorCode);
}

void CClientSock_Cognex::OnClose(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_hWnd)
		SendMessage(m_hWnd, WM_CLIENT_CLOSE, 3, nErrorCode);

	m_bConnect = FALSE;
	CAsyncSocket::OnClose(nErrorCode);
}

BOOL CClientSock_Cognex::Connect(LPCTSTR lpszHostAddress, UINT nHostPort)
{
	BOOL bResult = CAsyncSocket::Connect(lpszHostAddress, nHostPort);
	
	if(bResult == FALSE)
	{
		int nErrorCode = CAsyncSocket::GetLastError();
		
		switch(nErrorCode)
		{
		case WSANOTINITIALISED:
		case WSAENETDOWN:
		case WSAEADDRINUSE:
		case WSAEINPROGRESS:
		case WSAEAFNOSUPPORT:
		case WSAECONNREFUSED:
		case WSAEDESTADDRREQ:
		case WSAEFAULT:
		case WSAEINVAL:
		case WSAEISCONN:
		case WSAEMFILE:
		case WSAENOBUFS:
		case WSAENOTSOCK:
		case WSAETIMEDOUT:
			TRACE(_T("Connection Failure.\n"));
			m_bConnect = FALSE;
			return FALSE;
			break;
		case WSAEWOULDBLOCK:
			// If an error code is WSAWOULDBLOCK, and your application
			// is using the override callbacks,
			// your application will receive an OnConnect message
			// when the connect operation is complete. -> refer to MSDN.
			TRACE(_T("Connection Success.\n"));
		//	m_bConnect = TRUE;
			return TRUE;
		default:
			TRACE(_T("Connection Failure.\n"));
			m_bConnect = FALSE;
			return FALSE;
		}
		return FALSE;
	}
	
	TRACE(_T("Connection Success.\n"));
	

	return (TRUE);
}

int CClientSock_Cognex::ReceiveData()
{
	char sTemp[MAX_TOTAL_SIZE] = {0,};
	Receive(sTemp, MAX_TOTAL_SIZE);

	//if((strcmp(sTemp, "") != 0))
	//	return RETURN_FAIL_;

	CString strTemp;
	strTemp.Format("%s",sTemp);

	if(strTemp == "")
		return RETURN_FAIL_;

	m_PacketProc.ClearInPacket();

	int nResult = m_PacketProc.ParsePacket(sTemp);
	CString str;
//	str.Format(_T("%d : ������ �޾ҽ��ϴ�."), nResult);
//	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&str));
	
	return nResult;
}

void CClientSock_Cognex::SendNAK()
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();

	char Temp[MAX_SIZE1];
	memset(Temp, 0, MAX_SIZE1);


	pPacket = (char *)(m_PacketProc.MakePacket(_T("NAK"), Temp));
	Send(pPacket, MAX_TOTAL_SIZE);

}

void CClientSock_Cognex::SendACK()
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	
	char Temp[MAX_SIZE1];
	memset(Temp, 0, MAX_SIZE1);

	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("ACK"), Temp));
	
	Send(pPacket, MAX_TOTAL_SIZE);
	strMsg.Format(_T("(Send ACK Message) %s"), strPacket);
//	WriteLog(strMsg);
}

void CClientSock_Cognex::ReConnectTry()
{
	unsigned int unClientPort = 0;
	char sClientIPAddr[16] = {0,};
	CString str, str2;
	str = ::AfxGetApp()->GetProfileString(_T("Settings"), _T("Address"), _T("127.0.0.1"));
	strncpy_s(sClientIPAddr, 16, str, 15);
	unClientPort = ::AfxGetApp()->GetProfileInt(_T("Settings"), _T("Port"), 7000);

	Close();

	SetWnd(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_hWnd);
	Create();
	if(FALSE == Connect(sClientIPAddr, unClientPort))
	{
		m_bConnect = FALSE;
		//		ErrMessage(_T("���� ����"));
		//		return;
	}	
	else
		m_bConnect = TRUE;
}



///Socket

int CClientSock_Cognex::OnCamChange(int nCamNo)
{

	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;%02d;"),nCamNo,gFidFindExposure);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);
	//lstrcpy(cTemp,strMsg);
	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C01"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;


}
int CClientSock_Cognex::OnAcquire(int nCamNo) // refresh vision
{

	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();
	
	strMsg.Format(_T("%02d;"),nCamNo);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C02"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}
int CClientSock_Cognex::OnContrastAndBrightness(int nCamNo, double dContrast, double dBrightness)
{

	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;%.3f;%.3f"),nCamNo,dContrast,dBrightness);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C03"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}

int CClientSock_Cognex::OnContrast(int nCamNo, double dContrast)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;%.3f;"),nCamNo,dContrast);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C04"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}
int CClientSock_Cognex::OnBrightness(int nCamNo, double dBrightness)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;%.3f;"),nCamNo,dBrightness);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C05"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}
int CClientSock_Cognex::SaveImg(int nCamNo, CString strFilePathName)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;%s;"),nCamNo,strFilePathName);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C06"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}
int CClientSock_Cognex::OnLive(int nCamNo, BOOL bIsLive)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;%02d;%02d;"),nCamNo,bIsLive,gFidFindExposure);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	pPacket = (char *)(m_PacketProc.MakePacket(_T("C07"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}
int CClientSock_Cognex::OnApplyVisionParameter(int nID, int nCamNo, VISION_INFO sVisionInfo)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;%02d;%02d;"),nID,nCamNo,gFidFindExposure);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C08"), cTemp));

	CopyMemory(pPacket + (1 + CMD_SIZE + MAX_SIZE1),&sVisionInfo,sizeof(VISION_INFO));
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}
int CClientSock_Cognex::OnApplyVisionParam(int nID,  int nCamNo, SVISIONINFO sVisionInfo)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;%02d;%02d;"),nID,nCamNo,gFidFindExposure);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C09"), cTemp));
	
	CopyMemory(pPacket + (1 + CMD_SIZE + MAX_SIZE1),&sVisionInfo,sizeof(SVISIONINFO));
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}
/*
int CClientSock_Cognex::GetRealPos(DPOINT* rPos, int nCam, int nIndex, BOOL bRefresh, char* pChar, BOOL bFindPattern)
{

	return 0;
}
*/
int CClientSock_Cognex::LoadOptionFile(int nType)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;"),nType);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);
	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C10"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}

int CClientSock_Cognex::ShowArea(int nShow, int nPatternNo, int nCam)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;%02d;%02d;"),nShow,nPatternNo,nCam);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);
	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C11"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn = 0;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}
int CClientSock_Cognex::SetInspectionArea(int nSize, int nCam)
{

	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;%02d;"),nSize,nCam);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C12"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;

}

int CClientSock_Cognex::SetInspectionAreaPercent(double nPercent, int nCam)
{

	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%.3f;%02d;"),nPercent,nCam);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C13"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;

}

int CClientSock_Cognex::SetAcceptScore(double dVal)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%.3f;"),dVal);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);
	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C14"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}

int CClientSock_Cognex::GetDispParam(SVISIONINFO *pVisionInfo, int nSel, int nCamNo)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;%02d;"),nSel,nCamNo);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C15"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_15_MSG)
		{
			Pasing_GetDispParam(pVisionInfo);

			return SEND_OK_;
			
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
				return RETURN_FAIL_;	
		}

		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}
int CClientSock_Cognex::ClearInteractiveGraphics(int nCam)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;"),nCam);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	


	pPacket = (char *)(m_PacketProc.MakePacket(_T("C16"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;

}

int CClientSock_Cognex::TransformPixel()
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;"),0);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C17"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}

int CClientSock_Cognex::PMToolFind( int iDisplay, int iPatternNo, bool bShowResult, bool patternFlag )
{


	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;%02d;%02d;%02d;"),iDisplay,iPatternNo,bShowResult,patternFlag);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C18"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_18_MSG)
		{
			if(!Pasing_PMToolFind(iDisplay))
			return RETURN_FAIL_;

			return SEND_OK_;
	
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
				return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;

}

int CClientSock_Cognex::InitVisionPixelData(int nCam)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;"),nCam);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C19"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}

int CClientSock_Cognex::InitDistancePerPixel()
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;"),0);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C20"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}

int CClientSock_Cognex::GetNoGrabRealPosFor4Way(int nCam, int nIndex)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;%02d;"),nCam,nIndex);
	char cTemp[MAX_SIZE1];
	memset(cTemp, 0, MAX_SIZE1);
	lstrcpy(cTemp,strMsg);

	
	

	pPacket = (char *)(m_PacketProc.MakePacket(_T("C21"), cTemp));
	
	Send(pPacket, MAX_TOTAL_SIZE);

	int nCount = 0;
	int nReturn;
	
	while(TRUE) // 5sec
	{
		MessageLoopWait(10);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_21_MSG)
		{
			if(!Pasing_GetNoGrabRealPosFor4Way())
			return RETURN_FAIL_;

			return SEND_OK_;

		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;

		}
		if(nCount > 500)
			break;

		nCount++;
	}
	return TIME_OUT_;
}

BOOL CClientSock_Cognex::Pasing_GetDispParam(SVISIONINFO *pVisionInfo)
{
	CopyMemory(pVisionInfo,m_PacketProc.m_cSubData,sizeof(SVISIONINFO));

	return TRUE;
}

BOOL CClientSock_Cognex::Pasing_PMToolFind(int nCam)
{
	CopyMemory(&gProcess.m_ResultData[nCam],m_PacketProc.m_cSubData,sizeof(RESULT_DATA));
	return TRUE;
}
BOOL CClientSock_Cognex::Pasing_GetNoGrabRealPosFor4Way()
{
	CopyMemory(&gVariable.m_dVisionOffsetFor4Way_mm,m_PacketProc.m_cSubData,sizeof(CDPoint)*4);
	return TRUE;
}
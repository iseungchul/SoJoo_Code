// ScannerBiCubic.h: interface for the CScannerBiCubic class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCANNERBICUBIC_H__0A9E2F64_DC1F_46E1_8979_A8FE712903BE__INCLUDED_)
#define AFX_SCANNERBICUBIC_H__0A9E2F64_DC1F_46E1_8979_A8FE712903BE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ScannerCalibration.h"
#include "BicubicInterpolation.h" // COEF ����ϱ� ���ؼ�

class AFX_EXT_CLASS CScannerBiCubic : public CScannerCalibration  
{
public:
	CScannerBiCubic();
	virtual ~CScannerBiCubic();

protected:
	DPOINT* m_XGradient;
	DPOINT* m_YGradient;
	DPOINT* m_CrossDeriv;

	COEF* m_Coef;

	int m_nXStart, m_nXEnd, m_nYStart, m_nYEnd;

	void UpdateWholeCalibration();
	
	void GetPartialCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset);

	BOOL MakeDerivatives();
	BOOL MakeCoefficient();
	void SetCoefficient(double* dVal, double* dXGra, double* dYGra, double* dCross, int nX, int nY, bool bIsX);

	void DeleteMemory();

};

#endif // !defined(AFX_SCANNERBICUBIC_H__0A9E2F64_DC1F_46E1_8979_A8FE712903BE__INCLUDED_)

#pragma once
class CDevMCCDaq
{
public:
	CDevMCCDaq(void);
	~CDevMCCDaq(void);

	void SetParameter(int nPortNo, int nBaudRate, int nParity, int nDataBits, int nStopBits, int nFlowControl);
	void SetChannelIndex(int nMTC1, int nMTC2, int nMSB1, int nMSB2, int nSTC1, int nSTC2, int nSSB1, int nSSB2);
	void SetTemperLimit(double dDiff, double dMin, double dMax, double dDelta);
	BOOL PortOpened();
	BOOL Create();
	void Destroy();
	void ReadTemperature();
	double GetTemperature(int nMainIndex);
	BOOL GetTemperature(double* pdTempVal);
	void ReadAddress();

	int			m_nTCMasterCH1;
	int			m_nTCMasterCH2;
	int			m_nTCSlaveCH1;
	int			m_nTCSlaveCH2;
	int			m_nSBMasterCH1;
	int			m_nSBMasterCH2;
	int			m_nSBSlaveCH1;
	int			m_nSBSlaveCH2;

	double m_dTemperDiff;
	double m_dTemperMinLimit;
	double m_dTemperMaxLimit;
	double m_dTemperDeltaTLimit;

	BOOL m_bPortOpen;

	double m_dTemperature[10];
	double m_dOldTemperature[5][10];
	time_t  m_TemperatureSaveTime[10];
	
protected:
  	CRITICAL_SECTION	m_csCommunicationSync;
};


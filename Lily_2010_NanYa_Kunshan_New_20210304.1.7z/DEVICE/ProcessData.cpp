// ProcessData.cpp : implementation file
//

#include "stdafx.h"
#include "..\EasyDriller.h"
#include "ProcessData.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ProcessData

ProcessData::ProcessData()
{
}

ProcessData::~ProcessData()
{
}


BEGIN_MESSAGE_MAP(ProcessData, CWnd)
	//{{AFX_MSG_MAP(ProcessData)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// ProcessData message handlers




void ProcessData::GetTrainCoord(double cx, double cy, int PatternNo)
{
	m_AlignData[PatternNo].X = cx;
	m_AlignData[PatternNo].Y = cy;

}


// CalibrationPath.cpp: implementation of the CCalibrationPath class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\sysdef.h"
#include "CalibrationPath.h"
#include "..\model\GlobalVariable.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCalibrationPath::CCalibrationPath()
{
	InitializeVariable();
	m_pusVal = NULL;
}

CCalibrationPath::~CCalibrationPath()
{
	if (m_pusVal)
		delete [] m_pusVal;
}

inline double CCalibrationPath::Distance(double x1, double y1, double x2, double y2)
{
	return ((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

inline int CCalibrationPath::GetIndex(int nx, int ny)
{
	return nx * m_nSize + ny;
}

inline BOOL CCalibrationPath::GetIndex(int nIndex, int& nx, int& ny)
{
	ny = nIndex % m_nSize;
	nx = (nIndex - ny) / m_nSize;
	return TRUE;
}

void CCalibrationPath::InitializeVariable()
{
	m_emDirection = emHor;
	m_emHorDir = emRight;
	m_emVerDir = emBottom;
	
	m_nCurIndex = 0;
	m_nMaxIndex = 0;
	m_nSize = 0;

	m_nSpecialPointType = 0;
	m_nTurningPointType = 0;

	m_bReady = false;
}

BOOL CCalibrationPath::SetCalibrationGridSize(int nSize)
{
	if (m_pusVal)
	{
		delete [] m_pusVal;
		m_pusVal = NULL;
	}

	if (nSize < 2 || nSize % 2 == 0)
	{
		InitializeVariable();
		return FALSE;
	}

	TRY
	{
		m_pusVal = new USHORT[2 * nSize * nSize];
	}
	CATCH(CMemoryException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH

	InitializeVariable();
	m_nSize = nSize;
	m_nMaxIndex = nSize * nSize;

	for (int i = 0; i < m_nSize; i++)
	{
		for (int j = 0; j < m_nSize; j++)
		{
			m_pusVal[GetIndex(i, j)] = static_cast<unsigned short>(0.5 + i * (MAXLSB / (m_nSize - 1.0)));
			m_pusVal[GetIndex(i, j) + m_nMaxIndex] = static_cast<unsigned short>(0.5 + j * (MAXLSB / (m_nSize - 1.0)));
		}
	}

	return TRUE;
}

BOOL CCalibrationPath::GetClosestLSB(USHORT xPos, USHORT yPos, USHORT& xLSB, USHORT& yLSB)
{
	if (m_pusVal == NULL)
		return FALSE;

	double dDist, dMinDist = 4.0 * MAXLSB * MAXLSB;
	for (int n = 0; n < m_nMaxIndex; n++)
	{
		if (dMinDist > (dDist = Distance(xPos, yPos, m_pusVal[n], m_pusVal[n + m_nMaxIndex])))
		{
			dMinDist = dDist;
			xLSB = m_pusVal[n];
			yLSB = m_pusVal[n + m_nMaxIndex];
		}
	}

	if (dMinDist == 4.0 * MAXLSB * MAXLSB)
		return FALSE;
	else
		return TRUE;
}

int CCalibrationPath::GetClosestLSBIndex(USHORT x, USHORT y)
{
	if (m_pusVal == NULL)
		return FALSE;
	
	double dDist, dMinDist = 4.0 * MAXLSB * MAXLSB;
	int nMin = 0;
	for (int n = 0, nMin = 0; n < m_nMaxIndex; n++)
	{
		if (dMinDist > (dDist = Distance(x, y, m_pusVal[n], m_pusVal[n + m_nMaxIndex])))
		{
			dMinDist = dDist;
			nMin = n;
		}
	}
	
	if (dMinDist == 4.0 * MAXLSB * MAXLSB)
		return -1;
	else
		return nMin;
}

BOOL CCalibrationPath::SetCalibrationGridIndex(int nIndex)
{
	if (m_pusVal == NULL)
		return FALSE;

	if (nIndex < 0 || nIndex >= m_nMaxIndex)
		return FALSE;

	m_nCurIndex = nIndex;
	return TRUE;
}

BOOL CCalibrationPath::SetCalibrationGridIndex(double x, double y)
{
	if (m_pusVal == NULL)
		return FALSE;

	int nIndex = GetClosestLSBIndex((USHORT)x, (USHORT)y);
	if (nIndex == -1)
		return FALSE;
	else
	{
		m_nCurIndex = nIndex;
		return TRUE;
	}
}

BOOL CCalibrationPath::IsSpecialPoint(int nIndex)
{
	if (m_pusVal == NULL)
		return FALSE;

	if (nIndex == GetIndex(0, m_nSize - 2))
		m_nSpecialPointType = 1;
	else if (nIndex == GetIndex(0, m_nSize - 1))
		m_nSpecialPointType = 2;
	else if (nIndex == GetIndex(1, m_nSize - 1))
		m_nSpecialPointType = 3;
	else if (nIndex == GetIndex(1, m_nSize - 2))
		m_nSpecialPointType = 4;
	else if (nIndex == GetIndex(m_nSize - 2, 0))
		m_nSpecialPointType = 5;
	else if (nIndex == GetIndex(m_nSize - 3, 0))
		m_nSpecialPointType = 6;
	else if (nIndex == GetIndex(m_nSize - 1, m_nSize - 1))
		m_nSpecialPointType = 7;
	else
		m_nSpecialPointType = 0;

	if (m_nSpecialPointType)
		return TRUE;
	else
		return FALSE;
}

void CCalibrationPath::SetNextLSBIndexInSpecial()
{
	switch (m_nSpecialPointType)
	{
	case 1:
		m_nCurIndex = GetIndex(0, m_nSize - 1);
		break;
	case 2:
		m_nCurIndex = GetIndex(1, m_nSize - 1);
		break;
	case 3:
		m_nCurIndex = GetIndex(1, m_nSize - 2);
		break;
	case 4:
		m_nCurIndex = GetIndex(2, m_nSize - 1);
		m_emDirection = emHor;
		m_emHorDir = emRight;
		break;
	case 5:
		m_nCurIndex = GetIndex(m_nSize - 3, 0);
		break;
	case 6:
		m_nCurIndex = GetIndex(m_nSize - 3, 1);
		m_emDirection = emVer;
		m_emVerDir = emTop;
		break;
	case 7:
		m_nCurIndex = GetIndex(m_nSize - 1, m_nSize - 2);
		m_emDirection = emVer;
		m_emVerDir = emBottom;
		break;
	}
}

BOOL CCalibrationPath::IsTurningPoint(int nIndex)
{
	if (m_pusVal == NULL)
		return FALSE;

	int nx, ny;
	GetIndex(nIndex, nx, ny);

	if (ny == -nx + m_nSize - 1)
		m_nTurningPointType = 1;
	else if (ny == -nx + m_nSize - 2)
		m_nTurningPointType = 2;
	else if (ny == m_nSize - 2 && nx != m_nSize - 1 && nx > 1)
		m_nTurningPointType = 3;
	else if (ny == 0 && nx < m_nSize - 3)
		m_nTurningPointType = 4;
	else
		m_nTurningPointType = 0;

	if (m_nTurningPointType)
		return TRUE;
	else
		return FALSE;
}

void CCalibrationPath::SetNextLSBIndexInTurning()
{
	int nx, ny;

	m_emDirection = (m_emDirection == emVer) ? emHor : emVer;
	switch (m_nTurningPointType)
	{
	case 1:
		if (m_emDirection == emHor)
		{
			if (m_emVerDir == emBottom)
				m_emHorDir = emLeft;
		}
		else
		{
			if (m_emHorDir == emRight)
				m_emVerDir = emTop;
		}
		
		GetIndex(m_nCurIndex, nx, ny);
		if (m_emDirection == emHor)
			m_nCurIndex = GetIndex(nx - 1, ny);
		else
			m_nCurIndex = GetIndex(nx, ny + 1);

		break;

	case 2:
		if (m_emDirection == emHor)
		{
			if (m_emVerDir == emTop)
				m_emHorDir = emRight;
		}
		else
		{
			if (m_emHorDir == emLeft)
				m_emVerDir = emBottom;
		}

		GetIndex(m_nCurIndex, nx, ny);
		if (m_emDirection == emHor)
			m_nCurIndex = GetIndex(nx + 1, ny);
		else
			m_nCurIndex = GetIndex(nx, ny - 1);

		break;
		
	case 3:
		if (m_emDirection == emHor)
		{
			if (m_emVerDir == emTop)
				m_emHorDir = emLeft;
		}
		else
		{
			if (m_emHorDir == emLeft)
				m_emVerDir = emBottom;
		}

		GetIndex(m_nCurIndex, nx, ny);
		if (m_emDirection == emHor)
			m_nCurIndex = GetIndex(nx - 1, ny);
		else
			m_nCurIndex = GetIndex(nx, ny - 1);

		break;
	case 4:
		if (m_emDirection == emHor)
		{
			if (m_emVerDir == emBottom)
				m_emHorDir = emLeft;
		}
		else
		{
			if (m_emHorDir == emLeft)
				m_emVerDir = emTop;
		}

		GetIndex(m_nCurIndex, nx, ny);
		if (m_emDirection == emHor)
			m_nCurIndex = GetIndex(nx - 1, ny);
		else
			m_nCurIndex = GetIndex(nx, ny + 1);

		break;
	}
}

void CCalibrationPath::SetNextLSBIndexInNormal()
{
	int nx, ny;
	GetIndex(m_nCurIndex, nx, ny);

	if (m_emDirection == emHor)
	{
		if (m_emHorDir == emRight)
			m_nCurIndex = GetIndex(nx + 1, ny);
		else
			m_nCurIndex = GetIndex(nx - 1, ny);
	}
	else
	{
		if (m_emVerDir == emTop)
			m_nCurIndex = GetIndex(nx, ny + 1);
		else
			m_nCurIndex = GetIndex(nx, ny - 1);
	}
}

BOOL CCalibrationPath::GetNextLSB(USHORT& x, USHORT& y)
{
	if (m_pusVal == NULL || m_bReady == false)
		return FALSE;

	if (IsSpecialPoint(m_nCurIndex))
	{
		SetNextLSBIndexInSpecial();
	}
	else if (IsTurningPoint(m_nCurIndex))
	{
		SetNextLSBIndexInTurning();
	}
	else
	{
		SetNextLSBIndexInNormal();
	}
	x = m_pusVal[m_nCurIndex];
	y = m_pusVal[m_nCurIndex + m_nMaxIndex];

	return TRUE;
}


BOOL CCalibrationPath::GetNextLSBXYORDER_Use_vm(double& x, double& y, int nDivision, int nIndex, int nXYORDER) // yhchung 060802
{
	int nX, nY;

	if(gVariable.m_bDo4WayScal == TRUE)
	{

		if(gVariable.m_nFireCountFor4Way == LEFT_TO_RIGHT)//�� -> ��
		{
			nX = nIndex % nDivision;
			nY = nIndex / nDivision;

			x =  nX * (65535. / (nDivision - 1));
			y = nY * (65535. / (nDivision - 1));;

		}
		else if(gVariable.m_nFireCountFor4Way == RIGHT_TO_LEFT)//�� -> ��
		{
			nX = nIndex % nDivision;
			nY = nIndex / nDivision;

			nX = nDivision - nX - 1;

			x = (nX * (65535. / (nDivision - 1)));
			y = (nY * (65535. / (nDivision - 1)));;

		}
		else if(gVariable.m_nFireCountFor4Way == BOTTOM_TO_TOP)//�� -> ��
		{
			nX = nIndex / nDivision;
			nY = nIndex % nDivision;

			x = (nX * (65535. / (nDivision - 1)));
			y = (nY * (65535. / (nDivision - 1)));

		}
		else //�� -> ��
		{
			nX = nIndex / nDivision;
			nY = nIndex % nDivision;

			nY = nDivision - nY - 1;

			x = (nX * (65535. / (nDivision - 1)));
			y = (nY * (65535. / (nDivision - 1)));

		}

		return TRUE;
	}





	 if(nXYORDER == 1)
	{
		nX = nIndex % nDivision;
		nY = nIndex / nDivision;

		if(nY%2)
			nX = nDivision - nX - 1;

		x = (nX * (65535. / (nDivision - 1)));
		//	y = USHORT(nY * (65535. / (nDivision - 1)));;
		y = ((nDivision - nY - 1) * (65535. / (nDivision - 1)));

	}
	else
	{
		nX = nIndex / nDivision;
		nY = nIndex % nDivision;

		if(nX%2)
			nY = nDivision - nY - 1;

		x = (nX * (65535. / (nDivision - 1)));
		y = (nY * (65535. / (nDivision - 1)));
	}

	return TRUE;
}


BOOL CCalibrationPath::GetFirstLSB(USHORT& x, USHORT& y)
{
	if (m_pusVal == NULL)
		return FALSE;

	int nCurIndex = m_nCurIndex;

	m_bReady = TRUE;
	m_nCurIndex = GetIndex(0, m_nSize - 1);
	while (m_nCurIndex != nCurIndex)
		GetNextLSB(x, y);

	x = m_pusVal[m_nCurIndex];
	y = m_pusVal[m_nCurIndex + m_nMaxIndex];
	
	return TRUE;
}

BOOL CCalibrationPath::GetLSB(int nx, int ny, USHORT& x, USHORT& y)
{
	if (m_pusVal == NULL || nx < 0 || nx >= m_nMaxIndex || ny < 0 || ny >= m_nMaxIndex)
		return FALSE;

	int i = GetIndex(nx, ny);
	x = m_pusVal[i];
	y = m_pusVal[i + m_nMaxIndex];

	return TRUE;
}
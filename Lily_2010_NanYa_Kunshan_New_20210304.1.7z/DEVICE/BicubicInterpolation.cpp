// BicubicInterpolation.cpp: implementation of the CBicubicInterpolation class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "BicubicInterpolation.h"
#include <cmath>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

const int MIN_GRID_SIZE = 4;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBicubicInterpolation::CBicubicInterpolation()
{
	m_XGradient = m_YGradient = m_CrossDeriv = NULL;
	m_Coef = NULL;
	m_d1 = m_d2 = m_d3 = m_d4 = NULL;
	m_nXStart = m_nXEnd = m_nYStart = m_nYEnd = 0;
}

CBicubicInterpolation::~CBicubicInterpolation()
{
	DeleteMemory();
}

void CBicubicInterpolation::DeleteMemory()
{
	delete [] m_XGradient;	m_XGradient = NULL;
	delete [] m_YGradient;	m_YGradient = NULL;
	delete [] m_CrossDeriv;	m_CrossDeriv = NULL;
	delete [] m_Coef;		m_Coef = NULL;
	delete [] m_d1;			m_d1 = NULL;
	delete [] m_d2;			m_d2 = NULL;
	delete [] m_d3;			m_d3 = NULL;
	delete [] m_d4;			m_d4 = NULL;
}

void CBicubicInterpolation::UpdateWholeCalibration()
{
	if (!m_bIsSet)
		return;

	if (m_nGridX < MIN_GRID_SIZE || m_nGridY < MIN_GRID_SIZE)
		return;

	if (!MakeDerivatives())
		return;

	if (!MakeCoefficient())
		return;

	m_nXStart = m_dXStart > MIN_TABLE ? (fmod(m_dXStart, 1.0) == 0.0 ? static_cast<int>(m_dXStart) : static_cast<int>(m_dXStart + 1)) : MIN_TABLE;
	m_nXEnd = m_dXEnd > MAX_TABLE ? MAX_TABLE : static_cast<int>(m_dXEnd);
	m_nYStart = m_dYStart > MIN_TABLE ? (fmod(m_dYStart, 1.0) == 0.0 ? static_cast<int>(m_dYStart) : static_cast<int>(m_dYStart + 1)) : MIN_TABLE;
	m_nYEnd = m_dYEnd > MAX_TABLE ? MAX_TABLE : static_cast<int>(m_dYEnd);

	for (int nX = m_nXStart; nX <= m_nXEnd; nX++)
	{
		for (int nY = m_nYStart; nY <= m_nYEnd; nY++)
		{
			double dX, dY;
			GetPartialCalibrationOffset(nX, nY, dX, dY);
			m_Matrix[nX][nY].x += static_cast<float>(dX);
			m_Matrix[nX][nY].y += static_cast<float>(dY);
		}
	}

	TRY
	{
		m_d1 = new DPOINT[m_nXEnd - m_nXStart + 1];
		m_d2 = new DPOINT[m_nYEnd - m_nYStart + 1];
		m_d3 = new DPOINT[m_nYEnd - m_nYStart + 1];
		m_d4 = new DPOINT[m_nXEnd - m_nXStart + 1];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		DeleteMemory();

		return;
	}
	END_CATCH

	for (int nX = m_nXStart; nX <= m_nXEnd; nX++)
	{
		double dX, dY;
		GetPartialCalibrationOffset(nX, m_nYStart, dX, dY);
		m_d1[nX - m_nXStart].x = dX;
		m_d1[nX - m_nXStart].y = dY;
		
		GetPartialCalibrationOffset(nX, m_nYEnd, dX, dY);
		m_d4[nX - m_nXStart].x = dX;
		m_d4[nX - m_nXStart].y = dY;
	}
	
	for (int nY = m_nYStart; nY <= m_nYEnd; nY++)
	{
		double dX, dY;
		GetPartialCalibrationOffset(m_nXStart, nY, dX, dY);
		m_d2[nY - m_nYStart].x = dX;
		m_d2[nY - m_nYStart].y = dY;
		
		GetPartialCalibrationOffset(m_nXEnd, nY, dX, dY);
		m_d3[nY - m_nYStart].x = dX;
		m_d3[nY - m_nYStart].y = dY;
	}
	
	for (int nX = MIN_TABLE; nX <= MAX_TABLE; nX++)
	{
		for (int nY = MIN_TABLE; nY <= MAX_TABLE; nY++)
		{
			if (!IsPartialInside(nX, nY))
			{
				double dX, dY;
				GetEdgeCalibrationOffset(nX, nY, dX, dY);
				m_Matrix[nX][nY].x += static_cast<float>(dX);
				m_Matrix[nX][nY].y += static_cast<float>(dY);

#ifdef __TEST__
			//	TRACE("%d %d %.3f %.3f\n",nX,nY,dX,dY);
#endif

			}
		}
	}
}

BOOL CBicubicInterpolation::MakeCoefficient()
{
	TRY
	{
		delete [] m_Coef;
		m_Coef = NULL;
		
		m_Coef = new COEF[(m_nGridX - 1) * (m_nGridY - 1)];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		
		DeleteMemory();
		
		return FALSE;
	}
	END_CATCH

	double dVal[4], dXGra[4], dYGra[4], dCross[4];
	for (int i = 0; i < m_nGridX - 1; i++)
	{
		for (int j = 0; j < m_nGridY - 1; j++)
		{
			dVal[0] = m_Offset[m_nGridY * i + j].x;
			dVal[1] = m_Offset[m_nGridY * (i + 1) + j].x;
			dVal[2] = m_Offset[m_nGridY * (i + 1) + j + 1].x;
			dVal[3] = m_Offset[m_nGridY * i + j + 1].x;

			dXGra[0] = m_XGradient[m_nGridY * i + j].x;
			dXGra[1] = m_XGradient[m_nGridY * (i + 1) + j].x;
			dXGra[2] = m_XGradient[m_nGridY * (i + 1) + j + 1].x;
			dXGra[3] = m_XGradient[m_nGridY * i + j + 1].x;

			dYGra[0] = m_YGradient[m_nGridY * i + j].x;
			dYGra[1] = m_YGradient[m_nGridY * (i + 1) + j].x;
			dYGra[2] = m_YGradient[m_nGridY * (i + 1) + j + 1].x;
			dYGra[3] = m_YGradient[m_nGridY * i + j + 1].x;

			dCross[0] = m_CrossDeriv[m_nGridY * i + j].x;
			dCross[1] = m_CrossDeriv[m_nGridY * (i + 1) + j].x;
			dCross[2] = m_CrossDeriv[m_nGridY * (i + 1) + j + 1].x;
			dCross[3] = m_CrossDeriv[m_nGridY * i + j + 1].x;

			SetCoefficient(dVal, dXGra, dYGra, dCross, i, j, TRUE);

			dVal[0] = m_Offset[m_nGridY * i + j].y;
			dVal[1] = m_Offset[m_nGridY * (i + 1) + j].y;
			dVal[2] = m_Offset[m_nGridY * (i + 1) + j + 1].y;
			dVal[3] = m_Offset[m_nGridY * i + j + 1].y;
			
			dXGra[0] = m_XGradient[m_nGridY * i + j].y;
			dXGra[1] = m_XGradient[m_nGridY * (i + 1) + j].y;
			dXGra[2] = m_XGradient[m_nGridY * (i + 1) + j + 1].y;
			dXGra[3] = m_XGradient[m_nGridY * i + j + 1].y;
			
			dYGra[0] = m_YGradient[m_nGridY * i + j].y;
			dYGra[1] = m_YGradient[m_nGridY * (i + 1) + j].y;
			dYGra[2] = m_YGradient[m_nGridY * (i + 1) + j + 1].y;
			dYGra[3] = m_YGradient[m_nGridY * i + j + 1].y;
			
			dCross[0] = m_CrossDeriv[m_nGridY * i + j].y;
			dCross[1] = m_CrossDeriv[m_nGridY * (i + 1) + j].y;
			dCross[2] = m_CrossDeriv[m_nGridY * (i + 1) + j + 1].y;
			dCross[3] = m_CrossDeriv[m_nGridY * i + j + 1].y;
			
			SetCoefficient(dVal, dXGra, dYGra, dCross, i, j, false);
		}
	}

	return TRUE;
}

void CBicubicInterpolation::SetCoefficient(double* dVal, double* dXGra, double* dYGra, double* dCross, int nX, int nY, bool bIsX)
{
	static int nWeight[16 * 16] =
	{
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
		-3, 0, 0, 3, 0, 0, 0, 0, -2, 0, 0, -1, 0, 0, 0, 0,
		2, 0, 0, -2, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0,
		0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
		0, 0, 0, 0, -3, 0, 0, 3, 0, 0, 0, 0, -2, 0, 0, -1,
		0, 0, 0, 0, 2, 0, 0, -2, 0, 0, 0, 0, 1, 0, 0, 1,
		-3, 3, 0, 0, -2, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, -3, 3, 0, 0, -2, -1, 0, 0,
		9, -9, 9, -9, 6, 3, -3, -6, 6, -6, -3, 3, 4, 2, 1, 2,
		-6, 6, -6, 6, -4, -2, 2, 4, -3, 3, 3, -3, -2, -1, -1, -2,
		2, -2, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 2, -2, 0, 0, 1, 1, 0, 0,
		-6, 6, -6, 6, -3, -3, 3, 3, -4, 4, 2, -2, -2, -2, -1, -1,
		4, -4, 4, -4, 2, 2, -2, -2, 2, -2, -2, 2, 1, 1, 1, 1
	};

	double cl[16], x[16];

	for (int i = 0; i < 4; i++)
	{
		x[i] = dVal[i];
		x[i + 4] = dXGra[i] * m_dGap;
		x[i + 8] = dYGra[i] * m_dGap;
		x[i + 12] = dCross[i] * m_dGap * m_dGap;
	}

	for(int i =  0; i < 16; i++)
	{
		double xx = 0.0;
		for (int j = 0; j < 16; j++)
			xx += nWeight[16 * i + j] * x[j];
		cl[i] = xx;
	}

	int k = 0;
	for(int i =  0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (bIsX)
				m_Coef[(m_nGridY - 1) * nX + nY].dCoef[i][j].x = cl[k++];
			else
				m_Coef[(m_nGridY - 1) * nX + nY].dCoef[i][j].y = cl[k++];
		}
	}
}

BOOL CBicubicInterpolation::MakeDerivatives()
{
	TRY
	{
		DeleteMemory();

		m_XGradient = new DPOINT[m_nGridX * m_nGridY];
		m_YGradient = new DPOINT[m_nGridX * m_nGridY];
		m_CrossDeriv = new DPOINT[m_nGridX * m_nGridY];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		DeleteMemory();
		
		return FALSE;
	}
	END_CATCH

	for (int i = 0; i < m_nGridX; i++)
	{
		for (int j = 0; j < m_nGridY; j++)
		{
			if (i == m_nGridX - 1)
			{
				m_XGradient[m_nGridY * i + j].x = (m_Offset[m_nGridY * i + j].x - m_Offset[m_nGridY * (i - 1) + j].x) / m_dGap;
				m_XGradient[m_nGridY * i + j].y = (m_Offset[m_nGridY * i + j].y - m_Offset[m_nGridY * (i - 1) + j].y) / m_dGap;
			}
			else if (i == 0)
			{
				m_XGradient[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j].x - m_Offset[m_nGridY * i + j].x) / m_dGap;
				m_XGradient[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j].y - m_Offset[m_nGridY * i + j].y) / m_dGap;
			}
			else
			{
				m_XGradient[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j].x - m_Offset[m_nGridY * (i - 1) + j].x) / (m_dGap * 2.0);
				m_XGradient[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j].y - m_Offset[m_nGridY * (i - 1) + j].y) / (m_dGap * 2.0);
			}

			if (j == m_nGridY - 1)
			{
				m_YGradient[m_nGridY * i + j].x = (m_Offset[m_nGridY * i + j].x - m_Offset[m_nGridY * i + j - 1].x) / m_dGap;
				m_YGradient[m_nGridY * i + j].y = (m_Offset[m_nGridY * i + j].y - m_Offset[m_nGridY * i + j - 1].y) / m_dGap;
			}
			else if (j == 0)
			{
				m_YGradient[m_nGridY * i + j].x = (m_Offset[m_nGridY * i + j + 1].x - m_Offset[m_nGridY * i + j].x) / m_dGap;
				m_YGradient[m_nGridY * i + j].y = (m_Offset[m_nGridY * i + j + 1].y - m_Offset[m_nGridY * i + j].y) / m_dGap;
			}
			else
			{
				m_YGradient[m_nGridY * i + j].x = (m_Offset[m_nGridY * i + j + 1].x - m_Offset[m_nGridY * i + j - 1].x) / (m_dGap * 2.0);
				m_YGradient[m_nGridY * i + j].y = (m_Offset[m_nGridY * i + j + 1].y - m_Offset[m_nGridY * i + j - 1].y) / (m_dGap * 2.0);
			}

			if (i == 0 && j == 0)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j + 1].x - m_Offset[m_nGridY * (i + 1) + j].x
					- m_Offset[m_nGridY * i + j + 1].x + m_Offset[m_nGridY * i + j].x) / m_dGap / m_dGap;
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j + 1].y - m_Offset[m_nGridY * (i + 1) + j].y
					- m_Offset[m_nGridY * i + j + 1].y + m_Offset[m_nGridY * i + j].y) / m_dGap / m_dGap;
			}
			else if (i == 0 && j == m_nGridY - 1)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j].x - m_Offset[m_nGridY * (i + 1) + j - 1].x
					- m_Offset[m_nGridY * i + j].x + m_Offset[m_nGridY * i + j - 1].x) / m_dGap / m_dGap;
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j].y - m_Offset[m_nGridY * (i + 1) + j - 1].y
					- m_Offset[m_nGridY * i + j].y + m_Offset[m_nGridY * i + j - 1].y) / m_dGap / m_dGap;
			}
			else if (i == m_nGridX - 1 && j == 0)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * i + j + 1].x - m_Offset[m_nGridY * i + j].x
					- m_Offset[m_nGridY * (i - 1) + j + 1].x + m_Offset[m_nGridY * (i - 1) + j].x) / m_dGap / m_dGap;
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * i + j + 1].y - m_Offset[m_nGridY * i + j].y
					- m_Offset[m_nGridY * (i - 1) + j + 1].y + m_Offset[m_nGridY * (i - 1) + j].y) / m_dGap / m_dGap;
			}
			else if (i == m_nGridX - 1 && j == m_nGridY - 1)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * i + j].x - m_Offset[m_nGridY * i + j - 1].x
					- m_Offset[m_nGridY * (i - 1) + j].x + m_Offset[m_nGridY * (i - 1) + j - 1].x) / m_dGap / m_dGap;
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * i + j].y - m_Offset[m_nGridY * i + j - 1].y
					- m_Offset[m_nGridY * (i - 1) + j].y + m_Offset[m_nGridY * (i - 1) + j - 1].y) / m_dGap / m_dGap;
			}
			else if (i == 0 && j != 0 && j != m_nGridY - 1)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j + 1].x - m_Offset[m_nGridY * (i + 1) + j - 1].x
					- m_Offset[m_nGridY * i + j + 1].x + m_Offset[m_nGridY * i + j - 1].x) / m_dGap / (m_dGap * 2.0);
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j + 1].y - m_Offset[m_nGridY * (i + 1) + j - 1].y
					- m_Offset[m_nGridY * i + j + 1].y + m_Offset[m_nGridY * i + j - 1].y) / m_dGap / (m_dGap * 2.0);
			}
			else if (i == m_nGridX - 1 && j != 0 && j != m_nGridY - 1)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * i + j + 1].x - m_Offset[m_nGridY * i + j - 1].x
					- m_Offset[m_nGridY * (i - 1) + j + 1].x + m_Offset[m_nGridY * (i - 1) + j - 1].x) / m_dGap / (m_dGap * 2.0);
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * i + j + 1].y - m_Offset[m_nGridY * i + j - 1].y
					- m_Offset[m_nGridY * (i - 1) + j + 1].y + m_Offset[m_nGridY * (i - 1) + j - 1].y) / m_dGap / (m_dGap * 2.0);
			}
			else if (i != 0 && i != m_nGridX - 1 && j == 0)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j + 1].x - m_Offset[m_nGridY * (i + 1) + j].x
					- m_Offset[m_nGridY * (i - 1) + j + 1].x + m_Offset[m_nGridY * (i - 1) + j].x) / (m_dGap * 2.0) / m_dGap;
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j + 1].y - m_Offset[m_nGridY * (i + 1) + j].y
					- m_Offset[m_nGridY * (i - 1) + j + 1].y + m_Offset[m_nGridY * (i - 1) + j].y) / (m_dGap * 2.0) / m_dGap;
			}
			else if (i != 0 && i != m_nGridX - 1 && j == m_nGridY - 1)
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j].x - m_Offset[m_nGridY * (i + 1) + j - 1].x
					- m_Offset[m_nGridY * (i - 1) + j].x + m_Offset[m_nGridY * (i - 1) + j - 1].x) / (m_dGap * 2.0) / m_dGap;
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j].y - m_Offset[m_nGridY * (i + 1) + j - 1].y
					- m_Offset[m_nGridY * (i - 1) + j].y + m_Offset[m_nGridY * (i - 1) + j - 1].y) / (m_dGap * 2.0) / m_dGap;
			}
			else
			{
				m_CrossDeriv[m_nGridY * i + j].x = (m_Offset[m_nGridY * (i + 1) + j + 1].x - m_Offset[m_nGridY * (i + 1) + j - 1].x
					- m_Offset[m_nGridY * (i - 1) + j + 1].x + m_Offset[m_nGridY * (i - 1) + j - 1].x) / (m_dGap * 2.0) / (m_dGap * 2.0);
				m_CrossDeriv[m_nGridY * i + j].y = (m_Offset[m_nGridY * (i + 1) + j + 1].y - m_Offset[m_nGridY * (i + 1) + j - 1].y
					- m_Offset[m_nGridY * (i - 1) + j + 1].y + m_Offset[m_nGridY * (i - 1) + j - 1].y) / (m_dGap * 2.0) / (m_dGap * 2.0);
			}
		}
	}

	return TRUE;
}

void CBicubicInterpolation::GetPartialCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset)
{
	if (IsPartialInside(dX, dY))
	{
		// index = m_nGridY * nX + nY
		int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
		int nY = static_cast<int>((dY - m_dYStart) / m_dGap);
		if (nX == m_nGridX - 1)		nX = m_nGridX - 2;
		if (nY == m_nGridY - 1)		nY = m_nGridY - 2;
		
		double t = (dX - m_dXStart - m_dGap * nX) / m_dGap;
		double u = (dY - m_dYStart - m_dGap * nY) / m_dGap;
		
		DPOINT dCoef[4][4];
		memcpy(dCoef, m_Coef[(m_nGridY - 1) * nX + nY].dCoef, sizeof(DPOINT) * 16);

		dXOffset = dYOffset = 0.0;
		for (int i = 3; i >= 0; i--)
		{
			dXOffset = t * dXOffset + ((dCoef[i][3].x * u + dCoef[i][2].x) * u + dCoef[i][1].x) * u + dCoef[i][0].x;
			dYOffset = t * dYOffset + ((dCoef[i][3].y * u + dCoef[i][2].y) * u + dCoef[i][1].y) * u + dCoef[i][0].y;
		}
	}
	else
	{
		dXOffset = dYOffset = 0.0;
	}
}
/*
void CBicubicInterpolation::GetEdgeCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset)
{
	if (dX < m_dXStart && dY < m_dYStart)
	{
		double dXDist = dX;
		double dYDist = dY;
		
		double ax = 0.0;
		double bx = m_d1[0].x * dXDist / m_nXStart;
		double ay = 0.0;
		double by = m_d1[0].y * dYDist / m_nYStart;
		
		dXOffset = ax + (bx - ax) * dYDist / m_nYStart;
		dYOffset = ay + (by - ay) * dXDist / m_nXStart;
	}
	else if (dX >= m_dXStart && dX <= m_dXEnd && dY < m_dYStart)
	{
		int nX = static_cast<int>(dX - m_nXStart);
		if (nX < 0)	nX = 0;
		
		dXOffset = m_d1[nX].x * dY / m_nYStart;
		dYOffset = m_d1[nX].y * dY / m_nYStart;
	}
	else if (dX > m_dXEnd && dY < m_dYStart)
	{
		double dXDist = dX - m_nXEnd;
		double dYDist = dY;
		
		double ax = 0.0;
		double bx = m_d1[m_nXEnd - m_nXStart].x - m_d1[m_nXEnd - m_nXStart].x * dXDist / (MAX_TABLE - m_nXEnd);
		double ay = m_d1[m_nXEnd - m_nXStart].y * dYDist / m_nYStart;
		double by = 0.0;
		
		dXOffset = ax + (bx - ax) * dYDist / m_nYStart;
		dYOffset = ay + (by - ay) * dXDist / (MAX_TABLE - m_nXEnd);
	}
	else if (dX < m_dXStart && dY >= m_dYStart && dY <= m_dYEnd)
	{
		int nY = static_cast<int>(dY - m_nYStart);
		if (nY < 0)	nY = 0;
		
		dXOffset = m_d2[nY].x * dX / m_nXStart;
		dYOffset = m_d2[nY].y * dX / m_nXStart;
	}
	else if (dX > m_dXEnd && dY >= m_dYStart && dY <= m_dYEnd)
	{
		int nY = static_cast<int>(dY - m_nYStart);
		if (nY < 0)	nY = 0;
		
		dXOffset = m_d3[nY].x - m_d3[nY].x * (dX - m_nXEnd) / (MAX_TABLE - m_nXEnd);
		dYOffset = m_d3[nY].y - m_d3[nY].y * (dX - m_nXEnd) / (MAX_TABLE - m_nXEnd);
	}
	else if (dX < m_dXStart && dY > m_dYEnd)
	{
		double dXDist = dX;
		double dYDist = dY - m_nYEnd;
		
		double ax = m_d4[0].x * dXDist / m_nXStart;
		double bx = 0.0;
		double ay = 0.0;
		double by = m_d4[0].y - m_d4[0].y * dYDist / (MAX_TABLE - m_nYEnd);
		
		dXOffset = ax + (bx - ax) * dYDist / (MAX_TABLE - m_nYEnd);
		dYOffset = ay + (by - ay) * dXDist / m_nXStart;
	}
	else if (dX >= m_dXStart && dX <= m_dXEnd && dY > m_dYEnd)
	{
		int nX = static_cast<int>(dX - m_nXStart);
		if (nX < 0)	nX = 0;
		
		dXOffset = m_d4[nX].x - m_d4[nX].x * (dY - m_nYEnd) / (MAX_TABLE - m_nYEnd);
		dYOffset = m_d4[nX].y - m_d4[nX].y * (dY - m_nYEnd) / (MAX_TABLE - m_nYEnd);
	}
	else if (dX > m_dXEnd && dY > m_dYEnd)
	{
		double dXDist = dX - m_nXEnd;
		double dYDist = dY - m_nYEnd;
		
		double ax = m_d4[m_nXEnd - m_nXStart].x - m_d4[m_nXEnd - m_nXStart].x * dXDist / (MAX_TABLE - m_nXEnd);
		double bx = 0.0;
		double ay = m_d4[m_nXEnd - m_nXStart].y - m_d4[m_nXEnd - m_nXStart].y * dYDist / (MAX_TABLE - m_nYEnd);;
		double by = 0.0;
		
		dXOffset = ax + (bx - ax) * dYDist / (MAX_TABLE - m_nYEnd);
		dYOffset = ay + (by - ay) * dXDist / (MAX_TABLE - m_nXEnd);
	}
	else
		dXOffset = dYOffset = 0.0;
}
*/

void CBicubicInterpolation::GetEdgeCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset)
{
	if (dX < m_dXStart && dY < m_dYStart)
	{
		dXOffset = m_d1[0].x;
		dYOffset = m_d1[0].y;
	}
	else if (dX >= m_dXStart && dX <= m_dXEnd && dY < m_dYStart)
	{
		int nX = static_cast<int>(dX - m_nXStart);
		if (nX < 0)	nX = 0;
		
		dXOffset = m_d1[nX].x;
		dYOffset = m_d1[nX].y;
	}
	else if (dX > m_dXEnd && dY < m_dYStart)
	{
		dXOffset = m_d1[m_nXEnd - m_nXStart].x;
		dYOffset = m_d1[m_nXEnd - m_nXStart].y;
	}
	else if (dX < m_dXStart && dY >= m_dYStart && dY <= m_dYEnd)
	{
		int nY = static_cast<int>(dY - m_nYStart);
		if (nY < 0)	nY = 0;
		
		dXOffset = m_d2[nY].x;
		dYOffset = m_d2[nY].y;
	}
	else if (dX > m_dXEnd && dY >= m_dYStart && dY <= m_dYEnd)
	{
		int nY = static_cast<int>(dY - m_nYStart);
		if (nY < 0)	nY = 0;
		
		dXOffset = m_d3[nY].x;
		dYOffset = m_d3[nY].y;
	}
	else if (dX < m_dXStart && dY > m_dYEnd)
	{
		dXOffset = m_d4[0].x;
		dYOffset = m_d4[0].y;
	}
	else if (dX >= m_dXStart && dX <= m_dXEnd && dY > m_dYEnd)
	{
		int nX = static_cast<int>(dX - m_nXStart);
		if (nX < 0)	nX = 0;
		
		dXOffset = m_d4[nX].x;
		dYOffset = m_d4[nX].y;
	}
	else if (dX > m_dXEnd && dY > m_dYEnd)
	{
		dXOffset = m_d4[m_nXEnd - m_nXStart].x;
		dYOffset = m_d4[m_nXEnd - m_nXStart].y;
	}
	else
		dXOffset = dYOffset = 0.0;
}

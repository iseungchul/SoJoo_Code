// DOnlineCmdData.cpp: implementation of the DOnlineCmdData class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "DOnlineCmdData.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DOnlineCmdData::DOnlineCmdData()
{
	memset( m_szOnlineCmd, 0, 100 );
	m_nLen			= 0;
	m_pfMemData		= NULL;
	m_pMemData		= NULL;
	m_nMemSize		= 0;
	m_dwOffset		= 0;
	m_bDPRamFlag	= FALSE;	// TRUE : DPRAM DATA, FALSE : ONLINE CMD
	m_bReadDPRam	= FALSE;	// FALSE : WRITE DPRAM, TRUE : READ DPRAM
	m_bIsFloat		= FALSE;	// FALSE : DWORD, TRUE : float
	m_nDataType		= 0;		// 1 : Handler Sys Download, 2 : Coater Sys Download
								// 3 : Handler Sys Upload,	 4 : Coater Sys Upload
}

DOnlineCmdData::~DOnlineCmdData()
{
	if( NULL != m_pfMemData )
	{
		delete[] m_pfMemData;

		m_pfMemData = NULL;
	}

	if( NULL != m_pMemData )
	{
		delete[] m_pMemData;

		m_pMemData = NULL;
	}
}

void DOnlineCmdData::SetOnlineCmd(char* szCmd)
{
	sprintf_s( m_szOnlineCmd, 100, "%s", szCmd );
	m_nLen = strlen( m_szOnlineCmd );
}

void DOnlineCmdData::SetDPRamFloatData(int nSize, DWORD dwOffset, float* pMemData)
{
	m_bDPRamFlag	= TRUE;
	m_bIsFloat		= TRUE;
	m_nMemSize		= nSize;
	m_dwOffset		= dwOffset;
	m_pfMemData		= new float[m_nMemSize];

	memset( m_pfMemData, 0, m_nMemSize / sizeof(float) );
	memcpy( m_pfMemData, pMemData, sizeof(float)*m_nMemSize);
}

void DOnlineCmdData::SetDPRamDWORDData(int nSize, DWORD dwOffset, DWORD* pMemData, BOOL bRead, int nDataType)
{
	m_bDPRamFlag	= TRUE;
	m_bReadDPRam	= bRead;
	m_bIsFloat		= FALSE;
	m_nMemSize		= nSize;
	m_dwOffset		= dwOffset;
	m_pMemData		= new DWORD[m_nMemSize];
	m_nDataType		= nDataType;

	memset( m_pMemData, 0, m_nMemSize / sizeof(DWORD));
	memcpy( m_pMemData, pMemData, sizeof(DWORD) * m_nMemSize);
}
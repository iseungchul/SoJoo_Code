// DHandlerMonitor.cpp: implementation of the DHandlerMonitor class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "DHandlerMonitor.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DHandlerMonitor gHandlerMonitor;

DHandlerMonitor::DHandlerMonitor()
{
	memset( &m_sStageIF, 0, sizeof(m_sStageIF) );
	memset( &m_sBarcodeIF, 0, sizeof(m_sBarcodeIF) );
	memset( &m_sOneShotIF, 0, sizeof(m_sOneShotIF) );
	memset( &m_sSysSensor, 0, sizeof(m_sSysSensor) );
	memset( &m_sSysDoor, 0, sizeof(m_sSysDoor) );
	memset( &m_sSysAir, 0, sizeof(m_sSysAir) );
	memset( &m_sStageSensor, 0, sizeof(m_sStageSensor) );
	memset( &m_sCassetteSensor, 0, sizeof(m_sCassetteSensor) );
	memset( &m_nHighCassetteSlotStatus, 0, sizeof(m_nHighCassetteSlotStatus) );
	memset( &m_sPrealignSensor, 0, sizeof(m_sPrealignSensor) );
	memset( &m_sStagePickerSensor, 0, sizeof(m_sStagePickerSensor) );
	memset( &m_sCoaterPickerSensor, 0, sizeof(m_sCoaterPickerSensor) );
	memset( &m_sStagePos, 0, sizeof(m_sStagePos) );
	memset( &m_sHandlerPos, 0, sizeof(m_sHandlerPos) );
	memset( &m_nCassetteSlotStatus, 0, sizeof(m_nCassetteSlotStatus) );
	memset( &m_nHighCassetteSlotStatus, 0, sizeof(m_nHighCassetteSlotStatus) );
	memset( &m_nHandlerError, 0, sizeof(m_nHandlerError) );
	memset( &m_nWaferStatus, 0, sizeof(m_nWaferStatus) );
	memset( &m_nWaferSlot, 0, sizeof(m_nWaferSlot) );
	memset( &m_sLotEnd, 0, sizeof(m_sLotEnd) );
	m_dPolygonSpeed		= 0.;
}

DHandlerMonitor::~DHandlerMonitor()
{

}

void DHandlerMonitor::SetSensorMonitoring(DWORD* pData)
{
	int nVal;

	// M7000
	nVal = *(pData+0);

	// Emergency Switch
	m_sSysSensor.bEmergencySwitch	= ( nVal & 0x00000001 );
	
	// MainPower
	m_sSysSensor.bMainPower			= ( nVal & 0x00000002 );

	// Laser Power
	m_sSysSensor.bLaserPower		= ( nVal & 0x00000004 );

	// Servo Power
	m_sSysSensor.bServoPower		= ( nVal & 0x00000008 );

	// Circuit Protector
	m_sSysSensor.bCircuitProtector	= ( nVal & 0x00000010 );

	// Bypass Key Switch
	m_sSysSensor.bBypassKeySwitch	= ( nVal & 0x00000020 );
/*
	// Reset Switch
	m_sSysSensor.bResetSwitch		= ( nVal & 0x00000040 );

	// Initialize Switch
	m_sSysSensor.bInitialSwitch		= ( nVal & 0x00000080 );

	// Start Switch
	m_sSysSensor.bStartSwitch		= ( nVal & 0x00000100 );

	// Stop Switch
	m_sSysSensor.bStopSwitch		= ( nVal & 0x00000200 );
*/
	// M7001
	nVal = *(pData+1);

	// Front Door #1
	m_sSysDoor.bFrontDoor1			= ( nVal & 0x00000001 );

	// Front Door #2
	m_sSysDoor.bFrontDoor2			= ( nVal & 0x00000002 );

	// Front Door #3
	m_sSysDoor.bFrontDoor3			= ( nVal & 0x00000004 );

	// Left Door #1
	m_sSysDoor.bLeftDoor1			= ( nVal & 0x00000008 );

	// Left Door #2
	m_sSysDoor.bLeftDoor2			= ( nVal & 0x00000010 );

	// Rear Door #1
	m_sSysDoor.bRearDoor1			= ( nVal & 0x00000020 );

	// Rear Door #2
	m_sSysDoor.bRearDoor2			= ( nVal & 0x00000040 );

	// Right Door #1
	m_sSysDoor.bRightDoor1			= ( nVal & 0x00000080 );

	// M7002
	nVal = *(pData+2);

	// System Air Pressure
	m_sSysAir.bSysAir				= ( nVal & 0x00000001 );

	// Handler Air Pressure
	m_sSysAir.bHandlerAir			= ( nVal & 0x00000002 );

	// Stage Air Pressure
	m_sSysAir.bStageAir				= ( nVal & 0x00000004 );

	// Table Air Bearing
	m_sSysAir.bTableAirBearing		= ( nVal & 0x00000008 );

	// Stage Chuck Vacuum
	m_sStageSensor.bVacuum			= ( nVal & 0x00000010 );

	// Polygon Air
	m_sSysAir.bPolygonAir			= ( nVal & 0x00000020 );

	// N2 Gas Pressure Sensor
	m_sSysAir.bN2GasPressureSensor	= ( nVal & 0x00000040 );

	// System Vacuum Presure Sensor
	m_sSysAir.bSysVacuumPressureSensor = ( nVal & 0x00000080 );

	// Chamber Suction
	m_sStageSensor.bChamberSuction		= ( nVal & 0x00000100 );

	// Head Suction
	m_sStageSensor.bHeadSuction			= ( nVal & 0x00000200 );

	// Mask Picker
	m_sStageSensor.bMaskPicker		= ( nVal & 0x00000400 );

	// Mask Vacuum
	m_sStageSensor.bMaskVacuum		= ( nVal & 0x00000800 );

	// M7003
	nVal = *(pData+3);

	// Cupboard Door
	m_sCassetteSensor.bCupboardDoor							= ( nVal & 0x00000001 );
	
	// Low Cassette Door
	m_sCassetteSensor.bLowCassetteDoor						= ( nVal & 0x00000002 );

	// High Cassette Door
	m_sCassetteSensor.bHighCassetteDoor						= ( nVal & 0x00000004 );

	// Cupboard's Wafer Presence Check
	m_sCassetteSensor.bCupboardWaferPresenceCheck			= ( nVal & 0x00000008 );
	
	// Low Cassette Presence Check
	m_sCassetteSensor.bLowCassettePresenceCheck				= ( nVal & 0x00000010 );

	// High Cassette Presence Check
	m_sCassetteSensor.bHighCassettePresenceCheck			= ( nVal & 0x00000020 );

	// Wafer Presence Check in Rail
	m_sCassetteSensor.bWaferPresenceCheckInRail				= ( nVal & 0x00000040 );

	// Cassette Scanning
	m_sPrealignSensor.bCassetteScaning						= ( nVal & 0x00000080 );

	// Wafer Presence Check in Prealign Zone
	m_sPrealignSensor.bWaferPresenceCheckInPrealignZone		= ( nVal & 0x00000100 );

	// Wafer Presence Check in Buffer Zone
	m_sPrealignSensor.bWaferPresenceCheckInBufferZone		= ( nVal & 0x00000200 );

	// Prealign Cylinder Forword
	m_sPrealignSensor.bPrealignCylinderForword				= ( nVal & 0x00000400 );

	// Prealign Cylinder Backword
	m_sPrealignSensor.bPrealignCylinderBackword				= ( nVal & 0x00000800 );

	// Wafer Grip
	m_sPrealignSensor.bWaferGrip							= ( nVal & 0x00001000 );

	// Wafer Holding Assurance
	m_sPrealignSensor.bWaferHoldingAssurance				= ( nVal & 0x00002000 );

	// M7004
	nVal = *(pData+4);

	// Stage Picker Vaccum
	m_sStagePickerSensor.bVacuum			= ( nVal & 0x00000001 );

	// Stage Picker Cylinder Up
	m_sStagePickerSensor.bCylinderUp		= ( nVal & 0x00000002 );

	// Stage Picker Cylinder Down
	m_sStagePickerSensor.bCylinderDown		= ( nVal & 0x00000004 );

	// Stage Picker Shutter Up
	m_sStagePickerSensor.bShutterOpen		= ( nVal & 0x00000008 );

	// Stage Picker Shutter Down
	m_sStagePickerSensor.bShutterClose		= ( nVal & 0x00000010 );

	// Coater Picker Vacuum
	m_sCoaterPickerSensor.bVacuum			= ( nVal & 0x00000020 );

	// M7005
	nVal = *(pData+5);

	// Initialize Switch
	m_sSysSensor.bInitialSwitch		= ( nVal & 0x00000001 );

	// Reset Switch
	m_sSysSensor.bResetSwitch		= ( nVal & 0x00000002 );

	// Start Switch
	m_sSysSensor.bStartSwitch		= ( nVal & 0x00000004 );

	// Stop Switch
	m_sSysSensor.bStopSwitch		= ( nVal & 0x00000008 );

	// M7006
	nVal = *(pData+6);

	// Stage N2 Gas
	m_sStageSensor.bN2Gas					= ( nVal & 0x00000010 );

	// Stage Ionizer
	//m_sStageSensor.bIonizer					= ( nVal & 0x00000010 );

	// Stage Blowing
	//m_sStageSensor.bBlowing					= ( nVal & 0x00000020 );

	// M7007
	nVal = *(pData+7);

	// Prealigner Gripper
	m_sPrealignSensor.bGripperCylinder		= ( nVal & 0x00000002 );
}

void DHandlerMonitor::SetMotorPosition(DWORD* pData)
{
	long	nTemp;
	// #1 : Stage X
	nTemp				= *(pData+0);
	m_sStagePos.x		= nTemp;

	// #2 : Stage Y
	nTemp				= *(pData+1);
	m_sStagePos.y		= nTemp;

	// #3 : Stage Z
	nTemp				= *(pData+2);
	m_sStagePos.z		= nTemp;

	// #4 : Stage T
	nTemp				= *(pData+3);
	m_sStagePos.t		= nTemp;

	// #5 : Prealigner Z
	nTemp				= *(pData+4);
	m_sHandlerPos.dPreAlignerZ	= nTemp;

	// #6 : Stage Picker X
	nTemp				= *(pData+5);
	m_sHandlerPos.dStagePickerX	= nTemp;

	// #7 : Prealinger X
	nTemp				= *(pData+6);
	m_sHandlerPos.dPreAlignerX	= nTemp;

	// #8 : Coater Picker Y
	nTemp				= *(pData+7);
	m_sHandlerPos.dCoaterPickerY	= nTemp;

	// #9 : Coater Picker Z
	nTemp				= *(pData+8);
	m_sHandlerPos.dCoaterPickerZ	= nTemp;

	//#13 : Polygon RPM
	nTemp				= *(pData+9);
	m_dPolygonSpeed		= nTemp;

}

void DHandlerMonitor::SetCassetteSlotStatus(DWORD* pData, BOOL bLow)
{
	if( bLow )
		memcpy( m_nCassetteSlotStatus, pData, sizeof(m_nCassetteSlotStatus) );
	else
		memcpy( m_nHighCassetteSlotStatus, pData, sizeof(m_nHighCassetteSlotStatus) );
}

void DHandlerMonitor::SetHandlerError(DWORD* pData, int nOffset)
{
	if( nOffset == 1 )
		memcpy( m_nHandlerError, pData, sizeof(DWORD)*16 );
	else
		memcpy( m_nHandlerError+17, pData, sizeof(DWORD)*2 );
}

void DHandlerMonitor::SetStageIF(DWORD dwData)
{
	// Chuck Ready
	( dwData & 0x00000001 ) == 0x01 ? m_sStageIF.bStageReady = 1 : m_sStageIF.bStageReady = 0;

	// Chuck Progress
	( dwData & 0x00000002 ) == 0x02 ? m_sStageIF.bStageProgress = 1 : m_sStageIF.bStageProgress = 0;

	// Chuck Error
	( dwData & 0x00000004 ) == 0x04 ? m_sStageIF.bStageError = 1 : m_sStageIF.bStageError = 0;

	// Chuck End
	( dwData & 0x00000008 ) == 0x08 ? m_sStageIF.bStageEnd = 1 : m_sStageIF.bStageEnd = 0;

	// Chuck Start
	( dwData & 0x00000010 ) == 0x10 ? m_sStageIF.bStageStart = 1 : m_sStageIF.bStageStart = 0;
}

void DHandlerMonitor::SetBarcodeIF(DWORD dwData)
{
	// Barcode Ready
	( dwData & 0x00000001 ) == 0x01 ? m_sBarcodeIF.bStageReady = 1 : m_sBarcodeIF.bStageReady = 0;

	// Barcode Progress
	( dwData & 0x00000002 ) == 0x02 ? m_sBarcodeIF.bStageProgress = 1 : m_sBarcodeIF.bStageProgress = 0;

	// Barcode Error
	( dwData & 0x00000004 ) == 0x04 ? m_sBarcodeIF.bStageError = 1 : m_sBarcodeIF.bStageError = 0;

	// Barcode End
	( dwData & 0x00000008 ) == 0x08 ? m_sBarcodeIF.bStageEnd = 1 : m_sBarcodeIF.bStageEnd = 0;

	// Barcode Start
	( dwData & 0x00000010 ) == 0x10 ? m_sBarcodeIF.bStageStart = 1 : m_sBarcodeIF.bStageStart = 0;
}

void DHandlerMonitor::SetOneShotIF(DWORD dwData)
{
	// One Shot Vision Ready
	( dwData & 0x00000001 ) == 0x01 ? m_sOneShotIF.bStageReady = 1 : m_sOneShotIF.bStageReady = 0;

	// One Shot Vision Progress
	( dwData & 0x00000002 ) == 0x02 ? m_sOneShotIF.bStageProgress = 1 : m_sOneShotIF.bStageProgress = 0;

	// One Shot Vision Error
	( dwData & 0x00000004 ) == 0x04 ? m_sOneShotIF.bStageError = 1 : m_sOneShotIF.bStageError = 0;

	// One Shot Vision End
	( dwData & 0x00000008 ) == 0x08 ? m_sOneShotIF.bStageEnd = 1 : m_sOneShotIF.bStageEnd = 0;

	// One Shot Vision Start
	( dwData & 0x00000010 ) == 0x10 ? m_sOneShotIF.bStageStart = 1 : m_sOneShotIF.bStageStart = 0;
}

void DHandlerMonitor::SetWaferStatus(DWORD* pData)
{
	// Wafer Status
	memcpy( m_nWaferStatus, pData, sizeof(m_nWaferStatus) );
	
	// Wafer Slot
	memcpy( m_nWaferSlot, pData+8, sizeof(m_nWaferSlot) );
}
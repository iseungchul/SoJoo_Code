// HVisionTCP.cpp: implementation of the HVisionTCP class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "HVisionTCP.h"
#include "ClientSock.h"
#include "math.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HVisionTCP::HVisionTCP()
{
	m_pClientSock		= NULL;
}

HVisionTCP::~HVisionTCP()
{
	if( NULL != m_pClientSock)
	{
		delete m_pClientSock;
		m_pClientSock = NULL;
	}
}

BOOL HVisionTCP::InitMatroxTCP()
{
	m_pClientSock = new CClientSock();
	m_pClientSock->ReConnectTry();
	return m_pClientSock->m_bConnect;
}

BOOL HVisionTCP::ReConnect()
{
	m_pClientSock->ReConnectTry();
	return m_pClientSock->m_bConnect;
}

BOOL HVisionTCP::LoadJobFile(CString strFile)
{
	if(m_pClientSock->SendFileOpen(strFile))
		return FALSE;

	return TRUE;
}

BOOL HVisionTCP::GetRealPos(DPOINT* ptdPos, int nCamNo, int nIndex, char *pChar, int nMaskNo)
{
	int nReturn = m_pClientSock->GetRealPos(ptdPos, nCamNo, nIndex, nMaskNo);
	if(nReturn == SEND_OK_)
	{
		if(fabs(ptdPos->x - 999) < 1)
		{
			if(pChar)
			{
				memcpy(pChar, _T("Not Found"), 9);
			}
			return FALSE;
		}
		CString str;
		str.Format(_T("%.3f, %.3f"), ptdPos->x, ptdPos->y);
		if(pChar)
		{
			memcpy(pChar, str, str.GetLength());
		}
		return TRUE;
	}
	else if(nReturn == RETURN_FAIL_)
	{
		if(pChar)
		{
			memcpy(pChar, _T("Format Fail"), 11);
		}
		return FALSE;
	}
	else // Time out
	{
		if(pChar)
		{
			memcpy(pChar, _T("TCP/IP Time out"), 15);
		}
		return FALSE;
	}
	return TRUE;
}

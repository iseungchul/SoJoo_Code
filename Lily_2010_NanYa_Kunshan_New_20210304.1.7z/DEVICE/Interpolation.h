#if !defined(AFX_INTERPOLATION_H__6EFD015D_4098_47B0_BA78_3A2C7CCE937E__INCLUDED_)
#define AFX_INTERPOLATION_H__6EFD015D_4098_47B0_BA78_3A2C7CCE937E__INCLUDED_

#include "CalPoint.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Interpolation.h : header file
//

#include "FCalibration.h"

/////////////////////////////////////////////////////////////////////////////
// Interpolation command target

class Interpolation : public CObject
{
// Attributes
public:

// Operations
public:
	int m_nMatrixSize;						//check the Matrix size
	BOOL IsSuccess[MAX_CAL_X][MAX_CAL_Y];				//flag of success of not
	CCalPoint OffsetPoint[MAX_CAL_X][MAX_CAL_Y];		//vision offset point
	CCalPoint OffsetPointLSB[MAX_CAL_X][MAX_CAL_Y];	//vision offset point LSB
	CCalPoint CalibrationFile[MAX_CAL_X][MAX_CAL_Y];	//buffer of master Calibration file 
	CCalPoint CalFileLowMaster[MAX_CAL_X][MAX_CAL_Y];
	
	BOOL IsSuccess2[MAX_CAL_X][MAX_CAL_Y];				//flag of success of not
	CCalPoint OffsetPoint2[MAX_CAL_X][MAX_CAL_Y];		//vision offset point
	CCalPoint OffsetPointLSB2[MAX_CAL_X][MAX_CAL_Y];	//vision offset point LSB
	CCalPoint CalibrationFile2[MAX_CAL_X][MAX_CAL_Y]; //buffer of slave Calibration file 
	CCalPoint CalFileLowSlave[MAX_CAL_X][MAX_CAL_Y];

	Interpolation();	
	virtual ~Interpolation();

// Overrides
public:
	void BicubicCalibration();
	void FalseInterpolation();
	void Calibration();					// calibration main function
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Interpolation)
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(Interpolation)
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTERPOLATION_H__6EFD015D_4098_47B0_BA78_3A2C7CCE937E__INCLUDED_)

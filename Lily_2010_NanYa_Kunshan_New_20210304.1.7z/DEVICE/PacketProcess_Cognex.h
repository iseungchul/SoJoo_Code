// PacketProcess_Cognex.h: interface for the CPacketProcess_Cognex class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PacketProcess_Cognex_H__71FE9F5E_B045_4C56_937D_170945D8B225__INCLUDED_)
#define AFX_PacketProcess_Cognex_H__71FE9F5E_B045_4C56_937D_170945D8B225__INCLUDED_

//#include "Log.h"	// Added by ClassView

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

const char STX = 0x02;
const char ETX = 0x03;
const char Data1End = ';';


const int CMD_SIZE = 3;
const int MAX_SIZE1 = 100;
const int MAX_SIZE2 = 1000;
const int MAX_TOTAL_SIZE = CMD_SIZE + MAX_SIZE1 + MAX_SIZE2 + 2;

#define RECEIVE_WRONG_MSG	-200
#define RECEIVE_NAK_MSG		-100
#define RECEIVE_ACK_MSG		100


#define RECEIVE_10_MSG		10
#define RECEIVE_15_MSG		15
#define RECEIVE_18_MSG		18
#define RECEIVE_21_MSG		21

typedef struct COMM_PACKET
{
	char sSTX;
	char sCMD[3];
	char sData[MAX_SIZE1];
	char sData2[MAX_SIZE2];
	char sETX;
} PACKET;

class CPacketProcess_Cognex  
{
public:

	PACKET m_stInPacket;
	PACKET m_stOutPacket;

	void ClearInPacket();
	void ClearOutPacket();
	void * MakePacket(char *pCMD, char *pData1);
	int ParsePacket(char *pPacket);

	CPacketProcess_Cognex();
	virtual ~CPacketProcess_Cognex();
	char m_cSubData[MAX_SIZE2];
private:
//	CLog m_Log;
	CString m_strMsg;

};

#endif // !defined(AFX_PacketProcess_Cognex_H__71FE9F5E_B045_4C56_937D_170945D8B225__INCLUDED_)

// DHandlerInput.h: interface for the DHandlerInput class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DHANDLERINPUT_H__3DB2F193_68BD_4269_894D_36435455ECC5__INCLUDED_)
#define AFX_DHANDLERINPUT_H__3DB2F193_68BD_4269_894D_36435455ECC5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DSysInput.h"
#include "DSysErr.h"
#include "DPCOutput.h"

class DHandlerInput  
{
public:
	DHandlerInput();
	virtual ~DHandlerInput();

public :
	// System Input
	void	SetSysInput(DWORD* pData);
	void	UpdateSysInput(int nAddrIndex, DWORD dwData);

	// Motor Error
	void	SetMotorErr(DWORD* pData);
	void	UpdateMotorErr(int nAddrIndex, DWORD dwData);

	// System Error
	void	SetSysErr(DWORD* pData);
	void	UpdateSysErr(int nAddrIndex, DWORD dwData);

	// Etc.. Error
	void	SetEtcErr(DWORD* pData);
	void	UpdateEtcErr(int nAddrIndex, DWORD dwData);

	// Motor Position
	void	SetMotorPos(DWORD* pData);
	void	UpdateMotorPos(int nAddrIndex, DWORD dwData);

	// Cassette Slot Status
	void	SetCassetteSlotStatus(DWORD* pData);

	// Wafer Status
	void	SetWaferStatus(DWORD* pData);

	// PC Output
	void	SetPCOutputStatus(DWORD* pData);
	void	UpdatePCOutput(int nAddrIndex, DWORD dwData);

	BOOL	IsStageMotorErr(CString& strMsg);
	BOOL	IsHandlerMotorErr(CString& strMsg);
	BOOL	IsCoaterMotorErr(CString& strMsg);
	BOOL	IsMotorErr(int nAxis, CString& strMsg);
	
	BOOL	IsSysErr(CString& strMsg);
	BOOL	IsHandlerErr(int nCheckErrSection, CString& strMsg);

	BOOL	IsMPG();

public : // Attribute
	// System Input
	DWORD			m_nSysInput[12];
	DSysInput		m_clsSysInput;

	// Motor Error
	DWORD			m_nMotorErr[14];
	SMOTORERR		m_sStageX;
	SMOTORERR		m_sStageY;
	SMOTORERR		m_sStageZ;
	SMOTORERR		m_sStageT;
	SMOTORERR		m_sElevator;
	SMOTORERR		m_sAlignRail;
	SMOTORERR		m_sGripper;
	SMOTORERR		m_sLPickerY;
	SMOTORERR		m_sLPickerZ;
	SMOTORERR		m_sBPickerY;
	SMOTORERR		m_sBPickerZ;
	SMOTORERR		m_sSpinT;
	SMOTORERR		m_sSpinZ;
	SMOTORERR		m_sCoaterArm;

	// Sys Err
	DWORD			m_nSysErr[2];
	DWORD			m_nEtcErr[7];
	DSysErr			m_clsSysErr;

	// Motor Position
	DWORD			m_nMotorPos[15];
	DSTAGEPOS		m_sStagePos;
	DHANDLERPOS		m_sHandlerPos;

	// Cassette Slot Status
	int				m_nCassetteSlotStatus[25];

	// Wafer Status
	int				m_nWaferStatus[6];
	int 			m_nWaferSlot[6];

	// PC Output
	DWORD			m_nPCOutput[16];
	DPCOutput		m_clsPCOutput;
	
	SSYSSENSOR		m_sSysSensor;
};

extern DHandlerInput gHandlerInput;

#endif // !defined(AFX_DHANDLERINPUT_H__3DB2F193_68BD_4269_894D_36435455ECC5__INCLUDED_)

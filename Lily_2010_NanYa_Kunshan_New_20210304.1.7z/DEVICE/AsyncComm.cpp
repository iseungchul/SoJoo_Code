/*-------------------------------------------------------------------------------
| ���ϸ� : AsyncComm.Cpp
| �뵵   : Asynchronous Serial Communication Component for WIN 32 API
| ����   : 0.9
|-------------------------------------------------------------------------------
|                          ��  ��  ��  ��  ��  ��
|-------------------------------------------------------------------------------
| ��      ¥ | ������ |            ��       ��        ��       ��
|------------|--------|---------------------------------------------------------
| 1999.12.11 | ������ | Start
|            |        | ������ �ҽ��� �������� �Ͽ� ��� ��ƾ�� �������.
|            |        |
|            |        |
|            |        |
--------------------------------------------------------------------------------*/
#include "stdafx.h"
#include "stdio.h"
#include "AsyncComm.h"

// Disable C4100 : unreferenced formal parameter warning
#pragma warning(disable : 4100)

CAssEvent::CAssEvent(LPSECURITY_ATTRIBUTES EventAttributes, BOOL ManualReset,
	BOOL InitialState, char * Name)
{
	FHandle = CreateEvent(EventAttributes, ManualReset, InitialState, Name);
}

CAssEvent::~CAssEvent()
{
	if (FHandle != INVALID_HANDLE_VALUE)
		CloseHandle(FHandle);
}

TAssWaitResult CAssEvent::WaitFor(long TimeOut)
{
	switch (WaitForSingleObject(FHandle, TimeOut))
	{
	case WAIT_ABANDONED  : return wrAbandoned;
	case WAIT_OBJECT_0   : return wrSignaled;
	case WAIT_TIMEOUT    : return wrTimeout;
	case WAIT_FAILED     : return wrError;
	default : return wrError;
	}
}

void CAssEvent::SetEvent(void)
{
	::SetEvent(FHandle);
}

void CAssEvent::ResetEvent(void)
{
	::ResetEvent(FHandle);
}

////////////////////////////////////////////////////////////////////////////////
// Prototype   : CAsyncComm::CAsyncComm()
// Description : CAsyncComm �� ������.
//               
// Parameter   : 
// Return      : 
////////////////////////////////////////////////////////////////////////////////}
CAsyncComm::CAsyncComm() : FPortName(_T("COM1"))
{
	m_CommThread = NULL;

	FHandle = INVALID_HANDLE_VALUE;
	FPortOpened = false;
	FMaxInQueue = 1024;
	FMaxOutQueue = 1024;
	FTimeOut = 300;
	CommThreadTerminated = false;
	FEventMask = EV_BREAK | EV_CTS | EV_DSR | EV_ERR | EV_RING | EV_RLSD | EV_RXCHAR | EV_RXFLAG | EV_TXEMPTY;
	FEventChar = 0x10;
	FBaudRate = __19200;
	FByteSize = _8;
	FStopBits = _1;
	FParity = EVEN;
	FFlowControl = FC_NONE;
	FCheckParity = FALSE;
	FBinaryMode  = TRUE;
	FOVRead.Offset = 0;
	FOVRead.OffsetHigh = 0;
	FOVWrite.Offset = 0;
	FOVWrite.OffsetHigh = 0;
	FOVRead.hEvent = CreateEvent(NULL, true, false, NULL);
	FOVWrite.hEvent = CreateEvent(NULL, true, false, NULL);
	if (m_hevEventCharReceived != NULL)
		ResetEvent(m_hevEventCharReceived);
	m_nCmdSize = 0;
	m_bHIOKI8431 = FALSE;
	m_hevEventCharReceived = CreateEvent(NULL, TRUE, FALSE, NULL);
}

////////////////////////////////////////////////////////////////////////////////
// Prototype   : CAsyncComm::~CAsyncComm()
// Description : CAsyncComm �� �ı���
//               
// Parameter   : 
// Return      : 
////////////////////////////////////////////////////////////////////////////////}
CAsyncComm::~CAsyncComm()
{
	if (FPortOpened)
	{
		FPortOpened = FALSE;
		EscapeCommFunction(FHandle, CLRDTR);
		PurgeComm( FHandle, PURGE_RXABORT + PURGE_RXCLEAR + PURGE_TXABORT + PURGE_TXCLEAR);
		SetCommMask(FHandle, 0);
		if (FHandle != INVALID_HANDLE_VALUE)
		{
			CloseHandle(FHandle);
			FHandle = INVALID_HANDLE_VALUE;
		}
	}
	CloseHandle(FOVRead.hEvent);
	CloseHandle(FOVWrite.hEvent);
}

BOOL CAsyncComm::InitTimeOut(void)
{
	// �Է¹��ۿ� ����Ÿ�� ���� ��� ReadFile�� �Է¹����� ����� �Բ� �ٷ� Return�Ѵ�.
	// �Է¹��ۿ� ����Ÿ�� ���� ��� ReadFile�� ������ �� ����� ��ٷȴٰ� ����� �Բ�
	// Return�Ѵ�.
	// ReadTotalTimeoutConstant��ŭ ��ٷ��� ����Ÿ�� ���� ���� ��� Timeout���� ������.
	if (FHandle != INVALID_HANDLE_VALUE) 
	{
		GetCommTimeouts(FHandle, &FCommTimeouts);
		FCommTimeouts.ReadIntervalTimeout = MAXDWORD;
		FCommTimeouts.ReadTotalTimeoutMultiplier = 0;
		FCommTimeouts.ReadTotalTimeoutConstant = FTimeOut;
		// Write Timeout�� 2 ms
		FCommTimeouts.WriteTotalTimeoutMultiplier = 2;
		FCommTimeouts.WriteTotalTimeoutConstant = 0;
		if (SetCommTimeouts(FHandle, &FCommTimeouts))
		{
			return TRUE;
		}
		else
		{
			FireCommError(GetLastError(), "SetCommTimeouts Fail");
			return FALSE;
		}
	}
	else
	{
		return FALSE;
	}
}

BOOL CAsyncComm::InitDCB(void)
{
	if (FHandle != INVALID_HANDLE_VALUE)
	{
		if (GetCommState(FHandle, &FDCB))
		{
			switch (FBaudRate)
			{
			case ___2400 : FDCB.BaudRate = CBR_2400; break;
			case ___4800 : FDCB.BaudRate = CBR_4800; break;
			case ___9600 : FDCB.BaudRate = CBR_9600; break;
			case __14400 : FDCB.BaudRate = CBR_14400; break;
			case __19200 : FDCB.BaudRate = CBR_19200; break;
			case __38400 : FDCB.BaudRate = CBR_38400; break;
			case __57600 : FDCB.BaudRate = CBR_57600; break;
			case _115200 : FDCB.BaudRate = CBR_115200; break;
			case _128000 : FDCB.BaudRate = CBR_128000; break;
			case _256000 : FDCB.BaudRate = CBR_256000; break;
			}

			switch(FParity)
			{
			case NONE  : FDCB.Parity = NOPARITY; break;
			case ODD   : FDCB.Parity = ODDPARITY; break;
			case EVEN  : FDCB.Parity = EVENPARITY; break;
			case MARK  : FDCB.Parity = MARKPARITY; break;
			case SPACE : FDCB.Parity = SPACEPARITY; break;
			}

			switch (FByteSize)
			{
			case _7 : FDCB.ByteSize = 7; break;
			case _8 : FDCB.ByteSize = 8; break;
			}

			switch (FStopBits)
			{
			case _1   : FDCB.StopBits = ONESTOPBIT; break;
			case _1_5 : FDCB.StopBits = ONE5STOPBITS; break;
			case _2   : FDCB.StopBits = TWOSTOPBITS; break;
			}

			if (FFlowControl == FC_NONE) 
			{
				FDCB.fInX = 0;
				FDCB.fOutX = 0;
				FDCB.fOutxDsrFlow = 0;
				FDCB.fOutxCtsFlow = 0;
				FDCB.fDtrControl = 1;
				FDCB.fRtsControl = 1;
			}
			else if (FFlowControl == FC_XONXOFF)
			{
				FDCB.fInX = 1;
				FDCB.fOutX = 1; 
				FDCB.fOutxDsrFlow = 0; 
				FDCB.fOutxCtsFlow = 0; 
				FDCB.fDtrControl = 1; 
				FDCB.fRtsControl = 1; 
			}
			else
			{
				FDCB.fInX = 0;
				FDCB.fOutX = 0;
				FDCB.fOutxDsrFlow = 1;
				FDCB.fOutxCtsFlow = 1;
				FDCB.fDtrControl = 1;
				FDCB.fRtsControl = 1;
			}

			FDCB.fBinary = FBinaryMode;
			FDCB.fParity = FCheckParity;
			FDCB.fNull = FDiscardNull;

			FDCB.XonChar = XON_CHAR;
			FDCB.XoffChar = XOFF_CHAR;
			FDCB.EvtChar = FEventChar;

			if(m_bHIOKI8431)
			{
				FDCB.EvtChar = 0;
				FDCB.EofChar = 0x1a;
				FDCB.XonLim = 256;
				FDCB.XoffLim = 256;
			}

			if (SetCommState(FHandle, &FDCB)) 
			{
				return TRUE;
			}
			else
			{
				FireCommError(GetLastError(), "SetCommState Fail");
				return FALSE;
			}
		}
		else
		{
			FireCommError(GetLastError(), "GetCommState Fail");
			return FALSE;
		}
	}
	else
	{
		FireCommError(GetLastError(), "OpenComm First");
		return FALSE;
	}
}

////////////////////////////////////////////////////////////////////////////////
// Prototype   : CAsyncComm::OpenComm(void)
// Description : ��� ��Ʈ�� Open �Ѵ�.
//               
// Parameter   : 
// Return      : 
//
//               �� �Լ��� ȣ���ϱ⿡ �ռ� ���� ��� �Ķ���Ͱ� ������ �Ǿ� 
//               �־�� �Ѵ�.
////////////////////////////////////////////////////////////////////////////////}
BOOL CAsyncComm::OpenComm(void)
{
	if (!FPortOpened)
	{
		FHandle = CreateFile(FPortName,                      // Port Name
			GENERIC_READ | GENERIC_WRITE,  // Access Mode
			FILE_SHARE_READ | FILE_SHARE_WRITE,                              // Share Mode (No share)
			NULL,                            // Address of Security Descriptor
			OPEN_EXISTING,                  // How to create
			FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED,           // File Attributes
			NULL);                           // Handle of file with attributes to copy

		if (FHandle == INVALID_HANDLE_VALUE)
		{
			FireCommError(GetLastError(), "CreateFile Fail");
			return false;
		}
		else
		{
			SetCommMask(FHandle, EV_RXCHAR);
			SetupComm(FHandle, FMaxInQueue, FMaxOutQueue);
			PurgeComm( FHandle, PURGE_RXABORT + PURGE_RXCLEAR + PURGE_TXABORT + PURGE_TXCLEAR);
			if (InitTimeOut())
			{
				if (InitDCB())
				{
					FPortOpened = TRUE;

					EscapeCommFunction(FHandle, SETDTR);
					FireOpenStatus(TRUE);
					StartCommThread();
					return TRUE;
				}
				else
				{
					CloseHandle(FHandle);
					return FALSE;
				}
			}
			else
			{
				CloseHandle(FHandle);
				return FALSE;
			}
		}
	}
	else
	{
		return FALSE;
	}
}

////////////////////////////////////////////////////////////////////////////////
// Prototype   : CAsyncComm::CloseComm(void)
// Description : ��� ��Ʈ�� Close �Ѵ�.
//               
// Parameter   : 
// Return      : 
//
////////////////////////////////////////////////////////////////////////////////}
BOOL CAsyncComm::CloseComm(void)
{
	if (FPortOpened)
	{
		SetCommMask(FHandle, 0);
		EscapeCommFunction(FHandle, CLRDTR);
		PurgeComm( FHandle, PURGE_RXABORT | PURGE_RXCLEAR | PURGE_TXABORT | PURGE_TXCLEAR);
		if (CloseHandle(FHandle))
		{
			FireOpenStatus(FALSE);
			FPortOpened = FALSE;
			FHandle = INVALID_HANDLE_VALUE;
			StopCommThread();
			return TRUE;
		}
		else
		{
			FireCommError(GetLastError(), "CloseComm Fail");
			return FALSE;
		}
	}
	else
	{
		return TRUE;
	}
}

////////////////////////////////////////////////////////////////////////////////
// Prototype   : CAsyncComm::SetPort(TPort Value)
// Description : ��� ��Ʈ�� �����Ѵ�.
//               
// Parameter   : 
// Return      : 
//
////////////////////////////////////////////////////////////////////////////////}
void CAsyncComm::SetPort(TPort Value)
{
	FPort = Value;
	CString str;
	str.Format("%d",Value + 1);
	FPortName = "\\\\.\\COM" + str;
	if (FPortOpened) 
	{
		CloseComm();
		OpenComm();
	}
}

TPort CAsyncComm::GetPort(void)
{
	return FPort;
}

////////////////////////////////////////////////////////////////////////////////
// Prototype   : CAsyncComm::SetStopBits(TStopBits Value)
// Description : StopBits �� �����Ѵ�.
//               
// Parameter   : 
// Return      : 
//
////////////////////////////////////////////////////////////////////////////////}
void CAsyncComm::SetStopBits(TStopBits Value)
{
	FStopBits = Value;
	if (FPortOpened)
	{
		CloseComm();
		OpenComm();
	}
}

TStopBits CAsyncComm::GetStopBits(void)
{
	return FStopBits;
}

////////////////////////////////////////////////////////////////////////////////
// Prototype   : CAsyncComm::SetBaudRate(TBaudRate Value)
// Description : ���� �ӵ��� �����Ѵ�.
//               
// Parameter   : 
// Return      : 
//
////////////////////////////////////////////////////////////////////////////////}
void CAsyncComm::SetBaudRate(TBaudRate Value)
{
	FBaudRate = Value;
	if (FPortOpened)
	{
		CloseComm();
		OpenComm();
	}
}

TBaudRate CAsyncComm::GetBaudRate(void)
{
	return FBaudRate;
}

////////////////////////////////////////////////////////////////////////////////
// Prototype   : CAsyncComm::SetParity(TParity Value)
// Description : Parity Bits �� �����Ѵ�.
//               
// Parameter   : 
// Return      : 
//
////////////////////////////////////////////////////////////////////////////////}
void CAsyncComm::SetParity(TParity Value)
{
	FParity = Value;
	if (FPortOpened)
	{
		CloseComm();
		OpenComm();
	}
}

TParity CAsyncComm::GetParity(void)
{
	return FParity;
}

////////////////////////////////////////////////////////////////////////////////
// Prototype   : CAsyncComm::SetByteSize(TByteSize Value)
// Description : ByteSize �� �����Ѵ�.
//               
// Parameter   : 
// Return      : 
//
////////////////////////////////////////////////////////////////////////////////}
void CAsyncComm::SetByteSize(TByteSize Value)
{
	FByteSize = Value;
	if (FPortOpened)
	{
		CloseComm();
		OpenComm();
	}
}

TByteSize CAsyncComm::GetByteSize(void)
{
	return FByteSize;
}

////////////////////////////////////////////////////////////////////////////////
// Prototype   : CAsyncComm::SetFlowControl(TFlowControl Value)
// Description : Flow Control �� �����Ѵ�.
//               
// Parameter   : 
// Return      : 
//
////////////////////////////////////////////////////////////////////////////////}
void CAsyncComm::SetFlowControl(TFlowControl Value)
{
	FFlowControl = Value;
	if (FPortOpened)
	{
		CloseComm();
		OpenComm();
	}
}

void CAsyncComm::SetEventChar(char ch)
{
	FEventChar = ch;
}

////////////////////////////////////////////////////////////////////////////////
// Prototype   : CAsyncComm::SetCommEvents(DWORD Value)
// Description : Comm Event �� ����
//               
// Parameter   : 
// Return      : 
//
////////////////////////////////////////////////////////////////////////////////}
void CAsyncComm::SetCommEvents(DWORD Value)
{
	FCommEvents = Value;
	FEventMask = 0;
	if (EVBREAK & FCommEvents)		FEventMask = FEventMask + EV_BREAK;
	if (EVCTS & FCommEvents)		FEventMask = FEventMask + EV_CTS;
	if (EVDSR & FCommEvents)		FEventMask = FEventMask + EV_DSR;
	if (EVERR & FCommEvents)		FEventMask = FEventMask + EV_ERR;
	if (EVRING & FCommEvents)		FEventMask = FEventMask + EV_RING;
	if (EVRLSD & FCommEvents)		FEventMask = FEventMask + EV_RLSD;
	if (EVRXCHAR & FCommEvents)		FEventMask = FEventMask + EV_RXCHAR;
	if (EVRXFLAG & FCommEvents)		FEventMask = FEventMask + EV_RXFLAG;
	if (EVTXEMPTY & FCommEvents)	FEventMask = FEventMask + EV_TXEMPTY;
}

////////////////////////////////////////////////////////////////////////////////
// Prototype   : CAsyncComm::SetTimeOut(DWORD Value)
// Description : ��� �ִ� ��ٸ� �ӵ� ����
//               
// Parameter   : 
// Return      : 
//
////////////////////////////////////////////////////////////////////////////////}
void CAsyncComm::SetTimeOut(DWORD Value)
{
	if (FTimeOut != Value)
	{
		FTimeOut = Value;
	}
}

char* CAsyncComm::ReadComm(int ACount)
{
	if (!FPortOpened)
		return "";

	char szRead[1024];
	DWORD dwRead;
	DWORD dwErrorMask;
	DWORD dwError;
	BOOL bReadState;

	memset(szRead, 0x000, 1024);
	bReadState = ReadFile(FHandle, szRead, ACount, &dwRead, &FOVRead);
	if (!bReadState) 
	{
		if (GetLastError() == ERROR_IO_PENDING) 
		{
			while( !GetOverlappedResult(FHandle, &FOVRead, &dwRead, TRUE )) 
			{
				dwError = GetLastError();
				if (dwError != ERROR_IO_INCOMPLETE) 
				{
					// ������ �߻��ߴ�.
					ClearCommError(FHandle, &dwErrorMask, &FComStat);
					ProcessCommError(dwErrorMask);
					return "";
				}
			}
			return &szRead[0];
		}
		else
		{
			// ������ �߻��ߴ�.
			ClearCommError(FHandle, &dwErrorMask, &FComStat);
			ProcessCommError(dwErrorMask);
			return "";
		}
	}
	else
	{
		return &szRead[0];
	}
}

BOOL CAsyncComm::ReadChar(char * szRead, DWORD dwToRead)
{
	if (!FPortOpened)
		return false;

	DWORD dwRead;
	DWORD dwErrorMask;
	DWORD dwError;
	BOOL bReadState;

	bReadState = ReadFile(FHandle, szRead, dwToRead, &dwRead, &FOVRead);
	if(!bReadState)
	{
		if (GetLastError() == ERROR_IO_PENDING) 
		{
			while( !GetOverlappedResult(FHandle, &FOVRead, &dwRead, TRUE ))
			{
				dwError = GetLastError();
				if(dwError != ERROR_IO_INCOMPLETE)
				{
					// ������ �߻��ߴ�.
					ClearCommError(FHandle, &dwErrorMask, &FComStat);
					ProcessCommError(dwErrorMask);
					return FALSE;
				}
			}
			return TRUE;
		}
		else
		{
			// ������ �߻��ߴ�.
			ClearCommError(FHandle, &dwErrorMask, &FComStat);
			ProcessCommError(dwErrorMask);
			return FALSE;
		}
	}
	else
	{
		if (dwRead == dwToRead)
			return TRUE;
		else
			return FALSE;
	}
}

char * CAsyncComm::ReadString(void)
{
	if (!FPortOpened)
		return "";

	DWORD dwToRead;
	DWORD dwErrorMask;
	static char szRet[1024];
	memset(szRet, 0x00, sizeof(szRet));
	if (FPortOpened && (FHandle != INVALID_HANDLE_VALUE))
	{
		FireRXStatus(TRUE);
		szRet[0] = _T('\0');
		ClearCommError(FHandle, &dwErrorMask, &FComStat);
		ProcessCommError(dwErrorMask);
		dwToRead = FComStat.cbInQue;
		BOOL bStart = TRUE;
		while (dwToRead > 0)
		{
			if (dwToRead > 1024)
			{
//				sprintf_s(szRet, 1024, ReadComm(256));
				if(bStart)
				{
					memcpy(szRet, ReadComm(255), 255);
					bStart = FALSE;
				}
				else
					ReadComm(255);
//				strcpy_s(szRet, ReadComm(256));
			}
			else
			{
//				sprintf_s(szRet, 1024, ReadComm(dwToRead));
				if(bStart)
				{
					memcpy(szRet, ReadComm(dwToRead), dwToRead);
					bStart = FALSE;
				}
				else
					ReadComm(dwToRead);
//				strcpy_s(szRet, ReadComm(dwToRead));
			}
			ClearCommError(FHandle, &dwErrorMask, &FComStat);
			ProcessCommError(dwErrorMask);
			dwToRead = FComStat.cbInQue;
		}
		FireRXStatus(false);

		return &szRet[0];
	}
	else
	{
		return "";
	}
}

void CAsyncComm::ProcessCommError(DWORD dwCommError)
{
	if (dwCommError > 0)
	{
		if ((dwCommError & CE_BREAK) == 1) 
		{
			FireCommError(CE_BREAK, "The hardware detected a break condition.");
		}
		else if ((dwCommError & CE_DNS) == 1)
		{
			FireCommError(CE_DNS, "A parallel device is not selected.");
		}
		else if ((dwCommError & CE_FRAME) == 1)
		{
			FireCommError(CE_FRAME, "The hardware detected a framing error.");
		}
		else if ((dwCommError & CE_IOE) == 1)
		{
			FireCommError(CE_IOE, "An I/O error occurred during communications with the device.");
		}
		else if ((dwCommError & CE_MODE) == 1)
		{
			FireCommError(CE_MODE, "The requested mode is not supported, or the hFile parameter is invalid. if this value is specified, it is the only valid error.");
		}
		else if ((dwCommError & CE_OOP) == 1) 
		{
			FireCommError(CE_OOP, "A parallel device signaled that it is out of paper.");
		}
		else if ((dwCommError & CE_OVERRUN) == 1)
		{
			FireCommError(CE_OVERRUN, "A character-buffer overrun has occurred. The next character is lost.");
		}
		else if ((dwCommError & CE_PTO) == 1)
		{
			FireCommError(CE_PTO, "A time-out occurred on a parallel device.");
		}
		else if ((dwCommError & CE_RXOVER) == 1)
		{
			FireCommError(CE_RXOVER, "An input buffer overflow has occurred. There is either no room in the input buffer, or a character was received after the }-of-file (EOF) character.");
		}
		else if ((dwCommError & CE_RXPARITY) == 1)
		{
			FireCommError(CE_RXPARITY, "The hardware detected a parity error.");
		}
		else if ((dwCommError & CE_TXFULL) == 1)
		{
			FireCommError(CE_TXFULL, "The application tried to transmit a character, but the output buffer was full.");
		}
	}
}

int CAsyncComm::Write(char * ABuffer, int ACount)
{
	if (!FPortOpened)
		return -1;

	DWORD dwErrorMask, dwWritten, dwWriteNo;

	if (FPortOpened && (FHandle != INVALID_HANDLE_VALUE))
	{
		FireTXStatus(TRUE);
		dwWriteNo = 0;
		if (!WriteFile(FHandle, ABuffer, ACount, &dwWritten, &FOVWrite))
		{
			if (GetLastError() == ERROR_IO_PENDING)
			{
				while (!GetOverlappedResult(FHandle, &FOVWrite, &dwWritten, TRUE))
				{
					if (GetLastError() != ERROR_IO_INCOMPLETE)
					{
						ClearCommError(FHandle, &dwErrorMask, &FComStat);
						ProcessCommError(dwErrorMask);
						return -1;
					}
					else
						dwWriteNo = dwWriteNo + dwWritten;
				}
				dwWriteNo = dwWriteNo + dwWritten;
				return dwWriteNo;
			}
			else
			{
				ClearCommError(FHandle, &dwErrorMask, &FComStat);
				ProcessCommError(dwErrorMask);
				return -1;
			}
		}
		else
		{
			return -1;
		}

		//		FireTXStatus(false);
	}
	else
	{
		return -1;
	}
}

BOOL CAsyncComm::WriteChar(char * szData, DWORD dwToWrite, int * dwWritten)
{
	if (!FPortOpened)
		return FALSE;

	DWORD dwErrorMask, dwWrite, dwWriteNo;
	char szWrite[1024];
	//	int i;

	if (FPortOpened && (FHandle != INVALID_HANDLE_VALUE))
	{
		memset(szWrite, 1024, 0x00);
		for(int i = 0; dwToWrite - 1; i++)
		{
			szWrite[i] = szData[i];
		}
		FireTXStatus(TRUE);
		dwWriteNo = 0;
		if (!WriteFile(FHandle, szWrite, dwToWrite, &dwWrite, &FOVWrite))
		{
			if (GetLastError() == ERROR_IO_PENDING)
			{
				while (!GetOverlappedResult(FHandle, &FOVWrite, &dwWrite, TRUE))
				{
					if (GetLastError() != ERROR_IO_INCOMPLETE)
					{
						ClearCommError(FHandle, &dwErrorMask, &FComStat);
						ProcessCommError(dwErrorMask);
						return FALSE;
					}
					else
						dwWriteNo = dwWriteNo + dwWrite;
				}
				dwWriteNo = dwWriteNo + dwWrite;
				*dwWritten = dwWriteNo;
				return TRUE;
			}
			else
			{
				ClearCommError(FHandle, &dwErrorMask, &FComStat);
				ProcessCommError(dwErrorMask);
				dwWritten = 0;
				return FALSE;
			}
		}
		else
		{
			dwWritten = 0;
			return FALSE;
		}
		//		FireTXStatus(false);
	}
	else
	{
		dwWritten = 0;
		return false;
	}
}

BOOL CAsyncComm::WriteString(char * szData)
{
	if (!FPortOpened)
		return false;

	char OutBuffer[1024];
	DWORD dwErrorMask, dwToWrite, dwWritten, dwWriteNo;

	if (FPortOpened && (FHandle != INVALID_HANDLE_VALUE)) 
	{
		// Initialize buffer 
		memset(OutBuffer, 0x00, sizeof(OutBuffer));
		memset(OutBuffer, 0x00, sizeof(OutBuffer));

		// Make Send data 
		if(m_bAcceptNULL)
		{
			for(int i =0; i< m_nCmdSize; i++)
			{
				OutBuffer[i] = szData[i];
			}
			dwToWrite = m_nCmdSize;
		}
		else
		{
			strcpy_s(OutBuffer, szData);
			dwToWrite = strlen(OutBuffer);
		}
//		
		
//		dwToWrite = 8;//strlen(OutBuffer);
		FireTXStatus(TRUE);
		dwWriteNo = 0;
		if (!WriteFile(FHandle, OutBuffer, dwToWrite, &dwWritten, &FOVWrite))
		{
			if (GetLastError() == ERROR_IO_PENDING)
			{
				while (!GetOverlappedResult(FHandle, &FOVWrite, &dwWritten, TRUE)) 
				{
					if (GetLastError() != ERROR_IO_INCOMPLETE)
					{
						ClearCommError(FHandle, &dwErrorMask, &FComStat);
						ProcessCommError(dwErrorMask);
						return FALSE;
					}
					else
						dwWriteNo = dwWriteNo + dwWritten;
				}
				dwWriteNo = dwWriteNo + dwWritten;
				return TRUE;
			}
			else
			{
				ClearCommError(FHandle, &dwErrorMask, &FComStat);
				ProcessCommError(dwErrorMask);
				return FALSE;
			}
		}
		else
		{
			return  FALSE;
		}
		//		FireTXStatus(false);
	}
	else
	{
		return false;
	}
}

void CAsyncComm::FireOpenStatus(BOOL Stsate)
{
}

void CAsyncComm::FireTimeOut(void)
{
}

void CAsyncComm::FireCommError(int nErrCode, char * szErrDesc)
{
	// if Assigned(FOnCommError) FOnCommError(Self, nErrCode, szErrDesc);
}

void CAsyncComm::FireTXStatus(BOOL Value)
{
	// if Assigned(FOnTXStatus) Then FOnTXStatus(Self, Value);
}

void CAsyncComm::FireRXStatus(BOOL Value)
{
	// if Assigned(FOnRXStatus) Then FOnRXStatus(Self, Value);
}

void CAsyncComm::FireMessage(char * szMsg)
{
	// if assigned(FOnMessage) Then FOnMessage(Self, szMsg);
}

void CAsyncComm::FireCommEvents(UINT dwCommEvents)
{
	//  If Assigned(FOnCommEvents) Then FOnCommEvents(Self, dwCommEvents);
}

void CAsyncComm::FireReceived(void)
{
}

void CAsyncComm::FireEventCharReceived(void)
{
	SetEvent(m_hevEventCharReceived);
}

void CAsyncComm::SetBinaryMode(BOOL Value)
{
	FBinaryMode = Value;
}

void CAsyncComm::CheckParity(BOOL Value)
{
	FCheckParity = Value;
}

void CAsyncComm::SetMaxInQueue(DWORD Value)
{
	FMaxInQueue = Value;
}

void CAsyncComm::SetMaxOutQueue(DWORD Value)
{
	FMaxOutQueue = Value;
}

DWORD CAsyncComm::GetMaxInQueue(void)
{
	return FMaxInQueue;
}

DWORD CAsyncComm::GetMaxOutQueue(void)
{
	return FMaxOutQueue;
}

BOOL CAsyncComm::PortOpened(void)
{
	return FPortOpened;
}

void CAsyncComm::SetEventMask(DWORD Value)
{ 
	FEventMask = Value;
}

UINT procCommThread(LPVOID pParam)
{
	ULONG dwEventMask;
	CAsyncComm *Comm = (CAsyncComm*)pParam;

	if (!SetCommMask(Comm->FHandle, Comm->FEventMask))
	{
		Comm->FireMessage("SetCommMask  Failed");
		return 0;
	}
	while (Comm->PortOpened()) 
	{
		if (Comm->FHandle != INVALID_HANDLE_VALUE)
		{
			dwEventMask = 0;
			if (::WaitCommEvent(Comm->FHandle, &dwEventMask, NULL)) 
			{
				if ((dwEventMask & EV_RXCHAR) == EV_RXCHAR)
				{
					Comm->FireCommEvents(EV_RXCHAR);
					Comm->FireReceived();
				}
				if ((dwEventMask & EV_RXFLAG) == EV_RXFLAG)
				{
					Comm->FireCommEvents(EV_RXFLAG);
					Comm->FireEventCharReceived();
				}
				if ((dwEventMask & EV_BREAK) == EV_BREAK)
				{
					Comm->FireCommEvents(EV_BREAK);
				}
				if ((dwEventMask & EV_CTS) == EV_CTS)
				{
					Comm->FireCommEvents(EV_CTS);
				}
				if ((dwEventMask & EV_DSR) == EV_DSR)
				{
					Comm->FireCommEvents(EV_DSR);
				}
				if ((dwEventMask & EV_ERR) == EV_ERR)
				{
					Comm->FireCommEvents(EV_ERR);
				}
				if ((dwEventMask & EV_RING) == EV_RING)
				{
					Comm->FireCommEvents(EV_RING);
				}
				if ((dwEventMask & EV_RLSD) == EV_RLSD)
				{
					Comm->FireCommEvents(EV_RLSD);
				}
				if ((dwEventMask & EV_TXEMPTY) == EV_TXEMPTY)
				{
					Comm->FireCommEvents(EV_TXEMPTY);
				}
			}
			else
			{
				Comm->FireMessage("WaitComEvents Error");
			}
		}
	}
	return 0;
}

BOOL CAsyncComm::StartCommThread(void)
{	
	TRACE("CommThread start\n");
	if (m_CommThread == NULL)
	{
		m_CommThread = ::AfxBeginThread(procCommThread, this,THREAD_PRIORITY_LOWEST);
		if (m_CommThread == NULL)
			return FALSE;
		else
		{
			CommThreadTerminated = false;
			return TRUE;
		}
	}
	else
		return FALSE;
} 

BOOL CAsyncComm::StopCommThread(void)
{
	TRACE("CommThread ended\n");
	if (m_CommThread == NULL)
		return TRUE;

	FPortOpened = false;
	FHandle = INVALID_HANDLE_VALUE;
	if (::AfxIsValidAddress(m_CommThread, sizeof(CWinThread*)))
	{
		SetPriorityClass(m_CommThread, NORMAL_PRIORITY_CLASS);
		DWORD retCode = ::WaitForSingleObject(m_CommThread->m_hThread, 1000);
		if (retCode == WAIT_OBJECT_0)
		{
			m_CommThread = NULL;
		}
	}
	return TRUE;	
}
void CAsyncComm::SetAcceptNULL(BOOL bUse)
{
	m_bAcceptNULL = bUse;
}
void CAsyncComm::SetCmdSize(int nNum)
{
	m_nCmdSize = nNum;
}

void CAsyncComm::SetPortOpen(BOOL bOpen)
{
	FPortOpened = bOpen;
}

void CAsyncComm::SetHIOKI8431(BOOL bHIOKI)
{
	m_bHIOKI8431 = bHIOKI;
}
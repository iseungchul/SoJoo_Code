// SysUMAC.h: interface for the CSysUMAC class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SYSUMAC_H__6C89BB40_E642_4F8C_8360_43150FB807FC__INCLUDED_)
#define AFX_SYSUMAC_H__6C89BB40_E642_4F8C_8360_43150FB807FC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "CmdQueue.h"
#include "Timer.h"

//#define	STAGE_SUNHWAN

const double	STAGE_X_FACTOR			= 6400.0;
const double	STAGE_Y_FACTOR			= 6400.0;
const double	STAGE_Z_FACTOR			= 10000.0;
#ifdef STAGE_SUNHWAN
const double	STAGE_T_FACTOR			= (2621440.0/360);
#else
const double	STAGE_T_FACTOR			= 11377.7;
#endif
const double	PREALIGNER_X_FACTOR		= 819.2;
const double	PREALIGNER_Z_FACTOR		= 819.2;
const double	COATERPICKER_Y_FACTOR	= 819.2;
const double	COATERPICKER_Z_FACTOR	= 819.2;
const double	STAGEPICKER_X_FACTOR	= 819.2;

const double	MAGAZINE_ELEVATOR_FACTOR	= 819.2;
const double	LPICKER_Y_FACTOR		= 819.2;
const double	LPICKER_Z_FACTOR		= 819.2;
const double	BPICKER_Y_FACTOR		= 819.2;
const double	BPICKER_Z_FACTOR		= 819.2;
const double	PREALIGN_RAIL_FACTOR	= 819.2 * 2.0;
const double	PREALIGN_GRIPPER_FACTOR	= 819.2;
const double	SPINCOATER_T_FACTOR		= 4000.0;
const double	SPINCOATER_Z_FACTOR		= 1638.4;
const double	SPINCOATER_ARM_FACTOR	= 200.0;

class CSysUMAC  
{
public:
	CSysUMAC();
	virtual ~CSysUMAC();

// Operation
public:
	LONG GetCurrentError(ERRORCOMMAND nError);
	double GetPosition(int nAxis);

	// Initialze or Destory Operation
	BOOL		InitializeUMAC();
	void		DestroyUMAC();
	BOOL		PmacConfigureComm(HWND Wnd);
	BOOL		GetUMACDriver()			{ return m_bDriverOpen; }

	// Thread Start or Stop Operation
	BOOL		StartUMACThread();
	void		StopUMACThread();

	// Real Time Buffer
	BOOL		DPRUpdateRealtime();
	BOOL		DPRRealTimeEx(long mask, UINT period, long on);

	// Read Motor Position & Velociy
	double		DPRPosition(int i, double units);
	double		DPRGetVel(int i, double units);

	// Online Command
	BOOL		GetResponse(PCHAR a,UINT maxchar,PCHAR q);

	// Send Command To UMAC
	BOOL		SendCmdToUMAC();
	BOOL		SetOnlineCmdResponse(char* szCmd, char* szBuf);
	BOOL		SetDPRamResponse(int nSize, DWORD dwOffset, DWORD* pMemData);
	void		SendHandlerMonitor();
	void		SendHandlerInput();

	// Get Error Message
	void		SetUMACErrorMsg(int nErrorCode);

	// Set Move Motor
	void		MoveMotor(int nAxis, double dPos);
	void		MoveXYTable(double dXPos, double dYPos);
	void		InitializeMotor(int nAxis);
	void		SetMotorSpeed(int nAxis, int nSpeed);
	void		StartPolygon(int nSpeed);
	void		StopPolygon();

	// Laser On / Off Control
	void		UVLaserOnOffControl(BOOL bOnOff);
	void		CO2LaserOnOffControl(BOOL bOnOff);

	// Cassette Slot Status Change
	void		ChangeCassetteSlot(int nCutSlot, int nSlotStatus);

	// UMAC Motion Program
	void		StartMotion(int nCoordinate, int nMotionNo);
	void		StopMotion(int nCoordinate=1);

	// Check Motion Status
	void		SetCheckMotionStatus(BOOL bStatus)	{ m_bCheckMotionStatus = bStatus; }
	BOOL		GetCheckMotionStatus()				{ return m_bCheckMotionStatus; }
	void		IsExecutionMotion();

	// Download System Parameter
	void		OnDownloadSysParam();
	void		OnDownloadSysHandlerParam();
	void		OnDownloadSysCoaterParam();
	void		OnDownloadCoatingParam();
	void		OnDownloadCleaningParam();

	// Upload System Parameter
	void		OnUploadSysHandlerParam();
	void		OnUploadSysCoaterParam();
	void		OnUploadCoatingParam();
	void		OnUploadCleaningParam();
	void		SetDPRamUploadData( DOnlineCmdData*	pData );
	BOOL		CompareDPRamData( int nType );
	void		SetDPRamDataType(int nType, BOOL bVal);
	BOOL		GetDPRamDataType(int nType);
	void		OnApplyUploadSysHandlerParam();
	void		OnApplyUploadSysCoaterParam();
	void		OnApplyUploadCoatingParam();
	void		OnApplyUploadCleaningParam();

	// Change Wafer Processing Information
	void		OnDownloadWaferInfo(int* pWaferStatus, int* pWaferSlot);

	// Thread Event
	CEvent		m_EvtTerminate;
	CEvent		m_EvtGoodbye;

	// Motion Finish Event
	CEvent		m_EvtMotion;

	// Motion Start Event
	CEvent		m_EvtStartMotion;

	// Stage Position
//	DSTAGEPOS				m_sStagePos;

	// Handler Position
//	DHANDLERPOS				m_sHandlerPos;

	// Online Command Queue
	CCmdQueue				m_clsCmdQueue;

	// UMAC Timer
	CTimer					m_clsTimer;

	// Motion Start
	int			GetStartMotion()	{ return m_nStartMotion; }
	void		SetStartMotion(int nStart) { m_nStartMotion = nStart; }

	// Motion Error
	void		SetMotionError(BOOL bError)	{ m_bMotionError = bError; }
	BOOL		GetMotionError()			{ return m_bMotionError; }

	// UMAC Error Message
	CString		GetUMACErrMsg()				{ return m_strUMACErrMsg; }

	// Attributed
protected:

	// UMAC
	HINSTANCE				m_hPmacLib;
	BOOL					m_bDriverOpen;
	DWORD					m_dwDevice;

	// UMAC Worker Thread
	CWinThread*				m_pThread;

	// Position Index
	int						m_nMonitorIndex;
	int						m_nHandlerInputIndex;

	// Check Motion Status
	BOOL					m_bCheckMotionStatus;
	int						m_nMotionStatus;
	BOOL					m_nStartMotion;
	BOOL					m_bMotionError;

	// UMAC Error Message
	CString					m_strUMACErrMsg;

	// DPRAM Data Type
	BOOL					m_bHandlerSysDownload;
	BOOL					m_bSpinnerSysDownload;
	BOOL					m_bHandlerSysUpload;
	BOOL					m_bSpinnerSysUpload;
	BOOL					m_bCoatingParamDownload;
	BOOL					m_bCleaningParamDownload;
	BOOL					m_bCoatingParamUpload;
	BOOL					m_bCleaningParamUpload;

	// Upload DPRam Data
	int						m_nSysHandlerParam[48];
	int						m_nUploadSysHandlerParam[48];
	int						m_nSysCoaterParam[11];
	int						m_nUploadSysCoaterParam[11];
	int						m_nCoatingParam[80];
	int						m_nUploadCoatingParam[80];
	int						m_nCleaningParam[80];
	int						m_nUploadCleaningParam[80];
	int						m_nCoatingParamSize;
	int						m_nCleaningParamSize;
};

//extern CSysUMAC gSysUMAC;

#endif // !defined(AFX_SYSUMAC_H__6C89BB40_E642_4F8C_8360_43150FB807FC__INCLUDED_)

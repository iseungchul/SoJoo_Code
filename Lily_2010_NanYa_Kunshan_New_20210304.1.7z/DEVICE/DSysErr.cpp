// DSysErr.cpp: implementation of the DSysErr class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "DSysErr.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DSysErr::DSysErr()
{
	// M7016. $60210
	m_bDoorInterlock			= 0;
	m_bInitialReq				= 0;
	m_bSysAirLow				= 0;
	m_bStageAirLow				= 0;
	m_bSysVacuumLow				= 0;
	m_bN2GasLow					= 0;
	m_bPolygonAirLow			= 0;
	m_bN2TankAirLow				= 0;
	m_bMpgOnStatus				= 0;
	m_bGripperCatch				= 0;
	m_bLPickerWaferCatch		= 0;
	m_bBPickerWaferCatch		= 0;
	m_bWaferExistRailInit		= 0;
	m_bWaferOverload			= 0;
	m_bAlignRailWafer			= 0;

	// M7017. $60211
	m_bCoaterWaferCheck			= 0;
	m_bStageWaferCheck			= 0;
	m_bBufferWaferCheck			= 0;
	m_bOmit8InchCassette		= 0;
	m_bOmit12InchCassette		= 0;
	m_bServoPower				= 0;
	m_bEmgSw					= 0;
	m_bPolygonAmpFault			= 0;
	m_bPolygonOpenLoop			= 0;
//	m_bTableVacuumOn			= 0;
//	m_bTableVacuumOff			= 0;
	m_bPickerWafer				= 0;
	m_bIncorrectPickerWaferSize	= 0;
	m_bGripperCatchWaferErr		= 0;

	// M7096. $60260
	m_bGripperCylinderFw		= 0;
	m_bGripperCylinderBw		= 0;
	m_bBufferAlignerCylinderFw	= 0;
	m_bBufferAlignerCylinderBw	= 0;
	m_bLaserShutterCylinderFw	= 0;
	m_bLaserShutterCylinderBw	= 0;
	m_bPickerZCylinderFw		= 0;
	m_bPickerZCylinderBw		= 0;
	m_bPickerWaferSizeFw		= 0;
	m_bPickerWaferSizeBw		= 0;

	// M7099. $60263
//	m_bCoaterDoorCylinderFw		= 0;
//	m_bCoaterDoorCylinderBw		= 0;

	// M7100. $60264
	m_bSpinThetaSpeed			= 0;
	m_bCoater					= 0;
	m_bArmMotionErr				= 0;
	m_bSpinThetaVacuum			= 0;
	m_bTankEmpty				= 0;
	m_bCoaterWaterLeak			= 0;

	// M7101. $60265
	m_bInit						= 0;
	m_bScanCassette				= 0;
	m_bCassetteToAligner		= 0;
	m_bAlignerToCassette		= 0;
	m_bAlignerToLPicker			= 0;
	m_bLPickerToCoater			= 0;
	m_bCoaterToLPicker			= 0;
	m_bLPickerToChuck			= 0;
	m_bChuckToLPicker			= 0;
	m_bLPickerToAligner			= 0;
	m_bLPickerToBuffer			= 0;
	m_bBufferToBPicker			= 0;
	m_bBPickerToChuck			= 0;
	m_bCoating					= 0;
	m_bCleaning					= 0;

	// M7102. $60266
	m_bAlignRailZone			= 0;
	m_bCoaterZone				= 0;
	m_bLPickerZone				= 0;
	m_bBufferZone				= 0;
	m_bStageZone				= 0;
	m_bBufferPickerZone			= 0;
}

DSysErr::~DSysErr()
{

}

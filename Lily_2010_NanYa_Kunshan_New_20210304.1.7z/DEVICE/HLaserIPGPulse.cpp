// HLaserIPGPulse.cpp: implementation of the HLaserIPGPulse class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "HLaserIPGPulse.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#include "..\device\hdevicefactory.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HLaserIPGPulse::HLaserIPGPulse()
{
	m_pEOCard	= NULL;
	m_bPower	= FALSE;
	m_bShutter	= FALSE;

	m_lPortA	= 0x320;
	m_lPortB	= 0x321;
	m_lPortC	= 0x322;
	m_lAutoCard	= 0x328;

	m_bGuideBeam = false;
	m_bPreampError = false;
	m_bOverHeatError = false;
	m_bEmergencyError = false;
}

HLaserIPGPulse::~HLaserIPGPulse()
{
	m_pEOCard->SetFunction(0xFFFF);
}

void HLaserIPGPulse::Initialize()
{
	m_pEOCard = gDeviceFactory.GetEocard();
	
	m_pEOCard->SetFunction(0xFFFF);
}

BOOL HLaserIPGPulse::IsPowerOn()
{
//	UpdateStatus();
//	return m_bPower;
	return TRUE;
}

BOOL HLaserIPGPulse::IsShutterOpen()
{
//	UpdateStatus();
//	return m_bShutter;
	return TRUE;
}

void HLaserIPGPulse::PowerOn(BOOL bFlag)
{
//	USHORT usFunction = m_pEOCard->GetFunction();
//	if(bFlag)	usFunction &= 0xFFFA;
//	else		usFunction |= 0x0005;
//	m_pEOCard->SetFunction(usFunction);

	return;

	ULONG lTemp = 0;
	bool bErrorFlag = false;

	if(bFlag)
	{
		bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortC, lTemp);
		lTemp |= 0x02;
		m_pEOCard->m_pDriver->writeIFCard(m_lPortC, lTemp);
	}
	else
	{
		bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortC, lTemp);
		lTemp &= ~0x02;
		m_pEOCard->m_pDriver->writeIFCard(m_lPortC, lTemp);
	}
	
	m_bPower = bFlag;
}

void HLaserIPGPulse::ShutterOpen(BOOL bFlag)
{
//	USHORT usFunction = m_pEOCard->GetFunction();
//	if(bFlag)	usFunction &= 0xFFFD;
//	else		usFunction |= 0x0002;
//	m_pEOCard->SetFunction(usFunction);

	return;

	ULONG lTemp = 0;
	bool bErrorFlag = false;
	
	if(bFlag)
	{
		bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortC, lTemp);	
		lTemp &= ~0x01;
		m_pEOCard->m_pDriver->writeIFCard(m_lPortC, lTemp);
	}
	else
	{
		bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortC, lTemp);
		lTemp |= 0x01;
		m_pEOCard->m_pDriver->writeIFCard(m_lPortC, lTemp);
	}
	
	m_bShutter = bFlag;	
}

BOOL HLaserIPGPulse::SetCurrent(int nCurrent)
{
	if(nCurrent > 255)
	{
		ErrMessage(_T("Max current is over than specification."));
		return FALSE;
	}
	
	if(nCurrent < 0)
	{
		ErrMessage(_T("Min currnet is under than specification."));			
		return FALSE;
	}
	
	bool bErrorFlag = false;
	ULONG lCurrent = (ULONG) nCurrent;
	bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortB, lCurrent);
	
	ULONG lTemp = 0;
//	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortC, lTemp);
	
	for(int i=0;i<5;i++)
	{
		bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortC, lTemp);
		lTemp |= 0x04;
		bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortC, lTemp);
		Sleep(50);
		lTemp &= ~0x04;
		bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortC, lTemp);
		Sleep(50);
	}

	return TRUE;
}

POWER_STATUS HLaserIPGPulse::GetStatus()
{
	memset(&m_gStatus, 0, sizeof(m_gStatus));
	m_gStatus.bShutterOn = TRUE;
	m_gStatus.bPowerOn = TRUE;
	
//	UpdateStatus();
	
	return m_gStatus;
}

void HLaserIPGPulse::UpdateStatus()
{
	return;
	
#ifndef __TEST__
	ULONG lTemp = 0;
	bool bErrorFlag = false;
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortC, lTemp);
	if(lTemp & 0x40)
	{
		m_bPower = TRUE;
		m_bPreampError = false;
	}
	else
	{
		m_bPower = FALSE;
		m_bPreampError = true;
	}
	
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortA, lTemp); //hjlee
	
	if(lTemp & 0x02)
		m_bOverHeatError = false;
	else
		m_bOverHeatError = true;
	
	bool bPlusError = false, bMinusError = false;
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lAutoCard, lTemp);
	if(lTemp & 0x01)
		bPlusError = true;
	else
		bPlusError = false;
	
	if(lTemp & 0x02)
		bMinusError = true;
	else
		bMinusError = false;
	
	if(bPlusError || bMinusError)
		m_bEmergencyError = true; 
	else
		m_bEmergencyError = false;
	
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortC, lTemp);
	if(lTemp & 0x80)
		m_bShutter = FALSE;
	else
		m_bShutter = TRUE;
	
	if(lTemp & 0x08)
		m_bGuideBeam = true;
	else
		m_bGuideBeam = false;
#endif

	m_gStatus.bShutterOn = m_bShutter;
	m_gStatus.bPowerOn = m_bPower;
}

bool HLaserIPGPulse::ActionCommand(BOOL bOn)
{	
	bool bErrorFlag = false;
	ULONG lTemp = 0;
	bErrorFlag = m_pEOCard->m_pDriver->readIFCard(m_lPortC, lTemp);
	
//	if(m_bGuideBeam)
	if(!bOn)
	{
		m_bGuideBeam = false;
		lTemp &= ~0x08;
		bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortC, lTemp);
	}
	else
	{
		m_bGuideBeam = true;
		lTemp |=0x08;
		bErrorFlag = m_pEOCard->m_pDriver->writeIFCard(m_lPortC, lTemp);
	}
	return true;
}
//*****************************************************************************
// Filename: ORBTYPES.H
//
// Type definitions for 32 Bit Orbit Interface (Orbit_if.dll)
// For use with 32 Bit C compilers
//*****************************************************************************


//*********************************************
// Type definitions for Orbit Network functions
//*********************************************

typedef int (WINAPI *tConnectToOrbitNetworks)(int* NumberOfOrbitNetworks);

typedef int (WINAPI *tDisconnectFromOrbitNetworks)(void);

typedef int (WINAPI *tResetNetworkController)(int NetworkNumber);

typedef int (WINAPI *tGetOrbitNetworkNameAndType)(int NetworkNumber,
                                                  char* NetworkName,
                                                  int* NetworkType);

typedef int (WINAPI *tReportOrbitProbeAssignment)(int NetworkNumber,
             struct PROBE_ASSIGNMENT* ReportAssignment);

typedef int (WINAPI *tReportOrbitInterfaceVersion)(int* RevisionNumbers,
             char* VersionStr);


//*******************************************
// Type definitions for Orbit Module Commands 
//*******************************************

typedef int (WINAPI * tOrbitRst)(int network);

typedef int (WINAPI * tOrbitNotify)(int network,
                                    char id[]);

typedef int (WINAPI *tOrbitSetaddr)(int network,
                                    int oaddr,
                                    char id[],
                                    int *opt);

typedef int (WINAPI *tOrbitClr)(int network,
                                int oaddr);

typedef int (WINAPI *tOrbitIdentify)(int network,
                                     int oaddr,
                                     char id[],
                                     char devtype[],
                                     char ver[],
                                     int *stroke);

typedef int (WINAPI *tOrbitGetinfo)(int network,
                                    int oaddr,
                                    char moduletype[],
                                    int *hwtype,
                                    int *reso,
                                    char moduleinfo[]);

typedef int (WINAPI *tOrbitGetstatus)(int network,
                                      int oaddr,
                                      int *errcode,
                                      int *status);

typedef int (WINAPI *tOrbitRead1)(int network,
                                  int oaddr,
                                  int *rd);

typedef int (WINAPI *tOrbitRead2)(int network,
                                  int oaddr,
                                  long *rdlong);

typedef int (WINAPI *tOrbitAcquire)(int network,
                                    int oaddr,
                                    int *rdgs,
                                    int *dly);

typedef int (WINAPI *tOrbitTrigger)(int network);

typedef int (WINAPI *tOrbitReadia)(int network,
                                   int oaddr,
                                   int rdarray[]);

typedef int (WINAPI *tOrbitDifference)(int network,
                                       int oaddr);

typedef int (WINAPI *tOrbitStartdiff)(int network);

typedef int (WINAPI *tOrbitStopdiff)(int network);

typedef int (WINAPI *tOrbitReaddiff1)(int network,
                                      int oaddr,
                                      int *min,
                                      int *max,
                                      double *sum,
                                      long *num);

typedef int (WINAPI *tOrbitReaddiff2)(int network,
                                      int oaddr,
                                      long *minlong,
                                      long *maxlong);

typedef int (WINAPI *tOrbitPreset)(int network,
                                   int oaddr,
                                   long *pst);

typedef int (WINAPI *tOrbitRefmark)(int network,
                                    int oaddr);

typedef int (WINAPI *tOrbitDirection)(int network,
                                      int oaddr);


// FCalibration.h: interface for the FCalibration class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FCALIBRATION_H__2C0E0C63_02BD_11D4_888E_004F49089C0D__INCLUDED_)
#define AFX_FCALIBRATION_H__2C0E0C63_02BD_11D4_888E_004F49089C0D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "stdafx.h"

const int	MAX_CAL_X		= 65;
const int	MAX_CAL_Y		= 65;

class FCalibration
{
public:
	int CalM[MAX_CAL_X][MAX_CAL_Y][2];
	int CalS[MAX_CAL_X][MAX_CAL_Y][2];

public:
	void Copy( FCalibration *ptr );
	void Reset( void );
	FCalibration();
	virtual ~FCalibration();
};

#endif // !defined(AFX_FCALIBRATION_H__2C0E0C63_02BD_11D4_888E_004F49089C0D__INCLUDED_)

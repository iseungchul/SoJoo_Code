// DSysInput.cpp: implementation of the DSysInput class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "DSysInput.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DSysInput::DSysInput()
{
	// M7000. $60200
	m_bEmgStop			= 0;
	m_bServoPowerOn		= 0;
	m_bVacuumMotorOn	= 0;
	m_bResetSwitch		= 0;
	m_bInitSwitch		= 0;
	m_bMpgAxisSelect1	= 0;
	m_bMpgAxisSelect2	= 0;
	m_bMpgAxisSelect4	= 0;
	m_bMpgFeedSelect1	= 0;
	m_bMpgFeedSelect2	= 0;
	m_bMpgFeedSelect4	= 0;
//	m_bMpgJogPlus		= 0;
//	m_bMpgJogMinus		= 0;

	// M7001. $60201
//	m_bMpgEnableSwitch			= 0;
	m_bSysAirPressure			= 0;
	m_bStageAirPressure			= 0;
	m_bSysVacuumPressure		= 0;
	m_bN2GasPressure			= 0;
	m_bPolygonAirPressure		= 0;
	m_bN2TankPressure			= 0;
	m_bCoatingWaterLeak			= 0;
	m_bChuckVacuumPressure		= 0;
	m_bOpticalShutterCylinderFw	= 0;
	m_bOpticalShutterCylinderBw	= 0;
	m_bLPickerVacuumPressure	= 0;
	m_bBPickerVacuumPressure	= 0;

	// M7002. $60202
	m_bCassetteMagazineDetect	= 0;
	m_bCassette8InchDetect		= 0;
	m_bCassette12InchDetect		= 0;
	m_bWaferOverloadDetect		= 0;
	m_bWaferScan				= 0;
	m_bAlignerWaferStatus		= 0;
	m_bGripperWaferCatch		= 0;
	m_bGripperWaferMissCatch	= 0;
	m_bPrealignerCylinderFw		= 0;
	m_bPrealignerCylinderBw		= 0;
	m_bBufferGuideWafer8InchDetect		= 0;
	m_bBufferGuideWafer12InchDetect		= 0;
	m_bLPicker12InchCheck		= 0;
	m_bLPicker8InchCheck		= 0;
	m_bBPicker12InchCheck		= 0;
	m_bBPicker8InchCheck		= 0;
//	m_bSpinCover1Fw				= 0;
//	m_bSpinCover1Bw				= 0;
//	m_bSpinCover2Fw				= 0;
//	m_bSpinCover2Bw				= 0;

	// M7003. $60203
	m_bFrontDoor				= 0;
	m_bSide1Door				= 0;
	m_bSide2Door				= 0;
	m_bRearDoor					= 0;
//	m_bDoorLockConfirm			= 0;
	m_bCoaterChuckVacuum		= 0;
	m_bCDAPressure				= 0;
	m_bLPickerCylinderUp		= 0;
	m_bLPickerCylinderDown		= 0;
	m_bShutterInterlockSensor	= 0;

	// M7004. $60204
	m_bResetSWLamp				= 0;
	m_bInitSWLamp				= 0;
	m_bMpgLed					= 0;
	m_bTowerLampRed				= 0;
	m_bTowerLampYellow			= 0;
	m_bTowerLampGreen			= 0;
	m_bTowerLampBuzzer1			= 0;
	m_bTowerLampBuzzer2			= 0;
	m_bFluorescentLight			= 0;
	m_bCoatingVacuumMotor		= 0;
	m_bChuckVacuum8Inch			= 0;
	m_bChuckVacuum				= 0;
//	m_bChuckVacuumExhuast		= 0;
	m_bTable8InchVacuumExhuastSol = 0;
	m_bHeadBlowerSol			= 0;
	m_bGripperSol				= 0;
	m_bPrealignerCylinderSol	= 0;
	m_bFrontDoorLockSol			= 0;
	m_bSideDoorLockSol			= 0;

	// M7005. $60205
	m_bOpticalShutterCylinderSol	= 0;
//	m_bSpinCoverSol					= 0;
	m_bLPickerUpDownSol				= 0;
	m_bTable12InchVacuumExhaustSol	= 0;
	m_bLPickerVacuumSol				= 0;
	m_bLPickerVacuumExhuastSol		= 0;
	m_bBPickerVacuumSol				= 0;
	m_bBPickerVacuumExhuastSol		= 0;
	m_bHighPressurePumpAirSol		= 0;
	m_bN2GasSupplySol				= 0;
	m_bCoatingLiquidSupplySol		= 0;
	m_bSpinVacuumSupplySol			= 0;
	m_bSpinVacuumExhuastSol			= 0;
	m_bHighPressurePumpDISupplySol	= 0;
	m_bDIShowerSupplySol			= 0;

	// M7006. $60206
	m_bLaserEnable					= 0;
	m_bPickerWaferSol8Inch			= 0;
	m_bPickerWaferSol12Inch			= 0;
	m_bShutterInterlockSol			= 0;

	// M7008. $60208
	m_bLaserShutterCylinderFw		= 0;
	m_bLaserShutterCylinderBw		= 0;
	m_bInitStageMotor				= 0;
	m_bInitHnadlerMotor				= 0;
	m_bInitSpinCoaterMotor			= 0;
	m_bLotEnd						= 0;
//	m_bCoaterZAxisStatus			= 0;
	m_bCoaterArmPosStatus			= 0;
	m_bCoaterReady					= 0;
	m_bCoaterProgress				= 0;
	m_bCoaterErr					= 0;

	// M7009. $60209
	m_bRunStageX					= 0;
	m_bRunStageY					= 0;
	m_bRunStageT					= 0;
	m_bRunStageZ					= 0;
	m_bRunElevator					= 0;
	m_bRunAlignRail					= 0;
	m_bRunGripper					= 0;
	m_bRunLPickerY					= 0;
	m_bRunLPickerZ					= 0;
	m_bRunBPickerY					= 0;
	m_bRunBPickerZ					= 0;
	m_bRunCoaterSpinT				= 0;
//	m_bRunCoaterSpinZ				= 0;
	m_bRunCoaterSArm				= 0;

	// M7010. $6020A
	m_nCoaterProcessTime			= 0;

	// M7011. $6020B
	m_nSemiAutoRun = 0;
}

DSysInput::~DSysInput()
{

}

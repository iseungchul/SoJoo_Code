// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "IEODriver.h"



//##ModelId=4034007E01A6
IEODriver::IEODriver()
{
	// ToDo: Add your specialized code here and/or call the base class
}

//##ModelId=4034007E01A7
IEODriver::~IEODriver()
{
	// ToDo: Add your specialized code here and/or call the base class
}



//##ModelId=4034007E0197
bool IEODriver::writeIFCard(const ULONG port, const ULONG data, const char type)
{
	return (bool)0;
}

//##ModelId=4034007E019C
bool IEODriver::readIFCard( ULONG port, ULONG& data, const char type)
{
	data = 0;
	return (bool)0;
}


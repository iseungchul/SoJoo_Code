// PaneSysSetupMGC2.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetupMGC2.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\model\dsystemini.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupMGC2

IMPLEMENT_DYNCREATE(CPaneSysSetupMGC2, CFormView)

CPaneSysSetupMGC2::CPaneSysSetupMGC2()
	: CFormView(CPaneSysSetupMGC2::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupMGC2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneSysSetupMGC2::~CPaneSysSetupMGC2()
{
}

void CPaneSysSetupMGC2::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupMGC2)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_BTN_OPEN, m_btnOpenASC);
	DDX_Control(pDX, IDC_BTN_APPLY, m_btnApply);
	DDX_Control(pDX, IDC_BTN_SAVE, m_btnSaveAs);

	DDX_Control(pDX, IDC_EDT_X, m_edtX1);
	DDX_Control(pDX, IDC_EDT_X2, m_edtX2);
	DDX_Control(pDX, IDC_EDT_X3, m_edtX3);
	DDX_Control(pDX, IDC_EDT_Y, m_edtY1);
	DDX_Control(pDX, IDC_EDT_Y2, m_edtY2);
	DDX_Control(pDX, IDC_EDT_Y3, m_edtY3);
	DDX_Control(pDX, IDC_EDT_FIELD_X, m_edtScannerFieldX);
	DDX_Control(pDX, IDC_ASC_FILE, m_edtASCFile);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupMGC2, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupMGC2)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BTN_OPEN, OnBtnOpen)
	ON_BN_CLICKED(IDC_BTN_APPLY, OnBtnApply)
	ON_BN_CLICKED(IDC_BTN_SAVE, OnBtnSave)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupMGC2 diagnostics

#ifdef _DEBUG
void CPaneSysSetupMGC2::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupMGC2::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupMGC2 message handlers

void CPaneSysSetupMGC2::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_STC_GROUP_EDIT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_GROUP_EDIT2)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STC_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_X2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_X3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_X4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_Y2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STC_Y3)->SetFont( &m_fntStatic );
}

HBRUSH CPaneSysSetupMGC2::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STC_GROUP_EDIT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STC_GROUP_EDIT2)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

BOOL CPaneSysSetupMGC2::PreCreateWindow(CREATESTRUCT& cs) 
{
	// TODO: Add your specialized code here and/or call the base class
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

void CPaneSysSetupMGC2::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitBtnControl();
	InitEditControl();
	InitData();
}

void CPaneSysSetupMGC2::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	
	m_btnOpenASC.SetFont( &m_fntBtn );
	m_btnOpenASC.SetFlat( FALSE );
	m_btnOpenASC.EnableBallonToolTip();
	m_btnOpenASC.SetToolTipText( _T("Open ASC File") );
	m_btnOpenASC.SetBtnCursor(IDC_HAND_1);

	m_btnApply.SetFont( &m_fntBtn );
	m_btnApply.SetFlat( FALSE );
	m_btnApply.EnableBallonToolTip();
	m_btnApply.SetToolTipText( _T("Apply") );
	m_btnApply.SetBtnCursor(IDC_HAND_1);

	m_btnSaveAs.SetFont( &m_fntBtn );
	m_btnSaveAs.SetFlat( FALSE );
	m_btnSaveAs.EnableBallonToolTip();
	m_btnSaveAs.SetToolTipText( _T("Save File As..") );
	m_btnSaveAs.SetBtnCursor(IDC_HAND_1);
}

void CPaneSysSetupMGC2::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	m_edtX1.SetFont( &m_fntEdit );
	m_edtX1.SetReceivedFlag( 1 );
	m_edtX1.SetWindowText( _T("80") );

	m_edtX2.SetFont( &m_fntEdit );
	m_edtX2.SetReceivedFlag( 1 );
	m_edtX2.SetWindowText( _T("75") );

	m_edtX3.SetFont( &m_fntEdit );
	m_edtX3.SetReceivedFlag( 1 );
	m_edtX3.SetWindowText( _T("80") );

	m_edtY1.SetFont( &m_fntEdit );
	m_edtY1.SetReceivedFlag( 1 );
	m_edtY1.SetWindowText( _T("80") );
	
	m_edtY2.SetFont( &m_fntEdit );
	m_edtY2.SetReceivedFlag( 1 );
	m_edtY2.SetWindowText( _T("83") );
	
	m_edtY3.SetFont( &m_fntEdit );
	m_edtY3.SetReceivedFlag( 1 );
	m_edtY3.SetWindowText( _T("80") );

	m_edtScannerFieldX.SetFont( &m_fntEdit );
	m_edtScannerFieldX.SetReceivedFlag( 1 );
	m_edtScannerFieldX.SetWindowText( _T("70") );

	m_edtASCFile.SetFont( &m_fntEdit );
	m_edtASCFile.SetReceivedFlag( 1 );
	m_edtASCFile.SetWindowText( _T("") );
}

void CPaneSysSetupMGC2::OnBtnOpen() 
{
	// TODO: Add your control notification handler code here
	TCHAR BASED_CODE szFilter[] = _T("Calibration Files (*.asc)|*.asc||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.asc"), NULL, dwFlags, szFilter);
	
	dlg.m_ofn.lpstrInitialDir = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
	
	if(IDOK != dlg.DoModal())
	{
		return;
	}
	
	m_edtASCFile.SetWindowText( dlg.GetPathName() );

	//
	int i, j, k;
	float data;
	TCHAR buf[256];	
	FILE* fp;
	fp = NULL;

	CString str = dlg.GetPathName();
	errno_t err;
	err = fopen_s(&fp, str,_T("rt"));
	
	if(NULL != err)
	{
		ErrMessage(_T("Asc File Open Fail"));
		return;
	}
	
	fgets(buf, sizeof(buf), fp);	
	for (k=0; k < 2; k++) 
	{
		for  (i=0; i<65; i++) 
		{
			for (j=0; j<65; j++)   
			{
				switch(k) {
				case  0:
					fscanf(fp, "%f", &data);
					m_dCalY[j][i]  = (double)data;
					break;
				case  1:
					fscanf(fp, "%f", &data);
					m_dCalX[j][i]  = (double)data;
					break;
				default:  break;
				}
			}//  for (i)
		}//  for (j)
	} //  for (k)	
	fclose(fp);
}

void CPaneSysSetupMGC2::OnBtnApply() 
{
	// TODO: Add your control notification handler code here
	GetValueFromUI();

	double dX1, dX2, dX3, dY1, dY2, dY3;
	dX1 = (m_nX1 - m_nScannerFieldX)/2. / gSystemINI.m_sSystemDevice.dOriginFieldSize.x * MAXLSB;
	dX2 = (m_nX2 - m_nScannerFieldX)/2. / gSystemINI.m_sSystemDevice.dOriginFieldSize.x * MAXLSB;
	dX3 = (m_nX3 - m_nScannerFieldX)/2. / gSystemINI.m_sSystemDevice.dOriginFieldSize.x * MAXLSB;

	dY1 = (m_nY1 - m_nScannerFieldX)/2. / gSystemINI.m_sSystemDevice.dOriginFieldSize.x * MAXLSB;
	dY2 = (m_nY2 - m_nScannerFieldX)/2. / gSystemINI.m_sSystemDevice.dOriginFieldSize.x * MAXLSB;
	dY3 = (m_nY3 - m_nScannerFieldX)/2. / gSystemINI.m_sSystemDevice.dOriginFieldSize.x * MAXLSB;

	double dLBx, dLTx, dRBx, dRTx, dLBy, dLTy, dRBy, dRTy;
	double ax, ay, dmid1, dmid2;
	double dStep = 32;
	

	for(int i = 0; i < ASC_AXIS_SIZE; i++)
	{
		for(int j = 0; j < ASC_AXIS_SIZE; j++)
		{
			if(i < 32 && j < 32)
			{
				dLBx = dX1; dLTx = dX2; dRBx = 0;	dRTx = 0;
				dLBy = dY1; dLTy = 0;	dRBy = dY2; dRTy = 0;
				ax	= i/dStep; ay = j/dStep;
			}
			else if(i >= 32 && j < 32)
			{
				dLBx = 0;	dLTx = 0;	dRBx = -dX1;	dRTx = -dX2;
				dLBy = dY2; dLTy = 0;	dRBy = dY3; dRTy = 0;
				ax	= (i - 32)/dStep; ay = j/dStep;
			}
			else if(i < 32 && j >= 32)
			{
				dLBx = dX2; dLTx = dX3;		dRBx = 0;	dRTx = 0;
				dLBy = 0;	dLTy = -dY1;	dRBy = 0;	dRTy = -dY2;
				ax	= i/dStep; ay = (j - 32)/dStep;
			}
			else
			{
				dLBx = 0;	dLTx = 0;		dRBx = -dX2; dRTx = -dX3;
				dLBy = 0;	dLTy = -dY2;	dRBy = 0;	 dRTy = -dY3;
				ax	= (i - 32)/dStep; ay = (j - 32)/dStep;
			}
			
			dmid1 = ax * dRBx + (1-ax) * dLBx;
			dmid2 = ax * dRTx + (1-ax) * dLTx;
			m_dCalX[i][j] += (ay * dmid2 + (1-ay) * dmid1);

			dmid1 = ax * dRBy + (1-ax) * dLBy;
			dmid2 = ax * dRTy + (1-ax) * dLTy;
			m_dCalY[i][j] += (ay * dmid2 + (1-ay) * dmid1);

			if(i == 0 || i == 32 || i == 64 || j == 0 || j == 32 || j == 64)
			{
//				TRACE("i = \t%d\t , j = \t%d\t, \t%.0f\t%.0f\n", i, j, m_dCalX[i][j], m_dCalY[i][j]);
//				::Sleep(10);
			}
		}
	}
}

void CPaneSysSetupMGC2::OnBtnSave() 
{
	// TODO: Add your control notification handler code here
	TCHAR BASED_CODE szFilter[] = _T("ASC Files (*.asc)|*.asc|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CString strFull, strAddr, strFile;

	m_edtASCFile.GetWindowText( strFull );

	int nToken = strFull.ReverseFind(_T('\\'));
	if(nToken == -1)
	{
		strAddr = gEasyDrillerINI.m_clsDirPath.GetCorrectDir();
		strFile = strFull;
	}
	else
	{
		strAddr = strFull.Mid(0,nToken);
		strFile = strFull.Mid(nToken+1);
	}
	
	CFileDialog dlg(FALSE, _T("*.asc"), strFile, dwFlags, szFilter);
	dlg.m_ofn.lpstrInitialDir = strAddr;
	if(IDOK != dlg.DoModal())
	{
		return;
	}
	
	if(FALSE == SaveASC(dlg.GetPathName()))
	{
		ErrMessage(_T("ASC file save failure"));
		return; // error �α� ��� ����� �����Ѵ� -> ���� �߰�
	}

}

void CPaneSysSetupMGC2::SetAuthorityByLevel(int nLevel)
{
	switch(nLevel)
	{
	case 0:
	case 1:
		EnableControl(FALSE);
		break;
	case 2:
	case 3:
		EnableControl(TRUE);
		break;
	}
}

void CPaneSysSetupMGC2::EnableControl(BOOL bUse)
{
	m_btnOpenASC.EnableWindow(bUse);
	m_btnApply.EnableWindow(bUse);
	m_btnSaveAs.EnableWindow(bUse);

	m_edtX1.EnableWindow(bUse);
	m_edtX2.EnableWindow(bUse);
	m_edtX3.EnableWindow(bUse);
	m_edtY1.EnableWindow(bUse);
	m_edtY2.EnableWindow(bUse);
	m_edtY3.EnableWindow(bUse);
	m_edtScannerFieldX.EnableWindow(bUse);
}

void CPaneSysSetupMGC2::GetValueFromUI()
{
	CString str;
	m_edtX1.GetWindowText( str );
	m_nX1 = atoi(str);
	
	m_edtX2.GetWindowText( str );
	m_nX2 = atoi(str);

	m_edtX3.GetWindowText( str );
	m_nX3 = atoi(str);

	m_edtY1.GetWindowText( str );
	m_nY1 = atoi(str);

	m_edtY2.GetWindowText( str );
	m_nY2 = atoi(str);

	m_edtY3.GetWindowText( str );
	m_nY3 = atoi(str);

	m_edtScannerFieldX.GetWindowText( str );
	m_nScannerFieldX = atoi(str);
}

BOOL CPaneSysSetupMGC2::SaveASC(CString strPath)
{
	CFile file;	
	if(!file.Open(strPath, CFile::modeCreate | CFile::modeWrite))
		return FALSE;
	
	TCHAR buffer[32];
	CString str;
	
	TRY
	{
		file.Write(_T("LT\r\n"),4);
		
		//y position first
		for(int i=0;i<ASC_AXIS_SIZE;i++)
		{
			for(int j=0;j<ASC_AXIS_SIZE;j++)
			{
				str.Format(_T("%.3f\r\n"), m_dCalY[j][i]);
				for(int kk = 0; kk < str.GetLength(); kk++)
					buffer[kk] = str.GetAt(kk);
				
				file.Write(buffer ,str.GetLength());
			}
		}
		
		//x position second
		for(int i = 0;i<ASC_AXIS_SIZE;i++)
		{
			for(int j=0;j<ASC_AXIS_SIZE;j++)
			{
				str.Format(_T("%.3f\r\n"), m_dCalX[j][i]);
				for(int kk = 0; kk < str.GetLength(); kk++)
					buffer[kk] = str.GetAt(kk);
				
				file.Write(buffer ,str.GetLength());
			}
		}
		
		file.Write("QT\r\n",4);
		if (file.m_hFile != CFile::hFileNull)
			file.Close();
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
		
	return TRUE;
}

void CPaneSysSetupMGC2::InitData()
{
	for  (int i=0; i<65; i++) 
	{
		for (int j=0; j<65; j++)   
		{
			m_dCalY[i][j]  = 0;
			m_dCalX[i][j]  = 0;
		}//  for (i)
	}//  for (j)
}

void CPaneSysSetupMGC2::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	DrawField();
	// Do not call CFormView::OnPaint() for painting messages
}

void CPaneSysSetupMGC2::DrawField()
{
	CClientDC dc(GetDlgItem(IDC_STATIC_VIEW));
	CDC BufferDC;
	CRect cRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetClientRect(&cRect);
	
	BufferDC.CreateCompatibleDC(&dc);
	
	CBitmap bitmap;
	bitmap.CreateCompatibleBitmap(&dc, cRect.Width(), cRect.Height());
	BufferDC.SelectObject(&bitmap);

	CBitmap bitBack;
	bitBack.LoadBitmap(IDB_BITMAP13);

	CDC memDC;
	memDC.CreateCompatibleDC(&dc);
	memDC.SelectObject(&bitBack);

	BufferDC.BitBlt(0, 0, cRect.Width(), cRect.Height(), &memDC, 0, 0, SRCCOPY);
	CBitmap *pOldBitmap = BufferDC.SelectObject(&bitmap);

	//	GetDlgItem(IDC_STATIC_DRAW)->GetWindowRect(&cRect);
	dc.BitBlt(0,0,cRect.Width(),cRect.Height(),&BufferDC,0,0,SRCCOPY);
	
	BufferDC.SelectObject(pOldBitmap);
}

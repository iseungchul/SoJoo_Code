#if !defined(AFX_PANEPROCESSSETUPSYSSETTING_H__6CEC5DD7_5229_4E38_8F1B_07E329341718__INCLUDED_)
#define AFX_PANEPROCESSSETUPSYSSETTING_H__6CEC5DD7_5229_4E38_8F1B_07E329341718__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneProcessSetupSysSetting.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupSysSetting form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"

class CPaneProcessSetupSysSetting : public CFormView
{
protected:
	CPaneProcessSetupSysSetting();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneProcessSetupSysSetting)

// Form Data
public:
	//{{AFX_DATA(CPaneProcessSetupSysSetting)
	enum { IDD = IDD_DLG_PROCESS_SETUP_SYSSETTING };
	UEasyButtonEx	m_chkNoUseDustSuction;
	UEasyButtonEx	m_chkNoUseSuction;
	UEasyButtonEx	m_chkNoUseLoaderUnloader;
	UEasyButtonEx	m_chkNoUseFidFind;
	UEasyButtonEx	m_chkLoaderUnloaderDoorLock;
	UEasyButtonEx	m_chkDryRunWithoutLaser;
	UEasyButtonEx	m_chkNoUseAOMalarm;		//2011526
	UEasyButtonEx	m_chkNoUsePaper;
	UEasyButtonEx	m_chkNoUsePrework;
	UEasyButtonEx	m_chkNoUseChangeView;
	UEasyButtonEx	m_chkCheckPreworkData;
	UEasyButtonEx	m_chkUseGetHighCamOffset;
	UEasyButtonEx	m_chkUseEveryPanelThickness;
	UEasyButtonEx	m_chkUseEveryPanelHeadOffset;
	UEasyButtonEx	m_chkNoUseNGBox;
	UEasyButtonEx	m_chkUseSchedule;
	UEasyButtonEx	m_chkUseAIMode;
	UEasyButtonEx	m_chkUseNewParameter3;
	
	UEasyButtonEx	m_chkUseAllToolScal;
	UEasyButtonEx	m_chkUseAllToolPower;

	UEasyButtonEx	m_chkUseNewBarcodeContents;
	UEasyButtonEx	m_chkUseOriginalInspectionMode;
	UEasyButtonEx	m_chkUse1stPanelStop;
	UEasyButtonEx	m_chkNoUseMelsecInterface;
	UEasyButtonEx	m_chkPassMode;
	//}}AFX_DATA

// Attributes
public:
	int m_nUserLevel;
// Attributes
protected :
	CFont			m_fntBtn;

	SPROCESSSYSTEM	m_sProcessSystem;

// Operations
public:
	CString GetChangeValueStr();
	void InitBtnControl();

	void SetProcessSystem(SPROCESSSYSTEM sProcessSystem);
	void GetProcessSystem(SPROCESSSYSTEM* pProcessSystem);
	void DispProcessSystem();
	void OnApply();

	void EnableControl(BOOL bUse);
	void SetAuthorityByLevel(int nLevel);
	BOOL GetUseSchedule();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneProcessSetupSysSetting)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneProcessSetupSysSetting();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneProcessSetupSysSetting)
	afx_msg void OnDestroy();
	afx_msg void OnCheckDryRunWithoutLaser();
	afx_msg void OnCheckNoUseLoaderUnloader();
	afx_msg void OnCheckLoaderUnloaderDoorLock();
	afx_msg void OnCheckNoUseSuction();
	afx_msg void OnCheckNoUseFiducialFind();
	afx_msg void OnCheckNoUseDustSuction();
	afx_msg void OnCheckNoUseAOMAlarm();
	afx_msg void OnCheckNoUseRollUpDown();
	afx_msg void OnCheckNoUsePaper();
	afx_msg void OnCheckNoUsePrework();
	afx_msg void OnCheckPreworkData();
	afx_msg void OnCheckUseGetHighCamOffset();
	afx_msg void OnCheckUseEveryPanelThickness();
	afx_msg void OnCheckUseEveryPanelHeadOffset();
	afx_msg void OnCheckNoUseNGBox();
	afx_msg void OnCheckUseScheduling();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedCheckUseBarcodeMode();
	afx_msg void OnBnClickedCheckUseNewParameter();
	afx_msg void OnBnClickedCheckUseNewBarcodeContents();
	afx_msg void OnBnClickedCheckUseOriginalInspectionMode();
	afx_msg void OnBnClickedCheckUse1stPanelStop();
	afx_msg void OnBnClickedCheckNoUseMelsec();
	afx_msg void OnBnClickedCheckPassMode();
	afx_msg void OnBnClickedCheckUseAllToolScal();
	afx_msg void OnBnClickedCheckUseAllToolPower();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEPROCESSSETUPSYSSETTING_H__6CEC5DD7_5229_4E38_8F1B_07E329341718__INCLUDED_)

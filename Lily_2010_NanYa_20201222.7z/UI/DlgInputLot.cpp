// DlgInputLot.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgInputLot.h"
#include "..\EasyDrillerDlg.h"
#include "..\Model\DSystemINI.h"
#include "..\model\DProcessINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInputLot dialog


CDlgInputLot::CDlgInputLot(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgInputLot::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgInputLot)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nInputLot		= 0;
	m_nStartNo		= 0;
}


void CDlgInputLot::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInputLot)
	DDX_Control(pDX, IDOK, m_btnOk);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_EDIT_INPUT_LOT, m_edtInputLot);
	DDX_Control(pDX, IDC_EDIT_INPUT_START_NO, m_edtStartNo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInputLot, CDialog)
	//{{AFX_MSG_MAP(CDlgInputLot)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInputLot message handlers

BOOL CDlgInputLot::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitControl();

	if(gProcessINI.m_sProcessOption.bFullScheduling)
	{
		GetDlgItem(IDC_EDIT_INPUT_LOT)->EnableWindow(FALSE);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgInputLot::InitControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// Cancel
	m_btnCancel.SetFont( &m_fntBtn );
	m_btnCancel.SetFlat( FALSE );
	m_btnCancel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCancel.EnableBallonToolTip();
	m_btnCancel.SetToolTipText( _T("Cancel") );
	m_btnCancel.SetBtnCursor(IDC_HAND_1);

	// Ok
	m_btnOk.SetFont( &m_fntBtn );
	m_btnOk.SetFlat( FALSE );
	m_btnOk.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOk.EnableBallonToolTip();
	m_btnOk.SetToolTipText( _T("Ok") );
	m_btnOk.SetBtnCursor(IDC_HAND_1);

	GetDlgItem(IDC_STATIC_MSG)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AMOUNT_LOT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_START_NUM)->SetFont( &m_fntStatic );

	m_edtInputLot.SetFont( &m_fntEdit );
	m_edtInputLot.SetReceivedFlag( 1 );

	m_edtStartNo.SetFont( &m_fntEdit );
	m_edtStartNo.SetReceivedFlag( 1 );
	CString strData;
	strData.Format(_T("%d"), m_nInputLot);
	m_edtInputLot.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%d"), m_nStartNo);
	m_edtStartNo.SetWindowText( (LPCTSTR)strData );
}

void CDlgInputLot::OnOK() 
{
	CString strData;

	m_edtInputLot.GetWindowText( strData );

	int nLot = atoi( (LPSTR)(LPCTSTR)strData );

	if( nLot <= 0 )
	{
		ErrMessage(IDS_LOT_VALUE_ERR, MB_ICONERROR);
		m_edtInputLot.SetFocus();
		m_edtInputLot.SetSel( 0, -1 );
		return;
	}

	m_nInputLot = nLot;

	m_edtStartNo.GetWindowText( strData );

	int nStartNo = atoi((LPSTR)(LPCTSTR)strData );

	if(gProcessINI.m_sProcessOption.bFullScheduling)
	{
		if(nStartNo < 0 || nLot < nStartNo)
		{
			ErrMessage(IDS_START_LOTID_ERR, MB_ICONERROR);
			m_edtStartNo.SetFocus();
			m_edtStartNo.SetSel( 0, -1 );
			return;
		}
	}
	else
	{

		if(nStartNo <= 0 || nLot < nStartNo)
		{
			ErrMessage(IDS_START_LOTID_ERR, MB_ICONERROR);
			m_edtStartNo.SetFocus();
			m_edtStartNo.SetSel( 0, -1 );
			return;
		}
	}
	m_nStartNo = nStartNo;

	CDialog::OnOK();
}

BOOL CDlgInputLot::DestroyWindow() 
{
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();
	
	return CDialog::DestroyWindow();
}


BOOL CDlgInputLot::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
		if(pMsg->message == WM_LBUTTONDOWN)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CDialog::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CDialog::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Lot_Input) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}

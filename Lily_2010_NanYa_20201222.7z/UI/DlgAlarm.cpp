// DlgAlarm.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgAlarm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgAlarm dialog
const UINT TIMER_ERR_TIME = 100;

CDlgAlarm::CDlgAlarm(CWnd* pParent /*= NULL*/)
	: CDialog(CDlgAlarm::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgAlarm)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_strErrCode			= _T("");
	m_strErrReason			= _T("");
	m_strErrSolution		= _T("");
	m_nTimer = 0;
	m_nErrCount = 0;
}

void CDlgAlarm::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgAlarm)
//	DDX_Control(pDX, IDC_EDIT_ERROR_SOLUTION, m_edtErrSol);
//	DDX_Control(pDX, IDC_EDIT_ERROR_REASON, m_edtErrReason);
	DDX_Control(pDX, IDC_EDIT_ERROR_CODE, m_edtErrCode);
	DDX_Control(pDX, IDOK, m_btnClose);
	DDX_Text(pDX, IDC_EDIT_ERROR_REASON, m_strErrReason);
	DDX_Text(pDX, IDC_EDIT_ERROR_SOLUTION, m_strErrSolution);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgAlarm, CDialog)
	//{{AFX_MSG_MAP(CDlgAlarm)
	ON_WM_MOUSEWHEEL()
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
	ON_WM_TIMER()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgAlarm message handlers

void CDlgAlarm::OnCancel() 
{
//	CDialog::OnCancel();
}

BOOL CDlgAlarm::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitBtnControl();
	InitEditControl();
	InitStaticControl();

	::SetWindowPos(this->m_hWnd, HWND_TOPMOST, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOREDRAW);

	ResizeWindow();
	if(!m_nTimer)
		m_nTimer = SetTimer(TIMER_ERR_TIME, 1000, NULL);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgAlarm::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnClose.SetFont( &m_fntBtn );
	m_btnClose.SetFlat( FALSE );
	m_btnClose.SetImageOrg( 8, 3 );
	m_btnClose.SetIcon( IDI_OK );
	m_btnClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnClose.EnableBallonToolTip();
	m_btnClose.SetToolTipText( _T("CLOSE") );
	m_btnClose.SetBtnCursor(IDC_HAND_1);
}

void CDlgAlarm::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(130, "Arial Bold");

	// Error Code
	m_edtErrCode.SetFont( &m_fntEdit );
	m_edtErrCode.SetForeColor( RGB(0, 0, 255 ) ); //255, 0, 0 ) );
	m_edtErrCode.SetBackColor( RGB(192, 192, 192 ) ); //WHITE_COLOR );
	m_edtErrCode.SetReceivedFlag( -1 ); // Read-Only
	m_edtErrCode.SetWindowText( (LPCTSTR)m_strErrCode );

	// Error Reason
//	m_edtErrReason.SetFont( &m_fntEdit );
//	m_edtErrReason.SetForeColor( RGB(255, 0, 0 ) );
//	m_edtErrReason.SetBackColor( WHITE_COLOR );
//	m_edtErrReason.SetReceivedFlag( -1 ); // Read-Only
//	m_edtErrReason.SetWindowText( (LPCTSTR)m_strErrReason );

	// Error Solution
//	m_edtErrSol.SetFont( &m_fntEdit );
//	m_edtErrSol.SetForeColor( RGB(255, 0, 0 ) );
//	m_edtErrSol.SetBackColor( WHITE_COLOR );
//	m_edtErrSol.SetReceivedFlag( -1 ); // Read-Only
//	m_edtErrSol.SetWindowText( (LPCTSTR)m_strErrSolution );

	m_edtFont.CreateFont(20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDC_EDIT_ERROR_REASON)->SetFont(&m_edtFont);
	GetDlgItem(IDC_EDIT_ERROR_SOLUTION)->SetFont(&m_edtFont);
}

void CDlgAlarm::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	GetDlgItem(IDC_STATIC_ERR_CODE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ERR_REASON)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ERR_SOL)->SetFont( &m_fntStatic );
}

void CDlgAlarm::SetErrMsg(CString strErrCode, CString strErrReason, CString strErrSolution, CString strPlus)
{
	m_strErrCode.Format(strErrCode, strPlus);
	m_strErrReason.Format(strErrReason, strPlus);
	m_strErrSolution.Format(strErrSolution, strPlus);

//	m_strErrCode.Format(_T("%s"), strErrCode);
//	m_strErrReason.Format(_T("%s"), strErrReason);
//	m_strErrSolution.Format(_T("%s"), strErrSolution);
}

void CDlgAlarm::SetErrMsg(TCHAR* pErrCode, TCHAR* pErrReason, TCHAR* pErrSolution, CString strPlus)
{
	CString strErrCode, strErrReason, strErrSolution;
	strErrCode.Format(_T("%s"), pErrCode);
	strErrReason.Format(_T("%s"), pErrReason);
	strErrSolution.Format(_T("%s"), pErrSolution);

	m_strErrCode.Format(strErrCode, strPlus);
	m_strErrReason.Format(strErrReason, strPlus);
	m_strErrSolution.Format(strErrSolution, strPlus);
//	m_strErrCode.Format(_T("%s"), pErrCode);
//	m_strErrReason.Format(_T("%s"), pErrReason);
//	m_strErrSolution.Format(_T("%s"), pErrSolution);
}

void CDlgAlarm::ResizeWindow()
{
	CRect rt1, rt2;

	// Solution
	if( m_strErrSolution.IsEmpty() )
	{
		GetDlgItem(IDC_STATIC_ERR_SOL)->GetWindowRect( rt1 );
		GetDlgItem(IDOK)->GetWindowRect( rt2 );

		CSize sOffset;
		sOffset.cx = 0;
		sOffset.cy = rt1.top - rt2.top;

		GetDlgItem(IDC_STATIC_ERR_SOL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_ERROR_SOLUTION)->ShowWindow(SW_HIDE);

		OffsetItem(IDOK, sOffset.cx, sOffset.cy);

		this->GetWindowRect( &rt1 );
		rt1.bottom += sOffset.cy;
		this->MoveWindow( &rt1 );
	}
/*
	// Reason
	if( m_strErrReason.IsEmpty() )
	{
		GetDlgItem(IDC_STATIC_ERR_REASON)->GetWindowRect( rt1 );
		GetDlgItem(IDOK)->GetWindowRect( rt2 );

		CSize sOffset;
		sOffset.cx = 0;
		sOffset.cy = rt1.top - rt2.top;

		GetDlgItem(IDC_STATIC_ERR_REASON)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_ERROR_REASON)->ShowWindow(SW_HIDE);

		OffsetItem(IDOK, sOffset.cx, sOffset.cy);

		this->GetWindowRect( &rt1 );
		rt1.bottom += sOffset.cy;
		this->MoveWindow( &rt1 );
	}
*/
}

void CDlgAlarm::OffsetItem(UINT nID, int x, int y)
{
	CWnd* pWnd = GetDlgItem(nID);

	if( NULL != pWnd /*&& ::IsWindowVisible( pWnd->GetSafeHwnd() )*/ )
	{
		CRect rt;

		pWnd->GetWindowRect( &rt );
		ScreenToClient( &rt );
		rt.OffsetRect(x, y);
		pWnd->MoveWindow( &rt );
	}
}

BOOL CDlgAlarm::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{

	
	return CDialog::OnMouseWheel(nFlags, zDelta, pt);
}

HBRUSH CDlgAlarm::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	/*if( CTLCOLOR_STATIC == nCtlColor )
	{
		pDC->SetTextColor( RGB(0, 0, 255) );
	}*/
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

BOOL CDlgAlarm::DestroyWindow()
{
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();

	if(m_nTimer)
	{
		::AfxGetMainWnd()->SendMessage(UM_SET_JOB_TIME, m_nErrCount,ERROR_JOB);
		m_nErrCount = 0;
		KillTimer(m_nTimer);
		m_nTimer = 0;
	}

	return CDialog::DestroyWindow();
}

void CDlgAlarm::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if(nIDEvent == m_nTimer)
	{
		m_nErrCount++;
		if(m_nErrCount >= 600)
		{
			::AfxGetMainWnd()->SendMessage(UM_SET_JOB_TIME, m_nErrCount,ERROR_JOB);
			m_nErrCount = 0;
		}
	}

	CDialog::OnTimer(nIDEvent);
}

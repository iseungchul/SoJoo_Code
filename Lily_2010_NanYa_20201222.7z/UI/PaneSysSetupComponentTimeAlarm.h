#if !defined(AFX_PANESYSSETUPCOMPONENTTIMEALARM_H__57963519_9F40_4EBC_8F39_4BB3865D3F1A__INCLUDED_)
#define AFX_PANESYSSETUPCOMPONENTTIMEALARM_H__57963519_9F40_4EBC_8F39_4BB3865D3F1A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupComponentTimeAlarm.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupComponentTimeAlarm dialog

#include "ColorEdit.h"


class CPaneSysSetupComponentTimeAlarm : public CDialog
{

public:
	CColorEdit		m_edtExpireTime;

// Construction
public:
	void SetPreAcqtime(int PreAcqTime);
	void AddItem(CString strC, CString strStrartDate, CString strE, CString strUsingDate, CString strAlarmDate );
	CPaneSysSetupComponentTimeAlarm(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPaneSysSetupComponentTimeAlarm)
	enum { IDD = IDD_DLG_SYS_SETUP_COMPONENT_TIME_ALARM };
	CListCtrl	m_lShow;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupComponentTimeAlarm)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupComponentTimeAlarm)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPCOMPONENTTIMEALARM_H__57963519_9F40_4EBC_8F39_4BB3865D3F1A__INCLUDED_)

// PaneManualControlIOMonitorInputSub3Osan.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlIOMonitorInputSub3Osan.h"
#include "..\device\HDeviceFactory.h"
#include "..\Model\DSystemINI.h"
#include "..\Model\DEasyDrillerINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub3Osan

IMPLEMENT_DYNCREATE(CPaneManualControlIOMonitorInputSub3Osan, CFormView)

CPaneManualControlIOMonitorInputSub3Osan::CPaneManualControlIOMonitorInputSub3Osan()
	: CFormView(CPaneManualControlIOMonitorInputSub3Osan::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlIOMonitorInputSub3Osan)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nTimerID = 0;
	m_lStatusHandlerLoader = m_lStatusHandlerLoaderOld = 0;
}

CPaneManualControlIOMonitorInputSub3Osan::~CPaneManualControlIOMonitorInputSub3Osan()
{
}

void CPaneManualControlIOMonitorInputSub3Osan::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlIOMonitorInputSub3Osan)
	DDX_Control(pDX, IDC_CHECK_LC_READY, m_ledLCReady);
	DDX_Control(pDX, IDC_CHECK_LC_BUSY, m_ledLCBusy);
	DDX_Control(pDX, IDC_CHECK_LC_STOP, m_ledLCStop);
	DDX_Control(pDX, IDC_CHECK_LC_INIT_END, m_ledLCInitEnd);

	DDX_Control(pDX, IDC_CHECK_LD_PAPER_TRANS_FWD, m_ledLdPaperTransFwd);
	DDX_Control(pDX, IDC_CHECK_LD_PAPER_TRANS_BWD, m_ledLdPaperTransBwd);
	DDX_Control(pDX, IDC_CHECK_LD_PCB_TRANS_FWD, m_ledLdPCBTransFwd);
	DDX_Control(pDX, IDC_CHECK_LD_PCB_TRANS_BWD, m_ledLdPCBTransBwd);
	DDX_Control(pDX, IDC_CHECK_LD_ALIGN_SHEET_FWD, m_ledLdAlignSheetFwd);
	DDX_Control(pDX, IDC_CHECK_LD_ALIGN_SHEET_BWD, m_ledLdAlignSheetBwd);
	DDX_Control(pDX, IDC_CHECK_LD_ALIGN_GUIDE_FWD, m_ledLdAlignGuideFwd);
	DDX_Control(pDX, IDC_CHECK_LD_ALIGN_GUIDE_BWD, m_ledLdAlignGuideBwd);
	DDX_Control(pDX, IDC_CHECK_LD_CART_CLAMP_UP, m_ledLdCartClampUp);
	DDX_Control(pDX, IDC_CHECK_LD_CART_CLAMP_DOWN, m_ledLdCartClampDown);

	DDX_Control(pDX, IDC_CHECK_LP1_READY, m_ledLP1Ready);
	DDX_Control(pDX, IDC_CHECK_LP1_BUSY, m_ledLP1Busy);
	DDX_Control(pDX, IDC_CHECK_LP1_STOP, m_ledLP1Stop);
	DDX_Control(pDX, IDC_CHECK_LP1_INIT_END, m_ledLP1InitEnd);
	DDX_Control(pDX, IDC_CHECK_LP1_VACUUM_ON, m_ledLP1VacuumOn);
	DDX_Control(pDX, IDC_CHECK_LP1_VACUUM_OFF, m_ledLP1VacuumOff);

	DDX_Control(pDX, IDC_CHECK_LP2_READY, m_ledLP2Ready);
	DDX_Control(pDX, IDC_CHECK_LP2_BUSY, m_ledLP2Busy);
	DDX_Control(pDX, IDC_CHECK_LP2_STOP, m_ledLP2Stop);
	DDX_Control(pDX, IDC_CHECK_LP2_INIT_END, m_ledLP2InitEnd);
	DDX_Control(pDX, IDC_CHECK_LP2_VACUUM_ON, m_ledLP2VacuumOn);
	DDX_Control(pDX, IDC_CHECK_LP2_VACUUM_OFF, m_ledLP2VacuumOff);

	DDX_Control(pDX, IDC_CHECK_LP3_READY, m_ledLP3Ready);
	DDX_Control(pDX, IDC_CHECK_LP3_BUSY, m_ledLP3Busy);
	DDX_Control(pDX, IDC_CHECK_LP3_STOP, m_ledLP3Stop);
	DDX_Control(pDX, IDC_CHECK_LP3_INIT_END, m_ledLP3InitEnd);
	DDX_Control(pDX, IDC_CHECK_LP3_VACUUM_ON, m_ledLP3VacuumOn);
	DDX_Control(pDX, IDC_CHECK_LP3_VACUUM_OFF, m_ledLP3VacuumOff);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPaneManualControlIOMonitorInputSub3Osan, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlIOMonitorInputSub3Osan)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub3Osan diagnostics

#ifdef _DEBUG
void CPaneManualControlIOMonitorInputSub3Osan::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlIOMonitorInputSub3Osan::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub3Osan message handlers
void CPaneManualControlIOMonitorInputSub3Osan::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
}

void CPaneManualControlIOMonitorInputSub3Osan::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(100, "Arial Bold");
	
	m_ledLCReady.SetFont( &m_fntBtn );
	m_ledLCReady.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLCReady.Depress( TRUE );
	m_ledLCBusy.SetFont( &m_fntBtn );
	m_ledLCBusy.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLCBusy.Depress( TRUE );
	m_ledLCStop.SetFont( &m_fntBtn );
	m_ledLCStop.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLCStop.Depress( TRUE );
	m_ledLCInitEnd.SetFont( &m_fntBtn );
	m_ledLCInitEnd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLCInitEnd.Depress( TRUE );

	m_ledLdPaperTransFwd.SetFont( &m_fntBtn );
	m_ledLdPaperTransFwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLdPaperTransFwd.Depress( TRUE );
	m_ledLdPaperTransBwd.SetFont( &m_fntBtn );
	m_ledLdPaperTransBwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLdPaperTransBwd.Depress( TRUE );

	m_ledLdPCBTransFwd.SetFont( &m_fntBtn );
	m_ledLdPCBTransFwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLdPCBTransFwd.Depress( TRUE );
	m_ledLdPCBTransBwd.SetFont( &m_fntBtn );
	m_ledLdPCBTransBwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLdPCBTransBwd.Depress( TRUE );

	m_ledLdAlignSheetFwd.SetFont( &m_fntBtn );
	m_ledLdAlignSheetFwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLdAlignSheetFwd.Depress( TRUE );
	m_ledLdAlignSheetBwd.SetFont( &m_fntBtn );
	m_ledLdAlignSheetBwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLdAlignSheetBwd.Depress( TRUE );

	m_ledLdAlignGuideFwd.SetFont( &m_fntBtn );
	m_ledLdAlignGuideFwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLdAlignGuideFwd.Depress( TRUE );
	m_ledLdAlignGuideBwd.SetFont( &m_fntBtn );
	m_ledLdAlignGuideBwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLdAlignGuideBwd.Depress( TRUE );

	m_ledLdCartClampUp.SetFont( &m_fntBtn );
	m_ledLdCartClampUp.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLdCartClampUp.Depress( TRUE );
	m_ledLdCartClampDown.SetFont( &m_fntBtn );
	m_ledLdCartClampDown.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLdCartClampDown.Depress( TRUE );

	m_ledLP1Ready.SetFont( &m_fntBtn );
	m_ledLP1Ready.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP1Ready.Depress( TRUE );
	m_ledLP1Busy.SetFont( &m_fntBtn );
	m_ledLP1Busy.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP1Busy.Depress( TRUE );
	m_ledLP1Stop.SetFont( &m_fntBtn );
	m_ledLP1Stop.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP1Stop.Depress( TRUE );
	m_ledLP1InitEnd.SetFont( &m_fntBtn );
	m_ledLP1InitEnd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP1InitEnd.Depress( TRUE );
	m_ledLP1VacuumOn.SetFont( &m_fntBtn );
	m_ledLP1VacuumOn.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP1VacuumOn.Depress( TRUE );
	m_ledLP1VacuumOff.SetFont( &m_fntBtn );
	m_ledLP1VacuumOff.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP1VacuumOff.Depress( TRUE );

	m_ledLP2Ready.SetFont( &m_fntBtn );
	m_ledLP2Ready.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP2Ready.Depress( TRUE );
	m_ledLP2Busy.SetFont( &m_fntBtn );
	m_ledLP2Busy.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP2Busy.Depress( TRUE );
	m_ledLP2Stop.SetFont( &m_fntBtn );
	m_ledLP2Stop.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP2Stop.Depress( TRUE );
	m_ledLP2InitEnd.SetFont( &m_fntBtn );
	m_ledLP2InitEnd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP2InitEnd.Depress( TRUE );
	m_ledLP2VacuumOn.SetFont( &m_fntBtn );
	m_ledLP2VacuumOn.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP2VacuumOn.Depress( TRUE );
	m_ledLP2VacuumOff.SetFont( &m_fntBtn );
	m_ledLP2VacuumOff.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP2VacuumOff.Depress( TRUE );

	m_ledLP3Ready.SetFont( &m_fntBtn );
	m_ledLP3Ready.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP3Ready.Depress( TRUE );
	m_ledLP3Busy.SetFont( &m_fntBtn );
	m_ledLP3Busy.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP3Busy.Depress( TRUE );
	m_ledLP3Stop.SetFont( &m_fntBtn );
	m_ledLP3Stop.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP3Stop.Depress( TRUE );
	m_ledLP3InitEnd.SetFont( &m_fntBtn );
	m_ledLP3InitEnd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP3InitEnd.Depress( TRUE );
	m_ledLP3VacuumOn.SetFont( &m_fntBtn );
	m_ledLP3VacuumOn.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP3VacuumOn.Depress( TRUE );
	m_ledLP3VacuumOff.SetFont( &m_fntBtn );
	m_ledLP3VacuumOff.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP3VacuumOff.Depress( TRUE );
}

void CPaneManualControlIOMonitorInputSub3Osan::UpdateStatus()
{

}

void CPaneManualControlIOMonitorInputSub3Osan::OnTimer(UINT nIDEvent) 
{
	UpdateStatus();
	
	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlIOMonitorInputSub3Osan::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_nTimerID = SetTimer(9973, 1000, NULL);
		m_pMotor = gDeviceFactory.GetMotor();
	}
}

void CPaneManualControlIOMonitorInputSub3Osan::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

BOOL CPaneManualControlIOMonitorInputSub3Osan::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}
#if !defined(AFX_PANELOGMANAGERLOT_H__B197E331_4A57_4435_BC42_4F730E0BE9F8__INCLUDED_)
#define AFX_PANELOGMANAGERLOT_H__B197E331_4A57_4435_BC42_4F730E0BE9F8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneLogManagerLot.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerLot form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButtonEx.h"
#include "ColorEdit.h"
#include "ColorStatic.h"

struct stWorkStat
{
	CString		strDay;
	int			nPCB;
	__int64		n64Shot;
	int			nRemainPCB;
	__int64		n64RemainShot;

	__int64		n64Hole;
	__int64		n64RemainHole;
	CTimeSpan	ctsWorkHour;
	CTimeSpan	ctsAddToNext;
};

class CPaneLogManagerLot : public CFormView
{
protected:
	CPaneLogManagerLot();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneLogManagerLot)

// Form Data
public:
	//{{AFX_DATA(CPaneLogManagerLot)
	enum { IDD = IDD_DLG_LOG_MANAGER_LOT };
	UEasyButtonEx	m_btnSave;
	UEasyButtonEx	m_btnStatMonthly;
	CColorStatic	m_stcTotalShotCount;
	CColorStatic	m_stcTotalPCBCount;
	CListCtrl	m_listLot;
	CColorEdit	m_edtSearch;
	CColorEdit	m_edtHourStart;
	CDateTimeCtrl	m_dtcStart;
	CDateTimeCtrl	m_dtcEnd;
	CComboBox	m_cmbLotCategory;
	UEasyButtonEx	m_btnView;
	UEasyButtonEx	m_btnStop;
	UEasyButtonEx	m_btnStatDaily;
	UEasyButtonEx	m_btnStatAnnual;
	UEasyButtonEx	m_btnSearch;
	CTime	m_ctEnd;
	CTime	m_ctStart;
	CString	m_strSearch;
	int		m_nSearchType;
	//}}AFX_DATA

// Attributes
public:

// Attributes
protected :
	CFont		m_fntStatic;
	CFont		m_fntBtn;
	CFont		m_fntList;
	CFont		m_fntEdit;
	CFont		m_fntEtc;

	int			m_nTotalPCB;
	__int64		m_n64TotalShot;
	__int64		m_n64TotalHole;

	BOOL		m_bIsView;
	int			m_nListViewType;
	HANDLE		m_pHandle[3];
	CWinThread*	m_pThread;

	CString	m_strNewLine;
	CString	m_strMicroSec;
	CString	m_strMicroMeter;
	CString	m_strHertz;
	CString	m_strPercent;
	CString	m_strComma;

	TCHAR		m_lpszColumnHead[21][40];
	TCHAR		m_lpszShortDay[7][40];
	TCHAR		m_lpszShortMonth[7][40];
	TCHAR		m_lpszShortYear[6][40];

	CStringArray	m_strLotDetailArray;

// Operations
public:
	void		InitBtnControl();
	void		InitStaticControl();
	void		InitListControl();
	void		InitEditControl();
	void		InitEtcControl();

	void		ResetColumn();
	void		ShowDetailColumn();
	void		ShowShortColumn();

	CString		GetLogFile(CTime& cTime);
	void		LoadFromCurrentDate();
	void		UpdateTotalStatistic();
	void		MakeReadableNumber(CString& strVal);
	void		LoadFromFile(CString strFile, CString strSearch = CString(_T("")));
	void		RemoveEqualsFromName(CString& strVal);
	void		RemoveDirectoryFromName(CString& strVal);
	void		UpdateSaveButton();
	void		ShowDetailInformation();
	void		MakeThreadClear();
	void		EnableNormalButton(BOOL bEnable);
	static UINT ViewListThread(LPVOID lpVoid);
	static UINT ViewDayStatThread(LPVOID lpVoid);
	static UINT ViewMonthStatThread(LPVOID lpVoid);
	static UINT ViewYearStatThread(LPVOID lpVoid);
	int			GetDays(int nYear, int nMonth);
	int			GetDays(int nYear);
	void		WriteLogFile(CString& strSaveFileName);
	BOOL		CalDayStatFromFile(CString strFile, CString strNextFile, stWorkStat& stwStat);
	CString		MakeFixedWidthIntString(int nVal, int nWidth);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneLogManagerLot)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneLogManagerLot();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneLogManagerLot)
	afx_msg void OnClickListLot(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonView();
	afx_msg void OnButtonSave();
	afx_msg void OnButtonSearch();
	afx_msg void OnButtonStop();
	afx_msg void OnButtonStatDaily();
	afx_msg void OnButtonStatMonthly();
	afx_msg void OnButtonStatAnnual();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANELOGMANAGERLOT_H__B197E331_4A57_4435_BC42_4F730E0BE9F8__INCLUDED_)

﻿// PaneManualControl.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControl.h"


#ifdef __PUSAN2__ 

	#include "PaneManualControlIOMonitorOutputSub1Pusan1.h"
#else

	#include "PaneManualControlIOMonitorOutputSub1Large.h"
#endif
	#include "PaneManualControlMotorLarge.h"
#include "PaneManualControlDevice.h"
#include "PaneManualControlLaser.h"
#include "PaneManualControlLaserUV.h"
#include "PaneManualControlScannerCalibration.h"
//#include "PaneManualControlScannerCalibrationPos.h"
#include "PaneManualControlVision.h"

	#include "PaneManualControlOneHoleLarge.h"

#include "PaneManualControlPowerMeasurement.h"
#include "PaneManualControlIO.h"
#include "PaneManualControlParameter.h"
#include "PaneRecipeGenParameterNew.h"
#include "..\EasyDrillerDlg.h"
#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "DlgMatroxVisionView.h"
#include "..\model\dprocessini.h"
#include "..\model\DSystemINI.h"
#include "..\model\DEasyDrillerINI.h"
#include "PaneManualDrillSub.h"
#include "..\alarmmsg.h"
#include "..\device\HDeviceFactory.h"
#include "..\device\HVision.h"
#include "PaneManualControlIOMonitorOutput.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControl

IMPLEMENT_DYNCREATE(CPaneManualControl, CFormView)

CPaneManualControl::CPaneManualControl()
	: CFormView(CPaneManualControl::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControl)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pMotor			= NULL;
	m_pDevice			= NULL;
	m_pLaser			= NULL;
	m_pLaserUV			= NULL;
	m_pScannerCalibration = NULL;
//	m_pScannerCalibrationPos = NULL;
	m_pVision			= NULL;
	m_pOneHole			= NULL;
	m_pPowerMeasurement	= NULL;
	m_pIO				= NULL;
	m_nPaneNo			= 0;
	m_pParameter		= NULL;
}

CPaneManualControl::~CPaneManualControl()
{
}

void CPaneManualControl::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControl)
	DDX_Control(pDX, IDC_TAB_MANUAL_CONTROL, m_tabManualControl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControl, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControl)
	ON_NOTIFY(NM_CLICK, IDC_TAB_MANUAL_CONTROL, OnClickTabManualControl)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControl diagnostics

#ifdef _DEBUG
void CPaneManualControl::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControl::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControl message handlers

void CPaneManualControl::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	InitTabControl();
}

void CPaneManualControl::InitTabControl()
{
	// Set Button Font
	m_fntTab.CreatePointFont(150, "Arial Bold");
	CString strCh;
	BOOL bRet = 0;

	m_tabManualControl.SetFont( &m_fntTab );

	int nPanel = 0;
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
		gSystemINI.m_sHardWare.nLaserType == LASER_HYBRID)
	{
		// Laser
		if(gSystemINI.m_sHardWare.nLanguageType == 1)
			strCh = CW2A(L" 镭射 ");
		else
			strCh = " Laser ";

		bRet = m_tabManualControl.AddPane( strCh, RUNTIME_CLASS(CPaneManualControlLaser) );
		if( FALSE != bRet )
		{
			m_pLaser = static_cast<CPaneManualControlLaser*>(m_tabManualControl.GetPane(nPanel++));
			m_pLaser->OnInitialUpdate();
		}
	}
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV ||
		gSystemINI.m_sHardWare.nLaserType == LASER_HYBRID ||
		gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
			bRet = m_tabManualControl.AddPane( _T(" GV Laser "), RUNTIME_CLASS(CPaneManualControlLaserUV) );
		else
			// UV Laser
			bRet = m_tabManualControl.AddPane( _T(" UV Laser "), RUNTIME_CLASS(CPaneManualControlLaserUV) );
		if( FALSE != bRet )
		{
			m_pLaserUV = static_cast<CPaneManualControlLaserUV*>(m_tabManualControl.GetPane(nPanel++));
			m_pLaserUV->OnInitialUpdate();
		}
	}
	// Motor
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = CW2A(L" 马达 ");
	else
		strCh = " Motor ";

	bRet = m_tabManualControl.AddPane( strCh, RUNTIME_CLASS(CPaneManualControlMotorLarge) );
	if( FALSE != bRet )
	{
		m_pMotor = static_cast<CPaneManualControlMotorLarge*>(m_tabManualControl.GetPane(nPanel++));
		m_pMotor->OnInitialUpdate();
	}

	// Device
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = CW2A(L" 测高器 ");
	else
		strCh = " Height S ";

	bRet = m_tabManualControl.AddPane( strCh, RUNTIME_CLASS(CPaneManualControlDevice) );
	if( FALSE != bRet )
	{
		m_pDevice = static_cast<CPaneManualControlDevice*>(m_tabManualControl.GetPane(nPanel++));
		m_pDevice->OnInitialUpdate();
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 1)
	{
		// Power Measurement
		if(gSystemINI.m_sHardWare.nLanguageType == 1)
			strCh = CW2A(L" 能量  ");
		else
			strCh = " Power ";

		bRet = m_tabManualControl.AddPane( strCh, RUNTIME_CLASS(CPaneManualControlPowerMeasurement) );
		if( FALSE != bRet )
		{
			m_pPowerMeasurement = static_cast<CPaneManualControlPowerMeasurement*>(m_tabManualControl.GetPane(nPanel++));
			m_pPowerMeasurement->OnInitialUpdate();
			m_pPowerMeasurement->SetProcessPowerMeasure( gProcessINI.m_sProcessPowerMeasure, gProcessINI.m_sProcessAutoSetting.dPowermeterPos );
			m_pPowerMeasurement->SetComPortData( &gSystemINI.m_sSystemDevice.sPowermeterPort );
		}
	}

	// Scanner Calibration
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = CW2A(L" 振镜精度  ");
	else
		strCh = " ScannerCal ";

	bRet = m_tabManualControl.AddPane( strCh, RUNTIME_CLASS(CPaneManualControlScannerCalibration) );
	if( FALSE != bRet )
	{
		m_pScannerCalibration = static_cast<CPaneManualControlScannerCalibration*>(m_tabManualControl.GetPane(nPanel++));
		m_pScannerCalibration->OnInitialUpdate();
		m_pScannerCalibration->SetProcessScannerCal( gProcessINI.m_sProcessScannerCal );
	}

	// Vision
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = CW2A(L" 摄像机  ");
	else
		strCh = " Vision ";
	bRet = m_tabManualControl.AddPane( strCh, RUNTIME_CLASS(CPaneManualControlVision) );
	if( FALSE != bRet )
	{
		m_pVision = static_cast<CPaneManualControlVision*>(m_tabManualControl.GetPane(nPanel++));
		m_pVision->OnInitialUpdate();
	}

	// One Hole Process
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = CW2A(L" 孔加工  ");
	else
		strCh = " OneHole ";
	bRet = m_tabManualControl.AddPane( strCh, RUNTIME_CLASS(CPaneManualControlOneHoleLarge) );
	if( FALSE != bRet )
	{
		m_pOneHole = static_cast<CPaneManualControlOneHoleLarge*>(m_tabManualControl.GetPane(nPanel++));
		m_pOneHole->OnInitialUpdate();
	}

	// Parameter
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = CW2A(L" 参数  ");
	else
		strCh = " Parameter ";
	bRet = m_tabManualControl.AddPane( strCh, RUNTIME_CLASS(CPaneRecipeGenParameterNew) );
	if( FALSE != bRet )
	{
		m_pParameter = static_cast<CPaneRecipeGenParameterNew*>(m_tabManualControl.GetPane(nPanel++));
		m_pParameter->OnInitialUpdate();
	}
	
	// IO
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = CW2A(L" 进/出  ");
	else
		strCh = " I/O ";
	bRet = m_tabManualControl.AddPane( strCh, RUNTIME_CLASS(CPaneManualControlIO) );
	if( FALSE != bRet )
	{
		m_pIO = static_cast<CPaneManualControlIO*>(m_tabManualControl.GetPane(nPanel++));
		m_pIO->OnInitialUpdate();
	}

	// Scanner Calibration by pos
//	bRet = m_tabManualControl.AddPane( _T(" ScannerCal'2 "), RUNTIME_CLASS(CPaneManualControlScannerCalibrationPos) );
//	if( FALSE != bRet )
//	{
//		m_pScannerCalibrationPos = static_cast<CPaneManualControlScannerCalibrationPos*>(m_tabManualControl.GetPane(7));
//		m_pScannerCalibrationPos->OnInitialUpdate();
//		m_pScannerCalibrationPos->SetProcessScannerCal( gProcessINI.m_sProcessScannerCal );
//	}






	m_tabManualControl.ShowPane( 0 );
}

void CPaneManualControl::ShowTabPane(int nPaneNo, BOOL bSetFid)
{
	BOOL bSideVision = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetSideStatus();
	if( nPaneNo >= 0 && nPaneNo < 11 )
	{
		m_tabManualControl.ShowPane( nPaneNo );
		
		m_nPaneNo = nPaneNo;
		
		if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 1)
		{
			switch(nPaneNo)
			{
			case 1:
				m_pMotor->InitTimer();
				m_pMotor->DispVelocity();
				m_pIO->KillSubTimer();
				m_pVision->DestroyTimer();
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
				}
				break;
			case 3:
				m_pMotor->DestroyTimer();
				m_pIO->KillSubTimer();
				m_pVision->DestroyTimer();
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
				}
				m_pPowerMeasurement->SetProcessPowerMeasure( gProcessINI.m_sProcessPowerMeasure, gProcessINI.m_sProcessAutoSetting.dPowermeterPos );
				m_pPowerMeasurement->SetToolComboBox();
				break;
			case 4:
				m_pScannerCalibration->SetProcessScannerCal( gProcessINI.m_sProcessScannerCal );
				m_pScannerCalibration->SetToolComboBox();

				m_pMotor->DestroyTimer();
				m_pIO->KillSubTimer();
				m_pVision->DestroyTimer();
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					m_pScannerCalibration->ConnectView();
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
				}
				
				::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_TABLE, TRUE);
				::AfxGetMainWnd()->SendMessage(UM_TABLE_MODE, TABLE_MANUALSCAL);
				
				break;
			case 5:
				m_pVision->SetFiducial(bSetFid);
				m_pMotor->DestroyTimer();
				m_pIO->KillSubTimer();
				m_pVision->InitTimer();
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					m_pVision->ConnectView();
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
				}
				break;
			case 6:
				m_pVision->DestroyTimer();
				m_pOneHole->SetToolComboBox();
				
				m_pOneHole->SetDefaultZScan();
				m_pMotor->DestroyTimer();
				m_pIO->KillSubTimer();
				
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					m_pOneHole->ConnectView();
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
				}
				
				::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_TABLE, TRUE);
				::AfxGetMainWnd()->SendMessage(UM_TABLE_MODE, TABLE_ONEHOLE);
				
				break;
			case 8 : // IO
				m_pMotor->DestroyTimer();
				m_pIO->ChangeSubPane();
				m_pVision->DestroyTimer();
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
				}	break;
			case 0: // CO2 Laser or UV Laser
				m_pMotor->DestroyTimer();
				m_pIO->KillSubTimer();
				m_pVision->DestroyTimer();
				if(!bSideVision)
				{
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
				}
				#ifdef __3RDAOD__

					m_pLaser->GetDlgItem(IDC_CHECK_DUMMY_FREE)->ShowWindow(SW_HIDE);
					m_pLaser->GetDlgItem(IDC_BUTTON_DUMMY_FREE)->ShowWindow(SW_HIDE);

				#endif
				if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
					m_pLaserUV->CallDialog();
				if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
					m_pLaserUV->CallDialog();
				if(m_pLaser!=NULL)
					m_pLaser->InitTimer();
				break;
			case 9: // UV Laser
				m_pMotor->DestroyTimer();
				m_pIO->KillSubTimer();
				m_pVision->DestroyTimer();
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
				}
				m_pLaserUV->CallDialog();
				break;
				
				
			default:
				m_pMotor->DestroyTimer();
				m_pIO->KillSubTimer();
				m_pVision->DestroyTimer();
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
				}
				break;
			}
		}
		else
		{
			switch(nPaneNo)
			{
			case 1:
				m_pMotor->InitTimer();
				m_pMotor->DispVelocity();
				m_pIO->KillSubTimer();
				m_pVision->DestroyTimer();
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
				}
				break;
			case 3:
				
				m_pMotor->DestroyTimer();
				m_pIO->KillSubTimer();
				m_pVision->DestroyTimer();
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					m_pScannerCalibration->ConnectView();
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
				}
				break;
			case 4:
				m_pVision->InitTimer();
				m_pVision->SetFiducial(bSetFid);
				
				m_pMotor->DestroyTimer();
				m_pIO->KillSubTimer();
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					m_pVision->ConnectView();
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
				}
				break;
			case 5:
				m_pVision->DestroyTimer();
				
				m_pOneHole->SetDefaultZScan();
				m_pMotor->DestroyTimer();
				m_pIO->KillSubTimer();
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					m_pOneHole->ConnectView();
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
				}
				break;
			case 7 : // IO
				m_pVision->DestroyTimer();
				m_pMotor->DestroyTimer();
				m_pIO->ChangeSubPane();
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
				}
				break;
			case 0: // CO2 Laser or UV Laser
				m_pMotor->DestroyTimer();
				m_pIO->KillSubTimer();
				m_pVision->DestroyTimer();
				if(!bSideVision)
				{
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
				}
				if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
					m_pLaserUV->CallDialog();
				if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
					m_pLaserUV->CallDialog();
				if(m_pLaser!=NULL)
					m_pLaser->InitTimer();
				break;
			case 8: // UV Laser
				m_pMotor->DestroyTimer();
				m_pIO->KillSubTimer();
				m_pVision->DestroyTimer();
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
				}
				m_pLaserUV->CallDialog();
				break;
				
			default:
				m_pMotor->DestroyTimer();
				m_pIO->KillSubTimer();
				m_pVision->DestroyTimer();
				if(m_pLaser!=NULL)
					m_pLaser->DestroyTimer();
				if(!bSideVision)
				{
					if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
					else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
						((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
				}
				break;
			}
		}
	}
}

void CPaneManualControl::OnClickTabManualControl(NMHDR* pNMHDR, LRESULT* pResult) 
{
	int nSel = m_tabManualControl.GetCurSel();

	((CEasyDrillerDlg*)::AfxGetMainWnd())->ActiveStaticForKeyboardError();

	if( nSel == m_nPaneNo )
		return;

	BOOL bSideVision = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetSideStatus();

#ifdef __NANYA__
	int nLevel = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetUserLevel();

	if( nLevel == 0 && nSel > 4 )
	{
		m_tabManualControl.ShowPane( 4 );
		nSel = 4;
	}
#endif
	::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_TABLE, FALSE);

	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 1)
	{
		switch( m_nPaneNo )
		{
		case 1 :
			m_pMotor->DestroyTimer();
			break;
		case 3 :
//			m_pPowerMeasurement->DisconnectPort();
			break;
		case 4 :
			m_pScannerCalibration->ResetLive();
			break;
		case 5 :
			m_pVision->ResetLive();
			break;
		case 6 :
			m_pOneHole->ResetLive();
			break;
		case 8 :
			m_pIO->KillSubTimer();
			break;
		}

		switch( nSel )
		{
	
		case 1:
			m_pVision->DestroyTimer();
			m_pMotor->InitTimer();
			m_pMotor->DispVelocity();
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
			break;
		case 2:
			m_pVision->DestroyTimer();
			m_pDevice->SetDeviceStatus();			
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
			break;
		case 3 : // Power Measurement
//			m_pPowerMeasurement->ConnectPort();
			m_pVision->DestroyTimer();
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
			m_pPowerMeasurement->SetProcessPowerMeasure( gProcessINI.m_sProcessPowerMeasure, gProcessINI.m_sProcessAutoSetting.dPowermeterPos );
			m_pPowerMeasurement->SetToolComboBox();
			break;
		case 4 : // Scanner Calibration
			m_pVision->DestroyTimer();
			
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				m_pScannerCalibration->ConnectView();
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				{
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
					for(int i =0; i<MAX_CAMERA; i++)
						gDeviceFactory.GetVision()->ClearInteractiveGraphics(i);
				}
			}
			m_pScannerCalibration->SetProcessScannerCal( gProcessINI.m_sProcessScannerCal );
			m_pScannerCalibration->SetToolComboBox();
			
			::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_TABLE, TRUE);
			::AfxGetMainWnd()->SendMessage(UM_TABLE_MODE, TABLE_MANUALSCAL);
		
			break;
		case 5 : // Vision Teaching	
			m_pVision->InitTimer();
			
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				m_pVision->ConnectView();
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				{
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
					int nIndex, nCam;
					m_pVision->GetSelIndex(nIndex, nCam);
					m_pVision->ChangeDisplay(nIndex, nCam);
					for(int i =0; i<MAX_CAMERA; i++)
						gDeviceFactory.GetVision()->ClearInteractiveGraphics(i);
				}
			}
			break;
		case 6 : // One Hole
			m_pVision->DestroyTimer();
			m_pOneHole->SetToolComboBox();
		
			m_pOneHole->SetDefaultZScan();
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				m_pOneHole->ConnectView();
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				{
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
					for(int i =0; i<MAX_CAMERA; i++)
						gDeviceFactory.GetVision()->ClearInteractiveGraphics(i);
				}
			}
			
			::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_TABLE, TRUE);
			::AfxGetMainWnd()->SendMessage(UM_TABLE_MODE, TABLE_ONEHOLE);
			break;
		case 7 :
			m_pVision->DestroyTimer();
			if(!bSideVision)
			{
				m_pParameter->ConnectView();
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
			break;
		case 8 : // IO
			m_pVision->DestroyTimer();
			m_pIO->ChangeSubPane();
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
			break;
	//	case 7 : // Parameter
	//		break;
		case 0: // CO2 Laser or UV Laser
			m_pVision->DestroyTimer();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
			#ifdef __3RDAOD__

			{
				m_pLaser->GetDlgItem(IDC_CHECK_DUMMY_FREE)->ShowWindow(SW_HIDE);
				m_pLaser->GetDlgItem(IDC_BUTTON_DUMMY_FREE)->ShowWindow(SW_HIDE);
			}

			#endif
			if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
				m_pLaserUV->CallDialog();
			if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
					m_pLaserUV->CallDialog();
			if(m_pLaser!=NULL)
				m_pLaser->InitTimer();
			break;
		case 9: // UV Laser
			m_pVision->DestroyTimer();
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
			m_pLaserUV->CallDialog();
			break;
		default :
			m_pVision->DestroyTimer();
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
			break;
		}
	}
	else
	{
		switch( m_nPaneNo )
		{
		case 1 :
			m_pMotor->DestroyTimer();
			break;
		case 3 :
			m_pScannerCalibration->ResetLive();
			break;
		case 4 :
			m_pVision->ResetLive();
			break;
		case 5 :
			m_pOneHole->ResetLive();
			break;
		case 7 :
			m_pIO->KillSubTimer();
			break;
		}
		
		switch( nSel )
		{
		case 1:
			m_pVision->DestroyTimer();
			m_pMotor->InitTimer();
			m_pMotor->DispVelocity();
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
			break;
		case 2:
			m_pVision->DestroyTimer();
			m_pDevice->SetDeviceStatus();
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
			break;
		case 3 : // Scanner Calibration
			m_pVision->DestroyTimer();
			m_pScannerCalibration->SetProcessScannerCal( gProcessINI.m_sProcessScannerCal );
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				m_pScannerCalibration->ConnectView();
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
				m_pScannerCalibration->SetToolComboBox();
			}
			break;
		case 4: // Vision Teaching	
			m_pVision->InitTimer();
			
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				m_pVision->ConnectView();
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
			}
			break;
		case 5 : // One Hole
			m_pVision->DestroyTimer();
			
			m_pOneHole->SetToolComboBox();
			m_pOneHole->SetDefaultZScan();
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				m_pOneHole->ConnectView();
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_SHOW);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_SHOW);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_SHOW);
			}
			break;
		case 7 : // IO
			m_pVision->DestroyTimer();
			m_pIO->ChangeSubPane();
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
			break;
			//	case 6 : // Parameter
			//		break;
		case 0: // CO2 Laser or UV Laser
			m_pVision->DestroyTimer();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
			if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
				m_pLaserUV->CallDialog();
			if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
				m_pLaserUV->CallDialog();
			if(m_pLaser!=NULL)
				m_pLaser->InitTimer();
			break;
		case 8: // UV Laser
			m_pVision->DestroyTimer();
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
			m_pLaserUV->CallDialog();
			break;
		default :
			m_pVision->DestroyTimer();
			if(m_pLaser!=NULL)
				m_pLaser->DestroyTimer();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
			break;
		}
	}
	
	
	WPARAM wParam = MANUAL_CONTROL;
	LPARAM lParam = nSel;
	::AfxGetMainWnd()->PostMessage( CHANGE_SUB_PANE, wParam, lParam );
	
	m_nPaneNo = nSel;
	
	*pResult = 0;
}

void CPaneManualControl::OnDestroy() 
{
	m_fntTab.DeleteObject();

	CFormView::OnDestroy();
}

int CPaneManualControl::GetTabCurSel()
{
	return m_tabManualControl.GetCurSel();
}

BOOL CPaneManualControl::GetLaserPower()
{
	if(m_pLaser)
		return m_pLaser->m_bLaserPower;
	if(m_pLaserUV)
		return TRUE;
	return FALSE;
}

void CPaneManualControl::SetData(int nPane)
{
	if(nPane == 2)
		m_pParameter->SetData(gVariable, 2);
	else if(nPane == 3)
		m_pParameter->SetData(gVariable, 0);
	else if(nPane == 5)
		m_pParameter->SetData(gVariable, 1);
	else
		m_pParameter->SetData(gVariable, -1);
}

CPaneManualControlVision* CPaneManualControl::GetVisionTab()
{
	return m_pVision;
}

void CPaneManualControl::EnableTab(BOOL bEnable)
{
//	m_tabManualControl.EnableWindow(bEnable);
	m_tabManualControl.TabChangeEnable(bEnable);
}


void CPaneManualControl::ReDrawData_WhenTableChange()
{
	if(m_pScannerCalibration != NULL)
		m_pScannerCalibration->ReDrawData_WhenTableChange();

	if(m_pPowerMeasurement != NULL)
		m_pPowerMeasurement->ReDrawData_WhenTableChange();
}

void CPaneManualControl::SetAuthorityByLevel(int nLevel)
{
	if(m_pMotor != NULL)
		m_pMotor->SetAuthorityByLevel(nLevel);
	
	if(m_pParameter != NULL)
		m_pParameter->SetAuthorityByLevel(nLevel);

	if(m_pLaser != NULL)
		m_pLaser->SetAuthorityByLevel(nLevel);
	
	if(m_pIO != NULL &&	gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_PMAC)
		m_pIO->m_pSubOutput1->SetAuthorityByLevel(nLevel);

	if(m_pScannerCalibration != NULL)
		m_pScannerCalibration->SetAuthorityByLevel(nLevel);
	
	if(m_pPowerMeasurement != NULL)
		m_pPowerMeasurement->SetAuthorityByLevel(nLevel);

	if(m_pOneHole != NULL)
		m_pOneHole->SetAuthorityByLevel(nLevel);

	if(m_pScannerCalibration != NULL)
		m_pScannerCalibration->SetAuthorityByLevel(nLevel);

	if(m_pVision != NULL)
		m_pVision->SetAuthorityByLevel(nLevel);
}
// DlgShotTable.h: interface for the CPaneSysSetupShotTable class.
//
//////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "resource.h"
#include "easydriller.h"
#include "..\model\ShotTableINIFile.h"
#include "..\model\DShotTableINI.h"
#include "GridCtrl_src\GridCtrl.h"



#define		TABLE0  0
#define		TABLE1  1
#define		TABLE2  2
#define		TABLE3  3
#define		TABLE4  4
#define		TABLE5  5 






#define		SHOT_TABLE0_COLUMN_COUNT 1
#define		SHOT_TABLE1_COLUMN_COUNT 7
#define		SHOT_TABLE2_COLUMN_COUNT 2
#define		SHOT_TABLE3_COLUMN_COUNT 0
#define		SHOT_TABLE4_COLUMN_COUNT 0
#define		SHOT_TABLE5_COLUMN_COUNT 0

#define		SHOT_GROUP_TABLE0_COLUMN_COUNT 2
#define		SHOT_GROUP_TABLE1_COLUMN_COUNT 16
#define		SHOT_GROUP_TABLE2_COLUMN_COUNT 7

#define		SHOT_AOM_TABLE0_COLUMN_COUNT 3



#define		COLUMNWIDTH  13	// �÷��� �ѱ��ڴ� �Ҵ�Ǵ� ������ ���� 


#define		TABLETEXT_COLOR		RGB(0,0,0)
#define		TABLE1_COLOR		RGB(255,255,255)
#define		TABLE2_COLOR		RGB(230,230,230)
#define		TABLE3_COLOR		RGB(220,220,220)
#define		TABLE4_COLOR		RGB(210,210,210)
#define		TABLE5_COLOR		RGB(200,200,200) 
#define		TABLE6_COLOR		RGB(180,180,180)


class CDlgShotTable : public CDialog
{
	DECLARE_DYNAMIC(CDlgShotTable)

// Form Data
public:
    	CDlgShotTable(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgShotTable();
	enum { IDD = IDD_DLG_SHOT_TABLE };
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	//}}AFX_DATA

// Attributes
public:
	UEasyButtonEx	m_chkInfo;
	UEasyButtonEx	m_chkBeamPath;
	UEasyButtonEx	m_chkPowerOffset;
	UEasyButtonEx	m_chkPowerCompensation;
	UEasyButtonEx	m_chkScannerFact;
	UEasyButtonEx   m_ChkSubBox[6];

	UEasyButtonEx   m_ChkGroupSubBox[3];

	UEasyButtonEx	m_btnRefresh;
	UEasyButtonEx   m_btnAdd;
	UEasyButtonEx	m_btnDel;
	UEasyButtonEx   m_btnUp;
	UEasyButtonEx	m_btnDown;

	UEasyButtonEx   m_btnGroupAdd;
	UEasyButtonEx	m_btnGroupDel;


	BOOL			m_bInfoCheck;
	BOOL			m_bBeamPathCheck;
	BOOL			m_bPowerOffsetCheck;
	BOOL			m_bpowerCompensationCheck;
	BOOL			m_bScannerFactCheck;

	BOOL			m_bCheckBox[6];
	BOOL			m_bGroupCheckBox[3];



	CListCtrl		m_list;
	CListCtrl		m_GroupList;

	CEdit			m_editwnd;
	CPoint			m_posClicked;		// ����Ʈ �� Ŭ���� �� ��� 

	CPoint			m_posGroupClicked;
	CPoint			m_posAOMClicked;


	int				m_nRepeatCount;
	int				m_nGroupRepeatCount;
	int				m_nAOMRepeatCount;

	BOOL			m_bClickList;
	BOOL			m_ClickID;

	BOOL			m_bGroupClickGrid;
	BOOL			m_bClickGrid;
	BOOL			m_bAOMClickGrid;

	int m_nGroupSelectRow;
	int m_nSelectRow;
	int m_nAOMSelectRow;
//	SSHOTGROUPTABLE		m_sShotGroupTable;
//	SSHOTGROUPTABLE		m_sTempShotGroupTable;


	BOOL			m_GroupClickID;


	BOOL m_bDeleteAndSaveClick;
	BOOL m_bDelClick;



	int				 m_IdNoToAddDel;


	CGridCtrl m_Grid;
	CGridCtrl m_GroupGrid;
	CGridCtrl m_AOMGrid;

	int				m_nColumnCount;
	int				m_nGroupColumnCount;
	int				m_nAOMColumnCount;

	int				m_nUserLevel;



	CString strTable0[SHOT_TABLE0_COLUMN_COUNT];// = {"No", "Name"};
	CString strTable1[SHOT_TABLE1_COLUMN_COUNT]; // = {vision, size, tol, ratio, polarity, contrast, brightness}
	CString strTable2[SHOT_TABLE2_COLUMN_COUNT];

	CString strGroupTable0[SHOT_GROUP_TABLE0_COLUMN_COUNT];// = {"No", "Name"};
	CString strGroupTable1[SHOT_GROUP_TABLE1_COLUMN_COUNT];// = {Type, Mode,TotalShot,BurstShot,Votage_M,Votage_S,UseAperure,Path};
	CString strGroupTable2[SHOT_GROUP_TABLE2_COLUMN_COUNT];// = {LaserOnDelay, LaserOffDelay,DrawSpeed,JumpSpeed,ConerDelay,JumpDelay,LineDelay};


	CString strAOMTable0[SHOT_AOM_TABLE0_COLUMN_COUNT];// = {"No", "M.AOM On,M.AOM Off,S.AOM On,S.AOM Off"};

// Attributes
protected :
	CFont		m_fntStatic;
	CFont		m_fntEdit;
	CFont		m_fntBtn;
// Operations
public:
	void SaveChangeValue(int nGroup);
	void SaveChangeGroupValue();
	void EnableControl(BOOL bEnable);
	void SetAuthorityByLevel(int nLevel);
	void CellDisable(int y);


	BOOL CheckApply();

	int m_nVisionMode;

	int GetShowBoxMode(int nXPos);
	void SetCurrentScrollPos(int xPos, int yPos);
	void OnCheckDown();
	void OnCheckUp();

	void CopyFromTempToOriginal();
	void CopyFromOriginaltoTemp(int nSelectNo, int RepeatNo);

	void CopyFromTempToGroupOriginal();
	void CopyFromGroupOriginaltoTemp(int nSelectNo, int RepeatNo);
	


	void InitDataStruct();
	void InitGroupDataStruct();

	int GetIdNoToAddDel();
	void SetIdNoToAddDel(int nIdYPos);



	int GetColumnSize(int nStrlen);
	void OnCheckDel();
	void OnCheckAdd();
	
	void OnCheckGroupAdd();
	void OnCheckGroupDel();


	SSHOTTABLE		m_sTempShotTable;

	void GetShotGroupTable(SSHOTGROUPTABLE* pShotGroupTable);
	void SetShotGroupTable(SSHOTGROUPTABLE sShotGroupTable);


	CString GetChangeGroupValueStr();
	CString GetChangeAOMValueStr();

	BOOL FillTable2Data(int x, int y, CString str);
	BOOL FillTable1Data(int x, int y, CString str);
	BOOL FillTable0Data(int x, int y, CString str);

	BOOL FillGroupTable0Data(int x, int y, CString str);
	BOOL FillGroupTable1Data(int x, int y, CString str);
	BOOL FillGroupTable2Data(int x, int y, CString str);

	BOOL FillAOMTable0Data(int x, int y, CString str);

	BOOL ListUpdate(CPoint ClickedPos, CString str);
	BOOL GroupListUpdate(CPoint ClickedPos, CString str);
	BOOL AOMListUpdate(CPoint ClickedPos, CString str);
	


	void InsertGridValue(GV_ITEM Gvitem,int startNo, int TableNo, int ColCount);
	void InsertGroupGridValue(GV_ITEM Gvitem,int startNo, int TableNo, int ColCount);
	void InsertAOMGridValue(GV_ITEM Gvitem,int startNo, int TableNo, int ColCount);



	void InsertListComumn(int startNo, int TableNo);
	void InsertGroupListComumn(int startNo, int TableNo);
	void InsertAOMListComumn(int startNo, int TableNo);

	void DeleteList();
	void DeleteGroupList();
	void DeleteAOMList();



	void SetDrawMember(int listcount);
	int  GetListIndex();

	int GetGroupListIndex();
	void SetGroupDrawMember(int listcount);

	int GetAOMListIndex();
	void SetAOMDrawMember(int listcount);


	void InitListControl();
	void OnCheckRefresh();
	void OnCheckRefresh2(int nShowNo = 0);

	void OnCheckScannerFact();
	void OnCheckPowerCompensation();
	void OnCheckPowerOffset();
	void OnCheckBeamPath();
	void OnCheckHoleFact();
	void InitBtnControl();
	void InitStaticControl();
	void InitEditControl();
	void InitGrid();
	void ChangeShotOrderOfToolTable(int nDelShotNo);

	void OnCheckGroupTable1();
	void OnCheckGroupTable2();


	void UpdateGridSelNo();
	BOOL ValidateShotValue(int nGroupNo);
	BOOL ValidateGroupValue();

	BOOL ChangeAOMWait();


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgShotTable)
	public:

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support


	//}}AFX_VIRTUAL

// Implementation
protected:


	// Generated message map functions
	//{{AFX_MSG(CDlgShotTable)

	virtual BOOL OnInitDialog();
	afx_msg void OnClickList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//afx_msg void OnCustomdrawList(NMHDR* pNMHDR, LRESULT * pResult);
	afx_msg void OnNMCustomdrawListTest(NMHDR *pNMHDR, LRESULT *pResult);

	afx_msg void OnClickGroupList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnNMCustomdrawGroupListTest(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnGridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	afx_msg void OnGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult);
	afx_msg void OnGroupGridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	afx_msg void OnGroupGridDoubleClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	afx_msg void OnAOMGridClick(NMHDR *pNotifyStruct, LRESULT* pResult);

	afx_msg void OnGroupGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult);
	afx_msg void OnAOMGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult);

		//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnSave();
	afx_msg void OnBnClickedBtnCancel();
};



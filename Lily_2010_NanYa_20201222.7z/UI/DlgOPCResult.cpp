// D:\Source\2010_ver\Lily_2010\UI\DlgOPCResult.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "DlgOPCResult.h"
#include "afxdialogex.h"
#include "EasyDrillerDlg.h"
#include "..\DEVICE\OPCSvr.h"
// CDlgOPCResult ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDlgOPCResult, CDialog)

CDlgOPCResult::CDlgOPCResult(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgOPCResult::IDD, pParent)
{
	m_nProjectData = 1;
}

CDlgOPCResult::~CDlgOPCResult()
{
}

void CDlgOPCResult::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDOK, m_btnOK);
}


BEGIN_MESSAGE_MAP(CDlgOPCResult, CDialog)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDOK, &CDlgOPCResult::OnBnClickedOk)
END_MESSAGE_MAP()


// CDlgOPCResult �޽��� ó�����Դϴ�.


BOOL CDlgOPCResult::OnInitDialog()
{
	CDialog::OnInitDialog();

	InitStatic();
	InitBtn();
	ChangeDisplay();
	return TRUE;
}

void CDlgOPCResult::InitStatic()
{
	m_fntStatic.CreatePointFont(110, _T("Arial Bold"));

	GetDlgItem(IDC_STATIC_BASKET_VAL)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_COUNT_VAL)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_FILMNO_VAL)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_LOTID_VAL)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_MESSAGE_VAL)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_PROJECT_C_VAL)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_PROJECT_S_VAL)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_RESULT_VAL)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_THICK_VAL)->SetFont(&m_fntStatic);

	GetDlgItem(IDC_STATIC_BASKET)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_COUNT)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_FILMNO)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_LOTID)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_MESSAGE)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_PROJECT_C)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_PROJECT_S)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_RESULT)->SetFont(&m_fntStatic);
	GetDlgItem(IDC_STATIC_THICK)->SetFont(&m_fntStatic);
	SetFont(&m_fntStatic);

}
void CDlgOPCResult::InitBtn()
{
	m_fntBtn.CreatePointFont(110, _T("Arial Bold"));

	m_btnOK.SetFont( &m_fntBtn );
	m_btnOK.SetFlat( FALSE );
	m_btnOK.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOK.EnableBallonToolTip();
	m_btnOK.SetToolTipText( _T("OK") );
	m_btnOK.SetBtnCursor(IDC_HAND_1);
	
	m_btnCancel.SetFont( &m_fntBtn );
	m_btnCancel.SetFlat( FALSE );
	m_btnCancel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCancel.EnableBallonToolTip();
	m_btnCancel.SetToolTipText( _T("NO") );
	m_btnCancel.SetBtnCursor(IDC_HAND_1);

}
void CDlgOPCResult::ChangeDisplay()
{
	int nRMSType = ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType();
//	if(nRMSType == 0)
//	{
//		m_btnCancel.ShowWindow(SW_HIDE);
//		m_btnOK.SetWindowText(_T("MES OK"));
//
//	}

	GetDlgItem(IDC_STATIC_BASKET_VAL)->SetWindowText(m_strBasket);
	GetDlgItem(IDC_STATIC_COUNT_VAL)->SetWindowText(m_strCount);
	GetDlgItem(IDC_STATIC_FILMNO_VAL)->SetWindowText(m_strFilmNO);
	GetDlgItem(IDC_STATIC_LOTID_VAL)->SetWindowText(m_strLotID);
	GetDlgItem(IDC_STATIC_MESSAGE_VAL)->SetWindowText(m_strMessage);
	GetDlgItem(IDC_STATIC_PROJECT_C_VAL)->SetWindowText(m_strPrjC);
	GetDlgItem(IDC_STATIC_PROJECT_S_VAL)->SetWindowText(m_strPrjS);
	GetDlgItem(IDC_STATIC_RESULT_VAL)->SetWindowText(m_strResult);
	GetDlgItem(IDC_STATIC_THICK_VAL)->SetWindowText(m_strThick);

	if(m_nProjectData == 0)
	{
		m_btnOK.SetWindowText(_T("OK"));
		m_btnCancel.SetWindowText(_T("Cancel"));
	}
	else
	{
		m_btnOK.SetWindowText(_T("MES Input"));
		m_btnCancel.SetWindowText(_T("MES Cancel"));
	}
}
void CDlgOPCResult::SetResult( CString strBasket, CString strCount, CString strFilmNO, CString strLotID, CString strMessage, CString strPrjC, CString strPrjS, CString strResult, CString strThick)
{
	m_strBasket = strBasket;
	m_strCount = strCount;
	m_strFilmNO = strFilmNO;
	m_strLotID = strLotID;
	m_strMessage = strMessage;
	m_strPrjC = strPrjC;
	m_strPrjS = strPrjS;
	m_strResult = strResult;
	m_strThick = strThick;
}
HBRUSH CDlgOPCResult::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
		
	
	return hbr;
}

void CDlgOPCResult::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}

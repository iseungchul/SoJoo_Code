// PaneUserAccountSub.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneUserAccountSub.h"
#include "..\easydrillerdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneUserAccountSub

IMPLEMENT_DYNCREATE(CPaneUserAccountSub, CFormView)

CPaneUserAccountSub::CPaneUserAccountSub()
	: CFormView(CPaneUserAccountSub::IDD)
{
	//{{AFX_DATA_INIT(CPaneUserAccountSub)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneUserAccountSub::~CPaneUserAccountSub()
{
}

void CPaneUserAccountSub::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneUserAccountSub)
	DDX_Control(pDX, IDC_BUTTON_BACK, m_btnBack);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneUserAccountSub, CFormView)
	//{{AFX_MSG_MAP(CPaneUserAccountSub)
	ON_BN_CLICKED(IDC_BUTTON_BACK, OnButtonBack)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneUserAccountSub diagnostics

#ifdef _DEBUG
void CPaneUserAccountSub::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneUserAccountSub::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneUserAccountSub message handlers

void CPaneUserAccountSub::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
}

void CPaneUserAccountSub::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, _T("Arial Bold"));

	m_btnBack.SetFont( &m_fntBtn );
	m_btnBack.SetFlat( FALSE );
	m_btnBack.SetImageOrg( 10, 3 );
	m_btnBack.SetIcon( IDI_BACK );
	m_btnBack.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBack.EnableBallonToolTip();
	m_btnBack.SetToolTipText( _T("Back") );
	m_btnBack.SetBtnCursor( IDC_HAND_1 );
}

void CPaneUserAccountSub::OnButtonBack() 
{
	((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteProcessLog(_T("����� ���� ȭ�鿡�� LogOut�Ͽ����ϴ�."), _T(""));

	WPARAM wParam = -1;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, 0 );
}

void CPaneUserAccountSub::OnDestroy() 
{
	m_fntBtn.DeleteObject();

	CFormView::OnDestroy();
}

#if !defined(AFX_PANEMANUALCONTROLIOMONITORINPUTSUB2OSAN_H__F6D3152F_D5A0_4F47_91EA_E647F282597D__INCLUDED_)
#define AFX_PANEMANUALCONTROLIOMONITORINPUTSUB2OSAN_H__F6D3152F_D5A0_4F47_91EA_E647F282597D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlIOMonitorInputSub2Osan.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub2Osan form view

#include "LedButton.h"
#include "..\device\devicemotor.h"
#include "..\device\HMotor.h"
#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CPaneManualControlIOMonitorInputSub2Osan : public CFormView
{
protected:
	CPaneManualControlIOMonitorInputSub2Osan();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlIOMonitorInputSub2Osan)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlIOMonitorInputSub2Osan)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_IO_MONITOR_INPUT_SUB2_OSAN };
	CFont m_fntBtn;

	CLedButton m_ledAlignRun;
	CLedButton m_ledAlignEnd;
	CLedButton m_ledLoadRun;
	CLedButton m_ledLoadEnd;
	CLedButton m_ledUnloadRun;
	CLedButton m_ledUnloadEnd;
	CLedButton m_ledLoadRequestReady;
	CLedButton m_ledLoadPartError;
	CLedButton m_ledUnloadPartError;

	CLedButton m_ledLP1PCBExist;
	CLedButton m_ledLP2PCBExist;
	CLedButton m_ledUP1PCBExist;
	CLedButton m_ledUP2PCBExist;
	CLedButton m_ledLdElvPCBExist;
	CLedButton m_ledResetSwitch;
	CLedButton m_ledLoaderBypass;
	CLedButton m_ledUnloaderBypass;

	CLedButton m_ledLdPcbTransExist;
	CLedButton m_ledLdPaperTransExist;
	CLedButton m_ledUdPcbTransExist;
	CLedButton m_ledUdPaperTransExist;
	//}}AFX_DATA

// Attributes
public:
	int m_nTimerID;
#ifndef __MP920_MOTOR__
	DeviceMotor* m_pMotor;
#else
	HMotor* m_pMotor;
#endif
// Operations
public:
	void UpdateStatus();

	void InitTimer();
	void DestroyTimer();

	void InitBtnControl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlIOMonitorInputSub2Osan)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlIOMonitorInputSub2Osan();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlIOMonitorInputSub2Osan)
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLIOMONITORINPUTSUB2OSAN_H__F6D3152F_D5A0_4F47_91EA_E647F282597D__INCLUDED_)

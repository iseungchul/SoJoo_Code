#pragma once


// CDlgTableView dialog

class CDlgTableView : public CDialog
{
	DECLARE_DYNAMIC(CDlgTableView)

public:
	CDlgTableView(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgTableView();

// Dialog Data
	enum { IDD = IDD_DLG_TABLE_VIEW };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

public: //value
	int	m_nTimer;
	int m_nMode;
	int	m_nCam;
	BOOL m_bDisplayOn;
public: //function
	void SetDisplayOn(BOOL bOn);
	void DrawTable();
	void SetMode(int nType, int nCam);
	// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgComSetup)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnPaint();
	afx_msg void OnDestroy();
};

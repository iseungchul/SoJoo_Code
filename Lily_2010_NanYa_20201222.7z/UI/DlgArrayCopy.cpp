// DlgArrayCopy.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgArrayCopy.h"
#include "..\model\DEasyDrillerINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgArrayCopy dialog


CDlgArrayCopy::CDlgArrayCopy(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgArrayCopy::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgArrayCopy)
	m_dOffsetX = 10.0;
	m_dOffsetY = 10.0;
	m_dRadius = 20.0;
	m_nShapeType = 0;
	m_nCopyType = 0;
	m_dCenterOffsetX = 0.0;
	m_dCenterOffsetY = 0.0;
	m_bFieldCopy = FALSE;
	//}}AFX_DATA_INIT
}


void CDlgArrayCopy::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgArrayCopy)
	DDX_Text(pDX, IDC_EDT_DX, m_dOffsetX);
	DDX_Text(pDX, IDC_EDT_DY, m_dOffsetY);
	DDX_Text(pDX, IDC_EDT_R, m_dRadius);
	DDX_Radio(pDX, IDC_RAD_SHAPE, m_nShapeType);
	DDX_Radio(pDX, IDC_RAD_TYPE, m_nCopyType);
	DDX_Text(pDX, IDC_EDT_R_OFFSET_X, m_dCenterOffsetX);
	DDX_Text(pDX, IDC_EDT_R_OFFSET_Y, m_dCenterOffsetY);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgArrayCopy, CDialog)
	//{{AFX_MSG_MAP(CDlgArrayCopy)
	ON_BN_CLICKED(IDC_RAD_TYPE, OnRadType)
	ON_BN_CLICKED(IDC_RAD_TYPE2, OnRadType2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgArrayCopy message handlers

void CDlgArrayCopy::LoadData()
{
	CString strPath;
	strPath.Format(_T("%sTemp\\ArrayCopy.bhl"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	
	FILE* pFile;
	errno_t err = fopen_s(&pFile, strPath, "r");
	CString str;
	
	if(err == NULL)
	{
		fscanf(pFile, "%s\n", str.GetBuffer(256));
		str.ReleaseBuffer();
		m_nCopyType = atoi(str);
		fscanf(pFile, "%s\n", str.GetBuffer(256));
		str.ReleaseBuffer();
		m_nShapeType = atoi(str);
		fscanf(pFile, "%s\n", str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dRadius = atof(str);
		fscanf(pFile, "%s\n", str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dCenterOffsetX = atof(str);
		fscanf(pFile, "%s\n", str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dCenterOffsetY = atof(str);

		fscanf(pFile, "%s\n", str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dOffsetX = atof(str);
		fscanf(pFile, "%s\n", str.GetBuffer(256));
		str.ReleaseBuffer();
		m_dOffsetY = atof(str);

		fclose(pFile);
	}
}

void CDlgArrayCopy::SaveData()
{
	CString strPath;
	strPath.Format(_T("%sTemp\\ArrayCopy.bhl"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	
	FILE* pFile;
	errno_t err = fopen_s(&pFile, strPath, "w+");

	if(err == NULL)
	{
		fprintf(pFile,"%d\n", m_nCopyType);
		fprintf(pFile,"%d\n", m_nShapeType);
		fprintf(pFile,"%.3f\n", m_dRadius);
		fprintf(pFile,"%.3f\n", m_dCenterOffsetX);
		fprintf(pFile,"%.3f\n", m_dCenterOffsetY);
		fprintf(pFile,"%.3f\n", m_dOffsetX);
		fprintf(pFile,"%.3f\n", m_dOffsetY);
		fclose(pFile);
	}
}

BOOL CDlgArrayCopy::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	LoadData();
	UpdateData(FALSE);

	if(m_bFieldCopy)
	{
		m_nCopyType = 1;
		GetDlgItem(IDC_RAD_TYPE)->EnableWindow(FALSE);
		GetDlgItem(IDC_RAD_TYPE2)->EnableWindow(FALSE);
	}
	else
	{
		GetDlgItem(IDC_RAD_TYPE)->EnableWindow(FALSE);
		GetDlgItem(IDC_RAD_TYPE2)->EnableWindow(FALSE);
	}

	if(m_nCopyType == 0)
		OnRadType();
	else
		OnRadType2();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgArrayCopy::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
	SaveData();
	CDialog::OnOK();
}

void CDlgArrayCopy::OnRadType() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_EDT_R)->EnableWindow(TRUE);
	GetDlgItem(IDC_STATIC_CX)->SetWindowText("Center Off X");
	GetDlgItem(IDC_STATIC_CY)->SetWindowText("Center Off Y");
}

void CDlgArrayCopy::OnRadType2() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_EDT_R)->EnableWindow(FALSE);
	GetDlgItem(IDC_STATIC_CX)->SetWindowText("X array No.");
	GetDlgItem(IDC_STATIC_CY)->SetWindowText("Y array No.");
}

void CDlgArrayCopy::SetCopyMode(BOOL bField)
{
	m_bFieldCopy = bField; 

}

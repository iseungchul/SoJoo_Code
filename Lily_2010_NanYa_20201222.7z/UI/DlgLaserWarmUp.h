#if !defined(AFX_DLGLASERWARMUP_H__93082CC7_7F2C_454F_A532_9B6EA2B64341__INCLUDED_)
#define AFX_DLGLASERWARMUP_H__93082CC7_7F2C_454F_A532_9B6EA2B64341__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgLaserWarmUp.h : header file
//

#include "ColorEdit.h"
#include "UEasyButton.h"
#include "UEasyButtonEx.h"
#include "..\device\heocard.h"
#include "..\device\devicemotor.h"
#include "..\Device\FParameter.h"
#include "..\device\HMotor.h"

const int PREHEAT_MAXPOS			= 200;

/////////////////////////////////////////////////////////////////////////////
// CDlgLaserWarmUp dialog

class CDlgLaserWarmUp : public CDialog
{
// Construction
public:
	void ScannerWarmup();
	BOOL BusyCheck();
	BOOL		m_bStart;
	CWinThread*			m_pThread;
	CWinThread*			m_pThreadDataBackup;
	void RunWarmup();
	CDlgLaserWarmUp(CWnd* pParent = NULL);   // standard constructor

	void		InitBtnControl();
	void		InitStaticControl();
	void		InitEditControl();

	void		ResizeDlg(BOOL bResize=FALSE);
	void		EnableButton(BOOL bEnable=FALSE);

	void		SetWarmUpSpeed();
	void		SetOriginalSpeed();
	BOOL		MotorMove(BOOL bStart) ;
	void		MessageLoop();

	void		PreHeatDataSave();
	void		SetAutoMode(BOOL bFlag = TRUE)	{m_bAutoMode = bFlag;};
	void		PreheatGalvaOnly()				{m_bGalvaOnly = TRUE;};
	void		SetStartButton(BOOL bStart);

// Dialog Data
	//{{AFX_DATA(CDlgLaserWarmUp)
	enum { IDD = IDD_DLG_LASER_WARM_UP };
	UEasyButtonEx	m_btnSpeedApply;
//	CColorEdit		m_edtSpeedZ2;
//	CColorEdit		m_edtSpeedZ1;
//	CColorEdit		m_edtSpeedY;
	CColorEdit		m_edtSpeedX;
	CProgressCtrl	m_progTime;
	UEasyButton		m_btnStart;
	UEasyButtonEx	m_btnSetting;
	
	CColorEdit		m_edtFreq;
	CColorEdit		m_edtDuty;
	CColorEdit		m_edtTime;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgLaserWarmUp)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL		m_bFirstMove;

	CFont		m_fntBtn;
	CFont		m_fntEdit;
	CFont		m_fntStatic;

	BOOL		m_bSetting;
	
	BOOL		m_bAutoMode;
	BOOL		m_bGalvaOnly;

	CSize		m_siNormalSize;
	CSize		m_siExtendSize;

	time_t		m_timeStart;
	int			m_nTimerID;
	int			m_nPreHeatTime;
	int			m_nPreHeatPos;

	int			m_nMoveIndex;

	double		m_dPreX[PREHEAT_MAXPOS];
	double		m_dPreY[PREHEAT_MAXPOS];

	HEocard*	m_pEoCard;
#ifndef __MP920_MOTOR__
	DeviceMotor* m_pMotor;
#else
	HMotor*		m_pMotor;
#endif
	FParameter	m_fPara;

	int			m_nShutter1;
	int			m_nShutter2;

	// Generated message map functions
	//{{AFX_MSG(CDlgLaserWarmUp)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnButtonSetting();
	afx_msg void OnButtonStart();
	afx_msg void OnButtonApply();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGLASERWARMUP_H__93082CC7_7F2C_454F_A532_9B6EA2B64341__INCLUDED_)

// PaneRecipeGenLayoutEasy.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneRecipeGenLayoutEasy.h"
#include "DlgMeasuringPCBThickness.h"

#include "..\model\DProject.h"
#include "..\model\dsystemini.h"
#include "..\model\dprocessini.h"
#include "..\model\deasydrillerini.h"
#include "..\EasyDrillerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenLayoutEasy

IMPLEMENT_DYNCREATE(CPaneRecipeGenLayoutEasy, CFormView)

CPaneRecipeGenLayoutEasy::CPaneRecipeGenLayoutEasy()
	: CFormView(CPaneRecipeGenLayoutEasy::IDD)
{
	//{{AFX_DATA_INIT(CPaneRecipeGenLayoutEasy)
	m_nScaleMode = 0;
	m_nTypeOfZero = 0;
	m_nCoordType = 0;
	m_nInputUnit = 0;
	m_nUsePanel = USE_DUAL;
	m_nVacuumType = VACUUM_A;
	m_nDummyFreeType = DUMMY_FREE_1;
	m_nFindHole = NO_FIND;
	m_bTurn = FALSE;
	m_nUserLevel = 0;
	m_bThicknessOK = FALSE;
	//}}AFX_DATA_INIT
}

CPaneRecipeGenLayoutEasy::~CPaneRecipeGenLayoutEasy()
{
}

void CPaneRecipeGenLayoutEasy::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneRecipeGenLayoutEasy)
	DDX_Control(pDX, IDC_STATIC_FIELD_Y, m_stcFieldY);
	DDX_Control(pDX, IDC_STATIC_FIELD_X, m_stcFieldX);
	DDX_Control(pDX, IDC_EDIT_Y_AXIS_RANGE, m_edtYAxisRange);
	DDX_Control(pDX, IDC_EDIT_X_AXIS_RANGE, m_edtXAxisRange);
	DDX_Control(pDX, IDC_EDIT_FIELD_SIZE_Y_AXIS, m_edtFieldSizeYAxis);
	DDX_Control(pDX, IDC_EDIT_FIELD_SIZE_X_AXIS, m_edtFieldSizeXAxis);
	DDX_Control(pDX, IDC_EDIT_TEXT_RANGE_X, m_edtXAxisTextRange);
	DDX_Control(pDX, IDC_EDIT_TEXT_RANGE_Y, m_edtYAxisTextRange);
	DDX_Radio(pDX, IDC_RADIO_SCALE_AUTO, m_nScaleMode);
	DDX_Radio(pDX, IDC_RADIO_TZS, m_nTypeOfZero);
	DDX_Radio(pDX, IDC_RADIO_ABS, m_nCoordType);
	DDX_Radio(pDX, IDC_RADIO_1UM, m_nInputUnit);
	DDX_Radio(pDX, IDC_RADIO_USE_DUAL, m_nUsePanel);
	DDX_Radio(pDX, IDC_RADIO_TABLE_VACUMM_A, m_nVacuumType);
	DDX_Radio(pDX, IDC_RADIO_DUMMY_FREE_TYPE_1, m_nDummyFreeType);
	DDX_Radio(pDX, IDC_RADIO_USE_HOLE_NO, m_nFindHole);
	DDX_Control(pDX, IDC_EDIT_PCB_THICKNESS, m_edtPCBThickness);
	DDX_Control(pDX, IDC_EDIT_PCB_THICKNESS_2ND, m_edtPCBThickness2nd);
	DDX_Control(pDX, IDC_EDIT_PCB_THICKNESS2, m_edtPCBThicknessOffset);
	DDX_Control(pDX, IDC_BUTTON_MEASURING_THICKNESS, m_btnMeasuringThickness);
	DDX_Control(pDX, IDC_CHECK_USE_CUDIRECT, m_chkUseCuDirect);
	DDX_Control(pDX, IDC_CHECK_TURN, m_chkTurn);
	DDX_Control(pDX, IDC_EDIT_SCALE_LIMIT1, m_edtScaleLimit1);
	DDX_Control(pDX, IDC_EDIT_SCALE_LIMIT2, m_edtScaleLimit2);
	DDX_Control(pDX, IDC_EDIT_SCALE_MANUAL, m_edtScaleManual);
	DDX_Control(pDX, IDC_EDIT_SCALE_LIMIT1_MINUS, m_edtScaleLimit1Minus);
	DDX_Control(pDX, IDC_EDIT_SCALE_LIMIT2_MINUS, m_edtScaleLimit2Minus);
	DDX_Control(pDX, IDC_EDIT_REF_FID_OFFSET_X, m_edtRefFidOffsetX);
	DDX_Control(pDX, IDC_EDIT_REF_FID_OFFSET_Y, m_edtRefFidOffsetY);
	DDX_Control(pDX, IDC_EDIT_TOLERANCE, m_edtScaleTolerance1);
	DDX_Control(pDX, IDC_EDIT_TOLERANCE2, m_edtScaleTolerance2);
	DDX_Control(pDX, IDC_EDIT_MEAN_SCALE, m_edtMeanScale);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneRecipeGenLayoutEasy, CFormView)
	//{{AFX_MSG_MAP(CPaneRecipeGenLayoutEasy)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_MEASURING_THICKNESS, OnButtonMeasuringThickness)
	ON_BN_CLICKED(IDC_CHECK_USE_CUDIRECT, OnCheckUseCudirect)
	ON_BN_CLICKED(IDC_RADIO_SCALE_AUTO, OnRadioScaleAuto)
	ON_BN_CLICKED(IDC_RADIO_SCALE_MANUAL, OnRadioScaleManual)
	ON_BN_CLICKED(IDC_RADIO_TABLE_VACUMM_A, OnRadioTableVacummA)
	ON_BN_CLICKED(IDC_RADIO_TABLE_VACUMM_B, OnRadioTableVacummB)
	ON_BN_CLICKED(IDC_RADIO_TABLE_VACUMM_C, OnRadioTableVacummC)
	ON_BN_CLICKED(IDC_RADIO_DUMMY_FREE_TYPE_1, OnRadioDummyFreeType1)
	ON_BN_CLICKED(IDC_RADIO_DUMMY_FREE_TYPE_2, OnRadioDummyFreeType2)
	ON_BN_CLICKED(IDC_RADIO_USE_HOLE_NO, OnRadioUseHoleNo)
	ON_BN_CLICKED(IDC_RADIO_USE_HOLE_PRE, OnRadioUseHolePre)
	ON_BN_CLICKED(IDC_RADIO_USE_HOLE_POST, OnRadioUseHolePost)
	ON_BN_CLICKED(IDC_CHECK_TURN, OnBnClickedCheckTurn)
	//}}AFX_MSG_MAP
	
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenLayoutEasy diagnostics

#ifdef _DEBUG
void CPaneRecipeGenLayoutEasy::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneRecipeGenLayoutEasy::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenLayoutEasy message handlers

void CPaneRecipeGenLayoutEasy::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitStaticControl(); 
	InitEditControl();

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 1)
	{
//		GetDlgItem(IDC_STATIC_THICKNESS)->EnableWindow(FALSE);
//		m_edtPCBThickness.EnableWindow(FALSE);
		m_btnMeasuringThickness.EnableWindow(FALSE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 2)
	{
		GetDlgItem(IDC_STATIC_THICKNESS_2ND)->EnableWindow(FALSE);
		m_edtPCBThickness2nd.EnableWindow(FALSE);
	}
	
	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 0)
	{
		m_nUsePanel = USE_1ST;

		GetDlgItem(IDC_RADIO_USE_DUAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_USE_2ND)->EnableWindow(FALSE);
	}

#ifdef __PUSAN_OLD_17__
	GetDlgItem(IDC_STATIC_VACUUM_TYPE)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_RADIO_TABLE_VACUMM_A)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_RADIO_TABLE_VACUMM_B)->ShowWindow(SW_HIDE);
#endif
	
#ifdef __PUSAN_OLD_32__
	GetDlgItem(IDC_STATIC_VACUUM_TYPE)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_RADIO_TABLE_VACUMM_A)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_RADIO_TABLE_VACUMM_B)->ShowWindow(SW_HIDE);
#endif

#ifdef __PUSAN_LDD__
	GetDlgItem(IDC_STATIC_DUMMY_FREE_TYPE)->ShowWindow(SW_HIDE);
#endif
	
#ifdef __KUNSAN_8__
	GetDlgItem(IDC_STATIC_DUMMY_FREE_TYPE)->SetWindowText(_T("Dumper Shot Type"));
	GetDlgItem(IDC_RADIO_DUMMY_FREE_TYPE_1)->SetWindowText(_T("Default Dumper"));
	GetDlgItem(IDC_RADIO_DUMMY_FREE_TYPE_2)->SetWindowText(_T("Power-via Dumper"));
#endif

#ifndef __KUNSAN_SAMSUNG_LARGE__
	GetDlgItem(IDC_RADIO_SCALE_AUTO)->EnableWindow(FALSE);
	GetDlgItem(IDC_RADIO_SCALE_MANUAL)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SCALE_MANUAL)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_SCALE_MANUAL)->ShowWindow(SW_HIDE);

	GetDlgItem(IDC_EDIT_MEAN_SCALE)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_SCALE_MANUAL)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_TOLERANCE)->EnableWindow(FALSE);
#else
	GetDlgItem(IDC_STATIC_DUMMY_FREE_TYPE)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_RADIO_DUMMY_FREE_TYPE_1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_RADIO_DUMMY_FREE_TYPE_2)->ShowWindow(SW_HIDE);

	GetDlgItem(IDC_STATIC_VACUUM_TYPE)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_RADIO_TABLE_VACUMM_A)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_RADIO_TABLE_VACUMM_B)->ShowWindow(SW_HIDE);

	//�̻���ϱ�� ����
	GetDlgItem(IDC_RADIO_SCALE_AUTO)->EnableWindow(FALSE);
	GetDlgItem(IDC_RADIO_SCALE_MANUAL)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATIC_SCALE_MANUAL)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_SCALE_MANUAL)->ShowWindow(SW_HIDE);

	GetDlgItem(IDC_EDIT_MEAN_SCALE)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_SCALE_MANUAL)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_TOLERANCE)->EnableWindow(FALSE);
	
#endif
}

BOOL CPaneRecipeGenLayoutEasy::PreCreateWindow(CREATESTRUCT& cs) 
{
	BOOL bResult = CFormView::PreCreateWindow(cs);

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;

	return (bResult);	
}

void CPaneRecipeGenLayoutEasy::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(100, "Arial Bold");

	// Scale Option
	GetDlgItem(IDC_RADIO_SCALE_AUTO)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_SCALE_MANUAL)->SetFont( &m_fntBtn );

	// Type of zero
	GetDlgItem(IDC_RADIO_TZS)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_LTZ)->SetFont( &m_fntBtn );

	// Coordination type
	GetDlgItem(IDC_RADIO_ABS)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_INC)->SetFont( &m_fntBtn );

	// Input Unit
	GetDlgItem(IDC_RADIO_1UM)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_10UM)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_100UM)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_1MM)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_1INCH)->SetFont( &m_fntBtn );

	// Measuring Thickness
	m_btnMeasuringThickness.SetFont( &m_fntBtn );
	m_btnMeasuringThickness.SetFlat( FALSE );
	m_btnMeasuringThickness.EnableBallonToolTip();
	m_btnMeasuringThickness.SetToolTipText( _T("Measuring PCB Thickness") );
	m_btnMeasuringThickness.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMeasuringThickness.SetBtnCursor(IDC_HAND_1);

	m_fntBtn2.CreateFont(20, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDC_RADIO_USE_DUAL)->SetFont(&m_fntBtn2);
	GetDlgItem(IDC_RADIO_USE_1ST)->SetFont(&m_fntBtn2);
	GetDlgItem(IDC_RADIO_USE_2ND)->SetFont(&m_fntBtn2);

	GetDlgItem(IDC_RADIO_TABLE_VACUMM_A)->SetFont(&m_fntBtn2);
	GetDlgItem(IDC_RADIO_TABLE_VACUMM_B)->SetFont(&m_fntBtn2);
	GetDlgItem(IDC_RADIO_TABLE_VACUMM_C)->SetFont(&m_fntBtn2);
	GetDlgItem(IDC_RADIO_TABLE_VACUMM_D)->SetFont(&m_fntBtn2);

	GetDlgItem(IDC_RADIO_DUMMY_FREE_TYPE_1)->SetFont(&m_fntBtn2);
	GetDlgItem(IDC_RADIO_DUMMY_FREE_TYPE_2)->SetFont(&m_fntBtn2);
#ifdef __PUSAN_LDD__
	GetDlgItem(IDC_RADIO_DUMMY_FREE_TYPE_1)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_RADIO_DUMMY_FREE_TYPE_2)->ShowWindow(SW_HIDE);
#endif

	GetDlgItem(IDC_RADIO_USE_HOLE_NO)->SetFont(&m_fntBtn2);
	GetDlgItem(IDC_RADIO_USE_HOLE_PRE)->SetFont(&m_fntBtn2);
	GetDlgItem(IDC_RADIO_USE_HOLE_POST)->SetFont(&m_fntBtn2);


	// Cu direct
	m_chkUseCuDirect.SetFont( &m_fntBtn );
	m_chkUseCuDirect.SetImageOrg( 10, 3 );
	m_chkUseCuDirect.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseCuDirect.EnableBallonToolTip();
	m_chkUseCuDirect.SetToolTipText( _T("Use Dumper") );
	m_chkUseCuDirect.SetBtnCursor(IDC_HAND_1);
	m_chkUseCuDirect.EnableWindow(TRUE);


	// Turn
	m_chkTurn.SetFont( &m_fntBtn );
	m_chkTurn.SetImageOrg( 10, 3 );
	m_chkTurn.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkTurn.EnableBallonToolTip();
	m_chkTurn.SetToolTipText( _T("Turn panel") );
	m_chkTurn.SetBtnCursor(IDC_HAND_1);
	m_chkTurn.EnableWindow(TRUE);
#ifndef __KUNSAN_SAMSUNG_LARGE__
	m_chkTurn.ShowWindow(SW_HIDE);
#endif

}

void CPaneRecipeGenLayoutEasy::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(100, "Arial Bold");

	// Axis Setting
	GetDlgItem(IDC_STATIC_AXIS_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_X_RANGE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_Y_RANGE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FIELD_SIZE_X_AXIS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FIELD_SIZE_Y_AXIS)->SetFont( &m_fntStatic );

	// Use Panel
	GetDlgItem(IDC_STATIC_USE_PANEL)->SetFont( &m_fntBtn );
	
	// Vacuum Type
	GetDlgItem(IDC_STATIC_VACUUM_TYPE)->SetFont( &m_fntBtn );

	// Dummy Free Type
	GetDlgItem(IDC_STATIC_DUMMY_FREE_TYPE)->SetFont( &m_fntBtn );
	
	// RefFidPosOffset
	GetDlgItem(IDC_STATIC_REF_FID_POS_OFFSET)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_REF_FID_OFFSET_X)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_REF_FID_OFFSET_Y)->SetFont( &m_fntBtn );
	
	// Scale Limit
	GetDlgItem(IDC_STATIC_SCALE_SETTING)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_SCALE_LIMIT1)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_SCALE_LIMIT2)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_SCALE_MANUAL)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_SCALE_LIMIT3)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_SCALE_LIMIT4)->SetFont( &m_fntBtn );

	GetDlgItem(IDC_STATIC_TOLERANCE)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_TOLERANCE2)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_MEAN_SCALE)->SetFont( &m_fntBtn );

	// PCB Thickness
	GetDlgItem(IDC_STATIC_PCB_THICKNESS)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_THICKNESS)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_THICKNESS_2ND)->SetFont( &m_fntBtn );

	// PCB Thickness2 : skiving offset
	GetDlgItem(IDC_STATIC_PCB_THICKNESS2)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_THICKNESS2)->SetFont( &m_fntBtn );

	// Type of zero
	GetDlgItem(IDC_STATIC_TYPE_OF_ZERO)->SetFont( &m_fntStatic );

	// Coordination type
	GetDlgItem(IDC_STATIC_COORDINATION_TYPE)->SetFont( &m_fntStatic );

	// Input unit
	GetDlgItem(IDC_STATIC_INPUT_UNIT)->SetFont( &m_fntStatic );

	// Scanner Field Size
	GetDlgItem(IDC_STATIC_SCANNER_FIELD_SIZE)->SetFont( &m_fntStatic );

	// Text Marking Range
	GetDlgItem(IDC_STATIC_TEXT_RANGE_X)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_TEXT_RANGE_Y)->SetFont( &m_fntBtn );

	// Hole Find
	GetDlgItem(IDC_STATIC_USE_HOLE_FIND)->SetFont( &m_fntStatic);

	//turn 
	GetDlgItem(IDC_STATIC_TRUN)->SetFont( &m_fntStatic);
#ifndef __KUNSAN_SAMSUNG_LARGE__
	GetDlgItem(IDC_STATIC_TRUN)->ShowWindow(SW_HIDE);
#endif

	CString str;
	str.Format(_T("X : %.1f mm"), gSystemINI.m_sSystemDevice.dFieldSize.x);
	m_stcFieldX.SetFont( &m_fntStatic );
	m_stcFieldX.SetForeColor( VALUE_FORE_COLOR );
	m_stcFieldX.SetBackColor( VALUE_BACK_COLOR );
	m_stcFieldX.SetWindowText(str );

	str.Format(_T("Y : %.1f mm"), gSystemINI.m_sSystemDevice.dFieldSize.y);
	m_stcFieldY.SetFont( &m_fntStatic );
	m_stcFieldY.SetForeColor( VALUE_FORE_COLOR );
	m_stcFieldY.SetBackColor( VALUE_BACK_COLOR );
	m_stcFieldY.SetWindowText( str );
}

void CPaneRecipeGenLayoutEasy::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(100, "Arial Bold");

	m_edtFieldSizeXAxis.SetFont( &m_fntEdit );
	m_edtFieldSizeXAxis.SetForeColor( BLACK_COLOR );
	m_edtFieldSizeXAxis.SetBackColor( WHITE_COLOR );
	m_edtFieldSizeXAxis.SetReceivedFlag( 1 ); // int-Point
	m_edtFieldSizeXAxis.SetWindowText( _T("0") );

	m_edtFieldSizeYAxis.SetFont( &m_fntEdit );
	m_edtFieldSizeYAxis.SetForeColor( BLACK_COLOR );
	m_edtFieldSizeYAxis.SetBackColor( WHITE_COLOR );
	m_edtFieldSizeYAxis.SetReceivedFlag( 1 ); // int-Point
	m_edtFieldSizeYAxis.SetWindowText( _T("0") );

	m_edtXAxisTextRange.SetFont( &m_fntEdit );
	m_edtXAxisTextRange.SetForeColor( BLACK_COLOR );
	m_edtXAxisTextRange.SetBackColor( WHITE_COLOR );
	m_edtXAxisTextRange.SetReceivedFlag( 1 ); // int-Point
	m_edtXAxisTextRange.SetWindowText( _T("0") );
	
	m_edtYAxisTextRange.SetFont( &m_fntEdit );
	m_edtYAxisTextRange.SetForeColor( BLACK_COLOR );
	m_edtYAxisTextRange.SetBackColor( WHITE_COLOR );
	m_edtYAxisTextRange.SetReceivedFlag( 1 ); // int-Point
	m_edtYAxisTextRange.SetWindowText( _T("0") ); 

	m_edtXAxisRange.SetFont( &m_fntEdit );
	m_edtXAxisRange.SetForeColor( BLACK_COLOR );
	m_edtXAxisRange.SetBackColor( WHITE_COLOR );
	m_edtXAxisRange.SetReceivedFlag( 1 ); // int-Point
	m_edtXAxisRange.SetWindowText( _T("0") );

	m_edtYAxisRange.SetFont( &m_fntEdit );
	m_edtYAxisRange.SetForeColor( BLACK_COLOR );
	m_edtYAxisRange.SetBackColor( WHITE_COLOR );
	m_edtYAxisRange.SetReceivedFlag( 1 ); // int-Point
	m_edtYAxisRange.SetWindowText( _T("0") );

	m_edtPCBThickness.SetFont( &m_fntEdit );
	m_edtPCBThickness.SetForeColor( BLACK_COLOR );
	m_edtPCBThickness.SetBackColor( WHITE_COLOR );
	m_edtPCBThickness.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPCBThickness.SetWindowText( _T("0.0") );

	m_edtPCBThickness2nd.SetFont( &m_fntEdit );
	m_edtPCBThickness2nd.SetForeColor( BLACK_COLOR );
	m_edtPCBThickness2nd.SetBackColor( WHITE_COLOR );
	m_edtPCBThickness2nd.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPCBThickness2nd.SetWindowText( _T("0.0") );

	m_edtPCBThicknessOffset.SetFont( &m_fntEdit );
	m_edtPCBThicknessOffset.SetForeColor( BLACK_COLOR );
	m_edtPCBThicknessOffset.SetBackColor( WHITE_COLOR );
	m_edtPCBThicknessOffset.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPCBThicknessOffset.SetWindowText( _T("0.0") );

	m_edtScaleLimit1.SetFont( &m_fntEdit );
	m_edtScaleLimit1.SetForeColor( BLACK_COLOR );
	m_edtScaleLimit1.SetBackColor( WHITE_COLOR );
	m_edtScaleLimit1.SetReceivedFlag( 3 ); // Floating-Point
	m_edtScaleLimit1.SetWindowText( _T("100.0") );

	m_edtScaleLimit2.SetFont( &m_fntEdit );
	m_edtScaleLimit2.SetForeColor( BLACK_COLOR );
	m_edtScaleLimit2.SetBackColor( WHITE_COLOR );
	m_edtScaleLimit2.SetReceivedFlag( 3 ); // Floating-Point
	m_edtScaleLimit2.SetWindowText( _T("100.0") );

	m_edtScaleManual.SetFont( &m_fntEdit );
	m_edtScaleManual.SetForeColor( BLACK_COLOR );
	m_edtScaleManual.SetBackColor( WHITE_COLOR );
	m_edtScaleManual.SetReceivedFlag( 3 ); // Floating-Point
	m_edtScaleManual.SetWindowText( _T("100.0") );

	m_edtScaleLimit1Minus.SetFont( &m_fntEdit );
	m_edtScaleLimit1Minus.SetForeColor( BLACK_COLOR );
	m_edtScaleLimit1Minus.SetBackColor( WHITE_COLOR );
	m_edtScaleLimit1Minus.SetReceivedFlag( 3 ); // Floating-Point
	m_edtScaleLimit1Minus.SetWindowText( _T("100.0") );
	
	m_edtScaleLimit2Minus.SetFont( &m_fntEdit );
	m_edtScaleLimit2Minus.SetForeColor( BLACK_COLOR );
	m_edtScaleLimit2Minus.SetBackColor( WHITE_COLOR );
	m_edtScaleLimit2Minus.SetReceivedFlag( 3 ); // Floating-Point
	m_edtScaleLimit2Minus.SetWindowText( _T("100.0") );

	m_edtRefFidOffsetX.SetFont( &m_fntEdit );
	m_edtRefFidOffsetX.SetForeColor( BLACK_COLOR );
	m_edtRefFidOffsetX.SetBackColor( WHITE_COLOR );
	m_edtRefFidOffsetX.SetReceivedFlag( 3 ); // Floating-Point
	m_edtRefFidOffsetX.SetWindowText( _T("0.0") );

	m_edtRefFidOffsetY.SetFont( &m_fntEdit );
	m_edtRefFidOffsetY.SetForeColor( BLACK_COLOR );
	m_edtRefFidOffsetY.SetBackColor( WHITE_COLOR );
	m_edtRefFidOffsetY.SetReceivedFlag( 3 ); // Floating-Point
	m_edtRefFidOffsetY.SetWindowText( _T("0.0") );

	m_edtScaleTolerance1.SetFont( &m_fntEdit );
	m_edtScaleTolerance1.SetForeColor( BLACK_COLOR );
	m_edtScaleTolerance1.SetBackColor( WHITE_COLOR );
	m_edtScaleTolerance1.SetReceivedFlag( 3 ); // Floating-Point
	m_edtScaleTolerance1.SetWindowText( _T("0.02") );

	m_edtScaleTolerance2.SetFont( &m_fntEdit );
	m_edtScaleTolerance2.SetForeColor( BLACK_COLOR );
	m_edtScaleTolerance2.SetBackColor( WHITE_COLOR );
	m_edtScaleTolerance2.SetReceivedFlag( 3 ); // Floating-Point
	m_edtScaleTolerance2.SetWindowText( _T("0.02") );

	m_edtMeanScale.SetFont( &m_fntEdit );
	m_edtMeanScale.SetForeColor( BLACK_COLOR );
	m_edtMeanScale.SetBackColor( WHITE_COLOR );
	m_edtMeanScale.SetReceivedFlag( 3 ); // Floating-Point
	m_edtMeanScale.SetWindowText( _T("100.0") );
}

HBRUSH CPaneRecipeGenLayoutEasy::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	

	// TODO: Change any attributes of the DC here
	if( CTLCOLOR_STATIC == nCtlColor )
	{
		if( GetDlgItem(IDC_STATIC_TYPE_OF_ZERO)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_AXIS_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_COORDINATION_TYPE)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_INPUT_UNIT)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_USE_PANEL)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_VACUUM_TYPE)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_DUMMY_FREE_TYPE)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_SCALE_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_PCB_THICKNESS)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_SCANNER_FIELD_SIZE)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_PCB_THICKNESS2)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_REF_FID_POS_OFFSET)->GetSafeHwnd() == pWnd->m_hWnd || 
			GetDlgItem(IDC_STATIC_USE_HOLE_FIND)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_TRUN)->GetSafeHwnd() == pWnd->m_hWnd)
			pDC->SetTextColor( RGB(0, 0, 255) );
	}
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneRecipeGenLayoutEasy::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntBtn2.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();

	CFormView::OnDestroy();
}

BOOL CPaneRecipeGenLayoutEasy::GetData(DProject &tempDProject)
{
	UpdateData(TRUE);
	CString str;
	double dTempVal, dTempVal2;

	m_edtScaleTolerance1.GetWindowText(str);
	dTempVal2 = atof(str);

	if(dTempVal2 < 0 || dTempVal2 >1)
	{
		m_edtScaleLimit1.SetFocus();

		ErrMessage(_T("ScaleTolerance1 Setting Error"));
		return FALSE;
	}
	tempDProject.m_dScaleTolerance1 = dTempVal2;

	m_edtScaleTolerance2.GetWindowText(str);
	dTempVal2 = atof(str);
	if(dTempVal2 < 0 || dTempVal2 >1)
	{
		m_edtScaleLimit2.SetFocus();

		ErrMessage(_T("ScaleTolerance2 Setting Error"));
		return FALSE;
	}
	tempDProject.m_dScaleTolerance2 = dTempVal2;

	m_edtMeanScale.GetWindowText(str);
	dTempVal2 = atof(str);
	if(dTempVal2 < 90 || dTempVal2 >110)
	{
		m_edtMeanScale.SetFocus();

		ErrMessage(_T("Mean Scale Setting Error"));
		return FALSE;
	}
	tempDProject.m_dMeanScale = dTempVal2;
/*
	m_edtScaleLimit1.GetWindowText(str);
	dTempVal = atof(str);

	m_edtScaleLimit2.GetWindowText(str);
	dTempVal2 = atof(str);
	if(dTempVal > 105 || dTempVal < 100 || dTempVal > dTempVal2)
	{
		m_edtScaleLimit1.SetFocus();

		ErrMessage(_T("ScaleLimit (+) 1 Error"));
		return FALSE;
	}
	tempDProject.m_dScaleLimit1 = (double)dTempVal;

	if(dTempVal > 105 || dTempVal < 100 || dTempVal2 < dTempVal)
	{
		m_edtScaleLimit2.SetFocus();
		
		ErrMessage(_T("ScaleLimit (+) 2 Error"));
		return FALSE;
	}
	tempDProject.m_dScaleLimit2 = (double)dTempVal;

	m_edtScaleLimit1Minus.GetWindowText(str);
	dTempVal = atof(str);
	m_edtScaleLimit2Minus.GetWindowText(str);
	dTempVal2 = atof(str);
	
	if(dTempVal > 100 || dTempVal < 95 || dTempVal < dTempVal2)
	{
		m_edtScaleLimit1Minus.SetFocus();
		
		ErrMessage(_T("ScaleLimit (-) 1 Error"));
		return FALSE;
	}
	tempDProject.m_dScaleLimit1Minus = (double)dTempVal;
	
	if(dTempVal > 100 || dTempVal < 95 || dTempVal2 > dTempVal)
	{
		m_edtScaleLimit2Minus.SetFocus();
		
		ErrMessage(_T("ScaleLimit (-) 2 Error"));
		return FALSE;
	}
	tempDProject.m_dScaleLimit2Minus = (double)dTempVal;
*/
	m_edtScaleManual.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > 110 || dTempVal < 90)
	{
		m_edtScaleManual.SetFocus();
		
		ErrMessage(_T("Manual Scale Target Error"));
		return FALSE;
	}
	tempDProject.m_dScaleManual = (double)dTempVal;
	
	m_edtRefFidOffsetX.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > 200 || dTempVal < -200)
	{
		m_edtRefFidOffsetX.SetFocus();

		ErrMessage(_T("Reference Fiducial Position offset X Error"));
		return FALSE;
	}
	tempDProject.m_dRefFidOffsetX = (double)dTempVal;

	m_edtRefFidOffsetY.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > 200 || dTempVal < -200)
	{
		m_edtRefFidOffsetY.SetFocus();
		
		ErrMessage(_T("Reference Fiducial Position offset Y Error"));
		return FALSE;
	}
	tempDProject.m_dRefFidOffsetY = (double)dTempVal;

	m_edtXAxisRange.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_X_TABLE || dTempVal <= MIN_X_TABLE) // ��ȿ�� ����
	{
		m_edtXAxisRange.SetFocus();

		CString strString, strMsg;
		strString.LoadString(IDS_ERR_OUT_OF_AXIS);
		strMsg.Format(strString, "X");
		ErrMessage(strMsg);
		
		return FALSE;
	}
	tempDProject.m_nRangeXDisp =(int)dTempVal;

	m_edtYAxisRange.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal > MAX_Y_TABLE || dTempVal <= MIN_Y_TABLE) // ��ȿ�� ����
	{
		m_edtYAxisRange.SetFocus();

		CString strString, strMsg;
		strString.LoadString(IDS_ERR_OUT_OF_AXIS);
		strMsg.Format(strString, "Y");
		ErrMessage(strMsg);
		
		return FALSE;
	}
	tempDProject.m_nRangeYDisp =(int)dTempVal;

	m_edtFieldSizeXAxis.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal <= 0  || dTempVal > gSystemINI.m_sSystemDevice.dFieldSize.x -1) // ��ȿ�� ����
	{
		m_edtFieldSizeXAxis.SetFocus();

		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FIELD_SIZE);
		strMsg.Format(strString, "X");
		ErrMessage(strMsg);

		return FALSE;
	}
	tempDProject.m_nDivRangeXDisp =(int)(dTempVal);
	AfxGetApp()->WriteProfileInt(_T("Settings"), _T("DivRangeX"), tempDProject.m_nDivRangeXDisp);

	m_edtFieldSizeYAxis.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal <= 0 || dTempVal > gSystemINI.m_sSystemDevice.dFieldSize.y -1) // ��ȿ�� ����
	{
		m_edtFieldSizeYAxis.SetFocus();

		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FIELD_SIZE);
		strMsg.Format(strString, "Y");
		ErrMessage(strMsg);

		return FALSE;
	}
	tempDProject.m_nDivRangeYDisp =(int)(dTempVal);
	AfxGetApp()->WriteProfileInt(_T("Settings"), _T("DivRangeY"), tempDProject.m_nDivRangeYDisp);

	m_edtXAxisTextRange.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal <= 0 || dTempVal > gSystemINI.m_sSystemDevice.dFieldSize.y -1) // ��ȿ�� ����
	{
		m_edtXAxisTextRange.SetFocus();
		
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FIELD_SIZE);
		strMsg.Format(strString, "X");
		ErrMessage(strMsg);
		
		return FALSE;
	}
	tempDProject.m_nTextRangeXDisp =(int)(dTempVal);
	
	m_edtYAxisTextRange.GetWindowText(str);
	dTempVal = atof(str);
	if(dTempVal <= 0 || dTempVal > gSystemINI.m_sSystemDevice.dFieldSize.y -1) // ��ȿ�� ����
	{
		m_edtYAxisTextRange.SetFocus();
		
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FIELD_SIZE);
		strMsg.Format(strString, "Y");
		ErrMessage(strMsg);
		
		return FALSE;
	}
	tempDProject.m_nTextRangeYDisp =(int)(dTempVal);


	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() > 0)
	{
		m_edtPCBThickness.GetWindowText(str);
		if(atof(str) > gProcessINI.m_sProcessOption.d1stPCBHeightMax || atof(str) <= gProcessINI.m_sProcessOption.d1stPCBHeightMin) // ��ȿ�� ����
		{
			m_edtPCBThickness.SetFocus();
			ErrMessage(IDS_PCB_THICKNESS);
			return FALSE;
		}
		tempDProject.m_dPcbThick = atof(str);

		m_edtPCBThicknessOffset.GetWindowText(str);
		if( tempDProject.m_dPcbThick + atof(str) > gProcessINI.m_sProcessOption.d1stPCBHeightMax || tempDProject.m_dPcbThick + atof(str) <= gProcessINI.m_sProcessOption.d1stPCBHeightMin) // ��ȿ�� ����
		{
			m_edtPCBThicknessOffset.SetFocus();
			ErrMessage(IDS_PCB_THICKNESS);
			return FALSE;
		}
	}

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() > 1)
	{
		m_edtPCBThickness2nd.GetWindowText(str);
		if(atof(str) > gProcessINI.m_sProcessOption.d2ndPCBHeightMax || atof(str) <= gProcessINI.m_sProcessOption.d2ndPCBHeightMin) // ��ȿ�� ����
		{
			m_edtPCBThickness2nd.SetFocus();
			ErrMessage(IDS_PCB_THICKNESS);
			return FALSE;
		}
		tempDProject.m_dPcbThick2 = atof(str);

		m_edtPCBThicknessOffset.GetWindowText(str);
		if( tempDProject.m_dPcbThick2 + atof(str) > gProcessINI.m_sProcessOption.d1stPCBHeightMax || tempDProject.m_dPcbThick2 + atof(str) <= gProcessINI.m_sProcessOption.d1stPCBHeightMin) // ��ȿ�� ����
		{
			m_edtPCBThicknessOffset.SetFocus();
			ErrMessage(IDS_PCB_THICKNESS);
			return FALSE;
		}
	}
	else
		tempDProject.m_dPcbThick2 = tempDProject.m_dPcbThick;

	m_edtPCBThicknessOffset.GetWindowText(str);
	tempDProject.m_dSkivingThickOffset = atof(str);

	tempDProject.m_nScaleMode = (short)m_nScaleMode;
	
//	tempDProject.m_nABS = (short)m_nCoordType;
//	tempDProject.m_nTZS = (short)m_nTypeOfZero;
//	tempDProject.m_nInputUnit = (short)m_nInputUnit;

	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 0)
		m_nUsePanel = USE_1ST;

	tempDProject.m_nSeparation = m_nUsePanel;

	tempDProject.m_nVacuumType = m_nVacuumType;

	tempDProject.m_nDummyFreeType = m_nDummyFreeType;

	tempDProject.m_bUseCuDirect = m_chkUseCuDirect.GetCheck();
	tempDProject.m_nHoleFind = m_nFindHole;
	
	tempDProject.m_bUseTurn = m_bTurn;
	return TRUE;
}

BOOL CPaneRecipeGenLayoutEasy::SetData()
{
	CString str;

	str.Format(_T("%.3f"), gDProject.m_dScaleTolerance1);
	m_edtScaleTolerance1.SetWindowText(str);

	str.Format(_T("%.3f"), gDProject.m_dScaleTolerance2);
	m_edtScaleTolerance2.SetWindowText(str);

	str.Format(_T("%.3f"), gDProject.m_dMeanScale);
	m_edtMeanScale.SetWindowText(str);

/*	str.Format(_T("%.3f"), gDProject.m_dScaleLimit1);
	m_edtScaleLimit1.SetWindowText(str);

	str.Format(_T("%.3f"), gDProject.m_dScaleLimit2);
	m_edtScaleLimit2.SetWindowText(str);

	str.Format(_T("%.3f"), gDProject.m_dScaleLimit1Minus);
	m_edtScaleLimit1Minus.SetWindowText(str);
	
	str.Format(_T("%.3f"), gDProject.m_dScaleLimit2Minus);
	m_edtScaleLimit2Minus.SetWindowText(str);
	*/
	str.Format(_T("%.3f"), gDProject.m_dScaleManual);
	m_edtScaleManual.SetWindowText(str);

	str.Format(_T("%.3f"), gDProject.m_dRefFidOffsetX);
	m_edtRefFidOffsetX.SetWindowText(str);

	str.Format(_T("%.3f"), gDProject.m_dRefFidOffsetY);
	m_edtRefFidOffsetY.SetWindowText(str);

	str.Format(_T("%d"),gDProject.m_nRangeXDisp);
	m_edtXAxisRange.SetWindowText(str);

	str.Format(_T("%d"),gDProject.m_nRangeYDisp);
	m_edtYAxisRange.SetWindowText(str);

	str.Format(_T("%d"),gDProject.m_nDivRangeXDisp);
	m_edtFieldSizeXAxis.SetWindowText(str);

	str.Format(_T("%d"),gDProject.m_nDivRangeYDisp);
	m_edtFieldSizeYAxis.SetWindowText(str);

	str.Format(_T("%d"),gDProject.m_nTextRangeXDisp);
	m_edtXAxisTextRange.SetWindowText(str);
	
	str.Format(_T("%d"),gDProject.m_nTextRangeYDisp);
	m_edtYAxisTextRange.SetWindowText(str);

	str.Format(_T("%.3f"), gDProject.m_dPcbThick);
	m_edtPCBThickness.SetWindowText(str);

	str.Format(_T("%.3f"), gDProject.m_dPcbThick2);
	m_edtPCBThickness2nd.SetWindowText(str);

	str.Format(_T("%.3f"), gDProject.m_dSkivingThickOffset);
	m_edtPCBThicknessOffset.SetWindowText(str);

	str.Format(_T("X : %.1f mm"), gSystemINI.m_sSystemDevice.dFieldSize.x);
	m_stcFieldX.SetWindowText(str );
	
	str.Format(_T("Y : %.1f mm"), gSystemINI.m_sSystemDevice.dFieldSize.y);
	m_stcFieldY.SetWindowText( str );

	m_nScaleMode	= (int)gDProject.m_nScaleMode;

	if(m_nScaleMode == 0)
		OnRadioScaleAuto();
	else
		OnRadioScaleManual();
	
//	m_nCoordType	= (int)gDProject.m_nABS;
//	m_nTypeOfZero	= (int)gDProject.m_nTZS;
//	m_nInputUnit	= (int)gDProject.m_nInputUnit;

	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 0)
		gDProject.m_nSeparation = USE_1ST;

	m_nUsePanel = gDProject.m_nSeparation;

	m_nVacuumType = gDProject.m_nVacuumType;

	m_nDummyFreeType = gDProject.m_nDummyFreeType;
	
	m_nFindHole = gDProject.m_nHoleFind;


	m_chkUseCuDirect.SetCheck(gDProject.m_bUseCuDirect);
	m_bTurn = gDProject.m_bUseTurn;
	m_chkTurn.SetCheck(gDProject.m_bUseTurn);
	UpdateData(FALSE);
	return TRUE;
}

void CPaneRecipeGenLayoutEasy::OnButtonMeasuringThickness() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 1)
	{
		ErrMessage(IDS_NO_HEIGHTSENSOR1);
		return;
	}
	
	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 2 &&
		m_nUsePanel == USE_2ND)
	{
		ErrMessage(IDS_NO_HEIGHTSENSOR2);
		return;
	}

	CDlgMeasuringPCBThickness dlg;
	
	dlg.SetBaseZ( gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dBaseZ,
		gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dBaseZ);
	
	if(m_nUsePanel != USE_2ND || gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() <= 1)
	{
		dlg.SetPosition( gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dAutoX,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dAutoY,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dHeadZ,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dHeadZ);
		if(m_nUsePanel == USE_DUAL)
		{
			dlg.AutoSelectHead(0);
			dlg.SelectHead(0);
		}
		else
		{
			dlg.AutoSelectHead(1);
			dlg.SelectHead(1);
		}
	}
	else
	{
		dlg.SetPosition( gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dAutoX,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dAutoY,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dHeadZ,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dHeadZ);
		dlg.AutoSelectHead(2);
		dlg.SelectHead(2);
	}
	dlg.ChangeHeadSelectStatus(FALSE);

	if(IDOK != dlg.DoModal())
	{
		return;
	}
	m_bThicknessOK = TRUE;
	double dThickness;
	CString strData;

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() > 1 && 
		m_nUsePanel == USE_2ND)
	{
		dThickness = dlg.GetHeight(FALSE);
		
		strData.Format(_T("%.3f"), dThickness);
		m_edtPCBThickness.SetWindowText( (LPCTSTR)strData );
		m_edtPCBThickness2nd.SetWindowText( (LPCTSTR)strData );
		
		if( dThickness <=0. )
		{
			ErrMsgDlg(STDGNALM702);
		}
	}
	else if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() > 1 && 
			m_nUsePanel == USE_DUAL)
	{
		dThickness = dlg.GetHeight();
		strData.Format(_T("%.3f"), dThickness);
		m_edtPCBThickness.SetWindowText( (LPCTSTR)strData );
		if( dThickness <=0. )
		{
			ErrMsgDlg(STDGNALM702);
		}

		dThickness = dlg.GetHeight(FALSE);
		strData.Format(_T("%.3f"), dThickness);
		m_edtPCBThickness2nd.SetWindowText( (LPCTSTR)strData );
		if( dThickness <=0. )
		{
			ErrMsgDlg(STDGNALM702);
		}
	}
	else
	{
		dThickness = dlg.GetHeight();
		
		strData.Format(_T("%.3f"), dThickness);
		m_edtPCBThickness.SetWindowText( (LPCTSTR)strData );
		m_edtPCBThickness2nd.SetWindowText( (LPCTSTR)strData );

		if( dThickness <=0. )
		{
			ErrMsgDlg(STDGNALM702);
		}
	}
}

void CPaneRecipeGenLayoutEasy::EnableControl(BOOL bUse)
{
	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() != 0)
	{
//		GetDlgItem(IDC_RADIO_USE_DUAL)->EnableWindow(bUse);
//		GetDlgItem(IDC_RADIO_USE_1ST)->EnableWindow(bUse);
//		GetDlgItem(IDC_RADIO_USE_2ND)->EnableWindow(bUse);
	}

	GetDlgItem(IDC_RADIO_SCALE_AUTO)->EnableWindow(bUse);
	GetDlgItem(IDC_RADIO_SCALE_MANUAL)->EnableWindow(bUse);

	GetDlgItem(IDC_RADIO_USE_HOLE_NO)->EnableWindow(bUse);
	GetDlgItem(IDC_RADIO_USE_HOLE_PRE)->EnableWindow(bUse);
	GetDlgItem(IDC_RADIO_USE_HOLE_POST)->EnableWindow(bUse);

	m_edtScaleManual.EnableWindow(bUse);
	
	m_edtXAxisRange.EnableWindow(bUse);
	m_edtYAxisRange.EnableWindow(bUse);

	m_edtScaleLimit1.EnableWindow(bUse);
	m_edtScaleLimit2.EnableWindow(bUse);
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(bUse)
	{
		if(m_nUserLevel >= 2)
			m_edtScaleManual.EnableWindow(bUse);
	}
	else
		m_edtScaleManual.EnableWindow(bUse);

	if(m_nUserLevel == 0)
	{
		GetDlgItem(IDC_RADIO_USE_DUAL)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_USE_1ST)->EnableWindow(FALSE);
		GetDlgItem(IDC_RADIO_USE_2ND)->EnableWindow(FALSE);
		m_edtScaleTolerance2.EnableWindow(FALSE);
		
		m_edtFieldSizeYAxis.EnableWindow(FALSE);
		m_edtFieldSizeXAxis.EnableWindow(FALSE);
		m_edtXAxisTextRange.EnableWindow(FALSE);
		m_edtYAxisTextRange.EnableWindow(FALSE);
	}
	else
	{
		GetDlgItem(IDC_RADIO_USE_DUAL)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_USE_1ST)->EnableWindow(TRUE);
		GetDlgItem(IDC_RADIO_USE_2ND)->EnableWindow(TRUE);
		m_edtScaleTolerance2.EnableWindow(TRUE);
		m_edtXAxisTextRange.EnableWindow(TRUE);
		m_edtYAxisTextRange.EnableWindow(TRUE);
		m_edtFieldSizeXAxis.EnableWindow(TRUE);
		m_edtFieldSizeYAxis.EnableWindow(TRUE);
	}
#else
	m_edtScaleManual.EnableWindow(bUse);
#endif
	m_edtScaleManual.EnableWindow(bUse);
	m_edtScaleLimit1Minus.EnableWindow(bUse);
	m_edtScaleLimit2Minus.EnableWindow(bUse);
#if defined (__KUNSAN_2013__) || defined (__KUNSAN_2012__) || defined (__KUNSAN_1__) || defined (__KUNSAN_8__) || defined (__KUNSAN_6__)
	m_edtScaleTolerance2.EnableWindow(bUse);
#endif
}

void CPaneRecipeGenLayoutEasy::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;
	switch(nLevel)
	{
	case 0: // Operator
		EnableControl(FALSE);
		break;
	case 1: // Engineer
	case 2: // EO Engineer
	case 3: // Super Engineer
		EnableControl(TRUE);
		break;
	}
}

void CPaneRecipeGenLayoutEasy::EnableSkivingHeight(BOOL bEnable)
{
	if(!bEnable)
	{
		m_edtPCBThicknessOffset.SetWindowText(_T("0.0"));
	}

	GetDlgItem(IDC_STATIC_THICKNESS2)->EnableWindow(bEnable);
	m_edtPCBThicknessOffset.EnableWindow(bEnable);
}

void CPaneRecipeGenLayoutEasy::OnCheckUseCudirect() 
{
	// TODO: Add your control notification handler code here
//	UpdateData(TRUE);
//	m_bUseCuDirect = m_chkUseCuDirect.GetCheck();
}

void CPaneRecipeGenLayoutEasy::OnRadioScaleAuto() 
{
	// TODO: Add your control notification handler code here
	m_edtScaleManual.EnableWindow(FALSE);

#ifdef __KUNSAN_SAMSUNG_LARGE__
	m_edtScaleTolerance1.EnableWindow(TRUE);
	if(m_nUserLevel == 0 )
		m_edtScaleTolerance2.EnableWindow(FALSE);
	else
		m_edtScaleTolerance2.EnableWindow(TRUE);

	m_edtMeanScale.EnableWindow(TRUE);
#endif

	
}

void CPaneRecipeGenLayoutEasy::OnRadioScaleManual() 
{
	// TODO: Add your control notification handler code here
	if(m_nUserLevel < 2)
		return;

	m_edtScaleManual.EnableWindow(TRUE);

	m_edtScaleTolerance1.EnableWindow(FALSE);
	if(m_nUserLevel == 0 )
		m_edtScaleTolerance2.EnableWindow(FALSE);
	else
		m_edtScaleTolerance2.EnableWindow(TRUE);
	m_edtMeanScale.EnableWindow(FALSE);
}

void CPaneRecipeGenLayoutEasy::OnRadioTableVacummA() 
{
	// TODO: Add your control notification handler code here
	m_nVacuumType = VACUUM_A;
	UpdateData(FALSE);
}

void CPaneRecipeGenLayoutEasy::OnRadioTableVacummB() 
{
	// TODO: Add your control notification handler code here
	m_nVacuumType = VACUUM_B;
	UpdateData(FALSE);
}

void CPaneRecipeGenLayoutEasy::OnRadioTableVacummC() 
{
	// TODO: Add your control notification handler code here
	m_nVacuumType = VACUUM_A;//VACUUM_C;
	UpdateData(FALSE);
}

void CPaneRecipeGenLayoutEasy::OnRadioDummyFreeType1() 
{
	// TODO: Add your control notification handler code here
	m_nDummyFreeType = DUMMY_FREE_1;
	UpdateData(FALSE);
}

void CPaneRecipeGenLayoutEasy::OnRadioDummyFreeType2() 
{
	// TODO: Add your control notification handler code here
	m_nDummyFreeType = DUMMY_FREE_2;
	UpdateData(FALSE);
}

void CPaneRecipeGenLayoutEasy::OnRadioUseHoleNo() 
{
	// TODO: Add your control notification handler code here
	m_nFindHole = NO_FIND;
	UpdateData(FALSE);
}

void CPaneRecipeGenLayoutEasy::OnRadioUseHolePre() 
{
	// TODO: Add your control notification handler code here
	m_nFindHole = PRE_FIND;
	UpdateData(FALSE);
}

void CPaneRecipeGenLayoutEasy::OnRadioUseHolePost() 
{
	// TODO: Add your control notification handler code here
	m_nFindHole = POST_FIND;
	UpdateData(FALSE);
}


BOOL CPaneRecipeGenLayoutEasy::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Recipe_Layout) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneRecipeGenLayoutEasy::OnBnClickedCheckTurn()
{
	m_bTurn = m_chkTurn.GetCheck();
}

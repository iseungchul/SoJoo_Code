// DUnit.cpp: implementation of the DUnit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DUnit.h"
#include "..\EasyDriller.h"
#include "math.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DUnit::DUnit()
{
	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;
	m_bSelect	= FALSE;
}

DUnit::~DUnit()
{
	ReMoveAllHoleData();
	ReMoveAllLineData();

	int* pIndex;
	POSITION pos = m_SubFidIndexData.GetHeadPosition();
	while (pos) 
	{
		pIndex = m_SubFidIndexData.GetNext(pos);
		delete pIndex;
	}
	m_SubFidIndexData.RemoveAll();
}

BOOL DUnit::SaveFile10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			if(nVersion < 10008)
			{
				ar << _T("SubIndexNo = ") << m_SubFidIndexData.GetCount() << _T("\n");
				POSITION pos;
				int* pIndex;
				pos = m_SubFidIndexData.GetHeadPosition();
				while (pos) 
				{
					pIndex = m_SubFidIndexData.GetNext(pos);
					ar << _T("= ") << *pIndex << _T("\n");
				}
			}

			ar << _T("MinX = ") << m_nMinX << _T("\n");
			ar << _T("MinY = ") << m_nMinY << _T("\n");
			ar << _T("MaxX = ") << m_nMaxX << _T("\n");
			ar << _T("MaxY = ") << m_nMaxY << _T("\n");

			ar << _T("HoleNo = ") << m_HoleData.GetCount() << _T("\n");
			LPHOLEDATA pOriHole;
			POSITION pos;
			pos = m_HoleData.GetHeadPosition();
			while (pos) 
			{
				pOriHole = m_HoleData.GetNext(pos);
				ar << _T("= ") << pOriHole->nToolNo << _T("\n");
				ar << _T("= ") << pOriHole->npPos.x << _T("\n");
				ar << _T("= ") << pOriHole->npPos.y << _T("\n");
				ar << _T("= ") << pOriHole->nUnitIndex << _T("\n");
				ar << _T("= ") << pOriHole->nRotate << _T("\n");	
				if(nVersion > 10007)
				{
					for(int m=0; m<4; m++)
					{
						for(int n=0; n<2; n++)
						{
							ar << _T("= ") << pOriHole->nFidIndex[m][n] << _T("\n");
						}
					}
				}
			}
			
			ar << _T("LineNo = ") << m_LineData.GetCount() << _T("\n");
			LPLINEDATA pOriginLine;
			pos = m_LineData.GetHeadPosition();
			while (pos) 
			{
				pOriginLine = m_LineData.GetNext(pos);
				ar << _T("= ") << pOriginLine->nToolNo << _T("\n");
				ar << _T("= ") << pOriginLine->npStartPos.x << _T("\n");
				ar << _T("= ") << pOriginLine->npStartPos.y << _T("\n");
				ar << _T("= ") << pOriginLine->npEndPos.x << _T("\n");
				ar << _T("= ") << pOriginLine->npEndPos.y << _T("\n");
				ar << _T("= ") << pOriginLine->nUnitIndex << _T("\n");

				if(nVersion > 10007)
				{
					for(int m=0; m<4; m++)
					{
						for(int n=0; n<2; n++)
						{
							ar << _T("= ") << pOriginLine->nFidIndex[m][n] << _T("\n");
						}
					}
				}
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL DUnit::LoadFile10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	int nCount;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code

			if(nVersion < 10002)
			{

			}
			else
			{
				if(nVersion < 10008)
				{
					ar >> nCount;
					int* pIndex;
					for(int i = 0; i < nCount; i++)
					{
						pIndex = new int;
						ar >> *pIndex;
						m_SubFidIndexData.AddTail(pIndex);
					}
				}

				ar >> m_nMinX; 
				ar >> m_nMinY;
				ar >> m_nMaxX;
				ar >> m_nMaxY;
			}

			ar >> nCount;
			LPHOLEDATA pOriHole;
			for(int i = 0; i < nCount; i++)
			{
				pOriHole = new HOLEDATA;
				ar >> pOriHole->nToolNo;
				ar >> pOriHole->npPos.x;
				ar >> pOriHole->npPos.y;
				ar >> pOriHole->nUnitIndex;
				if(nVersion >= 10015)
					ar >> pOriHole->nRotate;
				else
					pOriHole->nRotate = 0;

//				pOriHole->bSelect = FALSE;
				pOriHole->nRefNo = 1;

				if(nVersion > 10007)
				{
					for(int m=0; m<4; m++)
					{
						for(int n=0; n<2; n++)
						{
							ar >> pOriHole->nFidIndex[m][n];
						}
					}
				}
				m_HoleData.AddTail(pOriHole);
			}
			
			LPLINEDATA pOriLine; 
			ar >> nCount;
			for(int i = 0; i < nCount; i++)
			{
				pOriLine = new LINEDATA;
				ar >> pOriLine->nToolNo;
				ar >> pOriLine->npStartPos.x;
				ar >> pOriLine->npStartPos.y;
				ar >> pOriLine->npEndPos.x;
				ar >> pOriLine->npEndPos.y;
				ar >> pOriLine->nUnitIndex;		
//				pOriLine->bSelect = FALSE;
				pOriLine->nRefNo = 1;

				if(nVersion > 10007)
				{
					for(int m=0; m<4; m++)
					{
						for(int n=0; n<2; n++)
						{
							ar >> pOriLine->nFidIndex[m][n];
						}
					}
				}
				m_LineData.AddTail(pOriLine);
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL DUnit::SaveFileRect10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	TRY
	{
		if (ar.IsStoring())
		{	// storing code
			
			if(nVersion < 10008)
			{
				ar << _T("SubIndexNo = ") << m_SubFidIndexData.GetCount() << _T("\n");
				POSITION pos;
				int* pIndex;
				pos = m_SubFidIndexData.GetHeadPosition();
				while (pos) 
				{
					pIndex = m_SubFidIndexData.GetNext(pos);
					ar << _T("= ") << *pIndex << _T("\n");
				}
			}

			ar << _T("MinX = ") << m_nMinX << _T("\n");
			ar << _T("MinY = ") << m_nMinY << _T("\n");
			ar << _T("MaxX = ") << m_nMaxX << _T("\n");
			ar << _T("MaxY = ") << m_nMaxY << _T("\n");
			// ver 10002 end
			
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL DUnit::LoadFileRect10000(CArchiveMark &ar, int nVersion)
{
	CString str;
	int nCount;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code
			
			if(nVersion < 10002)
			{

			}
			else
			{
				if(nVersion < 10008)
				{
					ar >> nCount;
					int* pIndex;
					for(int i = 0; i < nCount; i++)
					{
						pIndex = new int;
						ar >> *pIndex;
						m_SubFidIndexData.AddTail(pIndex);
					}
				}

				ar >> m_nMinX; 
				ar >> m_nMinY;
				ar >> m_nMaxX;
				ar >> m_nMaxY;
			}

		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL DUnit::IsSelect(CPoint point, int nTolerence, CToolCodeList **pToolCodes, BOOL bSelectOnlyView)
{
	if(m_nMaxX < point.x) return FALSE;
	if(m_nMinX > point.x) return FALSE;
	if(m_nMaxY < point.y) return FALSE;
	if(m_nMinY > point.y) return FALSE;
	
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(!(*(pToolCodes + pHole->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pHole->bSelect)
			continue;
		
		if (point.x < pHole->npPos.x - nTolerence ||
			point.x > pHole->npPos.x + nTolerence ||
			point.y < pHole->npPos.y - nTolerence ||
			point.y > pHole->npPos.y + nTolerence)
			continue;
		else
		{
			return TRUE;
		}
	}
	
	int a, b, c;
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(!(*(pToolCodes + pLine->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pLine->bSelect)
			continue;
		
		if (point.x < min(pLine->npStartPos.x, pLine->npEndPos.x) - nTolerence ||
			point.x > max(pLine->npStartPos.x, pLine->npEndPos.x) + nTolerence ||
			point.y < min(pLine->npStartPos.y, pLine->npEndPos.y) - nTolerence ||
			point.y > max(pLine->npStartPos.y, pLine->npEndPos.y) + nTolerence)
			continue;
		
		a = pLine->npStartPos.y - pLine->npEndPos.y;
		b = pLine->npEndPos.x - pLine->npStartPos.x;
		c = pLine->npStartPos.x*pLine->npEndPos.y - pLine->npStartPos.y*pLine->npEndPos.x;
		
		if(pow((double)nTolerence, 2)*(pow((double)a, 2) + pow((double)b, 2)) >= pow((double)a*point.x + b*point.y + c, 2))
		{
			return TRUE;
		}
	}
	return FALSE;
}

BOOL DUnit::IsSelect(CPoint point1, CPoint point2, CToolCodeList **pToolCodes, BOOL bSelectOnlyView)
{
	if(m_nMaxX < point1.x) return FALSE;
	if(m_nMaxY < point1.y) return FALSE;
	
	if(m_nMinX > point2.x) return FALSE;
	if(m_nMinY > point2.y) return FALSE;

	BOOL bIn = FALSE;
	
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(!(*(pToolCodes + pHole->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pHole->bSelect)
			continue;

		bIn = TRUE;
		
		if (point1.x > pHole->npPos.x || pHole->npPos.x > point2.x ||
			point1.y > pHole->npPos.y || pHole->npPos.y > point2.y)
		{
			return FALSE;
		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(!(*(pToolCodes + pLine->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pLine->bSelect)
			continue;

		bIn = TRUE;
		
		if (point1.x > pLine->npStartPos.x || pLine->npStartPos.x > point2.x ||
			point1.y > pLine->npStartPos.y || pLine->npStartPos.y > point2.y ||
			point1.x > pLine->npEndPos.x || pLine->npEndPos.x > point2.x ||
			point1.y > pLine->npEndPos.y || pLine->npEndPos.y > point2.y)
		{
			return FALSE;
		}
	}
	if(bIn)
		return TRUE;
	else
		return FALSE;
}

void DUnit::UnSelectData()
{
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		pHole->bSelect = FALSE;
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		pLine->bSelect = FALSE;
	}
}

BOOL DUnit::IsAnySelectedData(CToolCodeList **pToolCodes, BOOL bSelectOnlyView)
{
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(!(*(pToolCodes + pHole->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pHole->bSelect)
			continue;
		
		if(pHole->bSelect)// && !bSelectionPlus) // bSelectionPlus�� ������� ������Ų�� (���� �ʿ��ϸ� �ּ� Ǯ��)
			return TRUE;
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(!(*(pToolCodes + pLine->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pLine->bSelect)
			continue;
		
		if(pLine->bSelect)// && !bSelectionPlus)
			return TRUE;
	}

	return FALSE;
}

BOOL DUnit::SelectData(CPoint point1, CPoint point2, CToolCodeList **pToolCodes, BOOL bSelectOnlyView)//, BOOL bSelectionPlus)
{
	if(m_nMaxX < point1.x) return FALSE;
	if(m_nMaxY < point1.y) return FALSE;
	
	if(m_nMinX > point2.x) return FALSE;
	if(m_nMinY > point2.y) return FALSE;
	
	BOOL bIn = FALSE;
	
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(!(*(pToolCodes + pHole->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pHole->bSelect)
			continue;
		
		bIn = TRUE;

		if(point1.x <= pHole->npPos.x && pHole->npPos.x <= point2.x &&
			point1.y <= pHole->npPos.y && pHole->npPos.y <= point2.y)
		{
			if(pHole->bSelect)// && !bSelectionPlus) // bSelectionPlus�� ������� ������Ų�� (���� �ʿ��ϸ� �ּ� Ǯ��)
				pHole->bSelect = FALSE;
			else
				pHole->bSelect = TRUE;
		}
//		else
//		{
//			if(!bSelectionPlus)
//				pHole->bSelect = FALSE;
//		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(!(*(pToolCodes + pLine->nToolNo))->m_bVisible) // visible �ƴϸ�
		{
			continue;
		}
		
		if(bSelectOnlyView) // && !pLine->bSelect)
			continue;
		
		bIn = TRUE;

		if(point1.x <= pLine->npStartPos.x && pLine->npStartPos.x <= point2.x &&
			point1.x <= pLine->npEndPos.x && pLine->npEndPos.x <= point2.x &&
			point1.y <= pLine->npStartPos.y && pLine->npStartPos.x <= point2.y &&
			point1.y <= pLine->npEndPos.y && pLine->npEndPos.x <= point2.y)
		{
			if(pLine->bSelect)// && !bSelectionPlus)
				pLine->bSelect = FALSE;
			else
				pLine->bSelect = TRUE;
		}
//		else
//		{
//			if(!bSelectionPlus)
//				pLine->bSelect = FALSE;
//		}
	}
	if(bIn)
		return TRUE;
	else
		return FALSE;
}

void DUnit::Flip(BOOL bX, int nMinX, int nMaxX, int nMinY, int nMaxY)
{
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	if(bX)
	{
		while (pos) 
		{
			pHole = m_HoleData.GetNext(pos);
			pHole->npPos.x = nMaxX + nMinX - pHole->npPos.x;
		}
	}
	else
	{
		while (pos) 
		{
			pHole = m_HoleData.GetNext(pos);
			pHole->npPos.y = nMaxY + nMinY - pHole->npPos.y;
		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	if(bX)
	{
		while (pos) 
		{
			pLine = m_LineData.GetNext(pos);
			pLine->npStartPos.x = nMaxX + nMinX - pLine->npStartPos.x;
			pLine->npEndPos.x = nMaxX + nMinX - pLine->npEndPos.x;
		}
	}
	else
	{
		while (pos) 
		{
			pLine = m_LineData.GetNext(pos);
			pLine->npStartPos.y = nMaxY + nMinY - pLine->npStartPos.y;
			pLine->npEndPos.y = nMaxY + nMinY - pLine->npEndPos.y;
		}
	}
}

void DUnit::Rotate(double dDeg, int& nMinX, int& nMaxX, int& nMinY, int& nMaxY)
{
	CPoint nCenterP;
	int nX;
	double cosTheta, sinTheta;
	
	nCenterP.x = (nMaxX + nMinX) / 2;
	nCenterP.y = (nMaxY + nMinY) / 2;
	
	nMinX		= INT_MAX;
	nMinY		= INT_MAX;
	nMaxX		= INT_MIN;
	nMaxY		= INT_MIN;
	
	dDeg = dDeg * M_PI / 180; // deg to rad
	cosTheta = cos(dDeg);
	sinTheta = sin(dDeg);
	
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		nX = (int)(cosTheta*(pHole->npPos.x - nCenterP.x) - sinTheta*(pHole->npPos.y - nCenterP.y) + nCenterP.x);
		pHole->npPos.y = (int)(sinTheta*(pHole->npPos.x - nCenterP.x) + cosTheta*(pHole->npPos.y - nCenterP.y) + nCenterP.y);
		pHole->npPos.x = nX;
		
		if(nMaxX < pHole->npPos.x) nMaxX = pHole->npPos.x;
		if(nMinX > pHole->npPos.x) nMinX = pHole->npPos.x;
		if(nMaxY < pHole->npPos.y) nMaxY = pHole->npPos.y;
		if(nMinY > pHole->npPos.y) nMinY = pHole->npPos.y;
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		nX = (int)(cosTheta*(pLine->npStartPos.x - nCenterP.x) - sinTheta*(pLine->npStartPos.y - nCenterP.y) + nCenterP.x);
		pLine->npStartPos.y = (int)(sinTheta*(pLine->npStartPos.x - nCenterP.x) + cosTheta*(pLine->npStartPos.y - nCenterP.y) + nCenterP.y);
		pLine->npStartPos.x = nX;
		
		nX = (int)(cosTheta*(pLine->npEndPos.x - nCenterP.x) - sinTheta*(pLine->npEndPos.y - nCenterP.y) + nCenterP.x);
		pLine->npEndPos.y = (int)(sinTheta*(pLine->npEndPos.x - nCenterP.x) + cosTheta*(pLine->npEndPos.y - nCenterP.y) + nCenterP.y);
		pLine->npEndPos.x = nX;
		
		if(nMaxX < pLine->npStartPos.x) nMaxX = pLine->npStartPos.x;
		if(nMinX > pLine->npStartPos.x) nMinX = pLine->npStartPos.x;
		if(nMaxY < pLine->npStartPos.y) nMaxY = pLine->npStartPos.y;
		if(nMinY > pLine->npStartPos.y) nMinY = pLine->npStartPos.y;
		
		if(nMaxX < pLine->npEndPos.x) nMaxX = pLine->npEndPos.x;
		if(nMinX > pLine->npEndPos.x) nMinX = pLine->npEndPos.x;
		if(nMaxY < pLine->npEndPos.y) nMaxY = pLine->npEndPos.y;
		if(nMinY > pLine->npEndPos.y) nMinY = pLine->npEndPos.y;
	}
}

void DUnit::ReMoveAllLineData()
{
	LPLINEDATA pLine;
	POSITION pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		if(pLine->nRefNo == 1)
			delete pLine;
		else
			pLine->nRefNo--;
	}
	m_LineData.RemoveAll();
}

void DUnit::ReMoveAllHoleData()
{
	POSITION pos = m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	
	while (pos) 
	{
		pData = m_HoleData.GetNext(pos);
		if(pData->nRefNo == 1)
			delete pData;
		else
			pData->nRefNo--;
	}
	m_HoleData.RemoveAll();
}

BOOL DUnit::IsDotData(int nTool)
{
	POSITION pos = m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	
	while (pos) 
	{
		pData = m_HoleData.GetNext(pos);
		if(pData->nToolNo == nTool)
			return TRUE;
	}
	return FALSE;
}

BOOL DUnit::IsLineData(int nTool)
{
	POSITION pos = m_LineData.GetHeadPosition();
	LPLINEDATA pData;
	
	while (pos) 
	{
		pData = m_LineData.GetNext(pos);
		if(pData->nToolNo == nTool)
			return TRUE;
	}
	return FALSE;
}

void DUnit::Copy(DUnit *pUnit)
{
	POSITION pos = pUnit->m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	while (pos) 
	{
		pData = pUnit->m_HoleData.GetNext(pos);
		pData->nRefNo++;
		m_HoleData.AddTail(pData);
	}
	
	LPLINEDATA pLine;
	pos = pUnit->m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = pUnit->m_LineData.GetNext(pos);
		pLine->nRefNo++;
		m_LineData.AddTail(pLine);
	}

	int* pIndex;
	int* pNewIndex;
	pos = pUnit->m_SubFidIndexData.GetHeadPosition();
	while (pos) 
	{
		pIndex = pUnit->m_SubFidIndexData.GetNext(pos);
		pNewIndex = new int;
		*pNewIndex = *pIndex;
		m_SubFidIndexData.AddTail(pNewIndex);
	}

	m_nMinX = pUnit->m_nMinX;
	m_nMaxX = pUnit->m_nMaxX;
	m_nMinY = pUnit->m_nMinY;
	m_nMaxY = pUnit->m_nMaxY;
}

void DUnit::SetSelect()
{
	if(m_bSelect)
		m_bSelect = FALSE;
	else
		m_bSelect = TRUE;
}

void DUnit::Move(int nX, int nY)
{
	POSITION pos = m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	while (pos) 
	{
		pData = m_HoleData.GetNext(pos);
		pData->npPos.x += nX;
		pData->npPos.y += nY;
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		pLine->npStartPos.x += nX;
		pLine->npStartPos.y += nY;
		pLine->npEndPos.x += nX;
		pLine->npEndPos.y += nY;
	}
	
	m_nMinX += nX;
	m_nMaxX += nX;
	m_nMinY += nY;
	m_nMaxY += nY;
}

void DUnit::Copy(DUnit *pUnit, int nOffsetX, int nOffsetY)
{
	POSITION pos = pUnit->m_HoleData.GetHeadPosition();
	LPHOLEDATA pData, pNewData;
	while (pos) 
	{
		pData = pUnit->m_HoleData.GetNext(pos);
		pNewData = new HOLEDATA;
		pNewData->npPos.x = pData->npPos.x + nOffsetX;
		pNewData->npPos.y = pData->npPos.y + nOffsetY;
		pNewData->nRefNo = 1;
		pNewData->nToolNo = pData->nToolNo;
		pNewData->nUnitIndex = pData->nUnitIndex;

		for(int i=0; i<4; i++)
		{
			for(int j=0; j<2; j++)
			{
				pNewData->nFidIndex[i][j] = pData->nFidIndex[i][j];
			}
		}
		m_HoleData.AddTail(pNewData);
	}
	
	LPLINEDATA pLine, pNewLine;
	pos = pUnit->m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = pUnit->m_LineData.GetNext(pos);
		pNewLine = new LINEDATA;
		pNewLine->npStartPos.x = pLine->npStartPos.x + nOffsetX;
		pNewLine->npStartPos.y = pLine->npStartPos.y + nOffsetY;
		pNewLine->npEndPos.x = pLine->npEndPos.x + nOffsetX;
		pNewLine->npEndPos.y = pLine->npEndPos.y + nOffsetY;
		pNewLine->nUnitIndex = pLine->nUnitIndex;
		pNewLine->nRefNo = 1;
		pNewLine->nToolNo = pLine->nToolNo;

		for(int i=0; i<4; i++)
		{
			for(int j=0; j<2; j++)
			{
				pNewLine->nFidIndex[i][j] = pLine->nFidIndex[i][j];
			}
		}
		
		m_LineData.AddTail(pNewLine);
	}
	
/*	int* pIndex;
	int* pNewIndex;
	pos = pUnit->m_SubFidIndexData.GetHeadPosition();
	while (pos) 
	{
		pIndex = pUnit->m_SubFidIndexData.GetNext(pos);
		pNewIndex = new int;
		*pNewIndex = *pIndex;
		m_SubFidIndexData.AddTail(pNewIndex);
	}
*/ // �߰� �ؾ���. --> ��� �������� �����	
	m_nMinX = pUnit->m_nMinX + nOffsetX;
	m_nMaxX = pUnit->m_nMaxX + nOffsetX;
	m_nMinY = pUnit->m_nMinY + nOffsetY;
	m_nMaxY = pUnit->m_nMaxY + nOffsetY;
}

void DUnit::Merge(DUnit *pUnit)
{
	POSITION pos = pUnit->m_HoleData.GetHeadPosition();
	LPHOLEDATA pData;
	while (pos) 
	{
		pData = pUnit->m_HoleData.GetNext(pos);
		pData->nRefNo++;
		m_HoleData.AddTail(pData);
	}
	
	LPLINEDATA pLine;
	pos = pUnit->m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = pUnit->m_LineData.GetNext(pos);
		pLine->nRefNo++;
		m_LineData.AddTail(pLine);
	}
	
	if(m_nMinX > pUnit->m_nMinX)
		m_nMinX = pUnit->m_nMinX;
	if(m_nMaxX < pUnit->m_nMaxX)
		m_nMaxX = pUnit->m_nMaxX;
	if(m_nMinY > pUnit->m_nMinY)
		m_nMinY = pUnit->m_nMinY;
	if(m_nMaxY < pUnit->m_nMaxY)
		m_nMaxY = pUnit->m_nMaxY;
}

void DUnit::DelInRect(CPoint point1, CPoint point2, BOOL bReverse)
{
	LPHOLEDATA pHole;
	POSITION posBefore, pos = m_HoleData.GetHeadPosition();
	posBefore = pos;
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if (point1.x > pHole->npPos.x || pHole->npPos.x > point2.x ||
			point1.y > pHole->npPos.y || pHole->npPos.y > point2.y) // outer hole
		{
			if(bReverse)
			{
				if(pHole->nRefNo == 1)
					delete pHole;
				else
					pHole->nRefNo--;

				m_HoleData.RemoveAt(posBefore);
			}
		}
		else
		{
			if(!bReverse)
			{
				if(pHole->nRefNo == 1)
					delete pHole;
				else
					pHole->nRefNo--;
				
				m_HoleData.RemoveAt(posBefore);
			}
		}

		posBefore = pos;
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	posBefore = pos;
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if (point1.x > pLine->npStartPos.x || pLine->npStartPos.x > point2.x ||
			point1.y > pLine->npStartPos.y || pLine->npStartPos.y > point2.y ||
			point1.x > pLine->npEndPos.x || pLine->npEndPos.x > point2.x ||
			point1.y > pLine->npEndPos.y || pLine->npEndPos.y > point2.y) // outer line
		{
			if(bReverse)
			{
				if(pLine->nRefNo == 1)
					delete pLine;
				else
					pLine->nRefNo--;
				
				m_LineData.RemoveAt(posBefore);
			}
		}
		else
		{
			if(!bReverse)
			{
				if(pLine->nRefNo == 1)
					delete pLine;
				else
					pLine->nRefNo--;
				
				m_LineData.RemoveAt(posBefore);
			}
		}
		posBefore = pos;
	}
}

BOOL DUnit::IsAnyData()
{
	if(m_HoleData.GetCount() != 0 ||
		m_LineData.GetCount() != 0)
		return TRUE;
	else
		return FALSE;
}

void DUnit::ReCalRect()
{
	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;

	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(m_nMaxX < pHole->npPos.x) m_nMaxX = pHole->npPos.x;
		if(m_nMinX > pHole->npPos.x) m_nMinX = pHole->npPos.x;
		if(m_nMaxY < pHole->npPos.y) m_nMaxY = pHole->npPos.y;
		if(m_nMinY > pHole->npPos.y) m_nMinY = pHole->npPos.y;
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(m_nMaxX < pLine->npStartPos.x) m_nMaxX = pLine->npStartPos.x;
		if(m_nMinX > pLine->npStartPos.x) m_nMinX = pLine->npStartPos.x;
		if(m_nMaxY < pLine->npStartPos.y) m_nMaxY = pLine->npStartPos.y;
		if(m_nMinY > pLine->npStartPos.y) m_nMinY = pLine->npStartPos.y;
		
		if(m_nMaxX < pLine->npEndPos.x) m_nMaxX = pLine->npEndPos.x;
		if(m_nMinX > pLine->npEndPos.x) m_nMinX = pLine->npEndPos.x;
		if(m_nMaxY < pLine->npEndPos.y) m_nMaxY = pLine->npEndPos.y;
		if(m_nMinY > pLine->npEndPos.y) m_nMinY = pLine->npEndPos.y;
	}
}

void DUnit::ResetAllFiducial(BOOL bSubFid)
{
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(pHole->bSelect)
		{
			for(int i=0; i<4; i++)
				pHole->nFidIndex[i][bSubFid] = -1;
		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(pLine->bSelect)
		{
			for(int i=0; i<4; i++)
				pLine->nFidIndex[i][bSubFid] = -1;
		}
	}
}

void DUnit::SetFiducial(int nIndex, BOOL bSubFid)
{
	if(nIndex < 0)
		return;

	int nFind;
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		nFind = 0;
		pHole = m_HoleData.GetNext(pos);
		
		if(pHole->bSelect)
		{
			for(int i=0; i<4; i++)
			{
				if(pHole->nFidIndex[i][bSubFid] != -1)
					nFind++;
			}

			if(nFind < 4)
			{
				for(int i=0; i<4; i++)
				{
					if(pHole->nFidIndex[i][bSubFid] == nIndex)
					{
						ErrMessage(_T("This is Selected Fiducial"));
						return;
					}

					if(pHole->nFidIndex[i][bSubFid] == -1)
					{
						pHole->nFidIndex[i][bSubFid] = nIndex;
						break;
					}
				}
			}
			else
			{
				ErrMessage("Data must be able to Select Maximum 4 Fiducial\n if new set, reset old Fiducial Info");
				return;
			}
		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		nFind = 0;
		pLine = m_LineData.GetNext(pos);
		
		if(pLine->bSelect)
		{
			for(int i=0; i<4; i++)
			{
				if(pLine->nFidIndex[i][bSubFid] != -1)
					nFind++;
			}

			if(nFind < 4)
			{
				for(int i=0; i<4; i++)
				{
					if(pLine->nFidIndex[i][bSubFid] == nIndex)
					{
						ErrMessage(_T("This is Selected Fiducial"));
						return;
					}
					
					if(pLine->nFidIndex[i][bSubFid] == -1)
					{
						pLine->nFidIndex[i][bSubFid] = nIndex;
						break;
					}	
				}
			}
			else
			{
				ErrMessage("Data must be able to Select Maximum 4 Fiducial\n if new set, reset old Fiducial Info");
				return;
			}
		}
	}
}

void DUnit::ResetOneFiducial(int nIndex, BOOL bSubFid)
{
	if(nIndex < 0)
		return;
	int nFind = 0;
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(pHole->bSelect)
		{
			for(int i=0; i<4; i++)
			{
				if(pHole->nFidIndex[i][bSubFid] == nIndex)
				{
					pHole->nFidIndex[i][bSubFid] = -1;
					nFind++;
					break;
				}
			}
		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(pLine->bSelect)
		{
			for(int i=0; i<4; i++)
			{
				if(pLine->nFidIndex[i][bSubFid] == nIndex)
				{
					pLine->nFidIndex[i][bSubFid] = -1;
					nFind++;
					break;
				}
			}
		}
	}

	if(nFind == 0)
		ErrMessage(_T("There is no Fiducial for reset"));
}

BOOL DUnit::IsUseFidInArea(int nIndex, BOOL bSubFid)
{
	if(nIndex < 0)
		return FALSE;
	LPHOLEDATA pHole;
	POSITION pos = m_HoleData.GetHeadPosition();
	while (pos) 
	{
		pHole = m_HoleData.GetNext(pos);
		
		if(pHole->bSelect)
		{
			for(int i=0; i<4; i++)
			{
				if(pHole->nFidIndex[i][bSubFid] == nIndex)
				{
					return TRUE;
				}
			}
		}
	}
	
	LPLINEDATA pLine;
	pos = m_LineData.GetHeadPosition();
	while (pos) 
	{
		pLine = m_LineData.GetNext(pos);
		
		if(pLine->bSelect)
		{
			for(int i=0; i<4; i++)
			{
				if(pLine->nFidIndex[i][bSubFid] == nIndex)
				{
					return TRUE;
				}
			}
		}
	}
	return FALSE;
}

BOOL DUnit::LoadFile10000Pusan32(CArchiveMark &ar, int nVersion)
{
	CString str;
	int nCount;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code
			// ver 10002
			if(nVersion < 10002)
			{
				
			}
			else
			{
				ar >> nCount;
				int* pIndex;
				for(int i = 0; i < nCount; i++)
				{
					pIndex = new int;
					ar >> *pIndex;
					m_SubFidIndexData.AddTail(pIndex);
				}
				ar >> m_nMinX; 
				ar >> m_nMinY;
				ar >> m_nMaxX;
				ar >> m_nMaxY;
			}
			
			// ver 10002 end
			
			ar >> nCount;
			LPHOLEDATA pOriHole;
			for(int i = 0; i < nCount; i++)
			{
				pOriHole = new HOLEDATA;
				ar >> pOriHole->nToolNo;
				ar >> pOriHole->npPos.x;
				ar >> pOriHole->npPos.y;
				ar >> pOriHole->nUnitIndex;
				pOriHole->nRotate = 0;
				pOriHole->nRefNo = 1;

				for(int m=0; m<4; m++) //default
				{
					for(int n=0; n<2; n++)
					{
						pOriHole->nFidIndex[m][n] = -1;
					}
				}

				m_HoleData.AddTail(pOriHole);
			}
			
			LPLINEDATA pOriLine; 
			ar >> nCount;
			for(int i = 0; i < nCount; i++)
			{
				pOriLine = new LINEDATA;
				ar >> pOriLine->nToolNo;
				ar >> pOriLine->npStartPos.x;
				ar >> pOriLine->npStartPos.y;
				ar >> pOriLine->npEndPos.x;
				ar >> pOriLine->npEndPos.y;
				ar >> pOriLine->nUnitIndex;
				pOriLine->nRefNo = 1;

				for(int m=0; m<4; m++) //default
				{
					for(int n=0; n<2; n++)
					{
						pOriHole->nFidIndex[m][n] = -1;
					}
				}
				
				m_LineData.AddTail(pOriLine);
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}

BOOL DUnit::LoadFileRect10000Pusan32(CArchiveMark &ar, int nVersion)
{
	CString str;
	int nCount;
	TRY
	{
		if (!ar.IsStoring())
		{	// loading code
			
			if(nVersion < 10002)
			{
				
			}
			else
			{
				ar >> nCount;
				int* pIndex;
				for(int i = 0; i < nCount; i++)
				{
					pIndex = new int;
					ar >> *pIndex;
					m_SubFidIndexData.AddTail(pIndex);
				}
				
				ar >> m_nMinX; 
				ar >> m_nMinY;
				ar >> m_nMaxX;
				ar >> m_nMaxY;
			}
			
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
		return FALSE;
	}
	END_CATCH
		return TRUE;
}

// DUnit.h: interface for the DUnit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DUNIT_H__67DDD6E7_7FC0_4854_A030_7DAB6FD28376__INCLUDED_)
#define AFX_DUNIT_H__67DDD6E7_7FC0_4854_A030_7DAB6FD28376__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ToolCodeList.h"
#include "2DTransform.h"
#include "HOLEDATA.h"

struct LINEDATA {
	int			nToolNo;
	int			nRefToolNo;
	CPoint		npStartPos;
	CPoint		npEndPos;
	//	BOOL		bSelect;
	int			nRefNo;
	int			nUnitIndex;
	BOOL		bDivideDone;

	// 110516
	int			nFidIndex[4][2]; // 4�� Fiducial�� primary, secondary index
	BOOL		bSelect;
	BOOL		nLPCError;
	int			nFidBlock;
};
typedef LINEDATA*	LPLINEDATA;
typedef CTypedPtrList <CPtrList, LPLINEDATA>	LineDataList;
/*
struct HOLEDATA {
	int			nToolNo;
	CPoint		npPos;
	//	BOOL		bSelect;
	int			nRefNo;
};
*/
//typedef HOLEDATA*	LPHOLEDATA;
// typedef CTypedPtrList <CPtrList, LPHOLEDATA>	HoleDataList;
typedef CTypedPtrList <CPtrList, int*>	SubFidIndexList;

class DUnit  
{
public:
	BOOL LoadFileRect10000Pusan32(CArchiveMark &ar, int nVersion);
	BOOL LoadFile10000Pusan32(CArchiveMark &ar, int nVersion);
	void ReCalRect();
	BOOL IsAnyData();
	void DelInRect(CPoint point1, CPoint point2, BOOL bReverse);
	void Merge(DUnit* pUnit);
	void Copy(DUnit *pUnit, int nOffsetX, int nOffsetY);
	void Move(int nX, int nY);
	BOOL m_bSelect;
	void SetSelect();
	void Copy(DUnit* pUnit);
	BOOL IsLineData(int nTool);
	BOOL IsDotData(int nTool);
	void ReMoveAllHoleData();
	void ReMoveAllLineData();
	void Rotate(double dDeg, int& nMinX, int& nMaxX, int& nMinY, int& nMaxY);
	void Flip(BOOL bX, int nMinX, int nMaxX, int nMinY, int nMaxY);
	BOOL IsSelect(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
	BOOL IsSelect(CPoint point, int nTolerence, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
	BOOL LoadFile10000(CArchiveMark &ar, int nVersion);
	BOOL SaveFile10000(CArchiveMark &ar, int nVersion);
	BOOL LoadFileRect10000(CArchiveMark &ar, int nVersion);
	BOOL SaveFileRect10000(CArchiveMark &ar, int nVersion);
	DUnit();
	virtual ~DUnit();

	SubFidIndexList m_SubFidIndexData;
	int	m_nMinX;
	int	m_nMinY;
	int	m_nMaxX;
	int	m_nMaxY;
	LineDataList	m_LineData;
	HoleDataList	m_HoleData;
	
	BOOL m_bTransOK;
	C2DTransform m_1stTrans;
	C2DTransform m_2ndTrans;

	BOOL SelectData(CPoint point1, CPoint point2, CToolCodeList** pToolCodes, BOOL bSelectOnlyView);//, BOOL bSelectionPlus);
	void UnSelectData();

	void SetFiducial(int nIndex, BOOL bSubFid);
	void ResetOneFiducial(int nIndex, BOOL bSubFid);
	void ResetAllFiducial(BOOL bSubFid);
	BOOL IsUseFidInArea(int nIndex, BOOL bSubFid);
	

	BOOL IsAnySelectedData(CToolCodeList** pToolCodes, BOOL bSelectOnlyView);
};

#endif // !defined(AFX_DUNIT_H__67DDD6E7_7FC0_4854_A030_7DAB6FD28376__INCLUDED_)

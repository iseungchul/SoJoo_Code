// DShotTableINI.cpp: implementation of the DShotTableINI class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DShotTableINI.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
DShotTableINI gShotTableINI;

DShotTableINI::DShotTableINI()
{
	memset( &m_sShotGroupTable, 0, sizeof(m_sShotGroupTable) );
	for(int i = 0 ;i < SHOT_GROUP_COUNT; i++)
	{
		m_sShotGroupTable.nShotMinFrequency[i] = 3500;		
	}
	/*
	m_sFidTable.dScannerJumpDelay = 1000;
	
	for(int i = 0 ;i < BEAMPATH_COUNT; i++)
	{
		strcpy_s(m_sFidTable.strBeamPathAscFile[i],_T("-"));
		strcpy_s(m_sFidTable.strInfoName[i],_T("-"));		
	}
	strcpy_s(m_sBeampath.strPowCompensationAomFile,_T("-"));
	*/


}

DShotTableINI::~DShotTableINI()
{

}

// HOLEDATA.h: interface for the HOLEDATA class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HOLEDATA_H__0F35D9DF_0425_4E8E_86CF_C62546B84D65__INCLUDED_)
#define AFX_HOLEDATA_H__0F35D9DF_0425_4E8E_86CF_C62546B84D65__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <afxtempl.h>

class HOLEDATA  
{
public:
	void operator delete(void* p);
	void* operator new(size_t nSize);
	void* operator new(size_t nSize, LPCSTR lpszFileName, int nLine);
	void  operator delete(void* p, LPCSTR lpszFileName, int nLine);

	HOLEDATA();
	virtual ~HOLEDATA()
	{
	};

	int			nToolNo;
	int			nRefToolNo;
	CPoint		npPos;
	int			nRefNo;
	int			nUnitIndex;
	int		nRotate;
	// 110516
	int			nFidIndex[4][2]; // 4�� Fiducial�� Main, Sub index
	BOOL		bSelect;
	int			nLPCError;
	BOOL		bCurrnetLPCError;
	

	HOLEDATA*   pNext;
	HOLEDATA*	pBefore;
	int			nFidBlock; //20111123 bskim 
	int			nArrayNo;
	int			nOCRType;
	static HANDLE s_hHeap;
	
	static UINT   s_uNumAllocsInHeap;

};

typedef HOLEDATA*	LPHOLEDATA;

class HoleDataList
{
public:
	void RemoveAt(POSITION pos);
	void RemoveAll();
	void AddTail(LPHOLEDATA pData);
	LPHOLEDATA GetNext(POSITION& pos);
	POSITION GetHeadPosition();
	int GetCount();
	HoleDataList();
	virtual ~HoleDataList();

private:
	HOLEDATA* m_pHeadHoleData;
	HOLEDATA* m_pTailHoleData;
	int m_nCount;
};

#endif // !defined(AFX_HOLEDATA_H__0F35D9DF_0425_4E8E_86CF_C62546B84D65__INCLUDED_)

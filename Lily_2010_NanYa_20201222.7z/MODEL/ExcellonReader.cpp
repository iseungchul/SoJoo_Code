// ExcellonReader.cpp: implementation of the ExcellonReader class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "ExcellonReader.h"
#include "DProject.h"
#include "..\EasyDriller.h"
//#include "..\sysdef.h"
#include "DUodoRedo.h"
#include "..\resource.h"
#include "DProcessINI.h"
#include <crtdbg.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ExcellonReader::ExcellonReader()
{
	m_bReadStart	= TRUE;
	m_nNewTCode		= 0;
	m_nNewMCode		= 0;
	m_nLength		= 0;

	m_bRepeat		= FALSE;
	m_bIsSwap		= FALSE;
	m_bStoreData	= FALSE;
	m_nMirrorX		= 1;
	m_nMirrorY		= 1;
	m_bIsRead		= FALSE;
	m_bSetFid		= FALSE;
	m_bSetFid2		= FALSE;
	m_bReadHole		= FALSE;

	m_nHoleSize			= 0;
	m_bOverlapXY		= FALSE;

	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;
	m_pGlyphExcell = NULL;
	m_pDProject = NULL;
	m_pUnit		= NULL;
	m_nFidBlock = -1;
	m_bToolChange = TRUE;
	m_bFidTool = FALSE;
	m_nRotate	= ROT_NONE;
	m_bSaveRotate = FALSE;
	m_bm80m90 = FALSE;
	m_bOCR = FALSE;
	m_nFidCount = 0;

	for(int i = 0; i <MAX_TOOL_NO; i++)
	{
		m_nReadHoleCount[i] = 0;
	}

	m_nLineNo = 1;
	m_nLineDistance = 100;
	m_bZigZag = TRUE;
	m_nLineExtend = 0;
	m_bAbsoluteMode = TRUE;
	m_bDrillMode = TRUE;
	m_dIncrementalFirstPosX = 0;
	m_dIncrementalFirstPosY = 0;
	m_bHeaderEnd = FALSE;
	m_bHeaderStart = FALSE;

	m_nArrayNo = 1;
	m_bToolG93 = FALSE;
	m_nG821Count = 0;
	m_bFiducialDataLastRead = FALSE;
	m_nOCRType = -1;
	m_nMultiSkiveCount = 0;
	m_strOCRType = "";
}

ExcellonReader::~ExcellonReader()
{
	
	if(m_pUnit)
	{
		delete m_pUnit;
		m_pUnit = NULL;
	}

	// 20160610 check 
	if(m_pDProject)
	{
		delete m_pUnit;
		m_pUnit = NULL;
	}
}

int ExcellonReader::HeaderRead(CString strPath, GlyphExcellon* pExcellon, DProject* pProject, BOOL &bHeaderReadComplete, int &nG821Count)
{
	m_nLineNo = m_dlgExcellon.m_nLineNo; //LineNo;
	m_nLineDistance = m_dlgExcellon.m_nLineDistance;// .nLineDist;
	m_bCorrectTool = TRUE;
	m_bZigZag = m_dlgExcellon.m_bZigZag; //bZigZag;
	m_nLineExtend = m_dlgExcellon.m_nLineExtend; //nLineExtend;
	m_nFidBlock = -1;
	m_bToolChange = TRUE;
	m_bFidTool = FALSE;
	m_bCheckHoleCount = FALSE;
	m_bHeaderEnd = FALSE;

	m_bToolG93 = FALSE;
	m_nG821Count = 0;
	m_nPositionG93X = 0;
	m_nPositionG93Y = 0;

	m_nMultiSkiveCount = 0;

	TCHAR chBuffer[BUFMAX + 1], *token;
	TCHAR *szNext;
	FILE* pFile;
	errno_t err = fopen_s(&pFile, strPath, _T("rb"));
	if (err == NULL)
	{
		m_pGlyphExcell = pExcellon;
		m_pDProject = pProject;
		InitData(m_dlgExcellon.m_nTZS /*nLzs*/, m_dlgExcellon.m_nUnit /*nInputUnit*/);
		m_pUnit = new DUnit;
		m_pDProject->m_bSkivingMode = FALSE;

		while (!feof(pFile))
		{
			if (m_bHeaderEnd && bHeaderReadComplete)
			{
				nG821Count = m_nG821Count;
				fclose(pFile);
				bHeaderReadComplete = FALSE;
				delete m_pUnit;
				m_pUnit = NULL;
				return TRUE;
			}
			fgets(chBuffer, BUFMAX, pFile);
			token = strtok_s(chBuffer, _T("\n"), &szNext);
			if (token == NULL)
				continue;
			for (TCHAR* szPos = token; *szPos != _T('\0'); szPos++)
				*szPos = static_cast<TCHAR>(toupper(*szPos));
			ReadNums(token); // Write to buffer
		};
		fclose(pFile);
	}
	
	m_bHeaderEnd = TRUE;
	bHeaderReadComplete = FALSE;
	
	delete m_pUnit;
	m_pUnit = NULL;
	if( m_pDProject != NULL)
	{
		m_pDProject->ResetUseToolFlag();
		m_pDProject->ResetMinMaxData();
		m_pDProject->ReMoveExcellon();
		m_pDProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].RemoveFidData();
		m_pDProject->m_Glyphs.m_FiducialData[ADDED_FID_INDEX].RemoveFidData();
	}
	return TRUE;
}
int ExcellonReader::Read(CString strPath, short nLzs, int nInputUnit,  GlyphExcellon* pExcellon, DProject* pProject, int nLineNo, int nLineDist, BOOL bZigZag, int nLineExtend, BOOL& bHeaderReadComplete, int nG821Count)
{
	m_nLineNo = nLineNo;
	m_nLineDistance = nLineDist;
	m_bCorrectTool = TRUE;
	m_bZigZag = bZigZag;
	m_nLineExtend = nLineExtend;
	m_nFidBlock = -1;
	m_bToolChange = TRUE;
	m_bFidTool = FALSE;
	m_bCheckHoleCount = FALSE;
	
	m_bToolG93 = FALSE;
	m_nPositionG93X = 0;
	m_nPositionG93Y = 0;

	m_nG821Count = nG821Count;
	m_nMultiSkiveCount = 0;

	for(int i=0; i<30;i++)
	{
		m_ptSkivePos[i] = 0;
	}

	TCHAR chBuffer[BUFMAX + 1], *token;
	TCHAR *szNext;
	FILE* pFile;
	errno_t err = fopen_s(&pFile, strPath, _T("rb"));
	m_nArrayNo = 1; //2015.12.02
	for(int i = 0; i < MAX_TOOL_NO; i++)
	       m_nRealToolNo[i] = 0;//20160625
	if (err == NULL)
	{
		m_pGlyphExcell = pExcellon;
		m_pDProject = pProject;
		InitData(nLzs, nInputUnit);
		m_pUnit = new DUnit;

		m_pDProject->m_bSkivingMode = FALSE;

		while (!feof(pFile))
		{
			fgets(chBuffer, BUFMAX, pFile);
			token = strtok_s(chBuffer, _T("\n"), &szNext);
			if (token == NULL)
				continue;
			for (TCHAR* szPos = token; *szPos != _T('\0'); szPos++)
				*szPos = static_cast<TCHAR>(toupper(*szPos));
			ReadNums(token); // Write to buffer
		};
		fclose(pFile);
	}

	// 080818
	if(m_bOverlapXY)
	{
		//		::MessageDlg(STDGNALM510, MB_ICONSTOP);
		m_bOverlapXY = FALSE;

		delete m_pUnit;
		m_pUnit = NULL;
		bHeaderReadComplete = TRUE;

		return FALSE;
	}

	if(!m_bCorrectTool)
	{
		ErrMessage(_T("Check the File Tool No. : 0 < Tool No. < 13"));
		delete m_pUnit;
		m_pUnit = NULL;
		bHeaderReadComplete = TRUE;

		return FALSE;
	}

	if(m_pUnit == NULL)
		m_pUnit = new DUnit;
	if( m_pGlyphExcell != NULL)
	{
		if(!m_pGlyphExcell->IsValidTool(m_pUnit))
		{
			ErrMessage(IDS_ERR_TOOL_TYPE);

			delete m_pUnit;
			m_pUnit = NULL;

			return FALSE;
		}
	}
	if( m_pDProject != NULL)
		m_pDProject->m_nMaxFidBlock = m_nFidBlock;
	if( m_pGlyphExcell != NULL)
		m_pGlyphExcell->MakeUnitsForContinuousLine(m_pUnit);

	//	m_pGlyphExcell->m_Units.AddTail(m_pUnit);
	//	gDUndoRedo.AddGlyphtoList(m_pUnit);
	//	gDUndoRedo.AddGlyph();
	if( m_pGlyphExcell != NULL)
	{
		if(m_pGlyphExcell->m_nMaxX < m_nMaxX)
			m_pGlyphExcell->m_nMaxX = m_nMaxX;
		if(m_pGlyphExcell->m_nMaxY < m_nMaxY)
			m_pGlyphExcell->m_nMaxY = m_nMaxY;
		if(m_pGlyphExcell->m_nMinX > m_nMinX)
			m_pGlyphExcell->m_nMinX = m_nMinX;
		if(m_pGlyphExcell->m_nMinY > m_nMinY)
			m_pGlyphExcell->m_nMinY = m_nMinY;
	}
	m_pUnit = NULL;
	if( m_pGlyphExcell != NULL)
	{
		m_pGlyphExcell->SortFiducial(DEFAULT_FID_INDEX);
		m_pGlyphExcell->SortFiducial(ADDED_FID_INDEX);
	}
	//Hole Count Checkf
	if(gProcessINI.m_sProcessSystem.bCheckHoleCount)
	{
#ifdef __SAMSUNG_TYPE_DATA__
		if(m_bCheckHoleCount)
		{
			int nToolCheckCount = 0;
#ifdef  __KUNSAN_2012__
			nToolCheckCount = 3;
#else
			nToolCheckCount = MAX_TOOL_NO;
#endif

			for(int i = 0; i < nToolCheckCount; i++)
			{
#ifdef __KUNSAN_SAMSUNG_LARGE__
				if(m_nRealToolNo[i] == 8) //T08 üũ ����
					continue;
#endif
				//			if(m_nReadHoleCount[i] != 0)
				{
					int nDataNo = m_pDProject->GetDataNo(i);
					if(m_nReadHoleCount[m_nRealToolNo[i]] != nDataNo)
					{
						CString strMessage;
						strMessage.Format(_T("Hole Count is Wrong\nRead Hole Data = %d\nGet Hole Data = %d"), m_nReadHoleCount[i], nDataNo);
						ErrMessage(strMessage);
						if( m_pDProject != NULL)
						{
							m_pDProject->ResetUseToolFlag();
							m_pDProject->ResetMinMaxData();
							m_pDProject->ReMoveExcellon();
							m_pDProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].RemoveFidData();
							m_pDProject->m_Glyphs.m_FiducialData[ADDED_FID_INDEX].RemoveFidData();
						}

						gDUndoRedo.Clear();
						bHeaderReadComplete = TRUE;
						return FALSE;
					}
				}
			}
		}
#endif
#ifdef __LG_TYPE_DATA__
		int nDataNo = 0;
		for(int i = 0; i < MAX_TOOL_NO; i++)
		{
			nDataNo += m_pDProject->GetDataNo(i);
		}
		if(m_nReadHoleCount[0] != nDataNo)
		{
			CString strMessage;
			strMessage.Format(_T("Total Hole Count is Wrong\nRead Hole Data = %d\nGet Hole Data = %d"), m_nReadHoleCount[0], nDataNo);
			ErrMessage(strMessage);
			m_pDProject->ResetUseToolFlag();
			m_pDProject->ResetMinMaxData();
			m_pDProject->ReMoveExcellon();
			m_pDProject->m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].RemoveFidData();
			m_pDProject->m_Glyphs.m_FiducialData[ADDED_FID_INDEX].RemoveFidData();
			gDUndoRedo.Clear();
			bHeaderReadComplete = TRUE;
			return FALSE;
		}
#endif
	}

	bHeaderReadComplete = TRUE;
	return 0;
}

void ExcellonReader::ReadHoleData(TCHAR *szBuf)
{
	CHAR szSeps[] = _T(" \t\r\n");
	TCHAR *token = NULL;
	TCHAR *szNext;

	if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
		return;

	CString str;
	BOOL bCount = FALSE, bColon = FALSE;
	while(token = strtok_s(NULL, szSeps, &szNext))
	{
		if(bCount && bColon)
		{
			m_nReadHoleCount[0] = atoi(token);
			return;
		}

		str.Format(_T("%s"), token);
		if(str.CompareNoCase(_T("COUNT")) == 0)
			bCount = TRUE;
		if(str.CompareNoCase(_T(":")) == 0)
			bColon = TRUE;
	}
}

void ExcellonReader::ReadNums(TCHAR *szBuffer)
{
	bool bSavePos = false, bSaveFid = false, bSaveMFid = false, bLine = false;
	
	CString str;
	BOOL bUse1 = FALSE, bUse2 = FALSE, bUse3 = FALSE, bUse4 = FALSE, bRRepeat = FALSE;
//	int nParam1 = 0, nParam2 = 0, nParam3 = 0, nParam4 = 0;
	m_bRandM2 = FALSE;
	m_nRRepeat = 1;
	m_nRDupliMX = 0;
	m_nRDupliMY = 0;
	BOOL bG831 = FALSE;
	BOOL bMultiSkiveSave = FALSE;
	if(!m_bSaveRotate)
	{
		m_nRotate	= ROT_NONE;
	}
	else
		m_nRotate = ROT_90;


	m_bRepeatXFlip = m_bRepeatYFlip = m_bRepeatSwap = FALSE;

	double dParam1 = 0.0, dParam2 = 0.0, dParam3 = 0.0, dParam4 = 0.0;
	
//	if(!GetParam(szBuffer, nParam1, nParam2, nParam3, nParam4, bUse1, bUse2, bUse3, bUse4))
//		return;
	if(!m_bHeaderEnd)
	{
		if(HeaderSetting(szBuffer))
		{
			return;
		}
	}

	CString strBuffer;
	strBuffer.Format("%s",szBuffer);

	if ( strBuffer.Find(_T("G821")) != -1 )//20171010
	{
		if(!m_bHeaderEnd)
		{
			m_nG821Count++; 
		}
		else
		{
			if(m_nG821Count > 4)
			{
				strBuffer.Replace("G821","");
				lstrcpy(szBuffer,strBuffer);
				bMultiSkiveSave = TRUE;
			}
		}
		 
	}
	
	if ( strBuffer.Find(_T("G831")) != -1 )//20171010
	{
		if(!m_bHeaderEnd)
		{
			m_nG821Count++;
			bG831 = TRUE;
		}
		else
		{
			if(m_nG821Count > 4)
			{
				strBuffer.Replace("G831","");
				lstrcpy(szBuffer,strBuffer);
				bMultiSkiveSave = TRUE;
			}
		}
	}


	if(!GetParam(szBuffer, dParam1, dParam2, dParam3, dParam4, bUse1, bUse2, bUse3, bUse4))
	{
		ReadHoleData(szBuffer);
		return;
	}

	if(!m_bSaveRotate)
	{
		if ( strBuffer.Find(_T("M80M90")) != -1 )//20171010
		{
			m_bm80m90 = TRUE;
			m_nRotate	= ROT_180;
		}
	}
	else
	{
		if ( strBuffer.Find(_T("M80M90")) != -1 )//20171010
		{
			m_bm80m90 = TRUE;
			m_nRotate	= ROT_270;
		}
	}

	if(m_bOCR) //20200824
	{
		int nOcrStart = 0;
		TCHAR *token, seps[] = _T(",$");
		TCHAR *szNext;
		CString strOCR;
		CString strOCRTemp;
		if( NULL == (token = strtok_s(szBuffer, seps, &szNext)))
		{
			m_nOCRType = -1;
			m_strOCRType = "";
			return;
		}
		while(1)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))
			{
				m_nOCRType = atoi(m_strOCRType);
				break;
			}
			strOCR = token; //OCR Type
			strOCR.TrimLeft();
			strOCR.TrimRight();

			if(strcmp(strOCR, _T("MACHINE")) == 0)
			{
				m_nOCRType = 0;
				strOCRTemp.Format(_T("%d"),m_nOCRType);
				m_strOCRType += strOCRTemp;
			}
			else if(strcmp(strOCR, _T("STAGE")) == 0)
			{
				m_nOCRType = 1;
				strOCRTemp.Format(_T("%d"),m_nOCRType);
				m_strOCRType += strOCRTemp;
			}
			else if(strcmp(strOCR, _T("DATE")) == 0)
			{
				m_nOCRType = 2;
				strOCRTemp.Format(_T("%d"),m_nOCRType);
				m_strOCRType += strOCRTemp;
			}
			else if(strcmp(strOCR, _T("TIME")) == 0)
			{
				m_nOCRType = 3;
				strOCRTemp.Format(_T("%d"),m_nOCRType);
				m_strOCRType += strOCRTemp;
			}
			else if(strcmp(strOCR, _T("LOT")) == 0)
			{
				m_nOCRType = 4;
				strOCRTemp.Format(_T("%d"),m_nOCRType);
				m_strOCRType += strOCRTemp;
			}
			else if(strcmp(strOCR, _T("SINSYUKU")) == 0)
			{
				m_nOCRType = 5;
				strOCRTemp.Format(_T("%d"),m_nOCRType);
				m_strOCRType += strOCRTemp;
			}
		}
	}
	else
	{
		m_nOCRType = -1;
		m_strOCRType = "";
	}


	if(szBuffer[0] == _T('X') || szBuffer[0] == _T('Y') || szBuffer[0] == _T('A') || szBuffer[0] == _T('B'))
	{
		if(bUse1)
		{
//			m_nPositionX = nParam1 * m_nMetric;
			m_nPositionX = (int)(dParam1 * m_nMetric);
			bSavePos = true;
		}
		if(bUse2)
		{
//			m_nPositionY = nParam2 * m_nMetric;
			m_nPositionY = (int)(dParam2 * m_nMetric);
			bSavePos = true;
		}
		if(bUse3)
		{
			m_nStartX = m_nPositionX;
//			m_nPositionX = nParam3 * m_nMetric;
			m_nPositionX = (int)(dParam3 * m_nMetric);
			bSavePos = true;
			bLine = TRUE;
		}
		if(bUse4)
		{
			m_nStartY = m_nPositionY;
//			m_nPositionY = nParam4 * m_nMetric;
			m_nPositionY = (int)(dParam4 * m_nMetric);
			bSavePos = true;
			bLine = true;
		}
		if(szBuffer[0] == _T('A')|| m_bFidTool) // m_nNewTCode > MAX_TOOL_NO - 1)
			bSaveFid = true;
		if(szBuffer[0] == _T('B'))
			bSaveMFid = true;

		if(bMultiSkiveSave == TRUE) //20200825 Multi skive Position Save
		{
			if(bUse1)
				m_ptSkivePos[m_nMultiSkiveCount].x = m_nPositionX;
			if(bUse2)
				m_ptSkivePos[m_nMultiSkiveCount].y = m_nPositionY;
			
			m_nMultiSkiveCount++;
		}
	}
	else if(szBuffer[0] == _T('R'))
	{
		if(bUse1)
		{
//			m_nRRepeat = nParam1;
			m_nRRepeat = (int)dParam1;
			bRRepeat = TRUE;
		}
		if(bUse2)
		{
//			m_nRDupliMX = nParam2 * m_nMetric;
			m_nRDupliMX = (int)(dParam2 * m_nMetric);
			bSavePos = true;
		}
		if(bUse3)
		{
//			m_nRDupliMY = nParam3 * m_nMetric;
			m_nRDupliMY = (int)(dParam3 * m_nMetric);
			bSavePos = true;
		}

		if(m_bRandM2)
		{
			m_bRepeat = TRUE;
		}

	}
	else if(szBuffer[0] == _T('T'))
	{
//		if (bUse1 && nParam1 >= 0 && nParam1 < MAX_TOOL_NO)
		m_bToolChange = TRUE;

		if((int)(dParam1) == 999)
			m_bFidTool = TRUE;
		else
			m_bFidTool = FALSE;

		if (bUse1 && dParam1 > 0 && /*dParam1 < MAX_TOOL_NO - 1 &&*/ m_bHeaderEnd && !bUse2)//20171010
		{
			//m_nNewTCode	= static_cast<byte>(dParam1);


			if(m_bFiducialDataLastRead == TRUE)
			{
				dParam1 = m_nRefTCode;
			}
			
			
			m_nRefTCode = static_cast<byte>(dParam1);
			BOOL bBeforeRead = FALSE;



			int nReadToolNo = static_cast<byte>(dParam1);


			for(int i = 0; i < MAX_TOOL_NO; i++)
			{
				if(!bUse2 && m_nRealToolNo[i] != 0)
				{
					if(m_nRealToolNo[i] == nReadToolNo)
					   bBeforeRead = TRUE;
				}
			}

			if(!bBeforeRead)
			{
				m_nNewTCode++;
				m_nRealToolNo[m_nNewTCode] = nReadToolNo;//20160625
			}
			else
			{
				for(int i = 0; i < MAX_TOOL_NO; i++)
				{
					if(m_nRealToolNo[i] == nReadToolNo)
						m_nNewTCode = i;
				}
			}




			ReadTCode();
			if(dParam1 < 0 /*&& dParam1 >= MAX_TOOL_NO - 1*/)
				m_bOverlapXY = TRUE;
		}
		if(bUse2 && m_bHeaderEnd)
		{
//			m_nHoleSize = nParam2 * m_nMetric;
			m_nHoleSize = (int)(dParam2 * m_nMetric);
			ReadCCode();
		}
	}
	else if(szBuffer[0] == _T('M'))
	{
		if (bUse1  && m_bHeaderEnd)
		{
//			m_nNewMCode	= static_cast<byte>(nParam1);
			m_nNewMCode	= static_cast<byte>(dParam1);
			ReadMCode();
		}
//		if(nParam1 == 2)
		if(dParam1 == 2)
		{
			if(m_bRepeatXFlip)
				m_nMirrorX			= -1;
			else
				m_nMirrorX			= 1;
			
			if(m_bRepeatYFlip)
				m_nMirrorY			= -1;
			else
				m_nMirrorY			= 1;
			
			m_bIsSwap			= m_bRepeatSwap;

			if(bUse2)
			{
//				m_nPositionX = nParam2 * m_nMetric;
				m_nPositionX = (int)(dParam2 * m_nMetric);
				bSavePos = true;
			}
			else
				m_nPositionX = 0;
			
			if(bUse3)
			{
//				m_nPositionY = nParam3 * m_nMetric;
				m_nPositionY = (int)(dParam3 * m_nMetric);
				bSavePos = true;
			}
			else
				m_nPositionY = 0;
		}
	}
	else if(szBuffer[0] == _T('G'))
	{
		if (bUse1)
		{
//			if(nParam1 == 82 || nParam1 == 83 || nParam1 == 84 || nParam1 == 85)
			if(dParam1 == 82 || dParam1 == 83 || dParam1 == 84 || dParam1 == 85)
			{
				bSaveFid = true;
				m_nFidCount++;
			}
			else if(dParam1 == 93 )
			{
				m_bToolG93 = TRUE;
				m_nPositionG93X = (int)(dParam2 * m_nMetric);
				m_nPositionG93Y = (int)(dParam3 * m_nMetric);
				return;
			}
			else if ( dParam1 == 821 || dParam1 == 831 )
			{
				bSaveMFid = true;
			}
			if(dParam1 == 90 && !m_bToolChange)
			{
				RemoveNodataFiducial();
			}
		}
		if(bUse2)
		{
//			m_nPositionX = nParam2 * m_nMetric;
			m_nPositionX = (int)(dParam2 * m_nMetric);
			bSavePos = true;

			if(m_bToolG93)
				m_nPositionX += m_nPositionG93X;
		}
		if(bUse3)
		{
//			m_nPositionY = nParam3 * m_nMetric;
			m_nPositionY = (int)(dParam3 * m_nMetric);

			if(m_bToolG93)
				m_nPositionY += m_nPositionG93Y;

			bSavePos = true;
		}
	}
	else if(szBuffer[0] == _T('C'))
	{
		if (bUse1  && m_bHeaderEnd)
		{
//			m_nHoleSize = nParam1 * m_nMetric;
			m_nHoleSize = (int)(dParam1 * m_nMetric);
			ReadCCode();
		}
	}
	else
	{
		ReadHoleData(szBuffer);
		return;
	}
	
	if (m_bRepeat == false)
	{
		m_nDupliMovX = 0;
		m_nDupliMovY = 0;
	}
	
	if (m_bRepeat == TRUE && bSavePos == true)
	{
		if (m_nPositionX != 0.0 || m_nPositionY != 0.0)
		{
			if(m_bRandM2)
			{
				for(int i = 0; i < m_nRRepeat; i++)
				{
					m_nDupliMovX	+= m_nRDupliMX;
					m_nDupliMovY	+= m_nRDupliMY;
					ReadDuplicatePos();
				}
			}
			else
			{
				m_nDupliMovX	+= m_nPositionX;
				m_nDupliMovY	+= m_nPositionY;
				ReadDuplicatePos();
			}
			
		}
	}
	else if (bSavePos == true && bSaveFid == false && bSaveMFid == false)
	{
		if(bRRepeat)
		{
			for(int i = 0; i < m_nRRepeat; i++)
			{
				m_nPositionX	+= m_nRDupliMX;
				m_nPositionY	+= m_nRDupliMY;
				if(bLine)
					ReadLine();
				else
					ReadPosition();
			}
		}
		else
		{
			if(bLine)
				ReadLine();
			else
				ReadPosition();
		}
	}

	if(bG831)
	{
		if(!m_bHeaderEnd)
		{
			m_bHeaderEnd = TRUE;
			m_bHeaderStart = FALSE;
			return;
		}
	}

	if(!bSaveFid && !bSaveMFid)//20171010
	{
		m_bFiducialDataLastRead = FALSE;
	}
	if(bRRepeat)
	{
		for(int i = 0; i < m_nRRepeat; i++)
		{
			m_nPositionX	+= m_nRDupliMX;
			m_nPositionY	+= m_nRDupliMY;

			if (bSaveFid == true)
				ReadFiducial(DEFAULT_FID_INDEX);
			
			if(bSaveMFid == true)
				ReadFiducial(ADDED_FID_INDEX);
		}
	}
	else
	{
		if (bSaveFid == true)
			ReadFiducial(DEFAULT_FID_INDEX);
		
		if(bSaveMFid == true)
			ReadFiducial(ADDED_FID_INDEX);
	}
}

BOOL ExcellonReader::ExtractNums(TCHAR *szBuffer, TCHAR &chCode, double &dValue, BOOL bCheckValidity)
{
/*	chCode = 0;
	int nTotalLen = strlen(szBuffer);
	if (nTotalLen == 0)
		return FALSE;
	
	chCode = szBuffer[0];
	if (chCode == _T('%') && nTotalLen == 1)
	{
		m_bReadStart = TRUE;
		szBuffer[0] = _T('\0');
		return TRUE;
	}
	else if (chCode == _T('Y') && nTotalLen == 1)
	{
		szBuffer[0] = _T('\0');
		dValue = 0.0;
		return TRUE;
	}
	else if (nTotalLen == 1)
		return FALSE;
	
	if (bCheckValidity)
	{
		if (GetValid(chCode, szBuffer) == false)
			return FALSE;
	}
	
	for (int i = 0; i < nTotalLen - 1; i++)
		m_szData[i] = szBuffer[i] = szBuffer[i + 1];
	m_szData[i] = szBuffer[i] = _T('\0');
	
	TCHAR ch1 = szBuffer[0];
	if (chCode == _T('X') && ch1 == _T('Y'))
	{
		dValue = 0.0;
		return TRUE;
	}
	else if (chCode == _T('A') || chCode == _T('B'))
		return TRUE;
	
	TCHAR* szParse = strtok_s(szBuffer, _T("XYCM"));
	if (szParse == NULL)
		return FALSE;
	int nParseLen = strlen(szParse) + 1;
	
	if (nParseLen == 1) // LZS ����� ���� Routine
	{
		;
	}
	else
	{
		if (szParse[0] == _T('-'))
			m_nLength = nParseLen - 2;
		else
			m_nLength = nParseLen - 1;
		
		IsTzs();
	}
	
	dValue = atof(szParse);
	
	for(int i =  0; i < nTotalLen - nParseLen + 1; i++)
		szBuffer[i] = m_szData[i + nParseLen - 1];
	szBuffer[i] = _T('\0');
	
*/	return TRUE;
}

void ExcellonReader::IsTzs(int nCount)
{
	if (m_nLzs == emTZS)
	{
		m_lTzsLzs = 1;
	}
	else
	{
		switch (nCount)
		{
			case 1 : m_lTzsLzs = 100000; break;
			case 2 : m_lTzsLzs = 10000;  break;
			case 3 : m_lTzsLzs = 1000;   break;
			case 4 : m_lTzsLzs = 100;    break;
			case 5 : m_lTzsLzs = 10;     break;
			case 6 : m_lTzsLzs = 1;      break;
			default : m_lTzsLzs = 1;	 break;
		} 
	}
}

void ExcellonReader::SetMetric()
{
	if (m_nInputUnit != em1inch)
	{
		switch (m_nInputUnit)
		{
		case em1um		: m_nMetric = 1; break;
		case em10um		: m_nMetric = 10;  break;
		case em100um	: m_nMetric = 100;   break;
		case em1000um	: m_nMetric = 1000;    break;
		default			: m_nMetric = 1;	 break;
		} 
//		m_nMetric = 1;
	}
	else
		m_nMetric = 2.540;
}

void ExcellonReader::ReadMCode()
{
	POSITION pos;
	switch (m_nNewMCode)
	{
	case 25	:				// ���� ���� ����
		m_bRepeat			= FALSE;
		m_nDupliMovX		= 0;
		m_nDupliMovY		= 0;
		m_bIsSwap			= FALSE;
		
		m_bStoreData		= TRUE;
		m_listData.RemoveAll();
		m_listLineData.RemoveAll();
		m_RepeatlistData.RemoveAll();
		m_RepeatlistLineData.RemoveAll();
		break;
		
	case 1	:				// ���� ���� ����
		m_bOCR = FALSE;
		m_bIsSwap			= FALSE;
		m_nDupliMovX = m_nDupliMovY = 0;
		m_listData.RemoveAll();
		m_listLineData.RemoveAll();
		pos = m_RepeatlistData.GetHeadPosition();
		while (pos != NULL)
		{
			HOLEDATA drData = m_RepeatlistData.GetNext(pos);
			m_listData.AddTail(drData);
		}
		pos = m_RepeatlistLineData.GetHeadPosition();
		while (pos != NULL)
		{
			LINEDATA drLine = m_RepeatlistLineData.GetNext(pos);
			m_listLineData.AddTail(drLine);
		}
		break;
		
	case 2	:				// 25���� 01������ �����϶�.
		m_bRepeat			= TRUE;	
		m_nMirrorX			= 1;
		m_nMirrorY			= 1;
		break;
		
	case 8 :				// 02���� ��(���� ��)
		m_bRepeat			= FALSE;
		m_nMirrorX			= 1;
		m_nMirrorY			= 1;
		m_bIsSwap			= FALSE;
		m_bStoreData		= FALSE;
		
		m_listData.RemoveAll();
		m_listLineData.RemoveAll();
		m_RepeatlistData.RemoveAll();
		m_RepeatlistLineData.RemoveAll();
		break;
		
	case 48	:				// ����
		m_bRepeat			= FALSE;
		m_nDupliMovX		= 0;
		m_nDupliMovY		= 0;
		m_bHeaderStart		= TRUE;
		break;
		
	case 70:
		m_bIsSwap			= FALSE;
		break;
		
	case 80:				// X�� �̷�
		m_nMirrorX			= -1;
		break;
		
	case 90:				// Y�� �̷�
		m_nMirrorY			= -1;
		break;
		
	case 30:				// ������ ����
		if(m_bIsRead)
		{
//			::MessageDlg( STDGNALM509, MB_ICONSTOP );
//			m_bCheckSuccess = FALSE; // yhchung 060912 Check Code
		}
		else
			m_bIsRead	= TRUE;
		break;
	case 95:		//End of the header
		if(!m_bHeaderEnd)
		{
			m_bHeaderEnd = TRUE;
			m_bHeaderStart = FALSE;
		}
		break;
	case 97:
		m_nRotate = ROT_NONE;
		m_bSaveRotate = FALSE;
		break;
	case 98:
		m_nRotate = ROT_90;
		m_bSaveRotate = TRUE;
		break;
	}
}

BOOL ExcellonReader::ReadDuplicatePos()
{
	if (!m_listData.IsEmpty() || !m_listLineData.IsEmpty())
	{
		POSITION pos = m_listData.GetHeadPosition();
		while (pos != NULL)
		{
			HOLEDATA drData = m_listData.GetNext(pos);
			m_nNewTCode = drData.nToolNo;
			m_nOCRType = drData.nOCRType;
			m_nPositionX = drData.npPos.x;
			m_nPositionY = drData.npPos.y;
			if(m_bm80m90)
				m_nRotate += drData.nRotate; //20181115
			else
				m_nRotate = drData.nRotate; //20181115
			ReadPosition();
		}

		pos = m_listLineData.GetHeadPosition();
		while (pos != NULL)
		{
			LINEDATA drLine = m_listLineData.GetNext(pos);
			m_nNewTCode = drLine.nToolNo;
			m_nStartX = drLine.npStartPos.x;
			m_nStartY = drLine.npStartPos.y;
			m_nPositionX = drLine.npEndPos.x;
			m_nPositionY = drLine.npEndPos.y;
			ReadLine();
		}
		
		return TRUE;
	}
	else
		return FALSE;
}

void ExcellonReader::ReadPosition()
{
	CString strPos;
	HOLEDATA* pHoleData;
	if (m_nNewMCode != 30)
	{
		if (m_nNewTCode <= 0 || m_nNewTCode >= MAX_TOOL_NO)
		{
			m_bCorrectTool = FALSE;
			return;
		}
		
//		if (m_pExcellon != NULL)
		{
			int nX, nY;
			if (m_bIsSwap == false)
			{
				nX = m_nMirrorX * m_nPositionX + m_nDupliMovX;
				nY = m_nMirrorY * m_nPositionY + m_nDupliMovY;
			}
			else
			{
				nX = m_nMirrorY * m_nPositionY + m_nDupliMovX;
				nY = m_nMirrorX * m_nPositionX + m_nDupliMovY;
			}

			if(m_bToolG93)// ���� ��尡 �ƴϴ�
			{
				if(m_bRepeat == FALSE && m_bStoreData == FALSE)// ���� ��尡 �ƴϴ�
				{
					nX += m_nPositionG93X;
					nY += m_nPositionG93Y;
				}
				if(m_bRepeat == TRUE && m_bStoreData == TRUE)// ���� ���
				{
					nX += m_nPositionG93X;
					nY += m_nPositionG93Y;
				}
			}


		


			if(m_nNewTCode <= 0 || m_nNewTCode > MAX_TOOL_NO)
				m_bCorrectTool = FALSE;
			pHoleData = new HOLEDATA;
			pHoleData->npPos.x = nX;
			pHoleData->npPos.y = nY;

			if(m_bToolG93)// ���� ��尡 �ƴϴ�
			{
				if(m_bRepeat == FALSE && m_bStoreData == TRUE)// ���� ��尡 �ƴϴ�
				{
					pHoleData->npPos.x += m_nPositionG93X;
					pHoleData->npPos.y += m_nPositionG93Y;
				}
			}



			pHoleData->nToolNo = (int)m_nNewTCode;
			pHoleData->nRefToolNo = (int)m_nRefTCode;
//			pHoleData->bSelect = FALSE;
			pHoleData->nRefNo = 1;
			pHoleData->nRotate = m_nRotate;
			pHoleData->nOCRType = m_nOCRType;
			pHoleData->nFidBlock = m_nFidBlock;	//20111123 bskim 
			m_pUnit->m_HoleData.AddTail(pHoleData);
//			m_pExcellon->AddToToolList(m_nNewTCode, dX, dY);
//			m_pExcellon->AddToToolInfoHoles(m_nNewTCode);
			
			//CString strTrace;
			//strTrace.Format(_T("Array No : %d\n"), m_nArrayNo);
			//TRACE(strTrace);

			pHoleData->nArrayNo = m_nArrayNo; //2015.12.02
			m_nArrayNo++;

			if(m_bStoreData)
			{
				HOLEDATA drData;
				drData.npPos.x = nX;
				drData.npPos.y = nY;
				drData.nRotate = m_nRotate;
				drData.nOCRType = m_nOCRType;
				drData.nToolNo = (int)m_nNewTCode;
				drData.nRefToolNo = (int)m_nRefTCode;
				m_RepeatlistData.AddTail(drData);
			}
			else
			{
				m_bOCR = FALSE;
			}
			if(nX > m_nMaxX)
				m_nMaxX = nX;
			if(nX < m_nMinX)
				m_nMinX = nX;	
			if(nY > m_nMaxY)
				m_nMaxY = nY;
			if(nY < m_nMinY)
				m_nMinY = nY;

			if(nX > m_pUnit->m_nMaxX)
				m_pUnit->m_nMaxX = nX;
			if(nX < m_pUnit->m_nMinX)
				m_pUnit->m_nMinX = nX;	
			if(nY > m_pUnit->m_nMaxY)
				m_pUnit->m_nMaxY = nY;
			if(nY < m_pUnit->m_nMinY)
				m_pUnit->m_nMinY = nY;
		}
		if(m_bSaveRotate)
			m_bSaveRotate = FALSE;
		if(m_bm80m90)
			m_bm80m90 = FALSE;


		if(!m_bReadHole)
			m_bReadHole = TRUE;
	}
}

void ExcellonReader::ReadLine()
{
	CString strPos;
	LINEDATA* pLineData;
	if (m_nNewMCode != 30)
	{
		if (m_nNewTCode < 0 || m_nNewTCode >= MAX_TOOL_NO)
			return;
		
		//		if (m_pExcellon != NULL)
		{
			int nX, nY, nEndX, nEndY;
			if (m_bIsSwap == false)
			{
				nX = m_nMirrorX * m_nStartX + m_nDupliMovX;
				nY = m_nMirrorY * m_nStartY + m_nDupliMovY;
				nEndX = m_nMirrorX * m_nPositionX + m_nDupliMovX;
				nEndY = m_nMirrorY * m_nPositionY + m_nDupliMovY;
			}
			else
			{
				nX = m_nMirrorY * m_nStartY + m_nDupliMovY;
				nY = m_nMirrorX * m_nStartX + m_nDupliMovX;
				nEndX = m_nMirrorY * m_nPositionY + m_nDupliMovX;
				nEndY = m_nMirrorX * m_nPositionX + m_nDupliMovY;
			}
			if( nX == nEndX && nY == nEndY )
				return;

			if(m_nLineExtend != 0)
			{
				CPoint newStartP, newEndP;
				newStartP = GetExtendPoint(nX, nY, nEndX, nEndY, TRUE, m_nLineExtend);
				newEndP = GetExtendPoint(nX, nY, nEndX, nEndY, FALSE, m_nLineExtend);
				nX = newStartP.x;
				nY = newStartP.y;
				nEndX = newEndP.x;
				nEndY = newEndP.y;
			}
			
			if(m_nNewTCode <= 0 || m_nNewTCode >= MAX_TOOL_NO)
				m_bCorrectTool = FALSE;

			CPoint OffsetP;
			for(int i = 0; i < m_nLineNo; i++)
			{
				int nStartDist = (int)(-m_nLineDistance * ((m_nLineNo - 1)/ 2.));
				int nDistance = nStartDist + i * m_nLineDistance;

				pLineData = new LINEDATA;
				
				if(m_bZigZag && i%2 == 1)
				{
					OffsetP = GetNormalPointWithDistance(nX, nY, nEndX, nEndY, FALSE, nDistance);
					pLineData->npStartPos.x = OffsetP.x;
					pLineData->npStartPos.y = OffsetP.y;

					OffsetP = GetNormalPointWithDistance(nX, nY, nEndX, nEndY, TRUE, nDistance);
					pLineData->npEndPos.x = OffsetP.x;
					pLineData->npEndPos.y = OffsetP.y;
				}
				else
				{
					OffsetP = GetNormalPointWithDistance(nX, nY, nEndX, nEndY, TRUE, nDistance);
					pLineData->npStartPos.x = OffsetP.x;
					pLineData->npStartPos.y = OffsetP.y;
					
					OffsetP = GetNormalPointWithDistance(nX, nY, nEndX, nEndY, FALSE, nDistance);
					pLineData->npEndPos.x = OffsetP.x;
					pLineData->npEndPos.y = OffsetP.y;
				}

				for(int m=0; m<4; m++)
				{
					for(int n=0; n<2; n++)
					{
						pLineData->nFidIndex[m][n] = -1;
					}
				}

//				pLineData->npStartPos.x = nX;
//				pLineData->npStartPos.y = nY;
//				pLineData->npEndPos.x = nEndX;
//				pLineData->npEndPos.y = nEndY;
				pLineData->nToolNo = (int)m_nNewTCode;
				pLineData->nRefToolNo = (int)m_nRefTCode;
	//			pLineData->bSelect = FALSE;
				pLineData->nRefNo = 1;
				pLineData->nFidBlock = m_nFidBlock;	//20111123 bskim 
				m_pUnit->m_LineData.AddTail(pLineData);
				//			m_pExcellon->AddToToolList(m_nNewTCode, dX, dY);
				//			m_pExcellon->AddToToolInfoHoles(m_nNewTCode);
				
				if(m_bStoreData && i == 0)
				{
					LINEDATA drData;
					drData.npStartPos.x = nX;
					drData.npStartPos.y = nY;
					drData.npEndPos.x = nEndX;
					drData.npEndPos.y = nEndY;
					drData.nToolNo = (int)m_nNewTCode;
					drData.nRefToolNo = (int)m_nRefTCode;
					m_RepeatlistLineData.AddTail(drData);
				}
				if(nX > m_nMaxX)
					m_nMaxX = nX;
				if(nX < m_nMinX)
					m_nMinX = nX;	
				if(nY > m_nMaxY)
					m_nMaxY = nY;
				if(nY < m_nMinY)
					m_nMinY = nY;

				if(nEndX > m_nMaxX)
					m_nMaxX = nEndX;
				if(nEndX < m_nMinX)
					m_nMinX = nEndX;	
				if(nEndY > m_nMaxY)
					m_nMaxY = nEndY;
				if(nEndY < m_nMinY)
					m_nMinY = nEndY;

				if(nX > m_pUnit->m_nMaxX)
					m_pUnit->m_nMaxX = nX;
				if(nX < m_pUnit->m_nMinX)
					m_pUnit->m_nMinX = nX;	
				if(nY > m_pUnit->m_nMaxY)
					m_pUnit->m_nMaxY = nY;
				if(nY < m_pUnit->m_nMinY)
					m_pUnit->m_nMinY = nY;

				if(nEndX > m_pUnit->m_nMaxX)
					m_pUnit->m_nMaxX = nEndX;
				if(nEndX < m_pUnit->m_nMinX)
					m_pUnit->m_nMinX = nEndX;	
				if(nEndY > m_pUnit->m_nMaxY)
					m_pUnit->m_nMaxY = nEndY;
				if(nEndY < m_pUnit->m_nMinY)
					m_pUnit->m_nMinY = nEndY;
			}
		}

		if(!m_bReadHole)
			m_bReadHole = TRUE;
	}
}

BOOL ExcellonReader::IsFiducialMarkExist(double dX, double dY)
{
	if (m_pGlyphExcell->m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetCount() == 0)
		return FALSE;
	LPFIDDATA pFidData;
	POSITION pos = m_pGlyphExcell->m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	while(pos)
	{
		pFidData = m_pGlyphExcell->m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		if (dX == pFidData->npPosition.x && 
			dY == pFidData->npPosition.y)
			return TRUE;
	}
	return FALSE;
}

void ExcellonReader::ReadFiducial(int nFidKind)
{
	if(m_bToolChange || (m_nFidCount > 4))
	{
		m_nFidBlock++;
		m_bToolChange = FALSE;
		m_nFidCount = 1;
	}

	m_bFiducialDataLastRead = TRUE;//20171010

	int nFidNo = m_pGlyphExcell->m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetCount(); //nFidKind].m_PositionData.GetCount();
//	if (IsFiducialMarkExist(m_nPositionX, m_nPositionY))
	//	return;
	BOOL bMultiSkive = FALSE;
	for(int i=0; i < m_nMultiSkiveCount; i++) //MultiSkive-position compare with Multi-Fiducial.
	{
		if(m_bToolG93)
		{
			if(((m_ptSkivePos[i].x + m_nPositionG93X) == m_nPositionX) && ((m_ptSkivePos[i].y + m_nPositionG93Y) == m_nPositionY))
			{
				bMultiSkive = TRUE;
			}
		}
		else
		{
			if((m_ptSkivePos[i].x == m_nPositionX) && (m_ptSkivePos[i].y == m_nPositionY))
			{
				bMultiSkive = TRUE;
			}
		}
	}

	LPFIDDATA pFidData = new FID_DATA;
	memset(pFidData, 0, sizeof(FID_DATA));
	if (m_nNewMCode != 30)
	{
		pFidData->npPosition.x = m_nPositionX;
		pFidData->npPosition.y = m_nPositionY;
		pFidData->cType = FID_FILE_USE;
		pFidData->nFindIndex = nFidNo;
		pFidData->nFidBlock = m_nFidBlock; //20111123 bskim
		pFidData->bSelected = FALSE;
		pFidData->dOffsetZ = 0.0;
		pFidData->bCheckScaleLimit = TRUE;
		pFidData->bUseSensitive = FALSE;


		if(nFidKind == DEFAULT_FID_INDEX)
			pFidData->nFidType = FID_PRIMARY + FID_FIND;	
		else
		{
			pFidData->nFidType = FID_SECONDARY + FID_DRILL;
			//pFidData->nFidType = FID_PRIMARY + FID_FIND + FID_VERIFY;
			pFidData->nToolNo = 0;
		}
		// FID_PRIMARY : Primary ������, FID_SECONDARY : Secondary ������,
		// FID_FIND : Ž���� ������, FID_DRILL : ������ ������,
		// FID_VERIFY : ��ġ������ ������,

		if(m_pDProject->m_bSaveRefFidData)
		{
			pFidData->nCam = m_pDProject->m_pRefFidData->nCam;
			pFidData->dOffsetZ = m_pDProject->m_pRefFidData->dOffsetZ;
			pFidData->bUseSensitive = m_pDProject->m_pRefFidData->bUseSensitive;
//			pFidData->nFidType = m_pDProject->m_pRefFidData->nFidType;
			if(nFidKind == DEFAULT_FID_INDEX)
				pFidData->nToolNo = m_pDProject->m_pRefFidData->nToolNo;
			pFidData->sVisInfo.dAspectRatio = m_pDProject->m_pRefFidData->sVisInfo.dAspectRatio;
			pFidData->sVisInfo.dScoreAngle = m_pDProject->m_pRefFidData->sVisInfo.dScoreAngle;
			pFidData->sVisInfo.dScoreSize = m_pDProject->m_pRefFidData->sVisInfo.dScoreSize;
			pFidData->sVisInfo.dSizeA = m_pDProject->m_pRefFidData->sVisInfo.dSizeA;
			pFidData->sVisInfo.dSizeB = m_pDProject->m_pRefFidData->sVisInfo.dSizeB;
			pFidData->sVisInfo.dSizeC = m_pDProject->m_pRefFidData->sVisInfo.dSizeC;
			pFidData->sVisInfo.nModelType = m_pDProject->m_pRefFidData->sVisInfo.nModelType;
			pFidData->sVisInfo.nPolarity = m_pDProject->m_pRefFidData->sVisInfo.nPolarity;

			for(int i=0; i<4; i++)
			{
				if(nFidKind == DEFAULT_FID_INDEX)
				{
					if(bMultiSkive)
					{
						pFidData->sVisInfo.dBrightness[i] = m_pDProject->m_pRefFidData->sVisInfo.dBrightness[i];
						pFidData->sVisInfo.dContrast[i] = m_pDProject->m_pRefFidData->sVisInfo.dContrast[i];
						pFidData->sVisInfo.nCoaxial[i] = 0;//m_pDProject->m_pRefFidData->sVisInfo.nCoaxial[i];
						pFidData->sVisInfo.nRing[i] = 150;//m_pDProject->m_pRefFidData->sVisInfo.nRing[i];
						pFidData->sVisInfo.nIR[i] = 0;//m_pDProject->m_pRefFidData->sVisInfo.nRing[i];
					}
					else
					{
						pFidData->sVisInfo.dBrightness[i] = m_pDProject->m_pRefFidData->sVisInfo.dBrightness[i];
						pFidData->sVisInfo.dContrast[i] = m_pDProject->m_pRefFidData->sVisInfo.dContrast[i];
						pFidData->sVisInfo.nCoaxial[i] = 50;//m_pDProject->m_pRefFidData->sVisInfo.nCoaxial[i];
						pFidData->sVisInfo.nRing[i] = 0;//m_pDProject->m_pRefFidData->sVisInfo.nRing[i];
						pFidData->sVisInfo.nIR[i] = 0;//m_pDProject->m_pRefFidData->sVisInfo.nRing[i];
					}

				}
				else
				{
					pFidData->sVisInfo.dBrightness[i] = m_pDProject->m_pRefFidData->sVisInfo.dBrightness[i];
					pFidData->sVisInfo.dContrast[i] = m_pDProject->m_pRefFidData->sVisInfo.dContrast[i];
					pFidData->sVisInfo.nCoaxial[i] = 0;//m_pDProject->m_pRefFidData->sVisInfo.nCoaxial[i];
					pFidData->sVisInfo.nRing[i] = 150;//m_pDProject->m_pRefFidData->sVisInfo.nRing[i];
					pFidData->sVisInfo.nIR[i] = 0;//m_pDProject->m_pRefFidData->sVisInfo.nRing[i];
				}

			}
		}
		else
		{
			pFidData->sVisInfo.dAspectRatio = 3;
			pFidData->sVisInfo.dScoreAngle = 10;
			pFidData->sVisInfo.dScoreSize = 3;
			pFidData->sVisInfo.dSizeA = 0.5;
			pFidData->sVisInfo.dSizeB = 0;
			pFidData->sVisInfo.dSizeC = 0;
			pFidData->sVisInfo.nModelType = 1;
			pFidData->sVisInfo.nPolarity = 1;

			if(nFidKind == DEFAULT_FID_INDEX)
			{
				if(bMultiSkive)
				{
					for(int i=0; i<4; i++)
					{
						pFidData->sVisInfo.dBrightness[i] = 0.5;
						pFidData->sVisInfo.dContrast[i] = 0.5;
						pFidData->sVisInfo.nCoaxial[i] = 0;
						pFidData->sVisInfo.nRing[i] = 150;
						pFidData->sVisInfo.nIR[i] = 0;
					}
				}
				else
				{
					for(int i=0; i<4; i++)
					{
						pFidData->sVisInfo.dBrightness[i] = 0.5;
						pFidData->sVisInfo.dContrast[i] = 0.5;
						pFidData->sVisInfo.nCoaxial[i] = 50;
						pFidData->sVisInfo.nRing[i] = 0;
						pFidData->sVisInfo.nIR[i] = 0;
					}
				}

			}
			else
			{
				for(int i=0; i<4; i++)
				{
					pFidData->sVisInfo.dBrightness[i] = 0.5;
					pFidData->sVisInfo.dContrast[i] = 0.5;
					pFidData->sVisInfo.nCoaxial[i] = 0;
					pFidData->sVisInfo.nRing[i] = 150;
					pFidData->sVisInfo.nIR[i] = 0;
				}
			}
		}

		m_pGlyphExcell->m_FiducialData[DEFAULT_FID_INDEX].AddFidData(pFidData); //nFidKind].AddFidData(pFidData);
	}
	
	if(nFidKind == DEFAULT_FID_INDEX)
	{
		if (m_bSetFid == FALSE && m_bSetFid2 == FALSE && !m_bReadHole)
		{
			m_nMinX = m_nPositionX;
			m_nMinY = m_nPositionY;
			m_nMaxX = m_nPositionX;
			m_nMaxY = m_nPositionY;
			m_bSetFid = TRUE;
		}
		else
		{
			if (m_nPositionX > m_nMaxX)
				m_nMaxX = m_nPositionX;
			
			if (m_nPositionX < m_nMinX)
				m_nMinX = m_nPositionX;
			
			if (m_nPositionY > m_nMaxY)
				m_nMaxY = m_nPositionY;
			
			if (m_nPositionY < m_nMinY)
				m_nMinY = m_nPositionY;
		}
		
		if (m_nNewMCode == 30)
			m_bSetFid = TRUE;
	}
	else
	{
		m_pDProject->m_bSkivingMode = TRUE;

		if (m_bSetFid == FALSE && m_bSetFid2 == FALSE && !m_bReadHole)
		{
			m_nMinX = m_nPositionX;
			m_nMinY = m_nPositionY;
			m_nMaxX = m_nPositionX;
			m_nMaxY = m_nPositionY;
			m_bSetFid2 = TRUE;
		}
		else
		{
			if (m_nPositionX > m_nMaxX)
				m_nMaxX = m_nPositionX;
			
			if (m_nPositionX < m_nMinX)
				m_nMinX = m_nPositionX;
			
			if (m_nPositionY > m_nMaxY)
				m_nMaxY = m_nPositionY;
			
			if (m_nPositionY < m_nMinY)
				m_nMinY = m_nPositionY;
		}
		
		if (m_nNewMCode == 30)
			m_bSetFid2 = TRUE;

		m_pDProject->m_pToolCode[0]->m_bUseTool = TRUE;
		m_pDProject->m_pToolCode[0]->m_nToolColor = 0;
	}
}

BOOL ExcellonReader::GetValid(TCHAR character, TCHAR *szString)
{
	int nLen = strlen(szString);
	if (nLen == 0)
		return FALSE;
	
	if (nLen == 1 && szString[0] == _T('Y'))
		return TRUE;
	else if (nLen == 1)
	{
		TRACE(_T("False excellon data file string : %s\n"), szString);
		return FALSE;
	}
	else
	{
		TCHAR ch1 = szString[1];
		
		if ((character == _T('X') && IsNumber(ch1)) || (character == _T('X') && ch1 == _T('Y')))
			return TRUE;
		else if (character == _T('Y') && IsNumber(ch1))
			return TRUE;
		else if (character == _T('M') && IsNumber(ch1))
			return TRUE;
		else if (character == _T('A') || character == _T('B'))
		{
			if (nLen >= 3)
			{
				TCHAR ch2 = szString[2];
				if (IsNumber(ch2) || (ch1 == _T('X') && ch2 == _T('Y')))
					return TRUE;
				else
				{
					TRACE(_T("False excellon data file string : %s\n"), szString);
					return FALSE;
				}
			}
			else if (ch1 == _T('X') || ch1 == _T('Y'))
				return TRUE;
			else
			{
				TRACE(_T("False excellon data file string : %s\n"), szString);
				return FALSE;
			}
		}
		else if (character == _T('T') && IsNumber(ch1))
			return TRUE;
		else if (character == _T('G') && IsNumber(ch1))
			return TRUE;
		else if (character == _T('C') && IsNumber(ch1))
			return TRUE;
		else
		{
			TRACE(_T("False excellon data file string : %s\n"), szString);
			return FALSE;
		}
	}
}

BOOL ExcellonReader::IsNumber(TCHAR cNumber)
{
	if (isdigit((int)cNumber) || cNumber == _T('-') || cNumber == _T('.') || cNumber == _T('+'))
		return TRUE;
	else
		return FALSE;
}

void ExcellonReader::InitData(short nLzs, int nInputUnit)
{
	m_nLzs = nLzs;
	m_nInputUnit = nInputUnit;
	SetMetric();

	m_bReadStart	= TRUE;
	m_nNewTCode		= 0;
	m_nNewMCode		= 0;
	m_nLength		= 0;
	
	m_bRepeat		= FALSE;
	m_bIsSwap		= FALSE;
	m_bStoreData	= FALSE;
	m_nMirrorX		= 1;
	m_nMirrorY		= 1;
	m_bIsRead		= FALSE;
	m_bSetFid		= FALSE;
	m_bSetFid2		= FALSE;
	
	m_nMinX		= INT_MAX;
	m_nMinY		= INT_MAX;
	m_nMaxX		= INT_MIN;
	m_nMaxY		= INT_MIN;

	m_listData.RemoveAll();
	m_listLineData.RemoveAll();
	m_RepeatlistData.RemoveAll();
	m_RepeatlistLineData.RemoveAll();

//	m_pGlyphExcell->RemoveAllHoleData();
//	m_pDProject->InitToolData();

}

void ExcellonReader::ReadTCode()

{
	if (m_pDProject)
	{
		if(m_nNewTCode <= 0 || m_nNewTCode >= MAX_TOOL_NO)
			return;
		m_pDProject->m_pToolCode[m_nNewTCode]->m_bUseTool = TRUE;
		m_pDProject->m_pToolCode[m_nNewTCode]->m_nToolColor = m_nNewTCode;
		m_pDProject->m_pToolCode[m_nNewTCode]->m_nRefToolNo = m_nRefTCode;
	}
	m_bToolG93 = FALSE;
	m_nPositionG93X = 0;
	m_nPositionG93Y = 0;
}

//BOOL ExcellonReader::GetParam(TCHAR* szBuffer, int &nParam1, int &nParam2, int &nParam3, int &nParam4, BOOL &bUse1, BOOL &bUse2, BOOL &bUse3, BOOL &bUse4)
BOOL ExcellonReader::GetParam(TCHAR* szBuffer, double &dParam1, double &dParam2, double &dParam3, double &dParam4, BOOL &bUse1, BOOL &bUse2, BOOL &bUse3, BOOL &bUse4)
{
	int nTotalLen = strlen(szBuffer);
	
	for (int i = 0; i < nTotalLen - 1; i++)
	{
		if(szBuffer[i] == _T('$'))
			m_bOCR = TRUE;
	}

	if(szBuffer[0] == _T('A') || szBuffer[0] == _T('B'))  // Fiducial AX__Y__  or BX__Y__
	{
		int i=0;
		for (i = 0; i < nTotalLen - 1; i++)
			m_szData[i] = szBuffer[i + 1];
		m_szData[i] = _T('\0');
		
//		if(GetXYPos(m_szData, nParam1, nParam2, bUse1, bUse2))
		if(GetXYPos(m_szData, dParam1, dParam2, bUse1, bUse2))
			return TRUE;
		else
			return FALSE;
	}
	else if(szBuffer[0] == _T('C') || szBuffer[0] == _T('T') || szBuffer[0] == _T('M') || szBuffer[0] == _T('G'))
	{
		int nCount = 0;
		BOOL bStart = FALSE;
		int i = 1;
		for(i = 1; i < nTotalLen; i++)
		{
			if((szBuffer[i] >= _T('0') && szBuffer[i] <= _T('9')) || szBuffer[i] == _T('.'))
			{
				bStart = TRUE;
				m_szData[nCount++] = szBuffer[i];
			}
			else if (szBuffer[i] == _T(' '))
			{
				if(bStart)
					break;
			}
			else
				break;
		}
		m_szData[nCount] = _T('\0');
		
		if(bStart == FALSE)
			return FALSE;
		
		if(szBuffer[0] == _T('C'))
//			nParam1 = atof(m_szData) * 1000;
			dParam1 = atof(m_szData) * 1000.0;
		else
//			nParam1 = _wtoi(m_szData);
			dParam1 = atof(m_szData);
		
//		if(szBuffer[0] == _T('M') && nParam1 == 2) // offset  copy (M02X__Y__)
		if(szBuffer[0] == _T('M') && dParam1 == 2) // offset  copy (M02X__Y__)
		{
			bUse1 = TRUE;
			nCount = 0;
			int nStartI = i;
			for (i; i < nTotalLen; i++)
				m_szData[nCount++] = szBuffer[i];
			m_szData[nCount] = _T('\0');
			
//			if(GetXYPos(m_szData, nParam2, nParam3, bUse2, bUse3))
			i = GetXYPos(m_szData, dParam2, dParam3, bUse2, bUse3);
			if(i)
			{
				if(i == nCount)
					return TRUE;
				
				nCount = 0;
				for(i =  i + nStartI; i < nTotalLen; i++)
					m_szData[nCount++] = szBuffer[i];
				m_szData[nCount] = _T('\0');
				
				if(GetRepeatAxisInfo(m_szData))
					return TRUE;
				else
					return FALSE;
			}
			else
				return FALSE;
		}
//		else if(szBuffer[0] == _T('G') && nParam1 > 81 && nParam1 < 86) // Fiducial G82X__Y__
		else if(szBuffer[0] == _T('G') && dParam1 == 91)
		{
			m_bAbsoluteMode = FALSE;
			return TRUE;
		}
		else if(szBuffer[0] == _T('G') && dParam1 == 90)
		{
			m_bAbsoluteMode = TRUE;
			return TRUE;
		}
		else if(szBuffer[0] == _T('G') && dParam1 == 80)
		{
			m_bDrillMode = FALSE;
			return TRUE;
		}
		else if(szBuffer[0] == _T('G') && dParam1 == 81)
		{
			m_bDrillMode = TRUE;
			return TRUE;
		}
		else if(szBuffer[0] == _T('G') && ((dParam1 > 81 && dParam1 < 86) || (dParam1 == 821 || dParam1 == 831))) // Fiducial G82X__Y__
		{
			bUse1 = TRUE;
			nCount = 0;
			for (i; i < nTotalLen; i++)
				m_szData[nCount++] = szBuffer[i];
			m_szData[nCount] = _T('\0');
			
//			if(GetXYPos(m_szData, nParam2, nParam3, bUse2, bUse3))
			if(GetXYPos(m_szData, dParam2, dParam3, bUse2, bUse3))
				return TRUE;
			else
				return FALSE;
		}
		else if(szBuffer[0] == _T('G') && dParam1 == 93) // Fiducial G82X__Y__
		{
			bUse1 = TRUE;
			nCount = 0;
			for (i; i < nTotalLen; i++)
				m_szData[nCount++] = szBuffer[i];
			m_szData[nCount] = _T('\0');

			//			if(GetXYPos(m_szData, nParam2, nParam3, bUse2, bUse3))
			if(GetXYPos(m_szData, dParam2, dParam3, bUse2, bUse3))
				return TRUE;
			else
				return FALSE;
		}

		else if(szBuffer[0] == _T('T')) 
		{
			bUse1 = TRUE;
			for(int i =  0; i < nTotalLen; i++)
			{
				if(szBuffer[i] == _T('C'))
				{
					int nCount = 0;
					for(int k = i + 1; k < nTotalLen; k++)
					{
						if((szBuffer[k] >= _T('0') && szBuffer[k] <= _T('9')) || szBuffer[k] == _T('.'))
							m_szData[nCount++] = szBuffer[k];
						else
							break;
					}
					m_szData[nCount] = _T('\0');
					
//					nParam2 = atof(m_szData) * 1000; // um, inch
				 	dParam2 = atof(m_szData) * 1000.0; // um, inch
					bUse2 = TRUE;
					return TRUE;
				}
			}
			return TRUE;
		}
		else
		{
			bUse1 = TRUE;
			return TRUE;
		}
	}
	else if(szBuffer[0] == _T('X') || szBuffer[0] == _T('Y'))
	{
//		if(GetXYPos(szBuffer, nParam1, nParam2, bUse1, bUse2))
		if(GetXYPos(szBuffer, dParam1, dParam2, bUse1, bUse2))
		{
			for (int i = 0; i < nTotalLen; i++)
			{
				if(i + 2 < nTotalLen && szBuffer[i] == _T('G') && szBuffer[i+1] == _T('8') && szBuffer[i+2] == _T('5'))
				{
					int nCount = 0;
					for(int k = i + 3; k < nTotalLen; k++)
						m_szData[nCount++] = szBuffer[k];
					m_szData[nCount] = _T('\0');

//					if(GetXYPos(m_szData, nParam3, nParam4, bUse3, bUse4))
					if(GetXYPos(m_szData, dParam3, dParam4, bUse3, bUse4))
						return TRUE;
					else
						return FALSE;
				}
			}

			return TRUE;
		}
		else
			return FALSE;
	}
	else if(szBuffer[0] == _T('R'))
	{
		int nCount = 0;
		BOOL bStart = FALSE;
		int i = 1;
		for(i = 1; i < nTotalLen; i++)
		{
			if(szBuffer[i] >= _T('0') && szBuffer[i] <= _T('9'))
			{
				bStart = TRUE;
				m_szData[nCount++] = szBuffer[i];
			}
			else if (szBuffer[i] == _T(' '))
			{
				if(bStart)
					break;
			}
			else
				break;
		}
		m_szData[nCount] = _T('\0');
		
		if(bStart == FALSE)
			return FALSE;
//		nParam1 = _wtoi(m_szData);
		dParam1 = atof(m_szData);
		bUse1 = TRUE;
		if(szBuffer[i] == _T('M'))
		{
			m_bRandM2 = TRUE;
			for(i = i+1; i < nTotalLen; i++)
			{
				if(szBuffer[i] < _T('0') || szBuffer[i] > _T('9'))
					break;
			}
			nCount = 0;
			for (i; i < nTotalLen; i++)
				m_szData[nCount++] = szBuffer[i];
			m_szData[nCount] = _T('\0');
			
//			if(GetXYPos(m_szData, nParam2, nParam3, bUse2, bUse3))
			if(GetXYPos(m_szData, dParam2, dParam3, bUse2, bUse3))
				return TRUE;
			else
				return FALSE;
		}
		else
		{
			nCount = 0;
			for (i; i < nTotalLen; i++)
				m_szData[nCount++] = szBuffer[i];
			m_szData[nCount] = _T('\0');
			
//			if(GetXYPos(m_szData, nParam2, nParam3, bUse2, bUse3))
			if(GetXYPos(m_szData, dParam2, dParam3, bUse2, bUse3))
				return TRUE;
			else
				return FALSE;
		}
	}
	else if(szBuffer[0] == _T('(') && szBuffer[1] == _T('T'))
	{
		int nToolNo = 0;
		int nCount = 0;
		TCHAR szToolNo[BUFMAX];
		TCHAR szHoleCount[BUFMAX];
		memset(szToolNo, NULL, sizeof(szToolNo));
		memset(szHoleCount, NULL, sizeof(szHoleCount));
		szToolNo[0] = szBuffer[2];
		szToolNo[1] = szBuffer[3];
		for(int i =0; i < nTotalLen; i++)
		{
			if(szBuffer[i] == _T('P'))
			{
				for(int j = i; j < nTotalLen; j++)
				{
					if(szBuffer[j] >= _T('0') && szBuffer[j] <= _T('9'))
						szHoleCount[nCount++] = szBuffer[j];
				}
			}
		}
		nToolNo = atoi(szToolNo);
		m_nReadHoleCount[nToolNo] = atoi(szHoleCount);
		m_bCheckHoleCount = TRUE;
		return TRUE;
	}
	else
		return FALSE;
}

//BOOL ExcellonReader::GetXYPos(TCHAR *szBuffer, int &nParam1, int &nParam2, BOOL &bUse1, BOOL &bUse2)
int ExcellonReader::GetXYPos(TCHAR *szBuffer, double &dParam1, double &dParam2, BOOL &bUse1, BOOL &bUse2)
{
	CString strTemp, str1, str2;
	strTemp.Format(_T("%s"), szBuffer);
	int nCheckNULL;
	nCheckNULL = strTemp.Find(_T(" "));
	TCHAR szTemp[BUFMAX];
	memset(szTemp, NULL, sizeof(szTemp));
	//�߰��� NULL�� �����ϴ� ���
	if(nCheckNULL > 0)
	{
		str1 = strTemp.Left(nCheckNULL);

		for(int e = nCheckNULL; e < strTemp.GetLength(); e++)
		{
			if(szBuffer[e] != _T(' '))
			{
				nCheckNULL = e;
				break;
			}
			e++;
		}
		str2 = strTemp.Mid(nCheckNULL);
		str2.TrimRight();
		strTemp.Format(_T("%s%s"),str1, str2);
	
		strcpy_s(szTemp, (LPCTSTR)strTemp);
		memcpy(szBuffer, szTemp, sizeof(szTemp));
	}


	TCHAR	m_TempData[BUFMAX];
	int nTotalLen = strlen(szBuffer);
	if(szBuffer[0] == _T('X'))
	{
		if(szBuffer[1] == _T('Y'))
		{
			int nCount = 0;
			BOOL bStart = FALSE;
			int i = 2;
			for(i = 2; i < nTotalLen; i++)
			{
				if((szBuffer[i] >= _T('0') && szBuffer[i] <= _T('9')) || szBuffer[i] == _T('-') || szBuffer[i] == _T('.'))
				{
					bStart = TRUE;
					m_TempData[nCount++] = szBuffer[i];
				}
				else if (szBuffer[i] == _T(' '))
				{
					if(bStart)
						break;
				}
				else
					break;
			}
			m_TempData[nCount] = _T('\0');
			
			if(bStart == FALSE)
				return FALSE;
			bUse1 = FALSE;
			bUse2 = TRUE;

			if (m_TempData[0] == _T('-'))
				nCount = nCount - 1;
			IsTzs(nCount);
//			nParam2 = _wtoi(m_TempData) * m_lTzsLzs;
			dParam2 = atof(m_TempData) * m_lTzsLzs;
			return i;
		}
		else
		{
			int nCount = 0;
			BOOL bStart = FALSE;
			int i = 1;
			for(i = 1; i < nTotalLen; i++)
			{
				if((szBuffer[i] >= _T('0') && szBuffer[i] <= _T('9')) || szBuffer[i] == _T('-') || szBuffer[i] == _T('.'))
				{
					bStart = TRUE;
					m_TempData[nCount++] = szBuffer[i];
				}
				else if (szBuffer[i] == _T(' '))
				{
					if(bStart)
						break;
				}
				else
					break;
			}
			m_TempData[nCount] = _T('\0');
			
			if(bStart == FALSE)
			{
				bUse1 = FALSE;
			}
			else
			{
				bUse1 = TRUE;
				if (m_TempData[0] == _T('-'))
					nCount = nCount - 1;
				IsTzs(nCount);
//				nParam1 = _wtoi(m_TempData) * m_lTzsLzs;
				if(!m_bAbsoluteMode)
				{
					m_dIncrementalFirstPosX += atof(m_TempData) * m_lTzsLzs;
					dParam1 = m_dIncrementalFirstPosX;
				}
				else
				{
					dParam1 = atof(m_TempData) * m_lTzsLzs;
					m_dIncrementalFirstPosX = dParam1;
				}
				if(!m_bDrillMode)
				{
					bUse1 = FALSE;
				}
			}
			
			BOOL bY = FALSE;
			bStart = FALSE;
			nCount = 0;
			for(i; i < nTotalLen; i++)
			{
				if(bY)
				{
					if((szBuffer[i] >= _T('0') && szBuffer[i] <= _T('9')) || szBuffer[i] == _T('-') || szBuffer[i] == _T('.'))
					{
						bStart = TRUE;
						m_TempData[nCount++] = szBuffer[i];
					}
					else if (szBuffer[i] == _T(' '))
					{
						if(bStart)
							break;
					}
					else if(szBuffer[i] == _T('X') || szBuffer[i] == _T('Y'))
					{
						m_bOverlapXY = TRUE;
						break;
					}
					else
						break;
				}

				if(szBuffer[i] == _T('X'))
				{
					m_bOverlapXY = TRUE;
					break;
				}

				if(szBuffer[i] == _T('Y'))
				{
					bY = TRUE;
				}				
			}
			m_TempData[nCount] = _T('\0');

			if(bY && bStart)
			{
				bUse2 = TRUE;
				if (m_TempData[0] == _T('-'))
					nCount = nCount - 1;
				IsTzs(nCount);
//				nParam2 = atoi(m_TempData) * m_lTzsLzs;
				if(!m_bAbsoluteMode)
				{
					m_dIncrementalFirstPosY += atof(m_TempData) * m_lTzsLzs;
					dParam2 = m_dIncrementalFirstPosY;
				}
				else
				{
					dParam2 = atof(m_TempData) * m_lTzsLzs;
					m_dIncrementalFirstPosY = dParam2;
				}
				if(!m_bDrillMode)
				{
					bUse2 = FALSE;
				}
				
			}
			else
				bUse2 = FALSE;

			if(bUse1 || bUse2)
				return i;
			else
				return FALSE;
		}
	}
	else if(szBuffer[0] == _T('Y'))
	{
		int nCount = 0;
		BOOL bStart = FALSE;
		int i = 1;
		for(i = 1; i < nTotalLen; i++)
		{
			if((szBuffer[i] >= _T('0') && szBuffer[i] <= _T('9')) || szBuffer[i] == _T('-') || szBuffer[i] == _T('.'))
			{
				bStart = TRUE;
				m_TempData[nCount++] = szBuffer[i];
			}
			else if (szBuffer[i] == _T(' '))
			{
				if(bStart)
					break;
			}
			else if(szBuffer[i] == _T('X') || szBuffer[i] == _T('Y'))
			{
				m_bOverlapXY = TRUE;
				break;
			}
			else
				break;
		}
		m_TempData[nCount] = _T('\0');
		
		if(bStart == FALSE)
			return FALSE;
		bUse1 = FALSE;
		bUse2 = TRUE;
		if (m_TempData[0] == _T('-'))
			nCount = nCount - 1;
		IsTzs(nCount);
//		nParam2 = _wtoi(m_TempData) * m_lTzsLzs;
		dParam2 = atof(m_TempData) * m_lTzsLzs;
		return i;
	}
	else
		return FALSE;
}

void ExcellonReader::ReadCCode()
{
	if (m_pDProject)
	{
		m_pDProject->m_pToolCode[m_nNewTCode]->m_nToolSize = 1;//m_nHoleSize;
		m_pDProject->m_pToolCode[m_nNewTCode]->m_nMarkingSize = 1;//m_nHoleSize;
		
	}
}

BOOL ExcellonReader::GetRepeatAxisInfo(TCHAR *szBuffer)
{
	TCHAR	m_TempData[BUFMAX];
	int nTotalLen = strlen(szBuffer);
	
	for(int i = 0; i < nTotalLen; i++)
	{
		if(szBuffer[i] == _T('M'))
		{
			int nCount = 0;
			int j = i + 1;
			BOOL bStart = FALSE;
			for(j = i+1; j < nTotalLen; j++ )
			{
				if((szBuffer[j] >= _T('0') && szBuffer[j] <= _T('9')))
				{
					bStart = TRUE;
					m_TempData[nCount++] = szBuffer[j];
				}
				else if (szBuffer[j] == _T(' '))
				{
					if(bStart)
						break;
				}
				else
				{
					break;
				}
			}
			m_TempData[nCount] = _T('\0');
			
			if(bStart == FALSE)
				return TRUE;
			
			int nVal = atoi(m_TempData);
			if(nVal == 70) 
				m_bRepeatSwap = TRUE;
			else if(nVal == 80)
				m_bRepeatXFlip = TRUE;
			else if(nVal == 90)
				m_bRepeatYFlip = TRUE;
			else
			{
				
			}
			i = j - 1;
		}
	}
	return TRUE;
}

BOOL ExcellonReader::Save(CString strPath, GlyphExcellon* pExcellon, DProject* pProject)
{
	BOOL bRet = FALSE;
	CStdioFile sFile;
	if(!sFile.Open(strPath,CFile::modeCreate|CFile::modeWrite|CFile::typeText))
	{
		CString strMsg;	
		strMsg.Format(_T("Can't Save Excellon Data File"));
		ErrMessage(strMsg, MB_ICONERROR);
		
		return FALSE;
	}
	
	m_pGlyphExcell = pExcellon;
	m_pDProject = pProject;
	int i = 0;
	for(i = 0; i < MAX_TOOL_NO ; i++)
	{
		if(m_pDProject->m_pToolCode[i]->m_bUseTool == TRUE)
			SaveTCCode(sFile, i );
	}
	SaveFiducial(sFile, DEFAULT_FID_INDEX);
	SavePosition(sFile);
	CString str;
	str.Format(_T("M30\n"));
	sFile.WriteString(str);
	
	sFile.Close();
	
	return TRUE;
	
}
void ExcellonReader::SaveTCCode(CStdioFile& sFile, int nTCode)
{

	CString str;
	str.Format(_T("T0%dC%.3f\n"), m_pDProject->m_pToolCode[nTCode]->m_nToolColor, m_pDProject->m_pToolCode[nTCode]->m_nToolSize /1000.0);
	sFile.WriteString((LPCTSTR)str);
}

void ExcellonReader::SaveFiducial(CStdioFile& sFile, int nFidKind)
{
	int nFidNo = m_pGlyphExcell->m_FiducialData[nFidKind].m_PositionData.GetCount();
	if(nFidNo == 0)
		return;
	
	LPFIDDATA pFidData;
	POSITION pos;
	pos = m_pGlyphExcell->m_FiducialData[nFidKind].m_PositionData.GetHeadPosition();
	
	int i = 0;
	CString str;
	int nx, ny;
	while(pos)
	{
		pFidData = m_pGlyphExcell->m_FiducialData[nFidKind].m_PositionData.GetNext(pos);
		nx = pFidData->npPosition.x;
		ny = pFidData->npPosition.y;
		str.Format(_T("AX%dY%d\n"), nx, ny);
		sFile.WriteString((LPCTSTR)str);
	}
}

void ExcellonReader::SaveTCode(CStdioFile& sFile, int nToolNo)
{
	CString str;
	str.Format(_T("T%d\n"),nToolNo);
	sFile.WriteString((LPCTSTR)str);
}
void ExcellonReader::SavePosition(CStdioFile& sFile)
{
	//	ResetHoleData();
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		DAreaInfo* pAreaInfo;
		POSITION pos = m_pDProject->m_Areas[i].GetHeadPosition();
		int nAreaNo = 0;
		while (pos)
		{
			pAreaInfo = m_pDProject->m_Areas[i].GetNext(pos);
			if(IsInHoleData(pAreaInfo, i))
			{
				CollectHoleData(sFile, pAreaInfo, i);
			}
			nAreaNo++;
		}
	}
	
	SaveHoleData(sFile);
}

void ExcellonReader::SaveHoleData(CStdioFile &sFile)
{	
	HOLEDATA* pHole;
	BOOL bSaveTool = FALSE;
	
	int nx, ny;
	CString str;
	
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		
		POSITION pos = m_pCollectHoleList[i].GetHeadPosition();
		while (pos)
		{
			
			pHole = m_pCollectHoleList[i].GetNext(pos);
			
			if(!bSaveTool)
			{
				SaveTCode(sFile, i);
				bSaveTool = TRUE;
			}
			
			nx = pHole->npPos.x;
			ny = pHole->npPos.y;
			str.Format(_T("X%dY%d\n"), nx, ny);
			sFile.WriteString((LPCTSTR)str);
		}
		bSaveTool = FALSE;
	}

	//save line
	
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		bSaveTool = FALSE;
		LPFIRELINE pLine;
		DAreaInfo* pAreaInfo;
		POSITION pos = m_pDProject->m_Areas[i].GetHeadPosition();
		int nAreaNo = 0;
		while (pos)
		{
			pAreaInfo = m_pDProject->m_Areas[i].GetNext(pos);

			POSITION dataPos = pAreaInfo->m_FireLines[i].GetHeadPosition();
			while(dataPos)
			{
				if(!bSaveTool)
				{
					SaveTCode(sFile, i);
					bSaveTool = TRUE;
				}
				pLine = pAreaInfo->m_FireLines[i].GetNext(dataPos);
				
				if(!pLine->bSelect)
					continue;

				str.Format(_T("X%dY%dG85X%dY%d\n"), pLine->pOrigin->npStartPos.x, pLine->pOrigin->npStartPos.y,
												pLine->pOrigin->npEndPos.x, pLine->pOrigin->npEndPos.y);
				sFile.WriteString((LPCTSTR)str);
			}
		}
	}
	
}

BOOL ExcellonReader::IsInHoleData(DAreaInfo* pAreaInfo, int nTool)
{
	POSITION pos;
	pos = pAreaInfo->m_FireHoles[nTool].GetHeadPosition();
	
	if(pos == NULL)
		return FALSE;
	
	return TRUE;
}

void ExcellonReader::CollectHoleData(CStdioFile &sFile, DAreaInfo* pAreaInfo, int nToolNo)
{
	POSITION pos;
	LPFIREHOLE pHole;
	
	CString str;
	int nx, ny;
	int nRealTool;
	pos = pAreaInfo->m_FireHoles[nToolNo].GetHeadPosition();
	
	while (pos) 
	{
		pHole = pAreaInfo->m_FireHoles[nToolNo].GetNext(pos);
		
		if(!pHole->bSelect)
			continue;
		nRealTool = pHole->pOrigin->nToolNo;
		nx = pHole->pOrigin->npPos.x;
		ny = pHole->pOrigin->npPos.y;
		
		AddHoleList(nRealTool, nx, ny);
	}
}

void ExcellonReader::AddHoleList(int nRealTool, int nx, int ny)
{
	HOLEDATA* pTemp = new HOLEDATA;
	pTemp->npPos.x = nx;
	pTemp->npPos.y = ny;
	
	m_pCollectHoleList[nRealTool].AddTail(pTemp);
}

void ExcellonReader::RemoveNodataFiducial()
{
	LPFIDDATA pFidData;
	POSITION pos =m_pGlyphExcell->m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetHeadPosition();
	POSITION posBefore = pos;
	while (pos)
	{
		pFidData = m_pGlyphExcell->m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.GetNext(pos);
		if(pFidData->nFidBlock == m_nFidBlock)
		{
			m_pGlyphExcell->m_FiducialData[DEFAULT_FID_INDEX].m_PositionData.RemoveAt(posBefore);
			delete pFidData;
		}
		
		posBefore = pos;
	}
}

CPoint ExcellonReader::GetNormalPointWithDistance(int nStartX, int nStartY, int nEndX, int nEndY, BOOL bStart, int nDist)
{
	double x,y,c,e; // a,b �� ����, y=cx+d, y=ex+f
	CPoint retP;
	retP.x = INT_MAX;
	if(nStartX == nEndX && nStartY == nEndY)			// ������ �ƴ� ��� 
		return retP;

	if(bStart)
	{
		retP.x = nStartX; retP.y = nStartY;
	}
	else
	{
		retP.x = nEndX; retP.y = nEndY;
	}
	
	if(nStartX == nEndX)
	{
		if(nEndY > nStartY) // ���� ���� ������ ���
			retP.x = retP.x + nDist;
		else
			retP.x = retP.x - nDist;
	}
	else if(nStartY == nEndY)
	{
		if(nEndX > nStartX) // x�� +�������� ���� ���
			retP.y = retP.y - nDist;
		else
			retP.y = retP.y + nDist;
	}
	else
	{
		c = (double)(nEndY - nStartY)/(nEndX - nStartX);
		e = -1/c;
		x = sqrt(nDist*nDist/(1+e*e));
		y = x*e;
		if(nEndY - nStartY>0)
		{
			retP.x = retP.x + (LONG)x;
			retP.y = retP.y + (LONG)y;//.Set(refP.x-x, refP.y-y);	
		}
		else
		{
			retP.x = retP.x - (LONG)x;
			retP.y = retP.y - (LONG)y;
			//reP.Set(refP.x+x, refP.y+y);
		}
		
	}
	return retP;
}

CPoint ExcellonReader::GetExtendPoint(int nStartX, int nStartY, int nEndX, int nEndY, BOOL bStart, int nDist)
{
	double x,y,c;
	CPoint retP;
	retP.x = INT_MAX;
	if(nStartX == nEndX && nStartY == nEndY)			// ������ �ƴ� ��� 
		return retP;
	
	if(bStart)
	{
		retP.x = nStartX; retP.y = nStartY;
	}
	else
	{
		retP.x = nEndX; retP.y = nEndY;
	}
	
	if(nStartX == nEndX)
	{
		if(nEndY > nStartY) // ���� ���� ������ ���
		{
			if(bStart)
				retP.y = retP.y - nDist;
			else
				retP.y = retP.y + nDist;
		}
		else
		{
			if(bStart)
				retP.y = retP.y + nDist;
			else
				retP.y = retP.y - nDist;
		}
	}
	else if(nStartY == nEndY)
	{
		if(nEndX > nStartX) // x�� +�������� ���� ���
		{
			if(bStart)
				retP.x = retP.x - nDist;
			else
				retP.x = retP.x + nDist;
		}
		else
		{
			if(bStart)
				retP.x = retP.x - nDist;
			else
				retP.x = retP.x + nDist;
		}
	}
	else
	{
		c = (double)(nEndY - nStartY)/(nEndX - nStartX);
		x = nDist / sqrt(1+c*c);
		y = x*c;
		if(bStart)
		{
			retP.x = retP.x - (LONG)x;
			retP.y = retP.y - (LONG)y;//.Set(refP.x-x, refP.y-y);	
		}
		else
		{
			retP.x = retP.x + (LONG)x;
			retP.y = retP.y + (LONG)y;
			//reP.Set(refP.x+x, refP.y+y);
		}
		
	}
	return retP;
}
BOOL ExcellonReader::HeaderSetting(TCHAR *szBuffer)
{

	if (StrStrI(szBuffer, "METRIC") != 0)
	{
		if(szBuffer[6] == _T(',') || szBuffer[7] == _T('\0'))
		{
			m_dlgExcellon.m_nUnit = 0;
			SetMetric();
			if(StrStrI(szBuffer, _T("TZ")) != 0)
			{
				m_dlgExcellon.m_nTZS = 0;
				return TRUE;
			}
			else if(StrStrI(szBuffer, "LZ") != 0)
			{
				m_dlgExcellon.m_nTZS = 1;
				return TRUE;
			}
		}

	}
	else if (StrStrI(szBuffer, "INCH") != 0)
	{
		if(szBuffer[4] == _T(',') || szBuffer[5] == _T('\0'))
		{
			m_dlgExcellon.m_nUnit = 4;
			if(StrStrI(szBuffer, "TZ") != 0)
			{
				m_dlgExcellon.m_nTZS = 0;
				return TRUE;
			}
			else if(StrStrI(szBuffer, _T("LZ")) != 0)
			{
				m_dlgExcellon.m_nTZS = 1;
				return TRUE;
			}
		}
	}
	return FALSE;
}
// TempINIFile.h: interface for the CTempINIFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEMPINIFILE_H__7A8E08FD_C699_4B51_AD8D_519D09ED6CC1__INCLUDED_)
#define AFX_TEMPINIFILE_H__7A8E08FD_C699_4B51_AD8D_519D09ED6CC1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
class DTempINI;

class CTempINIFile  
{
public:
	void WriteLog(CString strLog);
	BOOL SaveTime(CStdioFile& sFile, DTempINI clsTempINI);
	BOOL ParsingTime(CStdioFile& sFile, DTempINI& clsTempINI);
	BOOL SaveTempINIFile(CString strFilePath, DTempINI clsTempINI);
	BOOL OpenTempINIFile(CString strFilePath, DTempINI& clsTempINI);
	CTempINIFile();
	virtual ~CTempINIFile();

};

#endif // !defined(AFX_TEMPINIFILE_H__7A8E08FD_C699_4B51_AD8D_519D09ED6CC1__INCLUDED_)

// 2DTransform.h: interface for the C2DTransform class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_2DTRANSFORM_H__BA247308_AC4C_42E2_9292_694774142785__INCLUDED_)
#define AFX_2DTRANSFORM_H__BA247308_AC4C_42E2_9292_694774142785__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DPoint.h"
#include <AFXTEMPL.H>

typedef CArray<int,int> CIntArray;

class C2DTransform  
{
public:
	double GetTransAngle();
	CDPoint GetStrechPoint(double x, double y);
	CDPoint GetRefsPoint(int nIndex);
	CDPoint GetTransPoint(int i);
	int GetNumPoint();
	double m_dAngle;
	double m_dYOffset;
	double m_dXOffset;
	double m_dDeltaLength;
	double m_dRefLength;
	BOOL	m_bUseScaleLimit;
	C2DTransform();
	virtual ~C2DTransform();

	double CalAngleMaxPi(CDPoint InPo1, CDPoint InPo2, CDPoint InPo3);
	bool isEqualAngle(double x, double y);
	bool SetNumPoint(int nNum);

	bool SetReferencePoint(double x, double y, int nIndex);
	bool SetTransformedPoint(double x, double y, int nIndex);

	bool Transform();
	void SetCheckScaleLimit(BOOL bUse);

	void TransformPoint(const double x, const double y, double& dXVal, double& dYVal);

//	bool IsValid()				{return !m_bNotReady;};

protected:
//	volatile bool	m_bNotReady;

	int		m_nNumPoint;
	int		m_nNumConvexHullPoint;

	DPOINT*	m_ptRef;
	DPOINT* m_ptTran;

	double*	m_XCal;
	double*	m_YCal;

	int*	m_pnLargeArea;
	int		m_nLargeArea;

	double*	m_VectCal;
	DPOINT*	m_ptVecCal;
	double*	m_VecXCal;
	double*	m_VecYCal;

	CIntArray m_ConvexIndex;

	void ClearMemory();

	bool AffineTransform();

	bool LUGetVal(double* Mat, int* Vec, double* Cal, int nDim);
	bool LUDecomp(double* Mat, int* Vec, int& nParity, int nDim);

	int	MakeConvexHull();
	bool PrepareForConvexHull();
	int GetCCW(double ax, double ay, double bx, double by, double cx, double cy);
	bool GetLargestArea();
	int Combination(int n, int r);
	bool SetCombinationIndex(int n, int r, int nCount, int* pnTot, int* pnArray);
	double GetRectArea(int* pnList);
	DPOINT IntermediateTransformPoint(const double& x, const double& y);
	void AffineTransformPoint(const double x, const double y, double& dXVal, double& dYVal);
};

#endif // !defined(AFX_2DTRANSFORM_H__BA247308_AC4C_42E2_9292_694774142785__INCLUDED_)

// HOLECONVERTDATA.h: interface for the HOLECONVERTDATA class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HOLECONVERTDATA_H__A033FCBB_1084_4E11_8717_6FC651771DDF__INCLUDED_)
#define AFX_HOLECONVERTDATA_H__A033FCBB_1084_4E11_8717_6FC651771DDF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <afxtempl.h>

#include "HOLEDATA.h"

class HOLECONVERTDATA  
{
public:
	HOLECONVERTDATA();
	virtual ~HOLECONVERTDATA()	
	{
	};

	void operator delete(void* p);
	void* operator new(size_t nSize);
	void* operator new(size_t nSize, LPCSTR lpszFileName, int nLine);
	void  operator delete(void* p, LPCSTR lpszFileName, int nLine);

	LPHOLEDATA	pOrigin;
	CPoint		npPos1;
	CPoint		npPos2;
	BOOL		bSelect;
//	int			nUnitIndex;
	BOOL		bDistanceSortingFinish;
	HOLECONVERTDATA*   pNext;
	HOLECONVERTDATA*	pBefore;
	
	static HANDLE s_hHeapCvt;
	
	static UINT   s_uNumAllocsInHeapCvt;
};

typedef HOLECONVERTDATA* LPFIREHOLE;

class FireHoleList
{
public:
	void RemoveAt(POSITION pos);
	void RemoveAll();
	void AddTail(LPFIREHOLE pData);
	void AddHead(LPFIREHOLE pData);
	LPFIREHOLE GetNext(POSITION& pos);
	LPFIREHOLE GetPrev(POSITION& pos);
	POSITION GetHeadPosition();
	POSITION GetTailPosition();
	int GetCount();
	FireHoleList();
	virtual ~FireHoleList();
	
private:
	HOLECONVERTDATA* m_pHeadHoleConvertData;
	HOLECONVERTDATA* m_pTailHoleConvertData;
	int m_nCount;
};

#endif // !defined(AFX_HOLECONVERTDATA_H__A033FCBB_1084_4E11_8717_6FC651771DDF__INCLUDED_)

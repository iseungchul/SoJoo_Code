// DFidData.h: interface for the DFidData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DFIDDATA_H__E9C977F2_4D88_41AE_A519_809525942779__INCLUDED_)
#define AFX_DFIDDATA_H__E9C977F2_4D88_41AE_A519_809525942779__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define MAX_FID_BLOCK		50 

#include "DPoint.h"
struct VISION_INFO
{
	int		nModelType;
	int		nPolarity;
	double	dSizeA;
	double	dSizeB;
	double	dSizeC;
	//	double	dOrientation;
	int		nCoaxial[4];
	int		nRing[4];
	int		nBlob[4];  
	int		nIR[4];
	double	dContrast[4];
	double	dBrightness[4];
	double	dScoreAngle;
	double	dScoreSize;
	double	dAspectRatio;
	int		nThreshold;

};

struct FID_DATA {
	CPoint	npPosition;			// um
	CPoint	npTransPosition;	// um
	CPoint	npTransPosition2;	// um
	CPoint  npTablePos1;		// 20130312
	CPoint	npTablePos2;
	
	BYTE	cType;

	int		nFindIndex;
	BOOL	bCheckIndex; // ã�� fiducial�̸� select���� �� (& 1)�̸� ã��, visible ���� �� (& 2)�� ã�´�. (and �����ؾ� ��)
	BOOL	bSelect; // skiving select

// 110513
	// Cameara ��ȣ
	int		nCam; // HIGH_CAM, LOW_CAM, LOW_TO_HIGH_CAM

	// Vision����
	VISION_INFO sVisInfo;

	// Fiducial ����
	int		nFidType;	// FID_PRIMARY : Primary ������, FID_SECONDARY : Secondary ������,
						// FID_FIND : Ž���� ������, FID_DRILL : ������ ������,
						// FID_VERIFY : ��ġ������ ������,
	
	// Z�� Offset
	double dOffsetZ; // Fiducial�� Z�� Ž�� �ɼ�

	// Tool ��ȣ
	int		nToolNo;

	// ���� ���ÿ�
	BOOL	bSelected;
	
	// �� Panel���� �ν� ����
	BOOL	bAcquire[2]; // 1stPanel, 2ndPanel
	int		nFidBlock;

	BOOL	bCheckScaleLimit;
	BOOL	bUseSensitive;

};

typedef	FID_DATA*	LPFIDDATA;

typedef CTypedPtrList <CPtrList, LPFIDDATA>	FidDataList;

struct FID_RESULT
{
	int		nFindIndex;				// sorted index
	CPoint	npRefPosition;			// um
//	DPOINT	dpGetPosition;			// um
	CPoint  npOffset;
	double	dScale;					// to Next Fid
	CPoint	npScaleDPPos;			// um
	int		nFidBlock;
	BOOL	bFound;
	int		nFidKind;
};

typedef FID_RESULT* LPFIDRESULT;

typedef CTypedPtrList <CPtrList, LPFIDRESULT> FidResultList;

struct PNLFID_INFO
{
	BOOL b1st;
	int nPanelNo;
	int	nNGType;				// default : 0;
	FidResultList FidResult;
	BOOL bReverse;
	BOOL bFidBlockFoundAll[MAX_FID_BLOCK];
};

typedef PNLFID_INFO* LPPNLFIDINFO;

typedef CTypedPtrList <CPtrList, LPPNLFIDINFO> PanelFidResultList;

class DFidData  
{
public:
	LPPNLFIDINFO GetPanelReverse(int nIndex, BOOL b1st);
	int GetPanelCount();
	BOOL IsFidFound(int nPanelNo,  CPoint npFilePos );
	LPFIDRESULT GetFidResult(LPPNLFIDINFO pPanel, CPoint npFilePos, int nFidBlock);
	LPFIDRESULT GetFidResult(LPPNLFIDINFO pPanel, int nFidNo, int nFidBlock);
	LPFIDRESULT GetFidResult(int nPanelNo, CPoint npFilePos ,  int nFidBlock);
	void RemovePanel();
	void RemoveFidResult(int nPanelIndex);
	void AddPanel(LPPNLFIDINFO Panel);
	void AddFidResult(int nPanelIndex, LPFIDRESULT sResult, LPPNLFIDINFO pPanel);
	LPPNLFIDINFO GetPanel(int nIndex, BOOL b1st);
	LPFIDDATA GetFidData(int nIndex);
	void SetFidIndex(int nIndex, int nVal);
	int GetFidNo();
	void AddFidData(LPFIDDATA pFidData);
	void RemoveFidData();
	DFidData();
	virtual ~DFidData();

	FidDataList m_PositionData;

	PanelFidResultList m_PanelFid;

	int			nRef; // ������ ���� ������

	void SetFidCamNum(int nIndex, int nCam);
	int	 GetFidCamNum(int nIndex);

	void SetFidVisInfo(int nIndex, VISION_INFO sVisInfo);
	VISION_INFO GetFidVisInfo(int nIndex);
};

#endif // !defined(AFX_DFIDDATA_H__E9C977F2_4D88_41AE_A519_809525942779__INCLUDED_)

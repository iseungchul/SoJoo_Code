// DPoint.cpp: implementation of the CDPoint class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DPoint.h"
#include "math.h"

//////////////////////////////////////////////////////////////////////
// CDPoint Class
//====================================================================
// Constructors & Destructor
//====================================================================
CDPoint::CDPoint( void )
{
	x = 0;
	y = 0;
}
//--------------------------------------------------------------------
CDPoint::CDPoint( const DPOINT& pt )
{
	x = pt.x;
	y = pt.y;
}
//--------------------------------------------------------------------
CDPoint::CDPoint( double xpos, double ypos )
{
	x = xpos;
	y = ypos;
}
//--------------------------------------------------------------------
CDPoint::CDPoint( const CDPoint& pt )
{
	x = pt.x;
	y = pt.y;
}
//====================================================================
// Operators
//====================================================================
void CDPoint::operator=( LPPOINT lpPoint )
{
	x = lpPoint->x;
	y = lpPoint->y;
}
//--------------------------------------------------------------------
void CDPoint::operator=( LPDPOINT lpPoint )
{
	x = lpPoint->x;
	y = lpPoint->y;
}
//--------------------------------------------------------------------
void CDPoint::operator+=( LPDPOINT lpPoint )
{
	x += lpPoint->x;
	y += lpPoint->y;
}
//--------------------------------------------------------------------
void CDPoint::operator+=( const CDPoint& pt )
{
	x += pt.x;
	y += pt.y;
}
//--------------------------------------------------------------------
CDPoint::operator LPDPOINT( void )
{
	return this;
}

//////////////////////////////////////////////////////////////////////
void CDPoint::rotateRadian(CDPoint center ,double angle)//radian ��
{   // Counter Clock wise
	double cosTheta, sinTheta;
	double tempx;
	
	cosTheta = cos(angle);
	sinTheta = sin(angle);
	tempx = cosTheta*(x-center.x) - sinTheta*(y-center.y)+center.x;
	y = sinTheta*(x-center.x)+cosTheta*(y-center.y)+center.y;
	x = tempx;
}

void CDPoint::Set(double refx, double refy)
{
	x = refx;
	y = refy;
}
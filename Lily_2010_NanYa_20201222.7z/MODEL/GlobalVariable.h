// GlobalVariable.h: interface for the GlobalVariable class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GLOBALVARIABLE_H__B713DA39_3F21_4AB5_B176_24A4300CC61D__INCLUDED_)
#define AFX_GLOBALVARIABLE_H__B713DA39_3F21_4AB5_B176_24A4300CC61D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\model\ToolCodeList.h"
#include "..\model\RefuseList.h"

class GlobalVariable  
{
public:
	void SetPath();
	GlobalVariable();
	virtual ~GlobalVariable();
	void Initialize();

	SGLOBALVARIABLE		m_sGlobal;
	CToolCodeList* m_pToolCode[MAX_TOOL_NO];

	CString m_strPath;
	int m_nVersion;

	BOOL SaveGlobalTool();
	BOOL LoadGlobalTool();
	void Serialize(CArchiveMark& ar, int nVersion, int nMode = 0);

	CRefuseList* m_pRefuse;

	CString m_strPath2;
	int m_nVersion2;

	BOOL m_bOpenProject;

	BOOL SaveRefuseList();
	BOOL LoadRefuseList();

	BOOL m_bStartEasyDrillerDlg;
	int m_nGlobalDummyType;

	BOOL m_bGrobalDutyOffsetCompenMode;

	BOOL m_bSaveRawFailImage;

	BOOL m_bDoSenstiveFidFind;
	BOOL m_bGrobAndNoDisplay;
	
	BOOL m_bTimming_SoldMarking;
	BOOL IsOkLotSchedule();

	int	m_nSelectFidNo;
	int m_nSelectBlockNo;
	int m_nSelectHead;

	int m_nMachineMode;

	CString m_strBackupLaserComp;
	CString m_strBackupLaserSold;
	CString m_strBackupRecipeComp;
	CString m_strBackupRecipeSold;
	SSHOTGROUPTABLE		m_sgShotGroupTable;
	SSHOTGROUPTABLE		m_sgTempShotGroupTable;
	SSHOTGROUPTABLE		m_sgShotGroupTablePower;


	SBEAMPATH		m_sgBeamPath;
	SBEAMPATH		m_sgTempBeamPath;


	double GetLMDuty_us(int nFrq ,double dDutyPercent);//20160627
	void GetMinMaxPower(double dTagetPower,double dTol ,double &dMin,double &dMax);
	BOOL  IsValidateTableModulationData(SBEAMPATH sBeampath,SSHOTGROUPTABLE sShotGroupTable,BOOL bPowerCompen = FALSE);
	BOOL  IsValidateTableModulationPowerCompen(int nHeadMode,double dNewDutyOffset1,double dNewDutyOffset2,int nToolTableNo, double dNewOntimeOffset1, double dNewOntimeOffset2);

	double m_dGlobal_FidScaleX[2];
	double m_dGlobal_FidScaleY[2];
};

extern GlobalVariable gVariable;

#endif // !defined(AFX_GLOBALVARIABLE_H__B713DA39_3F21_4AB5_B176_24A4300CC61D__INCLUDED_)

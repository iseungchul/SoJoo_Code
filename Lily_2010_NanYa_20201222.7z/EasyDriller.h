// EasyDriller.h : main header file for the EASYDRILLER application
//

#if !defined(AFX_EASYDRILLER_H__EDBCFE17_0CBD_4E9C_9E28_6797182CCCDA__INCLUDED_)
#define AFX_EASYDRILLER_H__EDBCFE17_0CBD_4E9C_9E28_6797182CCCDA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "sysdef.h"
#include "EasyDrillerDlg.h"

extern BOOL ScanSys(CString GetStr, TCHAR strCmp[], double &fValue);
extern BOOL ScanSys(CString GetStr, TCHAR strCmp[], int &Value);
extern BOOL ScanSys(CString GetStr, TCHAR strCmp[], long &Value);
extern BOOL ScanSys(CString GetStr, TCHAR strCmp[], CString& Target);

extern void ErrMsgDlg(int nID, CString strPlus = _T(""));
extern int ErrMessage(CString StrMessage,  UINT nType = MB_OK, BOOL bLog = TRUE);
extern int ErrMessage(int nMessage, UINT nType = MB_OK, BOOL bLog = TRUE);
extern void MessageLoopWait(UINT nWaitms);
extern DWORD	HextoNum(TCHAR *hex);

extern HANDLE g_hLogFile;
extern HANDLE g_hLotFile;

#ifdef USE_VISION_PRO
	#include "device\VProData.h"
	#include "device\ProcessData.h"

	extern VProData gVPro;
	extern VProData gVPro_Temp[CAM_TOT_COUNT];
	extern ProcessData gProcess;
#endif

extern BOOL gFidFindExposure;

/////////////////////////////////////////////////////////////////////////////
// CEasyDrillerApp:
// See EasyDriller.cpp for the implementation of this class
//
class CEasyDrillerDlg;

class CEasyDrillerApp : public CWinApp
{
public:
	CEasyDrillerApp();

	void		CheckWorkDir();
	CString		m_strWorkDir;
	BOOL		m_bStartEasyDrillerDlg;

	HINSTANCE m_hInstanceLanguage;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEasyDrillerApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CEasyDrillerApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

extern CEasyDrillerDlg *theDlg;
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EASYDRILLER_H__EDBCFE17_0CBD_4E9C_9E28_6797182CCCDA__INCLUDED_)

// DlgLaserHeightSet.cpp : implementation file
//

#include "stdafx.h"
#include "easydriller.h"
#include "DlgLaserHeightSet.h"
#include "Model\DSystemINI.h"
#include "model\deasydrillerini.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgLaserHeightSet dialog


CDlgLaserHeightSet::CDlgLaserHeightSet(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgLaserHeightSet::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgLaserHeightSet)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgLaserHeightSet::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgLaserHeightSet)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Text(pDX, IDC_EDIT1, m_d1stLaserHeight[0]);
	DDX_Text(pDX, IDC_EDIT2, m_d1stLaserHeight[1]);
	DDX_Text(pDX, IDC_EDIT3, m_d1stLaserHeight[2]);
	DDX_Text(pDX, IDC_EDIT4, m_d1stLaserHeight[3]);
	DDX_Text(pDX, IDC_EDIT5, m_d1stLaserHeight[4]);
	DDX_Text(pDX, IDC_EDIT6, m_d1stLaserHeight[5]);
	DDX_Text(pDX, IDC_EDIT7, m_d1stLaserHeight[6]);
	DDX_Text(pDX, IDC_EDIT8, m_d1stLaserHeight[7]);
	DDX_Text(pDX, IDC_EDIT9, m_d1stLaserHeight[8]);
	DDX_Text(pDX, IDC_EDIT10, m_d1stLaserHeight[9]);
	
	DDX_Text(pDX, IDC_EDIT11, m_d2ndLaserHeight[0]);
	DDX_Text(pDX, IDC_EDIT12, m_d2ndLaserHeight[1]);
	DDX_Text(pDX, IDC_EDIT13, m_d2ndLaserHeight[2]);
	DDX_Text(pDX, IDC_EDIT14, m_d2ndLaserHeight[3]);
	DDX_Text(pDX, IDC_EDIT15, m_d2ndLaserHeight[4]);
	DDX_Text(pDX, IDC_EDIT16, m_d2ndLaserHeight[5]);
	DDX_Text(pDX, IDC_EDIT17, m_d2ndLaserHeight[6]);
	DDX_Text(pDX, IDC_EDIT18, m_d2ndLaserHeight[7]);
	DDX_Text(pDX, IDC_EDIT19, m_d2ndLaserHeight[8]);
	DDX_Text(pDX, IDC_EDIT20, m_d2ndLaserHeight[9]);

	DDX_Text(pDX, IDC_EDIT21, m_d1stLaserHeightTophat[0]);
	DDX_Text(pDX, IDC_EDIT22, m_d1stLaserHeightTophat[1]);
	DDX_Text(pDX, IDC_EDIT23, m_d1stLaserHeightTophat[2]);
	DDX_Text(pDX, IDC_EDIT24, m_d1stLaserHeightTophat[3]);
	DDX_Text(pDX, IDC_EDIT25, m_d1stLaserHeightTophat[4]);
	DDX_Text(pDX, IDC_EDIT26, m_d1stLaserHeightTophat[5]);
	DDX_Text(pDX, IDC_EDIT27, m_d1stLaserHeightTophat[6]);
	DDX_Text(pDX, IDC_EDIT28, m_d1stLaserHeightTophat[7]);
	DDX_Text(pDX, IDC_EDIT29, m_d1stLaserHeightTophat[8]);
	DDX_Text(pDX, IDC_EDIT30, m_d1stLaserHeightTophat[9]);

	DDX_Text(pDX, IDC_EDIT31, m_d2ndLaserHeightTophat[0]);
	DDX_Text(pDX, IDC_EDIT32, m_d2ndLaserHeightTophat[1]);
	DDX_Text(pDX, IDC_EDIT33, m_d2ndLaserHeightTophat[2]);
	DDX_Text(pDX, IDC_EDIT34, m_d2ndLaserHeightTophat[3]);
	DDX_Text(pDX, IDC_EDIT35, m_d2ndLaserHeightTophat[4]);
	DDX_Text(pDX, IDC_EDIT36, m_d2ndLaserHeightTophat[5]);
	DDX_Text(pDX, IDC_EDIT37, m_d2ndLaserHeightTophat[6]);
	DDX_Text(pDX, IDC_EDIT38, m_d2ndLaserHeightTophat[7]);
	DDX_Text(pDX, IDC_EDIT39, m_d2ndLaserHeightTophat[8]);
	DDX_Text(pDX, IDC_EDIT40, m_d2ndLaserHeightTophat[9]);
	
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgLaserHeightSet, CDialog)
	//{{AFX_MSG_MAP(CDlgLaserHeightSet)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgLaserHeightSet message handlers

BOOL CDlgLaserHeightSet::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	if(gSystemINI.m_sHardWare.nLaserType != LASER_CO2)
	{
		GetDlgItem(IDC_EDIT2)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT3)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT4)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT5)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT6)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT7)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT8)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT9)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT10)->EnableWindow(FALSE);
		
		GetDlgItem(IDC_EDIT12)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT13)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT14)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT15)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT16)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT17)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT18)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT19)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT20)->EnableWindow(FALSE);

		GetDlgItem(IDC_EDIT22)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT23)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT24)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT25)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT26)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT27)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT28)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT29)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT30)->EnableWindow(FALSE);

		GetDlgItem(IDC_EDIT32)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT33)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT34)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT35)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT36)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT37)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT38)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT39)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT40)->EnableWindow(FALSE);
		
		GetDlgItem(IDC_STATIC_M0)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M3)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M4)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M5)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_M9)->ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		GetDlgItem(IDC_EDIT11)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT12)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT13)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT14)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT15)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT16)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT17)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT18)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT19)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT20)->EnableWindow(FALSE);

		GetDlgItem(IDC_EDIT32)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT33)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT34)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT35)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT36)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT37)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT38)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT39)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT40)->EnableWindow(FALSE);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgLaserHeightSet::OnOK()
{
	UpdateData(TRUE);
	CDialog::OnOK();
}

void CDlgLaserHeightSet::SetData(double* d1stHeight, double* d2ndHeight, double* d1stHeightTophat, double* d2ndHeightTophat)
{
	for(int i=0; i<MOTOR_MASK_MAX; i++)
	{
		memcpy(m_d1stLaserHeight+i, &d1stHeight[i], sizeof(d1stHeight[i]));
		memcpy(m_d2ndLaserHeight+i, &d2ndHeight[i], sizeof(d2ndHeight[i]));
		memcpy(m_d1stLaserHeightTophat+i, &d1stHeightTophat[i], sizeof(d1stHeightTophat[i]));
		memcpy(m_d2ndLaserHeightTophat+i, &d2ndHeightTophat[i], sizeof(d2ndHeightTophat[i]));
	}
}

void CDlgLaserHeightSet::GetData(double* d1stHeight, double* d2ndHeight, double* d1stHeightTophat, double* d2ndHeightTophat)
{
	for(int i=0; i<MOTOR_MASK_MAX; i++)
	{
		memcpy(d1stHeight+i, &m_d1stLaserHeight[i], sizeof(m_d1stLaserHeight[i]));
		memcpy(d2ndHeight+i, &m_d2ndLaserHeight[i], sizeof(m_d2ndLaserHeight[i]));
		memcpy(d1stHeightTophat+i, &m_d1stLaserHeightTophat[i], sizeof(m_d1stLaserHeightTophat[i]));
		memcpy(d2ndHeightTophat+i, &m_d2ndLaserHeightTophat[i], sizeof(m_d2ndLaserHeightTophat[i]));
	}	
}

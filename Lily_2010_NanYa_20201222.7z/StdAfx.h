// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//


#if !defined(AFX_STDAFX_H__7E346D7F_187B_4CFB_A98F_FF708ECAC6D1__INCLUDED_)
#define AFX_STDAFX_H__7E346D7F_187B_4CFB_A98F_FF708ECAC6D1__INCLUDED_

//#define _SECURE_SCL 0
//#define _SECURE_SCL_THROWS 1

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
//#define _CRT_SECURE_NO_WARNINGS

#define WINVER 0x0501 // Win2k


#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls

/********************* DB ����� ���� �߰��� �κ� *********************/
#ifndef _AFX_NO_DB_SUPPORT
#include <afxdb.h>			// MFC ODBC database classes
#endif // _AFX_NO_DB_SUPPORT
/*********************************************************************/

#include <atlbase.h>

#define  USE_VISION_PRO

#ifdef USE_VISION_PRO
/*************************�߰� �κ� *****************************/
	#pragma warning (disable : 4146 4192 4278)
	#import "cogxstd.dll" raw_interfaces_only, raw_native_types, no_namespace, \
						  named_guids, no_implementation
	#import "CogDisplay.ocx" raw_interfaces_only, raw_native_types, \
							 no_namespace, named_guids, no_implementation
	#import "cogxpma.dll" raw_interfaces_only, raw_native_types, no_namespace, \
						   named_guids, no_implementation

	#import "cogxtoolgrp.dll" raw_interfaces_only, raw_native_types, no_namespace, \
						   named_guids, no_implementation

	#import "cogxidb.dll" raw_interfaces_only, raw_native_types, no_namespace, \
						   named_guids, no_implementation

	#import "cogx8501.dll" raw_interfaces_only, raw_native_types, no_namespace, \
						   named_guids, no_implementation

	#import "cogxblob.dll" raw_interfaces_only, raw_native_types, no_namespace, \
							named_guids, no_implementation	//Cognex Blob Type Library
	//CogSynthModelCtl.ocx
	//CogShapeEditCtl.ocx



	#pragma warning (default : 4146 4192 4278)
#include "memorystream.h"
/**************************** �߰��κ� �� ***************************/
#endif

#endif // _AFX_NO_AFXCMN_SUPPORT


#include <afxmt.h>

#include <afxtempl.h>

//#include <afxsock.h>
#include <winsock2.h>




//#include "./pattern_common.h"
//extern int _api_init;
//extern "C" int APIENTRY Pt_InitOpc(char* szModuleName);


#define M_PI		3.1415926535897932384

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__7E346D7F_187B_4CFB_A98F_FF708ECAC6D1__INCLUDED_)

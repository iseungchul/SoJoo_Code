// CmdQueue.cpp: implementation of the CCmdQueue class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "CmdQueue.h"
#include "DOnlineCmdData.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCmdQueue::CCmdQueue()
{
	::InitializeCriticalSection( &m_Crit );
}

CCmdQueue::~CCmdQueue()
{
	::DeleteCriticalSection( &m_Crit );
}

BOOL CCmdQueue::AddOnlineCmd(char* szCmd)
{
	::EnterCriticalSection( &m_Crit );

	DOnlineCmdData* pData = NULL;

	pData = new DOnlineCmdData;
	pData->SetOnlineCmd( szCmd );

	m_ptrCmdArray.Add( pData );

	::LeaveCriticalSection( &m_Crit );

	return TRUE;
}

BOOL CCmdQueue::AddDPRamFloatData(int nSize, DWORD dwOffset, float* pfMemData)
{
	::EnterCriticalSection( &m_Crit );

	DOnlineCmdData*	pData = NULL;

	pData = new DOnlineCmdData;
	pData->SetDPRamFloatData(nSize, dwOffset, pfMemData);

	m_ptrCmdArray.Add( pData );

	::LeaveCriticalSection( &m_Crit );

	return TRUE;
}

BOOL CCmdQueue::AddDPRamDWORDData(int nSize, DWORD dwOffset, DWORD* pMemData, BOOL bRead, int nDataType)
{
	::EnterCriticalSection( &m_Crit );

	DOnlineCmdData*	pData = NULL;

	pData = new DOnlineCmdData;
	pData->SetDPRamDWORDData(nSize, dwOffset, pMemData, bRead, nDataType);

	m_ptrCmdArray.Add( pData );

	::LeaveCriticalSection( &m_Crit );

	return TRUE;
}

BOOL CCmdQueue::DeleteQueue(int nIndex)
{
	::EnterCriticalSection( &m_Crit );

	int nSize = m_ptrCmdArray.GetSize();

	if( nSize > 0 )
	{
		DOnlineCmdData* pData = NULL;
		
		pData = (DOnlineCmdData*)m_ptrCmdArray.GetAt(nIndex);
		delete pData;
		pData = NULL;

		m_ptrCmdArray.RemoveAt(nIndex);
	}

	::LeaveCriticalSection( &m_Crit );

	return TRUE;
}

BOOL CCmdQueue::DeleteAllQueue()
{
	::EnterCriticalSection( &m_Crit );

	int nSize = m_ptrCmdArray.GetSize();

	if( nSize > 0 )
	{
		DOnlineCmdData* pData = NULL;
		
		for( int i = 0 ; i < nSize ; i++ )
		{
			pData = (DOnlineCmdData*)m_ptrCmdArray.GetAt(0);
			
			if( NULL != pData )
			{
				delete pData;
				pData = NULL;
			}

			m_ptrCmdArray.RemoveAt(0);
		}

		m_ptrCmdArray.RemoveAll();
	}

	::LeaveCriticalSection( &m_Crit );

	return TRUE;
}

DOnlineCmdData* CCmdQueue::GetOnlineCmdData()
{
	DOnlineCmdData* pData = NULL;

	int nSize = m_ptrCmdArray.GetSize();

	if( nSize == 0 )
		return NULL;

	pData = (DOnlineCmdData*)m_ptrCmdArray.GetAt(0);

	return pData;
}

// TRUE : Is Empty, FALSE : Is not Empty
BOOL CCmdQueue::IsEmptyQueue()
{
	int nSize = m_ptrCmdArray.GetSize();

	if( nSize > 0 )
		return FALSE;

	return TRUE;
}
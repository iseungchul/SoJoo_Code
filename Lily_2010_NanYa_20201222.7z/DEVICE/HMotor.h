// HMotor.h: interface for the HMotor class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HMOTOR_H__5B332390_FA6E_4B1B_AD87_E2C6D9554B29__INCLUDED_)
#define AFX_HMOTOR_H__5B332390_FA6E_4B1B_AD87_E2C6D9554B29__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Calibration.h"
#include "TCalibration.h"
#ifndef __KUNSAN_SAMSUNG_LARGE__
#include "DeviceMelsecOsan.h"
#else
#include "DeviceMelsecLarge.h"
#endif
class CCalibration;

class HMotor  
{
public:
	HMotor();
	virtual ~HMotor();

// Operation
public :
	void SetTemeratureLimits();
	virtual void	GetTemperatureForAllCh (double* dTemper) = 0;
	virtual void	GetTCTemperature (double& d1stTemper, double& d2ndTemper) = 0;
	virtual void	GetSBTemperature (double& d1stTemper, double& d2ndTemper) = 0;
	virtual BOOL	InitMotor() = 0;
	virtual void	DestroyMotor() = 0;
	
	// Table Clamp
	virtual BOOL	TableClamp(BOOL bClamp, BOOL bLeft = TRUE) = 0;
	virtual BOOL	GetCurrentTableClamp(BOOL b1st, BOOL bClamp) = 0;

	// MoveCommand
	virtual BOOL	MotorMove() = 0;

	// Just Download Posisition
	virtual BOOL	MotorMoveMC_W(double m, double c) = 0;
	virtual BOOL	MotorMoveMC_W(int nMaskIndex, double c) = 0;
	virtual BOOL	MoveMC_W(double m, double c) = 0;
	virtual BOOL	MoveMC_W(int nMaskIndex, double c) = 0;

	virtual BOOL	MotorMoveXYZ1Z2_W(double x, double y, double z1, double z2, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MoveXYZ1Z2_W(double x, double y, double z1, double z2, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;

	virtual BOOL	MoveZMC_W(double z1, double z2, int nMaskIndex, double c) = 0;
	virtual BOOL	MoveZMC_W(double z1, double z2, double m, double c) = 0;

	// Dual Panel
	virtual BOOL	MoveXYZ1Z2MC(double x, double y, double z1, double z2, double m, double c, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MoveXYZ1Z2M(double x, double y, double z1, double z2, double m, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MoveXYZ1Z2(double x, double y, double z1, double z2, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MoveZ1Z2(double z1, double z2, BOOL bRawMove=FALSE) = 0;

	virtual BOOL	MotorMoveXYZ1Z2MC(double x, double y, double z1, double z2, double m, double c, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MotorMoveXYZ1Z2M(double x, double y, double z1, double z2, double m, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MotorMoveXYZ1Z2(double x, double y, double z1, double z2, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MotorMoveZ1Z2(double z1, double z2, BOOL bRawMove=FALSE) = 0;

	// Single Panel
	virtual BOOL	MoveXYZMC(double x, double y, double z, double m, double c, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MoveXYZM(double x, double y, double z, double m, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MoveXYZ(double x, double y, double z, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MoveZ(double z, BOOL bRawMove=FALSE) = 0;

	virtual BOOL	MotorMoveXYZMC(double x, double y, double z, double m, double c, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MotorMoveXYZM(double x, double y, double z, double m, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MotorMoveXYZ(double x, double y, double z, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MotorMoveZ(double z, BOOL bRawMove=FALSE) = 0;

	virtual BOOL	MotorMoveAxis(int nAxis, double dPosition, BOOL b1stPanel = TRUE, BOOL bZCalUse = TRUE, int nMoveMode = 0, BOOL bPass = FALSE) = 0;

	// Common
	virtual BOOL	SetLimitZ() = 0;
	virtual BOOL	SetLoaderUnloaderPos(double dLoadX, double dLoadY, double UnloadX, double UnloadY) = 0;
	virtual BOOL	SetLoaderUnloaderPos2(double dLoadX, double dLoadY) = 0;
	virtual BOOL	MoveXY(double x, double y, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MoveMC(double m, double c) = 0;
	virtual BOOL	MoveMC(int nMaskIndex, double c) = 0;
	virtual BOOL	MoveM(double m) = 0;
	virtual BOOL	MoveM(int nMaskIndex) = 0;
	virtual BOOL	SetOrigin(int nAxis=-1) = 0;
	virtual BOOL	SetShutter(BOOL bMaster=TRUE, BOOL bSlave=TRUE) = 0;
	virtual BOOL	SetOutPort(DWORD dwOffset, DWORD dwOonOff, BOOL bAbs=TRUE) = 0;
	virtual BOOL	StopMotor(int nAxis=-1) = 0;

	virtual BOOL	MotorMoveXY(double x, double y, BOOL b1stPanel = TRUE, BOOL bRawMove=FALSE) = 0;
	virtual BOOL	MotorMoveMC(double m, double c) = 0;
	virtual BOOL	MotorMoveMC(int nMaskIndex, double c) = 0;
	virtual BOOL	MotorMoveM(double m) = 0;
	virtual BOOL	MotorMoveM(int nMaskIndex) = 0;

	virtual BOOL	SetMaskPosition(double dMaskPosition[], double dMaskPosition2[]) = 0;
	virtual BOOL	SetAutoSetting(SAUTOSETTING sAutoSetting) = 0;
	virtual BOOL	DownloadAxisInfo() = 0;
	virtual BOOL	DownloadAutoSetting() = 0;

	virtual BOOL	HandlerOperation(int nHandlerOperationID, BOOL bAction=TRUE) = 0;
	virtual BOOL	IsHandlerOperation(int nHandlerOperationID, BOOL bStop, BOOL bWait=TRUE) = 0;
	virtual BOOL	IsInPosition(int nAxis=-1, BOOL bWait=TRUE) = 0;
	virtual BOOL	IsInOrigin(int nAxis, BOOL bWait=TRUE) = 0;

	virtual double	GetPosition(int nAxisNo, BOOL b1stPanel = TRUE) = 0;
	virtual double	GetMoveSpeed(int nAxisNo) = 0;

	virtual BOOL	GetPosition(int nAxisNo, double &dPosition, BOOL b1stPanel = TRUE) = 0;

	void	SetMotorType(int nType)		{ m_nMotorType = nType; }
	int		GetMotorType()				{ return m_nMotorType; }

	void	SetCalType(int nCalType)	{ m_nCalType = nCalType; }
	int		GetCalType()				{ return m_nCalType; }

	void	SetUseDualPanel(int nDual)	{ m_nUseDualPanel = nDual; }
	int		GetUseDualPanel()			{ return m_nUseDualPanel; }

	virtual void LoadCalibrationFile(CString strPath) = 0;
	virtual void UpdateCalibrationFile(CString strPath) = 0;

	virtual BOOL AutoSaveInit() = 0;
	virtual BOOL AutoSaveXY(double dPosX, double dPosY) = 0;
	virtual BOOL AutoSaveZ(double dPosZ) = 0;
	virtual BOOL AutoSaveZ(double dPosZ1, double dPosZ2) = 0;
	virtual BOOL AutoNext(int nCount) = 0;
	virtual int	 GetAutoDataMax() = 0;

	virtual long GetCurrentError(ERRORCOMMAND nError) = 0;
	virtual int  GetCurrentStatus(CURRENTSTATUS nStatus, BOOL bFlag=FALSE) = 0;
	virtual int  GetCurrentMode() = 0;
	virtual BOOL  IsSafetyMode() = 0;
	virtual BOOL SetCurrentStatus(CURRENTSTATUS nStatus, BOOL bFlag=FALSE) = 0;
	virtual int  IsStatus(ISSTATUS nStatus, BOOL bFlag=FALSE) = 0;

	virtual BOOL	SetSpeed(int nAxisNo, long nSpeed) = 0;

	virtual void GetAxisMoveOffset(double dX, double dY, double& dXOffset, double& dYOffset, BYTE cFlag) = 0;

	virtual BYTE GetCurrentSuction() = 0;

	virtual BOOL FireMoveXY(double dX, double dY, double dSFX, double dEFX, int nSpeed, int nLaserOnDelay, int nLaserOffDelay) = 0;

	virtual BOOL	SetAxisInfo(SAXISINFO* sAxisInfo) = 0;
	
	//�ҽ������ϸ鼭 ������ �͵� 
	virtual BOOL IsBMMotorHomeEnd() = 0;
	virtual BYTE GetCurrentShutter1() = 0;
	virtual BYTE GetCurrentShutter2() = 0;
	virtual BOOL MotorShutterAll(BOOL bMaster, BOOL bSlave) = 0;
	virtual BOOL MainReset(BOOL bOn) = 0;
	virtual BOOL SetError(BOOL bError) =0;
	virtual BOOL IsAnyError() = 0;
	virtual BOOL InPositionIO(int nAxis) = 0;
	virtual BOOL GetCurrentLoadDetect(int nUsePanel) = 0;
	virtual BOOL GetCurrentSuctionMotor() = 0;
	virtual BOOL ScannerPower(BOOL bOn) = 0;
	virtual BOOL SetAOMPowerON(BOOL bOn) = 0;
	virtual BOOL IsLoaderPicker1PCBExist() = 0;
	virtual BOOL IsLoaderPicker2PCBExist() = 0;
	virtual BOOL IsLoadCartNoPCB() = 0;
	virtual BOOL GetScannerStatus() = 0;
	virtual BOOL GetAOMStatus() = 0;
	virtual BOOL IsTable1PCBExist() = 0;
	virtual BOOL IsTable2PCBExist() = 0;
	virtual BOOL IsUnloaderPicker1PCBExist() = 0;
	virtual BOOL IsUnloaderPicker2PCBExist() = 0;
	virtual BOOL IsHandlerPartError(BOOL bLoader) = 0;
	virtual BOOL SetTowerLampBuzzer(int nColor, BOOL bBuzzer) = 0;
	virtual BOOL IonizerOn(BOOL bOn) = 0;
	virtual BOOL DustSuctionControl(BOOL bLeft, BOOL bUp) = 0;
	virtual BOOL HoodOpen(BOOL bOpen) = 0;
	virtual BOOL MoveLaserBeamPath(BOOL bUp, BOOL bUseAom) = 0;
	virtual BOOL MoveTophatShutter(BOOL bUp) = 0;
	virtual BOOL IsHoodOK(BOOL bOpen) = 0;
	virtual BOOL MainStop(BOOL bOn = TRUE) = 0;
	virtual BOOL MainReady(BOOL bOn) =0;
	virtual BOOL SetMoveIO(int nMoveAxis) =0;
	virtual BOOL WriteOutputIOBIt(int nAddr, short nBit, BOOL bOnOff) = 0;
	virtual BOOL GetCurrentAcrylSuction(BOOL b1st) = 0;
	virtual BOOL GetRawPosition(int nAxis, double &dPosition) = 0;
	virtual BOOL MoveXYZMC2(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat = FALSE) =0;
	virtual BOOL MoveZMCA2(double dPosZ1, double dPosZ2, int nMaskPos, int nMaskPos2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat = FALSE)=0;
	virtual BOOL MoveZMCA2(double dPosZ1, double dPosZ2, double dPosM1, double dPosM2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL bZCalUse, BOOL bTophat = FALSE) =0;
	
	virtual BOOL MoveXYZMC2A(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosC, double dPosC2, double dPosA, double dPosA2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat = FALSE)=0;
	virtual BOOL MotorMoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dA1, double dA2, BOOL bTophat = FALSE) = 0;
	virtual BOOL MotorMoveXYZDownOnly(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel, int nMoveMode = TRUE, BOOL bPass = TRUE) =0;
	virtual BOOL MoveMCA2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, double dA1, double dA2, BOOL bTophat = FALSE) =0;
	virtual BOOL MoveMC2DownOnly(double dMaskPos, double dMaskPos2, double dPosC, double dPosC2, BOOL bTophat = FALSE) =0;
	virtual BOOL MotorMoveZMC2(double dPosZ1, double dPosZ2, double dMaskPos, double dPosC, BOOL bTophat = FALSE) =0;
	virtual BOOL MotorMoveXYZMC3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat = FALSE) =0;
	virtual BOOL MoveZ(double dPosZ1, double dPosZ2, BOOL bRawMove) = 0;
	virtual BOOL MoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel = TRUE, BOOL bZCalUse = TRUE, int nMoveMode = 0, BOOL bPass = FALSE) =0;
	virtual BOOL MotorMoveXYZ(double dPosX, double dPosY, double dPosZ1, double dPosZ2, BOOL b1stPanel = TRUE, int nMoveMode = 0, BOOL bPass = FALSE) =0;
	virtual BOOL MoveZMC2(double dPosZ1, double dPosZ2, double dMaskPos, double dPosC, BOOL bZCalUse = TRUE, BOOL bTophat = FALSE) =0;
	virtual BOOL IsReady(int nAxis = -1) =0;
	virtual BOOL SetOutportTableVacuum(BOOL bUseBTable) =0;
////
	virtual BOOL GetCurrentMotorSol() = 0;
	virtual BOOL Stop(int nAxis) = 0;
	virtual void SetAxisSpeed(int nAxis, long nSpeed) = 0;
	virtual void SetOriginalSpeed() = 0;
	virtual void SetFixedMaskPos(double dPos) =0;
	virtual BOOL GetCurrentHeight(BOOL bFirst, BOOL bDown) = 0;
	virtual BOOL GetCurrentEMStop() =0;
	virtual BOOL IsFluorescentLampOn() = 0;
	virtual BOOL SetLimitYPos(double dPos) =0;
	virtual void UpdateZCalibrationFile(CALHEAD &calHead, BOOL bFirst) =0;
	virtual BOOL LoaderCarrierLoadPos() = 0;
	virtual BOOL LoaderCarrierAlignPos() = 0;
	virtual BOOL LoaderCarrierCartPos() = 0;
	virtual BOOL UnloaderCarrierTablePos() = 0;
	virtual BOOL UnloaderCarrierUnloadPos() = 0;
	virtual BYTE GetCurrentPowerMeter() = 0;
	virtual BOOL Table1VacuumMotor(BOOL bOn) = 0;
	virtual BOOL GetChuckStatus(BOOL bClamp) = 0;
	virtual BOOL GetSystemAir() = 0;
	virtual BOOL GetLoadingShutterStatus(BOOL bOpen) = 0;
	virtual BOOL IsFrontDoorOpen() = 0;
	virtual BOOL IsLeftDoorOpen() = 0;
	virtual BOOL IsRightDoorOpen() = 0;
	virtual BOOL IsRear1DoorOpen() = 0;
	virtual BOOL IsRear2DoorOpen() = 0;
	virtual BOOL GetBrushStatus(BOOL bUp) = 0;
	virtual BOOL GetResetSW() = 0;
	virtual BOOL GetStartSW() = 0;
	virtual BOOL GetStopSW() = 0;
	virtual BOOL IsAlignerPCBExist() = 0;
	virtual BOOL IsULAlignerPCBExist() = 0;
	virtual BOOL IsLCinLoadPos() = 0;
	virtual BOOL IsLCinCartPos() = 0;
	virtual BOOL IsUCinCartPos() = 0;
	virtual BOOL IsUCinUnloadPos() = 0;
	virtual BOOL Loader1PCBExist(BOOL bOn) = 0;
	virtual BOOL Loader2PCBExist(BOOL bOn) = 0;
	virtual BOOL AlignTablePCBExist(BOOL bOn) = 0;
	virtual BOOL Unloader1PCBExist(BOOL bOn) = 0;
	virtual BOOL Unloader2PCBExist(BOOL bOn) = 0;
	virtual BOOL ULAlignTablePCBExist(BOOL bOn) = 0;
	virtual BOOL TablePCBReset() = 0;

	virtual BOOL IsLoaderCartClamp() = 0;
	virtual BOOL IsLoaderPicker1Vacuum() = 0;
	virtual BOOL IsLoaderPicker2Vacuum() = 0;
	virtual BOOL IsUnloaderPicker1Vacuum() =0;
	virtual BOOL IsUnloaderPicker2Vacuum() =0;
	virtual BOOL IsLoaderAlignTableForward() = 0;
	virtual BOOL IsAlignGuideForward() = 0;
	virtual BOOL IsAlignSheetTableForward() = 0;

	virtual BOOL Table2VacuumMotor(BOOL bOn) = 0;
	virtual BOOL LoaderElvLoadPos() = 0;
	virtual BOOL LoaderElvOriginPos() = 0;
	virtual BOOL UnloaderElvUnloadPos() = 0;
	virtual BOOL UnloaderElvOriginPos() =0;
	virtual BOOL UnloaderCarrierAlignPos() = 0;
	virtual BOOL WriteOutPort(int nAdd, BOOL bOn) = 0;
	virtual BOOL IsLP2P1Up() = 0;
	virtual BOOL IsLP2P2Up() = 0;
	virtual BOOL IsLP1P1Up() = 0;
	virtual BOOL IsLP1P2Up() = 0;
	virtual BOOL IsULP1P1Up() = 0;
	virtual BOOL IsULP1P2Up() = 0;
	virtual BOOL IsULP2P1Up() = 0;
	virtual BOOL IsULP2P2Up() = 0;
	virtual BOOL IsUnloaderCartClamp() =0;
	virtual BOOL IsUnloaderAlignTableForward() = 0;
	virtual BOOL LoaderPicker1Init() = 0;
	virtual BOOL LoaderPicker1Align() =0;
	virtual BOOL LoaderPicker1P2() =0;
	virtual BOOL LoaderPicker1Load() = 0;
	virtual BOOL LoaderPicker2Init() =0;
	virtual BOOL LoaderPicker2Align() =0;
	virtual BOOL LoaderPicker2P2() = 0;
	virtual BOOL LoaderPicker2Load() =0;
	virtual BOOL LoaderVacuum1On() = 0;
	virtual BOOL LoaderVacuum1Off() = 0;
	virtual BOOL LoaderVacuum2On() = 0;
	virtual BOOL LoaderVacuum2Off() = 0;
	virtual BOOL LoaderClampForward() =0; 
	virtual BOOL LoaderClampBackward() =0; 
	virtual BOOL LoaderTableForward() =0; 
	virtual BOOL LoaderTableBackward() =0; 
	virtual BOOL LoaderAlignXForward() =0; 
	virtual BOOL LoaderAlignXBackward() =0; 
	virtual BOOL LoaderAlignYForward() =0; 
	virtual BOOL LoaderAlignYBackward() =0; 

	virtual BOOL UnloaderPicker1Init() =0; 
	virtual BOOL UnloaderPicker1Table() =0; 
	virtual BOOL UnloaderPicker1P2() =0; 
	virtual BOOL UnloaderPicker1Unload() =0; 
	virtual BOOL UnloaderPicker2Init() =0; 
	virtual BOOL UnloaderPicker2Table() =0; 
	virtual BOOL UnloaderPicker2P2() =0; 
	virtual BOOL UnloaderPicker2Unload() =0;
	virtual BOOL UnloaderVacuum1On() = 0;
	virtual BOOL UnloaderVacuum1Off() =0;
	virtual BOOL UnloaderVacuum2On() = 0;
	virtual BOOL UnloaderVacuum2Off() =0;
	virtual BOOL UnloaderTableBackward() =0 ;
	virtual BOOL UnloaderTableForward() = 0;
	virtual BOOL UnloaderClampBackward() = 0;
	virtual BOOL UnloaderClampForward() = 0;
	virtual BOOL IsLCinAlignPos() = 0;
	virtual BOOL IsUCinAlignPos() = 0;
	virtual BOOL TableVacuumSelect(BOOL bOn) = 0;
	virtual BOOL GetAOMAlarm() =0;
	virtual BOOL UnLoaderPCBReset() = 0;
	virtual BOOL LoaderPCBReset() = 0;
	virtual BOOL IsHandlerReady() = 0;
	virtual BOOL IsHandlerAlarm() = 0;
	virtual BOOL IsHandlerLotEnd() = 0;
	virtual BOOL IsHandler1stTableExist() = 0;
	virtual BOOL IsHandler2ndTableExist() = 0;
	virtual BOOL IsHandlerLoadReady() = 0;
	virtual BOOL IsHandlerLoadEnd() = 0;
	virtual BOOL IsHandlerLoadAlarm() = 0;
	virtual BOOL IsHandlerUnloadReady() =0 ;
	virtual BOOL IsHandlerUnloadEnd() = 0;
	virtual BOOL IsHandlerUnloadAlarm() = 0;
	virtual void UpdateTCalibrationFile(CALDATA &calData) = 0;
	virtual double GetMoveAccel(int nAxis) = 0;
	virtual double GetMPosition(int nIndex) = 0;
	virtual BOOL SendLoadCartNoPCB() = 0;
	virtual BOOL SetPickerVacuum(BOOL bLoader, BOOL b1st, BOOL bOn) =0;
	virtual BOOL IsResetSwitch() = 0;
	virtual BOOL IsHandlerDoorBypass(BOOL bLoader) =0;
	virtual BOOL IsHandlerReady(int nAxis) = 0;
	virtual BOOL IsHandlerBusy(int nAxis) = 0;
	virtual BOOL IsHandlerStop(int nAxis) = 0;
	virtual BOOL IsHandlerInitEnd(int nAxis) = 0;
	virtual BOOL UseRoll(BOOL bUse) = 0;
	virtual BOOL IsHandlerTablePCBExist(BOOL bLoader) =0;
	virtual BOOL LoaderPicker3Init() = 0;
	virtual BOOL UnloaderPicker3Init() = 0;
	virtual int ChangeMotorPosition(double dXPos, double dYPos, BOOL b1stPanel) = 0;
	virtual int GetInpositionError() = 0;
	virtual BOOL SetAlarmTolLed(BOOL bOn) = 0;
	virtual BOOL SetWaterFlow1Value(double dVal) = 0;
	virtual BOOL SetWaterFlow2Value(double dVal) = 0;
	virtual BOOL SetMainAirValue(double dVal) = 0;
	virtual BOOL SetDustSuctionValue(double dVal) = 0;
	virtual BOOL SetTableVauumValue(BOOL b1st, double dVal) = 0;
	virtual BOOL Set2DBarcodeTrigger() = 0;
	virtual BOOL MoveZMC3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, BOOL bZCalUse, BOOL bTophat) = 0;
	virtual BOOL GetChillerRun() = 0;
	virtual BOOL GetLPCStatus() = 0;
	virtual BYTE GetBasketIn() = 0;
	virtual BOOL SetUseNGBox(BOOL bUse) = 0;
	virtual BOOL SetUsePaperBox(BOOL bUse) = 0;
	virtual BOOL SetTablePCBExist(BOOL b1st, BOOL b2nd) = 0;
	virtual BOOL IsStartMode() = 0;
	virtual BOOL MoveMCA3DownOnly(double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA, double dPosA2) = 0;
	virtual BOOL MoveZMCA3(double dPosZ1, double dPosZ2, double dMaskPos, double dMaskPos2, double dMaskPos3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL bZCalUse, BOOL bTophat) = 0;
	virtual void ReadAddressTemperatureComp() = 0;
	virtual void ReadTemperatureComp() = 0;
	virtual BOOL GetReverseDirection() = 0;
	virtual void ReadAllError(int* pnVal) = 0;
	virtual BOOL GetReverseReady() = 0;
	virtual void DisconnectAnyDevice(int nType) = 0;
	virtual void ConnectAnyDevice(int nType) = 0; // 0 : chiller 1: thermo-hyprometer
	virtual BOOL MotorMoveXYZMCA3(double dPosX, double dPosY, double dPosZ1, double dPosZ2, double dPosM, double dPosM2, double dPosM3, double dPosC, double dPosC2, double dPosA1, double dPosA2, BOOL b1stPanel, int nMoveMode, BOOL bPass, BOOL bTophat) = 0;
	virtual BOOL SetLoadPickerDownOK(BOOL b1st, BOOL b2nd) = 0;
	virtual BOOL IsUnloaderNGBoxForward() = 0;
	virtual BOOL IsUnloaderNGBoxBackward() = 0;
	virtual BOOL IsLCinCartPos2() = 0;
	virtual BOOL IsLCinAlignPos2() = 0;
	virtual BOOL LoaderCarrierAlignPos2() = 0;
	virtual BOOL LoaderCarrierCartPos2() = 0;
	virtual BOOL IsOrigin(int nAxis) = 0;
	virtual BOOL SetReverseDirection(BOOL bChange) = 0;
	virtual BOOL SetUnloadPickerDownOK(BOOL b1st, BOOL b2nd) = 0;
	virtual BOOL SetOutputBasket(BOOL bLoad) = 0;
	virtual BOOL UnloaderNGBoxForward() = 0;
	virtual BOOL UnloaderNGBoxBackward() = 0;
	virtual BOOL IsMainDoorStop() = 0;
	virtual int	GetMainAirValue() = 0;
	virtual double GetChillerTemp() = 0;
	virtual int	GetWaterFlow1Value() = 0;
	virtual int	GetWaterFlow2Value() = 0;
	virtual double GetVolateSubData(int nIndex) = 0;
	virtual void GetHumiTempDew(double& dHumidity, double& dTemperature, double& dDewPoint) = 0;
	virtual void GetVoltage(double& dV, double& dA,double& dKw) = 0;
	virtual BOOL GetLoadBasketSignal(BOOL bIn) = 0;
	virtual BOOL GetUnloadBasketSignal(BOOL bIn) = 0;
	virtual BOOL ResetBasketInfo(BOOL bLoad) = 0;

	// Attributes
protected :
	int				m_nMotorType;
	int				m_nCalType;
	int				m_nUseDualPanel;
	CCalibration*	m_pCalibration;
	CCalibration*	m_pSlaveCalibration;
	SAUTODATA*		m_pAutoData;
	int				m_nAutoDataMax;
};

#endif // !defined(AFX_HMOTOR_H__5B332390_FA6E_4B1B_AD87_E2C6D9554B29__INCLUDED_)

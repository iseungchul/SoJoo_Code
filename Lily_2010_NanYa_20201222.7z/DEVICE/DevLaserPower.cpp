// DevLaserPower.cpp: implementation of the CDevLaserPower class.
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DevLaserPower.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//extern HINSTANCE g_hDllDeviceCom;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDevLaserPower::CDevLaserPower()
	: CAsyncComm()
{

}

CDevLaserPower::~CDevLaserPower()
{

}

BOOL CDevLaserPower::Create()
{
	InitializeCriticalSection(&m_csCommunicationSync);
	SetBinaryMode(TRUE);
	CheckParity(FALSE);
	SetPort((TPort)m_nPortNo);
	SetBaudRate((TBaudRate)m_nBaudRate);
	SetParity((TParity)m_nParity);
	SetByteSize((TByteSize)m_nDataBits);
	SetStopBits((TStopBits)m_nStopBits);
	SetFlowControl((TFlowControl)m_nFlowControl);
	SetTimeOut(300);
	SetEventChar(0x0d);
	SetEventMask(EV_BREAK | EV_CTS | EV_DSR | EV_ERR | EV_RING | EV_RLSD | EV_RXCHAR | EV_RXFLAG | EV_TXEMPTY);
	
	OpenComm();
	if(PortOpened())
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

void CDevLaserPower::Destroy()
{
	CloseComm();
	DeleteCriticalSection(&m_csCommunicationSync);
}

char* CDevLaserPower::QueryCommand(char *szCmd)
{
	if (!PortOpened())
		return "";

	char szTmp[1024], szTrans[1024], szRet[1024];
	BOOL FEnd;
	TAssWaitResult wr;

	memset(szTmp, 0x00, sizeof(szTmp));
	memset(szRet, 0x00, sizeof(szRet));
	memset(szTrans, 0x00, sizeof(szTrans));

	EnterCriticalSection(&m_csCommunicationSync);
  
	if (strlen(szCmd) <= 102)
	{
		FEnd = FALSE;
		sprintf_s(szTrans, 1024, _T("%s\r\n"), szCmd); 

	    WriteString(szTrans);
    
		wr = FReceiveEvent.WaitFor(FTimeOut);
		if (wr == wrSignaled)
		{
#ifndef __TEST__
			Sleep(300); // ���� ������ ���� ������ bhlee : ���� �� �ȳѾ� �´ٸ� �� �־����.
#endif
			strcpy_s(szRet, ReadString());

			if (strlen(szRet) > 0)
			{
				LeaveCriticalSection(&m_csCommunicationSync);
				return &szRet[0];
			}
			else
			{
      			LeaveCriticalSection(&m_csCommunicationSync);
				return _T("");
			}
		}
		else
		{
		FireTimeOut();       
    	LeaveCriticalSection(&m_csCommunicationSync);
		return _T("");
	    }
	}
	LeaveCriticalSection(&m_csCommunicationSync);
	return &szTmp[0];
}

void CDevLaserPower::ProcessMonitor()
{

}

void CDevLaserPower::FireReceived()
{
	FReceiveEvent.SetEvent();
}

void CDevLaserPower::SetParameter(int nPortNo, int nBaudRate, int nParity, int nDataBits, int nStopBits, int nFlowControl)
{
	m_nPortNo = nPortNo;
	m_nBaudRate = nBaudRate;
	m_nParity = nParity;
	m_nDataBits = nDataBits;
	m_nStopBits = nStopBits;
	m_nFlowControl = nFlowControl;
}
// MMelsec.cpp: implementation of the MMelsec class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MMelsec.h"
#include "..\EasyDriller.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
MMelsec::MMelsec()
{
	::InitializeCriticalSection( &m_CritSocket );
	m_hLocalSocket			= INVALID_SOCKET;

	m_strDestAddr.Format(_T("172.16.1.1"));
	m_nDestPortNo			= 0x2000;//10010;
 
	m_strLocalAddr.Format(_T("172.16.1.2"));
	m_nLocalPortNo			= m_nDestPortNo;//20010;

	m_nCommErrorCount		= 0;
	m_nTimeOut				= 10;
}

MMelsec::~MMelsec()
{
	CloseWinSock();
	::DeleteCriticalSection( &m_CritSocket );
}

BOOL MMelsec::InitWinSock()
{
	WSADATA wsaData;
	WORD wVersion =  MAKEWORD(2,2);

	// Init Win Sock
	if( 0 != ::WSAStartup( wVersion, &wsaData ) )
	{
		ErrMessage(_T("WSAStartup Error"), MB_ICONERROR);
		return FALSE;
	}

	/* Confirm that the WinSock DLL supports 2.2.*/
	/* Note that if the DLL supports versions greater    */
	/* than 2.2 in addition to 2.2, it will still return */
	/* 2.2 in wVersion since that is the version we      */
	/* requested.                                        */
 	if ( LOBYTE( wsaData.wVersion ) != 2 || HIBYTE( wsaData.wVersion ) != 2 ) 
	{
		ErrMessage(_T("Invalid Socket Version"), MB_ICONERROR);
		/* Tell the user that we could not find a usable */
		/* WinSock DLL.                                  */
		WSACleanup( );
		return FALSE; 
	}

	return TRUE;
}

BOOL MMelsec::Connect()
{
	if( INVALID_SOCKET != m_hLocalSocket )
		return TRUE;

/*	if( INVALID_SOCKET == m_hLocalSocket )
	{
		if( FALSE == InitWinSock() )
			return FALSE;
	}
*/
	// Socket
	m_hLocalSocket = ::socket( AF_INET, SOCK_STREAM, 0 );
	if( INVALID_SOCKET == m_hLocalSocket )
	{
		ShowErrMsg(_T("socket()"));
		::WSACleanup();

		return FALSE;
	}

	// Get Client PC Name & IP Address
	char szLocalName[MAXBUFSIZE] = {0,};

	::gethostname( szLocalName, MAXBUFSIZE );

	// Init Socket Address Struct
	memset( &m_sDestAddr, 0, sizeof(m_sDestAddr) );
	memset( &m_sLocalAddr, 0, sizeof(m_sLocalAddr) );

	// Destination Address
	m_sDestAddr.sin_family			= AF_INET;
	m_sDestAddr.sin_port			= htons( m_nDestPortNo );
	m_sDestAddr.sin_addr.s_addr		= inet_addr( (LPSTR)(LPCTSTR)m_strDestAddr );

	// Local Address
	m_sLocalAddr.sin_family			= AF_INET;
	m_sLocalAddr.sin_port			= htons( 0 ); // htons( m_nLocalPortNo );
	m_sLocalAddr.sin_addr.s_addr	= inet_addr( (LPSTR)(LPCTSTR)m_strLocalAddr );

	// bind. 
	int nRet = ::bind( m_hLocalSocket, (SOCKADDR*)&m_sLocalAddr, sizeof(m_sLocalAddr) );

	if( SOCKET_ERROR == nRet )
	{
		ShowErrMsg(_T("bind()"));
		CloseWinSock();
		return FALSE;
	}

	nRet = ::connect( m_hLocalSocket, (SOCKADDR*)&m_sDestAddr, sizeof(m_sDestAddr) );
	
	if( SOCKET_ERROR == nRet )
	{
		ShowErrMsg(_T("bind()"));
		CloseWinSock();
		return FALSE;
	}

	// Timeout Option
	int nTimeout = 1000 * m_nTimeOut;
	nRet = ::setsockopt( m_hLocalSocket, SOL_SOCKET, SO_RCVTIMEO, (char*)&nTimeout, sizeof(nTimeout) );

	if( SOCKET_ERROR == nRet )
	{
		ShowErrMsg(_T("setsockopt()"));
		CloseWinSock();

		return FALSE;
	}

	return TRUE;
}

void MMelsec::CloseWinSock()
{
	if( INVALID_SOCKET == m_hLocalSocket )
		return;

	int nErrCode = ::closesocket( m_hLocalSocket );
	if( 0 != nErrCode )
	{
		ShowErrMsg(_T("closesocket()"));
	}
	::WSACleanup();

	m_hLocalSocket	= INVALID_SOCKET;
}

void MMelsec::ShowErrMsg(CString strMsg)
{
	LPVOID lpMsgBuf;

	::FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL,
					 ::WSAGetLastError(), MAKELANGID( LANG_NEUTRAL, SUBLANG_DEFAULT ),
					 (LPTSTR)&lpMsgBuf, 0, NULL );

	CString strErrMsg;

	strErrMsg.Format(_T("[%s] %s"), strMsg, (LPCTSTR)lpMsgBuf);
	ErrMessage(strErrMsg, MB_ICONERROR);

	::LocalFree( lpMsgBuf );
}

int MMelsec::SendMsg(char* pData, int nDataSize)
{
	int nRet = 0;

//	nRet = ::sendto( m_hLocalSocket, pData, nDataSize, 0, (SOCKADDR*)&m_sDestAddr, sizeof(m_sDestAddr) );
	nRet = ::send( m_hLocalSocket, pData, nDataSize, 0);

	if( SOCKET_ERROR == nRet )
	{
		//ShowErrMsg(_T("sendto()"));
		if( m_nCommErrorCount <= 7 )
			m_nCommErrorCount++;

		return 0;
	}
	else
		m_nCommErrorCount = 0;

	return nRet;
}

int MMelsec::RecvMsg(char* pData, int nDataSize)
{
	int nRet = 0;
	int nCount = 0;

//	SOCKADDR_IN sPeerAddr;
	int nAddrLen = sizeof(SOCKADDR_IN);

	while(nRet == 0)
	{
		nCount++;
//		::Sleep(0);
//		nRet = ::recvfrom( m_hLocalSocket, pData, nDataSize, 0, (SOCKADDR*)&sPeerAddr, &nAddrLen );
		nRet = ::recv( m_hLocalSocket, pData, nDataSize, 0);
		if(nCount > 100)
		{
			TRACE(_T("Time over\n"));
			break;
		}
	}

	if( SOCKET_ERROR == nRet )
	{
		//ShowErrMsg(_T("recvfrom()"));
		if( m_nCommErrorCount <= 7 )
			m_nCommErrorCount++;

		return 0;
	}
	else
		m_nCommErrorCount = 0;

	// Sender�� IP Address �˻�
/*	if( 0 != memcmp( &sPeerAddr, &m_sDestAddr, sizeof(sPeerAddr) ) )
	{
		ErrMessage(_T("Unknown Sender"), MB_ICONERROR);
		
		return 0;
	}
*/
	return nRet;
}

BOOL MMelsec::IsConnect()
{
	if( INVALID_SOCKET == m_hLocalSocket )
		return FALSE;

	return TRUE;
}

BOOL MMelsec::Create()
{
#ifdef __TEST__
	return TRUE;
#endif
	BOOL bRet = 0;
	
	// Initialize WinSock
	bRet = InitWinSock();
	
	if( FALSE == bRet )
		return bRet;
	
	// Connect Melsec
	bRet = Connect();
	
	if( FALSE == bRet )
	{
		CloseWinSock();
		return bRet; 
	}

	// Initialzie Motor Command
	InitCommand();

	return bRet;
}

void MMelsec::InitCommand()
{
	m_qSendData.sHeader.cSubHeader1			= 0x50;			// sub-header no
	m_qSendData.sHeader.cSubHeader2			= 0x00;			// sub-header no
	m_qSendData.sHeader.cNetworkNo			= 0x00;			// �ڱ�
	m_qSendData.sHeader.cPLCNo				= 0xFF;			// �ڱ� 
	m_qSendData.sHeader.wModuleIONo[0]		= 0xFF;			// not Q*C24 and multi-cpu	
	m_qSendData.sHeader.wModuleIONo[1]		= 0x03;			// not Q*C24 and multi-cpu
	m_qSendData.sHeader.cModuleNo			= 0x00;			// not Q*C24 and multi-cpu		
	m_qSendData.sHeader.wDataLength[0]		= 0x00;			// changable
	m_qSendData.sHeader.wDataLength[1]		= 0x00;			// changable
	m_qSendData.sHeader.wCPUWaitTime[0]		= 0x0A;			// �ڱ� max.
	m_qSendData.sHeader.wCPUWaitTime[1]		= 0x00;			// �ڱ� max.
	
	m_qRecieveData.sHeader.cSubHeader1		= 0x50;			// sub-header no
	m_qRecieveData.sHeader.cSubHeader2		= 0x00;			// sub-header no
	m_qRecieveData.sHeader.cNetworkNo		= 0x00;			// �ڱ�
	m_qRecieveData.sHeader.cPLCNo			= 0xFF;			// �ڱ� 
	m_qRecieveData.sHeader.wModuleIONo[0]	= 0xFF;			// not Q*C24 and multi-cpu	
	m_qRecieveData.sHeader.wModuleIONo[1]	= 0x03;			// not Q*C24 and multi-cpu
	m_qRecieveData.sHeader.cModuleNo		= 0x00;			// not Q*C24 and multi-cpu		
	m_qRecieveData.sHeader.wDataLength[0]	= 0x00;			// changable
	m_qRecieveData.sHeader.wDataLength[1]	= 0x00;			// changable
	m_qRecieveData.sHeader.wEndCode[0]		= 0x00;			// changable
	m_qRecieveData.sHeader.wEndCode[1]		= 0x00;			// changable	
}

BOOL MMelsec::ReadMemsbyWord(WORD *wData, WORD wAddress, BYTE cMemoryKind, WORD nSize)
{
	::EnterCriticalSection( &m_CritSocket );
	WORD wCmdSize = 0, wVal;
	BOOL bRet;
	int nRet;

	memset(m_qSendData.cData, 0, sizeof(m_qSendData.cData));
	wVal = CMD_TOTAL_READ;
	memcpy(m_qSendData.cData, &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);
	
	wVal = SUBCMD_WORD;
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);

	wVal = wAddress;
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);

	wVal = cMemoryKind;
	wVal = (wVal << 8);
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);

	wVal = nSize; // WORD
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);

	wCmdSize += SIZE_WAIT_TIME;
	memcpy((void*)(&m_qSendData.sHeader.wDataLength), &wCmdSize, sizeof(WORD));

	bRet = SendMsg((char*)(&m_qSendData), sizeof(m_qSendData.sHeader) + wCmdSize - SIZE_WAIT_TIME);
	if( FALSE == bRet )
	{
		TRACE(_T("Total read cmd send FAIL!!!!\n"));
		::LeaveCriticalSection( &m_CritSocket );
		return bRet;
	}

	memset(&m_qRecieveData, 0, sizeof(m_qRecieveData));
	nRet = RecvMsg((char*)&m_qRecieveData, nSize*sizeof(WORD) + 18);

	if( 0 != nRet  && nRet - EXCEPT_CHAR_LENG == m_qRecieveData.sHeader.wDataLength[0])
	{
		if(m_qRecieveData.sHeader.wEndCode[0] == FALSE && m_qRecieveData.sHeader.wEndCode[1] == FALSE) // good
		{
			memcpy(wData, (void*)(&m_qRecieveData.cData), nSize * sizeof(WORD));
			
		}
		else
		{
			TRACE(_T("Recieve Error code: %d\n"), m_qRecieveData.sHeader.wEndCode);
			::LeaveCriticalSection( &m_CritSocket );
			return FALSE;
		}
	}
	else
	{
		TRACE(_T("Recieve msg FAIL!!!!\n"));
		::LeaveCriticalSection( &m_CritSocket );
		return bRet;
	}

	::LeaveCriticalSection( &m_CritSocket );

	return TRUE;
}

BOOL MMelsec::WriteMemsbyWord(WORD *wData, WORD wAddress, BYTE cMemoryKind, WORD nSize)
{
	::EnterCriticalSection( &m_CritSocket );
	WORD wCmdSize = 0, wVal;
	BOOL bRet;
	int nRet;
	
	memset(m_qSendData.cData, 0, sizeof(m_qSendData.cData));
	wVal = CMD_TOTAL_WRITE;
	memcpy(m_qSendData.cData, &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);
	
	wVal = SUBCMD_WORD;
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);
	
	wVal = wAddress;
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);
	
	wVal = cMemoryKind;
	wVal = (wVal << 8);
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);
	
	wVal = nSize; // WORD
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);

	memcpy((void*)(&m_qSendData.cData[wCmdSize]), wData, nSize * sizeof(WORD));
	wCmdSize += nSize * sizeof(WORD);
	
	wCmdSize += SIZE_WAIT_TIME;
	memcpy((void*)(&m_qSendData.sHeader.wDataLength), &wCmdSize, sizeof(WORD));
	
	bRet = SendMsg((char*)(&m_qSendData), sizeof(m_qSendData.sHeader) + wCmdSize - SIZE_WAIT_TIME);
	if( FALSE == bRet )
	{
		TRACE(_T("Total read cmd send FAIL!!!!\n"));
		::LeaveCriticalSection( &m_CritSocket );
		return bRet;
	}
	
	memset(&m_qRecieveData, 0, sizeof(m_qRecieveData));
	nRet = RecvMsg((char*)&m_qRecieveData, sizeof(m_qRecieveData));
	
	if( 0 != nRet  && nRet - EXCEPT_CHAR_LENG == m_qRecieveData.sHeader.wDataLength[0])
	{
		if(m_qRecieveData.sHeader.wEndCode[0] == FALSE && m_qRecieveData.sHeader.wEndCode[1] == FALSE) // good
		{
		}
		else
		{
			TRACE(_T("Recieve Error code: %d\n"), m_qRecieveData.sHeader.wEndCode);
			::LeaveCriticalSection( &m_CritSocket );
			return FALSE;
		}
	}
	else
	{
		TRACE(_T("Recieve msg FAIL!!!!\n"));
		::LeaveCriticalSection( &m_CritSocket );
		return bRet;
	}
	
	::LeaveCriticalSection( &m_CritSocket );
	
	return TRUE;	
}

BOOL MMelsec::ReadBitMembyBits(BYTE *cData, WORD wAddress, WORD nSize)
{
	::EnterCriticalSection( &m_CritSocket );
	WORD wCmdSize = 0, wVal;
	BOOL bRet;
	int nRet;
	
	memset(m_qSendData.cData, 0, sizeof(m_qSendData.cData));
	wVal = CMD_TOTAL_READ;
	memcpy(m_qSendData.cData, &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);
	
	wVal = SUBCMD_BIT;
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);
	
	wVal = wAddress;
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);
	
	wVal = INTERNALRELAY;
	wVal = (wVal << 8);
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);
	
	wVal = nSize; // bit 
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);
	
	wCmdSize += SIZE_WAIT_TIME;
	memcpy((void*)(&m_qSendData.sHeader.wDataLength), &wCmdSize, sizeof(WORD));
	
	bRet = SendMsg((char*)(&m_qSendData), sizeof(m_qSendData.sHeader) + wCmdSize - SIZE_WAIT_TIME);
	if( FALSE == bRet )
	{
		TRACE(_T("Total read cmd send FAIL!!!!\n"));
		::LeaveCriticalSection( &m_CritSocket );
		return bRet;
	}
	
	memset(&m_qRecieveData, 0, sizeof(m_qRecieveData));
	nRet = RecvMsg((char*)&m_qRecieveData, sizeof(m_qRecieveData));
	
	if( 0 != nRet  && nRet - EXCEPT_CHAR_LENG == m_qRecieveData.sHeader.wDataLength[0])
	{
		if(m_qRecieveData.sHeader.wEndCode[0] == FALSE && m_qRecieveData.sHeader.wEndCode[1] == FALSE) // good
		{
			memcpy(cData, (void*)(&m_qRecieveData.cData), (nSize + 1) / 2);
		}
		else
		{
			TRACE(_T("Recieve Error code: %d\n"), m_qRecieveData.sHeader.wEndCode);
			::LeaveCriticalSection( &m_CritSocket );
			return FALSE;
		}
	}
	else
	{
		TRACE(_T("Recieve msg FAIL!!!!\n"));
		::LeaveCriticalSection( &m_CritSocket );
		return bRet;
	}
	
	::LeaveCriticalSection( &m_CritSocket );
	
	return TRUE;
}

BOOL MMelsec::WriteBitMembyBits(BYTE *cData, WORD wAddress, WORD nSize)
{
	::EnterCriticalSection( &m_CritSocket );
	WORD wCmdSize = 0, wVal;
	BOOL bRet;
	int nRet;
	
	memset(m_qSendData.cData, 0, sizeof(m_qSendData.cData));
	wVal = CMD_TOTAL_WRITE;
	memcpy(m_qSendData.cData, &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);
	
	wVal = SUBCMD_BIT;
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);
	
	wVal = wAddress;
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);
	
	wVal = INTERNALRELAY;
	wVal = (wVal << 8);
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);
	
	wVal = nSize; // bit
	memcpy((void*)(&m_qSendData.cData[wCmdSize]), &wVal, sizeof(WORD));
	wCmdSize += sizeof(WORD);

	memcpy((void*)(&m_qSendData.cData[wCmdSize]), cData, (nSize + 1)/2);
	wCmdSize += (nSize + 1)/2;
	
	wCmdSize += SIZE_WAIT_TIME;
	memcpy((void*)(&m_qSendData.sHeader.wDataLength), &wCmdSize, sizeof(WORD));
	
	bRet = SendMsg((char*)(&m_qSendData), sizeof(m_qSendData.sHeader) + wCmdSize - SIZE_WAIT_TIME);
	if( FALSE == bRet )
	{
		TRACE(_T("Total read cmd send FAIL!!!!\n"));
		::LeaveCriticalSection( &m_CritSocket );
		return bRet;
	}
	
	memset(&m_qRecieveData, 0, sizeof(m_qRecieveData));
	nRet = RecvMsg((char*)&m_qRecieveData, sizeof(m_qRecieveData));
	
	if( 0 != nRet  && nRet - EXCEPT_CHAR_LENG == m_qRecieveData.sHeader.wDataLength[0])
	{
		if(m_qRecieveData.sHeader.wEndCode[0] == FALSE && m_qRecieveData.sHeader.wEndCode[1] == FALSE) // good
		{
		}
		else
		{
			TRACE(_T("Recieve Error code: %d\n"), m_qRecieveData.sHeader.wEndCode);
			::LeaveCriticalSection( &m_CritSocket );
			return FALSE;
		}
	}
	else
	{
		TRACE(_T("Recieve msg FAIL!!!!\n"));
		::LeaveCriticalSection( &m_CritSocket );
		return bRet;
	}
	
	::LeaveCriticalSection( &m_CritSocket );
	
	return TRUE;
}



// DevChiller.h: interface for the CDevLaserPower class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVCHILLER_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_)
#define AFX_DEVCHILLER_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "AsyncComm.h"

class CDevChiller : public CAsyncComm  
{
protected:
  	CRITICAL_SECTION	m_csCommunicationSync;

public:
	double GetChillerTemp();
	BOOL IsConnect();
	int ConvertASCIItoNum(char ascii);
	double ParsePack(char* szResult);
	char* MakePack(char* szCmd);
	void FireReceived(void);
	virtual void ProcessMonitor(void);
	char* QueryCommand(char* szCmd);
	virtual void Destroy(void);
	virtual BOOL Create(void);
	CDevChiller();
	virtual	~CDevChiller();

    CAssEvent FReceiveEvent;

	void SetParameter(int nPortNo, int nBaudRate, int nParity, int nDataBits, int nStopBits, int nFlowControl);
	char m_szCmd[5];
	int m_nPortNo;
	int m_nBaudRate;
	int m_nParity;
	int m_nDataBits;
	int m_nStopBits;
	int m_nFlowControl;
};

#endif // !defined(AFX_DEVCHILLEr_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_)

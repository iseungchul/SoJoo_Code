// HVision.cpp: implementation of the HVision class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "..\easydrillerDlg.h"
#include "HVision2DBarcode.h"
#include "HVision2DBarcodeSock.h"
#include "..\MODEL\DSystemINI.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//#import "C:\Program Files\Cognex\DataMan SDK 5.0.8.0\Binaries\PC\Cognex.DataMan.SDK.PC.dll" raw_interfaces_only, raw_native_types, no_namespace, \
//									named_guids, no_implementation

//using namespace Cognex.DataMan.SDK

volatile __int64 HVision2DBarcode::m_n64Count = 0;

#define DISPLAY_PATTERN	8
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HVision2DBarcode::HVision2DBarcode()
{
	m_bLoadConnect = FALSE;
	m_bUnloadConnect = FALSE;
	m_pClientSock = NULL;
}

HVision2DBarcode::~HVision2DBarcode()
{
	if(m_pClientSock != NULL)
	{
		m_pClientSock->Close();
		delete m_pClientSock;
		m_pClientSock = NULL;
	}
}
BOOL HVision2DBarcode::Connect(BOOL bLoad)
{
	if(m_pClientSock != NULL)
	{
		m_pClientSock->Close();
		delete m_pClientSock;
		m_pClientSock = NULL;
	}
	if(m_pClientSock == NULL)
	{
		AfxSocketInit();
		m_pClientSock = new HVision2DBarcodeSock();
 		m_pClientSock->Create();
	}
	//IP�� ���� �������� 
	if( bLoad)
	{
		if(!m_pClientSock->Connect(gSystemINI.m_sSystemDevice.szVision2DBarcodeIP, 23))
		{
			m_bLoadConnect = FALSE;
			return FALSE;
		}
		else
			m_bLoadConnect = TRUE;
	}
	else
	{
		if(!m_pClientSock->Connect(gSystemINI.m_sSystemDevice.szVision2DBarcodeUnloadIP, 23))
		{
			m_bUnloadConnect = FALSE;
			return FALSE;
		}
		else
			m_bUnloadConnect = TRUE;
	}
	return TRUE;

}

void HVision2DBarcode::Disconnect()
{
	if(m_pClientSock != NULL)
	{
		m_pClientSock->Close();
		delete m_pClientSock;
		m_pClientSock = NULL;
	}
}

BOOL HVision2DBarcode::GetResult(char* szResult, BOOL bLoad)
{
//	if(!m_pClientSock->m_bConnect)
//	{
	Disconnect();
	
	Connect(bLoad);
	Sleep(100);
		//if(m_pClientSock == NULL)
		//{
		//	AfxSocketInit();
		//	m_pClientSock = new HVision2DBarcodeSock();
		//	m_pClientSock->Create();
		//}

		//if(m_pClientSock != NULL)
		//{
		//	if(!m_pClientSock->Connect(gSystemINI.m_sSystemDevice.szVision2DBarcodeIP, 23))
		//	{
		//		m_bLoadConnect = FALSE;
		//	}
		//	else
		//		m_bLoadConnect = TRUE;
		//}
			
//	}

	CString strResult = "";
	if(m_pClientSock != NULL)
		strResult = m_pClientSock->GetBarcodeID();

	if(strResult == "")
		return FALSE;

	strcpy(szResult, (LPCTSTR)strResult);

	return TRUE;
}
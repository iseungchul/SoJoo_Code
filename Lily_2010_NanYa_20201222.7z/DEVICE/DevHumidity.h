// DevHumidity.h: interface for the CDevLaserPower class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVHUMIDITY_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_)
#define AFX_DEVHUMIDITY_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "AsyncComm.h"

class CDevHumidity : public CAsyncComm  
{
protected:
  	CRITICAL_SECTION	m_csCommunicationSync;

public:
	void GetHumiTempDew(double& dHumidity, double& dTemperature, double& dDewPoint);
	BOOL IsConnect();
	void ParsePack();
	void MakePack();
	void FireReceived(void);
	virtual void ProcessMonitor(void);
	char* QueryCommand(char* szCmd);
	virtual void Destroy(void);
	virtual BOOL Create(void);
	CDevHumidity();
	virtual	~CDevHumidity();

    CAssEvent FReceiveEvent;
	char m_szCmd[50];
	char m_szResult[50];
	void SetParameter(int nPortNo, int nBaudRate, int nParity, int nDataBits, int nStopBits, int nFlowControl);
	int m_nPortNo;
	int m_nBaudRate;
	int m_nParity;
	int m_nDataBits;
	int m_nStopBits;
	int m_nFlowControl;
	
	double m_dHumidity; // %
	double m_dTemperature; 
	double m_dDewPoint; 

};

#endif // !defined(AFX_DEVHUMIDITY_H__37D30223_F02D_11D4_9E82_004F490C4B72__INCLUDED_)

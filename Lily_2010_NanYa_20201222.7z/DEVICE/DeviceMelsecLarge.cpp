// DeviceMelsecLarge.cpp: implementation of the DeviceMelsec class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\EasyDriller.h"
#include "DeviceMelsecLarge.h"
#include "math.h"
#include "time.h"
#include "..\alarmmsg.h"
#include "..\Model\DEasyDrillerIni.h"
#include "..\model\dsystemini.h"
#include "..\model\DProcessINI.h"
#include "..\model\ProcessINIFile.h"
#include "..\model\DSystemINI.h"
#include "..\model\SystemINIFile.h"
#include "..\EasyDrillerDlg.h"

#define READ_MELSEC_BASE	 1050
#define OCX_READ_MELSEC_BASE	"R1050"

#define OCX_READ_MELSEC_ALARM	"R1100"

#define WRITE_CHANGE_DIRECTION	1000
#define WRITE_PANEL_TURN		1001
#define WRITE_USE_PAPER			1002
#define WRITE_USE_NGBOX			1003
#define WRITE_OUT_LOAD_BASKET	1004
#define WRITE_OUT_UNLOAD_BASKET 1005
#define WRITE_RESET_BASKET_INFO	1050
#define WRITE_PICKER_MOVE		1006
#define WRITE_NGPANEL			1008
#define WRITE_VIBRATION			1009
#define WRITE_2DBARCODE			1010
#define WRITE_NO_USE_SUCTION	1011
#define WRITE_LOADER_PCB_CHECK  1012
#define WRITE_PCB_SIZE  1013
#define WRITE_SAFETY_MODE		1014

#define WRITE_ALAIN_START		1200
#define WRITE_LOADING_START		1201
#define WRITE_UNLOADING_START	1202
#define WRITE_LOADER_PICKER1_DOWN	1203
#define WRITE_LOADER_PICKER2_DOWN	1204
#define WRITE_UNLOADER_PICKER1_DOWN	1205
#define WRITE_UNLOADER_PICKER2_DOWN	1206
#define WRITE_TABLE1_PCB_EXIST	1207
#define WRITE_TABLE2_PCB_EXIST	1208
#define WRITE_TABLE1_USE	1209
#define WRITE_TABLE2_USE	1210
#define WRITE_TABLE1_VACUUM_ON	1211
#define WRITE_TABLE2_VACUUM_ON	1212



#define TIME_MELSEC_STATUS	50
#define MOTOR_SCALE			1000.0

UINT DeviceMelsecLarge::ThreadStatus(LPVOID pParam)
{
	DeviceMelsecLarge *pMelsec = (DeviceMelsecLarge *)pParam;
	BOOL bFirst = TRUE;
	
	do
	{
#ifndef __TEST__
		Sleep(TIME_MELSEC_STATUS);
#endif
		// read
		pMelsec->ReadStatus(bFirst);

		if(bFirst)
			bFirst = FALSE;
		
	} while(!pMelsec->m_bStatusStop);
	return TRUE;
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DeviceMelsecLarge::DeviceMelsecLarge()
{
	m_thdStatus			= NULL;
	m_bStatusStop		= FALSE;
	m_nIsInPosition		= FALSE;
	m_nInPositionCount	= 0;
	m_pMelsec			= NULL;
	m_pMelsec			= new MMelsecFx();

	m_lErrorHandlerMain	= 0;
	m_lErrorHandlerLoader = 0;
	m_lErrorHandlerUnloader = 0;
	m_lErrorHandlerEtc1 = 0;

	SetAxisMax(HANDLER_AXIS_MAX);

	m_nInposTimeCount = 0;
	memset(m_dScale, 1, sizeof(m_dScale));
	m_bConnect = FALSE;
	m_bWriteLog = TRUE;

	theMelsecDlg = NULL;

}

DeviceMelsecLarge::~DeviceMelsecLarge()
{
	m_bStatusStop = TRUE;

	if(m_thdStatus != NULL)		// Thread ����
		WaitForSingleObject(m_thdStatus->m_hThread, INFINITE);
	m_thdStatus = NULL;

	if(m_pMelsec)
	{
		delete m_pMelsec;
		m_pMelsec = NULL;
	}

	if(theMelsecDlg)
	{
		delete theMelsecDlg;
		theMelsecDlg = NULL;
	}
}

BOOL DeviceMelsecLarge::Initialize()
{
  	BOOL bResult = FALSE;

	if(NULL == theMelsecDlg)
	{
		theMelsecDlg = new CDlgMelsecOCX;
		theMelsecDlg->Create(this);
		theMelsecDlg->ShowWindow(SW_HIDE);
	}

	long lRet;
	for(int i=0; i<=5; i++)
	{
		lRet = theMelsecDlg->m_MelsecQCPU.Open();
		if( 0 == lRet )
		{
			m_bConnect = TRUE;
			break;
		}
		Sleep(200);
	}
	 
	if( 0 != lRet )
	{
		return FALSE;
	}
	else
	{
		if(m_thdStatus == NULL)		// Thread  Ȱ��ȭ
		{
			m_thdStatus = ::AfxBeginThread(ThreadStatus, this);
		}
	}
	return TRUE;


	
}

void DeviceMelsecLarge::ReadStatus(BOOL bFirst)
{
//	if(!m_bConnect)
	//	return;

	long lRet = 0;

	//Loader Input
	lRet = theMelsecDlg->m_MelsecQCPU.ReadDeviceBlock2( OCX_READ_MELSEC_BASE, sizeof(PLC_BIT_SIGNAL_FX), m_nLoader_ReadPLCSignal );
	if( 0 != lRet )
	{
		//theMelsecDlg->GetErrorFromMelsecQ( lRet );
		//AfxMessageBox(_T("Loader Melsec �Է� ��ȣ �б� ����"));
		return;
	}
#ifdef __NANYA__
	lRet = theMelsecDlg->m_MelsecQCPU.ReadDeviceBlock2( OCX_READ_MELSEC_ALARM, sizeof(PLC_BIT_SIGNAL_ALARM), m_nLoader_AlarmPLCSignal );
	if( 0 != lRet )
	{
		//theMelsecDlg->GetErrorFromMelsecQ( lRet );
		//AfxMessageBox(_T("Loader Melsec �Է� ��ȣ �б� ����"));
		return;
	}
#endif

	memcpy(&m_NewPLCBitSignal, &m_nLoader_ReadPLCSignal, sizeof(PLC_BIT_SIGNAL_FX));
#ifndef __NANYA__
	memcpy(&m_NewPLCBitSignalAlarm, &m_NewPLCBitSignal, sizeof(PLC_BIT_SIGNAL_ALARM));
#else
	memcpy(&m_NewPLCBitSignalAlarm, &m_nLoader_AlarmPLCSignal, sizeof(PLC_BIT_SIGNAL_ALARM));
#endif
	memcpy(&m_nPosition, &m_NewPLCBitSignal.wLoaderPos, 8);
	ReadBasket();

	ReadErrorHandler1060();
	ReadErrorHandler1061();
	ReadErrorHandler1062();
	ReadErrorHandler1063();
	ReadErrorHandler1064();
	ReadErrorHandler1065();
	ReadErrorHandler1066();
	ReadErrorHandler1067();


	ReadErrorHandlerLoader1();
	ReadErrorHandlerLoader2();
	ReadErrorHandlerLoader3();
	ReadErrorHandlerLoader4();
	ReadErrorHandlerUnloader1();
	ReadErrorHandlerUnloader2();
	ReadErrorHandlerUnloader3();
	ReadErrorHandlerUnloader4();


/*	ReadErrorHandlerMain();
	ReadErrorHandlerLoader();
	ReadErrorHandlerUnloader();
	ReadErrorHandlerEtc1();
	*/

}

DWORD DeviceMelsecLarge::GetIntPosition(double dPos, int nAxis)
{
	if(!m_bConnect)
		return 999;

	DWORD nResult = 999;
	if(nAxis == AXIS_L_CARRIER)
		nResult = (DWORD)((dPos + 0.5 / m_dScale[nAxis]) * m_dScale[nAxis]);
	return nResult;
}

BOOL DeviceMelsecLarge::SetAxisMax(int nAxisMax)
{
	if(!m_bConnect)
		return FALSE;

	m_nAxisMax = nAxisMax;
	return TRUE;
}

BOOL DeviceMelsecLarge::GetPosition(int nAxis, double &dPosition) // real position
{
	if(!m_bConnect)
	{
		dPosition = -999;
		return TRUE;
	}

	switch(nAxis)
	{
	case HANDLER_LC:
		dPosition = m_nPosition[0] / 10000.; // m_dScale[nAxis];
		break;
	case HANDLER_UC:
		dPosition = m_nPosition[1] / 10000.;// / m_dScale[nAxis];
		break;
	default:
		return FALSE;
	}

	return TRUE;
}

LONG DeviceMelsecLarge::GetCurrentError(ERRORCOMMAND nError)
{
	if(!m_bConnect)
		return 0;

	switch(nError)
	{
	case ERROR_HANDLER_1060	:
		return m_lErrorHandler1060;
	case ERROR_HANDLER_1061	:
		return m_lErrorHandler1061;
	case ERROR_HANDLER_1062	:
		return m_lErrorHandler1062;
	case ERROR_HANDLER_1063	:
		return m_lErrorHandler1063;
	case ERROR_HANDLER_1064	:
		return m_lErrorHandler1064;
	case ERROR_HANDLER_1065	:
		return m_lErrorHandler1065;
	case ERROR_HANDLER_1066	:
		return m_lErrorHandler1066;
	case ERROR_HANDLER_1067	:
		return m_lErrorHandler1067;

	case ERROR_HANDLER_LOADER1	:
		return m_lErrorHandlerLoader1;
	case ERROR_HANDLER_LOADER2	:
		return m_lErrorHandlerLoader2;
	case ERROR_HANDLER_LOADER3	:
		return m_lErrorHandlerLoader3;
	case ERROR_HANDLER_LOADER4	:
		return m_lErrorHandlerLoader4;
	case ERROR_HANDLER_UNLOADER1	:
		return m_lErrorHandlerUnloader1;
	case ERROR_HANDLER_UNLOADER2	:
		return m_lErrorHandlerUnloader2;
	case ERROR_HANDLER_UNLOADER3	:
		return m_lErrorHandlerUnloader3;
	case ERROR_HANDLER_UNLOADER4	:
		return m_lErrorHandlerUnloader4;
	
	}

	return 0;
}
void DeviceMelsecLarge::ReadBasket()
{
	m_lStatusBasket = 0;

	m_lStatusBasket += (m_NewPLCBitSignal.bInputLoadBasket)			? 0x0002 : 0x0000;
	m_lStatusBasket += (m_NewPLCBitSignal.bOutputLoadBasket)		? 0x0004 : 0x0000;
	m_lStatusBasket += (m_NewPLCBitSignal.bInputUnlodBasket)		? 0x0008 : 0x0000;
	m_lStatusBasket += (m_NewPLCBitSignal.bOutputUnloadBasket)		? 0x0010 : 0x0000;
	m_lStatusBasket += (m_NewPLCBitSignal.bChangeDirection)			? 0x0020 : 0x0000;

}
void DeviceMelsecLarge::ReadErrorHandlerMain()
{
	m_lErrorHandlerMain = 0;

	m_lErrorHandlerMain += (m_NewPLCBitSignal.bEStopAlarm)			? 0x0002 : 0x0000;
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bPLCBATAlarm)			? 0x0004 : 0x0000; 
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bAirDownAlarm)		? 0x0008 : 0x0000; 
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bDoorOpenAlarm)		? 0x0010 : 0x0000; 
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bAxis1DriveAlarm)		? 0x0020 : 0x0000; 
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bAxis2DriveAlarm)		? 0x0040 : 0x0000; 
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bAxis3DriveAlarm)		? 0x0080 : 0x0000;
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bAxis1ControlAlarm)	? 0x0100 : 0x0000;
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bAxis2ControlAlarm)	? 0x0200 : 0x0000; 
	m_lErrorHandlerMain += (m_NewPLCBitSignal.bAxis3ControlAlarm)	? 0x0400 : 0x0000;

}

void DeviceMelsecLarge::ReadErrorHandlerLoader()
{
	m_lErrorHandlerLoader = 0;

	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLoadLeftPicker1UpDownCYLAlarm)		? 0x0001 : 0x0000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLoadLeftPicker2UpDownCYLAlarm)		? 0x0002 : 0x0000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLoadLeftPickerVacuumAlarm)			? 0x0004 : 0x0000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLoadRightPicker1UpDownCYLAlarm)	? 0x0008 : 0x0000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLoadRightPicker2UpDownCYLAlarm)	? 0x0010 : 0x0000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLoadRightPickerVacuumAlam)			? 0x0020 : 0x0000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLAlignTableForBackAlarm)			? 0x0040 : 0x0000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLAlign1LeftAlarm)					? 0x0080 : 0x0000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLAlign1FrontAlarm)					? 0x0100 : 0x0000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLAlignPalteAlarm)					? 0x0200 : 0x0000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLAlignROnOffAlarm)					? 0x0400 : 0x0000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLCardLockAlarm)					? 0x0800 : 0x0000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLLifterAlarm)						? 0x1000 : 0x0000; 
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLNGTableForBackAlarm)				? 0x2000 : 0x0000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLPaperTableForBackAlarm)			? 0x4000 : 0x0000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLoadLeftPickerPCBAlarm)			? 0x8000 : 0x0000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLoadRightPickerPCBAlarm)			? 0x10000 : 0x0000;
//	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLoadSafePos)						? 0x20000 : 0x0000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLoadPosAlarm)						? 0x40000 : 0x0000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bLoadUnloadCollisionAlarm)			? 0x80000 : 0x0000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bTwoDetectionAlarm)					? 0x100000 : 0x0000;
	m_lErrorHandlerLoader += (m_NewPLCBitSignal.bTwoDetectionCylinderAlarm)			? 0x200000 : 0x0000;
	
}

void DeviceMelsecLarge::ReadErrorHandlerUnloader()
{
	m_lErrorHandlerUnloader = 0;
	
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUnloadLeftPicker1UpDownCYLAlarm)		? 0x0001 : 0x0000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUnloadLeftPicker2UpDownCYLAlarm)		? 0x0002 : 0x0000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUnloadLeftPickerVacuumAlarm)			? 0x0004 : 0x0000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUnloadRightPicker1UpDownCYLAlarm)	? 0x0008 : 0x0000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUnloadRightPicker2UpDownCYLAlarm)	? 0x0010 : 0x0000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUnloadRightPickerVacuumAlam)			? 0x0020 : 0x0000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUAlignTableForBackAlarm)				? 0x0040 : 0x0000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUAlign1LeftAlarm)					? 0x0080 : 0x0000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUAlign1FrontAlarm)					? 0x0100 : 0x0000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUAlignPalteAlarm)					? 0x0200 : 0x0000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUAlignROnOffAlarm)					? 0x0400 : 0x0000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUCardLockAlarm)						? 0x0800 : 0x0000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bULifterAlarm)						? 0x1000 : 0x0000; 
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUNGTableForBackAlarm)				? 0x2000 : 0x0000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUPaperTableForBackAlarm)				? 0x4000 : 0x0000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUnloadLeftPickerPCBAlarm)			? 0x8000 : 0x0000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUnloadRightPickerPCBAlarm)			? 0x10000 : 0x0000;
//	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUnloadSafePos)						? 0x20000 : 0x0000;
	m_lErrorHandlerUnloader += (m_NewPLCBitSignal.bUnloadPosAlarm)						? 0x40000 : 0x0000;
}

void DeviceMelsecLarge::ReadErrorHandlerEtc1()
{
	m_lErrorHandlerEtc1 = 0;
	
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bTurnTableForBackAlarm)			? 0x00000001 : 0x00000000;
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bTurnTableUpDownAlarm)			? 0x00000002 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bTurnTableVacuumAlarm)			? 0x00000004 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bPaperNoExist)					? 0x00000008 : 0x00000000;
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bPaperBoxFull)					? 0x00000010 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.NGBoxFull)						? 0x00000020 : 0x00000000; 
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bNoUsePaperLoadPaper)				? 0x00000040 : 0x00000000;
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bNoUsePaperUnloadPaper)			? 0x00000080 : 0x00000000;
	m_lErrorHandlerEtc1 += (m_NewPLCBitSignal.bPCBDownDanger)					? 0x00000100 : 0x00000000;
}

BOOL DeviceMelsecLarge::IsMotorStop(BOOL bFlag)
{
	if (bFlag == FALSE)
		m_bCommandStop = FALSE;
	
	return m_bCommandStop;
}

void DeviceMelsecLarge::ReadPosition()
{
	m_nInPositionError = 0;
/*
	if(m_NewPositionInfo.nLCCurrentPos != m_lWritePos[HANDLER_LC])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 1;
		return;
	}

	if(m_NewPositionInfo.nLP1CurrentPos != m_lWritePos[HANDLER_LP1])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 2;
		return;
	}

	if(m_NewPositionInfo.nLP2CurrentPos != m_lWritePos[HANDLER_LP2])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 3;
		return;
	}

	if(m_NewPositionInfo.nLP3CurrentPos != m_lWritePos[HANDLER_LP3])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 4;
		return;
	}

	if(m_NewPositionInfo.nUCCurrentPos != m_lWritePos[HANDLER_UC])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 5;
		return;
	}

	if(m_NewPositionInfo.nUP1CurrentPos != m_lWritePos[HANDLER_UP1])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 6;
		return;
	}
	
	if(m_NewPositionInfo.nUP2CurrentPos != m_lWritePos[HANDLER_UP2])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 7;
		return;
	}
	
	if(m_NewPositionInfo.nUP3CurrentPos != m_lWritePos[HANDLER_UP3])
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 8;
		return;
	}
*/
	m_bCommandStop = TRUE;
}


BOOL DeviceMelsecLarge::IsMoveEnd(int nAxis)
{
	return TRUE;
/*	if(nAxis == -1)
	{
//		if( abs(m_NewPositionInfo.nLCCurrentPos - m_lWritePos[HANDLER_LC] < 5) && m_NewPLCBitSignal.bLCStop && !m_NewPLCBitSignal.bLCBusy)
		if(m_NewPLCBitSignal.bLCStop && !m_NewPLCBitSignal.bLCBusy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 1;
			return FALSE;
		}

//		if( abs(m_NewPositionInfo.nLP1CurrentPos - m_lWritePos[HANDLER_LP1] < 5) && m_NewPLCBitSignal.bLP1Stop && !m_NewPLCBitSignal.bLP1Busy)
		if(m_NewPLCBitSignal.bLP1Stop && !m_NewPLCBitSignal.bLP1Busy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 2;
			return FALSE;
		}

//		if( abs(m_NewPositionInfo.nLP2CurrentPos - m_lWritePos[HANDLER_LP2] < 5) && m_NewPLCBitSignal.bLP2Stop && !m_NewPLCBitSignal.bLP2Busy)
		if(m_NewPLCBitSignal.bLP2Stop && !m_NewPLCBitSignal.bLP2Busy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 3;
			return FALSE;
		}

//		if( abs(m_NewPositionInfo.nLP3CurrentPos - m_lWritePos[HANDLER_LP3] < 5) && m_NewPLCBitSignal.bLP3Stop && !m_NewPLCBitSignal.bLP3Busy)
/*		if(m_NewPLCBitSignal.bLP3Stop && !m_NewPLCBitSignal.bLP3Busy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 4;
			return FALSE;
		}

//		if( abs(m_NewPositionInfo.nUCCurrentPos - m_lWritePos[HANDLER_UC] < 5) && m_NewPLCBitSignal.bUCStop && !m_NewPLCBitSignal.bUCBusy)
		if(m_NewPLCBitSignal.bUCStop && !m_NewPLCBitSignal.bUCBusy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 5;
			return FALSE;
		}

//		if( abs(m_NewPositionInfo.nUP1CurrentPos - m_lWritePos[HANDLER_UP1] < 5) && m_NewPLCBitSignal.bUP1Stop && !m_NewPLCBitSignal.bUP1Busy)
		if(m_NewPLCBitSignal.bUP1Stop && !m_NewPLCBitSignal.bUP1Busy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 6;
			return FALSE;
		}
		
//		if( abs(m_NewPositionInfo.nUP2CurrentPos - m_lWritePos[HANDLER_UP2] < 5) && m_NewPLCBitSignal.bUP2Stop && !m_NewPLCBitSignal.bUP2Busy)
		if(m_NewPLCBitSignal.bUP2Stop && !m_NewPLCBitSignal.bUP2Busy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 7;
			return FALSE;
		}
		
//		if( abs(m_NewPositionInfo.nUP3CurrentPos - m_lWritePos[HANDLER_UP3] < 5) && m_NewPLCBitSignal.bUP3Stop && !m_NewPLCBitSignal.bUP3Busy)
/*		if(m_NewPLCBitSignal.bUP3Stop && !m_NewPLCBitSignal.bUP3Busy)
		{
			m_nInPositionError = 0;
		}
		else
		{
			m_nInPositionError = 8;
			return FALSE;
		}

		return TRUE;
	}
	else
	{
		switch(nAxis)
		{
		case HANDLER_LC:
//			if( abs(m_NewPositionInfo.nLCCurrentPos - m_lWritePos[HANDLER_LC] < 5) && m_NewPLCBitSignal.bLCStop && !m_NewPLCBitSignal.bLCBusy)
			if(m_NewPLCBitSignal.bLCStop && !m_NewPLCBitSignal.bLCBusy)
			{
				return TRUE;
			}
			break;
		case HANDLER_LP1:
//			if( abs(m_NewPositionInfo.nLP1CurrentPos - m_lWritePos[HANDLER_LP1] < 5) && m_NewPLCBitSignal.bLP1Stop && !m_NewPLCBitSignal.bLP1Busy)
			if(m_NewPLCBitSignal.bLP1Stop && !m_NewPLCBitSignal.bLP1Busy)
			{
				return TRUE;
			}
			break;
		case HANDLER_LP2:
//			if( abs(m_NewPositionInfo.nLP2CurrentPos - m_lWritePos[HANDLER_LP2] < 5) && m_NewPLCBitSignal.bLP2Stop && !m_NewPLCBitSignal.bLP2Busy)
			if(m_NewPLCBitSignal.bLP2Stop && !m_NewPLCBitSignal.bLP2Busy)
			{
				return TRUE;
			}
			break;
//		case HANDLER_LP3:
//			if( abs(m_NewPositionInfo.nLP3CurrentPos - m_lWritePos[HANDLER_LP3] < 5) && m_NewPLCBitSignal.bLP3Stop && !m_NewPLCBitSignal.bLP3Busy)
//			if(m_NewPLCBitSignal.bLP3Stop && !m_NewPLCBitSignal.bLP3Busy)
//			{
//				return TRUE;
//			}
//			break;
		case HANDLER_UC:
//			if( abs(m_NewPositionInfo.nUCCurrentPos - m_lWritePos[HANDLER_UC] < 5) && m_NewPLCBitSignal.bUCStop && !m_NewPLCBitSignal.bUCBusy)
			if(m_NewPLCBitSignal.bUCStop && !m_NewPLCBitSignal.bUCBusy)
			{
				return TRUE;
			}
			break;
		case HANDLER_UP1:
//			if( abs(m_NewPositionInfo.nUP1CurrentPos - m_lWritePos[HANDLER_UP1] < 5) && m_NewPLCBitSignal.bUP1Stop && !m_NewPLCBitSignal.bUP1Busy)
			if(m_NewPLCBitSignal.bUP1Stop && !m_NewPLCBitSignal.bUP1Busy)
			{
				return TRUE;
			}
			break;
		case HANDLER_UP2:
//			if( abs(m_NewPositionInfo.nUP2CurrentPos - m_lWritePos[HANDLER_UP2] < 5) && m_NewPLCBitSignal.bUP2Stop && !m_NewPLCBitSignal.bUP2Busy)
			if(m_NewPLCBitSignal.bUP2Stop && !m_NewPLCBitSignal.bUP2Busy)
			{
				return TRUE;
			}
			break;
//		case HANDLER_UP3:
//			if( abs(m_NewPositionInfo.nUP3CurrentPos - m_lWritePos[HANDLER_UP3] < 5) && m_NewPLCBitSignal.bUP3Stop && !m_NewPLCBitSignal.bUP3Busy)
//			if(m_NewPLCBitSignal.bUP3Stop && !m_NewPLCBitSignal.bUP3Busy)
//			{
//				return TRUE;
//			}
//			break;
		}
	}

	m_nInPositionError = nAxis + 1;

	return FALSE;
		*/
}

BOOL DeviceMelsecLarge::IsHandlerBusy(int nAxis)
{
	return FALSE;
/*	BOOL bRet = TRUE;
	switch(nAxis)
	{
	case HANDLER_LC:
		bRet = m_NewPLCBitSignal.bLCBusy;
		break;
	case HANDLER_LP1:
		bRet = m_NewPLCBitSignal.bLP1Busy;
		break;
	case HANDLER_LP2:
		bRet = m_NewPLCBitSignal.bLP2Busy;
		break;
//	case HANDLER_LP3:
//		bRet = m_NewPLCBitSignal.bLP3Busy;
//		break;
	case HANDLER_UC:
		bRet = m_NewPLCBitSignal.bUCBusy;
		break;
	case HANDLER_UP1:
		bRet = m_NewPLCBitSignal.bUP1Busy;
		break;
	case HANDLER_UP2:
		bRet = m_NewPLCBitSignal.bUP2Busy;
		break;
//	case HANDLER_UP3:
//		bRet = m_NewPLCBitSignal.bUP3Busy;
//		break;
	}
	return bRet;
	*/
}

BOOL DeviceMelsecLarge::IsHandlerStop(int nAxis)
{
	return FALSE;
/*	BOOL bRet = TRUE;
	switch(nAxis)
	{
	case HANDLER_LC:
		bRet = m_NewPLCBitSignal.bLCStop;
		break;
	case HANDLER_LP1:
		bRet = m_NewPLCBitSignal.bLP1Stop;
		break;
	case HANDLER_LP2:
		bRet = m_NewPLCBitSignal.bLP2Stop;
		break;
//	case HANDLER_LP3:
//		bRet = m_NewPLCBitSignal.bLP3Stop;
//		break;
	case HANDLER_UC:
		bRet = m_NewPLCBitSignal.bUCStop;
		break;
	case HANDLER_UP1:
		bRet = m_NewPLCBitSignal.bUP1Stop;
		break;
	case HANDLER_UP2:
		bRet = m_NewPLCBitSignal.bUP2Stop;
		break;
//	case HANDLER_UP3:
//		bRet = m_NewPLCBitSignal.bUP3Stop;
//		break;
	}
	return bRet;
	*/

}

BOOL DeviceMelsecLarge::IsMotorOrigin(int nAxis)
{
	return TRUE;
/*	BOOL bRet = TRUE;
	if(nAxis == -1)
	{
		bRet = m_NewPLCBitSignal.bLCInitialEnd & m_NewPLCBitSignal.bLP1InitialEnd & m_NewPLCBitSignal.bLP2InitialEnd & m_NewPLCBitSignal.bLP3InitialEnd &
			m_NewPLCBitSignal.bUCInitialEnd & m_NewPLCBitSignal.bUP1InitialEnd & m_NewPLCBitSignal.bUP2InitialEnd & m_NewPLCBitSignal.bUP3InitialEnd;
	}
	else
	{
		switch(nAxis)
		{
		case HANDLER_LC:
			bRet = m_NewPLCBitSignal.bLCInitialEnd;
			break;
		case HANDLER_LP1:
			bRet = m_NewPLCBitSignal.bLP1InitialEnd;
			break;
		case HANDLER_LP2:
			bRet = m_NewPLCBitSignal.bLP2InitialEnd;
			break;
//		case HANDLER_LP3:
//			bRet = m_NewPLCBitSignal.bLP3InitialEnd;
//			break;
		case HANDLER_UC:
			bRet = m_NewPLCBitSignal.bUCInitialEnd;
			break;
		case HANDLER_UP1:
			bRet = m_NewPLCBitSignal.bUP1InitialEnd;
			break;
		case HANDLER_UP2:
			bRet = m_NewPLCBitSignal.bUP2InitialEnd;
			break;
//		case HANDLER_UP3:
//			bRet = m_NewPLCBitSignal.bUP3InitialEnd;
//			break;
		}
	}
	return bRet;
	*/
}

BOOL DeviceMelsecLarge::PeekMessage()
{
	MSG msg;
	if(::PeekMessage((LPMSG)&msg,(HWND)NULL,(WORD)NULL,(WORD)NULL,PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
		return TRUE;
	}
	return FALSE;
}

int DeviceMelsecLarge::IsInPosition(int nAxis, BOOL bWait/*TRUE*/)
{
	return TRUE;
/*	if(bWait)
	{
		m_nInPositionAxis = nAxis;
		return IsInPositionThread(nAxis, COMMAND_INPOSITION);
	}
	return IsMoveEnd(nAxis);
	*/
}

int DeviceMelsecLarge::IsInOrigin(int nAxis, BOOL bWait/*TRUE*/)
{
	return TRUE;
/*	if(bWait)
	{
		m_nInPositionAxis = nAxis;
		return IsInPositionThread(nAxis, COMMAND_INORIGIN);
	}
	return IsMotorOrigin(nAxis);
	*/
}

BOOL DeviceMelsecLarge::IsReady(int nAxis)
{
	BOOL bRet = TRUE;
/*	if(nAxis == -1)
	{
		bRet = m_NewPLCBitSignal.bLCReady & m_NewPLCBitSignal.bLP1Ready & m_NewPLCBitSignal.bLP2Ready //& m_NewPLCBitSignal.bLP3Ready &
			m_NewPLCBitSignal.bUCReady & m_NewPLCBitSignal.bUP1Ready & m_NewPLCBitSignal.bUP2Ready;// & m_NewPLCBitSignal.bUP3Ready;
	}
	else
	{
		switch(nAxis)
		{
		case HANDLER_LC:
			bRet = m_NewPLCBitSignal.bLCReady;
			break;
		case HANDLER_LP1:
			bRet = m_NewPLCBitSignal.bLP1Ready;
			break;
		case HANDLER_LP2:
			bRet = m_NewPLCBitSignal.bLP2Ready;
			break;
//		case HANDLER_LP3:
//			bRet = m_NewPLCBitSignal.bLP3Ready;
//			break;
		case HANDLER_UC:
			bRet = m_NewPLCBitSignal.bUCReady;
			break;
		case HANDLER_UP1:
			bRet = m_NewPLCBitSignal.bUP1Ready;
			break;
		case HANDLER_UP2:
			bRet = m_NewPLCBitSignal.bUP2Ready;
			break;
//		case HANDLER_UP3:
//			bRet = m_NewPLCBitSignal.bUP3Ready;
//			break;
		}
	}
	*/
	return bRet;
}

int DeviceMelsecLarge::GetAxisMax()
{
	if(!m_bConnect)
		return 2;
	return m_nAxisMax;
}

void DeviceMelsecLarge::GetBitSiganl(PLC_BIT_SIGNAL_FX *pData)
{
	memcpy(pData, &m_NewPLCBitSignal, sizeof(PLC_BIT_SIGNAL_FX));
}

int DeviceMelsecLarge::GetCurrentPos(int nAxis)
{
	if(nAxis == HANDLER_LC)
		return m_nPosition[0];
//	if(nAxis == HANDLER_LP1)
//		return m_NewPositionInfo.nLP1CurrentPos;
//	if(nAxis == HANDLER_LP2)
//		return m_NewPositionInfo.nLP2CurrentPos;
//	if(nAxis == HANDLER_LP3)
//		return m_NewPositionInfo.nLP3CurrentPos;
	if(nAxis == HANDLER_UC)
		return m_nPosition[1];;
//	if(nAxis == HANDLER_UP1)
//		return m_NewPositionInfo.nUP1CurrentPos;
//	if(nAxis == HANDLER_UP2)
//		return m_NewPositionInfo.nUP2CurrentPos;
//	if(nAxis == HANDLER_UP3)
//		return m_NewPositionInfo.nUP3CurrentPos;
	return 0;
}

int DeviceMelsecLarge::GetWritePos(int nAxis)
{
	return m_lWritePos[nAxis];
}

BOOL DeviceMelsecLarge::IsUnloadertoLoadStart()
{
	return m_NewPLCBitSignal.bLoadRequestReady;
}

BOOL DeviceMelsecLarge::IsAligner(BOOL bStop)
{
	if(bStop)
	{
		return m_NewPLCBitSignal.bAlignEnd;
	}
	else
	{
		return m_NewPLCBitSignal.bAlignRun;
	}
}

BOOL DeviceMelsecLarge::IsUnload(BOOL bStop)
{
	if(bStop)
	{
		return m_NewPLCBitSignal.bUnloadEnd && m_NewPLCBitSignal.bUnloadReady;	
	}
	else
	{
		return m_NewPLCBitSignal.bUnloadRun;
	}
}

BOOL DeviceMelsecLarge::IsLoader(BOOL bStop)
{
	if(bStop)
	{
		return m_NewPLCBitSignal.bLoadEnd;
	}
	else
	{
		return m_NewPLCBitSignal.bLoadRun;
	}
}

BOOL DeviceMelsecLarge::IsLoaderPicker1PCBExist()
{
	if(m_NewPLCBitSignal.bLP1PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceMelsecLarge::IsLoaderPicker2PCBExist()
{
	if(m_NewPLCBitSignal.bLP2PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceMelsecLarge::IsUnloaderPicker1PCBExist()
{
	if(m_NewPLCBitSignal.bUP1PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceMelsecLarge::IsUnloaderPicker2PCBExist()
{
	if(m_NewPLCBitSignal.bUP2PCBExist)
		return TRUE;
	else
		return FALSE;
}

BOOL DeviceMelsecLarge::IsResetSwitch()
{
	return FALSE;

	//return m_NewPLCBitSignal.bSystemReset;
}

BOOL DeviceMelsecLarge::IsSystemDoorBypass(BOOL bLoader)
{
	return TRUE;
//	if(bLoader)
//		return m_NewPLCBitSignal.bLoaderInterlockBypass;
//	else
//		return m_NewPLCBitSignal.bUnloaderInterlockBypass;
}

BOOL DeviceMelsecLarge::IsAnyMotorRun()
{
	return TRUE;
//	return (m_NewPLCBitSignal.bLCBusy | m_NewPLCBitSignal.bLP1Busy | m_NewPLCBitSignal.bLP2Busy |/* m_NewPLCBitSignal.bLP3Busy |*/
//		m_NewPLCBitSignal.bUCBusy | m_NewPLCBitSignal.bUP1Busy | m_NewPLCBitSignal.bUP2Busy /*| m_NewPLCBitSignal.bUP3Busy*/);
}

BOOL DeviceMelsecLarge::IsLoadCartNoPCB()
{
	if(!m_bConnect)
		return FALSE;

	return !m_NewPLCBitSignal.bLdElvPCBExist;
	/*
	if(m_NewPLCBitSignal.bLdElvPCBExist)
		return FALSE;
	else
		return TRUE;
		*/
}

BOOL DeviceMelsecLarge::SendLoadCartNoPCB()
{
	return TRUE;
}

BOOL DeviceMelsecLarge::LoaderAlign(BOOL bOn)
{
	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = bOn; // 1�̸� Ű�� 0�̸� ���� 
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_ALAIN_START), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;
}

BOOL DeviceMelsecLarge::LoaderLoading(BOOL bOn)
{
	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = bOn; // 1�̸� Ű�� 0�̸� ���� 
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_LOADING_START), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;
}

BOOL DeviceMelsecLarge::UnloadUnloading(BOOL bOn)
{
	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = bOn; // 1�̸� Ű�� 0�̸� ���� 
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_UNLOADING_START), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;
}

BOOL DeviceMelsecLarge::LoaderInit()
{
	return TRUE;
	/*
	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_COMMAND_BASE + 3, 1); // 1 bits
	return bResult;
	*/
}

BOOL DeviceMelsecLarge::UnloaderInit()
{
	return TRUE;
/*	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_COMMAND_BASE + 4, 1); // 1 bits
	return bResult;
	*/
}

BOOL DeviceMelsecLarge::LoaderAlignLoading()
{
	return TRUE;
/*	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_COMMAND_BASE + 5, 1); // 1 bits
	return bResult;
	*/
}

BOOL DeviceMelsecLarge::SetOutPort(BYTE nPortNo, WORD wOnOff)
{
	//return TRUE;
	
	BOOL bResult = TRUE;
	BYTE cVal;
	if(wOnOff)	cVal = 0x10;
	else		cVal = 0x01;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	short nData2[1];

	nData[0] = wOnOff & 0x01; // 
	nData2[0] = (wOnOff >> 1) & 0x01; // 

	switch(nPortNo)
	{
/*	case PORT_ALARM	:
		bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_INTERFACE_BASE, 1); // 1 bits
		return bResult;
		break;
	case PORT_SYSTEM_DOOR_BYPASS:
		bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_INTERFACE_BASE + 1, 1);
		return bResult;
		break;*/
	case PORT_PCB_SINGLE	:
		lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_TABLE1_USE), lSize, nData );
		lRet &= theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_TABLE2_USE), lSize, nData2 );
		break;
	}

	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

	return TRUE;
	
}

BOOL DeviceMelsecLarge::MainReset(BOOL bOn)
{
	return TRUE;
	/*
	BOOL bResult = TRUE;
	BYTE cVal;

	if(bOn)	cVal = 0x10;
	else	cVal = 0x01;

	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_INTERFACE_BASE + 2, 1); // 1 bits
	return bResult;
	*/
}

BOOL DeviceMelsecLarge::LoaderPCBReset()
{
	return TRUE;
/*	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_REJECT_BASE, 1); // 1 bits
	return bResult;
	*/
}

BOOL DeviceMelsecLarge::UnloaderPCBReset()
{
	return TRUE;
/*	BOOL bResult = TRUE;
	BYTE cVal = 0x10;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_REJECT_BASE + 1, 1); // 1 bits
	return bResult;
	*/
}

BOOL DeviceMelsecLarge::LoaderCarrierElvPos()
{
	if(!m_bConnect)
		return FALSE;

	if(!m_NewPLCBitSignal.bLoadSafePos)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = 3;
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_PICKER_MOVE), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}

BOOL DeviceMelsecLarge::LoaderCarrierTablePos()
{
	if(!m_bConnect)
		return FALSE;

	if(!m_NewPLCBitSignal.bLoadSafePos)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = 1;
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_PICKER_MOVE), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}

BOOL DeviceMelsecLarge::UnloaderCarrierElvPos()
{
	if(!m_bConnect)
		return FALSE;
	if(!m_NewPLCBitSignal.bUnloadSafePos)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = 3;
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_PICKER_MOVE + 1), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}

BOOL DeviceMelsecLarge::UnloaderCarrierTablePos()
{
	if(!m_bConnect)
		return FALSE;
	if(!m_NewPLCBitSignal.bUnloadSafePos)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = 1;
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_PICKER_MOVE + 1), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}

BOOL DeviceMelsecLarge::LoaderPickerUpPos(int nNum)
{
	return TRUE;
/*	BOOL bResult = TRUE;
	BYTE cVal = 0x10;

	nNum = nNum - 1;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LP_MOVING_BASE + (nNum*10), 1); // 1 bits
	return bResult;
	*/
}

BOOL DeviceMelsecLarge::UnloaderPickerUpPos(int nNum)
{
	return TRUE;
/*	BOOL bResult = TRUE;
	BYTE cVal = 0x10;

	nNum = nNum - 1;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_UP_MOVING_BASE + (nNum*10), 1); // 1 bits
	return bResult;
	*/
}

BOOL DeviceMelsecLarge::UseRoll(BOOL bUse)
{
	return TRUE;
/*	BOOL bResult = TRUE;
	BYTE cVal;
	
	if(!bUse)	cVal = 0x10; // On�̸� ������
	else		cVal = 0x01;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_ROLL_BASE, 1); // 1 bits
	return bResult;
	*/
}

BOOL DeviceMelsecLarge::UsePaper(BOOL bUse)
{
	return TRUE;
/*	BOOL bResult = TRUE;
	BYTE cVal;
	
	if(!bUse)	cVal = 0x10; // On�̸� ������
	else		cVal = 0x01;
	
	bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_PAPER_BASE, 1); // 1 bits
	return bResult;
	*/
}

BOOL DeviceMelsecLarge::IsHandlerTablePCBExist(BOOL bLoader)
{
	return TRUE;
/*	if(bLoader)
		return m_NewPLCBitSignal.bLdTablePCBExist;
	else
		return m_NewPLCBitSignal.bUdTablePCBExist;
		*/
}

BOOL DeviceMelsecLarge::IsHandlerPaperTransPCBExist(BOOL bLoader)
{
	return TRUE;
/*	if(bLoader)
		return m_NewPLCBitSignal.bLdPaperTransPCBExist;
	else
		return m_NewPLCBitSignal.bUdPaperTransPCBExist;
		*/
}

BOOL DeviceMelsecLarge::IsHandlerPartError(BOOL bLoader)
{
	if(!m_bConnect)
		return FALSE;

	if(bLoader)
	{
		if((m_lErrorHandlerLoader1 > 0) ||
			(m_lErrorHandlerLoader2 > 0) ||
			(m_lErrorHandlerLoader3 > 0) ||
			(m_lErrorHandlerLoader4 > 0))
			return TRUE;
		else
			return FALSE;
	}
	else
	{
		if((m_lErrorHandlerUnloader1 > 0) ||
			(m_lErrorHandlerUnloader2 > 0) ||
			(m_lErrorHandlerUnloader3 > 0) ||
			(m_lErrorHandlerUnloader4 > 0))
			return TRUE;
		else
			return FALSE;
	}
}

BOOL DeviceMelsecLarge::SetPickerVacuum(BOOL bLoader, BOOL b1st, BOOL bOn)
{
	return TRUE;
	/*BOOL bResult = TRUE;
	BYTE cVal, cVal2;

	if(bOn)
	{
		cVal = 0x10;
		cVal2 = 0x01;
	}
	else
	{
		cVal = 0x01;
		cVal2 = 0x10;
	}
	if(bLoader)//�δ� 
	{
		if(b1st)
		{
			bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LP_MOVING_BASE + 1, 1); // 1 bits
			bResult = bResult & m_pMelsec->WriteBitMembyBits(&cVal2, WRITE_LP_MOVING_BASE + 2, 1); // 1 bits
		}
		else
		{
			bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_LP_MOVING_BASE + 11, 1); // 1 bits
			bResult = bResult & m_pMelsec->WriteBitMembyBits(&cVal2, WRITE_LP_MOVING_BASE + 12, 1); // 1 bits
		}
	}
	else//���δ� 
	{
		if(b1st)
		{
			bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_UP_MOVING_BASE + 1, 1); // 1 bits
			bResult = bResult & m_pMelsec->WriteBitMembyBits(&cVal2, WRITE_UP_MOVING_BASE + 2, 1); // 1 bits
		}
		else
		{
			bResult = m_pMelsec->WriteBitMembyBits(&cVal, WRITE_UP_MOVING_BASE + 11, 1); // 1 bits
			bResult = bResult & m_pMelsec->WriteBitMembyBits(&cVal2, WRITE_UP_MOVING_BASE + 12, 1); // 1 bits
		}
	}

	return bResult;
	*/
}

BOOL DeviceMelsecLarge::IsLPVacuum(BOOL b1st, BOOL bOn)
{
	return TRUE;
	/*
	if(b1st)
	{
		if(bOn)
			return m_NewPLCBitSignal.bLdPick1VacOn;
		else
			return m_NewPLCBitSignal.bLdPick1VacOff;
	}
	else
	{
		if(bOn)
			return m_NewPLCBitSignal.bLdPick2VacOn;
		else
			return m_NewPLCBitSignal.bLdPick2VacOff;
	}
	*/
}

BOOL DeviceMelsecLarge::IsUPVacuum(BOOL b1st, BOOL bOn)
{
	return TRUE;
/*	if(b1st)
	{
		if(bOn)
			return m_NewPLCBitSignal.bUdPick1VacOn;
		else
			return m_NewPLCBitSignal.bUdPick1VacOff;
	}
	else
	{
		if(bOn)
			return m_NewPLCBitSignal.bUdPick2VacOn;
		else
			return m_NewPLCBitSignal.bUdPick2VacOff;
	}
	*/
}

BOOL DeviceMelsecLarge::CheckMelsecConnect()
{
	return m_bConnect;
//	return m_NewPLCBitSignal.bMelsecConnect;
}

BOOL DeviceMelsecLarge::GetReverseDirection()
{
	if(!m_bConnect)
		return FALSE;

	return m_NewPLCBitSignal.bChangeDirection; // 1 : Reverse
}
BOOL DeviceMelsecLarge::GetLoadBasketSignal(BOOL bIn)
{
	if(!m_bConnect)
		return FALSE;

	if(bIn)
		return m_NewPLCBitSignal.bInputLoadBasket;
	else
		return m_NewPLCBitSignal.bOutputLoadBasket;
}
BOOL DeviceMelsecLarge::GetUnloadBasketSignal(BOOL bIn)
{
	if(!m_bConnect)
		return FALSE;

	if(bIn) 
		return m_NewPLCBitSignal.bInputUnlodBasket;
	else
		return m_NewPLCBitSignal.bOutputUnloadBasket;
}
BOOL DeviceMelsecLarge::SetReverseDirection(BOOL bChange)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	if(bChange)		nData[0] = 0x02; // ������
	else			nData[0] = 0x01; // ������
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_CHANGE_DIRECTION), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}
BOOL DeviceMelsecLarge::SetTrunPanel(BOOL bTurn)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = bTurn; // ������
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_PANEL_TURN), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}

BOOL DeviceMelsecLarge::SetPCBSize(int bLarge)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = bLarge; // ������
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_PCB_SIZE), lSize, nData );
	
 	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}

BOOL DeviceMelsecLarge::SetUsePaperBox(BOOL bUse)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = bUse; // ������
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_USE_PAPER), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}
BOOL DeviceMelsecLarge::SetUseNGBox(BOOL bUse)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = bUse; // ������
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_USE_NGBOX), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}
BOOL DeviceMelsecLarge::SetOutputBasket(BOOL bLoad)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = 1; // ������
	if(bLoad)
		lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_OUT_LOAD_BASKET), lSize, nData );
	else
		lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_OUT_UNLOAD_BASKET), lSize, nData );

	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}
BOOL DeviceMelsecLarge::ResetBasketInfo(BOOL bLoad)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = 0x10; // ������
	if(bLoad)
		lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_RESET_BASKET_INFO), lSize, nData );
	else
		lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_RESET_BASKET_INFO+2), lSize, nData );

	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}
BOOL DeviceMelsecLarge::SetNGPanel(int nNG)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = nNG; // ������
	
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_NGPANEL), lSize, nData );

	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}
BOOL DeviceMelsecLarge::InPositionStop()
{
	m_nIsInPosition = -3;
	return TRUE;
}

BOOL DeviceMelsecLarge::LoaderClampForward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::LoaderClampBackward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::LoaderTableForward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::LoaderTableBackward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::LoaderAlignXForward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::LoaderAlignXBackward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::LoaderAlignYForward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::LoaderAlignYBackward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::UnloaderClampForward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::UnloaderClampBackward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::UnloaderTableForward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::UnloaderTableBackward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::IsLoaderAlignTableForward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::IsUnloaderAlignTableForward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::IsLoaderCartClamp()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::IsAlignSheetTableForward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::IsAlignGuideForward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::IsUnloaderCartClamp()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::IsUnloaderNGBoxForward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::IsUnloaderNGBoxBackward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::UnloaderNGBoxForward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::UnloaderNGBoxBackward()
{
	return TRUE;
}
BOOL DeviceMelsecLarge::SetVibration(int nCount)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = nCount; // ������
	
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_VIBRATION), lSize, nData );

	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}
BOOL DeviceMelsecLarge::IsStartMode()
{
	if(!m_bConnect)
		return TRUE;

	return m_NewPLCBitSignal.bStartMode;
}
BYTE DeviceMelsecLarge::GetBasketIn()
{
	if(!m_bConnect)
		return FALSE;

	return (m_NewPLCBitSignal.bLoadBoxNoExist & 0x01) + (m_NewPLCBitSignal.bUnloadBoxNoExist << 1 & 0x02);
}
BOOL DeviceMelsecLarge::Set2DBarcodeTrigger()
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = 1;
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_2DBARCODE), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;
}
BOOL DeviceMelsecLarge::SetNoUseSuction(BOOL bNoUse)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = bNoUse;
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_NO_USE_SUCTION), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;
}

PLC_BIT_SIGNAL_FX DeviceMelsecLarge::GetMelsecIOStuct()
{
	return m_NewPLCBitSignal;
}
BOOL DeviceMelsecLarge::IsAlignerPCBExist()
{
	return m_NewPLCBitSignal.bAlignTablePCBExist;
}

BOOL DeviceMelsecLarge::SetLoaderCartPCB(BOOL bNoUse)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = bNoUse;
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_LOADER_PCB_CHECK), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}

BOOL DeviceMelsecLarge::SetSafetyMode(int bMode)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = bMode;
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_SAFETY_MODE), lSize, nData );
	
	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;

}

//2015.03.31 pjm
CString DeviceMelsecLarge::MakeRCode(int nCode)
{
	CString strData;
	strData.Format("R%d", nCode);
	
	return strData;
}

void DeviceMelsecLarge::ReadErrorHandler1060()
{
	m_lErrorHandler1060 = 0;
#ifndef __NANYA__
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bEStopAlarm)								? 0x0001 : 0x0000;
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bPLCBATAlarm)							? 0x0002 : 0x0000; 
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bAirDownAlarm)							? 0x0004 : 0x0000; 
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bDoorOpenAlarm)							? 0x0008 : 0x0000; 
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bAxis1LoadXAlarm)						? 0x0010 : 0x0000; 
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bAxis2LoadZLAlarm)						? 0x0020 : 0x0000; 
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bAxis3LoadZRAlarm)						? 0x0040 : 0x0000; 
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bAxis4UnloadXAlarm)						? 0x0080 : 0x0000; 
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bAxis5UnloadZLAlarm)						? 0x0100 : 0x0000; 
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bAxis6UnloadZRAlarm)						? 0x0200 : 0x0000;
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bAxis7LoadAlign1Alarm)					? 0x0400 : 0x0000;
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bAxis8LoadAlign2Alarm)					? 0x0800 : 0x0000;
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bAxis9LoadAlign3Alarm)					? 0x1000 : 0x0000; 
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bAxis10LoadAlign4Alarm)					? 0x2000 : 0x0000;
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bAxis11UnloadAlign1Alarm)				? 0x4000 : 0x0000;
	m_lErrorHandler1060 += (m_NewPLCBitSignalAlarm.bAxis12UnloadAlign2Alarm)				? 0x8000 : 0x0000;
#endif
}
void DeviceMelsecLarge::ReadErrorHandler1061()
{
	m_lErrorHandler1061 = 0;
#ifndef __NANYA__
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bAxis13UnloadAlign3Alarm)				? 0x0001 : 0x0000;
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bAxis14UnloadAlign4Alarm)				? 0x0002 : 0x0000; 
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bLoadHomeAlarm)							? 0x0004 : 0x0000; 
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bLoadLeftExistAlarm)						? 0x0008 : 0x0000; 
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bLoadRightExistAlarm)					? 0x0010 : 0x0000; 
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bLoadAlignExistAlarm)					? 0x0020 : 0x0000; 
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bUnloadHomeAlarm)						? 0x0040 : 0x0000; 
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bUnloadLeftExistAlarm)					? 0x0080 : 0x0000; 
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bUnloadRightExistAlarm)					? 0x0100 : 0x0000; 
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bUnloadAlignExistAlarm)					? 0x0200 : 0x0000;
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bDummyR1061_10)							? 0x0400 : 0x0000;
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bDummyR1061_11)							? 0x0800 : 0x0000;
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bLoadIonizer1Alarm)						? 0x1000 : 0x0000; 
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bLoadIonizer2Alarm)						? 0x2000 : 0x0000;
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bUnloadIonizer1Alarm)						? 0x4000 : 0x0000;
	m_lErrorHandler1061 += (m_NewPLCBitSignalAlarm.bUnloadIonizer21Alarm)						? 0x8000 : 0x0000;
#endif
}
void DeviceMelsecLarge::ReadErrorHandler1062()
{
	m_lErrorHandler1062 = 0;
#ifndef __NANYA__
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bLoadMainPCBDropAlarm)					? 0x0001 : 0x0000;
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bUnloadMainPCBDropAlarm)					? 0x0002 : 0x0000; 
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bDummyR1062_2)							? 0x0004 : 0x0000; 
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bDummyR1062_3)							? 0x0008 : 0x0000; 
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bDummyR1062_4)							? 0x0010 : 0x0000; 
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bDummyR1062_5)							? 0x0020 : 0x0000; 
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bDummyR1062_6)							? 0x0040 : 0x0000; 
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bDummyR1062_7)							? 0x0080 : 0x0000; 
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bLoadLeftSuctionAlarm)					? 0x0100 : 0x0000; 
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bLoadRightSuctionAlarm)					? 0x0200 : 0x0000;
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bLoad2PCBAlarm)							? 0x0400 : 0x0000;
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bLoadLeftPCBSizeAlarm)					? 0x0800 : 0x0000;
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bLoadRightPCBSizeAlarm)					? 0x1000 : 0x0000; 
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bLoadLeftPCBExistAlarm)					? 0x2000 : 0x0000;
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bLoadrightCBExistAlarm)					? 0x4000 : 0x0000;
	m_lErrorHandler1062 += (m_NewPLCBitSignalAlarm.bDummyR1062_15)							? 0x8000 : 0x0000;
#endif
}
void DeviceMelsecLarge::ReadErrorHandler1063()
{
	m_lErrorHandler1063 = 0;
#ifndef __NANYA__
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bUnloadLeftSuctionAlarm)					? 0x0001 : 0x0000;
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bUnloadRightSuctionAlarm)				? 0x0002 : 0x0000; 
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bUnload2PCBAlarm)						? 0x0004 : 0x0000; 
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bUnloadLeftPCBSizeAlarm)					? 0x0008 : 0x0000; 
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bUnloadRightPCBSizeAlarm)				? 0x0010 : 0x0000; 
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bUnloadLeftPCBExistAlarm)				? 0x0020 : 0x0000; 
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bUnloadrightCBExistAlarm)				? 0x0040 : 0x0000; 
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bDummyR1063_7)							? 0x0080 : 0x0000; 
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bLoadAlignSuctionAlarm)					? 0x0100 : 0x0000; 
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bLoadAlignExistnAlarm)					? 0x0200 : 0x0000;
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bLoadAlignLeftForwardAlarm)				? 0x0400 : 0x0000;
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bLoadAlignLeftBackwardAlarm)				? 0x0800 : 0x0000;
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bLoadAlignRightForwardAlarm)				? 0x1000 : 0x0000; 
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bLoadAlignRightBackwardAlarm)			? 0x2000 : 0x0000;
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bDummyR1063_14)							? 0x4000 : 0x0000;
	m_lErrorHandler1063 += (m_NewPLCBitSignalAlarm.bDummyR1063_15)							? 0x8000 : 0x0000;
#endif
}
void DeviceMelsecLarge::ReadErrorHandler1064()
{
	m_lErrorHandler1064 = 0;
#ifndef __NANYA__
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bUnloadAlignSuctionAlarm)				? 0x0001 : 0x0000;
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bUnloadAlignExistnAlarm)					? 0x0002 : 0x0000; 
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bUnloadAlignLeftForwardAlarm)			? 0x0004 : 0x0000; 
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bUnloadAlignLeftBackwardAlarm)			? 0x0008 : 0x0000; 
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bUnloadAlignLeftForwardAlarm)			? 0x0010 : 0x0000; 
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bUnloadAlignLeftBackwardAlarm)			? 0x0020 : 0x0000; 
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bDummyR1064_6)							? 0x0040 : 0x0000; 
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bDummyR1064_7)							? 0x0080 : 0x0000; 
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bLoadPaperNoAlarm)						? 0x0100 : 0x0000; 
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bLoadPaperFULLAlarm)						? 0x0200 : 0x0000;
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bLoadPaperTableForwardAlarm)				? 0x0400 : 0x0000;
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bLoadPaperTableBackwardAlarm)			? 0x0800 : 0x0000;
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bDummyR1064_12)							? 0x1000 : 0x0000; 
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bDummyR1064_13)							? 0x2000 : 0x0000;
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bLoadPaperNoUseExistAlarm)				? 0x4000 : 0x0000;
	m_lErrorHandler1064 += (m_NewPLCBitSignalAlarm.bDummyR1064_15)							? 0x8000 : 0x0000;
#endif
	
}
void DeviceMelsecLarge::ReadErrorHandler1065()
{
	m_lErrorHandler1065 = 0;
#ifndef __NANYA__
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bUnloadPaperNoAlarm)						? 0x0001 : 0x0000;
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bUnloadPaperFULLAlarm)					? 0x0002 : 0x0000; 
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bUnloadPaperTableForwardAlarm)			? 0x0004 : 0x0000; 
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bUnloadPaperTableBackwardAlarm)			? 0x0008 : 0x0000; 
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bDummyR1065_4)							? 0x0010 : 0x0000; 
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bDummyR1065_5)							? 0x0020 : 0x0000; 
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bUnloadPaperNoUseExistAlarm)				? 0x0040 : 0x0000; 
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bDummyR1065_7)							? 0x0080 : 0x0000; 
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bLoadBoxNoExistAlarm)					? 0x0100 : 0x0000; 
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bLoadBoxDropAlarm)						? 0x0200 : 0x0000;
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bLoadLiftUpAlarm)						? 0x0400 : 0x0000;
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bLoadLiftDownAlarm)						? 0x0800 : 0x0000;
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bLoadCartLockAlarm)						? 0x1000 : 0x0000; 
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bLoadCartUnlockAlarm)					? 0x2000 : 0x0000;
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bDummyR1065_14)							? 0x4000 : 0x0000;
	m_lErrorHandler1065 += (m_NewPLCBitSignalAlarm.bDummyR1065_15)							? 0x8000 : 0x0000;
#endif
}
void DeviceMelsecLarge::ReadErrorHandler1066()
{
	m_lErrorHandler1066 = 0;
#ifndef __NANYA__
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bUnloadBoxNoExistAlarm)					? 0x0001 : 0x0000;
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bUnloadBoxDropAlarm)						? 0x0002 : 0x0000; 
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bUnloadLiftUpAlarm)						? 0x0004 : 0x0000; 
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bUnloadLiftDownAlarm)					? 0x0008 : 0x0000; 
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bUnloadCartLockAlarm)					? 0x0010 : 0x0000; 
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bUnloadCartUnlockAlarm)					? 0x0020 : 0x0000; 
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bUnloadLiftMiddlePosAlarm)				? 0x0040 : 0x0000; 
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bDummyR1066_7)							? 0x0080 : 0x0000; 
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bDummyR1066_8)							? 0x0100 : 0x0000; 
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bDummyR1066_9)							? 0x0200 : 0x0000;
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bDummyR1066_10)							? 0x0400 : 0x0000;
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bDummyR1066_11)							? 0x0800 : 0x0000;
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bDummyR1066_12)							? 0x1000 : 0x0000; 
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bDummyR1066_13)							? 0x2000 : 0x0000;
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bDummyR1066_14)							? 0x4000 : 0x0000;
	m_lErrorHandler1066 += (m_NewPLCBitSignalAlarm.bDummyR1066_15)							? 0x8000 : 0x0000;
#endif
}
void DeviceMelsecLarge::ReadErrorHandler1067()
{
	m_lErrorHandler1067 = 0;
#ifndef __NANYA__
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bTurnPCBExistAlarm)						? 0x0001 : 0x0000;
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bTurnSuctionAlarm)						? 0x0002 : 0x0000; 
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bTurnPCBSizeAlarm)						? 0x0004 : 0x0000; 
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bTurnPCBDropAlarm)						? 0x0008 : 0x0000; 
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bTurnUnitForwardAlarm)					? 0x0010 : 0x0000; 
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bTurnUnitBackwardAlarm)					? 0x0020 : 0x0000; 
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bTurnUnitTurnAlarm)						? 0x0040 : 0x0000; 
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bTurnUnitReturnAlarm)					? 0x0080 : 0x0000; 
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bTurnUnitUpAlarm)						? 0x0100 : 0x0000; 
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bTurnUnitdownAlarm)						? 0x0200 : 0x0000;
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bDummyR1067_10)							? 0x0400 : 0x0000;
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bDummyR1067_11)							? 0x0800 : 0x0000;
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bDummyR1067_12)							? 0x1000 : 0x0000; 
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bDummyR1067_13)							? 0x2000 : 0x0000;
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bDummyR1067_14)							? 0x4000 : 0x0000;
	m_lErrorHandler1067 += (m_NewPLCBitSignalAlarm.bDummyR1067_15)							? 0x8000 : 0x0000;
#endif
}

BYTE DeviceMelsecLarge::GetLoadPickerDownOK()
{
	return ( m_NewPLCBitSignal.bLoadPicker2Down << 1 & 0x02 ) + (m_NewPLCBitSignal.bLoadPicker1Down & 0x01); 
}

BYTE DeviceMelsecLarge::GetUnloadPickerDownOK()
{
	return ( m_NewPLCBitSignal.bUnloaderPicker2Down << 1 & 0x02 ) + (m_NewPLCBitSignal.bUnloaderPicker1Down & 0x01); 
}

BYTE DeviceMelsecLarge::GetCurrentLoadDetect()
{
	return (BYTE)(m_NewPLCBitSignal.bLP1PCBExist + ((m_NewPLCBitSignal.bLP2PCBExist << 1) & 0x02));//(BYTE)(m_NewStatus.m_bLoaderPick1Detector + ((m_NewStatus.m_bLoaderPick2Detector << 1) & 0x02));
}

BYTE DeviceMelsecLarge::GetCurrentUnloadDetect()
{
	return (BYTE)(m_NewPLCBitSignal.bUP1PCBExist + ((m_NewPLCBitSignal.bUP2PCBExist << 1) & 0x02));
}

BOOL DeviceMelsecLarge::SetLoadPickerDownOK(BOOL b1st, BOOL b2nd)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	short nData2[1];
	nData[0] = b1st; // 
	nData2[0] = b2nd;
	
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_LOADER_PICKER1_DOWN), lSize, nData );
	lRet &= theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_LOADER_PICKER2_DOWN), lSize, nData2 );

	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;
}

BOOL DeviceMelsecLarge::SetUnloadPickerDownOK(BOOL b1st, BOOL b2nd)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	short nData2[1];
	nData[0] = b1st; // 
	nData2[0] = b2nd;

	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_UNLOADER_PICKER1_DOWN), lSize, nData );
	lRet &= theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_UNLOADER_PICKER2_DOWN), lSize, nData2 );

	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;
}

BOOL DeviceMelsecLarge::SetTablePCBExist(BOOL b1st, BOOL b2nd)
{
	if(!m_bConnect)
		return FALSE;

	long lRet = 0;
	long lSize = 1;
	short nData[1];
	short nData2[1];
	nData[0] = b1st; // 
	nData2[0] = b2nd;

	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_TABLE1_PCB_EXIST), lSize, nData );
	lRet &= theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_TABLE2_PCB_EXIST), lSize, nData2 );

	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );

		return FALSE;
	}
	return TRUE;
}

BOOL DeviceMelsecLarge::SetTableVacuumOn(BOOL bOK) //R4005
{


	long lRet = 0;
	long lSize = 1;
	short nData[1];
	nData[0] = bOK;

	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_TABLE1_VACUUM_ON), lSize, nData );
	lRet = theMelsecDlg->m_MelsecQCPU.WriteDeviceBlock2( (LPCTSTR)MakeRCode(WRITE_TABLE2_VACUUM_ON), lSize, nData );

	if( 0 != lRet )
	{
		theMelsecDlg->GetErrorFromMelsecQ( lRet );
		return FALSE;
	}
	return TRUE;
}

void DeviceMelsecLarge::ReadErrorHandlerLoader1()
{
	m_lErrorHandlerLoader1 = 0;
#ifdef __NANYA__
	//R1100
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bLoadEStopAlarm)						? 0x0001 : 0x0000;
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bLoadMainAirAlarm)					? 0x0002 : 0x0000; 
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bAxis1ServoAlarm)						? 0x0004 : 0x0000; 
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bAxis1FlsOnAlarm)						? 0x0008 : 0x0000; 
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bAxis1RlsOnLAlarm)					? 0x0010 : 0x0000; 
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bAxis2ServoRAlarm)					? 0x0020 : 0x0000; 
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bAxis2FlsOnXAlarm)					? 0x0040 : 0x0000; 
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bAxis2RlsOnLAlarm)					? 0x0080 : 0x0000; 
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bAxis3ServoAlarm)						? 0x0100 : 0x0000; 
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bAxis3FlsOnAlarm)						? 0x0200 : 0x0000;
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bAxis3RlsOnAlarm)						? 0x0400 : 0x0000;
	//R1102
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bLoadLeftSuctionAlarm)				? 0x0800 : 0x0000;
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bLoadLeftSensorAlarm)					? 0x1000 : 0x0000;
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bLoadLeftFirstSuctionAlarm)			? 0x2000 : 0x0000;
	//R1103
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bLoadRightSuctionAlarm)				? 0x4000 : 0x0000;
	m_lErrorHandlerLoader1 += (m_NewPLCBitSignalAlarm.bLoadRightSensorAlarm)				? 0x8000 : 0x0000;
#endif
}

void DeviceMelsecLarge::ReadErrorHandlerLoader2()
{
	m_lErrorHandlerLoader2 = 0;
#ifdef __NANYA__
		//R1103
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadRightDownSensorAlarm)			? 0x0001 : 0x0000;
	//R1104
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadRightFirstSuctionAlarm)			? 0x0002 : 0x0000; 
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadLiftNoPCBAlarm)					? 0x0004 : 0x0000; 
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadLiftNoPCBCountAlarm)				? 0x0008 : 0x0000; 
	//R1105
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadAlign1Alarm)						? 0x0010 : 0x0000; 
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadAlign2Alarm)						? 0x0020 : 0x0000; 
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadAlign3Alarm)						? 0x0040 : 0x0000; 

	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadAlignPcbExistAlarm)				? 0x0080 : 0x0000; 

	//R1106
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadCartClampAlarm)					? 0x0100 : 0x0000; 
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadLiftOverloadAlarm)				? 0x0200 : 0x0000;
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadLiftUpperAlarm)					? 0x0400 : 0x0000;
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadLiftLowerAlarm)					? 0x0800 : 0x0000;
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadDoorAlarm)						? 0x1000 : 0x0000; 
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bInLiftNotingProduct)						? 0x2000 : 0x0000; 
    
	
#endif
}

void DeviceMelsecLarge::ReadErrorHandlerLoader3()
{
	m_lErrorHandlerLoader3 = 0;
#ifdef __NANYA__
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadRightDownSensorAlarm)			? 0x0001 : 0x0000;
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadRightFirstSuctionAlarm)		? 0x0002 : 0x0000; 
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadLiftNoPCBAlarm)				? 0x0004 : 0x0000; 
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadLiftNoPCBCountAlarm)			? 0x0008 : 0x0000; 


	//R1105_������
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadAlign4Alarm)			? 0x0001 : 0x0000;
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadAlign5Alarm)				? 0x0002 : 0x0000;
	//R1105_������
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadAlignFirstSuctionAlarm)				? 0x0004 : 0x0000;
	//R1106_������
	m_lErrorHandlerLoader2 += (m_NewPLCBitSignalAlarm.bLoadLiftDownAlarm)				? 0x0008 : 0x0000;


	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadAlign1Alarm)					? 0x0010 : 0x0000; 
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadAlign2Alarm)					? 0x0020 : 0x0000; 
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadAlign3Alarm)					? 0x0040 : 0x0000; 
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadAlignPcbExistAlarm)			? 0x0080 : 0x0000; 
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadCartClampAlarm)				? 0x0100 : 0x0000; 
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadLiftOverloadAlarm)				? 0x0200 : 0x0000;
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadLiftUpperAlarm)				? 0x0400 : 0x0000;
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadLiftLowerAlarm)				? 0x0800 : 0x0000;
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadDoorAlarm)						? 0x1000 : 0x0000; 
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadLeftFirstSuctionAlarm)			? 0x2000 : 0x0000;
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadRightSuctionAlarm)				? 0x4000 : 0x0000;
	//m_lErrorHandlerLoader3 += (m_NewPLCBitSignalAlarm.bLoadRightSensorAlarm)				? 0x8000 : 0x0000;
#endif
}
void DeviceMelsecLarge::ReadErrorHandlerLoader4()
{
	m_lErrorHandlerLoader4 = 0;
#ifdef __NANYA__
	//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadRightDownSensorAlarm)			? 0x0001 : 0x0000;
//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadRightFirstSuctionAlarm)			? 0x0002 : 0x0000; 
//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadLiftNoPCBAlarm)					? 0x0004 : 0x0000; 
//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadLiftNoPCBCountAlarm)				? 0x0008 : 0x0000; 
//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadAlign1Alarm)						? 0x0010 : 0x0000; 
//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadAlign2Alarm)						? 0x0020 : 0x0000; 
//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadAlign3Alarm)						? 0x0040 : 0x0000; 
//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadAlignPcbExistAlarm)				? 0x0080 : 0x0000; 
//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadCartClampAlarm)					? 0x0100 : 0x0000; 
//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadLiftOverloadAlarm)					? 0x0200 : 0x0000;
//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadLiftUpperAlarm)					? 0x0400 : 0x0000;
//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadLiftLowerAlarm)					? 0x0800 : 0x0000;
	//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadDoorAlarm)						? 0x1000 : 0x0000; 
	//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadLeftFirstSuctionAlarm)			? 0x2000 : 0x0000;
	//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadRightSuctionAlarm)				? 0x4000 : 0x0000;
	//m_lErrorHandlerLoader4 += (m_NewPLCBitSignalAlarm.bLoadRightSensorAlarm)				? 0x8000 : 0x0000;
#endif
}

void DeviceMelsecLarge::ReadErrorHandlerUnloader1()
{
	m_lErrorHandlerUnloader1 = 0;
#ifdef __NANYA__
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bUnloadEStopAlarm)				? 0x0001 : 0x0000;
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bUnloadMainAirAlarm)			? 0x0002 : 0x0000; 
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bAxis8ServoAlarm)				? 0x0004 : 0x0000; 
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bAxis8FlsOnlarm)				? 0x0008 : 0x0000; 
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bAxis8RlsOnAlarm)				? 0x0010 : 0x0000; 
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bAxis9ServoAlarm)				? 0x0020 : 0x0000; 
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bAxis9FlsOnAlarm)				? 0x0040 : 0x0000; 
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bAxis9RlsOnAlarm)				? 0x0080 : 0x0000; 
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bAxis10ServoAlarm)				? 0x0100 : 0x0000; 
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bAxis10FlsOnAlarm)				? 0x0200 : 0x0000;
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bAxis10RlsOnAlarm)				? 0x0400 : 0x0000;
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bUnloadLeftSuctionAlarm)		? 0x0800 : 0x0000;
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bUnloadLeftSensorAlarm)			? 0x1000 : 0x0000; 
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bUnloadLeftDownSensorAlarm)		? 0x2000 : 0x0000;
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bUnloadLeftFirstSuctionAlarm)	? 0x4000 : 0x0000;
	m_lErrorHandlerUnloader1 += (m_NewPLCBitSignalAlarm.bUnloadLiftNoPcbAlarm)			? 0x8000 : 0x0000;
#endif
}

void DeviceMelsecLarge::ReadErrorHandlerUnloader2()
{
	m_lErrorHandlerUnloader2 = 0;
#ifdef __NANYA__
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadLiftNoPcbCountAlarm)			? 0x0001 : 0x0000;
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadRightSuctionAlarm)			? 0x0002 : 0x0000; 
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadRightSensorAlarm)			? 0x0004 : 0x0000; 
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadRightFirSuctionAlarm)		? 0x0008 : 0x0000; 
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadAlign1Alarm)					? 0x0010 : 0x0000; 
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadAlign2Alarm)					? 0x0020 : 0x0000; 
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadAlign3Alarm)					? 0x0040 : 0x0000; 
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadAlignPcbExistAlarm)			? 0x0080 : 0x0000; 
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadCartClampAlarm)				? 0x0100 : 0x0000; 
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadLiftOverloadAlarm)			? 0x0200 : 0x0000;
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadLiftUpperAlarm)				? 0x0400 : 0x0000;
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadLiftLowerALarm)				? 0x0800 : 0x0000;
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadDoorOpenAlarm)				? 0x1000 : 0x0000; 
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadIonizerAlarm)				? 0x2000 : 0x0000;
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableFWBWAlarm)			? 0x4000 : 0x0000;
	m_lErrorHandlerUnloader2 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableRotateAlarm)		? 0x8000 : 0x0000;
#endif
}

void DeviceMelsecLarge::ReadErrorHandlerUnloader3()
{
	m_lErrorHandlerUnloader3 = 0;
#ifdef __NANYA__
	m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableUpDownAlarm)			? 0x0001 : 0x0000;
	m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableSuctionAlarm)			? 0x0002 : 0x0000; 
	m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadTurnTablePCBDropAlarm)			? 0x0004 : 0x0000; 
	m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableOriginSuctionAlarm)		? 0x0008 : 0x0000; 
	m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableOriginPcbExistAlarm)	? 0x0010 : 0x0000; 
	m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableAlarm)					? 0x0020 : 0x0000; 
	
	m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadAlign4Alarm)					? 0x0040 : 0x0000; //20180212 �߰�
	m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadAlign5Alarm)			? 0x0080 : 0x0000; 
	m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadAlignFirstSuctionAlarm)				? 0x0100 : 0x0000;

	m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadLiftDownAlarm)				? 0x0200 : 0x0000;

	//m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadLiftUpperAlarm)				? 0x0400 : 0x0000;
	//m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadLiftLowerALarm)				? 0x0800 : 0x0000;
	//m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadDoorOpenAlarm)					? 0x1000 : 0x0000; 
	//m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadIonizerAlarm)					? 0x2000 : 0x0000;
	//m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableFWBWAlarm)			? 0x4000 : 0x0000;
	//m_lErrorHandlerUnloader3 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableRotateAlarm)			? 0x8000 : 0x0000;
#endif
}

void DeviceMelsecLarge::ReadErrorHandlerUnloader4()
{
	m_lErrorHandlerUnloader4 = 0;
#ifdef __NANYA__
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableUpDownAlarm)			? 0x0001 : 0x0000;
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableSuctionAlarm)			? 0x0002 : 0x0000; 
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadTurnTablePCBDropAlarm)			? 0x0004 : 0x0000; 
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableOriginSuctionAlarm)		? 0x0008 : 0x0000; 
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableOriginPcbExistAlarm)	? 0x0010 : 0x0000; 
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableAlarm)					? 0x0020 : 0x0000; 
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadAlign3Alarm)					? 0x0040 : 0x0000; 
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadAlignPcbExistAlarm)			? 0x0080 : 0x0000; 
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadCartClampAlarm)				? 0x0100 : 0x0000; 
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadLiftOverloadAlarm)				? 0x0200 : 0x0000;
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadLiftUpperAlarm)				? 0x0400 : 0x0000;
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadLiftLowerALarm)				? 0x0800 : 0x0000;
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadDoorOpenAlarm)					? 0x1000 : 0x0000; 
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadIonizerAlarm)					? 0x2000 : 0x0000;
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableFWBWAlarm)			? 0x4000 : 0x0000;
	//m_lErrorHandlerUnloader4 += (m_NewPLCBitSignalAlarm.bUnloadTurnTableRotateAlarm)			? 0x8000 : 0x0000;
#endif
}
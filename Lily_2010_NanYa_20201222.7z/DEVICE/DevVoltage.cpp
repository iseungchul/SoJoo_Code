#include "stdafx.h"
#include "DevVoltage.h"
#include "sysdef.h"

//#define __USE_MEASURE_VOLTAGE__
CDevVoltage::CDevVoltage(void)
{
	m_bConnect = FALSE;
	m_pAccuraClient = NULL;
	m_pAccuraModBus = NULL;
	m_pModBus = NULL;
	m_nType = TYPE_A;
	m_nSubDataCount = 0;

	for(int i =0; i< 3; i++)
	{
		m_dV[i] = -1;
		m_dA[i] = -1;
		m_dkW[i] = -1;
	}
	
	memset(m_dSubData, -1, sizeof(m_dSubData));
}


CDevVoltage::~CDevVoltage(void)
{
	if(m_pAccuraModBus != NULL)
	{
		delete m_pAccuraModBus;
		m_pAccuraModBus = NULL;
	}

	if(m_pAccuraClient != NULL)
	{
		delete m_pAccuraClient;
		m_pAccuraClient = NULL;
	}

	if(m_pModBus != NULL)
	{
		delete m_pModBus;
		m_pModBus = NULL;
	}
}

BOOL CDevVoltage::Connect()
{
#ifdef __USE_MEASURE_VOLTAGE__
	if(m_pAccuraModBus == NULL)
		m_pAccuraModBus = AccuraModbusTcpClient::Create("10.10.10.100");
	 

	if(!IsConnected())
	{
		m_bConnect = FALSE;
		return FALSE;
	}
	m_pAccuraModBus->SetTimeout(2);//Data ���� �� Timeout sec
	m_pAccuraModBus->EnableException(); //���� �߻��� �����ڵ� ��� 

	m_bConnect = TRUE;
#endif
	return TRUE;
}

void CDevVoltage::ReadVoltage()
{

	try {
		unsigned short productId = m_pAccuraModBus->GetProductId();
		CString str;
		if (productId == 2300) 
		{
			unsigned short fetchAndValidity[42];
			unsigned short* selectedIndex = &fetchAndValidity[0];
			unsigned short* ptValidity = &fetchAndValidity[1];
			unsigned short* subunitValidity = &fetchAndValidity[2];
			
			m_pAccuraModBus->ReadHoldingRegisters(11044, 42, fetchAndValidity);

			if (*ptValidity == 1)
			{
				unsigned short ptData[56];

				m_pAccuraModBus->ReadHoldingRegisters(11101, 56, ptData);

				m_dV[0] = ToFloat(ptData, 8);
				m_dV[1] = ToFloat(ptData, 10);
				m_dV[2] = ToFloat(ptData, 12);

			} 
			else
			{
				str = _T("pt data invalid.");
			}

			unsigned short subunitData[150];

			if (subunitValidity[0] == 0)
			{
				m_pAccuraModBus->ReadHoldingRegisters(11201, 141, subunitData);

				m_dA[0] = ToFloat(subunitData, 0);
				m_dA[1] = ToFloat(subunitData, 2);
				m_dA[2] = ToFloat(subunitData, 4);

				m_dkW[0] = ToFloat(subunitData, 60);
				m_dkW[1] = ToFloat(subunitData, 62);
				m_dkW[2] = ToFloat(subunitData, 64);
			}

			if(subunitValidity[1] == 3)// moduleID 1 = 3(GW module) �½��� ���
			{
				m_pAccuraModBus->ReadHoldingRegisters(11351, 150, subunitData); // �� 150�������� ���� �ִ� ��ġ ������ 60��
				int nDeviceCount = 0;
				for(int i = 0; i < 20; i++)
				{
					if(subunitData[i] >> 3 & 0x1)		// [3-0]bit �� 0001 �϶� 1�� ��ġ �� ����
						nDeviceCount++;
					if(subunitData[i] >> 7 & 0x1)		// [7-4]bit �� 0001 �϶� 2�� ��ġ �� ����
						nDeviceCount++;
					if(subunitData[i] >> 11 & 0x1)		// [11-8]bit �� 0001 �϶� 3�� ��ġ �� ����  ==> �̷��� �� 20�������� 60���� ��ġ�� ����� ����
						nDeviceCount++;
				}
				for(int i = 0; i <nDeviceCount; i++)
					m_dDeviceValue[i] = ToDouble(subunitData, 20 + (i*2));  //20���� ���� ���� 2byte �� ��ġ �� ������
			}

		} 
		else
		{
			str.Format(_T("unsupported device. productId = %d"), productId);
		}
	}
	catch (enum ModbusTcpError)
	{
		for(int i =0; i< 3; i++)
		{
			m_dV[i] = -1;
			m_dA[i] = -1;
			m_dkW[i] = -1;
		}
	}
}
double CDevVoltage::ToDouble(unsigned short* buffer, int index)
{
	unsigned short reversed[2];

	reversed[0] = buffer[index + 1];
	reversed[1] = buffer[index + 0];

	return (double)reversed[1];
}
float CDevVoltage::ToFloat(unsigned short* buffer, int index)
{
	unsigned short reversed[2];

	reversed[0] = buffer[index + 1];
	reversed[1] = buffer[index + 0];

	return *(float*)reversed;
}
int CDevVoltage::ToInt32(unsigned short* buffer, int index)
{
	unsigned short reversed[2];

	reversed[0] = buffer[index + 1];
	reversed[1] = buffer[index + 0];

	return *(int*)reversed;
}

BOOL CDevVoltage::IsConnected()
{
	//������ return ProductID�� üũ
	unsigned short productId = m_pAccuraModBus->GetProductId();

	if (productId == 2300)
		return TRUE;
	else
		return FALSE;

}
void CDevVoltage::SetSubCount(int nCount)
{
	m_nSubDataCount = nCount;
}
void CDevVoltage::ReadSubData(int nIndex)
{
	try {
		unsigned short productId = m_pAccuraModBus->GetProductId();
		CString str;

		if (productId == 2300) 
		{
			unsigned short subunitData[10];
			m_pAccuraModBus->ReadHoldingRegisters(32006 + (nIndex *5), 5, subunitData);

			if(ValidSubData(subunitData[0]))
			{
				m_dSubData[nIndex] = ToDouble(subunitData,2);
			}
		} 
		else
		{
			str.Format(_T("unsupported device. productId = %d"), productId);
		}
	}
	catch (enum ModbusTcpError)
	{
	}
}

BOOL CDevVoltage::ValidSubData(short cCheck)
{
	short cTemp;
	cTemp = cCheck >> 8;

	if(cTemp == 0x03)
		return TRUE;
	else 
		return FALSE;
}
void CDevVoltage::GetVoltage(double& dV, double& dA, double& dWh)
{
	if(!m_bConnect)
	{
		dV = -1;
		dA = -1;
		dWh = -1;
		return;
	}
	ReadVoltage();

	if(m_nType == TYPE_A)
	{
		dV = (m_dV[0] + m_dV[1] + m_dV[2])/3;
		dA = (m_dA[0] + m_dA[1] + m_dA[2])/3;
		dWh = m_dkW[0] + m_dkW[1] + m_dkW[2];
	}
	else if(m_nType == TYPE_B)
	{
		dV = m_dV[1];
		dA = m_dA[1];
		dWh = m_dkW[1];

	}
	else
	{
		dV = m_dV[1];
		dA = m_dA[1];
		dWh = m_dkW[1];
	}
}

double CDevVoltage::GetSubData(int nIndex)
{
	if(!m_bConnect)
		return -1;
	ReadSubData(nIndex);
#ifndef __2016_KUNSAN__
	return m_dSubData[nIndex]; 
#else
	return m_dDeviceValue[nIndex];
#endif
}
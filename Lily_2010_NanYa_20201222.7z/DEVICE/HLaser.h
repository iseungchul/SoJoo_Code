// HLaser.h: interface for the HLaser class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HLASER_H__AB545DDF_6E75_4AE4_9603_CCDD72EFA95E__INCLUDED_)
#define AFX_HLASER_H__AB545DDF_6E75_4AE4_9603_CCDD72EFA95E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "HLaserIPGPulse.h"
#include "HLaserCO2.h"
#include "HLaserUV.h"
#include "HLaserQuanta.h"


class HLaser  
{
public:
	void EnableOn();
	BOOL IsFireOK();
	BOOL setQuataParam(int nFPK, int nCurrent);
	void LaserDoModal();
	int GetAviaTriggerMode(); // 20090629 Front Mode error
	HLaser();
	virtual ~HLaser();
	
	void Create();

	BOOL IsTempReady();
	void OpenPowerDlg();
	int IsPowerOn();
	int IsShutterOpen();
	BOOL IsPulseOpen();
	BOOL ChangeAviaDiodeCurrent(double dDiodeCurrent, long lFreq, int nThermalTrack = -1);
	void PowerOn(BOOL bFlag);
	void ShutterOpen(BOOL bFlag);
	void PulseOpen(BOOL bFlag);
	BOOL IsDutyError();
	BOOL IsDigitalReflectError();
	BOOL IsVSWRError();

	POWER_STATUS GetStatus();

	HLaserIPGPulse* m_pLaserIPGPulse;
	HLaserCO2* m_pLaserCO2;
	HLaserUV*  m_pLaserUV;
	HLaserQuanta* m_pLaserQuanta;
	
	int	m_nLaserType;

	BOOL SetCurrent(double dCurrent);

	BOOL GuideBeamOnOff(BOOL bOn);
};

#endif // !defined(AFX_HLASER_H__AB545DDF_6E75_4AE4_9603_CCDD72EFA95E__INCLUDED_)

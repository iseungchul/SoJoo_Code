// DeviceMelsecLarge.h: interface for the DeviceMelsec class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVICEMELSECLARGE_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_)
#define AFX_DEVICEMELSECLARGE_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CorrectTime.h"
#include "MMelsecFx.h"
#include "..\actqj71e71tcp3.h"
#include "..\ui\DlgMelsecOCX.h"

const int HANDLER_AXIS_MAX = 0x02;	

#define OCX_READ_MELSEC_SIZE 50

struct PLC_BIT_SIGNAL_FX
{
	//R1050
	WORD	bInputLoadBasket;				// 0 : R1050
	WORD	bOutputLoadBasket;				// 1 : R1051
	WORD	bInputUnlodBasket;				// 2 : R1052
	WORD	bOutputUnloadBasket;			// 3 : R1053
	WORD	bChangeDirection;				// 4 : R1054
	WORD	bDummyR1054;					// 
	WORD	wLoaderPos[2];					// 6 ~ 7 : R1056  
	WORD	wUnloaderPos[2];				// 8 ~ 9 : R1058 

	//R1060
	BYTE	bEStopAlarm:1;						// 0 : R1060.0
	BYTE	bPLCBATAlarm:1;						// 1 : R1060.1
	BYTE	bAirDownAlarm:1;					// 2 : R1060.2
	BYTE	bDoorOpenAlarm:1;					// 3 : R1060.3
	BYTE	bAxis1DriveAlarm:1;					// 4 : R1060.4
	BYTE	bAxis2DriveAlarm:1;					// 5 : R1060.5
	BYTE	bAxis3DriveAlarm:1;					// 6 : R1060.6
	BYTE	bAxis1ControlAlarm:1;				// 7 : R1060.7
	BYTE	bAxis2ControlAlarm:1;				// 8 : R1060.8
	BYTE	bAxis3ControlAlarm:1;				// 9 : R1060.9 
	BYTE	bLoadLeftPicker1UpDownCYLAlarm:1;	// 10 : R1060.A
	BYTE	bLoadLeftPicker2UpDownCYLAlarm:1;	// 11 : R1060.B
	BYTE	bLoadLeftPickerVacuumAlarm:1;		// 12 : R1060.C
	BYTE	bLoadRightPicker1UpDownCYLAlarm:1;	// 13 : R1060.D
	BYTE	bLoadRightPicker2UpDownCYLAlarm:1;	// 14 : R1060.E
	BYTE	bLoadRightPickerVacuumAlam:1;		// 15 : R1060.F

	//R1061
	BYTE	bLoadUnloadCollisionAlarm:1;		// 0 : R1061.0 
	BYTE	bTwoDetectionAlarm:1;				// 1 : R1061.1
	BYTE	bLAlignTableForBackAlarm:1;			// 2 : R1061.2
	BYTE	bLAlign1LeftAlarm:1;				// 3 : R1061.3
	BYTE	bLAlign1FrontAlarm:1;				// 4 : R1061.4
	BYTE	bLAlignPalteAlarm:1;				// 5 : R1061.5
	BYTE	bLAlignROnOffAlarm:1;				// 6 : R1061.6
	BYTE	bLCardLockAlarm:1;					// 7 : R1061.7
	BYTE	bLLifterAlarm:1;					// 8 : R1061.8
	BYTE	bDummyR1061_9:1;					// 9
	BYTE	bLNGTableForBackAlarm:1;			// 10 : R1061.A
	BYTE	bLPaperTableForBackAlarm:1;			// 11 : R1061.B
	BYTE	bTwoDetectionCylinderAlarm:1;		// 12 : R1061.C
	BYTE	bDummyR1061_13:1;					// 13
	BYTE	bUnloadLeftPicker1UpDownCYLAlarm:1;	// 14 : R1061.E
	BYTE	bUnloadLeftPicker2UpDownCYLAlarm:1;	// 15 : R1061.F

	// R1062
	BYTE	bUnloadLeftPickerVacuumAlarm:1;		// 0 : R1062.0
	BYTE	bUnloadRightPicker1UpDownCYLAlarm:1;// 1 : R1062.1
	BYTE	bUnloadRightPicker2UpDownCYLAlarm:1;// 2 : R1062.2
	BYTE	bUnloadRightPickerVacuumAlam:1;		// 3 : R1062.3
	BYTE	bDummyR1062_4:1;					// 4 
	BYTE	bDummyR1062_5:1;					// 5
	BYTE	bUAlignTableForBackAlarm:1;			// 6 : R1062.6
	BYTE	bUAlign1LeftAlarm:1;				// 7 : R1062.7
	BYTE	bUAlign1FrontAlarm:1;				// 8 : R1062.8
	BYTE	bUAlignPalteAlarm:1;				// 9 : R1062.9
	BYTE	bUAlignROnOffAlarm:1;				// 10 : R1062.A
	BYTE	bUCardLockAlarm:1;					// 11 : R1062.B
	BYTE	bULifterAlarm:1;					// 12 : R1062.C
	BYTE	bDummyR1062_13:1;					// 13
	BYTE	bUNGTableForBackAlarm:1;			// 14 : R1061.E
	BYTE	bUPaperTableForBackAlarm:1;			// 15 : R1061.F

	// R1063
	BYTE	bTurnTableForBackAlarm:1;			// 0 : R1063.0
	BYTE	bTurnTableUpDownAlarm:1;			// 1 : R1063.1
	BYTE	bTurnTableVacuumAlarm:1;			// 2 : R1063.2
	BYTE	bLoadLeftPickerPCBAlarm:1;			// 3 : R1063.3
	BYTE	bLoadRightPickerPCBAlarm:1;			// 4 : R1063.4 
	BYTE	bUnloadLeftPickerPCBAlarm:1;		// 5 : R1063.5
	BYTE	bUnloadRightPickerPCBAlarm:1;		// 6 : R1063.6
	BYTE	bLoadPosAlarm:1;					// 7 : R1063.7 
	BYTE	bUnloadPosAlarm:1;					// 8 : R1063.8
	BYTE	bLoadBoxNoExist:1;					// 9 
	BYTE	bUnloadBoxNoExist:1;				// 10
	BYTE	bNoUsePaperLoadPaper:1;				// 11
	BYTE	bNoUsePaperUnloadPaper:1;			// 12
	BYTE	bPaperNoExist:1;					// 13
	BYTE	bPaperBoxFull:1;					// 14
	BYTE	NGBoxFull:1;						// 15

///////////////////////////////////////////////////////////////////////////////////	
	// R1064
	BYTE	bLP1PCBExist:1;					// 0 : R1063.0
	BYTE	bLP2PCBExist:1;					// 1 : R1063.1
	BYTE	bUP1PCBExist:1;					// 2 : R1063.2
	BYTE	bUP2PCBExist:1;					// 3 : R1063.3
	BYTE	bAlignEnd:1;					// 4 : R1063.4 
	BYTE	bAlignRun:1;					// 5 : R1063.5
	BYTE	bLoadEnd:1;						// 6 : R1063.6
	BYTE	bLoadRun:1;						// 7 : R1063.7 
	BYTE	bUnloadEnd:1;					// 8 : R1063.8
	BYTE	bUnloadRun:1;					// 9 : R1063.9
	BYTE	bLoadRequestReady:1;			// 10 : R1063.10
	BYTE	bLoadPicker1Down:1;				// 11 : R1063.11
	BYTE	bLoadPicker2Down:1;				// 12 : R1063.12
	BYTE	bUnloaderPicker1Down:1;			// 13 : R1063.13
	BYTE	bUnloaderPicker2Down:1;			// 14 : R1063.14
	BYTE	bUnloadReady:1;					// 15 : R1063.15

	WORD    wDummyR1064_1069[5];

	WORD	bLoadSafePos;						// R1070
	WORD	bUnloadSafePos;						// R1071
	WORD	bLdElvPCBExist;						// R1072
	WORD	bStartMode;							// R1073
	WORD	bPCBDownDanger;						// R1074
	WORD	bAlignTablePCBExist;				// R1075
};
#ifdef __NANYA__
struct PLC_BIT_SIGNAL_ALARM
{
	//R1100
	BYTE	bDummyR1100_0:1;					// 0 : R1100.0
	BYTE	bLoadEStopAlarm:1;						// 1 : R1100.1
	BYTE	bLoadMainAirAlarm:1;					// 2 : R1100.2
	BYTE	bAxis1ServoAlarm:1;					// 3 : R1100.3
	BYTE	bAxis1FlsOnAlarm:1;					// 4 : R1100.4
	BYTE	bAxis1RlsOnLAlarm:1;				// 5 : R1100.5
	BYTE	bAxis2ServoRAlarm:1;				// 6 : R1100.6
	BYTE	bAxis2FlsOnXAlarm:1;				// 7 : R1100.7
	BYTE	bAxis2RlsOnLAlarm:1;				// 8 : R1100.8
	BYTE	bAxis3ServoAlarm:1;					// 9 : R1100.9 
	BYTE	bAxis3FlsOnAlarm:1;					// 10 : R1100.A
	BYTE	bAxis3RlsOnAlarm:1;					// 11 : R1100.B
	BYTE	bDummyR1100_12:1;					// 12 : R1100.C
	BYTE	bDummyR1100_13:1;					// 13 : R1100.D
	BYTE	bDummyR1100_14:1;					// 14 : R1100.E
	BYTE	bDummyR1100_15:1;					// 15 : R1100.F

	//R1101
	WORD bDummyR1101; //R1101
	//BYTE	bAxis13UnloadAlign3Alarm:1;			// 0 : R1061.0 
	//BYTE	bAxis14UnloadAlign4Alarm:1;			// 1 : R1061.1
	//BYTE	bLoadHomeAlarm:1;					// 2 : R1061.2
	//BYTE	bLoadLeftExistAlarm:1;				// 3 : R1061.3
	//BYTE	bLoadRightExistAlarm:1;				// 4 : R1061.4
	//BYTE	bLoadAlignExistAlarm:1;				// 5 : R1061.5
	//BYTE	bUnloadHomeAlarm:1;					// 6 : R1061.6
	//BYTE	bUnloadLeftExistAlarm:1;			// 7 : R1061.7
	//BYTE	bUnloadRightExistAlarm:1;			// 8 : R1061.8
	//BYTE	bUnloadAlignExistAlarm:1;			// 9 : R1061.9
	//BYTE	bDummyR1061_10:1;					// 10 : 
	//BYTE	bDummyR1061_11:1;					// 11 : 
	//BYTE	bLoadIonizer1Alarm:1;				// 12 : R1061.C
	//BYTE	bLoadIonizer2Alarm:1;				// 13 : R1061.D
	//BYTE	bUnloadIonizer1Alarm:1;				// 14 : R1061.E
	//BYTE	bUnloadIonizer21Alarm:1;				// 15 : R1061.F

	// R1102
	BYTE	bDummyR1102_0:1;					// 0 : R1102.0
	BYTE	bDummyR1102_1:1;					// 1 : R1102.1
	BYTE	bDummyR1102_2:1;					// 2 : R1102.2
	BYTE	bDummyR1102_3:1;					// 3 : R1102.3
	BYTE	bDummyR1102_4:1;					// 4 : R1102
	BYTE	bDummyR1102_5:1;					// 5 : R1102
	BYTE	bDummyR1102_6:1;					// 6 : R1102
	BYTE	bDummyR1102_7:1;					// 7 : R1102
	BYTE	bLoadLeftSuctionAlarm:1;			// 8 : R1102.8
	BYTE	bLoadLeftSensorAlarm:1;				// 9 : R1102.9
	BYTE	bDummyR1102_10:1;					// 10 : R1102.A
	BYTE	bDummyR1102_11:1;					// 11 : R1102.B
	BYTE	bDummyR1102_12:1;					// 12 : R1102.C
	BYTE	bLoadLeftFirstSuctionAlarm:1;		// 13 : R1102.D
	BYTE	bDummyR1102_14:1;					// 14 : R1102.E
	BYTE	bDummyR1102_15:1;					// 15 : R1102.F

	// R1103
	BYTE	bDummyR1103_0:1;			// 0 : RR1103.0
	BYTE	bDummyR1103_1:1;			// 1 : RR1103.1
	BYTE	bDummyR1103_2:1;			// 2 : RR1103.2
	BYTE	bDummyR1103_3:1;			// 3 : RR1103.3
	BYTE	bDummyR1103_4:1;			// 4 : RR1103.4 
	BYTE	bDummyR1103_5:1;			// 5 : RR1103.5
	BYTE	bDummyR1103_6:1;			// 6 : RR1103.6
	BYTE	bDummyR1103_7:1;			// 7 : RR1103.7
	BYTE	bDummyR1103_8:1;			// 8 : RR1103.8
	BYTE	bDummyR1103_9:1;			// 9 : RR1103.9
	BYTE	bDummyR1103_10:1;			// 10 : R1063.A
	BYTE	bDummyR1103_11:1;			// 11 : R1063.B
	BYTE	bLoadRightSuctionAlarm:1;	// 12 : R1063.C
	BYTE	bLoadRightSensorAlarm:1;	// 13 : R1063.D
	BYTE	bLoadRightDownSensorAlarm:1;// 14 : R1063.E
	BYTE	bDummyR1103_15:1;			// 15 : R1063.F

	// R1104
	BYTE	bDummyR1104_0:1;					// 0 : RR1104.0
	BYTE	bLoadRightFirstSuctionAlarm:1;		// 1 : RR1104.1
	BYTE	bLoadLiftNoPCBAlarm:1;				// 2 : RR1104.2
	BYTE	bLoadLiftNoPCBCountAlarm:1;			// 3 : RR1104.3
	BYTE	bDummyR1104_4:1;					// 4 : RR1104.4 
	BYTE	bDummyR1104_5:1;					// 5 : RR1104.5
	BYTE	bDummyR1104_6:1;					// 6 : RR1104.6
	BYTE	bDummyR1104_7:1;					// 7 : RR1104.7
	BYTE	bDummyR1104_8:1;					// 8 : RR1104.8
	BYTE	bDummyR1104_9:1;					// 9 : RR1104.9
	BYTE	bDummyR1104_10:1;					// 10 : R1104.A
	BYTE	bDummyR1104_11:1;					// 11 : R1104.B
	BYTE	bDummyR1104_12:1;					// 12 : R1104.C
	BYTE	bDummyR1104_13:1;					// 13 : R1104.D
	BYTE	bDummyR1104_14:1;					// 14 : R1104.E
	BYTE	bDummyR1104_15:1;					// 15 : R1104.F

	// R1105
	BYTE	bLoadAlign1Alarm:1;					// 0 : RR1105.0
	BYTE	bLoadAlign2Alarm:1;					// 1 : RR1105.1
	BYTE	bLoadAlign3Alarm:1;					// 2 : RR1105.2
	
	BYTE	bLoadAlign4Alarm:1;					// 3 : RR1105.3 //20180212 �߰�
	BYTE	bLoadAlign5Alarm:1;					// 4 : RR1105.4 
	
	BYTE	bDummyR1105_5:1;					// 5 : RR1105.5
	BYTE	bLoadAlignPcbExistAlarm:1;			// 6 : RR1105.6
	BYTE	bLoadAlignFirstSuctionAlarm:1;		// 7 : RR1105.7 //20180212 �߰�
	BYTE	bDummyR1105_8:1;					// 8 : RR1105.8
	BYTE	bDummyR1105_9:1;					// 9 : RR1105.9
	BYTE	bDummyR1105_10:1;					// 10 : R1105.A
	BYTE	bDummyR1105_11:1;					// 11 : R1105.B
	BYTE	bDummyR1105_12:1;					// 12 : R1105.C
	BYTE	bDummyR1105_13:1;					// 13 : R1105.D
	BYTE	bDummyR1105_14:1;					// 14 : R1105.E
	BYTE	bDummyR1105_15:1;					// 15 : R1105.F

	// R1106
	BYTE	bDummyR1106_0:1;					// 0 : RR1106.0
	BYTE	bDummyR1106_1:1;					// 1 : RR1106.1
	BYTE	bDummyR1106_2:1;					// 2 : RR1106.2
	BYTE	bDummyR1106_3:1;					// 3 : RR1106.3
	BYTE	bLoadCartClampAlarm:1;					// 4 : RR1106.4 
	BYTE	bLoadLiftOverloadAlarm:1;					// 5 : RR1106.5
	BYTE	bLoadLiftUpperAlarm:1;					// 6 : RR1106.6
	BYTE	bLoadLiftLowerAlarm:1;					// 7 : RR1106.7
	BYTE	bLoadLiftDownAlarm:1;					// 8 : RR1106.8 //20180212 �߰�
	BYTE	bDummyR1106_9:1;					// 9 : RR1106.9
	BYTE	bDummyR1106_10:1;					// 10 : R1106.A
	BYTE	bDummyR1106_11:1;					// 11 : R1106.B
	BYTE	bLoadDoorAlarm:1;					// 12 : R1106.C
	BYTE	bDummyR1106_13:1;					// 13 : R1106.D
	BYTE	bInLiftNotingProduct:1;					// 14 : R1106.E
	BYTE	bDummyR1106_15:1;					// 15 : R1106.F

	// R1107
	BYTE	bDummyR1107_0:1;					// 0 : RR1107.0
	BYTE	bDummyR1107_1:1;					// 1 : RR1107.1
	BYTE	bDummyR1107_2:1;					// 2 : RR1107.2
	BYTE	bDummyR1107_3:1;					// 3 : RR1107.3
	BYTE	bDummyR1107_4:1;					// 4 : RR1107.4 
	BYTE	bDummyR1107_5:1;					// 5 : RR1107.5
	BYTE	bDummyR1107_6:1;					// 6 : RR1107.6
	BYTE	bDummyR1107_7:1;					// 7 : RR1107.7
	BYTE	bDummyR1107_8:1;					// 8 : RR1107.8
	BYTE	bDummyR1107_9:1;					// 9 : RR1107.9
	BYTE	bDummyR1107_10:1;					// 10 : R1107.A
	BYTE	bDummyR1107_11:1;					// 11 : R1107.B
	BYTE	bDummyR1107_12:1;					// 12 : R1107.C
	BYTE	bDummyR1107_13:1;					// 13 : R1107.D
	BYTE	bDummyR1107_14:1;					// 14 : R1107.E
	BYTE	bDummyR1107_15:1;					// 15 : R1107.F

	// R1108
	BYTE	bDummyR1108_0:1;					// 0 : RR1108.0
	BYTE	bDummyR1108_1:1;					// 1 : RR1108.1
	BYTE	bDummyR1108_2:1;					// 2 : RR1108.2
	BYTE	bDummyR1108_3:1;					// 3 : RR1108.3
	BYTE	bDummyR1108_4:1;					// 4 : RR1108.4 
	BYTE	bDummyR1108_5:1;					// 5 : RR1108.5
	BYTE	bDummyR1108_6:1;					// 6 : RR1108.6
	BYTE	bDummyR1108_7:1;					// 7 : RR1108.7
	BYTE	bDummyR1108_8:1;					// 8 : RR1108.8
	BYTE	bDummyR1108_9:1;					// 9 : RR1108.9
	BYTE	bDummyR1108_10:1;					// 10 : R1108.A
	BYTE	bDummyR1108_11:1;					// 11 : R1108.B
	BYTE	bDummyR1108_12:1;					// 12 : R1108.C
	BYTE	bDummyR1108_13:1;					// 13 : R1108.D
	BYTE	bDummyR1108_14:1;					// 14 : R1108.E
	BYTE	bDummyR1108_15:1;					// 15 : R1108.F

	// R1109
	BYTE	bDummyR1109_0:1;					// 0 : RR1109.0
	BYTE	bDummyR1109_1:1;					// 1 : RR1109.1
	BYTE	bDummyR1109_2:1;					// 2 : RR1109.2
	BYTE	bDummyR1109_3:1;					// 3 : RR1109.3
	BYTE	bDummyR1109_4:1;					// 4 : RR1109.4 
	BYTE	bDummyR1109_5:1;					// 5 : RR1109.5
	BYTE	bDummyR1109_6:1;					// 6 : RR1109.6
	BYTE	bDummyR1109_7:1;					// 7 : RR1109.7
	BYTE	bDummyR1109_8:1;					// 8 : RR1109.8
	BYTE	bDummyR1109_9:1;					// 9 : RR1109.9
	BYTE	bDummyR1109_10:1;					// 10 : R1109.A
	BYTE	bDummyR1109_11:1;					// 11 : R1109.B
	BYTE	bDummyR1109_12:1;					// 12 : R1109.C
	BYTE	bDummyR1109_13:1;					// 13 : R1109.D
	BYTE	bDummyR1109_14:1;					// 14 : R1109.E
	BYTE	bDummyR1109_15:1;					// 15 : R1109.F

	///////////��δ�

	// R1110
	BYTE	bDummyR1110_0:1;					// 0 : RR1110.0
	BYTE	bUnloadEStopAlarm:1;					// 1 : RR1110.1
	BYTE	bUnloadMainAirAlarm:1;					// 2 : RR1110.2
	BYTE	bAxis8ServoAlarm:1;					// 3 : RR1110.3
	BYTE	bAxis8FlsOnlarm:1;					// 4 : RR1110.4 
	BYTE	bAxis8RlsOnAlarm:1;					// 5 : RR1110.5
	BYTE	bAxis9ServoAlarm:1;					// 6 : RR1110.6
	BYTE	bAxis9FlsOnAlarm:1;					// 7 : RR1110.7
	BYTE	bAxis9RlsOnAlarm:1;					// 8 : RR1110.8
	BYTE	bAxis10ServoAlarm:1;					// 9 : RR1110.9
	BYTE	bAxis10FlsOnAlarm:1;					// 10 : R1110.A
	BYTE	bAxis10RlsOnAlarm:1;					// 11 : R1110.B
	BYTE	bDummyR1110_12:1;					// 12 : R1110.C
	BYTE	bDummyR1110_13:1;					// 13 : R1110.D
	BYTE	bDummyR1110_14:1;					// 14 : R1110.E
	BYTE	bDummyR1110_15:1;					// 15 : R1110.F

	// R1109
	BYTE	bDummyR1111_0:1;					// 0 : RR1111.0
	BYTE	bDummyR1111_1:1;					// 1 : RR1111.1
	BYTE	bDummyR1111_2:1;					// 2 : RR1111.2
	BYTE	bDummyR1111_3:1;					// 3 : RR1111.3
	BYTE	bDummyR1111_4:1;					// 4 : RR1111.4 
	BYTE	bDummyR1111_5:1;					// 5 : RR1111.5
	BYTE	bDummyR1111_6:1;					// 6 : RR1111.6
	BYTE	bDummyR1111_7:1;					// 7 : RR1111.7
	BYTE	bDummyR1111_8:1;					// 8 : RR1111.8
	BYTE	bDummyR1111_9:1;					// 9 : RR1111.9
	BYTE	bDummyR1111_10:1;					// 10 : R1111.A
	BYTE	bDummyR1111_11:1;					// 11 : R1111.B
	BYTE	bDummyR1111_12:1;					// 12 : R1111.C
	BYTE	bDummyR1111_13:1;					// 13 : R1111.D
	BYTE	bDummyR1111_14:1;					// 14 : R1111.E
	BYTE	bDummyR1111_15:1;					// 15 : R1111.F

	// R1109
	BYTE	bDummyR1112_0:1;					// 0 : RR1112.0
	BYTE	bDummyR1112_1:1;					// 1 : RR1112.1
	BYTE	bDummyR1112_2:1;					// 2 : RR1112.2
	BYTE	bDummyR1112_3:1;					// 3 : RR1112.3
	BYTE	bDummyR1112_4:1;					// 4 : RR1112.4 
	BYTE	bDummyR1112_5:1;					// 5 : RR1112.5
	BYTE	bDummyR1112_6:1;					// 6 : RR1112.6
	BYTE	bDummyR1112_7:1;					// 7 : RR1112.7
	BYTE	bUnloadLeftSuctionAlarm:1;					// 8 : RR1112.8
	BYTE	bUnloadLeftSensorAlarm:1;					// 9 : RR1112.9
	BYTE	bUnloadLeftDownSensorAlarm:1;					// 10 : R1112.A
	BYTE	bDummyR1112_11:1;					// 11 : R1112.B
	BYTE	bDummyR1112_12:1;					// 12 : R1112.C
	BYTE	bUnloadLeftFirstSuctionAlarm:1;					// 13 : R1112.D
	BYTE	bUnloadLiftNoPcbAlarm:1;					// 14 : R1112.E
	BYTE	bUnloadLiftNoPcbCountAlarm:1;					// 15 : R1112.F

	// R1109
	BYTE	bDummyR1113_0:1;					// 0 : RR1113.0
	BYTE	bDummyR1113_1:1;					// 1 : RR1113.1
	BYTE	bDummyR1113_2:1;					// 2 : RR1113.2
	BYTE	bDummyR1113_3:1;					// 3 : RR1113.3
	BYTE	bDummyR1113_4:1;					// 4 : RR1113.4 
	BYTE	bDummyR1113_5:1;					// 5 : RR1113.5
	BYTE	bDummyR1113_6:1;					// 6 : RR1113.6
	BYTE	bDummyR1113_7:1;					// 7 : RR1113.7
	BYTE	bDummyR1113_8:1;					// 8 : RR1113.8
	BYTE	bDummyR1113_9:1;					// 9 : RR1113.9
	BYTE	bDummyR1113_10:1;					// 10 : R1113.A
	BYTE	bDummyR1113_11:1;					// 11 : R1113.B
	BYTE	bUnloadRightSuctionAlarm:1;					// 12 : R1113.C
	BYTE	bUnloadRightSensorAlarm:1;					// 13 : R1113.D
	BYTE	bDummyR1113_14:1;					// 14 : R1113.E
	BYTE	bDummyR1113_15:1;					// 15 : R1113.F

	// R1109
	BYTE	bDummyR1114_0:1;					// 0 : RR1114.0
	BYTE	bUnloadRightFirSuctionAlarm:1;					// 1 : RR1114.1
	BYTE	bDummyR1114_2:1;					// 2 : RR1114.2
	BYTE	bDummyR1114_3:1;					// 3 : RR1114.3
	BYTE	bDummyR1114_4:1;					// 4 : RR1114.4 
	BYTE	bDummyR1114_5:1;					// 5 : RR1114.5
	BYTE	bDummyR1114_6:1;					// 6 : RR1114.6
	BYTE	bDummyR1114_7:1;					// 7 : RR1114.7
	BYTE	bDummyR1114_8:1;					// 8 : RR1114.8
	BYTE	bDummyR1114_9:1;					// 9 : RR1114.9
	BYTE	bDummyR1114_10:1;					// 10 : R1114.A
	BYTE	bDummyR1114_11:1;					// 11 : R1114.B
	BYTE	bDummyR1114_12:1;					// 12 : R1114.C
	BYTE	bDummyR1114_13:1;					// 13 : R1114.D
	BYTE	bDummyR1114_14:1;					// 14 : R1114.E
	BYTE	bDummyR1114_15:1;					// 15 : R1114.F

	// R1109
	BYTE	bUnloadAlign1Alarm:1;					// 0 : RR1115.0
	BYTE	bUnloadAlign2Alarm:1;					// 1 : RR1115.1
	BYTE	bUnloadAlign3Alarm:1;					// 2 : RR1115.2
	BYTE	bUnloadAlign4Alarm:1;					// 3 : RR1115.3 //20180212 �߰�
	BYTE	bUnloadAlign5Alarm:1;					// 4 : RR1115.4 
	BYTE	bDummyR1115_5:1;					// 5 : RR1115.5
	BYTE	bUnloadAlignPcbExistAlarm:1;					// 6 : RR1115.6
	BYTE	bUnloadAlignFirstSuctionAlarm:1;		// 7 : RR1115.7 //20180212 �߰�	
	BYTE	bDummyR1115_8:1;					// 8 : RR1115.8
	BYTE	bDummyR1115_9:1;					// 9 : RR1115.9
	BYTE	bDummyR1115_10:1;					// 10 : R1115.A
	BYTE	bDummyR1115_11:1;					// 11 : R1115.B
	BYTE	bDummyR1115_12:1;					// 12 : R1115.C
	BYTE	bDummyR1115_13:1;					// 13 : R1115.D
	BYTE	bDummyR1115_14:1;					// 14 : R1115.E
	BYTE	bDummyR1115_15:1;					// 15 : R1115.F

	// R1109
	BYTE	bDummyR1116_0:1;					// 0 : RR1116.0
	BYTE	bDummyR1116_1:1;					// 1 : RR1116.1
	BYTE	bDummyR1116_2:1;					// 2 : RR1116.2
	BYTE	bDummyR1116_3:1;					// 3 : RR1116.3
	BYTE	bUnloadCartClampAlarm:1;					// 4 : RR1116.4 
	BYTE	bUnloadLiftOverloadAlarm:1;					// 5 : RR1116.5
	BYTE	bUnloadLiftUpperAlarm:1;					// 6 : RR1116.6
	BYTE	bUnloadLiftLowerALarm:1;					// 7 : RR1116.7
	BYTE	bUnloadLiftDownAlarm:1;					// 8 : RR1106.8 //20180212 �߰�
	BYTE	bDummyR1116_9:1;					// 9 : RR1116.9
	BYTE	bDummyR1116_10:1;					// 10 : R1116.A
	BYTE	bDummyR1116_11:1;					// 11 : R1116.B
	BYTE	bUnloadDoorOpenAlarm:1;					// 12 : R1116.C
	BYTE	bDummyR1116_13:1;					// 13 : R1116.D
	BYTE	bDummyR1116_14:1;					// 14 : R1116.E
	BYTE	bDummyR1116_15:1;					// 15 : R1116.F

	// R1109
	BYTE	bDummyR1117_0:1;					// 0 : RR1117.0
	BYTE	bDummyR1117_1:1;					// 1 : RR1117.1
	BYTE	bDummyR1117_2:1;					// 2 : RR1117.2
	BYTE	bUnloadIonizerAlarm:1;					// 3 : RR1117.3
	BYTE	bDummyR1117_4:1;					// 4 : RR1117.4 
	BYTE	bDummyR1117_5:1;					// 5 : RR1117.5
	BYTE	bDummyR1117_6:1;					// 6 : RR1117.6
	BYTE	bDummyR1117_7:1;					// 7 : RR1117.7
	BYTE	bUnloadTurnTableFWBWAlarm:1;					// 8 : RR1117.8
	BYTE	bUnloadTurnTableRotateAlarm:1;					// 9 : RR1117.9
	BYTE	bUnloadTurnTableUpDownAlarm:1;					// 10 : R1117.A
	BYTE	bUnloadTurnTableSuctionAlarm:1;					// 11 : R1117.B
	BYTE	bUnloadTurnTablePCBDropAlarm:1;					// 12 : R1117.C
	BYTE	bUnloadTurnTableOriginSuctionAlarm:1;					// 13 : R1117.D
	BYTE	bUnloadTurnTableOriginPcbExistAlarm:1;					// 14 : R1117.E
	BYTE	bUnloadTurnTableAlarm:1;					// 15 : R1117.F

	// R1109
	BYTE	bDummyR1118_0:1;					// 0 : RR1118.0
	BYTE	bDummyR1118_1:1;					// 1 : RR1118.1
	BYTE	bDummyR1118_2:1;					// 2 : RR1118.2
	BYTE	bDummyR1118_3:1;					// 3 : RR1118.3
	BYTE	bDummyR1118_4:1;					// 4 : RR1118.4 
	BYTE	bDummyR1118_5:1;					// 5 : RR1118.5
	BYTE	bDummyR1118_6:1;					// 6 : RR1118.6
	BYTE	bDummyR1118_7:1;					// 7 : RR1118.7
	BYTE	bDummyR1118_8:1;					// 8 : RR1118.8
	BYTE	bDummyR1118_9:1;					// 9 : RR1118.9
	BYTE	bDummyR1118_10:1;					// 10 : R1118.A
	BYTE	bDummyR1118_11:1;					// 11 : R1118.B
	BYTE	bDummyR1118_12:1;					// 12 : R1118.C
	BYTE	bDummyR1118_13:1;					// 13 : R1118.D
	BYTE	bDummyR1118_14:1;					// 14 : R1118.E
	BYTE	bDummyR1118_15:1;					// 15 : R1118.F
};
#else
struct PLC_BIT_SIGNAL_ALARM
{
	//R1050
	WORD	bInputLoadBasket;				// 0 : R1050
	WORD	bOutputLoadBasket;				// 1 : R1051
	WORD	bInputUnlodBasket;				// 2 : R1052
	WORD	bOutputUnloadBasket;			// 3 : R1053
	WORD	bChangeDirection;				// 4 : R1054
	WORD	bDummyR1054;					// 
	WORD	wLoaderPos[2];					// 6 ~ 7 : R1056  
	WORD	wUnloaderPos[2];				// 8 ~ 9 : R1058 

	//R1060
	BYTE	bEStopAlarm:1;						// 0 : R1060.0
	BYTE	bPLCBATAlarm:1;						// 1 : R1060.1
	BYTE	bAirDownAlarm:1;					// 2 : R1060.2
	BYTE	bDoorOpenAlarm:1;					// 3 : R1060.3
	BYTE	bAxis1LoadXAlarm:1;					// 4 : R1060.4
	BYTE	bAxis2LoadZLAlarm:1;				// 5 : R1060.5
	BYTE	bAxis3LoadZRAlarm:1;				// 6 : R1060.6
	BYTE	bAxis4UnloadXAlarm:1;				// 7 : R1060.7
	BYTE	bAxis5UnloadZLAlarm:1;				// 8 : R1060.8
	BYTE	bAxis6UnloadZRAlarm:1;				// 9 : R1060.9 
	BYTE	bAxis7LoadAlign1Alarm:1;			// 10 : R1060.A
	BYTE	bAxis8LoadAlign2Alarm:1;			// 11 : R1060.B
	BYTE	bAxis9LoadAlign3Alarm:1;			// 12 : R1060.C
	BYTE	bAxis10LoadAlign4Alarm:1;			// 13 : R1060.D
	BYTE	bAxis11UnloadAlign1Alarm:1;			// 14 : R1060.E
	BYTE	bAxis12UnloadAlign2Alarm:1;			// 15 : R1060.F

	//R1061
	BYTE	bAxis13UnloadAlign3Alarm:1;			// 0 : R1061.0 
	BYTE	bAxis14UnloadAlign4Alarm:1;			// 1 : R1061.1
	BYTE	bLoadHomeAlarm:1;					// 2 : R1061.2
	BYTE	bLoadLeftExistAlarm:1;				// 3 : R1061.3
	BYTE	bLoadRightExistAlarm:1;				// 4 : R1061.4
	BYTE	bLoadAlignExistAlarm:1;				// 5 : R1061.5
	BYTE	bUnloadHomeAlarm:1;					// 6 : R1061.6
	BYTE	bUnloadLeftExistAlarm:1;			// 7 : R1061.7
	BYTE	bUnloadRightExistAlarm:1;			// 8 : R1061.8
	BYTE	bUnloadAlignExistAlarm:1;			// 9 : R1061.9
	BYTE	bDummyR1061_10:1;					// 10 : 
	BYTE	bDummyR1061_11:1;					// 11 : 
	BYTE	bLoadIonizer1Alarm:1;				// 12 : R1061.C
	BYTE	bLoadIonizer2Alarm:1;				// 13 : R1061.D
	BYTE	bUnloadIonizer1Alarm:1;				// 14 : R1061.E
	BYTE	bUnloadIonizer21Alarm:1;				// 15 : R1061.F

	// R1062
	BYTE	bLoadMainPCBDropAlarm:1;				// 0 : R1062.0
	BYTE	bUnloadMainPCBDropAlarm:1;			// 1 : R1062.1
	BYTE	bDummyR1062_2:1;				// 2 : R1062.2
	BYTE	bDummyR1062_3:1;				// 3 : R1062.3
	BYTE	bDummyR1062_4:1;					// 4 :
	BYTE	bDummyR1062_5:1;					// 5 :
	BYTE	bDummyR1062_6:1;					// 6 : 
	BYTE	bDummyR1062_7:1;					// 7 : 
	BYTE	bLoadLeftSuctionAlarm:1;			// 8 : R1062.8
	BYTE	bLoadRightSuctionAlarm:1;			// 9 : R1062.9
	BYTE	bLoad2PCBAlarm:1;					// 10 : R1062.A
	BYTE	bLoadLeftPCBSizeAlarm:1;			// 11 : R1062.B
	BYTE	bLoadRightPCBSizeAlarm:1;			// 12 : R1062.C
	BYTE	bLoadLeftPCBExistAlarm:1;			// 13 : R1062.D
	BYTE	bLoadrightCBExistAlarm:1;			// 14 : R1061.E
	BYTE	bDummyR1062_15:1;					// 15 : 

	// R1063
	BYTE	bUnloadLeftSuctionAlarm:1;			// 0 : R1063.0
	BYTE	bUnloadRightSuctionAlarm:1;			// 1 : R1063.1
	BYTE	bUnload2PCBAlarm:1;					// 2 : R1063.2
	BYTE	bUnloadLeftPCBSizeAlarm:1;			// 3 : R1063.3
	BYTE	bUnloadRightPCBSizeAlarm:1;			// 4 : R1063.4 
	BYTE	bUnloadLeftPCBExistAlarm:1;			// 5 : R1063.5
	BYTE	bUnloadrightCBExistAlarm:1;			// 6 : R1063.6
	BYTE	bDummyR1063_7:1;					// 7 : R1063.7
	BYTE	bLoadAlignSuctionAlarm:1;			// 8 : R1063.8
	BYTE	bLoadAlignExistnAlarm:1;			// 9 : R1063.9
	BYTE	bLoadAlignLeftForwardAlarm:1;		// 10 : R1063.A
	BYTE	bLoadAlignLeftBackwardAlarm:1;		// 11 : R1063.B
	BYTE	bLoadAlignRightForwardAlarm:1;		// 12 : R1063.C
	BYTE	bLoadAlignRightBackwardAlarm:1;		// 13 : R1063.D
	BYTE	bDummyR1063_14:1;					// 14
	BYTE	bDummyR1063_15:1;					// 15

	// R1064
	BYTE	bUnloadAlignSuctionAlarm:1;			// 0 : R1064.0
	BYTE	bUnloadAlignExistnAlarm:1;			// 1 : R1064.1
	BYTE	bUnloadAlignLeftForwardAlarm:1;		// 2 : R1064.2
	BYTE	bUnloadAlignLeftBackwardAlarm:1;	// 3 : R1064.3
	BYTE	bUnloadAlignRightForwardAlarm:1;		// 4 : R1064.4 
	BYTE	bUnloadAlignRightBackwardAlarm:1;	// 5 : R1064.5
	BYTE	bDummyR1064_6:1;					// 6 : 
	BYTE	bDummyR1064_7:1;					// 7 : 
	BYTE	bLoadPaperNoAlarm:1;				// 8 : R1064.8
	BYTE	bLoadPaperFULLAlarm:1;				// 9 : R1064.9
	BYTE	bLoadPaperTableForwardAlarm:1;		// 10 : R1064.A
	BYTE	bLoadPaperTableBackwardAlarm:1;		// 11 : R1064.B
	BYTE	bDummyR1064_12:1;					// 12 : 
	BYTE	bDummyR1064_13:1;					// 13 : 
	BYTE	bLoadPaperNoUseExistAlarm:1;		// 14 : R1064.E
	BYTE	bDummyR1064_15:1;					// 15 : 

	// R1065
	BYTE	bUnloadPaperNoAlarm:1;				// 0 : R1065.0
	BYTE	bUnloadPaperFULLAlarm:1;				// 1 : R1065.1
	BYTE	bUnloadPaperTableForwardAlarm:1;		// 2 : R1065.2
	BYTE	bUnloadPaperTableBackwardAlarm:1;		// 3 : R1065.3
	BYTE	bDummyR1065_4:1;					// 4 :  
	BYTE	bDummyR1065_5:1;					// 5 : 
	BYTE	bUnloadPaperNoUseExistAlarm:1;		// 6 : R1065.6
	BYTE	bDummyR1065_7:1;					// 7 : 
	BYTE	bLoadBoxNoExistAlarm:1;				// 8 : R1065.8
	BYTE	bLoadBoxDropAlarm:1;				// 9 : R1065.9
	BYTE	bLoadLiftUpAlarm:1;					// 10 : R1065.A
	BYTE	bLoadLiftDownAlarm:1;				// 11 : R1065.B
	BYTE	bLoadCartLockAlarm:1;				// 12 : R1065.C
	BYTE	bLoadCartUnlockAlarm:1;				// 13 : R1065.D
	BYTE	bDummyR1065_14:1;					// 14 : 
	BYTE	bDummyR1065_15:1;					// 15 : 

	//R1066
	BYTE	bUnloadBoxNoExistAlarm:1;				// 0 : R1066.0
	BYTE	bUnloadBoxDropAlarm:1;				// 1 : R1066.1
	BYTE	bUnloadLiftUpAlarm:1;					// 2 : R1066.2
	BYTE	bUnloadLiftDownAlarm:1;				// 3 : R1066.3
	BYTE	bUnloadCartLockAlarm:1;				// 4 : R1066.4
	BYTE	bUnloadCartUnlockAlarm:1;				// 5 : R1066.5
	BYTE	bUnloadLiftMiddlePosAlarm:1;			// 6 : R1066.6
	BYTE	bDummyR1066_7:1;					// 7 : 
	BYTE	bDummyR1066_8:1;					// 8 : 
	BYTE	bDummyR1066_9:1;					// 9 : 
	BYTE	bDummyR1066_10:1;					// 10 : 
	BYTE	bDummyR1066_11:1;					// 11 : 
	BYTE	bDummyR1066_12:1;					// 12 : 
	BYTE	bDummyR1066_13:1;					// 13 : 
	BYTE	bDummyR1066_14:1;					// 14 : 
	BYTE	bDummyR1066_15:1;					// 15 : 

	//R!067
	BYTE	bTurnPCBExistAlarm:1;				// 0 : R1067.0
	BYTE	bTurnSuctionAlarm:1;				// 1 : R1067.1
	BYTE	bTurnPCBSizeAlarm:1;				// 2 : R1067.2
	BYTE	bTurnPCBDropAlarm:1;				// 3 : R1067.3
	BYTE	bTurnUnitForwardAlarm:1;			// 4 : R1067.4
	BYTE	bTurnUnitBackwardAlarm:1;			// 5 : R1067.5
	BYTE	bTurnUnitTurnAlarm:1;				// 6 : R1067.6
	BYTE	bTurnUnitReturnAlarm:1;				// 7 : R1067.7
	BYTE	bTurnUnitUpAlarm:1;					// 8 : R1067.8
	BYTE	bTurnUnitdownAlarm:1;				// 9 : R1067.9
	BYTE	bDummyR1067_10:1;					// 10 : 
	BYTE	bDummyR1067_11:1;					// 11 : 
	BYTE	bDummyR1067_12:1;					// 12 : 
	BYTE	bDummyR1067_13:1;					// 13 : 
	BYTE	bDummyR1067_14:1;					// 14 : 
	BYTE	bDummyR1067_15:1;					// 15 : 

	WORD    wDummyR1068_1069[2];

	WORD	bLoadSafePos;						// R1070
	WORD	bUnloadSafePos;						// R1071
	WORD	bLdElvPCBExist;						// R1072
	WORD	bStartMode;							// R1073
	WORD	bPCBDownDanger;						// R1074
	WORD	bAlignTablePCBExist;				// R1075
};

#endif

class DeviceMelsecLarge : public CWnd  
{
public:
	static  UINT ThreadStatus(LPVOID pParam);
	static UINT ThreadInPosition(LPVOID pParam);
	BOOL Initialize();
	DeviceMelsecLarge();
	virtual ~DeviceMelsecLarge();

protected:
	CWinThread*		m_thdStatus;
	int				m_nAxisMax;
	LONG			m_lErrorHandlerMain;
	LONG			m_lErrorHandlerLoader;
	LONG			m_lErrorHandlerUnloader;
	LONG			m_lErrorHandlerEtc1;
	LONG			m_lStatusBasket;


	LONG			m_lErrorHandler1060;
	LONG			m_lErrorHandler1061;
	LONG			m_lErrorHandler1062;
	LONG			m_lErrorHandler1063;
	LONG			m_lErrorHandler1064;
	LONG			m_lErrorHandler1065;
	LONG			m_lErrorHandler1066;
	LONG			m_lErrorHandler1067;

	LONG			m_lErrorHandlerLoader1;
	LONG			m_lErrorHandlerLoader2;
	LONG			m_lErrorHandlerLoader3;
	LONG			m_lErrorHandlerLoader4;
	LONG			m_lErrorHandlerUnloader1;
	LONG			m_lErrorHandlerUnloader2;
	LONG			m_lErrorHandlerUnloader3;
	LONG			m_lErrorHandlerUnloader4;


public:
	BOOL SetNoUseSuction(BOOL bNoUse);
	BOOL SetLoaderCartPCB(BOOL bNoUse);
	BOOL SetSafetyMode(int bNoUse);
	BOOL Set2DBarcodeTrigger();
	BOOL SetVibration(int nCount);
	BOOL SetNGPanel(int nNG);
	BOOL ResetBasketInfo(BOOL bLoad);
	BOOL SetOutputBasket(BOOL bLoad);
	BOOL SetUseNGBox(BOOL bUse);
	BOOL SetUsePaperBox(BOOL bUse);
	BOOL SetTrunPanel(BOOL bTurn);
	BOOL SetPCBSize(int bLarge);
	BOOL SetReverseDirection(BOOL bChange);
	BOOL GetUnloadBasketSignal(BOOL bIn);
	BOOL GetLoadBasketSignal(BOOL bIn);
	BOOL GetReverseDirection();
	BYTE GetBasketIn();
	



	BYTE GetLoadPickerDownOK();
	BYTE GetUnloadPickerDownOK();
	BYTE GetCurrentUnloadDetect();
	BYTE GetCurrentLoadDetect();
	BOOL SetUnloadPickerDownOK(BOOL b1st, BOOL b2nd);
	BOOL SetLoadPickerDownOK(BOOL b1st, BOOL b2nd);
	BOOL SetTablePCBExist(BOOL b1st, BOOL b2nd);
	BOOL SetTableVacuumOn(BOOL bOK);




	BOOL CheckMelsecConnect();
	void ReadStautsOther();
	BOOL IsUPVacuum(BOOL b1st, BOOL bOn);
	BOOL IsLPVacuum(BOOL b1st, BOOL bOn);
	BOOL SetPickerVacuum(BOOL bLoader, BOOL b1st, BOOL bOn);
	BOOL IsHandlerTablePCBExist(BOOL bLoader);
	BOOL IsHandlerPaperTransPCBExist(BOOL bLoader);
	BOOL IsHandlerPartError(BOOL bLoader);

	int GetWritePos(int nAxis);
	int GetCurrentPos(int nAxis);
	void GetBitSiganl(PLC_BIT_SIGNAL_FX* pData);
	int GetAxisMax();
	CString MakeRCode(int nCode);
	MMelsecFx*		m_pMelsec;

	BOOL IsHandlerBusy(int nAxis);
	BOOL IsHandlerStop(int nAxis);	

	BOOL IsReady(int nAxis = -1);
	int IsInOrigin(int nAxis = -1, BOOL bWait = TRUE);
	int IsInPosition(int nAxis = -1, BOOL bWait = TRUE);
	BOOL InPositionStop();
	BOOL PeekMessage();
	BOOL IsMotorOrigin(int nAxis);
	BOOL IsMoveEnd(int nAxis = -1);
	BOOL IsMotorStop(BOOL bFlag =TRUE);
	BOOL GetPosition(int nAxis, double& dPosition);
	BOOL SetAxisMax(int nAxisMax);
	DWORD GetIntPosition(double dPos, int nAxis);

	void ReadStatus(BOOL bFirst);
	void ReadBasket();
	void ReadPosition();
	void ReadErrorHandlerMain();
	void ReadErrorHandlerLoader();
	void ReadErrorHandlerUnloader();
	void ReadErrorHandlerEtc1();

	void ReadErrorHandler1060();
	void ReadErrorHandler1061();
	void ReadErrorHandler1062();
	void ReadErrorHandler1063();
	void ReadErrorHandler1064();
	void ReadErrorHandler1065();
	void ReadErrorHandler1066();
	void ReadErrorHandler1067();
	
	void ReadErrorHandlerLoader1();
	void ReadErrorHandlerLoader2();
	void ReadErrorHandlerLoader3();
	void ReadErrorHandlerLoader4();
	void ReadErrorHandlerUnloader1();
	void ReadErrorHandlerUnloader2();
	void ReadErrorHandlerUnloader3();
	void ReadErrorHandlerUnloader4();



	LONG GetCurrentError(ERRORCOMMAND nError);

	BOOL IsUnloadertoLoadStart();
	BOOL IsAligner(BOOL bStop = TRUE);
	BOOL IsUnload(BOOL bStop = TRUE);
	BOOL IsLoader(BOOL bStop = TRUE);
	BOOL IsAlignerPCBExist();
	BOOL IsLoaderPicker1PCBExist();
	BOOL IsLoaderPicker2PCBExist();
	BOOL IsUnloaderPicker1PCBExist();
	BOOL IsUnloaderPicker2PCBExist();
	BOOL IsResetSwitch();
	BOOL IsSystemDoorBypass(BOOL bLoader);
	BOOL IsAnyMotorRun();
	BOOL IsLoadCartNoPCB();
	BOOL SendLoadCartNoPCB();

	BOOL SetOutPort(BYTE nPortNo, WORD wOnOff);

	BOOL LoaderAlign(BOOL bOn);
	BOOL LoaderLoading(BOOL bOn);
	BOOL UnloadUnloading(BOOL bOn);
	BOOL LoaderInit();
	BOOL UnloaderInit();
	BOOL LoaderAlignLoading();
	
	BOOL MainReset(BOOL bOn);
	BOOL UnloaderPCBReset();
	BOOL LoaderPCBReset();

	BOOL LoaderCarrierElvPos();
	BOOL LoaderCarrierTablePos();
	BOOL UnloaderCarrierElvPos();
	BOOL UnloaderCarrierTablePos();

	BOOL LoaderPickerUpPos(int nNum);
	BOOL UnloaderPickerUpPos(int nNum);

	BOOL UseRoll(BOOL bUse);
	BOOL UsePaper(BOOL bUse);

	// no use func
	BOOL LoaderClampForward();
	BOOL LoaderClampBackward();
	BOOL LoaderTableForward();
	BOOL LoaderTableBackward();
	BOOL LoaderAlignXForward();
	BOOL LoaderAlignXBackward();
	BOOL LoaderAlignYForward();
	BOOL LoaderAlignYBackward();
	BOOL UnloaderClampForward();
	BOOL UnloaderClampBackward();
	BOOL UnloaderTableForward();
	BOOL UnloaderTableBackward();
	BOOL IsLoaderAlignTableForward();
	BOOL IsUnloaderAlignTableForward();
	BOOL IsLoaderCartClamp();
	BOOL IsAlignSheetTableForward();
	BOOL IsAlignGuideForward();
	BOOL IsUnloaderCartClamp();
	BOOL IsUnloaderNGBoxForward();
	BOOL IsUnloaderNGBoxBackward();
	BOOL UnloaderNGBoxForward();
	BOOL UnloaderNGBoxBackward();
	BOOL IsStartMode();
	BOOL m_bStatusStop; // Thread Stop Signal
	PLC_BIT_SIGNAL_FX GetMelsecIOStuct();
	
	PLC_BIT_SIGNAL_FX	m_NewPLCBitSignal;
	PLC_BIT_SIGNAL_FX	m_OldPLCBitSignal;

	PLC_BIT_SIGNAL_ALARM m_NewPLCBitSignalAlarm;

	long			m_lWritePos[HANDLER_AXIS_MAX];
	BOOL			m_bIsInPosition[HANDLER_AXIS_MAX];
	double			m_dScale[HANDLER_AXIS_MAX];
	BOOL			m_bCommandStop;
	BYTE			m_nInPositionCommand;	// Thread Stop Signal
	int				m_nInPositionAxis;		// Thread InPosition Axis
	int				m_nIsInPosition;		// Thread Stop Signal
	CCorrectTime	m_pStopTime;

	int				m_nInPositionCount;
	int				m_nInPositionError;

	int				m_nInposTimeCount;
	int				m_nPosition[2]; //load unload pos
	BOOL			m_bConnect;
	BOOL			m_bWriteLog;

	CDlgMelsecOCX*	theMelsecDlg;

	short	m_nLoader_ReadPLCSignal[OCX_READ_MELSEC_SIZE];


	short	m_nLoader_AlarmPLCSignal[OCX_READ_MELSEC_SIZE];
};

#endif // !defined(AFX_DEVICEMELSECLARGE_H__FDD2D725_347C_4AF7_9A75_60DA28F2F89E__INCLUDED_)

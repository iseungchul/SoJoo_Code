// HLaserIPGPulse.h: interface for the HLaserIPGPulse class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HLASERIPGPULSE_H__921EAA6C_218D_4711_B738_FA59D8A563A6__INCLUDED_)
#define AFX_HLASERIPGPULSE_H__921EAA6C_218D_4711_B738_FA59D8A563A6__INCLUDED_

#include "..\device\heocard.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class HLaserIPGPulse  
{
public:
	HLaserIPGPulse();
	virtual ~HLaserIPGPulse();

	HEocard* m_pEOCard;

	void Initialize();
	BOOL IsPowerOn();
	BOOL IsShutterOpen();
	void PowerOn(BOOL bFlag);
	void ShutterOpen(BOOL bFlag);

	BOOL SetCurrent(int nCurrent);

	POWER_STATUS GetStatus();
	void UpdateStatus();
	
	POWER_STATUS m_gStatus;

	BOOL m_bPower;
	BOOL m_bShutter;

	bool ActionCommand(BOOL bOn);

	ULONG m_lPortA;
	ULONG m_lPortB;
	ULONG m_lPortC;
	ULONG m_lAutoCard;

	bool m_bGuideBeam;
	bool m_bPreampError;
	bool m_bOverHeatError;
	bool m_bEmergencyError;
};

#endif // !defined(AFX_HLASERIPGPULSE_H__921EAA6C_218D_4711_B738_FA59D8A563A6__INCLUDED_)

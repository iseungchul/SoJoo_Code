// ScannerCalibration.h: interface for the CScannerCalibration class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCANNERCALIBRATION_H__95A0CC17_08F0_420D_852B_A60E3192FE8E__INCLUDED_)
#define AFX_SCANNERCALIBRATION_H__95A0CC17_08F0_420D_852B_A60E3192FE8E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\MODEL\DPoint.h"
#include "Calibration.h" // struct CALHEAD struct FLOATPOINT �̿��ϱ� ����

#define MAX_SIZE	65
#define MIN_FIELD	0
#define MAX_FIELD	64

class CScannerCalibration  
{
public:
	CScannerCalibration();
	virtual ~CScannerCalibration();

	void UpdateCalibration(const CALHEAD& calHead);
	void GetCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset);
	BOOL IsInside(double dX, double dY);

	BOOL m_bIsSet;
	BOOL m_bFirst;
	
	CString m_strPath;
	
	int m_nGridX;
	int m_nGridY;
	double m_dGap;
	double m_dXStart;
	double m_dXEnd;
	double m_dYStart;
	double m_dYEnd;
	
	DPOINT* m_Offset;
	
	FLOATPOINT	m_Matrix[MAX_SIZE][MAX_SIZE];
	
	void Clear();
	void SetMatrixToZero();
	
	virtual void UpdateWholeCalibration() = 0;

};

#endif // !defined(AFX_SCANNERCALIBRATION_H__95A0CC17_08F0_420D_852B_A60E3192FE8E__INCLUDED_)

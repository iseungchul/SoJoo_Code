// PacketProcess.h: interface for the CPacketProcess class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PACKETPROCESS_H__71FE9F5E_B045_4C56_937D_170945D8B225__INCLUDED_)
#define AFX_PACKETPROCESS_H__71FE9F5E_B045_4C56_937D_170945D8B225__INCLUDED_

//#include "Log.h"	// Added by ClassView

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

const char STX = 0x02;
const char ETX = 0x03;
const int MAX_SIZE = 10000;

#define RECEIVE_WRONG_MSG	0
#define RECEIVE_OPF_MSG		1
#define RECEIVE_ADS_MSG		2
#define RECEIVE_ACK_MSG		3
#define RECEIVE_NAK_MSG		4
#define RECEIVE_IDS_MSG		5
#define RECIEVE_MSC_START_MSG	6
#define RECIEVE_MSC_STOP_MSG	7

typedef struct COMM_PACKET
{
	char sMachineID[4];
	char sCMD[3];
	char sTimeStamp[5];
	char sLength[4];
	char sData[MAX_SIZE];
	CString ID;
	CString CMD;
	CString TS;
	CString LT;
	int nLength;
} PACKET;

class CPacketProcess  
{
public:

	PACKET m_stInPacket;
	PACKET m_stOutPacket;

	void ClearInPacket();
	void ClearOutPacket();
	void * MakePacket(char *pCMD, char *pData);
	int ParsePacket(char *pPacket);

	CPacketProcess();
	virtual ~CPacketProcess();

private:
//	CLog m_Log;
	CString m_strMsg;

};

#endif // !defined(AFX_PACKETPROCESS_H__71FE9F5E_B045_4C56_937D_170945D8B225__INCLUDED_)

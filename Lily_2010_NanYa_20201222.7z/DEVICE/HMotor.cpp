// HMotor.cpp: implementation of the HMotor class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "HMotor.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HMotor::HMotor()
{
	m_nMotorType		= 0; // 0 : MP920
	m_nCalType			= 0;
	m_nUseDualPanel		= 1; // 1 : Dual Panel, 0 : Single Panel
	m_pCalibration		= NULL;
	m_pAutoData			= NULL;
}

HMotor::~HMotor()
{

}

void HMotor::SetTemeratureLimits()
{
}


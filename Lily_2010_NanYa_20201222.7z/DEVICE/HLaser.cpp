// HLaser.cpp: implementation of the HLaser class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "HLaser.h"
#include "..\Model\DSystemINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HLaser::HLaser()
{
	m_nLaserType = gSystemINI.m_sHardWare.nLaserType; // LASER_CO2, LASER_UV, LASER_HYBRID, LASER_LV100, LASER_IPGPULSE;

	m_pLaserIPGPulse = NULL;
	m_pLaserCO2 = NULL;
	m_pLaserUV = NULL;
	m_pLaserQuanta = NULL;
}

HLaser::~HLaser()
{
	if(m_pLaserCO2 != NULL)
	{
		delete m_pLaserCO2;
		m_pLaserCO2 = NULL;
	}

	if(m_pLaserUV != NULL)
	{
		delete m_pLaserUV;
		m_pLaserUV = NULL;
	}

	if(m_pLaserIPGPulse != NULL)
	{
		delete m_pLaserIPGPulse;
		m_pLaserIPGPulse = NULL;
	}

	if(m_pLaserQuanta != NULL)
	{
		delete m_pLaserQuanta;
		m_pLaserQuanta = NULL;
	}
}

void HLaser::Create()
{
	// LASER_CO2, LASER_UV, LASER_HYBRID;
	switch(m_nLaserType)
	{
	case 0:
		m_pLaserCO2 = new HLaserCO2;
		m_pLaserCO2->Initialize();
		break;
	case 1:
		m_pLaserUV = new HLaserUV;
		m_pLaserUV->Initialize();
		break;
	case 2:
		m_pLaserCO2 = new HLaserCO2;
		m_pLaserCO2->Initialize();

		m_pLaserUV = new HLaserUV;
		m_pLaserUV->Initialize();
		break;
	case 4:
		m_pLaserIPGPulse = new HLaserIPGPulse;
		m_pLaserIPGPulse->Initialize();
		break;
	case 5:
		m_pLaserQuanta = new HLaserQuanta;
		m_pLaserQuanta->Initialize();
		break;
	}
}

BOOL HLaser::IsTempReady()
{
	if(m_pLaserUV != NULL)
		return m_pLaserUV->IsTempReady();

	return FALSE;
}

void HLaser::OpenPowerDlg()
{
	if(m_pLaserUV != NULL)
		m_pLaserUV->OpenPowerDlg();

	if(m_pLaserQuanta)
		m_pLaserQuanta->DoModal();
}

int HLaser::IsPowerOn()
{
#ifdef __TEST__
	return 1;
#endif
	BOOL bOnCO2 = 0, bOnUV = 0, bOnIPGPulse = 0;
	if(m_pLaserCO2 != NULL)
		bOnCO2 = m_pLaserCO2->IsPowerOn();

	if(m_pLaserUV != NULL)
		bOnUV = m_pLaserUV->IsPowerOn();

	if(m_pLaserIPGPulse != NULL)
		bOnIPGPulse = m_pLaserIPGPulse->IsPowerOn();
	
	return (int)(bOnCO2 + (bOnUV * 2) + bOnIPGPulse);
}

int HLaser::IsShutterOpen()
{
#ifdef __TEST__
	return 1;
#endif
	BOOL bOpenCO2 = 0, bOpenUV = 0, bOpenIPGPulse = 0;
	if(m_pLaserCO2 != NULL)
		bOpenCO2 = m_pLaserCO2->IsShutterOpen();

	if(m_pLaserUV != NULL)
		bOpenUV = m_pLaserUV->IsShutterOpen();

	if(m_pLaserIPGPulse != NULL)
		bOpenIPGPulse = m_pLaserIPGPulse->IsShutterOpen();

	return (int)(bOpenCO2 + (bOpenUV * 2) + bOpenIPGPulse);
}

BOOL HLaser::IsPulseOpen()
{
	if(m_pLaserUV != NULL)
		return m_pLaserUV->IsPulseOpen();

	return FALSE;
}

BOOL HLaser::ChangeAviaDiodeCurrent(double dDiodeCurrent, long lFreq, int nThermalTrack)
{
	if(m_pLaserUV != NULL)
		return m_pLaserUV->ChangeAviaDiodeCurrent(dDiodeCurrent, lFreq, nThermalTrack);

	return FALSE;
}

void HLaser::PowerOn(BOOL bFlag)
{
	if(m_pLaserCO2 != NULL)
		m_pLaserCO2->PowerOn(bFlag);

	if(m_pLaserUV != NULL)
		m_pLaserUV->PowerOn(bFlag);

	if(m_pLaserIPGPulse != NULL)
		m_pLaserIPGPulse->PowerOn(bFlag);
}

void HLaser::ShutterOpen(BOOL bFlag)
{
	if(m_pLaserCO2 != NULL)
		m_pLaserCO2->ShutterOpen(bFlag);

	if(m_pLaserUV != NULL)
		m_pLaserUV->ShutterOpen(bFlag);

	if(m_pLaserIPGPulse != NULL)
		m_pLaserIPGPulse->ShutterOpen(bFlag);
}

void HLaser::PulseOpen(BOOL bFlag)
{
	if(m_pLaserUV != NULL)
		m_pLaserUV->PulseOpen(bFlag);
}

POWER_STATUS HLaser::GetStatus()
{
	if(m_pLaserCO2 != NULL)
		return m_pLaserCO2->GetStatus();
	else if(m_pLaserIPGPulse != NULL)
		return m_pLaserIPGPulse->GetStatus();
	else
	{
		POWER_STATUS gStatus;
		memset(&gStatus, 0, sizeof(gStatus));
		return gStatus;
	}
}

BOOL HLaser::SetCurrent(double dCurrent)
{
	if(m_pLaserIPGPulse != NULL)
	{
		int nCurrent = (int)((dCurrent / 100.0) * 255);
		if(nCurrent < 0)
			nCurrent = 0;
		if(nCurrent > 255)
			nCurrent = 255;
		
		return m_pLaserIPGPulse->SetCurrent(nCurrent);
	}

	return TRUE;
}

BOOL HLaser::IsDutyError()
{
	if(m_pLaserCO2 != NULL)
	{
		return m_pLaserCO2->m_gStatus.bDutyCycleFlect & m_pLaserCO2->m_bPower;
	}
	return FALSE;
}

BOOL HLaser::IsDigitalReflectError()
{
	if(m_pLaserCO2 != NULL)
	{
		return m_pLaserCO2->m_gStatus.bDigitalReflect & m_pLaserCO2->m_bPower;
	}
	return FALSE;
}

BOOL HLaser::IsVSWRError()
{
	if(m_pLaserCO2 != NULL)
	{
		return m_pLaserCO2->m_gStatus.bMVSWR & m_pLaserCO2->m_bPower;
	}
	return FALSE;
}

BOOL HLaser::GuideBeamOnOff(BOOL bOn)
{
	if(m_pLaserIPGPulse != NULL)
		return m_pLaserIPGPulse->ActionCommand(bOn);
	
	return TRUE;
}

// 20090629 Front Mode error
int HLaser::GetAviaTriggerMode()
{
	if(m_pLaserUV != NULL)
		return m_pLaserUV->GetTriggerMode();
	else
		return 1;
}

void HLaser::LaserDoModal()
{
	
}

BOOL HLaser::setQuataParam(int nFPK, int nCurrent)
{
	if(m_pLaserQuanta)
		return m_pLaserQuanta->setQuataParam(nFPK, nCurrent);
	
	return FALSE;
}

BOOL HLaser::IsFireOK()
{
	if(m_pLaserQuanta)
	{
		m_pLaserQuanta->getStatusfromScanner();
		
		if(m_pLaserQuanta->getPowerStatus() != POWER_ON)
			return FALSE;
		
		if(!m_pLaserQuanta->isShutterOpen())
			return FALSE;
		
		if(m_pLaserQuanta->isErrorIgnore())
			return TRUE;
		
		
		if(!m_pLaserQuanta->isSystemReady())
			return FALSE;
		
		if(!m_pLaserQuanta->m_bIsPowerOnStatus)
			return FALSE;
		
		if(!m_pLaserQuanta->isMinus15VError())
			return FALSE;
		
		if(!m_pLaserQuanta->isPlus15VError())
			return FALSE;
		
		
		if(m_pLaserQuanta->m_bIsPowerOnStatus || (m_pLaserQuanta->isRfPwrOn()))//over temp event -> power off & chiller off
		{
			if(m_pLaserQuanta->isOverTemp() == FALSE) 
				return FALSE;
		}
		
		if(!m_pLaserQuanta->isRfPwrOn())
			return FALSE;
		
		if(!m_pLaserQuanta->isInterLock())
			return FALSE;
		
		if(!m_pLaserQuanta->isRfLP())
			return FALSE;
		//		if(!m_pLaserQuanta->isChiller())		
		//			return FALSE;
		if(!m_pLaserQuanta->isHighPower())
			return FALSE;
		if(!m_pLaserQuanta->isVswr())
			return FALSE;
		
		//0x322 error check
		if(!m_pLaserQuanta->isTherMistor())		
			return FALSE;
		if(!m_pLaserQuanta->isWarmUp())
			return FALSE;
		
		if(!m_pLaserQuanta->isSystemOk())
			return FALSE;
		if(!m_pLaserQuanta->isLdDriveOk())		
			return FALSE;
		
		if(!m_pLaserQuanta->isOverTemp())
			return FALSE;
		if(!m_pLaserQuanta->isEnableFB())
			return FALSE;
		
		return TRUE;
	}	
	return FALSE;
}

void HLaser::EnableOn()
{
	if(m_pLaserCO2 != NULL)
		m_pLaserCO2->EnableOn();
}

// TCalibration.h: interface for the TCalibration class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TCALIBRATION_H__C3D76623_B1E8_41EF_A0C9_4E4A388112BE__INCLUDED_)
#define AFX_TCALIBRATION_H__C3D76623_B1E8_41EF_A0C9_4E4A388112BE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Calibration.h"

struct CALDATA
{
	double dInterval;
	int nCount;
	double* dOffset;
};

class TCalibration  
{
public:
	void LoadData(CString strPath);
	TCalibration();
	virtual ~TCalibration();

	void UpdateCalibration(const CALDATA& calData);
	void GetCalibrationOffset(double dPos, double& dOffset);
	void GetPartialCalibrationOffset(double dPos, double& dOffset);
	
	volatile BOOL m_bIsSet;
	volatile BOOL m_bFirst;
	
	CString m_strPath;
	
	double m_dInterval;
	int m_nCount;
	double* m_Offset;
	
	void Clear();
	void SetMatrixToZero();
	void SaveCalibration();
	
protected:
	BOOL LoadCalibration(CString strPath);
};

#endif // !defined(AFX_TCALIBRATION_H__C3D76623_B1E8_41EF_A0C9_4E4A388112BE__INCLUDED_)

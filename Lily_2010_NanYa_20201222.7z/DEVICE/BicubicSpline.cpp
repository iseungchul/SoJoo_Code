// BicubicSpline.cpp: implementation of the CBicubicSpline class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "BicubicSpline.h"
#include <cmath>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

const int MIN_GRID_SIZE = 4;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBicubicSpline::CBicubicSpline()
{
	m_Deriv = m_d1 = m_d2 = m_d3 = m_d4 = NULL;
	m_dVal = m_dDeriv = m_yytmp = m_ytmp = m_u = NULL;

	m_nXStart = m_nXEnd = m_nYStart = m_nYEnd = 0;
}

CBicubicSpline::~CBicubicSpline()
{
	MemoryDelete();
}

void CBicubicSpline::MemoryDelete()
{
	delete [] m_Deriv;	m_Deriv = NULL;
	delete [] m_dVal;	m_dVal = NULL;
	delete [] m_dDeriv;	m_dDeriv = NULL;
	delete [] m_yytmp;	m_yytmp = NULL;
	delete [] m_ytmp;	m_ytmp = NULL;
	delete [] m_u;		m_u = NULL;
	delete [] m_d1;		m_d1 = NULL;
	delete [] m_d2;		m_d2 = NULL;
	delete [] m_d3;		m_d3 = NULL;
	delete [] m_d4;		m_d4 = NULL;
}

void CBicubicSpline::UpdateWholeCalibration()
{
	if (!m_bIsSet)
		return;

	if (m_nGridX < MIN_GRID_SIZE || m_nGridY < MIN_GRID_SIZE)
		return;

	m_nXStart = m_dXStart > MIN_TABLE ? (fmod(m_dXStart, 1.0) == 0.0 ? static_cast<int>(m_dXStart) : static_cast<int>(m_dXStart + 1)) : MIN_TABLE;
	m_nXEnd = m_dXEnd > MAX_TABLE ? MAX_TABLE : static_cast<int>(m_dXEnd);
	m_nYStart = m_dYStart > MIN_TABLE ? (fmod(m_dYStart, 1.0) == 0.0 ? static_cast<int>(m_dYStart) : static_cast<int>(m_dYStart + 1)) : MIN_TABLE;
	m_nYEnd = m_dYEnd > MAX_TABLE ? MAX_TABLE : static_cast<int>(m_dYEnd);

	TRY
	{
		MemoryDelete();

		m_Deriv = new DPOINT[m_nGridX * m_nGridY];
		m_dVal = new double[m_nGridY];
		m_dDeriv = new double[m_nGridY];
		m_yytmp = new double[m_nGridX];
		m_ytmp = new double[m_nGridX];
		
		const int nLarge = m_nGridX > m_nGridY ? m_nGridX : m_nGridY;
		m_u = new double[nLarge];

		m_d1 = new DPOINT[m_nXEnd - m_nXStart + 1];
		m_d2 = new DPOINT[m_nYEnd - m_nYStart + 1];
		m_d3 = new DPOINT[m_nYEnd - m_nYStart + 1];
		m_d4 = new DPOINT[m_nXEnd - m_nXStart + 1];
	}
	CATCH (CMemoryException, e)
	{
		MemoryDelete();

		e->ReportError();
		e->Delete();

		return;
	}
	END_CATCH

	if (!Spline2D())
		return;

	for (int nX = m_nXStart; nX <= m_nXEnd; nX++)
	{
		for (int nY = m_nYStart; nY <= m_nYEnd; nY++)
		{
			double dX, dY;
			GetPartialCalibrationOffset(nX, nY, dX, dY);
			m_Matrix[nX][nY].x += static_cast<float>(dX);
			m_Matrix[nX][nY].y += static_cast<float>(dY);
		}
	}

	for (int nX = m_nXStart; nX <= m_nXEnd; nX++)
	{
		double dX, dY;
		GetPartialCalibrationOffset(nX, m_nYStart, dX, dY);
		m_d1[nX - m_nXStart].x = dX;
		m_d1[nX - m_nXStart].y = dY;

		GetPartialCalibrationOffset(nX, m_nYEnd, dX, dY);
		m_d4[nX - m_nXStart].x = dX;
		m_d4[nX - m_nXStart].y = dY;
	}

	for (int nY = m_nYStart; nY <= m_nYEnd; nY++)
	{
		double dX, dY;
		GetPartialCalibrationOffset(m_nXStart, nY, dX, dY);
		m_d2[nY - m_nYStart].x = dX;
		m_d2[nY - m_nYStart].y = dY;
		
		GetPartialCalibrationOffset(m_nXEnd, nY, dX, dY);
		m_d3[nY - m_nYStart].x = dX;
		m_d3[nY - m_nYStart].y = dY;
	}

	for (int nX = MIN_TABLE; nX <= MAX_TABLE; nX++)
	{
		for (int nY = MIN_TABLE; nY <= MAX_TABLE; nY++)
		{
			if (!IsPartialInside(nX, nY))
			{
				double dX, dY;
				GetEdgeCalibrationOffset(nX, nY, dX, dY);
				m_Matrix[nX][nY].x += static_cast<float>(dX);
				m_Matrix[nX][nY].y += static_cast<float>(dY);
			}
		}
	}
}

void CBicubicSpline::GetPartialCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset)
{
	if (IsPartialInside(dX, dY))
	{
		for (int i = 0; i < m_nGridX; i++)
		{
			for (int j = 0; j < m_nGridY; j++)
			{
				m_dVal[j] = m_Offset[m_nGridY * i + j].x;
				m_dDeriv[j] = m_Deriv[m_nGridY * i + j].x;
			}
			GetSpline1D(m_dVal, m_dDeriv, m_dYStart, dY, m_yytmp[i], m_nGridY);
		}
		Spline1D(m_yytmp, 1.0e30, 1.0e30, m_ytmp, m_nGridX);
		GetSpline1D(m_yytmp, m_ytmp, m_dXStart, dX, dXOffset, m_nGridX);

		for (int i = 0; i < m_nGridX; i++)
		{
			for (int j = 0; j < m_nGridY; j++)
			{
				m_dVal[j] = m_Offset[m_nGridY * i + j].y;
				m_dDeriv[j] = m_Deriv[m_nGridY * i + j].y;
			}
			GetSpline1D(m_dVal, m_dDeriv, m_dYStart, dY, m_yytmp[i], m_nGridY);
		}
		Spline1D(m_yytmp, 1.0e30, 1.0e30, m_ytmp, m_nGridX);
		GetSpline1D(m_yytmp, m_ytmp, m_dXStart, dX, dYOffset, m_nGridX);
	}
	else
		dXOffset = dYOffset = 0.0;
}

void CBicubicSpline::Spline1D(double* dOffset, const double& dStartDeriv, const double& dEndDeriv, double* dDeriv, int nSize)
{
	if (dStartDeriv > 0.99e30)
		dDeriv[0] = m_u[0] = 0.0;
	else
	{
		dDeriv[0] = -0.5;
		m_u[0] = (3.0 / m_dGap) * ((dOffset[1] - dOffset[0]) / m_dGap - dStartDeriv);
	}

	const double sig = 0.5;
	for (int i = 1; i < nSize - 1; i++)
	{
		double p = sig * dDeriv[i - 1] + 2.0;
		dDeriv[i] = (sig - 1.0) / p;
		m_u[i] = (dOffset[i + 1] - dOffset[i]) / m_dGap - (dOffset[i] - dOffset[i - 1]) / m_dGap;
		m_u[i] = (6.0 * m_u[i] / (2.0 * m_dGap) - sig * m_u[i - 1]) / p;
	}

	double qn, un;
	if (dEndDeriv > 0.99e30)
		qn = un = 0.0;
	else
	{
		qn = 0.5;
		un = (3.0 / m_dGap) * (dEndDeriv - (dOffset[nSize - 1] - dOffset[nSize - 2]) / m_dGap);
	}

	dDeriv[nSize - 1] = (un - qn * m_u[nSize - 2]) / (qn * dDeriv[nSize - 2] + 1.0);

	for(int i =  nSize - 2; i >= 0; i--)
		dDeriv[i] = dDeriv[i] * dDeriv[i + 1] + m_u[i];
}

void CBicubicSpline::GetSpline1D(double* dOffset, double* dDeriv, const double& dStart, const double& dPos, double& dVal, int nSize)
{
	int klo = 0;
	int khi = nSize - 1;
	while (khi - klo > 1)
	{
		int k = (khi + klo) >> 1;
		if (dStart + m_dGap * k > dPos)
			khi = k;
		else
			klo = k;
	}

	double h = m_dGap * (khi - klo);
	if (h == 0.0)
	{
		dVal = 0.0;
		return;
	}

	double a = (dStart + m_dGap * khi - dPos) / h;
	double b = (dPos - (dStart + m_dGap * klo)) / h;
	dVal = a * dOffset[klo] + b * dOffset[khi] + ((a * a * a - a) * dDeriv[klo] + (b * b * b - b) * dDeriv[khi]) * (h * h) / 6.0;
}

BOOL CBicubicSpline::Spline2D()
{
	double *dVal = NULL, *dDeriv = NULL;

	TRY
	{
		dVal = new double[m_nGridY];
		dDeriv = new double[m_nGridY];
	}
	CATCH (CMemoryException, e)
	{
		delete [] dVal;
		delete [] dDeriv;

		e->ReportError();
		e->Delete();

		return FALSE;
	}
	END_CATCH

	for (int i = 0; i < m_nGridX; i++)
	{
		for (int j = 0; j < m_nGridY; j++)		dVal[j] = m_Offset[m_nGridY * i + j].x;
		Spline1D(dVal, 1.0e30, 1.0e30, dDeriv, m_nGridY);
		for (int j = 0; j < m_nGridY; j++)			m_Deriv[m_nGridY * i + j].x = dDeriv[j];

		for (int j = 0; j < m_nGridY; j++)			dVal[j] = m_Offset[m_nGridY * i + j].y;
		Spline1D(dVal, 1.0e30, 1.0e30, dDeriv, m_nGridY);
		for (int j = 0; j < m_nGridY; j++)			m_Deriv[m_nGridY * i + j].y = dDeriv[j];
	}

	delete [] dVal;
	delete [] dDeriv;

	return TRUE;
}

void CBicubicSpline::GetEdgeCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset)
{
	if (dX < m_dXStart && dY < m_dYStart)
	{
		double dXDist = dX;
		double dYDist = dY;
		
		double ax = 0.0;
		double bx = m_d1[0].x * dXDist / m_nXStart;
		double ay = 0.0;
		double by = m_d1[0].y * dYDist / m_nYStart;
		
		dXOffset = ax + (bx - ax) * dYDist / m_nYStart;
		dYOffset = ay + (by - ay) * dXDist / m_nXStart;
	}
	else if (dX >= m_dXStart && dX <= m_dXEnd && dY < m_dYStart)
	{
		int nX = static_cast<int>(dX - m_nXStart);
		if (nX < 0)	nX = 0;
		
		dXOffset = m_d1[nX].x * dY / m_nYStart;
		dYOffset = m_d1[nX].y * dY / m_nYStart;
	}
	else if (dX > m_dXEnd && dY < m_dYStart)
	{
		double dXDist = dX - m_nXEnd;
		double dYDist = dY;
		
		double ax = 0.0;
		double bx = m_d1[m_nXEnd - m_nXStart].x - m_d1[m_nXEnd - m_nXStart].x * dXDist / (MAX_TABLE - m_nXEnd);
		double ay = m_d1[m_nXEnd - m_nXStart].y * dYDist / m_nYStart;
		double by = 0.0;
		
		dXOffset = ax + (bx - ax) * dYDist / m_nYStart;
		dYOffset = ay + (by - ay) * dXDist / (MAX_TABLE - m_nXEnd);
	}
	else if (dX < m_dXStart && dY >= m_dYStart && dY <= m_dYEnd)
	{
		int nY = static_cast<int>(dY - m_nYStart);
		if (nY < 0)	nY = 0;
		
		dXOffset = m_d2[nY].x * dX / m_nXStart;
		dYOffset = m_d2[nY].y * dX / m_nXStart;
	}
	else if (dX > m_dXEnd && dY >= m_dYStart && dY <= m_dYEnd)
	{
		int nY = static_cast<int>(dY - m_nYStart);
		if (nY < 0)	nY = 0;
		
		dXOffset = m_d3[nY].x - m_d3[nY].x * (dX - m_nXEnd) / (MAX_TABLE - m_nXEnd);
		dYOffset = m_d3[nY].y - m_d3[nY].y * (dX - m_nXEnd) / (MAX_TABLE - m_nXEnd);
	}
	else if (dX < m_dXStart && dY > m_dYEnd)
	{
		double dXDist = dX;
		double dYDist = dY - m_nYEnd;
		
		double ax = m_d4[0].x * dXDist / m_nXStart;
		double bx = 0.0;
		double ay = 0.0;
		double by = m_d4[0].y - m_d4[0].y * dYDist / (MAX_TABLE - m_nYEnd);
		
		dXOffset = ax + (bx - ax) * dYDist / (MAX_TABLE - m_nYEnd);
		dYOffset = ay + (by - ay) * dXDist / m_nXStart;
	}
	else if (dX >= m_dXStart && dX <= m_dXEnd && dY > m_dYEnd)
	{
		int nX = static_cast<int>(dX - m_nXStart);
		if (nX < 0)	nX = 0;
		
		dXOffset = m_d4[nX].x - m_d4[nX].x * (dY - m_nYEnd) / (MAX_TABLE - m_nYEnd);
		dYOffset = m_d4[nX].y - m_d4[nX].y * (dY - m_nYEnd) / (MAX_TABLE - m_nYEnd);
	}
	else if (dX > m_dXEnd && dY > m_dYEnd)
	{
		double dXDist = dX - m_nXEnd;
		double dYDist = dY - m_nYEnd;
		
		double ax = m_d4[m_nXEnd - m_nXStart].x - m_d4[m_nXEnd - m_nXStart].x * dXDist / (MAX_TABLE - m_nXEnd);
		double bx = 0.0;
		double ay = m_d4[m_nXEnd - m_nXStart].y - m_d4[m_nXEnd - m_nXStart].y * dYDist / (MAX_TABLE - m_nYEnd);;
		double by = 0.0;
		
		dXOffset = ax + (bx - ax) * dYDist / (MAX_TABLE - m_nYEnd);
		dYOffset = ay + (by - ay) * dXDist / (MAX_TABLE - m_nXEnd);
	}
	else
		dXOffset = dYOffset = 0.0;
}
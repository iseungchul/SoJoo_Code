// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_IEODRIVE_3E80FD0F0109_INCLUDED
#define _INC_IEODRIVE_3E80FD0F0109_INCLUDED

#include "IAbstractDriver.h"

//##ModelId=4034007E0188
class IEODriver : public IAbstractDriver
{
public:
	//##ModelId=4034007E0197
	virtual bool writeIFCard(const ULONG port, const ULONG data, const char type= _T('b'));

	//##ModelId=4034007E019C
	virtual bool readIFCard( ULONG port, ULONG& data, const char type = _T('b'));

	//##ModelId=4034007E01A6
	IEODriver();

	//##ModelId=4034007E01A7
	virtual ~IEODriver();

};

#endif /* _INC_IEODRIVE_3E80FD0F0109_INCLUDED */

// ClientSock.cpp : implementation file
//

#include "stdafx.h"
#include "ClientSock.h"
#include "..\EasyDriller.h"
#include "..\Model\Glyph.h"
#include "..\EasyDrillerDlg.h"
#include "..\Model\DProcessINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define	RECEIVE_STATUS_INIT				0
#define RECEIVED_MASTER_DX_DATA			1
#define RECEIVED_MASTER_DY_DATA			2
#define RECEIVED_MASTER_THETA_DATA		3

/////////////////////////////////////////////////////////////////////////////
// CClientSock

CClientSock::CClientSock()
{
	m_bConnect = FALSE;
	m_hWnd = NULL;
}

CClientSock::~CClientSock()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CClientSock, CAsyncSocket)
	//{{AFX_MSG_MAP(CClientSock)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CClientSock member functions
void CClientSock::SetWnd(HWND hWnd)
{
	m_hWnd = hWnd;
}

void CClientSock::OnConnect(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_hWnd)
		SendMessage(m_hWnd, WM_CLIENT_CONNECT, 1, nErrorCode);
	
	CAsyncSocket::OnConnect(nErrorCode);
}

void CClientSock::OnReceive(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_hWnd)
		SendMessage(m_hWnd, WM_CLIENT_RECEIVE, 2, nErrorCode);

	CAsyncSocket::OnReceive(nErrorCode);
}

void CClientSock::OnClose(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_hWnd)
		SendMessage(m_hWnd, WM_CLIENT_CLOSE, 3, nErrorCode);

	m_bConnect = FALSE;
	CAsyncSocket::OnClose(nErrorCode);
}

BOOL CClientSock::Connect(LPCTSTR lpszHostAddress, UINT nHostPort)
{
	BOOL bResult = CAsyncSocket::Connect(lpszHostAddress, nHostPort);
	
	if(bResult == FALSE)
	{
		int nErrorCode = CAsyncSocket::GetLastError();
		
		switch(nErrorCode)
		{
		case WSANOTINITIALISED:
		case WSAENETDOWN:
		case WSAEADDRINUSE:
		case WSAEINPROGRESS:
		case WSAEAFNOSUPPORT:
		case WSAECONNREFUSED:
		case WSAEDESTADDRREQ:
		case WSAEFAULT:
		case WSAEINVAL:
		case WSAEISCONN:
		case WSAEMFILE:
		case WSAENOBUFS:
		case WSAENOTSOCK:
		case WSAETIMEDOUT:
			TRACE(_T("Connection Failure.\n"));
			m_bConnect = FALSE;
			return FALSE;
			break;
		case WSAEWOULDBLOCK:
			// If an error code is WSAWOULDBLOCK, and your application
			// is using the override callbacks,
			// your application will receive an OnConnect message
			// when the connect operation is complete. -> refer to MSDN.
			TRACE(_T("Connection Success.\n"));
			m_bConnect = TRUE;
			return TRUE;
		default:
			TRACE(_T("Connection Failure.\n"));
			m_bConnect = FALSE;
			return FALSE;
		}
		return FALSE;
	}
	
	TRACE(_T("Connection Success.\n"));
	
	m_bConnect = TRUE;
	return (TRUE);
}

int CClientSock::ReceiveData()
{
	char sTemp[65535] = {0,};
	Receive(sTemp, 65535);
	if((strcmp(sTemp, "") != 0))
		return RETURN_FAIL_;

	m_PacketProc.ClearInPacket();

	int nResult = m_PacketProc.ParsePacket(sTemp);
	CString str;
//	str.Format(_T("%d : ������ �޾ҽ��ϴ�."), nResult);
//	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&str));
	
	return nResult;
}

void CClientSock::SendNAK()
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	
	char *Temp;
	Temp = (LPSTR)(LPCTSTR)m_PacketProc.m_stInPacket.CMD;
	pPacket = (char *)(m_PacketProc.MakePacket(_T("NAK"), Temp));
	strPacket.Format(_T("%c%s%c"), STX, pPacket,ETX);
	Send(strPacket, 21);
//	strMsg.Format(_T("(Send NAK Message) %s"), strPacket);
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->WriteLog(strMsg);
}

void CClientSock::SendACK()
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	
	char *Temp;
	Temp = (LPSTR)(LPCTSTR)m_PacketProc.m_stInPacket.CMD;
	pPacket = (char *)(m_PacketProc.MakePacket(_T("ACK"), Temp));
	strPacket.Format(_T("%c%s%c"), STX, pPacket,ETX);
	Send(strPacket, 21);
	strMsg.Format(_T("(Send ACK Message) %s"), strPacket);
//	WriteLog(strMsg);
}

CString CClientSock::GetFileName()
{
	CString str;
	str.Format(_T("%s"), m_PacketProc.m_stInPacket.sData);
	return str;
}

CString CClientSock::GetBarcodeID()
{
	CString str;
	str.Format(_T("%s"), m_PacketProc.m_stInPacket.sData);
	return str;
}

BOOL CClientSock::GetOffsetAndAngle(double& dx, double& dy, double& dDeg, double& dx2, double& dy2, double& dDeg2)
{
	char sADSData[MAX_SIZE];
	memset(sADSData, 0 , MAX_SIZE);
	strcpy_s(sADSData, m_PacketProc.m_stInPacket.sData);
	char *pToken;
	TCHAR *szNext;
	CString strData;
	int nReceiveStatus = RECEIVE_STATUS_INIT;
	BOOL bFindDX, bFindDY, bFindTHETA, bFindDX2, bFindDY2, bFindTHETA2;
	bFindDX = bFindDY = bFindTHETA = FALSE;
	bFindDX2 = bFindDY2 = bFindTHETA2 = FALSE;
	pToken = strtok_s(sADSData, _T(";"), &szNext);
	
	while ( pToken != NULL )
	{
		strData = pToken;
		
		// �� �Ӹ��� ���۰�����... ���~ ���� ����� �������� ����.. ������..��,.�� 
		if ( strData.Find(_T("DX")) != -1 )
		{
			nReceiveStatus = RECEIVED_MASTER_DX_DATA;
		}
		else if ( strData.Find(_T("DY")) != -1 )
		{
			nReceiveStatus = RECEIVED_MASTER_DY_DATA;
		}
		else if ( strData.Find(_T("THETA")) != -1 )
		{
			nReceiveStatus = RECEIVED_MASTER_THETA_DATA;
		}	
		else if ( nReceiveStatus == RECEIVED_MASTER_DX_DATA )
		{
			if(!bFindDX)
			{
				dx = (atof(strData));
				nReceiveStatus = RECEIVE_STATUS_INIT;
				bFindDX = TRUE;
			}
			else
			{
				dx2 = (atof(strData));
				nReceiveStatus = RECEIVE_STATUS_INIT;
				bFindDX2 = TRUE;
			}

		}
		else if ( nReceiveStatus== RECEIVED_MASTER_DY_DATA )
		{
			if(!bFindDY)
			{
				dy = (atof(strData));
				nReceiveStatus = RECEIVE_STATUS_INIT;
				bFindDY = TRUE;
			}
			else
			{
				dy2 = (atof(strData));
				nReceiveStatus = RECEIVE_STATUS_INIT;
				bFindDY2 = TRUE;
			}
		}
		else if ( nReceiveStatus== RECEIVED_MASTER_THETA_DATA )
		{
			if(!bFindTHETA)
			{
				dDeg = atof(strData);
				nReceiveStatus = RECEIVE_STATUS_INIT;
				bFindTHETA = TRUE;
			}
			else
			{
				dDeg2 = atof(strData);
				nReceiveStatus = RECEIVE_STATUS_INIT;
				bFindTHETA2 = TRUE;
			}
		}
		
		pToken = strtok_s(NULL, _T(";"), &szNext);
	}
	
	if ( ( bFindDX && bFindDY && bFindTHETA /* &&
		   bFindDX2 && bFindDY2 && bFindTHETA2 */) == FALSE )
	{
		return FALSE;
	}
	
	return TRUE;
}

void CClientSock::ReConnectTry()
{
	unsigned int unClientPort = 0;
	char sClientIPAddr[16] = {0,};
	CString str, str2;
	str = ::AfxGetApp()->GetProfileString(_T("Settings"), _T("Address"), _T("127.0.0.1"));
	strncpy_s(sClientIPAddr, 16, str, 15);
	unClientPort = ::AfxGetApp()->GetProfileInt(_T("Settings"), _T("Port"), 5001);

	Close();

	SetWnd(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_hWnd);
	Create();
	if(FALSE == Connect(sClientIPAddr, unClientPort))
	{
		m_bConnect = FALSE;
//		ErrMessage(_T("���� ����"));
//		return;
	}	
	else
		m_bConnect = TRUE;
}

int CClientSock::SendFileOpen(CString strFile)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();
	
	char cTemp[255];
	memset(cTemp, 0, 255);
	memcpy(cTemp, strFile, 255);
	pPacket = (char *)(m_PacketProc.MakePacket(_T("OPF"), cTemp));
	strPacket.Format(_T("%c%s%c"), STX, pPacket,ETX);
	Send(strPacket, strPacket.GetLength());

	int nCount = 0;
	int nReturn;
	while(nCount > 50) // 5sec
	{
		::Sleep(100);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ACK_MSG)
		{
			strMsg.Format(_T("%s"), m_PacketProc.m_stInPacket.sData);
			if (strncmp(strMsg, _T("OPF"), 3) == 0)
				return SEND_OK_;
			else
				return RETURN_FAIL_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
	}
	return TIME_OUT_;
}

int CClientSock::GetRealPos(DPOINT *ptdPos, int nCamNo, int nIndex, int nMaskNo)
{
	char *pPacket;
	CString strPacket;
	CString strMsg;
	m_PacketProc.ClearOutPacket();
	ReceiveData();

	strMsg.Format(_T("%02d;%02d;%02d"),nCamNo, nIndex, nMaskNo);
	char cTemp[255];
	memset(cTemp, 0, 255);
	memcpy(cTemp, strMsg, 255);
	pPacket = (char *)(m_PacketProc.MakePacket(_T("ADS"), cTemp));
	strPacket.Format(_T("%c%s%c"), STX, pPacket,ETX);
	Send(strPacket, strPacket.GetLength());
	
	int nCount = 0;
	int nReturn;
	double dAngle, dx2, dy2, dAngle2;
	while(nCount > 50) // 5sec
	{
		::Sleep(100);
		nReturn = ReceiveData();
		if(nReturn == RECEIVE_ADS_MSG)
		{
			if(!GetOffsetAndAngle(ptdPos->x, ptdPos->y, dAngle, dx2, dy2, dAngle2))
				return RETURN_FAIL_;

			return SEND_OK_;
		}
		else if(nReturn == RECEIVE_NAK_MSG)
		{
			return RETURN_FAIL_;
		}
	}
	return TIME_OUT_;
}

// Calibration.h: interface for the CCalibration class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CALIBRATION_H__7A85BED6_EED5_4A03_A714_67B5BEFABA17__INCLUDED_)
#define AFX_CALIBRATION_H__7A85BED6_EED5_4A03_A714_67B5BEFABA17__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\model\DPoint.h"

const int MAX_TABLE_SIZE = 1001;
const int MIN_TABLE = 0;
const int MAX_TABLE = 1000;

struct CALHEAD
{
	int nGridX;
	int nGridY;
	double dGap;
	double dXStart;
	double dYStart;
	DPOINT* dOffset;
};

struct FLOATPOINT
{
	float x, y;
};

class CCalibration  
{
public:
	void SetMaster(BOOL bMaster);
	BOOL m_b1stPanel;
	
	virtual ~CCalibration();

	void LoadCalibration(CString strPath);
	
	void UpdateCalibration(const CALHEAD& calHead, BOOL bSave = TRUE);
	void SetMatrixToZero();
	void GetCalibrationOffset(double dX, double dY, double& dXOffset, double& dYOffset);
	
protected:
	CCalibration();

	volatile BOOL m_bIsSet;
	volatile BOOL m_bFirst;
	
	CString m_strPath;
	
	int m_nGridX;
	int m_nGridY;
	double m_dGap;
	double m_dXStart;
	double m_dXEnd;
	double m_dYStart;
	double m_dYEnd;
	
	DPOINT* m_Offset;
	
	FLOATPOINT	m_Matrix[MAX_TABLE_SIZE][MAX_TABLE_SIZE];
	
	void Clear();
	void SaveCalibration();
	
	BOOL IsPartialInside(double dX, double dY);
	BOOL IsInside(double& dX, double& dY);
	
	virtual void UpdateWholeCalibration() = 0;
};

#endif // !defined(AFX_CALIBRATION_H__7A85BED6_EED5_4A03_A714_67B5BEFABA17__INCLUDED_)

// ZCalibration.h: interface for the CZCalibration class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZCALIBRATION_H__D5A3ECF1_4608_4587_A090_42FCE643B6DA__INCLUDED_)
#define AFX_ZCALIBRATION_H__D5A3ECF1_4608_4587_A090_42FCE643B6DA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Calibration.h"

class CZCalibration  
{
public:
	void LoadData(CString strPath, BOOL bFirst);
	CZCalibration();
	virtual ~CZCalibration();
	
	void UpdateCalibration(const CALHEAD& calHead);
	void GetCalibrationOffset(double dX, double dY, double& dOffset);
	void GetPartialCalibrationOffset(double dX, double dY, double& dOffset);
	
	volatile BOOL m_bIsSet;
	volatile BOOL m_bFirst;
	
	CString m_strPath;
	
	int m_nGridX;
	int m_nGridY;
	double m_dGap;
	double m_dXStart;
	double m_dXEnd;
	double m_dYStart;
	double m_dYEnd;

	DPOINT* m_Offset;
	
	void Clear();
	void SetMatrixToZero();
	void SaveCalibration(BOOL bFirst);
	
	BOOL IsPartialInside(double dX, double dY);
	BOOL IsInside(double dX, double dY);

protected:
	BOOL LoadCalibration(CString strPath, BOOL bFirst);
	
};

#endif // !defined(AFX_ZCALIBRATION_H__D5A3ECF1_4608_4587_A090_42FCE643B6DA__INCLUDED_)

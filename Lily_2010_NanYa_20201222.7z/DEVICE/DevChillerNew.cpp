// DevChillerNew.cpp: implementation of the CDevLaserPower class.
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DevChillerNew.h"
#include "..\MODEL\DSystemINI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

const int STX = 0x02;
const int CR = 0x0D;
const int LF = 0x0A;
const int ETX = 0x03;
//extern HINSTANCE g_hDllDeviceCom;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDevChillerNew::CDevChillerNew()
	: CAsyncComm()
{
	memset(m_szCmd, 0, sizeof(m_szCmd));
	m_nTemperature = 0;
	m_nFlowRate = 0;
	m_nPressure = 0;
	m_nStatus = 0;
	m_nRun = 1;
	m_nRun2 = 1;
	m_nSetRun = 2;
	m_nAlarm = 0;
	m_nAlarm2 = 0;
	m_nRemote = 0;
	m_nRemote2 = 0;
}

CDevChillerNew::~CDevChillerNew()
{

}

BOOL CDevChillerNew::Create()
{
	InitializeCriticalSection(&m_csCommunicationSync);
	SetBinaryMode(TRUE);
	CheckParity(FALSE);
	SetPort((TPort)m_nPortNo);
	SetBaudRate((TBaudRate)m_nBaudRate);
	SetParity((TParity)m_nParity);
	SetByteSize((TByteSize)m_nDataBits);
	SetStopBits((TStopBits)m_nStopBits);
	SetFlowControl((TFlowControl)m_nFlowControl);
	SetTimeOut(0);
	SetEventChar(0x0d);
	SetEventMask(EV_BREAK | EV_CTS | EV_DSR | EV_ERR | EV_RING | EV_RLSD | EV_RXCHAR | EV_RXFLAG | EV_TXEMPTY);
	
	OpenComm();
	if(PortOpened())
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

void CDevChillerNew::Destroy()
{
	CloseComm();
	DeleteCriticalSection(&m_csCommunicationSync);
}

char* CDevChillerNew::QueryCommand(char *szCmd)
{
	if (!PortOpened())
		return "";

	char szTmp[1024], szTrans[1024], szRet[1024];
	BOOL FEnd;
	TAssWaitResult wr;

	memset(szTmp, 0x00, sizeof(szTmp));
	memset(szRet, 0x00, sizeof(szRet));
	memset(szTrans, 0x00, sizeof(szTrans));

	EnterCriticalSection(&m_csCommunicationSync);
  
	if (strlen(szCmd) <= 1024)
	{
		FEnd = FALSE;
		PurgeComm( FHandle, PURGE_TXCLEAR);
		PurgeComm( FHandle, PURGE_RXABORT + PURGE_RXCLEAR );
		sprintf_s(szTrans, 1024, _T("%s"), szCmd); 

	    WriteString(szTrans);
    
		wr = FReceiveEvent.WaitFor(FTimeOut);
		if (wr == wrSignaled)
		{
//#ifndef __TEST__
			Sleep(100);
//#endif
			strcpy_s(szRet, ReadString());

			if (strlen(szRet) > 0)
			{
				LeaveCriticalSection(&m_csCommunicationSync);
				return &szRet[0];
			}
			else
			{
      			LeaveCriticalSection(&m_csCommunicationSync);
				return _T("");
			}
		}
		else
		{
		FireTimeOut();       
    	LeaveCriticalSection(&m_csCommunicationSync);
		return _T("");
	    }
	}
	LeaveCriticalSection(&m_csCommunicationSync);
	return &szTmp[0];
}

void CDevChillerNew::ProcessMonitor()
{

}

void CDevChillerNew::FireReceived()
{
	FReceiveEvent.SetEvent();
}

void CDevChillerNew::SetParameter(int nPortNo, int nBaudRate, int nParity, int nDataBits, int nStopBits, int nFlowControl)
{
	m_nPortNo = nPortNo;
	m_nBaudRate = nBaudRate;
	m_nParity = nParity;
	m_nDataBits = nDataBits;
	m_nStopBits = nStopBits;
	m_nFlowControl = nFlowControl;
}

char* CDevChillerNew::MakePack(char* szCmd)
{
	//�۽� = STX + "01 00 00C8 3 C F" + ETX + CR
	//���� = STX + "01DRS,OK,04D2,0929" + CR + LF
	// # PV=04D2 �� 1234 �� 123.4, SV = 0929 �� 2345 �� 234.5

	CString strTemp1;
	memset(m_szCmd, 0, sizeof(m_szCmd));
	int nCheckSum = 0;
	int i = 0;

	while(szCmd[i] != NULL)
	{
		nCheckSum +=  szCmd[i];
		if( szCmd[i] == '\0')
			break;
		i++;
	}
	CString strTemp2;
	strTemp2.Format(_T("%X"),nCheckSum);
	strTemp2 = strTemp2.Right(2);;

	strTemp1.Format(_T("%c%s%s%c%c"), STX, szCmd, strTemp2, ETX, CR);
	sprintf_s(m_szCmd, strTemp1);
	
	return m_szCmd;
}

double CDevChillerNew::ParsePack(char* szResult, int nChannel)
{
	CString str;
	str.Format("%s", szResult);
	double dVal = 0;
	char szTemp[5];
	char szSTX[5];
	char szTo[5];
	char szFrom[5];
	char szTemperature[5];
	char szFlowRate[5];
	char szPressure[5];
	char szStatus[11];
	char szCheckSum[5];
	char szETX[5];
	char szCR[5];
	char szAlarm[10];

	memset(szSTX, 0, sizeof(szSTX));
	memset(szTo, 0, sizeof(szTo));
	memset(szFrom, 0, sizeof(szFrom));
	memset(szTemperature, 0, sizeof(szTemperature));
	memset(szFlowRate, 0, sizeof(szFlowRate));
	memset(szPressure, 0, sizeof(szPressure));
	memset(szStatus, 0, sizeof(szStatus));
	memset(szCheckSum, 0, sizeof(szCheckSum));
	memset(szETX, 0, sizeof(szETX));
	memset(szCR, 0, sizeof(szCR));
	memset(szAlarm, 0, sizeof(szAlarm));

	int nCount = 0;
	strncpy(szSTX, &szResult[0],1);
	strncpy(szTo, &szResult[1],2);
	strncpy(szFrom, &szResult[3],2);
	strncpy(szTemperature, &szResult[5],4);
	strncpy(szFlowRate, &szResult[9],4);
	strncpy(szPressure, &szResult[13],4);
	strncpy(szStatus, &szResult[17],1);
	strncpy(szAlarm, &szResult[18],9);
	strncpy(szCheckSum, &szResult[27],2);
	strncpy(szETX, &szResult[29],1);
	strncpy(szCR, &szResult[30],1);
	memset(szTemp, 0, sizeof(szTemp));

	m_nTemperature = (int)strtol(szTemperature,NULL,16);
	m_nFlowRate = (int)strtol(szFlowRate,NULL,16);
	m_nPressure = (int)strtol(szPressure,NULL,16);
	m_nStatus = (int)strtol(szStatus,NULL,16);

	if(nChannel == 1)
	{
		m_nAlarm = (int)strtol(szAlarm,NULL,16);
		m_nRun = 1 & m_nStatus;
		m_nRemote = 0x04 & m_nStatus;
	}
	else if(nChannel ==2)
	{
		m_nAlarm2 = (int)strtol(szAlarm,NULL,16);
		m_nRun2 = 1 & m_nStatus;
		m_nRemote2 = 0x04 & m_nStatus;
	}
	

	int nIndex;
	nIndex = str.Find("OK");

	if(nIndex == -1)
		return -1;
	else
	{
		str = str.Mid(nIndex+1,4);
		strcpy_s(szTemp, (LPCTSTR)str);
		
		for(int i = 0; szTemp[i] != ' '; i++)
		{
			dVal += ConvertASCIItoNum(szTemp[i]);
		}

		return dVal/10.;
	}
	return -1;

}
int CDevChillerNew::ConvertASCIItoNum(char ascii)
{
	if(isdigit(ascii))
		return ascii - '0';
	if(islower(ascii))
		return ascii - 'a' + 10;

	return ascii - 'A' + 10;
}

BOOL CDevChillerNew::IsConnect()
{
	return PortOpened();
}

double CDevChillerNew::GetChillerTemp(int nChannel, double &dTemperature, double &dFlowRate, double &dPressure)
{
	m_nTemperature = 0;
	m_nFlowRate = 0;
	m_nPressure = 0;

	double dVal = 0.0;
	int nVal = 200;
	char szCmd[300], szResult[500];
	memset(szCmd, 0 , sizeof(szCmd));
	memset(szResult, 0, sizeof(szResult));
	CString strChannel;
	strChannel.Format(_T("%02d00"),nChannel);
	strcpy(szCmd, strChannel);
	CString strTemperature;

	if(nChannel == 1)
		strTemperature.Format(_T("%04X"), (int)gSystemINI.m_sSystemDevice.sChillerPort.dCH1*10); // ���ð�
	else 
		strTemperature.Format(_T("%04X"), (int)gSystemINI.m_sSystemDevice.sChillerPort.dCH2*10); // ���ð�

	strcat(szCmd, strTemperature);
	CString strStatus;
	strStatus.Format(_T("%d"), 1+m_nSetRun);
	strcat(szCmd, strStatus);
	strcpy(szCmd, MakePack(szCmd));
	SetCmdSize(30);
	strcpy(szResult, QueryCommand(szCmd));


#ifdef __TEST__
	//CString strResult;
	//strResult.Format(_T("%c000100F4003900415000000000BF%c%c"),STX,ETX,CR);
	//strcpy(szResult,strResult);
#endif
	dVal = ParsePack(szResult, nChannel);
	
	dTemperature = m_nTemperature / 10.0;
	dFlowRate = m_nFlowRate / 10.0;
	dPressure = m_nPressure / 10.0;

	return dVal;
}
#pragma once

class C2DVisionSocket;

class HVision2D
{
public:
	HVision2D(void);
	~HVision2D(void);
	
	BOOL Connect();
	BOOL SetAcqTriggerEnable(BOOL bUse);
	BOOL SetAcqTrigger(BOOL bTrigger);
	BYTE GetAcqStatusRegister();
	BOOL SetUserData(char* Data);
	BOOL SetBufferResultEnable(BOOL bEnable);
	BYTE GetDecodeStatusRegister();
	BOOL SetDecodeResultAck(BOOL bAck);
	UINT GetDecodeResult();
	UINT GetResultID();
	UINT GetResultCode();
	UINT GetResultExtended();
	UINT GetResultLength();
	void GetResultData(char* pData);
	BOOL SetSoftEvents();
	UINT GetTriggerID();
	BOOL SetUserDataOption();
	BOOL SetUserDataLength(int nSize);
	BYTE GetSoftEventAck();
	void Get2DBarcode(char * szResult);
	
public :
	C2DVisionSocket* m_pClientSock;
	BOOL m_bConnect;
};


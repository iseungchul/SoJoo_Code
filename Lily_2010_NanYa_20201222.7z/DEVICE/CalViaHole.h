// CalViaHole.h: interface for the CCalViaHole class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CALVIAHOLE_H__71962CD3_B5DA_11D4_9E00_004F490C4B72__INCLUDED_)
#define AFX_CALVIAHOLE_H__71962CD3_B5DA_11D4_9E00_004F490C4B72__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Interpolation.h"

class CCalViaHole : public CObject
{
public:
	BOOL Calibration();

	CCalViaHole();
	virtual ~CCalViaHole();

private:
	void LoadBeamTextFile();
	void CalculateCalibrationAndSave();
	void LoadCalibrationData();
	void LoadLowCalibrationFile();

	Interpolation m_InterpolCal;

	BOOL m_bIsFileOK;
};

#endif // !defined(AFX_CALVIAHOLE_H__71962CD3_B5DA_11D4_9E00_004F490C4B72__INCLUDED_)

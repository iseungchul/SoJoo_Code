// DPCOutput.cpp: implementation of the DPCOutput class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "easydriller.h"
#include "DPCOutput.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DPCOutput::DPCOutput()
{
	// Sys Request
	m_bSysStart					= 0;
	m_bSysStop					= 0;
	m_bSysAlarmClearReq			= 0;
	m_bDoorByPass				= 0;
	m_bNotUseBuzzer				= 0;
	m_bNewCassetteChangeReq		= 0;
	m_bCoatingParamDownReq		= 0;
	m_bCleaningParamDownReq		= 0;
	m_bHandlerPosDownReq		= 0;
	m_bCoaterPosDownReq			= 0;
	m_bWaferSize				= 0;
	m_bWorkingTool				= 0;
	m_bTableVacuumSolReq		= 0;
	m_bTableVacuumExhaustReq	= 0;
	m_bLaserEnableReq			= 0;
	m_bN2GasSolReq				= 0;

	// Chuck Interface between Stage and PLC
	memset( &m_sStageIF, 0, sizeof(m_sStageIF) );
	m_bHandlerRun				= 0;
	m_bAllInitReq				= 0;
	m_bOnlyHanadlerInitReq		= 0;
	m_bOnlyStageInitReq			= 0;
	m_bOnlyCoaterInitReq		= 0;
	m_bAllInitIgnoreErr			= 0;

	// Dry Run
	m_bFullDryRun				= 0;
	m_bNoWaferFullDryRun		= 0;
	m_bSkipCoaterRun			= 0;

	// Manual Wafer Status Change
	m_bRailZoneWaferStatusClearReq			= 0;
	m_bCoaterZoneWaferStatusClearReq		= 0;
	m_bLPickerZoneWaferStatusClearReq		= 0;
	m_bBufferZoneWaferStatusClearReq		= 0;
	m_bChuckZoneWaferStatusClearReq			= 0;
	m_bBPickerZoneWaferStatusClearReq		= 0;
	m_bCassetteSlotWaferStatusChangeReq		= 0;
	memset( &m_bSlot, 0, sizeof(m_bSlot) );
	m_nMpgMode					= 0;
}

DPCOutput::~DPCOutput()
{

}

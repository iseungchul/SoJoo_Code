// HLaserCO2.h: interface for the HLaserCO2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HLASERCO2_H__F2E8432D_38C6_4F07_92CE_A4F5879E8704__INCLUDED_)
#define AFX_HLASERCO2_H__F2E8432D_38C6_4F07_92CE_A4F5879E8704__INCLUDED_

#include "..\device\heocard.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class HLaserCO2  
{
public:
	void EnableOn();
	HLaserCO2();
	virtual ~HLaserCO2();

	HEocard* m_pEOCard;

	void Initialize();
	BOOL IsPowerOn();
	BOOL IsShutterOpen();
	void PowerOn(BOOL bFlag);
	void ShutterOpen(BOOL bFlag);

	POWER_STATUS GetStatus();
	void UpdateStatus();

	POWER_STATUS m_gStatus;
	BOOL m_bPower;
	BOOL m_bShutter;
};

#endif // !defined(AFX_HLASERCO2_H__F2E8432D_38C6_4F07_92CE_A4F5879E8704__INCLUDED_)

// DevicePMac.cpp: implementation of the DevicePMac class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DevicePMac.h"
#include "..\..\MotionControlDLL_2010\MotionControlDll_Interface.h"
#include "..\alarmmsg.h"
#include "..\Model\DEasyDrillerIni.h"
#include "math.h"

#define WRITE_BASE			0x610A0
#define READ_BASE			0x61000
#define SET_XY_PARAM_BASE	0x40

#define TIME_STATUS			50
#define WAIT_COMMAND_TIME	20
#define MAX_STOPOVER_TIME	25.0
#define MP920_SCALE			1000.0

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

UINT DevicePMac::ThreadPMacStatus(LPVOID pParam)
{
	DevicePMac *pPMac = (DevicePMac *)pParam;
	BOOL bFirst = TRUE;
	
	do
	{
#ifndef __TEST__
		Sleep(TIME_STATUS);
#endif
		// read
		pPMac->ReadStatus(bFirst);
		
		if(bFirst)
			bFirst = FALSE;
		
	} while(!pPMac->m_bStatusStop);
	return TRUE;
}

UINT DevicePMac::ThreadPMacInPosition(LPVOID pParam)
{
	DevicePMac *pPMac = (DevicePMac *)pParam;
	
	pPMac->m_bCommandStop = false;
	do
	{
#ifndef __TEST__
		Sleep(TIME_STATUS);
#endif
		switch(pPMac->m_nInPositionCommand)
		{
		case COMMAND_INPOSITION :		// ���� ����
			if(pPMac->IsMoveEnd(pPMac->m_nInPositionAxis))
				pPMac->m_nIsInPosition = TRUE;
			break;
		}
		
		if(pPMac->m_nIsInPosition == TRUE)
			pPMac->m_pStopTime.StartTime();
		
		if(pPMac->m_pStopTime.PresentTime() > MAX_STOPOVER_TIME)
			pPMac->m_nIsInPosition = -1;
	} while(!pPMac->m_bPositionStop);
	return TRUE;
}

DevicePMac::DevicePMac()
{
	m_thdStatus			= NULL;
	m_thdInPosition		= NULL;
	m_bStatusStop		= FALSE;
	m_nIsInPosition		= FALSE;
	m_bPositionStop		= FALSE;
	m_nInPositionCount	= 0;

	m_lStatusIO1		= 0;
	m_lStatusIO2		= 0;
	m_lStatusIO3		= 0;
	m_lStatusIO4		= 0;
}

DevicePMac::~DevicePMac()
{
	m_bStatusStop = TRUE;
	m_bPositionStop = TRUE;
	
	if(m_thdStatus != NULL)		// Thread ����
		WaitForSingleObject(m_thdStatus->m_hThread, INFINITE);
	m_thdStatus = NULL;
	
	if(m_thdInPosition != NULL)
	{
		m_thdInPosition->ResumeThread();
		WaitForSingleObject(m_thdInPosition->m_hThread, INFINITE);
	}
	
	if(::MotionControlDLL_IsInitialized())
	{
		::MotionControlDLL_Uninitialize();
	}
}

BOOL DevicePMac::Initialize()
{
	CString strPath;
	CString strMotionControlProfile, strPMACProfile, strInputIOProfile, strOutputIOProfile;
	
	strPath.Format(_T("%s"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	strMotionControlProfile.Format(
		_T("%s\\MotionControl.ini"),
		strPath
		);
	
	strPMACProfile.Format(
		_T("%s\\PMACProfile.ini"),
		strPath
		);
	
	strInputIOProfile.Format(
		_T("%s\\InputIOControl.ini"),
		strPath
		);
	
	strOutputIOProfile.Format(
		_T("%s\\OutputIOControl.ini"),
		strPath
		);
	
	BOOL bResult = ::MotionControlDLL_Initialize(
		strPMACProfile,
		strMotionControlProfile,
		strInputIOProfile,
		strOutputIOProfile
		);
	
	if(bResult)
	{
		if(m_thdStatus == NULL)		// Thread  Ȱ��ȭ
		{
			m_thdStatus = ::AfxBeginThread(ThreadPMacStatus, this);
		}

		if(m_thdInPosition == NULL)
		{
			m_thdInPosition = ::AfxBeginThread(ThreadPMacInPosition, this);
			m_thdInPosition->SuspendThread();
		}
	}
	
	return bResult;
}

void DevicePMac::ReadStatus(BOOL bFirst)
{
//	::MotionControlDLL_ReadMem(0, sizeof(DpramReadPosition1), &m_NewStatus1);
//	::MotionControlDLL_ReadMem(1, sizeof(DpramReadPosition2), &m_NewStatus2);

	ReadPosition();
//	ReadStatusIO1();
//	ReadStatusIO2();
//	ReadStatusIO3();
//	ReadStatusIO4();
	
	if(bFirst)
	{
		memcpy(&m_OldStatus1, &m_NewStatus1, sizeof(DpramReadPosition1));
		memcpy(&m_OldStatus2, &m_NewStatus2, sizeof(DpramReadPosition2));
	}
}

void DevicePMac::ReadStatusIO1()
{
	m_lStatusIO1 = 0;
	m_lStatusIO1 += (m_NewStatus1.m_bStartLamp)						? 0x0001 : 0x0000;
	m_lStatusIO1 += (m_NewStatus1.m_bStopLamp)						? 0x0002 : 0x0000;
	m_lStatusIO1 += (m_NewStatus1.m_bResetLamp)						? 0x0004 : 0x0000;
	m_lStatusIO1 += (m_NewStatus1.m_bInitialLamp)					? 0x0008 : 0x0000;
	m_lStatusIO1 += (m_NewStatus1.m_bOPKeyboardLamp)				? 0x0010 : 0x0000;
	m_lStatusIO1 += (m_NewStatus1.m_bVIKeyboardLamp)				? 0x0020 : 0x0000;
	m_lStatusIO1 += (m_NewStatus1.m_bClampLamp)						? 0x0040 : 0x0000;
	m_lStatusIO1 += (m_NewStatus1.m_bUnclampLamp)					? 0x0080 : 0x0000;
	m_lStatusIO1 += (m_NewStatus1.m_bMpgLed)						? 0x0100 : 0x0000;
	m_lStatusIO1 += (m_NewStatus1.m_bClampOpenClose)				? 0x0200 : 0x0000;
	m_lStatusIO1 += (m_NewStatus1.m_bOPDoorOpenClose)				? 0x0400 : 0x0000;
	m_lStatusIO1 += (m_NewStatus1.m_bOPSlideExtRet)					? 0x0800 : 0x0000;
	m_lStatusIO1 += (m_NewStatus1.m_bVIDoorOpenClose)				? 0x1000 : 0x0000;
	m_lStatusIO1 += (m_NewStatus1.m_bVISlideExtRet)					? 0x2000 : 0x0000;
	m_lStatusIO1 += (m_NewStatus1.m_bAirBlowSol)					? 0x4000 : 0x0000;
//	m_lStatusIO1 += (m_NewStatus1.m_bSpare61000)					? 0x8000 : 0x0000;
}

void DevicePMac::ReadStatusIO2()
{
	m_lStatusIO2 = 0;
	m_lStatusIO2 += (m_NewStatus1.m_bMarkStart)						? 0x0001 : 0x0000;
	m_lStatusIO2 += (m_NewStatus1.m_bHandlerReady1)					? 0x0002 : 0x0000;
	m_lStatusIO2 += (m_NewStatus1.m_bHandlerError1)					? 0x0004 : 0x0000;
//	m_lStatusIO2 += (m_NewStatus1.m_bSpare61001_3)					? 0x0008 : 0x0000;
//	m_lStatusIO2 += (m_NewStatus1.m_bSpare61001_3)					? 0x0010 : 0x0000;
//	m_lStatusIO2 += (m_NewStatus1.m_bSpare61001_3)					? 0x0020 : 0x0000;
	m_lStatusIO2 += (m_NewStatus1.m_bHandlerReady2)					? 0x0040 : 0x0000;
	m_lStatusIO2 += (m_NewStatus1.m_bHandlerError2)					? 0x0080 : 0x0000;
	m_lStatusIO2 += (m_NewStatus1.m_bVisionStart1)					? 0x0100 : 0x0000;
	m_lStatusIO2 += (m_NewStatus1.m_bVisionStart2)					? 0x0200 : 0x0000;
	m_lStatusIO2 += (m_NewStatus1.m_bVisionStart3)					? 0x0400 : 0x0000;
	m_lStatusIO2 += (m_NewStatus1.m_bVisionStart4)					? 0x0800 : 0x0000;
//	m_lStatusIO2 += (m_NewStatus1.m_bSpare61001)					? 0x1000 : 0x0000;
//	m_lStatusIO2 += (m_NewStatus1.m_bSpare61001)					? 0x2000 : 0x0000;
//	m_lStatusIO2 += (m_NewStatus1.m_bSpare61001)					? 0x4000 : 0x0000;
//	m_lStatusIO2 += (m_NewStatus1.m_bSpare61001)					? 0x8000 : 0x0000;
}

void DevicePMac::ReadStatusIO3()
{
	m_lStatusIO3 = 0;
//	m_lStatusIO3 += (m_NewStatus2.m_bSpare60EFE_0)					? 0x0001 : 0x0000;
	m_lStatusIO3 += (m_NewStatus2.m_bXStop)							? 0x0002 : 0x0000;
	m_lStatusIO3 += (m_NewStatus2.m_bYStop)							? 0x0004 : 0x0000;
	m_lStatusIO3 += (m_NewStatus2.m_bCStop)							? 0x0008 : 0x0000;
	m_lStatusIO3 += (m_NewStatus2.m_bZStop)							? 0x0010 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus2.m_bSpare60EFE)					? 0x0020 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus2.m_bSpare60EFE)					? 0x0040 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus2.m_bSpare60EFE)					? 0x0080 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus2.m_bSpare60EFE)					? 0x0100 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus2.m_bSpare60EFE)					? 0x0200 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus2.m_bSpare60EFE)					? 0x0400 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus2.m_bSpare60EFE)					? 0x0800 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus2.m_bSpare60EFE)					? 0x1000 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus2.m_bSpare60EFE)					? 0x2000 : 0x0000;
//	m_lStatusIO3 += (m_NewStatus2.m_bSpare60EFE)					? 0x4000 : 0x0000;
}

void DevicePMac::ReadStatusIO4()
{
	m_lStatusIO4 = 0;
	m_lStatusIO4 += (m_NewStatus2.m_bSystemInitial)					? 0x0001 : 0x0000;
	m_lStatusIO4 += (m_NewStatus2.m_bXinitial)						? 0x0002 : 0x0000;
	m_lStatusIO4 += (m_NewStatus2.m_bYinitial)						? 0x0004 : 0x0000;
	m_lStatusIO4 += (m_NewStatus2.m_bCinitial)						? 0x0008 : 0x0000;
	m_lStatusIO4 += (m_NewStatus2.m_bZinitial)						? 0x0010 : 0x0000;
//	m_lStatusIO4 += (m_NewStatus2.m_bSpare60EFF_5)					? 0x0020 : 0x0000;
//	m_lStatusIO4 += (m_NewStatus2.m_bSpare60EFF_6)					? 0x0040 : 0x0000;
	m_lStatusIO4 += (m_NewStatus2.m_bLogicError)					? 0x0080 : 0x0000;
	m_lStatusIO4 += (m_NewStatus2.m_bHandlerAlarm)					? 0x0100 : 0x0000;
	m_lStatusIO4 += (m_NewStatus2.m_bPlcReady)						? 0x0200 : 0x0000;
	m_lStatusIO4 += (m_NewStatus2.m_bMPGreset)						? 0x0400 : 0x0000;
	m_lStatusIO4 += (m_NewStatus2.m_bAutoStart)						? 0x0800 : 0x0000;
	m_lStatusIO4 += (m_NewStatus2.m_bAutoStop)						? 0x1000 : 0x0000;
	m_lStatusIO4 += (m_NewStatus2.m_bErrorReset)					? 0x2000 : 0x0000;
//	m_lStatusIO4 += (m_NewStatus2.m_bSpare60EFF)					? 0x4000 : 0x0000;
}

BOOL DevicePMac::PeekMessage()
{
	MSG msg;
	if(::PeekMessage((LPMSG)&msg,(HWND)NULL,(WORD)NULL,(WORD)NULL,PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
		return TRUE;
	}
	return FALSE;
}

BOOL DevicePMac::IsMoveEnd(int nAxis)
{
	if(nAxis == -1) // all axis
	{
		if(fabs(m_dWritePos[AXIS_X] - m_dActualPosX) > 0.002)	
		{
			m_nInPositionError = 1;
			return FALSE;
		}
		if(fabs(m_dWritePos[AXIS_Y] - m_dActualPosY) > 0.002)	
		{
			m_nInPositionError = 2;
			return FALSE;
		}
		if(fabs(m_dWritePos[AXIS_Z1] - m_dActualPosZ) > 0.002)	
		{
			m_nInPositionError = 3;
			return FALSE;
		}
		
		return m_bCommandStop;
	}
	else
	{
		switch(nAxis)
		{
		case AXIS_X:
			if(fabs(m_dWritePos[AXIS_X] - m_dActualPosX) < 0.003)
				return TRUE;
			break;
		case AXIS_Y:
			if(fabs(m_dWritePos[AXIS_Y] - m_dActualPosY) < 0.003)
			return TRUE;
			break;
		case AXIS_Z1:
			if(fabs(m_dWritePos[AXIS_Z1] - m_dActualPosZ) < 0.003)
			return TRUE;
			break;
		default:
			return TRUE;
		}
		m_nInPositionError = nAxis + 1;
	}
	return FALSE;
}

BOOL DevicePMac::IsInPositionThread(int nAxis, BYTE nCommand)
{
	CString strLog;
	
	if(IsMoveEnd(nAxis))
		return TRUE;
	
	if(m_thdInPosition != NULL && m_nInPositionCount <= 0)
	{
		m_pStopTime.Pause();
		m_pStopTime.StartTime();
		
		m_nIsInPosition = FALSE;
		m_nInPositionCommand= nCommand;
		m_nInPositionCount = m_thdInPosition->ResumeThread();
		do
		{
			PeekMessage();
#ifndef __TEST__
			Sleep(TIME_STATUS);
#endif
			if(m_nIsInPosition != FALSE)
			{
				m_nInPositionCount = m_thdInPosition->SuspendThread();
				break;
			}
		} while (!m_bPositionStop);
		
		// by HJ.Cho 2003. 3. 29
		if (m_nIsInPosition == -1)
		{
			switch(m_nInPositionError)
			{
			case 1:
				ErrMsgDlg(STDGNALM404);
				break;
			case 2:
				ErrMsgDlg(STDGNALM405);
				break;
			case 3:
				ErrMsgDlg(STDGNALM406);
				break;
			}
		}
		else if (m_nIsInPosition == -2)
			ErrMessage(_T("Socket time error !!!"));
		else if (m_nIsInPosition == -3)
			m_nIsInPosition = TRUE;
		
		return m_nIsInPosition;
	}
	return FALSE;
}

void DevicePMac::ReadPosition()
{
	double xx;
	CString str;
	char buf[255];
	memset(buf, 0, 255);

	char val[255]={0};
	sprintf_s(val, 255, _T("#1p"));
	MotionControlDLL_DownloadPVar2(buf, val);
	xx=atol(buf);
	str.Format(_T("%3.3f"),xx/ScaleX);
	m_dActualPosX = atof(str);
	
	sprintf_s(val, 255, _T("#2p"));
	MotionControlDLL_DownloadPVar2(buf, val);
	xx=atol(buf);
	str.Format(_T("%3.3f"),xx/ScaleY);
	m_dActualPosY = atof(str);

	// ���� Toshiba����
	sprintf_s(val, 255, _T("#3p"));
	
	// ���� WaferDriller��
//	sprintf_s(val, 255, _T("#9p"));

	MotionControlDLL_DownloadPVar2(buf, val);
	xx=atol(buf);
	str.Format(_T("%3.3f"),xx/ScaleZ);
	m_dActualPosZ = atof(str);

	m_nInPositionError = 0;
	
	if(m_dActualPosX != m_dWritePos[AXIS_X]) // x command pos , real encoder pos
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 1;
		return;
	}
	if(m_dActualPosY != m_dWritePos[AXIS_Y]) // y
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 2;
		return;
	}
	
	if(m_dActualPosZ != m_dWritePos[AXIS_Z1]) // z
	{
		m_bCommandStop = FALSE;
		m_nInPositionError = 3;
		return;
	}
	
	m_bCommandStop = TRUE;
}

int DevicePMac::IsInPosition(int nAxis, BOOL bWait/*TRUE*/)
{
	if(bWait)
	{
		m_nInPositionAxis = nAxis;
		return IsInPositionThread(nAxis, COMMAND_INPOSITION);
	}
	return IsMoveEnd(nAxis);
}

BOOL DevicePMac::InPositionIO(int nAxis)
{
	double xx;
	CString str;
	char buf[255];
	memset(buf, 0, 255);
	
	char val[255]={0};
	sprintf_s(val, 255, _T("#1p"));
	MotionControlDLL_DownloadPVar2(buf, val);
	xx=atol(buf);
	str.Format(_T("%3.3f"),xx/ScaleX);
	m_dActualPosX = atof(str);
	
	sprintf_s(val, 255, _T("#2p"));
	MotionControlDLL_DownloadPVar2(buf, val);
	xx=atol(buf);
	str.Format(_T("%3.3f"),xx/ScaleY);
	m_dActualPosY = atof(str);
	
	// ���� Toshiba����
	sprintf_s(val, 255, _T("#3p"));

	// ���� WaferDriller��
//	sprintf_s(val, 255, _T("#9p"));

	MotionControlDLL_DownloadPVar2(buf, val);
	xx=atol(buf);
	str.Format(_T("%3.3f"),xx/ScaleZ);
	m_dActualPosZ = atof(str);
	
	if(nAxis & 0x0001)
	{
		if(fabs(m_dActualPosX - m_dWritePos[AXIS_X])>0.002) // x command pos , real encoder pos
			return FALSE;
	}
	
	if(nAxis >> 1 & 0x0001)
	{
		if(fabs(m_dActualPosY - m_dWritePos[AXIS_Y])>0.002) // y
			return FALSE;
	}
	
	if(nAxis >> 2 & 0x0001)
	{
		if(fabs(m_dActualPosZ - m_dWritePos[AXIS_Z1])>0.002) // z
			return FALSE;
	}
	
	return TRUE;
}

BOOL DevicePMac::GetPosition(int nAxis, double &dPosition) // real position
{
	if(nAxis == AXIS_X)
		dPosition = m_dActualPosX;// / ScaleX;
	else if(nAxis == AXIS_Y)
		dPosition = m_dActualPosY;// / ScaleY;
	else if(nAxis == AXIS_Z1)
		dPosition = m_dActualPosZ;// / ScaleZ;
	else 
	{
		dPosition = 0.;
		return FALSE;
	}
	
	return TRUE;
}

BOOL DevicePMac::MotorMoveAxis(int nAxis, double dPosition)
{
	m_dWritePos[nAxis] = dPosition;

	char buf[255];
	memset(buf, 0, 255);

	char val[255]={0};

	if(nAxis == AXIS_X)
		sprintf_s(val, 255, _T("#1J=%lf"), dPosition*ScaleX);
	else if(nAxis == AXIS_Y)
		sprintf_s(val, 255, _T("#2J=%lf"), dPosition*ScaleY);
	else if(nAxis == AXIS_Z1)
		// ���� Toshiba����
		sprintf_s(val, 255, _T("#3J=%lf"), dPosition*ScaleZ);
		// ���� WaferDriller��
	//	sprintf_s(val, 255, _T("#9J=%lf"), dPosition*ScaleZ);

	return MotionControlDLL_DownloadPVar2(buf, val);
}

BOOL DevicePMac::MotorMoveXY(double dPosX, double dPosY)
{
	m_dWritePos[AXIS_X] = dPosX;
	m_dWritePos[AXIS_Y] = dPosY;

	char buf[255];
	memset(buf, 0, 255);

	BOOL bResult = TRUE;

	char val[255]={0};
	sprintf_s(val, 255, _T("#1J=%lf"), dPosX*ScaleX);
	bResult = bResult & MotionControlDLL_DownloadPVar2(buf, val);

	sprintf_s(val, 255, _T("#2J=%lf"), dPosY*ScaleY);
	bResult = bResult & MotionControlDLL_DownloadPVar2(buf, val);

	return bResult;
}

BOOL DevicePMac::MotorMoveZ(double dPosZ)
{
	m_dWritePos[AXIS_Z1] = dPosZ;

	char buf[255];
	memset(buf, 0, 255);

	BOOL bResult = TRUE;
	
	char val[255]={0};
	// ���� Toshiba����
	sprintf_s(val, 255, _T("#3J=%lf"), dPosZ*ScaleZ);
	// ���� WaferDriller��
//	sprintf_s(val, 255, _T("#9J=%lf"), dPosZ*ScaleZ);
	bResult = bResult & MotionControlDLL_DownloadPVar2(buf, val);
	
	return bResult;
}

BOOL DevicePMac::MotorMoveXYZ(double dPosX, double dPosY, double dPosZ)
{
	m_dWritePos[AXIS_X] = dPosX;
	m_dWritePos[AXIS_Y] = dPosY;
	m_dWritePos[AXIS_Z1] = dPosZ;

	char buf[255];
	memset(buf, 0, 255);

	BOOL bResult = TRUE;
	
	char val[255]={0};
	sprintf_s(val, 255, _T("#1J=%lf"), dPosX*ScaleX);
	bResult = bResult & MotionControlDLL_DownloadPVar2(buf, val);
	
	sprintf_s(val, 255, _T("#2J=%lf"), dPosY*ScaleY);
	bResult = bResult & MotionControlDLL_DownloadPVar2(buf, val);

	// ���� Toshiba����
	sprintf_s(val, 255, _T("#3J=%lf"), dPosZ*ScaleZ);
	// ���� WaferDriller��
//	sprintf_s(val, 255, _T("#9J=%lf"), dPosZ*ScaleZ);

	bResult = bResult & MotionControlDLL_DownloadPVar2(buf, val);
	
	return bResult;
}

BOOL DevicePMac::SetOutPort(BYTE nPortNo, WORD wOnOff)
{
	// ���� WaferDriller��
	//	return TRUE;

	BOOL bResult = TRUE;
	if(nPortNo == PORT_TABLE_SUCTION1)
	{
		char szBuf[255]={0};
		char buf[255];
		memset(buf, 0, 255);

		if(wOnOff == 0)
		{
			sprintf_s(szBuf, 255, _T("m6013=101"));
			MotionControlDLL_DownloadPVar2(buf, szBuf);
			sprintf_s(szBuf, 255, _T("m6012=1"));
			MotionControlDLL_DownloadPVar2(buf, szBuf);
		}
		else
		{
			sprintf_s(szBuf, 255, _T("m6013=100"));
			MotionControlDLL_DownloadPVar2(buf, szBuf);
			sprintf_s(szBuf, 255, _T("m6012=1"));
			MotionControlDLL_DownloadPVar2(buf, szBuf);
		}
		return bResult;
	}
	return 0;
}

BOOL DevicePMac::SetSpeed(int nAxis, long lSpeed)
{
	char szBuf[255]={0};
	char buf[255];
	memset(buf, 0, 255);
	
	// ���� Toshiba����
	if(nAxis == AXIS_X)
	{
		sprintf_s(szBuf, 255, _T("I122=%d"), lSpeed*10);
		MotionControlDLL_DownloadPVar2(buf, szBuf);
	}
	else if(nAxis == AXIS_Y)
	{
		sprintf_s(szBuf, 255, _T("I222=%d"), lSpeed*10);
		MotionControlDLL_DownloadPVar2(buf, szBuf);
	}
	else if(nAxis == AXIS_Z1)
	{
		sprintf_s(szBuf, 255, _T("I322=%d"), lSpeed*10);
		MotionControlDLL_DownloadPVar2(buf, szBuf);
	}
	else
		return TRUE;

/*
	// ���� WaferDriller��
	if(nAxis == AXIS_X)
	{
		sprintf_s(szBuf, 255, _T("I122=%d"), lSpeed*10);
		MotionControlDLL_DownloadPVar2(buf, szBuf);
	}
	else if(nAxis == AXIS_Y)
	{
		sprintf_s(szBuf, 255, _T("I222=%d"), lSpeed*10);
		MotionControlDLL_DownloadPVar2(buf, szBuf);
	}
	else if(nAxis == AXIS_Z1)
	{
		sprintf_s(szBuf, 255, _T("I322=%d"), lSpeed*10);
		MotionControlDLL_DownloadPVar2(buf, szBuf);
	}
	else if(nAxis == AXIS_Z2)
	{
		sprintf_s(szBuf, 255, _T("I422=%d"), lSpeed*10);
		MotionControlDLL_DownloadPVar2(buf, szBuf);
	}
	else
		return TRUE;
*/
	return TRUE;
}
// FParameter.h: unsigned shorterface for the FParameter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FPARAMETER_H__5127564F_46D7_11D3_9F63_004F49089C0D__INCLUDED_)
#define AFX_FPARAMETER_H__5127564F_46D7_11D3_9F63_004F49089C0D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "stdafx.h"

#define MAXSHOTCNT				16
#define HALF_LSB				32767


typedef struct {
	unsigned int	nToolNo;
	unsigned int	nFreq;
	double			dDuty[MAXSHOTCNT];	// %
	unsigned int	nUseDutyNo;
	
	unsigned int	nBurstShot;
	unsigned int	nTotalShot;
	BOOL			bUseAperture;
} TCODE_INFO;

class FParameter
{
public:
	unsigned short DrawStep ;
	unsigned short JumpStep ;
	unsigned short StepPeriod ;
	unsigned short CornerDelay ;
	unsigned short JumpDelay ;
	unsigned short LineDelay ;
	unsigned Frequency ;
	double		   dDuty ;
	unsigned short LaserOnDelay ;
	unsigned short LaserOffDelay ;
	unsigned short LampCurrent ;
	unsigned short PowerChangeDelay ;
	double		   dAOMDelay ;
	double		   dAOMDuty ;
	char		   cAOMFilePath[255];
	unsigned short BreakAngle ;
	unsigned short AutoSegmentation ;
	unsigned short CycleTime ; // yhchung 070214 add
	unsigned short FPSDelay ;

	unsigned short DrawStepPeriod;
	unsigned short MinShotTime;

public:
	void Copy( FParameter *ptr );
	void Reset( void );
	FParameter();
	virtual ~FParameter();
};

#endif // !defined(AFX_FPARAMETER_H__5127564F_46D7_11D3_9F63_004F49089C0D__INCLUDED_)

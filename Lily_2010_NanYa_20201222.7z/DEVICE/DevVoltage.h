#pragma once

#include "..\AccuraClient.h"
enum VOL_TYPE {TYPE_A, TYPE_B, TYPE_C};
class CDevVoltage
{
public:
	CDevVoltage(void);
	virtual ~CDevVoltage(void);

	BOOL Connect();
	void SetSubCount(int nCount);
	void ReadSubData(int nIndex);
	void ReadVoltage();
	void GetVoltage(double& dV, double& dA, double& dWh);
	double GetSubData(int nIndex);
	float ToFloat(unsigned short* buffer, int index);
	int ToInt32(unsigned short* buffer, int index);
	double ToDouble(unsigned short* buffer, int index);
	BOOL IsConnected();
	BOOL ValidSubData(short cCheck);


	int m_nType; 
	int m_nSubDataCount;
	double m_dV[3];
	double m_dA[3];
	double m_dkW[3];
	double m_dDeviceValue[60];
	double m_dSubData[20];
	BOOL m_bConnect;
	AccuraClients* m_pAccuraClient;
	AccuraModbusTcpClient * m_pAccuraModBus;
	ModbusTcpClient* m_pModBus;
};


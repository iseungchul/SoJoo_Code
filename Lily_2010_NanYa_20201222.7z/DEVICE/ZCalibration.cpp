// ZCalibration.cpp: implementation of the CZCalibration class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ZCalibration.h"
#include "..\EasyDriller.h"
#include "..\resource.h"

const char	WHOLE_Z_CALIBRATION_FILE1[] = _T("z.calibration");
const char	WHOLE_Z_CALIBRATION_FILE2[] = _T("z2.calibration");
#define BUF_SIZE	1024
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CZCalibration::CZCalibration()
{
	Clear();
}

CZCalibration::~CZCalibration()
{
	if(m_Offset)
	{
		delete [] m_Offset;
		m_Offset = NULL;
	}
}

void CZCalibration::Clear()
{
	m_bIsSet = FALSE;
	m_bFirst = TRUE;
	m_nGridX = 0;
	m_nGridY = 0;
	m_dGap = 0.0;
	m_dXStart = 0.0;
	m_dXEnd = 0.0;
	m_dYStart = 0.0;
	m_dYEnd = 0.0;
	
	m_Offset = NULL;
}

void CZCalibration::GetCalibrationOffset(double dX, double dY, double& dOffset)
{
	if(m_bIsSet)
		GetPartialCalibrationOffset(dX, dY, dOffset);
	else
		dOffset = 0.;
}

void CZCalibration::GetPartialCalibrationOffset(double dX, double dY, double& dOffset)
{
	if (IsPartialInside(dX, dY))
	{
		// index = m_nGridY * nX + nY
		int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
		int nY = static_cast<int>((dY - m_dYStart) / m_dGap);

		double dXDist = dX - m_dXStart - m_dGap * nX;
		double dYDist = dY - m_dYStart - m_dGap * nY;

		double ax, bx;

		if (nX == m_nGridX - 1)
			ax = m_Offset[m_nGridY * nX + nY].x;
		else
			ax = m_Offset[m_nGridY * nX + nY].x + (m_Offset[m_nGridY * (nX + 1) + nY].x - m_Offset[m_nGridY * nX + nY].x) * dXDist / m_dGap;

		if (nY == m_nGridY - 1)
			bx = ax;
		else if (nX == m_nGridX - 1 && nY != m_nGridY - 1)
			bx = m_Offset[m_nGridY * nX + nY + 1].x;
		else
			bx = m_Offset[m_nGridY * nX + nY + 1].x + (m_Offset[m_nGridY * (nX + 1) + nY + 1].x - m_Offset[m_nGridY * nX + nY + 1].x) * dXDist / m_dGap;

		dOffset = ax + (bx - ax) * dYDist / m_dGap;
	}
	else if (IsInside(dX, dY))
	{
		if (m_dXStart < MIN_TABLE || m_dXEnd > MAX_TABLE || m_dYStart < MIN_TABLE || m_dYEnd > MAX_TABLE)
		{
			dOffset = 0.0;
			return;
		}

		if (dX < m_dXStart && dY < m_dYStart)
		{
			dOffset = m_Offset[0].x;
		}
		else if (dX >= m_dXStart && dX <= m_dXEnd && dY < m_dYStart)
		{
			// index = m_nGridY * nX + nY
			int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
			int nY = 0;
			
			double dXDist = dX - m_dXStart - m_dGap * nX;
			double dYDist = dY;
			
			if (nX == m_nGridX - 1)
				dOffset = m_Offset[m_nGridY * nX].x;
			else
				dOffset = m_Offset[m_nGridY * nX].x + (m_Offset[m_nGridY * (nX + 1)].x - m_Offset[m_nGridY * nX].x) * dXDist / m_dGap;
			
		}
		else if (dX > m_dXEnd && dY < m_dYStart)
		{
			dOffset = m_Offset[m_nGridY * (m_nGridX - 1) + 0].x;
		}
		else if (dX < m_dXStart && dY >= m_dYStart && dY <= m_dYEnd)
		{
			// index = m_nGridY * nX + nY
			int nX = 0;
			int nY = static_cast<int>((dY - m_dYStart) / m_dGap);
			
			double dXDist = dX;
			double dYDist = dY - m_dYStart - m_dGap * nY;
			
			double ax = m_Offset[nY].x;
			if (nY == m_nGridY - 1)
				dOffset = m_Offset[nY].x;
			else
				dOffset = m_Offset[nY].x + (m_Offset[nY + 1].x - m_Offset[nY].x) * dYDist / m_dGap;
		}
		else if (dX > m_dXEnd && dY >= m_dYStart && dY <= m_dYEnd)
		{
			// index = m_nGridY * nX + nY
			int nX = m_nGridX - 1;
			int nY = static_cast<int>((dY - m_dYStart) / m_dGap);
			
			double dXDist = dX - m_dXEnd;
			double dYDist = dY - m_dYStart - m_dGap * nY;
			
			if (nY == m_nGridY - 1)
				dOffset = m_Offset[m_nGridY * nX + nY].x;
			else
				dOffset = m_Offset[m_nGridY * nX + nY].x + (m_Offset[m_nGridY * nX + nY + 1].x - m_Offset[m_nGridY * nX + nY].x) * dYDist / m_dGap;

		}
		else if (dX < m_dXStart && dY > m_dYEnd)
		{
			dOffset = m_Offset[m_nGridY * 0 + m_nGridY - 1].x;
		}
		else if (dX >= m_dXStart && dX <= m_dXEnd && dY > m_dYEnd)
		{
			// index = m_nGridY * nX + nY
			int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
			int nY = m_nGridY - 1;
			
			double dXDist = dX - m_dXStart - m_dGap * nX;
			double dYDist = dY - m_dYEnd;
			
			if (nX == m_nGridX - 1)
				dOffset = m_Offset[m_nGridY * nX + nY].x;
			else
				dOffset = m_Offset[m_nGridY * nX + nY].x + (m_Offset[m_nGridY * (nX + 1) + nY].x - m_Offset[m_nGridY * nX + nY].x) * dXDist / m_dGap;
		}
		else if (dX > m_dXEnd && dY > m_dYEnd)
		{
			dOffset = m_Offset[m_nGridY * (m_nGridX - 1) + m_nGridY - 1].x;
		}
		else
			dOffset= 0.0;
	}
	else
		dOffset = 0.0;
}

/*
void CZCalibration::GetPartialCalibrationOffset(double dX, double dY, double& dOffset)
{
	if (IsPartialInside(dX, dY))
	{
		// index = m_nGridY * nX + nY
		int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
		int nY = static_cast<int>((dY - m_dYStart) / m_dGap);

		double dXDist = dX - m_dXStart - m_dGap * nX;
		double dYDist = dY - m_dYStart - m_dGap * nY;

		double ax, bx;

		if (nX == m_nGridX - 1)
			ax = m_Offset[m_nGridY * nX + nY].x;
		else
			ax = m_Offset[m_nGridY * nX + nY].x + (m_Offset[m_nGridY * (nX + 1) + nY].x - m_Offset[m_nGridY * nX + nY].x) * dXDist / m_dGap;

		if (nY == m_nGridY - 1)
			bx = ax;
		else if (nX == m_nGridX - 1 && nY != m_nGridY - 1)
			bx = m_Offset[m_nGridY * nX + nY + 1].x;
		else
			bx = m_Offset[m_nGridY * nX + nY + 1].x + (m_Offset[m_nGridY * (nX + 1) + nY + 1].x - m_Offset[m_nGridY * nX + nY + 1].x) * dXDist / m_dGap;

		dOffset = ax + (bx - ax) * dYDist / m_dGap;
	}
	else if (IsInside(dX, dY))
	{
		if (m_dXStart < MIN_TABLE || m_dXEnd > MAX_TABLE || m_dYStart < MIN_TABLE || m_dYEnd > MAX_TABLE)
		{
			dOffset = 0.0;
			return;
		}

		if (dX < m_dXStart && dY < m_dYStart)
		{
			double dXDist = dX;
			double dYDist = dY;

			double ax = 0.0;
			double bx = m_Offset[m_nGridY * 0 + 0].x * dXDist / m_dXStart;

			dOffset = ax + (bx - ax) * dYDist / m_dYStart;
		}
		else if (dX >= m_dXStart && dX <= m_dXEnd && dY < m_dYStart)
		{
			// index = m_nGridY * nX + nY
			int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
			int nY = 0;
			
			double dXDist = dX - m_dXStart - m_dGap * nX;
			double dYDist = dY;
			
			double ax = 0.0, bx;
			if (nX == m_nGridX - 1)
				bx = m_Offset[m_nGridY * nX + nY].x;
			else
				bx = m_Offset[m_nGridY * nX + nY].x + (m_Offset[m_nGridY * (nX + 1) + nY].x - m_Offset[m_nGridY * nX + nY].x) * dXDist / m_dGap;
			
			dOffset = ax + (bx - ax) * dYDist / m_dYStart;
		}
		else if (dX > m_dXEnd && dY < m_dYStart)
		{
			double dXDist = dX - m_dXEnd;
			double dYDist = dY;
			
			double ax = 0.0;
			double bx = m_Offset[m_nGridY * (m_nGridX - 1) + 0].x - m_Offset[m_nGridY * (m_nGridX - 1) + 0].x * dXDist / (MAX_TABLE - m_dXEnd);
			
			dOffset = ax + (bx - ax) * dYDist / m_dYStart;
		}
		else if (dX < m_dXStart && dY >= m_dYStart && dY <= m_dYEnd)
		{
			// index = m_nGridY * nX + nY
			int nX = 0;
			int nY = static_cast<int>((dY - m_dYStart) / m_dGap);
			
			double dXDist = dX;
			double dYDist = dY - m_dYStart - m_dGap * nY;
			
			double ax = m_Offset[m_nGridY * nX + nY].x * dXDist / m_dXStart, bx;
			if (nY == m_nGridY - 1)
				bx = ax;
			else
				bx = m_Offset[m_nGridY * nX + nY + 1].x * dXDist / m_dXStart;
	
			dOffset = ax + (bx - ax) * dYDist / m_dGap;
		}
		else if (dX > m_dXEnd && dY >= m_dYStart && dY <= m_dYEnd)
		{
			// index = m_nGridY * nX + nY
			int nX = m_nGridX - 1;
			int nY = static_cast<int>((dY - m_dYStart) / m_dGap);
			
			double dXDist = dX - m_dXEnd;
			double dYDist = dY - m_dYStart - m_dGap * nY;
			
			double ax = m_Offset[m_nGridY * nX + nY].x - m_Offset[m_nGridY * nX + nY].x * dXDist / (MAX_TABLE - m_dXEnd), bx;
			if (nY == m_nGridY - 1)
				bx = ax;
			else
				bx = m_Offset[m_nGridY * nX + nY + 1].x - m_Offset[m_nGridY * nX + nY + 1].x * dXDist / (MAX_TABLE - m_dXEnd);
			
			dOffset = ax + (bx - ax) * dYDist / m_dGap;
		}
		else if (dX < m_dXStart && dY > m_dYEnd)
		{
			double dXDist = dX;
			double dYDist = dY - m_dYEnd;
			
			double ax = m_Offset[m_nGridY * 0 + m_nGridY - 1].x * dXDist / m_dXStart;
			double bx = 0.0;
		
			dOffset = ax + (bx - ax) * dYDist / (MAX_TABLE - m_dYEnd);
		}
		else if (dX >= m_dXStart && dX <= m_dXEnd && dY > m_dYEnd)
		{
			// index = m_nGridY * nX + nY
			int nX = static_cast<int>((dX - m_dXStart) / m_dGap);
			int nY = m_nGridY - 1;
			
			double dXDist = dX - m_dXStart - m_dGap * nX;
			double dYDist = dY - m_dYEnd;
			
			double ax;
			if (nX == m_nGridX - 1)
				ax = m_Offset[m_nGridY * nX + nY].x;
			else
				ax = m_Offset[m_nGridY * nX + nY].x + (m_Offset[m_nGridY * (nX + 1) + nY].x - m_Offset[m_nGridY * nX + nY].x) * dXDist / m_dGap;
			double bx = 0.0;
			
			dOffset = ax + (bx - ax) * dYDist / (MAX_TABLE - m_dYEnd);
		}
		else if (dX > m_dXEnd && dY > m_dYEnd)
		{
			double dXDist = dX - m_dXEnd;
			double dYDist = dY - m_dYEnd;
			
			double ax = m_Offset[m_nGridY * (m_nGridX - 1) + m_nGridY - 1].x - m_Offset[m_nGridY * (m_nGridX - 1) + m_nGridY - 1].x * dXDist / (MAX_TABLE - m_dXEnd);
			double bx = 0.0;
			
			dOffset = ax + (bx - ax) * dYDist / (MAX_TABLE - m_dYEnd);
		}
		else
			dOffset= 0.0;
	}
	else
		dOffset = 0.0;
}
*/

BOOL CZCalibration::IsPartialInside(double dX, double dY)
{
	if (dX >= m_dXStart && dX <= m_dXEnd && dY >= m_dYStart && dY <= m_dYEnd)
		return TRUE;
	else
		return FALSE;
}

BOOL CZCalibration::IsInside(double dX, double dY)
{
	if (dX >= MIN_TABLE && dX <= MAX_TABLE && dY >= MIN_TABLE && dY <= MAX_TABLE)
		return TRUE;
	else
		return FALSE;
}

BOOL CZCalibration::LoadCalibration(CString strPath, BOOL bFirst)
{
	if (m_bFirst)
	{
		m_strPath = strPath;
		m_bFirst = FALSE;
	}
	
	CALHEAD calHead;

	TCHAR szSeps[] = _T(" \t\r\n");
	TCHAR *szNext;
	TCHAR szBuf[BUF_SIZE], *token = NULL;
	FILE* fp = NULL;

	CString strFileName;

	if(bFirst)
		strFileName.Format(_T("%s%s"), strPath , WHOLE_Z_CALIBRATION_FILE1);
	else
		strFileName.Format(_T("%s%s"), strPath , WHOLE_Z_CALIBRATION_FILE2);
	
	if (NULL == fopen_s(&fp, strFileName, _T("rb")))
	{
		if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
		{
			fclose(fp);
			return FALSE;
		}

		if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
		{
			fclose(fp);
			return FALSE;
		}
		int nTemp = atoi(token);
		if (nTemp < 2)
		{
			fclose(fp);
			return FALSE;
		}

		calHead.nGridX = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
		{
			fclose(fp);
			return FALSE;
		}

		nTemp = atoi(token);
		if (nTemp < 2)
		{
			fclose(fp);
			return FALSE;
		}

		calHead.nGridY = nTemp;

		if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
		{
			fclose(fp);
			return FALSE;
		}

		double dSize = atof(token);
		if (dSize < 1.0 || dSize > 1000.0)
		{
			fclose(fp);
			return FALSE;
		}

		calHead.dGap = dSize;

		DPOINT* dpOffset = NULL;
		TRY
		{
			dpOffset = new DPOINT[calHead.nGridX * calHead.nGridY];
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();

			fclose(fp);
			return FALSE;
		}
		END_CATCH

		double dX = 0.0, dXPos = 0.0, dYPos = 0.0, dXPosMin = 1000.0, dYPosMin = 1000.0;
		for (int i = 0; i < calHead.nGridX; i++)
		{
			for (int j = 0; j < calHead.nGridY; j++)
			{
				if (NULL == fgets(szBuf, BUF_SIZE - 1, fp))
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}

				if (NULL == (token = strtok_s(szBuf, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}
				dXPos = atof(token);

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}
				dYPos = atof(token);

#ifndef __TEST__ 
				if (dXPos < 0.0 || dXPos > 1000.0 || dYPos < 0.0 || dYPos > 1000.0)
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}
#endif

				if (dXPos < dXPosMin)	dXPosMin = dXPos;
				if (dYPos < dYPosMin)	dYPosMin = dYPos;

				if (NULL == (token = strtok_s(NULL, szSeps, &szNext)))
				{
					fclose(fp);
					delete [] dpOffset;
					return FALSE;
				}
				dX = atof(token);

				dpOffset[calHead.nGridY * i + j].x = dX;
				dpOffset[calHead.nGridY * i + j].y = 0;
			}
		}

		fclose(fp);

		calHead.dXStart = dXPosMin;
		calHead.dYStart = dYPosMin;
		calHead.dOffset = dpOffset;

		UpdateCalibration(calHead);
		delete [] dpOffset;
		return TRUE;
	}
	else
		return FALSE;
}

void CZCalibration::SaveCalibration(BOOL bFirst)
{
	FILE *fp = NULL;
	CString strFileName;
	if(bFirst)
		strFileName.Format(_T("%s%s"), m_strPath , WHOLE_Z_CALIBRATION_FILE1);
	else
		strFileName.Format(_T("%s%s"), m_strPath ,  WHOLE_Z_CALIBRATION_FILE2);

	if (NULL == fopen_s(&fp, strFileName, _T("w")))
	{
		fprintf(fp, _T("%d\t%d\t%f\n"), m_nGridX, m_nGridY, m_dGap);
		
		// index = GridSize * nX + nY
		for (int i = 0; i < m_nGridX; i++)
		{
			for (int j = 0; j < m_nGridY; j++)
			{
				fprintf(fp, _T("%lf\t%lf\t%lf\n"),
					m_dXEnd + (-m_nGridX + i + 1) * m_dGap,
					m_dYEnd + (-m_nGridY + j + 1) * m_dGap,
					m_Offset[i * m_nGridY + j].x);
			}
		}
		
		fclose(fp);
		return;
	}
	else
	{
		CString strString, strMsg;
		strString.LoadString(IDS_ERR_FILE_OPEN);
		strMsg.Format(strString, _T(""));
		ErrMessage(strMsg);
		return;
	}
}

void CZCalibration::SetMatrixToZero()
{
	m_nGridX = 2;
	m_nGridY = 2;
	m_dGap = 10;
	m_dXStart = 500;
	m_dXEnd = 510;
	m_dYStart = 500;
	m_dYEnd = 510;
	
	TRY
	{
		if(m_Offset)
		{
			delete [] m_Offset;
			m_Offset = NULL;
		}
		m_Offset = new DPOINT[m_nGridX * m_nGridY];
		m_Offset[0].x = 0.;
		m_Offset[0].y = 0.;
		m_Offset[1].x = 0.;
		m_Offset[1].y = 0.;
		m_Offset[2].x = 0.;
		m_Offset[2].y = 0.;
		m_Offset[3].x = 0.;
		m_Offset[3].y = 0.;

		m_bIsSet = TRUE;
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		
		Clear();
		return;
	}
	END_CATCH
}

void CZCalibration::UpdateCalibration(const CALHEAD& calHead)
{
	m_nGridX = calHead.nGridX;
	m_nGridY = calHead.nGridY;
	m_dGap = calHead.dGap;
	m_dXStart = calHead.dXStart;
	m_dXEnd = m_dXStart + m_dGap * (m_nGridX - 1);
	m_dYStart = calHead.dYStart;
	m_dYEnd = m_dYStart + m_dGap * (m_nGridY - 1);
	
	TRY
	{
		delete [] m_Offset;
		m_Offset = NULL;
		m_Offset = new DPOINT[m_nGridX * m_nGridY];
		memcpy(m_Offset, calHead.dOffset, sizeof(DPOINT) * m_nGridX * m_nGridY);
		m_bIsSet = TRUE;
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		
		Clear();
		return;
	}
	END_CATCH
}

void CZCalibration::LoadData(CString strPath, BOOL bFirst)
{
	if(!LoadCalibration(strPath, bFirst))
		SetMatrixToZero();
}

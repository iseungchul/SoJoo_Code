// PenFile.h: interface for the CPenFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PENFILE_H__4BF7F04B_6E25_497A_9FDC_CE58E6498483__INCLUDED_)
#define AFX_PENFILE_H__4BF7F04B_6E25_497A_9FDC_CE58E6498483__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPenFile  
{
public:
	CPenFile();
	virtual ~CPenFile();

	BOOL OpenPenFile(CString strFilePath, SPENDATA& sPenData);
	BOOL SavePenFile(CString strFilePath, SPENDATA sPenData);
};

#endif // !defined(AFX_PENFILE_H__4BF7F04B_6E25_497A_9FDC_CE58E6498483__INCLUDED_)

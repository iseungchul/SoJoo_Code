// GlobalVariable.cpp: implementation of the GlobalVariable class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "GlobalVariable.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\MODEL\DProcessINI.h"
#include "DShotTableINI.h"
#include "DBeampathINI.h"
#include "..\Device\Hdevicefactory.h"
#include "..\Device\DeviceMotor.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
GlobalVariable gVariable;

GlobalVariable::GlobalVariable()
{
	m_strPath.Format(_T(""));
	m_strPath2.Format(_T(""));
	memset( &m_sGlobal, 0, sizeof(m_sGlobal) );
	Initialize();
	m_bOpenProject = FALSE;
	m_bApplyScalFlag = FALSE;
	m_strBackupLaserComp = _T("");
	m_strBackupLaserSold = _T("");
	m_strBackupRecipeComp = _T("");
	m_strBackupRecipeSold = _T("");

	m_nGlobalDummyType = 0;
	m_bGrobalDutyOffsetCompenMode = TRUE;
	 m_dGlobalChillerTemp1 = 0;
	 m_dGlobalChillerTemp2 = 0;
	 m_dGlobalChillerFlow1 = 0;
	 m_dGlobalChillerFlow2 = 0;
	 m_dGlobalChillerPressure1 = 0;
	 m_dGlobalChillerPressure2 = 0;

	 m_nFireCountFor4Way = 0;

	 m_bDo4WayScal = FALSE;
	 InitVisionOffsetFor4Way();
	 InitCognixResult();
	 
	 m_bLPCRangeReset = FALSE;
	 m_bExsitPreLPCTable = FALSE;
	m_bMarkingCavity = FALSE;
	m_nShotNoForCavity = 0;
	m_bDoingPreHeat = FALSE;
	m_bShowBlockOnly = false;
	m_bShowNoBlockOnly = false;
	m_strProcessStatus = "";

	m_bShowSelectAreaOnly = false;
	m_nSelectArea = -1;
	m_nUseTable = USE_DUAL;
	m_nChangeDisplayLogMode = 1;
	m_bShowSelectFidBlockOnly = false;
	m_nSelectFidBlock = -1;

	m_bShowBlockNo = false;

	m_nMachineMode = 0;
	m_nMachineNo = 28;

	for(int i=0; i<2; i++)
	{
		m_dGlobal_FidScaleX[i] = 100;
		m_dGlobal_FidScaleY[i] = 100;
	}
}

GlobalVariable::~GlobalVariable()
{
//	SaveGlobalTool();
//	SaveRefuseList();

	for(int i=0; i<MAX_TOOL_NO; i++)
	{
		delete m_pToolCode[i];
		m_pToolCode[i] = NULL;
	}

	if(m_pRefuse != NULL)
	{
		delete m_pRefuse;
		m_pRefuse = NULL;
	}
}

void GlobalVariable::Initialize()
{
	for(int i=0; i< MAX_TOOL_NO; i++)
	{
		m_pToolCode[i] = new CToolCodeList;
		m_pToolCode[i]->Initialize();
		if(i < 1)
			m_pToolCode[i]->m_bUseTool = TRUE;
	}
//	LoadGlobalTool();
	
	m_pRefuse = new CRefuseList;
	m_pRefuse->Initialize();
}

BOOL GlobalVariable::SaveGlobalTool()
{
	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(m_strPath, CFile::modeWrite|CFile::modeCreate))
		{
			return FALSE;
		}
		CArchiveMark ar(&file, CArchive::store);
		Serialize(ar, 10033);
	}
	CATCH (CException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
	file.Close();
	return TRUE;
}

BOOL GlobalVariable::LoadGlobalTool()
{

	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(m_strPath, CFile::modeRead))
		{
			return FALSE;
		}
		
//		DWORD dwFileSize;
		if(file.GetLength() < 1)
		{
			file.Close();
			
			::DeleteFile(m_strPath);
			
			return FALSE;
		}

		CArchiveMark ar(&file, CArchive::load);
		Serialize(ar, 10033);
	}
	CATCH (CException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
	file.Close();
	return TRUE;
}

BOOL GlobalVariable::SaveRefuseList()
{
	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(m_strPath2, CFile::modeWrite|CFile::modeCreate))
		{
			return FALSE;
		}
		CArchiveMark ar(&file, CArchive::store);
		Serialize(ar, 10000, 1);
	}
	CATCH (CException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
	file.Close();
	return TRUE;
}

BOOL GlobalVariable::LoadRefuseList()
{
	CStdioFile file;
	TRY
	{
		if (FALSE == file.Open(m_strPath2, CFile::modeRead))
		{
			return FALSE;
		}

//		DWORD dwFileSize;
		if(file.GetLength() < 1)
		{
			file.Close();
			
			::DeleteFile(m_strPath);
			
			return FALSE;
		}

		CArchiveMark ar(&file, CArchive::load);
		Serialize(ar, 10000, 1);
	}
	CATCH (CException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
	file.Close();
	return TRUE;
}

void GlobalVariable::Serialize(CArchiveMark &ar, int nVersion, int nMode)
{

	TRY
	{
		if (ar.IsStoring())
		{	// storing code

			if(nMode == 0)
			{
				m_nVersion = nVersion; // version 1.00.00
				ar << _T("Version = ") << m_nVersion << _T("\n");
//				if(m_nVersion <= 10000)
				{
					for(int i = 0; i < MAX_TOOL_NO; i++)
					{
						m_pToolCode[i]->SaveFile10000(ar, m_nVersion);
					}
				}
			}
			else
			{
				m_nVersion2 = nVersion; // version 1.00.00
				ar << _T("Version = ") << m_nVersion2 << _T("\n");
//				if(m_nVersion2 <= 10000)
				{
					m_pRefuse->SaveFile10000(ar, m_nVersion2);
				}
			}
		}
		else
		{	// loading code

			if(nMode == 0)
			{
				ar >> m_nVersion; 
//				if(m_nVersion <= 10000)
				{
					for(int i = 0; i < MAX_TOOL_NO; i++)
					{
						m_pToolCode[i]->LoadFile10000(ar, m_nVersion, TRUE);
					}
				}
			}
			else
			{
				ar >> m_nVersion2; 
//				if(m_nVersion2 <= 10000)
				{
					m_pRefuse->LoadFile10000(ar, m_nVersion2);
				}
			}
		}
	}
	CATCH (CException, e)
	{
		e->Delete();
		THROW_LAST();
	}
	END_CATCH
}

void GlobalVariable::SetPath()
{
	m_strPath.Format(_T("%sGlobalTool.dat"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
	
	m_strPath2.Format(_T("%sRefuseList.dat"), gEasyDrillerINI.m_clsDirPath.GetSystemDir());
}

double GlobalVariable::GetLMDuty_us(int nFrq ,double dDutyPercent)//20160627
{

	double dMaxLM_us = 1/(double)nFrq * 1000000. ;

	double dTagetLM_us = dDutyPercent/100 * dMaxLM_us;

	return dTagetLM_us;
}
void GlobalVariable::GetMinMaxPower(double dTagetPower,double dTol ,double &dMin,double &dMax)
{
	//Get Min,Max Power
	double dGap = dTagetPower * dTol/100;

	dMin = dTagetPower - dGap;
	dMax = dTagetPower + dGap;
}

BOOL GlobalVariable::IsValidateTableModulationData(SBEAMPATH sBeampath , SSHOTGROUPTABLE sShotGroupTable,BOOL bPowerCompen)//20160626
{
	int nToolCount = sBeampath.nLastIndex;
	double dOntimeOffsetM[12];
	double dOntimeOffsetS[12];

	for(int k =  0; k < 12; k++)
	{
		dOntimeOffsetM[k] = 0;
		dOntimeOffsetS[k] = 0;
	}
	for(int nShotTableIndex = 0; nShotTableIndex <= sShotGroupTable.nGroupLastIndex; nShotTableIndex++)
	{
		//int nShotTableIndex = sBeampath.nSelectShot[nToolNo];

		double dMasterDutyOffset = 0;//sToolTable.dMasterDutyOffset[nToolNo];
		double dSlaveDutyOffset = 0;//sToolTable.dSlaveDutyOffset[nToolNo];

		int nPulseCount = sShotGroupTable.nTotalShotCount[nShotTableIndex];
		BOOL bUseAom = sShotGroupTable.bUseAom[nShotTableIndex] = FALSE;

		//---------------------------------
		for(int nPulseNo = 0; nPulseNo < nPulseCount; nPulseNo++)
		{

			if(sShotGroupTable.nTotalShotCount[nShotTableIndex] < nPulseNo)//20160628
				continue;

			if(nPulseNo != 0)//First Pulse Only
			{
				dMasterDutyOffset = 0;
				dSlaveDutyOffset = 0;
			}


			int nFrq = sShotGroupTable.nShotFrequency[nShotTableIndex];
			double dLM_us = sShotGroupTable.dShotLMDuty_us[nShotTableIndex];

			double dDutyLimit = gProcessINI.m_sProcessOption.dDutyLimit;//9;//9% Fix
			double dDutyPercent = sShotGroupTable.dShotDuty_Percent[nShotTableIndex];
			

			
			double dMaxDuty = 1/(double)nFrq * 1000000. ;    
			double dInsertDuty = dLM_us/dMaxDuty * 100.;


			//---------------------------------

			double dOnTime_M = sShotGroupTable.m_sShotParam[nShotTableIndex].dOnTime_M[nPulseNo];
			double dOnTime_S = sShotGroupTable.m_sShotParam[nShotTableIndex].dOnTime_S[nPulseNo];

			double dWait_M = sShotGroupTable.m_sShotParam[nShotTableIndex].dAOMWait_M[nPulseNo];
			double dWait_S = sShotGroupTable.m_sShotParam[nShotTableIndex].dAOMWait_S[nPulseNo];


			dOnTime_M += dMasterDutyOffset;
			dOnTime_S += dSlaveDutyOffset;

			int nAOMNoCnt1 = sShotGroupTable.m_sShotParam[nShotTableIndex].nAOMNum_M[nPulseNo];
			int nAOMNoCnt2 = sShotGroupTable.m_sShotParam[nShotTableIndex].nAOMNum_S[nPulseNo];

			for(int k = 0; k < nAOMNoCnt1; k++)
			{
				dOntimeOffsetM[k] = (sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset_M[nPulseNo] + sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset2_M[nPulseNo]) / nAOMNoCnt1;
			}
			for(int k = 0; k < nAOMNoCnt2; k++)
			{
				dOntimeOffsetS[k] = (sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset_S[nPulseNo] + sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset2_S[nPulseNo]) / nAOMNoCnt2;
			}
			dOnTime_M += (sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset_M[nPulseNo] + sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset2_M[nPulseNo]);
			dOnTime_S += (sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset_S[nPulseNo] + sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset2_S[nPulseNo]);
			//---------------------------------
			double dAOMSum1 =0,dAOMSum2 =0;  
			for(int nAOM1 = 0; nAOM1 < nAOMNoCnt1; nAOM1++)
			{
				if(nAOM1 == 0)
					dAOMSum1 += sShotGroupTable.m_sShotParam[nShotTableIndex].m_sAOMParam[nPulseNo].dAOM_ON_M[nAOM1] + dMasterDutyOffset + dOntimeOffsetM[nAOM1];
				else
					dAOMSum1 += sShotGroupTable.m_sShotParam[nShotTableIndex].m_sAOMParam[nPulseNo].dAOM_ON_M[nAOM1] + dOntimeOffsetM[nAOM1];

				dAOMSum1 += sShotGroupTable.m_sShotParam[nShotTableIndex].m_sAOMParam[nPulseNo].dAOM_OFF_M[nAOM1];
			}

			for(int nAOM2 = 0; nAOM2 < nAOMNoCnt2; nAOM2++)
			{
				if(nAOM2 == 0)
					dAOMSum2 += sShotGroupTable.m_sShotParam[nShotTableIndex].m_sAOMParam[nPulseNo].dAOM_ON_S[nAOM2] + dSlaveDutyOffset + dOntimeOffsetS[nAOM2];
				else
					dAOMSum2 += sShotGroupTable.m_sShotParam[nShotTableIndex].m_sAOMParam[nPulseNo].dAOM_ON_S[nAOM2] + dOntimeOffsetS[nAOM2];

				dAOMSum2 += sShotGroupTable.m_sShotParam[nShotTableIndex].m_sAOMParam[nPulseNo].dAOM_OFF_S[nAOM2];
			}

			CString strShow;
			CString strCR = "\n";
			//---------------------------------
			//Table Info
			CString strInfo;
			strInfo.Format(" [Tool Info] \n");
			strShow +=strInfo;
			strInfo.Format("Shot No:[%d] ,Pulse No:[%d] \n",nShotTableIndex,nPulseNo);
			strShow +=strInfo;
			strInfo.Format(" LM Offset  M:%.2f ,S:%.2f \n",dMasterDutyOffset,dSlaveDutyOffset);
			strShow +=strInfo;
			strInfo.Format(" Frquency :%d hz , LM :%.2f us \n",nFrq,dLM_us);
			strShow +=strInfo;
			strInfo.Format(" OffsetM :%.2f , OffsetS :%.2f \n",
				sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset_M[nPulseNo] + sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset2_M[nPulseNo] ,
				sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset_S[nPulseNo] + sShotGroupTable.m_sShotParam[nShotTableIndex].dOntimeOffset2_S[nPulseNo]);
			strShow +=strInfo;
			strShow +=strCR;
			//---------------------------------
			CString strIErrorInfo;
			strIErrorInfo.Format(" [Error Info] \n");
			strShow +=strIErrorInfo;
			double dDutyLimitGap = dLM_us * 0.0;//0%


			//Error1
			if(bUseAom)
			{
				if((dOnTime_M + dWait_M) - dLM_us  > dDutyLimitGap)
				{
					strIErrorInfo.Format(" [1] (OnTime+ Wait) Duty Limit Error \n");
					strShow +=strIErrorInfo;
					strIErrorInfo.Format("  LM: %.2f us , Limit: %.2f us  ([1]OnTime: %.2f us + Wait: %.2f us)  \n",dLM_us,dLM_us + dDutyLimitGap,dOnTime_M,dWait_M);
					strShow +=strIErrorInfo;
					if(bPowerCompen)
						ErrMessage(_T("Power ComPen Fail"));
					else
						ErrMessage(strShow);
					return FALSE;
				}
				//Error1
				/*if( (dOnTime_S + dWait_S) - dLM_us  > dDutyLimitGap)
				{
					strIErrorInfo.Format(" [2] (OnTime+ Wait) Duty Limit Error \n");
					strShow +=strIErrorInfo;
					strIErrorInfo.Format("  LM: %.2f us, Limit: %.2f us  ([1]OnTime: %.2f us + Wait: %.2f us)  \n",dLM_us,dLM_us + dDutyLimitGap,dOnTime_S,dWait_S);
					strShow +=strIErrorInfo;
					if(bPowerCompen)
						ErrMessage(_T("Power ComPen Fail"));
					else
						ErrMessage(strShow);
					return FALSE;
				}*/
			}
			else
			{
				if((dOnTime_M - dLM_us)  > dDutyLimitGap)
				{
					strIErrorInfo.Format(" [1] OnTime Duty Limit Error \n");
					strShow +=strIErrorInfo;
					strIErrorInfo.Format("  LM: %.2f us , Limit: %.2f us  ([1]OnTime: %.2f us)  \n",dLM_us,dLM_us + dDutyLimitGap,dOnTime_M);
					strShow +=strIErrorInfo;
					if(bPowerCompen)
						ErrMessage(_T("Power ComPen Fail"));
					else
						ErrMessage(strShow);
					return FALSE;
				}
				//Error1
				/*if( (dOnTime_S - dLM_us)  > dDutyLimitGap)
				{
					strIErrorInfo.Format(" [2] OnTime Duty Limit Error \n");
					strShow +=strIErrorInfo;
					strIErrorInfo.Format("  LM: %.2f us, Limit: %.2f us  ([1]OnTime: %.2f us)  \n",dLM_us,dLM_us + dDutyLimitGap,dOnTime_S);
					strShow +=strIErrorInfo;
					if(bPowerCompen)
						ErrMessage(_T("Power ComPen Fail"));
					else
						ErrMessage(strShow);
					return FALSE;
				}*/
			}
			
			//Error2
			double dTempDutyLimit = GetLMDuty_us(nFrq,gProcessINI.m_sProcessOption.dDutyLimit);


			if(dLM_us > dTempDutyLimit)
			{
				strIErrorInfo.Format(" LM(us) Tool High Error (%.2f us Over) \n",dTempDutyLimit);
				strShow +=strIErrorInfo;
				strIErrorInfo.Format(" Insert LM: %.2f us \n",dLM_us);
				strShow +=strIErrorInfo;
				if(bPowerCompen)
					ErrMessage(_T("Power ComPen Fail"));
				else
					ErrMessage(strShow);
				return FALSE;
			}

			if(bUseAom)
			{

				//Error3
				if((int)(dOnTime_M*1000) < (int)(dAOMSum1*1000))
				{
					strIErrorInfo.Format(" AOM [1] SUM Error \n");
					strShow +=strIErrorInfo;
					strIErrorInfo.Format(" [1]OnTime: %.2f us ,AOM SUM ([1]:%.2f ) \n",dOnTime_M,dAOMSum1);
					strShow +=strIErrorInfo;
					if(bPowerCompen)
						ErrMessage(_T("Power ComPen Fail"));
					else

						ErrMessage(strShow);
					return FALSE;
				}
			}
			//Error3
			/*if((int)(dOnTime_S*1000) < (int)(dAOMSum2*1000))
			{
				strIErrorInfo.Format(" AOM [2] SUM Error \n");
				strShow +=strIErrorInfo;
				strIErrorInfo.Format(" [2]OnTime: %.2f us ,AOM SUM ([2]:%.2f ) \n",dOnTime_S,dAOMSum2);
				strShow +=strIErrorInfo;
				if(bPowerCompen)
					ErrMessage(_T("Power ComPen Fail"));
				else
					ErrMessage(strShow);
				return FALSE;
			}*/

			//Error4

			if(dDutyLimit < dInsertDuty)
			{
				strIErrorInfo.Format(" Duty Limit Over Error \n");
				strShow +=strIErrorInfo;
				strIErrorInfo.Format(" Duty Limit: %.2f  (Insert Duty: %.2f ,LM: %.2f us)  \n",dDutyLimit,dInsertDuty,dLM_us);
				strShow +=strIErrorInfo;
				if(bPowerCompen)
					ErrMessage(_T("Power ComPen Fail"));
				else
					ErrMessage(strShow);
				return FALSE;
			}
			//-----------------------


			////Error5
			//if(dWait_M > gProcessINI.m_sProcessPowerMeasure.dCompensationWaitLimit)
			//{
			//	strIErrorInfo.Format(" Wait Time Over Error \n");
			//	strShow +=strIErrorInfo;
			//	strIErrorInfo.Format(" Wait Time Limit : %.2f  (Wait Time : %.2f us)  \n",gProcessINI.m_sProcessPowerMeasure.dCompensationWaitLimit,dWait_M);
			//	strShow +=strIErrorInfo;
			//	if(bPowerCompen)
			//		ErrMessage(_T("Power ComPen Fail"));
			//	ErrMessage(strShow);
			//	return FALSE;
			//}
		}
	}

	return TRUE;
}

BOOL GlobalVariable::IsValidateTableModulationPowerCompen(int nHeadMode,double dNewDutyOffset1,double dNewDutyOffset2,int nToolTableNo, double dNewOntimeOffset1, double dNewOntimeOffset2)
{	
	if(dNewDutyOffset1 == 0 && dNewDutyOffset2 == 0 && dNewOntimeOffset1 == 0 && dNewOntimeOffset2 == 0)
		return TRUE;

	memcpy( &m_sgShotGroupTablePower, &gShotTableINI.m_sShotGroupTable, sizeof(gShotTableINI.m_sShotGroupTable) );

	CString strEvent, strInfo;
	int nMask = nToolTableNo;

	int nShotIndex = gBeamPathINI.m_sBeampath.nSelectShot[nToolTableNo];

	int nPulseCount = gShotTableINI.m_sShotGroupTable.nTotalShotCount[nShotIndex];


	for(int nPulseNo = 0; nPulseNo < nPulseCount; nPulseNo++)
	{
		m_sgShotGroupTablePower.m_sShotParam[nShotIndex].dAOMWait_M[nPulseNo] += dNewDutyOffset1;
		m_sgShotGroupTablePower.m_sShotParam[nShotIndex].dAOMWait_S[nPulseNo] += dNewDutyOffset2;
			
		m_sgShotGroupTablePower.m_sShotParam[nShotIndex].dOntimeOffset_M[nPulseNo] += dNewOntimeOffset1;
		m_sgShotGroupTablePower.m_sShotParam[nShotIndex].dOntimeOffset_S[nPulseNo] += dNewOntimeOffset2;
	}

	if(!IsValidateTableModulationData(gBeamPathINI.m_sBeampath, m_sgShotGroupTablePower, TRUE))
	{
		return FALSE;
	}

	return TRUE;
}

BOOL GlobalVariable::IsOkLotSchedule()
{

	int nFirst = gLotInfo.nComSol[0];
	int nSecond = gLotInfo.nComSol[1];


	int n1st = 0;
	int n2nd = 0;

	for(int i = 1; i < 5; i++)
	{
		int nTemp = i * 2;
		n1st = gLotInfo.nComSol[nTemp];
		n2nd = gLotInfo.nComSol[nTemp+1];

		if(strcmp(gLotInfo.szPrj[nTemp], "" ) != 0 && (nFirst != n1st))
			return FALSE;

		if(strcmp(gLotInfo.szPrj[nTemp+1], "" ) != 0 && (nSecond != n2nd))
			return FALSE;
	}


	return TRUE;
}

void GlobalVariable::InitVisionOffsetFor4Way()
{
	for(int ii = 0; ii < 4; ii++)
	{
		m_dVisionOffsetFor4Way_mm[ii].x = -999;
		m_dVisionOffsetFor4Way_mm[ii].y = -999;
	}
}

void GlobalVariable::InitCognixResult()
{
	for(int ii = 0; ii < 100; ii++)
	{
		m_CognixTemp[ii].bUse = FALSE;
		m_CognixTemp[ii].dOffsetReuslt_Pixcel.x = 0;
		m_CognixTemp[ii].dOffsetReuslt_Pixcel.y = 0;
		m_CognixTemp[ii].dOffsetReuslt_mm.x = 0;
		m_CognixTemp[ii].dOffsetReuslt_mm.y = 0;
		m_CognixTemp[ii].dScaleResult.x = 0;
		m_CognixTemp[ii].dScaleResult.y = 0;
		m_CognixTemp[ii].dHoleSize.x = 0;
		m_CognixTemp[ii].dHoleSize.y = 0;
		m_CognixTemp[ii].dScoreValue = 0;
		m_CognixTemp[ii].bSizeCheck = 0;
		m_CognixTemp[ii].bRatioCheck = 0;
		m_CognixTemp[ii].bFinalSuccess = 0;
		m_CognixTemp[ii].nHoleSortIndex = -1;
		m_CognixTemp[ii].nHoleOriginIndex = -1;
		m_CognixTemp[ii].dScaleGap = 0;
	}

	for(int ii = 0; ii < 4; ii++)
	{
		m_CognixFinalResult[ii].bUse = FALSE;
		m_CognixFinalResult[ii].dOffsetReuslt_Pixcel.x = 0;
		m_CognixFinalResult[ii].dOffsetReuslt_Pixcel.y = 0;
		m_CognixFinalResult[ii].dOffsetReuslt_mm.x = 0;
		m_CognixFinalResult[ii].dOffsetReuslt_mm.y = 0;
		m_CognixFinalResult[ii].dScaleResult.x = 0;
		m_CognixFinalResult[ii].dScaleResult.y = 0;
		m_CognixFinalResult[ii].dHoleSize.x = 0;
		m_CognixFinalResult[ii].dHoleSize.y = 0;
		m_CognixFinalResult[ii].dScoreValue = 0;
		m_CognixFinalResult[ii].bSizeCheck = 0;
		m_CognixFinalResult[ii].bRatioCheck = 0;
		m_CognixFinalResult[ii].bFinalSuccess = 0;
		m_CognixFinalResult[ii].nHoleSortIndex = -1;
		m_CognixFinalResult[ii].nHoleOriginIndex = -1;
		m_CognixFinalResult[ii].dScaleGap = 0;
	}
}

int CompareValue(const void *a,const void *b)
{
	if(gVariable.m_nLineUpType == INT_TYPE)
	{
		int *nX = (int*)a;
		int *nY = (int*)b;
		if(gVariable.m_nLineUpOrder == ASCENDING_ORDER)
			return *nX - *nY;
		else
			return *nY - *nX;
	}
	else
	{
		double *dX = (double*)a;
		double *dY = (double*)b;
		double dCal = 0;
		if(gVariable.m_nLineUpOrder == ASCENDING_ORDER)
			dCal = *dX - *dY ;
		else
			dCal = *dY - *dX ;

		if(dCal < 0)
			return -1;
		else if(dCal > 0)
			return 1;
		else 
			return 0;
	}
}
void GlobalVariable::SetLineUpValue_int(int nOrder,int * nArray,int nSize)
{ 
	m_nLineUpOrder = nOrder;
	m_nLineUpType = INT_TYPE;
	qsort(nArray,nSize,sizeof(int),CompareValue);
}
void GlobalVariable::SetLineUpValue_double(int nOrder,double * dArray,int nSize)
{ 
	m_nLineUpOrder = nOrder;
	m_nLineUpType = DOUBLE_TYPE;
	qsort(dArray,nSize,sizeof(double),CompareValue);
}


BOOL GlobalVariable::IsValidVisionOffsetFor4Way(double dCenterOffsetX ,double dCenterOffsetY,CString &strErr,DPOINT & dFinalReuslt)
{

	CDPoint dSum;
	dSum.x = 0;dSum.y = 0;

	CDPoint dAvg;
	dAvg.x = 0;dAvg.y = 0;

	CDPoint dTempOffset[4];
	CString strDisplay;
	CString strTemp;
	

	for(int ii = 0; ii < 4; ii++)
	{
		double dGapX = fabs(m_dVisionOffsetFor4Way_mm[ii].x + 999);
		double dGapY = fabs(m_dVisionOffsetFor4Way_mm[ii].y + 999);

		////�ϳ��� ��ã������ Fail?
		if(dGapX < 1 || dGapY < 1)
		{
			strErr = "Hole Find Fail";
			return FALSE;
		}
		m_dVisionOffsetFor4Way_mm[ii].x += dCenterOffsetX;
		m_dVisionOffsetFor4Way_mm[ii].y += dCenterOffsetY;

		dSum.x += m_dVisionOffsetFor4Way_mm[ii].x;
		dSum.y += m_dVisionOffsetFor4Way_mm[ii].y;

		dTempOffset[ii] = m_dVisionOffsetFor4Way_mm[ii];
	}
	dAvg.x = dSum.x/4.;
	dAvg.y = dSum.y/4.;


	//strDisplay.Format("Raw AVG , X:%.4f  ,Y:%.4f",dAvg.x, dAvg.y);
//	TRACE("%s\n",strDisplay);
	//::AfxGetMainWnd()->SendMessage(UM_SHOW_4WAY, reinterpret_cast<WPARAM>(&strDisplay));

	for(int ii = 0; ii < 4; ii++)
	{
		double dX = m_dVisionOffsetFor4Way_mm[ii].x;
		double dY = m_dVisionOffsetFor4Way_mm[ii].y;
		strDisplay.Format("Raw %d , X:%.4f  ,Y:%.4f",ii +1,dX, dY);
	//	TRACE("%s\n",strDisplay);
	//	::AfxGetMainWnd()->SendMessage(UM_SHOW_4WAY, reinterpret_cast<WPARAM>(&strDisplay));
	}

	
	int nLT = -1;
	int nRT = -1;
	int nLB = -1;
	int nRB = -1;


	CDPoint dp1;

	//enum {LEFT_TOP, RIGHT_TOP, LEFT_BOTTOM, RIGHT_BOTTOM};

	//4����
	for(int aa = 0; aa< 4; aa++)
	{
		dp1.x = dTempOffset[aa].x;
		dp1.y = dTempOffset[aa].y;

		if(dp1.x < dAvg.x && dp1.y >= dAvg.y)
			nLT = aa;
		else if(dp1.x >= dAvg.x && dp1.y >= dAvg.y)
			nRT = aa;
		else if(dp1.x < dAvg.x && dp1.y < dAvg.y)
			nRB = aa;
		else if(dp1.x >= dAvg.x && dp1.y < dAvg.y)
			nLB = aa;
	}

	//4���� ������ �ȵȴٸ� Fail?
	if(nLT == -1 || nRT == -1 || nLB == -1 || nRB == -1)
	{
		strErr = "ã�� Hole ���� 4���� ����";
		/*
		strDisplay.Format("LT : %d, RT : %d, LB : %d, RB : %d",nLT, nRT,nLB,nRB);
		::AfxGetMainWnd()->SendMessage(UM_SHOW_4WAY, reinterpret_cast<WPARAM>(&strDisplay));

		strDisplay.Format("Raw AVG , X:%.4f  ,Y:%.4f",dAvg.x, dAvg.y);
		TRACE("%s\n",strDisplay);
		::AfxGetMainWnd()->SendMessage(UM_SHOW_4WAY, reinterpret_cast<WPARAM>(&strDisplay));

		for(int ii = 0; ii < 4; ii++)
		{
			double dX = m_dVisionOffsetFor4Way_mm[ii].x;
			double dY = m_dVisionOffsetFor4Way_mm[ii].y;
			strDisplay.Format("Raw %d , X:%.4f  ,Y:%.4f",ii +1,dX, dY);
			TRACE("%s\n",strDisplay);
			::AfxGetMainWnd()->SendMessage(UM_SHOW_4WAY, reinterpret_cast<WPARAM>(&strDisplay));
		}
		*/
		return FALSE;
	}
	
	
	



	
	
	m_dVisionOffsetFor4Way_mm[LEFT_TOP] = dTempOffset[nLT];
	m_dVisionOffsetFor4Way_mm[RIGHT_TOP] = dTempOffset[nRT];
	
	m_dVisionOffsetFor4Way_mm[RIGHT_BOTTOM] = dTempOffset[nRB];
	m_dVisionOffsetFor4Way_mm[LEFT_BOTTOM] = dTempOffset[nLB];


	double dGapLimit = 0.1;// 50um
	for(int aa = 0; aa< 3; aa++)
	{
		double dGapX = fabs(m_dVisionOffsetFor4Way_mm[aa].x - m_dVisionOffsetFor4Way_mm[aa+1].x);
		double dGapY = fabs(m_dVisionOffsetFor4Way_mm[aa].y - m_dVisionOffsetFor4Way_mm[aa+1].y);
		
		double dDistance = sqrt(dGapX * dGapX + dGapY * dGapY);
		double dDistanceGap = fabs(dDistance - gProcessINI.m_sProcessCal.dCalibrationHoleGap/2.);


		//�Ÿ����� 50um �̻� ���̳��� ����
		if(dDistanceGap > dGapLimit)
		{
			strErr = "���� �ɼ°� ���̰� �ʹ� ���� ��";
			return FALSE;
		}
	}
	

	double dDist = gProcessINI.m_sProcessCal.dCalibrationHoleGap/4.;

	m_dVisionOffsetFor4Way_mm[LEFT_TOP].x += dDist;
	m_dVisionOffsetFor4Way_mm[LEFT_TOP].y -= dDist;
	m_dVisionOffsetFor4Way_mm[RIGHT_TOP].x -= dDist;
	m_dVisionOffsetFor4Way_mm[RIGHT_TOP].y -= dDist;
	m_dVisionOffsetFor4Way_mm[RIGHT_BOTTOM].x -= dDist;
	m_dVisionOffsetFor4Way_mm[RIGHT_BOTTOM].y += dDist;
	m_dVisionOffsetFor4Way_mm[LEFT_BOTTOM].x += dDist;
	m_dVisionOffsetFor4Way_mm[LEFT_BOTTOM].y += dDist;



	dSum.x = 0;dSum.y = 0;

	for(int ii = 0; ii < 4; ii++)
	{
		dSum.x += m_dVisionOffsetFor4Way_mm[ii].x;
		dSum.y += m_dVisionOffsetFor4Way_mm[ii].y;
	}


	for(int ii = 0; ii < 4; ii++)
	{
		double dX = m_dVisionOffsetFor4Way_mm[ii].x;
		double dY = m_dVisionOffsetFor4Way_mm[ii].y;

		if(ii == LEFT_TOP)
			strTemp = "LT";
		else if(ii == RIGHT_TOP)
			strTemp = "RT";
		else if(ii == RIGHT_BOTTOM)
			strTemp = "RB";
		else 
			strTemp = "LB";

		strDisplay.Format("%s :  %.4f %.4f",strTemp, dX,dY);
		::AfxGetMainWnd()->SendMessage(UM_SHOW_4WAY, reinterpret_cast<WPARAM>(&strDisplay));

	}

	dFinalReuslt.x = dSum.x/4.;
	dFinalReuslt.y = dSum.y/4.;

	return TRUE;
}


CString GlobalVariable::DoEncrypt(CString strOrigin,BOOL bUseDecryt)
{
	char chTemp[1024];
	memset(chTemp,0x000, 1024);

	int nDataCount = strOrigin.GetLength();
	lstrcpy(chTemp,strOrigin);


	for(int ii = 0; ii < nDataCount; ii++)
	{

		chTemp[ii] ^= SECRET_KEY;
	}
	CString strResult;
	strResult.Format("%s",chTemp);

	if(bUseDecryt == TRUE && nDataCount > 3)
	{
		strResult = strResult.Mid(0,nDataCount-2);
	}

	return strResult;
}


BOOL GlobalVariable::CreateEncryptionFile(CString strPathOld)
{
	CString strPathNew = strPathOld;

	if(strPathOld.Find(".txt") == -1)
		return TRUE;


	strPathNew.Replace(".txt",".encryt");

	CStdioFile sFileNew;
	if(!sFileNew.Open(strPathNew,CFile::modeCreate|CFile::modeWrite|CFile::typeText))
	{
		CString strMsg;	
		strMsg.Format(_T("Can't Save Excellon Data File"));
		ErrMessage(strMsg, MB_ICONERROR);

		return FALSE;
	}


	CString strGetData;
	CString strFinal;

	CStdioFile sFileOld;
	sFileOld.Open( strPathOld, CFile::modeRead | CFile::typeText );
	while( sFileOld.ReadString( strGetData ) )
	{
		strGetData = DoEncrypt(strGetData);

		strFinal.Format("%s\n",strGetData);
		sFileNew.WriteString(strFinal);
	}

	sFileNew.Close();
	sFileOld.Close();

	::DeleteFile(strPathOld);

	return TRUE;
}
void GlobalVariable::SaveTableCalLog(BOOL b1st)
{

	CString strFile, strLog;
	strFile.Format(_T("TableCalCheckLog"));
	strLog.Format("Master T Cal Start");

	if(!b1st)
		strLog.Format("Slave T Cal Start");

	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	double dStartX, dStartY,dTablePosX, dTablePosY, dPanelOffsetX, dPanelOffsetY;

	dStartX = 44.846;
	dStartY = 3.46;

	int nFlag = 1;//FIRST_PANEL_OFFSET;

	if(!b1st)
		nFlag = 2;//SECOND_PANEL_OFFSET;

	for(int ii = 0; ii < 86; ii++)
	{

		dTablePosX  = dStartX; 
		dTablePosY  = dStartY + (10 * ii);

		gDeviceFactory.GetMotor()->GetAxisMoveOffset(dTablePosX, dTablePosY, dPanelOffsetX, dPanelOffsetY, nFlag);
		CString str;
		str.Format("%d \t %.3f \t %.3f \t %8f \t %.8f",ii+1, dTablePosX, dTablePosY, dPanelOffsetX, dPanelOffsetY);
		TRACE("%s\n",str);

		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
	}

}



// 2DTransform.cpp: implementation of the C2DTransform class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "2DTransform.h"
#include <cmath>
#include <cfloat>

#define ANGLE_RESOLUTION				0.000001
#define CALCULATION_RESOLUTION			0.001
#define INVALID_INDEX			-1
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
#define			ONE_FID						1
#define			TWO_FID						2
const	int		AFFINE					=	3;
const	int		PSEUDO_AFFINE			=	4;
const	int		QUADRATIC				=	6;
const	int		CUBIC					=	10;
const	int		MAX_DIM					=	16;
const	int		TRIANGLE				=	3;
const	int		QUADRANGLE				=	4;
const	int		CCW						=	1;
const	int		CW						=	-1;
const	int		COLINEAR				=	0;

double	DISTANCE(double x1, double y1, double x2, double y2)	{return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));}
double	SQDISTANCE(double x1, double y1, double x2, double y2)	{return (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);}
double	ABSDISTANCE(double x1, double y1, double x2, double y2)	{return (fabs(x2 - x1) + fabs(y2 - y1));}

C2DTransform::C2DTransform()
{
//	m_bNotReady = true;
	m_nNumPoint = 0;
	m_nNumConvexHullPoint = 0;

	m_ptRef = m_ptTran = NULL;

	m_XCal = m_YCal = NULL;

	m_pnLargeArea = NULL;

	m_VectCal = m_VecXCal = m_VecYCal = NULL;
	m_ptVecCal = NULL;

	m_nLargeArea = 0;
	m_bUseScaleLimit = TRUE;
}

C2DTransform::~C2DTransform()
{
	ClearMemory();
}

void C2DTransform::ClearMemory()
{
	delete [] m_ptRef;		m_ptRef = NULL;
	delete [] m_ptTran;		m_ptTran = NULL;
	delete [] m_XCal;		m_XCal = NULL;
	delete [] m_YCal;		m_YCal = NULL;
	
	delete [] m_pnLargeArea;	m_pnLargeArea = NULL;

	delete [] m_VectCal;	m_VectCal = NULL;
	delete [] m_ptVecCal;	m_ptVecCal = NULL;
	delete [] m_VecXCal;	m_VecXCal = NULL;
	delete [] m_VecYCal;	m_VecYCal = NULL;

	m_nNumPoint = 0;
}

bool C2DTransform::SetNumPoint(int nNum)
{
	ClearMemory();

	m_nNumPoint = nNum;
	if(m_nNumPoint == 0)
		return true;
//	m_bNotReady = true;

	TRY
	{
		m_ptRef = new DPOINT[nNum];
		m_ptTran = new DPOINT[nNum];
		for(int i = 0; i < nNum; i++)
		{
			m_ptTran[i].x = 0;
			m_ptTran[i].y = 0;
		}
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		ClearMemory();

		return false;
	}
	END_CATCH

	m_bUseScaleLimit = FALSE;

	return true;
}

void C2DTransform::SetCheckScaleLimit(BOOL bUse)
{
	m_bUseScaleLimit = bUse;
}

bool C2DTransform::SetReferencePoint(double x, double y, int nIndex)
{
//	if (!m_bNotReady)
//		return false;

	if (nIndex < 0 || nIndex > m_nNumPoint- 1)
		return false;

	m_ptRef[nIndex].x = x;
	m_ptRef[nIndex].y = y;

	return true;
}

bool C2DTransform::SetTransformedPoint(double x, double y, int nIndex)
{
//	if (!m_bNotReady)
//		return false;

	if (nIndex < 0 || nIndex > m_nNumPoint - 1)
		return false;

	m_ptTran[nIndex].x = x;
	m_ptTran[nIndex].y = y;

	return true;
}

// LU Back-substitution and forward substitution
// Refer to "Numerical Recipes in C/C++" Chapter 2.3 LU Decomposition
bool C2DTransform::LUGetVal(double* Mat, int* Vec, double* Cal, int nDim)
{
	int ii = 0, ip, j, n = nDim;
	double sum;

	for(int i =  0; i < n; i++)
	{
		ip = Vec[i];
		sum = Cal[ip];
		Cal[ip] = Cal[i];
		if (ii != 0)
		{
			for (j = ii - 1; j < i; j++)
				sum -= Mat[i * n + j] * Cal[j];
		}
		else if (sum != 0.0)
			ii = i + 1;
		Cal[i] = sum;
	}

	for(int i =  n - 1; i >= 0; i--)
	{
		sum = Cal[i];
		for (j = i + 1; j < n; j++)
			sum -= Mat[i * n + j] * Cal[j];
		Cal[i] = sum / Mat[i * n + i];
	}

	return true;
}

// LU Decomposition
// Refer to "Numerical Recipes in C/C++" Chapter 2.3 LU Decomposition
bool C2DTransform::LUDecomp(double* Mat, int* Vec, int& nParity, int nDim)
{
	int iMax = 0, j, k, n = nDim;
	double big, dum, sum, temp;
	double* vv;

	TRY
	{
		vv = new double[n];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		return false;
	}
	END_CATCH

	nParity = 1;

	for(int i =  0; i < n; i++)
	{
		big = 0.0;
		for (j = 0; j < n; j++)
		{
			if ((temp = fabs(Mat[i * n + j])) > big)
				big = temp;
		}
		if (big == 0.0)
		{
			delete [] vv;
			return false;
		}
		vv[i] = 1.0 / big;
	}

	for (j = 0; j < n; j++)
	{
		for(int i =  0; i < j; i++)
		{
			sum = Mat[i * n + j];
			for (k = 0; k < i; k++)
				sum -= Mat[i * n + k] * Mat[k * n + j];
			Mat[i * n + j] = sum;
		}
	
		big = 0.0;
		for(int i =  j; i < n; i++)
		{
			sum = Mat[i * n + j];
			for (k = 0; k < j; k++)
				sum -= Mat[i * n + k] * Mat[k * n + j];
			Mat[i * n + j] = sum;

			if ((dum = vv[i] * fabs(sum)) >= big)
			{
				big = dum;
				iMax = i;
			}
		}

		if (j != iMax)
		{
			for (k = 0; k < n; k++)
			{
				dum = Mat[iMax * n + k];
				Mat[iMax * n + k] = Mat[j * n + k];
				Mat[j * n + k] = dum;
			}
			nParity = -nParity;
			vv[iMax] = vv[j];
		}

		Vec[j] = iMax;

// This is bad conditioned matrix
//		if (Mat[j * m_nCalDim + j] == 0.0)
		if (fabs(Mat[j * n + j]) <= DBL_EPSILON)
		{
			delete [] vv;
			return false;
		}

		if (j != n - 1)
		{
			dum = 1.0 / Mat[j * n + j];
			for(int i =  j + 1; i < n; i++)
				Mat[i * n + j] *= dum;
		}
	}

	delete [] vv;
	return true;
}

bool C2DTransform::AffineTransform()
{
	double* pdMat = NULL;
	int* pnVec = NULL;

	delete [] m_XCal;	m_XCal = NULL;
	delete [] m_YCal;	m_YCal = NULL;
	TRY
	{
		m_XCal = new double[m_nNumPoint];
		m_YCal = new double[m_nNumPoint];
		pdMat = new double[m_nNumPoint * m_nNumPoint];
		pnVec = new int[m_nNumPoint];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		delete [] pdMat;
		delete [] pnVec;

		return false;
	}
	END_CATCH
		
	// angle ���ϱ�
	m_dXOffset = m_ptTran[ONE_FID - 1].x - m_ptRef[ONE_FID - 1].x;
	m_dYOffset = m_ptTran[ONE_FID - 1].y - m_ptRef[ONE_FID - 1].y;
	
	CDPoint point, point0, point1;
	point.x = m_ptTran[TWO_FID - 1].x - m_dXOffset;
	point.y = m_ptTran[TWO_FID - 1].y - m_dYOffset;
	point0.x = m_ptRef[ONE_FID - 1].x;
	point0.y = m_ptRef[ONE_FID - 1].y;
	point1.x = m_ptRef[ONE_FID].x;
	point1.y = m_ptRef[ONE_FID].y;	
	
	m_dAngle = CalAngleMaxPi(point, point0, point1);
	// angle ��

	int nParity = 1;
	switch (m_nNumPoint)
	{
		// Affine Transformation
		// X' = a + bX + cY
		// Y' = A + BX + CY
		case AFFINE:
			for(int i =  0; i < AFFINE; i++)
			{
				pdMat[i * m_nNumPoint + 0] = 1.0;
				pdMat[i * m_nNumPoint + 1] = m_ptRef[i].x;
				pdMat[i * m_nNumPoint + 2] = m_ptRef[i].y;
				m_XCal[i] = m_ptTran[i].x;
				m_YCal[i] = m_ptTran[i].y;
			}
			
			if (!LUDecomp(pdMat, pnVec, nParity, m_nNumPoint))
			{
				delete [] pdMat;
				delete [] pnVec;

				return false;
			}
			LUGetVal(pdMat, pnVec, m_XCal, m_nNumPoint);
			LUGetVal(pdMat, pnVec, m_YCal, m_nNumPoint);
			
			break;
			
		// Pseudo Affine Transformation
		// X' = a + bX + cY + dXY
		// Y' = A + BX + CY + DXY
		case PSEUDO_AFFINE:
			for(int i =  0; i < PSEUDO_AFFINE; i++)
			{
				pdMat[i * m_nNumPoint + 0] = 1.0;
				pdMat[i * m_nNumPoint + 1] = m_ptRef[i].x;
				pdMat[i * m_nNumPoint + 2] = m_ptRef[i].y;
				pdMat[i * m_nNumPoint + 3] = m_ptRef[i].x * m_ptRef[i].y;
				m_XCal[i] = m_ptTran[i].x;
				m_YCal[i] = m_ptTran[i].y;
			}
			
			if (!LUDecomp(pdMat, pnVec, nParity, m_nNumPoint))
			{
				delete [] pdMat;
				delete [] pnVec;

				return false;
			}
			LUGetVal(pdMat, pnVec, m_XCal, m_nNumPoint);
			LUGetVal(pdMat, pnVec, m_YCal, m_nNumPoint);
			
			break;
	}

	delete [] pdMat;
	delete [] pnVec;
	
	return true;
}

double C2DTransform::CalAngleMaxPi(CDPoint InPo1, CDPoint InPo2, CDPoint InPo3)
{
	double angle = atan2( InPo2.y - InPo1.y, InPo2.x - InPo1.x);
	double angle2 = atan2( InPo2.y - InPo3.y, InPo2.x - InPo3.x);
	double ang;
	if(isEqualAngle(angle,0.0)) angle=0.;
	if(isEqualAngle(angle2,0.0)) angle2=0.;
//	if(angle < 0 ) angle += 2 * M_PI;
//	if(angle2 < 0 ) angle2 += 2 * M_PI;
	ang = angle - angle2;
	return (ang);
}

bool C2DTransform::isEqualAngle(double x, double y)
{
	double remainder = fmod(fabs(x - y), 2 * M_PI);
	return remainder < ANGLE_RESOLUTION || remainder > 2 * M_PI - ANGLE_RESOLUTION;
}
	
bool C2DTransform::Transform()
{
//	if (!m_bNotReady)
//		return true;

	if(m_nNumPoint <= 0)
		return false;
	if(m_nNumPoint == ONE_FID)
	{
		m_dAngle = 0;
		m_dXOffset = m_ptTran[ONE_FID - 1].x - m_ptRef[ONE_FID - 1].x;
		m_dYOffset = m_ptTran[ONE_FID - 1].y - m_ptRef[ONE_FID - 1].y;
		return true;
	}
	if(m_nNumPoint >= TWO_FID)
	{
		m_dXOffset = m_ptTran[ONE_FID - 1].x - m_ptRef[ONE_FID - 1].x;
		m_dYOffset = m_ptTran[ONE_FID - 1].y - m_ptRef[ONE_FID - 1].y;

		CDPoint point, point0, point1;
		point.x = m_ptTran[TWO_FID - 1].x - m_dXOffset;
		point.y = m_ptTran[TWO_FID - 1].y - m_dYOffset;
		point0.x = m_ptRef[ONE_FID - 1].x;
		point0.y = m_ptRef[ONE_FID - 1].y;
		point1.x = m_ptRef[ONE_FID].x;
		point1.y = m_ptRef[ONE_FID].y;	

		m_dAngle = CalAngleMaxPi(point, point0, point1);

		double dlen1;
		dlen1 = sqrt((point.x - point0.x)*(point.x - point0.x) + (point.y - point0.y)*(point.y - point0.y));
		m_dRefLength = sqrt((point1.x - point0.x)*(point1.x - point0.x) + (point1.y - point0.y)*(point1.y - point0.y));
		m_dDeltaLength = dlen1 - m_dRefLength;

		if(m_nNumPoint == TWO_FID)
			return true;
	}

	if (m_nNumPoint == AFFINE)
	{
		if (AffineTransform())
		{
//			m_bNotReady = false;
			return true;
		}
		else
			return false;
	}

	m_nNumConvexHullPoint = MakeConvexHull();

	if (m_nNumPoint == PSEUDO_AFFINE && m_nNumConvexHullPoint == QUADRANGLE)
	{
		if (AffineTransform())
		{
//			m_bNotReady = false;
			return true;
		}
		else
			return false;
	}
	
	if (!m_nNumConvexHullPoint)
	{
//		m_bNotReady = true;
		return false;
	}

	if (!GetLargestArea())
	{
//		m_bNotReady = true;
		return false;
	}
	
	double* pdMat = NULL;
	int* pnVec = NULL;

	delete [] m_VectCal;	m_VectCal = NULL;
	delete [] m_ptVecCal;	m_ptVecCal = NULL;
	delete [] m_VecXCal;	m_VecXCal = NULL;
	delete [] m_VecYCal;	m_VecYCal = NULL;
	TRY
	{
		m_VectCal = new double[m_nNumPoint];
		m_ptVecCal = new DPOINT[m_nNumPoint];
		m_VecXCal = new double[m_nLargeArea];
		m_VecYCal = new double[m_nLargeArea];
		pdMat = new double[m_nLargeArea * m_nLargeArea];
		pnVec = new int[m_nLargeArea];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		
		ClearMemory();
		delete [] pdMat;
		delete [] pnVec;

//		m_bNotReady = true;
		return false;
	}
	END_CATCH

	ASSERT(m_nLargeArea == TRIANGLE || m_nLargeArea == QUADRANGLE);

	int nParity = 1;
	// Cal intermediate Affine/Pseudo-Affine transformation
	switch (m_nLargeArea)
	{
		// Affine Transformation
		// X' = a + bX + cY
		// Y' = A + BX + CY
		case TRIANGLE:
			for(int i =  0; i < TRIANGLE; i++)
			{
				pdMat[i * m_nLargeArea + 0] = 1.0;
				pdMat[i * m_nLargeArea + 1] = m_ptRef[m_pnLargeArea[i]].x;
				pdMat[i * m_nLargeArea + 2] = m_ptRef[m_pnLargeArea[i]].y;
				m_VecXCal[i] = m_ptTran[m_pnLargeArea[i]].x;
				m_VecYCal[i] = m_ptTran[m_pnLargeArea[i]].y;
			}

			if (!LUDecomp(pdMat, pnVec, nParity, m_nLargeArea))
			{
				ClearMemory();
				delete [] pdMat;
				delete [] pnVec;
				
//				m_bNotReady = true;
				return false;
			}
			LUGetVal(pdMat, pnVec, m_VecXCal, m_nLargeArea);
			LUGetVal(pdMat, pnVec, m_VecYCal, m_nLargeArea);

			break;
		
		// Pseudo Affine Transformation
		// X' = a + bX + cY + dXY
		// Y' = A + BX + CY + DXY
		case QUADRANGLE:
			for(int i =  0; i < QUADRANGLE; i++)
			{
				pdMat[i * m_nLargeArea + 0] = 1.0;
				pdMat[i * m_nLargeArea + 1] = m_ptRef[m_pnLargeArea[i]].x;
				pdMat[i * m_nLargeArea + 2] = m_ptRef[m_pnLargeArea[i]].y;
				pdMat[i * m_nLargeArea + 3] = m_ptRef[m_pnLargeArea[i]].x * m_ptRef[m_pnLargeArea[i]].y;
				m_VecXCal[i] = m_ptTran[m_pnLargeArea[i]].x;
				m_VecYCal[i] = m_ptTran[m_pnLargeArea[i]].y;
			}

			if (!LUDecomp(pdMat, pnVec, nParity, m_nLargeArea))
			{
				ClearMemory();
				delete [] pdMat;
				delete [] pnVec;
				
//				m_bNotReady = true;
				return false;
			}
			LUGetVal(pdMat, pnVec, m_VecXCal, m_nLargeArea);
			LUGetVal(pdMat, pnVec, m_VecYCal, m_nLargeArea);
			
			break;
		default:
			break;
	}

	delete [] pdMat;
	delete [] pnVec;
//	m_bNotReady = false;

	for(int i =  0; i < m_nNumPoint; i++)
		m_ptVecCal[i] = IntermediateTransformPoint(m_ptRef[i].x, m_ptRef[i].y);
		
//	m_bNotReady = false;
	return true;
}

// This algorithm is based on Graham's method
int	C2DTransform::MakeConvexHull()
{
	if (!PrepareForConvexHull())
		return 0;
	
	int nSize = m_ConvexIndex.GetSize();
	CList<int,int> Stack;
	
	TRY
	{
		Stack.AddHead(m_ConvexIndex[0]);
		Stack.AddHead(m_ConvexIndex[1]);
		Stack.AddHead(m_ConvexIndex[2]);
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		return 0;
	}
	END_CATCH

	POSITION pos = NULL;
	for (int i = 3, l = 0; i < nSize; i++)
	{
		while (1)
		{
			l = m_ConvexIndex[i];
			pos = Stack.GetHeadPosition();
			if (pos == NULL)
				break;
			int m = Stack.GetNext(pos);
			if (pos == NULL)
				break;
			int n = Stack.GetAt(pos);
			if (pos == NULL)
				break;
			
			if (GetCCW(m_ptRef[l].x, m_ptRef[l].y, m_ptRef[m].x, m_ptRef[m].y, m_ptRef[n].x, m_ptRef[n].y) == CCW)
				Stack.RemoveHead();
			else
				break;
		}

		TRY
		{
			Stack.AddHead(l);
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();

			return 0;
		}
		END_CATCH
	}
	
	int n = Stack.GetCount();
	m_ConvexIndex.RemoveAll();
	pos = Stack.GetTailPosition();
	for(int i =  0; i < n && pos != NULL; i++)
	{
		TRY
		{
			m_ConvexIndex.Add(Stack.GetAt(pos));
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();
			m_ConvexIndex.RemoveAll();

			return 0;
		}
		END_CATCH
		
		Stack.GetPrev(pos);
	}

	Stack.RemoveAll();
	return n;
}

bool C2DTransform::PrepareForConvexHull()
{
	m_ConvexIndex.RemoveAll();
	
	int minInd = 0;
	TRY
	{
		m_ConvexIndex.Add(minInd);
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		m_ConvexIndex.RemoveAll();

		return false;
	}
	END_CATCH
	int i = 1;
	for (i = 1; i < m_nNumPoint; i++)
	{
		if (m_ptRef[i].y < m_ptRef[minInd].y
			|| (m_ptRef[i].y == m_ptRef[minInd].y && m_ptRef[i].x > m_ptRef[minInd].x))
		{
			minInd = i;
		}
		
		TRY
		{
			m_ConvexIndex.Add(i);
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();

			m_ConvexIndex.RemoveAll();

			return false;
		}
		END_CATCH
	}

	if (minInd != 0)
	{
		i = m_ConvexIndex[0];
		m_ConvexIndex[0] = m_ConvexIndex[minInd];
		m_ConvexIndex[minInd] = i;
	}
	
	int nSize = m_ConvexIndex.GetSize();
	double* dAngle = NULL;
	TRY
	{
		dAngle = new double[nSize];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		return false;
	}
	END_CATCH
	
	i = 1;
	for (dAngle[0] = 0.0,i = 1; i < nSize; i++)
	{
		dAngle[i] = atan2(m_ptRef[m_ConvexIndex[i]].y - m_ptRef[m_ConvexIndex[0]].y,
							m_ptRef[m_ConvexIndex[i]].x - m_ptRef[m_ConvexIndex[0]].x);
		ASSERT(dAngle[i] >= 0.0);
	}
	
	for (int i = 1; i < nSize; i++)
	{
		for (int j = i + 1; j < nSize; j++)
		{
			if (dAngle[i] > dAngle[j])
			{
				int nTemp = m_ConvexIndex[i];
				double dTemp = dAngle[i];
				m_ConvexIndex[i] = m_ConvexIndex[j];
				dAngle[i] = dAngle[j];
				m_ConvexIndex[j] = nTemp;
				dAngle[j] = dTemp;
			}
		}
	}

	delete [] dAngle;

	return true;
}

// Return the counterclockwise-ness of three point
// Return 1 if CCW
// Return -1 if CW
// Return 0 if colinear
int C2DTransform::GetCCW(double ax, double ay, double bx, double by, double cx, double cy)
{
	double cp = bx * cy - ay * bx - ax * cy - by * cx + ax * by + ay * cx;
	
	if (cp > 0.0)
		return CCW;
	else if (cp < 0.0)
		return CW;
	else
		return COLINEAR;
}

// Get the largest quadrangle(triangle)
bool C2DTransform::GetLargestArea()
{
	int nSize = m_ConvexIndex.GetSize();

	if (nSize == TRIANGLE || nSize == QUADRANGLE)
	{
		delete [] m_pnLargeArea;	m_pnLargeArea = NULL;

		TRY
		{
			m_pnLargeArea = new int[nSize];
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();

			return false;
		}
		END_CATCH

		for (int i = 0; i < nSize; i++)
			m_pnLargeArea[i] = m_ConvexIndex[i];
		m_nLargeArea = nSize;

		return true;
	}
	else if (nSize > QUADRANGLE)
	{
		int n = Combination(nSize, QUADRANGLE);
		if (n == 0)
			return false;

		delete [] m_pnLargeArea;	m_pnLargeArea = NULL;

		int *pnTot = NULL, *pnCombi = NULL;
		TRY
		{
			m_pnLargeArea = new int[QUADRANGLE];
			pnTot = new int[nSize];
			pnCombi = new int[QUADRANGLE * n];
		}
		CATCH (CMemoryException, e)
		{
			e->ReportError();
			e->Delete();

			delete [] pnTot;
			delete [] pnCombi;

			return false;
		}
		END_CATCH

		for (int i = 0; i < nSize; i++)
			pnTot[i] = m_ConvexIndex[i];
		m_nLargeArea = QUADRANGLE;

		SetCombinationIndex(nSize, QUADRANGLE, n, pnTot, pnCombi);
		
		double Area, maxA = GetRectArea(pnCombi);
		if (maxA == 0)
		{
			delete [] pnTot;
			delete [] pnCombi;

			m_nLargeArea = 0;
			return false;
		}
		for(int i =  1; i < n; i++)
		{
			Area = GetRectArea(pnCombi + i * QUADRANGLE);
			if (Area == 0)
			{
				delete [] pnTot;
				delete [] pnCombi;
				m_nLargeArea = 0;

				return false;
			}
			if (Area > maxA)
			{
				for (n = 0; n < QUADRANGLE; n++)
					m_pnLargeArea[n] = pnCombi[i * QUADRANGLE + n];
				maxA = Area;
			}
		}

		delete [] pnTot;
		delete [] pnCombi;

		return true;
	}
	return false;
}

// Return the number of combination nCr
int C2DTransform::Combination(int n, int r)
{
	if (r > n || n < 1 || r < 0)
		return 0;

	int* d = NULL;
	TRY
	{
		d = new int[r];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		return 0;
	}
	END_CATCH
	
	if (n - r < r)
		r = n - r;
	if (r == 0)
	{
		delete [] d;
		return 1;
	}
	else if (r == 1)
	{
		delete [] d;
		return n;
	}
	
	for (int i = 1; i < r; i++)
		d[i] = i + 2;
	for(int i =  3; i <= n - r + 1; i++)
	{
		d[0] = i;
		for (int j = 1; j < r; j++)
			d[j] += d[j-1];
	}
	
	int val = d[r-1];
	delete [] d;
	
	if (val < 0)
		return 0;
	else
		return val;
}

bool C2DTransform::SetCombinationIndex(int n, int r, int nCount, int* pnTot, int* pnArray)
{
	if (n > 31 || n < r || n < 1 || r <= 0)
		return false;

	if (n == r)
	{
		for (int m = 0; m < r; m++)
			pnArray[m] = pnTot[m];
		return true;
	}

	int *nList = NULL;
	TRY
	{
		nList = new int[r];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();

		return false;
	}
	END_CATCH

	int x = (1 << r) - 1;
	int nIndex = 0;
//	while (!(x & ((1 << n) - 1)))
	while (nIndex < nCount)
	{
		int i = 0, j = 0, k = 0;
		for (i = n - 1, j = 0, k = 1; i >= 0; i--, k <<= 1)
		{
			if (x & k)
				nList[j++] = pnTot[i];
		}
		for (int m = 0; m < r; m++)
			pnArray[nIndex * r + m] = nList[m];
		nIndex++;
		
		int s = x & -x;
		int l = x + s;
		int sl = l & -l;
		k = ((sl / s) >> 1) - 1;
		x = l | k;
	}
	
	delete [] nList;

	if (nIndex != nCount)
	{
		return false;
	}
	else
		return true;
}

// Calculate rectangle area using heron's theorem and adding two triangle
double C2DTransform::GetRectArea(int* pnList)
{
	double a, b, c, s, Area;
	
	a = DISTANCE(m_ptRef[pnList[0]].x, m_ptRef[pnList[0]].y, m_ptRef[pnList[1]].x, m_ptRef[pnList[1]].y);
	b = DISTANCE(m_ptRef[pnList[1]].x, m_ptRef[pnList[1]].y, m_ptRef[pnList[2]].x, m_ptRef[pnList[2]].y);
	c = DISTANCE(m_ptRef[pnList[2]].x, m_ptRef[pnList[2]].y, m_ptRef[pnList[0]].x, m_ptRef[pnList[0]].y);
	s = (a + b + c) / 2.0;
	Area = sqrt(s * (s - a) * (s - b) * (s - c));
	a = DISTANCE(m_ptRef[pnList[2]].x, m_ptRef[pnList[2]].y, m_ptRef[pnList[3]].x, m_ptRef[pnList[3]].y);
	b = DISTANCE(m_ptRef[pnList[3]].x, m_ptRef[pnList[3]].y, m_ptRef[pnList[0]].x, m_ptRef[pnList[0]].y);
	s = (a + b + c) / 2.0;
	Area += sqrt(s * (s - a) * (s - b) * (s - c));
	
	return Area;
}

DPOINT C2DTransform::IntermediateTransformPoint(const double& x, const double& y)
{
//	ASSERT(m_bNotReady == false);
	
	DPOINT Dest;
	Dest.x = Dest.y = DBL_MAX;
	
	switch (m_nLargeArea)
	{
	case AFFINE:
		Dest.x = m_VecXCal[0] + m_VecXCal[1] * x + m_VecXCal[2] * y;
		Dest.y = m_VecYCal[0] + m_VecYCal[1] * x + m_VecYCal[2] * y;
		break;
		
	case PSEUDO_AFFINE:
		Dest.x = m_VecXCal[0] + m_VecXCal[1] * x + m_VecXCal[2] * y + m_VecXCal[3] * x * y;
		Dest.y = m_VecYCal[0] + m_VecYCal[1] * x + m_VecYCal[2] * y + m_VecYCal[3] * x * y;
		break;
		
	default:
		break;
	}
	
	return Dest;
}

void C2DTransform::AffineTransformPoint(const double x, const double y, double& dXVal, double& dYVal)
{
	switch (m_nNumPoint)
	{
	case AFFINE:
		dXVal = m_XCal[0] + m_XCal[1] * x + m_XCal[2] * y;
		dYVal = m_YCal[0] + m_YCal[1] * x + m_YCal[2] * y;
		break;
		
	case PSEUDO_AFFINE:
		dXVal = m_XCal[0] + m_XCal[1] * x + m_XCal[2] * y + m_XCal[3] * x * y;
		dYVal = m_YCal[0] + m_YCal[1] * x + m_YCal[2] * y + m_YCal[3] * x * y;
		break;

	default:
		break;
	}
}

// Weight = ( (length of fiducial difference)^p / (a + distance to each fiducial) )^b
void C2DTransform::TransformPoint(const double x, const double y, double& dXVal, double& dYVal)
{
	if(m_nNumPoint <= 0)
	{
		dXVal = x;
		dYVal = y;
		return;
	}

	if(m_nNumPoint == ONE_FID)
	{
		dXVal = x + m_dXOffset;
		dYVal = y + m_dYOffset;
		return;
	}

	if(m_nNumPoint == TWO_FID)
	{
		CDPoint myPoint, refPoint, strechP;
		strechP = GetStrechPoint(x, y);
		myPoint.x = m_ptRef[ONE_FID - 1].x + strechP.x;
		myPoint.y = m_ptRef[ONE_FID - 1].y + strechP.y;
		refPoint.x = m_ptRef[ONE_FID - 1].x;
		refPoint.y = m_ptRef[ONE_FID - 1].y;
		
		myPoint.rotateRadian(refPoint, m_dAngle);
		
		dXVal = myPoint.x + m_dXOffset;
		dYVal = myPoint.y + m_dYOffset;
		return;
	}

	if ((m_nNumPoint == AFFINE || (m_nNumPoint == PSEUDO_AFFINE && m_nNumConvexHullPoint == QUADRANGLE)) /*&& !m_bNotReady*/)
	{
		AffineTransformPoint(x, y, dXVal, dYVal);
		return;
	}
	
	DPOINT Mid = IntermediateTransformPoint(x, y);
	double dSumVectCal = 0.0;
	for (int nIndex = 0; nIndex < m_nNumPoint; nIndex++)
	{
		m_VectCal[nIndex] = 1.0 / (DISTANCE(Mid.x, Mid.y, m_ptVecCal[nIndex].x, m_ptVecCal[nIndex].y) + DBL_EPSILON);
		dSumVectCal += m_VectCal[nIndex];
	}
	
	for (int i = 0; i < m_nNumPoint; i++)
	{
		m_VectCal[i] /= dSumVectCal;
	}
	
	dXVal = Mid.x + m_VectCal[0] * (m_ptTran[0].x - m_ptVecCal[0].x);
	dYVal = Mid.y + m_VectCal[0] * (m_ptTran[0].y - m_ptVecCal[0].y);
	
	for (int nIndex = 1; nIndex < m_nNumPoint; nIndex++)
	{
		dXVal += m_VectCal[nIndex] * (m_ptTran[nIndex].x - m_ptVecCal[nIndex].x);
		dYVal += m_VectCal[nIndex] * (m_ptTran[nIndex].y - m_ptVecCal[nIndex].y);
	}
}

int C2DTransform::GetNumPoint()
{
	return m_nNumPoint;
}

CDPoint C2DTransform::GetTransPoint(int nIndex)
{
	CDPoint reP;
	reP.Set(INVALID_INDEX, INVALID_INDEX);

	if (nIndex < 0 || nIndex > m_nNumPoint - 1)
		return reP;
	
	reP.x = m_ptTran[nIndex].x;
	reP.y = m_ptTran[nIndex].y;
	
	return reP;
}

CDPoint C2DTransform::GetRefsPoint(int nIndex)
{
	CDPoint reP;
	reP.Set(INVALID_INDEX, INVALID_INDEX);
	
	if (nIndex < 0 || nIndex > m_nNumPoint - 1)
		return reP;
	
	reP.x = m_ptRef[nIndex].x;
	reP.y = m_ptRef[nIndex].y;
	
	return reP;
}

CDPoint C2DTransform::GetStrechPoint(double x, double y)
{
	CDPoint ReturnP;
	double dx, dy, dAngle, dLength;
	dx = x - m_ptRef[0].x;
	dy = y - m_ptRef[0].y;
	dLength = sqrt(dx*dx + dy*dy);
	dLength = dLength + m_dDeltaLength*dLength/m_dRefLength;
	
	if(dx == 0)
		dAngle = M_PI/2;
	else
		dAngle = fabs(atan(dy/dx));

	if(dx>=0)
	{
		if(dy>=0)
		{
			ReturnP.x = dLength*cos(dAngle);
			ReturnP.y = dLength*sin(dAngle);
		}
		else
		{
			ReturnP.x = dLength*cos(dAngle);
			ReturnP.y = -dLength*sin(dAngle);
		}
	}
	else
	{
		if(dy>=0)
		{
			ReturnP.x = -dLength*cos(dAngle);
			ReturnP.y = dLength*sin(dAngle);
		}
		else
		{
			ReturnP.x = -dLength*cos(dAngle);
			ReturnP.y = -dLength*sin(dAngle);
		}
	}

	return ReturnP;
}

double C2DTransform::GetTransAngle()
{
	return m_dAngle * 180 / M_PI;
}

// PaneMainMenu.cpp : implementation file
//

#include "stdafx.h"
#include "..\EasyDriller.h"
#include "PaneMainMenu.h"
#include "..\EasyDrillerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneMainMenu

IMPLEMENT_DYNCREATE(CPaneMainMenu, CFormView)

CPaneMainMenu::CPaneMainMenu()
	: CFormView(CPaneMainMenu::IDD)
{
	//{{AFX_DATA_INIT(CPaneMainMenu)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneMainMenu::~CPaneMainMenu()
{
}

void CPaneMainMenu::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneMainMenu)
	DDX_Control(pDX, IDC_BUTTON_AUTO_RUN, m_btnAutoRun);
	DDX_Control(pDX, IDC_BUTTON_SYSTEM_SETUP, m_btnSystemSetup);
	DDX_Control(pDX, IDC_BUTTON_RECIPE_OPEN, m_btnRecipeOpen);
	DDX_Control(pDX, IDC_BUTTON_RECIPE_GEN, m_btnRecipeGen);
	DDX_Control(pDX, IDC_BUTTON_PROCESS_SETUP, m_btnProcessSetup);
	DDX_Control(pDX, IDC_BUTTON_MANUAL_DRILL, m_btnManualDrill);
	DDX_Control(pDX, IDC_BUTTON_MANUAL_CONTROL, m_btnManualControl);
	DDX_Control(pDX, IDC_BUTTON_LOGOUT, m_btnLogout);
	DDX_Control(pDX, IDC_BUTTON_LOG_MANAGEMENT, m_btnLogManagement);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneMainMenu, CFormView)
	//{{AFX_MSG_MAP(CPaneMainMenu)
	ON_BN_CLICKED(IDC_BUTTON_LOGOUT, OnButtonLogout)
	ON_BN_CLICKED(IDC_BUTTON_RECIPE_GEN, OnButtonRecipeGen)
	ON_BN_CLICKED(IDC_BUTTON_AUTO_RUN, OnButtonAutoRun)
	ON_BN_CLICKED(IDC_BUTTON_RECIPE_OPEN, OnButtonRecipeOpen)
	ON_BN_CLICKED(IDC_BUTTON_MANUAL_DRILL, OnButtonManualDrill)
	ON_BN_CLICKED(IDC_BUTTON_MANUAL_CONTROL, OnButtonManualControl)
	ON_BN_CLICKED(IDC_BUTTON_PROCESS_SETUP, OnButtonProcessSetup)
	ON_BN_CLICKED(IDC_BUTTON_SYSTEM_SETUP, OnButtonSystemSetup)
	ON_BN_CLICKED(IDC_BUTTON_LOG_MANAGEMENT, OnButtonLogManagement)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneMainMenu diagnostics

#ifdef _DEBUG
void CPaneMainMenu::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneMainMenu::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneMainMenu message handlers

void CPaneMainMenu::OnButtonLogout() 
{
	WPARAM wParam = -1;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, 0 );
}

void CPaneMainMenu::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	InitBtnControl();
}

void CPaneMainMenu::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(150, "Arial Bold");

	m_btnAutoRun.SetFont( &m_fntBtn );
	m_btnAutoRun.SetFlat( FALSE );
	m_btnAutoRun.SetImageOrg( 10, 3 );
	m_btnAutoRun.SetIcon( IDI_DRILL );
	m_btnAutoRun.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAutoRun.EnableToolTips();
	m_btnAutoRun.SetToolTipText( _T("Auto Run") );
	m_btnAutoRun.SetBtnCursor( IDC_HAND_1 );

	m_btnRecipeOpen.SetFont( &m_fntBtn );
	m_btnRecipeOpen.SetFlat( FALSE );
	m_btnRecipeOpen.SetImageOrg( 10, 3 );
	m_btnRecipeOpen.SetIcon( IDI_OPEN );
	m_btnRecipeOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRecipeOpen.EnableToolTips();
	m_btnRecipeOpen.SetToolTipText( _T("Recipe Open") );
	m_btnRecipeOpen.SetBtnCursor( IDC_HAND_1 );

	m_btnRecipeGen.SetFont( &m_fntBtn );
	m_btnRecipeGen.SetFlat( FALSE );
	m_btnRecipeGen.SetImageOrg( 10, 3 );
	m_btnRecipeGen.SetIcon( IDI_SAVE );
	m_btnRecipeGen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRecipeGen.EnableToolTips();
	m_btnRecipeGen.SetToolTipText( _T("Recipe Generation and Save") );
	m_btnRecipeGen.SetBtnCursor( IDC_HAND_1 );

	m_btnManualDrill.SetFont( &m_fntBtn );
	m_btnManualDrill.SetFlat( FALSE );
	m_btnManualDrill.SetImageOrg( 10, 3 );
	m_btnManualDrill.SetIcon( IDI_FIDUCIALSETTING, 48, 48 );
	m_btnManualDrill.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnManualDrill.EnableToolTips();
	m_btnManualDrill.SetToolTipText( _T("Fiducial Setting") );
	m_btnManualDrill.SetBtnCursor( IDC_HAND_1 );

	m_btnManualControl.SetFont( &m_fntBtn );
	m_btnManualControl.SetFlat( FALSE );
	m_btnManualControl.SetImageOrg( 10, 3 );
	m_btnManualControl.SetIcon( IDI_MANUAL );
	m_btnManualControl.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnManualControl.EnableToolTips();
	m_btnManualControl.SetToolTipText( _T("Device Manual Control") );
	m_btnManualControl.SetBtnCursor( IDC_HAND_1 );

	m_btnProcessSetup.SetFont( &m_fntBtn );
	m_btnProcessSetup.SetFlat( FALSE );
	m_btnProcessSetup.SetImageOrg( 10, 3 );
	m_btnProcessSetup.SetIcon( IDI_PROCESSSETUP );
	m_btnProcessSetup.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnProcessSetup.EnableToolTips();
	m_btnProcessSetup.SetToolTipText( _T("Process Setup") );
	m_btnProcessSetup.SetBtnCursor( IDC_HAND_1 );

	m_btnSystemSetup.SetFont( &m_fntBtn );
	m_btnSystemSetup.SetFlat( FALSE );
	m_btnSystemSetup.SetImageOrg( 15, 3 );
	m_btnSystemSetup.SetIcon( IDI_SYSSETUP48, 48, 48 );
	m_btnSystemSetup.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSystemSetup.EnableToolTips();
	m_btnSystemSetup.SetToolTipText( _T("System Setup") );
	m_btnSystemSetup.SetBtnCursor( IDC_HAND_1 );

	m_btnLogManagement.SetFont( &m_fntBtn );
	m_btnLogManagement.SetFlat( FALSE );
	m_btnLogManagement.SetImageOrg( 15, 3 );
	m_btnLogManagement.SetIcon( IDI_LOGMANAGER );
	m_btnLogManagement.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLogManagement.EnableToolTips();
	m_btnLogManagement.SetToolTipText( _T("Log Manager") );
	m_btnLogManagement.SetBtnCursor( IDC_HAND_1 );

	m_btnLogout.SetFont( &m_fntBtn );
	m_btnLogout.SetFlat( FALSE );
	m_btnLogout.SetImageOrg( 15, 3 );
	m_btnLogout.SetIcon( IDI_LOGOUT );
	m_btnLogout.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLogout.EnableToolTips();
	m_btnLogout.SetToolTipText( _T("Logout") );
	m_btnLogout.SetBtnCursor( IDC_HAND_1 );
}

void CPaneMainMenu::OnButtonRecipeGen() 
{
	WPARAM wParam = RECIPE_GEN;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, DRILL );
}

void CPaneMainMenu::OnButtonAutoRun() 
{
	WPARAM wParam = DRILL;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, DRILL );
}

void CPaneMainMenu::OnButtonRecipeOpen() 
{
	TCHAR BASED_CODE szFilter[] = _T("Project Files (*.prj)|*.prj|All Files (*.*)|*.*||");

	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;

	CFileDialog dlg(TRUE, "*.prj", NULL, dwFlags, szFilter);

	//dlg.m_ofn.lpstrInitialDir = gRecipeData.GetRecipeDir();

	if(IDOK != dlg.DoModal())
	{
		return;
	}

	((CEasyDrillerDlg*)GetParent())->SetPrjName( dlg.GetPathName() );
}

void CPaneMainMenu::OnButtonManualDrill() 
{
	WPARAM wParam = FIDUCIAL_SETTING;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, DRILL );
}

void CPaneMainMenu::OnButtonManualControl() 
{
	WPARAM wParam = MANUAL_CONTROL;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, DRILL );
}

void CPaneMainMenu::OnButtonProcessSetup() 
{
	WPARAM wParam = PROCESS_SETUP;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, DRILL );
}

void CPaneMainMenu::OnButtonSystemSetup() 
{
	WPARAM wParam = SYSTEM_SETUP;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, DRILL );
}

void CPaneMainMenu::OnButtonLogManagement() 
{
	WPARAM wParam = LOG_MANAGER;
	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, DRILL );
}

void CPaneMainMenu::OnDestroy()
{
	m_fntBtn.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneMainMenu::ShowMenuLevel(int nLevel)
{
	switch( nLevel )
	{
	case 0 :
		m_btnRecipeGen.ShowWindow(SW_HIDE);
		m_btnManualControl.ShowWindow(SW_HIDE);
		m_btnManualDrill.ShowWindow(SW_HIDE);
		m_btnProcessSetup.ShowWindow(SW_HIDE);
		m_btnSystemSetup.ShowWindow(SW_HIDE);
		break;
	case 1 :
		m_btnRecipeGen.ShowWindow(SW_SHOW);
		m_btnManualControl.ShowWindow(SW_SHOW);
		m_btnManualDrill.ShowWindow(SW_SHOW);
		m_btnProcessSetup.ShowWindow(SW_SHOW);
		m_btnSystemSetup.ShowWindow(SW_HIDE);
		break;
	case 2 :
		m_btnRecipeGen.ShowWindow(SW_SHOW);
		m_btnManualControl.ShowWindow(SW_SHOW);
		m_btnManualDrill.ShowWindow(SW_SHOW);
		m_btnProcessSetup.ShowWindow(SW_SHOW);
		m_btnSystemSetup.ShowWindow(SW_SHOW);
		break;
	case 3 :
		m_btnRecipeGen.ShowWindow(SW_SHOW);
		m_btnManualControl.ShowWindow(SW_SHOW);
		m_btnManualDrill.ShowWindow(SW_SHOW);
		m_btnProcessSetup.ShowWindow(SW_SHOW);
		m_btnSystemSetup.ShowWindow(SW_SHOW);
		break;
	}
}
#if !defined(AFX_PANEMANUALCONTROLIOMONITORINPUTSUB4OSAN_H__D8E606B1_F9C4_452E_AB49_FE82E4CD983F__INCLUDED_)
#define AFX_PANEMANUALCONTROLIOMONITORINPUTSUB4OSAN_H__D8E606B1_F9C4_452E_AB49_FE82E4CD983F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlIOMonitorInputSub4Osan.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub4Osan form view

#include "LedButton.h"
#include "..\device\devicemotor.h"

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CPaneManualControlIOMonitorInputSub4Osan : public CFormView
{
protected:
	CPaneManualControlIOMonitorInputSub4Osan();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlIOMonitorInputSub4Osan)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlIOMonitorInputSub4)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_IO_MONITOR_INPUT_SUB4_OSAN };
	CFont m_fntBtn;

	CLedButton m_ledUCReady;
	CLedButton m_ledUCBusy;
	CLedButton m_ledUCStop;
	CLedButton m_ledUCInitEnd;

	CLedButton m_ledUdPaperTransFwd;
	CLedButton m_ledUdPaperTransBwd;
	CLedButton m_ledUdPCBTransFwd;
	CLedButton m_ledUdPCBTransBwd;
	CLedButton m_ledUdCartClampUp;
	CLedButton m_ledUdCartClampDown;

	CLedButton m_ledUP1Ready;
	CLedButton m_ledUP1Busy;
	CLedButton m_ledUP1Stop;
	CLedButton m_ledUP1InitEnd;
	CLedButton m_ledUP1VacuumOn;
	CLedButton m_ledUP1VacuumOff;

	CLedButton m_ledUP2Ready;
	CLedButton m_ledUP2Busy;
	CLedButton m_ledUP2Stop;
	CLedButton m_ledUP2InitEnd;
	CLedButton m_ledUP2VacuumOn;
	CLedButton m_ledUP2VacuumOff;

	CLedButton m_ledUP3Ready;
	CLedButton m_ledUP3Busy;
	CLedButton m_ledUP3Stop;
	CLedButton m_ledUP3InitEnd;
	CLedButton m_ledUP3VacuumOn;
	CLedButton m_ledUP3VacuumOff;
	//}}AFX_DATA

// Attributes
public:
	int m_nTimerID;
	LONG m_lStatusHandlerUnloader;
	LONG m_lStatusHandlerUnloaderOld;
#ifndef __MP920_MOTOR__
	DeviceMotor* m_pMotor;
#else
	HMotor* m_pMotor;
#endif
// Operations
public:
	void UpdateStatus();
	
	void InitTimer();
	void DestroyTimer();
	
	void InitBtnControl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlIOMonitorInputSub4Osan)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlIOMonitorInputSub4Osan();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlIOMonitorInputSub4Osan)
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLIOMONITORINPUTSUB4OSAN_H__D8E606B1_F9C4_452E_AB49_FE82E4CD983F__INCLUDED_)

// DlgToolHoleSort.h: interface for the CDlgToolHoleSort class.
//
//////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "resource.h"
#include "easydriller.h"
#include "GridCtrl_src\GridCtrl.h"



#define		TABLE0  0
#define		TABLE1  1
#define		TABLE2  2
#define		TABLE3  3
#define		TABLE4  4
#define		TABLE5  5 

#define		SHOT_PREWORK_TABLE0_COLUMN_COUNT 2

#define		COLUMNWIDTH  13	// �÷��� �ѱ��ڴ� �Ҵ�Ǵ� ������ ���� 


#define		TABLETEXT_COLOR		RGB(0,0,0)
#define		TABLE1_COLOR		RGB(255,255,255)
#define		TABLE2_COLOR		RGB(230,230,230)
#define		TABLE3_COLOR		RGB(220,220,220)
#define		TABLE4_COLOR		RGB(210,210,210)
#define		TABLE5_COLOR		RGB(200,200,200) 
#define		TABLE6_COLOR		RGB(180,180,180)


class CDlgToolHoleSort : public CDialog
{

	DECLARE_DYNAMIC(CDlgToolHoleSort)

// Form Data
public:
    	CDlgToolHoleSort(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgToolHoleSort();
	enum { IDD = IDD_DLG_TOOL_HOLE_SORT };
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	//}}AFX_DATA

// Attributes
public:
	UEasyButtonEx	m_chkInfo;
	UEasyButtonEx	m_chkBeamPath;
	UEasyButtonEx	m_chkPowerOffset;
	UEasyButtonEx	m_chkPowerCompensation;
	UEasyButtonEx	m_chkScannerFact;
	UEasyButtonEx   m_ChkSubBox[6];
	UEasyButtonEx	m_btnRefresh;
	UEasyButtonEx   m_btnAdd;
	UEasyButtonEx	m_btnDel;
	UEasyButtonEx   m_btnUp;
	UEasyButtonEx	m_btnDown;

	BOOL			m_bInfoCheck;
	BOOL			m_bBeamPathCheck;
	BOOL			m_bPowerOffsetCheck;
	BOOL			m_bpowerCompensationCheck;
	BOOL			m_bScannerFactCheck;

	BOOL			m_bCheckBox[6];
	CListCtrl		m_list;

	CEdit			m_editwnd;
	CPoint			m_posClicked;		// ����Ʈ �� Ŭ���� �� ��� 
	CColorEdit		m_edtFixMask;


	int				m_nRepeatCount;

	BOOL			m_bClickList;
	BOOL			m_ClickID;


	//SFIDTABLE		m_sFiducialTable;
	//SFIDTABLE		m_sTempFiducialTable;

	SPROCESSSYSTEM  m_sProcessSystem;

	int				m_IdNoToAddDel;
	BOOL	 		m_bDelClick;
	BOOL			m_bDeleteAndSaveClick;

	CGridCtrl m_Grid;
	int				m_nColumnCount;
	int				m_nUserLevel;
	CString strTable0[SHOT_PREWORK_TABLE0_COLUMN_COUNT];// = {"No", "Hole", "Check Hole", "Check"};
// Attributes
protected :
	CFont		m_fntStatic;
	CFont		m_fntEdit;
	CFont		m_fntBtn;
// Operations
public:
	void SaveChangeValue();
	void EnableControl(BOOL bEnable);
	void SetAuthorityByLevel(int nLevel);
	void CellDisable(int y);
	void SetProcessSystem(SPROCESSSYSTEM sProcessSystem);
	void GetCurrentASC();
	BOOL CheckApply();

	int m_nVisionMode;
	void CheckAnyDoPrework();
	int GetShowBoxMode(int nXPos);
	void SetCurrentScrollPos(int xPos, int yPos);
	void OnCheckDown();
	void OnCheckUp();
	void CopyFromTempToOriginal();
	void CopyFromOriginaltoTemp(int nSelectNo, int RepeatNo);
	void InitDataStruct();

	int GetIdNoToAddDel();
	void SetIdNoToAddDel(int nIdYPos);

	int GetListRowIndexCount();
	BOOL MoveFocus(int nXpos, int nYpos,int nMoveType);
	int GetColumnSize(int nStrlen);
	void OnCheckDel();
	void OnCheckAdd();
	void LotListDlbCheck(CPoint m_posDblClick);
	CString GetChangeValueStr();

	BOOL FillTable1Data(int x, int y, CString str);
	BOOL FillTable0Data(int x, int y, CString str);


	BOOL ListUpdate(CPoint ClickedPos, CString str);
	void OnKillfocusEditGrid();

	void InsertGridValue(GV_ITEM Gvitem,int startNo, int TableNo, int ColCount);
	void InsertListComumn(int startNo, int TableNo);
	void DeleteList();
	void SetDrawMember(int listcount);
	int  GetListIndex();
	void InitListControl();
	void OnCheckRefresh();
	void OnCheckScannerFact();
	void OnCheckPowerCompensation();
	void OnCheckPowerOffset();
	void OnCheckBeamPath();
	void OnCheckHoleFact();
	void InitBtnControl();
	void InitStaticControl();
	void InitEditControl();
	void InitGrid();
	BOOL ValidateFiducialValue();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgToolHoleSort)
	public:

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support


	//}}AFX_VIRTUAL

// Implementation
protected:


	// Generated message map functions
	//{{AFX_MSG(CDlgShotTable)

	virtual BOOL OnInitDialog();
	afx_msg void OnClickList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//afx_msg void OnCustomdrawList(NMHDR* pNMHDR, LRESULT * pResult);
	afx_msg void OnNMCustomdrawListTest(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnGridClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	afx_msg void OnGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult);
	afx_msg void OnGridDblClick(NMHDR *pNotifyStruct, LRESULT* pResult);
		//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnSave();
	afx_msg void OnBnClickedBtnCancel();
};



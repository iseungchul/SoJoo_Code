// D:\Source\2010_ver\Lily_2010\UI\PaneAutoRunViewStatus.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "PaneAutoRunViewStatus.h"
#include "..\DEVICE\HDeviceFactory.h"
#include "..\DEVICE\DeviceMotor.h"

#include "..\MODEL\DSystemINI.h"
#include "..\MODEL\DProcessINI.h"
#include "math.h"
#include "..\MODEL\DEasyDrillerINI.h"
#include "..\DEVICE\OPCSvr.h"
#include "..\model\GlobalVariable.h"
#include "..\easydrillerdlg.h"
#include "PaneAutoRun.h"
#include "..\alarmmsg.h"
// CPaneAutoRunViewStatus

IMPLEMENT_DYNCREATE(CPaneAutoRunViewStatus, CFormView)

CPaneAutoRunViewStatus::CPaneAutoRunViewStatus()
	: CFormView(CPaneAutoRunViewStatus::IDD)
{
	m_nTimer = -1;
	m_dMainAir = 0.0;
	m_dWaterFlow1 = 0.0;
	m_dWaterFlow2 = 0.0;
	m_dChillerTemp1 = m_dChillerTemp2 = 0.0;
	m_dHumidity = 0.0;
	m_dTemperatur = 0.0;
	m_dCurrent = 0.0;
	m_dVoltage = 0.0;
	m_dPower = 0.0;
	m_dTableVacuum1 = 0.0;
	m_dTableVacuum2 = 0.0;
	m_dDustSuction = 0.0;
	m_nCount = 0;
	m_dWaterFlowLaser = 0.0;
	m_dWaterFlowAom = 0.0;
	m_dWaterFlowScanner1 = 0.0;
	m_dWaterFlowScanner2 = 0.0;
	m_bWaterFlowError = FALSE;
	m_bWaterFlowErrorOld = FALSE;
	m_nErrorCount = 0;
}

CPaneAutoRunViewStatus::~CPaneAutoRunViewStatus()
{
}

void CPaneAutoRunViewStatus::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CPaneAutoRunViewStatus, CFormView)
	ON_WM_TIMER()
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CPaneAutoRunViewStatus �����Դϴ�.

#ifdef _DEBUG
void CPaneAutoRunViewStatus::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CPaneAutoRunViewStatus::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CPaneAutoRunViewStatus �޽��� ó�����Դϴ�.


void CPaneAutoRunViewStatus::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if(m_nTimer == nIDEvent)
	{
		ChangeDisplay();
		if(m_nCount >= 1200)
		{
			SaveStatus();
			m_nCount = 0;
		}
		else
			m_nCount++;
	}
	CFormView::OnTimer(nIDEvent);
}


void CPaneAutoRunViewStatus::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	
	InitStaticControl();
	if(m_nTimer == -1)
		m_nTimer = SetTimer(1357, 500, NULL);

	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
}
void CPaneAutoRunViewStatus::InitStaticControl()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");

	GetDlgItem(IDC_STATIC_MAIN_AIR)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MAIN_AIR_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_WATER_FLOW1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_WATER_FLOW_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_WATER_FLOW2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_WATER_FLOW_VAL2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CHILLER_PRESSURE1_VAL)->SetFont( &m_fntStatic);
	GetDlgItem(IDC_STATIC_CHILLER_PRESSURE2_VAL)->SetFont( &m_fntStatic);

	GetDlgItem(IDC_STATIC_WATER_FLOW3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_WATER_FLOW_VAL3)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_WATER_FLOW4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_WATER_FLOW_VAL4)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_CHILLER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CHILLER_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CHILLER2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CHILLER_VAL2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CHILLER3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CHILLER_VAL3)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CHILLER4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CHILLER_VAL4)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HUMIDITY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HUMIDITY_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TEMP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TEMP_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DEW)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DEW_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOTOR)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_CURRENT_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CURRENT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VOLTAGE_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VOLTAGE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_VACUUM1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VACUUM1_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VACUUM2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_VACUUM2_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUST)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DUST_VAL)->SetFont( &m_fntStatic );

	if(!gProcessINI.m_sProcessOption.bTemperCompensationMode)
	{
		GetDlgItem(IDC_STATIC_TEMP2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_SB_TEMP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_MPA10)->ShowWindow(SW_HIDE);
	}
}


void CPaneAutoRunViewStatus::ChangeDisplay()
{
	CString str; 
	double dVal = 0 , dVal2 = 0 , dVal3 = 0, dVal4 = 0, dVal5 = 0, dVal6 = 0;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	BOOL bSwitch = pMotor->IsResetSwitch();
	if(bSwitch)
	{
		m_bWaterFlowErrorOld = m_bWaterFlowError= FALSE;
		m_nErrorCount = 0;
	}
	
	int nValue = pMotor->GetMainAirValue();
#ifdef __KUNSAN_SAMSUNG_LARGE__
	dVal = ((nValue - 156) / 6.)/100;
	str.Format(_T("%.2f"), dVal );
	GetDlgItem(IDC_STATIC_MAIN_AIR_VAL)->SetWindowText(str);
	gOPCParam.dMainAir = dVal;
#else
	str.Format(_T("%.1f"), ((nValue - 169) / 670.0) );
	GetDlgItem(IDC_STATIC_MAIN_AIR_VAL)->SetWindowText(str);
#endif

	int nWaterFlow1Value = pMotor->GetWaterFlow1Value();
	int nWaterFlow2Value = pMotor->GetWaterFlow2Value();

	int nAOMWaterFlow1Value = pMotor->GetAOMWaterFlow1Value();
	int nLaserWaterFlowValue = pMotor->GetLaserWaterFlowValue();
	
	dVal = gSystemINI.m_sSystemDevice.dWaterFlowOffsetSetting1;
	dVal2 = gSystemINI.m_sSystemDevice.dWaterFlowOffsetSetting2;
	dVal3 = gSystemINI.m_sSystemDevice.dWaterFlowOffsetSetting3;
	dVal4 = gSystemINI.m_sSystemDevice.dWaterFlowOffsetSetting4;
	
	/*str.GetBuffer(256);
	str.Format(_T("%.2f"), ((nWaterFlow1Value + dVal - 156) / 156) );
	GetDlgItem(IDC_STATIC_WATER_FLOW_VAL)->SetWindowText(str);

	str.Format(_T("%.2f"), ((nWaterFlow2Value + dVal2 - 156) / 156) );
	GetDlgItem(IDC_STATIC_WATER_FLOW_VAL2)->SetWindowText(str);

	str.Format(_T("%.2f"), ((nAOMWaterFlow1Value + dVal3 - 156) / 156) );
	GetDlgItem(IDC_STATIC_WATER_FLOW_VAL3)->SetWindowText(str);

	str.Format(_T("%.2f"), ((nLaserWaterFlowValue + dVal4 - 156) / 156 * 4) );
	GetDlgItem(IDC_STATIC_WATER_FLOW_VAL4)->SetWindowText(str);*/

	m_dWaterFlow1 = ((nWaterFlow1Value + dVal - 156) / 6.0);
	m_dWaterFlow2 = ((nWaterFlow2Value + dVal2 - 156) / 6.0);


	m_dWaterFlowAom = ((nAOMWaterFlow1Value + dVal3 - 156) / 156);
	m_dWaterFlowLaser = ((nLaserWaterFlowValue + dVal4 - 156) / 156);

//#ifdef __TEST__
//	m_dWaterFlow1 = 3.0;
//	m_dWaterFlow2 = 3.0;
//	m_dWaterFlowAom = 3.0;
//	m_dWaterFlowLaser = 3.0;
//#endif
	//gOPCParam.dWaterFlow[0] = m_dWaterFlow1;
	//gOPCParam.dWaterFlow[1] = m_dWaterFlow2;
	//gOPCParam.dSetWaterFlow[0] = dVal;
	//gOPCParam.dSetWaterFlow[1] = dVal2;

	if(gProcessINI.m_sProcessOption.bWaterFlowErrorCheck)
	{
		if((gProcessINI.m_sProcessOption.dWaterFlowLaser > m_dWaterFlowLaser) || /*(gProcessINI.m_sProcessOption.dWaterFlowAom > m_dWaterFlowAom) ||*/
			(gProcessINI.m_sProcessOption.dWaterFlowScanner1 > m_dWaterFlow1) || (gProcessINI.m_sProcessOption.dWaterFlowScanner2 > m_dWaterFlow2))
		{
			m_bWaterFlowError = TRUE;
			m_nErrorCount++;
		}
		else
		{
			m_bWaterFlowError = FALSE;
			m_nErrorCount = 0;
		}
		if(m_nErrorCount >= 10)
		{
			m_nErrorCount = 10;
			if(m_bWaterFlowError != m_bWaterFlowErrorOld)
			{
				m_bWaterFlowErrorOld = m_bWaterFlowError;
				if(m_bWaterFlowError == TRUE)
				{
					if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->IsDrilling())
					{
						::AfxGetMainWnd()->SendMessage( DRILL_STOP, TRUE );
					}
					ErrMsgDlg(STDGNALM429);
				}
			}
		}
	}


	//gOPCParam.dAOMWaterFlow[0] = dAOM1WaterFlowValue;
	//gOPCParam.dAOMWaterFlow[1] = dAOM2WaterFlowValue;
	
	int nConnectIndex = 0;
	if(gSystemINI.m_sHardWare.bHumidityConnect)
	{
		if(gSystemINI.m_sHardWare.bVoltageConnect && gSystemINI.m_sHardWare.bHumidityConnect)
		{
			dVal2 = gDeviceFactory.GetMotor()->GetVolateSubData(nConnectIndex++) / 10.;
			dVal = gDeviceFactory.GetMotor()->GetVolateSubData(nConnectIndex++) / 10.;
		}
		else
			gDeviceFactory.GetMotor()->GetHumiTempDew(dVal, dVal2, dVal3);

		if(gSystemINI.m_sHardWare.bVoltageConnect && gSystemINI.m_sHardWare.bChillerConnect)
		{
#ifndef __FST_CHILLER_TYPE__
			dVal3 = gDeviceFactory.GetMotor()->GetVolateSubData(nConnectIndex++) / 10.; //chiller 1 
			dVal4 = gDeviceFactory.GetMotor()->GetVolateSubData(nConnectIndex++) / 10.; //chiller 1 set
			dVal5 = gDeviceFactory.GetMotor()->GetVolateSubData(nConnectIndex++) / 10.;//chiller 2
			dVal6 = gDeviceFactory.GetMotor()->GetVolateSubData(nConnectIndex) / 10.; //chiller 3 set
#endif
		}
		else
			dVal3 = gDeviceFactory.GetMotor()->GetChillerTemp();
	}

#ifdef __FST_CHILLER_TYPE__

	if(gSystemINI.m_sHardWare.bChillerConnect)
	{
		double dTemp= 0;
		double dFlow1, dFlow2;
		double dPressure1, dPressure2;
		gDeviceFactory.GetMotor()->GetChillerTemp(1,dTemp,dFlow1,dPressure1);
		dVal3 = dTemp;
		dVal4 = gSystemINI.m_sSystemDevice.sChillerPort.dCH1;
		gDeviceFactory.GetMotor()->GetChillerTemp(2,dTemp,dFlow2,dPressure2);
		dVal5 = dTemp;
		dVal6 = gSystemINI.m_sSystemDevice.sChillerPort.dCH2;

		gVariable.m_dGlobalChillerTemp1 = dVal3;
		gVariable.m_dGlobalChillerTemp2 = dVal5;

		gVariable.m_dGlobalChillerPressure1 = dPressure1;
		gVariable.m_dGlobalChillerPressure2 = dPressure2;

		gVariable.m_dGlobalChillerFlow1 = dFlow1;
		gVariable.m_dGlobalChillerFlow2 = dFlow2;
	}

#endif
	str.Format(_T("%.1f"), gVariable.m_dGlobalChillerFlow1);
	GetDlgItem(IDC_STATIC_WATER_FLOW_VAL)->SetWindowText(str);

	str.Format(_T("%.1f"), gVariable.m_dGlobalChillerFlow2);
	GetDlgItem(IDC_STATIC_WATER_FLOW_VAL2)->SetWindowText(str);

	str.Format(_T("%.1f"), gVariable.m_dGlobalChillerPressure1);
	GetDlgItem(IDC_STATIC_CHILLER_PRESSURE1_VAL)->SetWindowText(str);

	str.Format(_T("%.1f"), gVariable.m_dGlobalChillerPressure2);
	GetDlgItem(IDC_STATIC_CHILLER_PRESSURE2_VAL)->SetWindowText(str);

	str.Format(_T("%.1f"), gVariable.m_dGlobalChillerFlow2);
	GetDlgItem(IDC_STATIC_WATER_FLOW_VAL2)->SetWindowText(str);

	str.Format(_T("%.1f"), dVal );
	GetDlgItem(IDC_STATIC_HUMIDITY_VAL)->SetWindowText(str);
	m_dHumidity = dVal;
	gOPCParam.dHumidity = dVal;

	str.Format(_T("%.1f"), dVal2 );
	GetDlgItem(IDC_STATIC_TEMP_VAL)->SetWindowText(str);
	m_dTemperatur = dVal2;
	gOPCParam.dTemp = dVal2;
	
	m_dChillerTemp1 = dVal3; 
	str.Format(_T("%.1f"), dVal3);
	GetDlgItem(IDC_STATIC_CHILLER_VAL)->SetWindowText(str);
	str.Format(_T("%.1f"), dVal4);
	GetDlgItem(IDC_STATIC_CHILLER_VAL3)->SetWindowText(str);
	gOPCParam.dChillerTemp[0] = dVal3;
	gOPCParam.dSetChillerTemp[0] = dVal4;

	m_dChillerTemp2 = dVal5; 
	str.Format(_T("%.1f"), dVal5);
	GetDlgItem(IDC_STATIC_CHILLER_VAL2)->SetWindowText(str);
	str.Format(_T("%.1f"), dVal6);
	GetDlgItem(IDC_STATIC_CHILLER_VAL4)->SetWindowText(str);
	gOPCParam.dChillerTemp[1] = dVal5;
	gOPCParam.dSetChillerTemp[1] = dVal6;

//	str.Format(_T("%.1f"), dVal3 );
//	GetDlgItem(IDC_STATIC_DEW_VAL)->SetWindowText(str);

	gDeviceFactory.GetMotor()->GetVoltage(dVal, dVal2, dVal3);
	m_dCurrent = dVal;
	m_dVoltage = dVal2;
	m_dPower = dVal3;
	gOPCParam.dCurrent = dVal;
	gOPCParam.dVoltage = dVal2;
	gOPCParam.dPower = dVal3;

	str.Format(_T("%.2f"), dVal2 );
	GetDlgItem(IDC_STATIC_CURRENT_VAL)->SetWindowText(str);

	str.Format(_T("%.2f"), dVal );
	GetDlgItem(IDC_STATIC_VOLTAGE_VAL)->SetWindowText(str);

	str.Format(_T("%.2f"), dVal3 );
	GetDlgItem(IDC_STATIC_POWER_VAL)->SetWindowText(str);


#ifdef __KUNSAN_SAMSUNG_LARGE__
	nValue = gDeviceFactory.GetMotor()->GetTableVauumValue(TRUE);
	str.Format(_T("%.1f"), ((nValue - 156) / 6.0) + gSystemINI.m_sSystemVacuum.dVacuumOffset);
	GetDlgItem(IDC_STATIC_VACUUM1_VAL)->SetWindowText(str);
	m_dTableVacuum1 = (nValue - 156) / 6.0 + gSystemINI.m_sSystemVacuum.dVacuumOffset;
	gOPCParam.dVacuum[0] = m_dTableVacuum1;
	gOPCParam.dSetVacuum[0] = gSystemINI.m_sSystemDevice.dTableVacuumSetting1;

	nValue = gDeviceFactory.GetMotor()->GetTableVauumValue(FALSE);
	str.Format(_T("%.1f"), ((nValue - 156) / 6.0) + gSystemINI.m_sSystemVacuum.dVacuumOffset2);
	GetDlgItem(IDC_STATIC_VACUUM2_VAL)->SetWindowText(str);
	m_dTableVacuum2 = (nValue - 156) / 6.0 + gSystemINI.m_sSystemVacuum.dVacuumOffset2;
	gOPCParam.dVacuum[1] = m_dTableVacuum2;
	gOPCParam.dSetVacuum[1] = gSystemINI.m_sSystemDevice.dTableVacuumSetting2;

	nValue = gDeviceFactory.GetMotor()->GetDustSuctionValue();
	str.Format(_T("%.1f"), ((nValue - 156) / 6.0) + gSystemINI.m_sSystemVacuum.dSuctionHoodOffset);
	GetDlgItem(IDC_STATIC_DUST_VAL)->SetWindowText(str);
	m_dDustSuction = nValue;
	gOPCParam.dDustSuction  = nValue;
	gOPCParam.dSetDustSuction = gSystemINI.m_sSystemDevice.dDustSuctionSetting; 
#endif

	if(gProcessINI.m_sProcessOption.bTemperCompensationMode && gSystemINI.m_sHardWare.bTemperCompConnect)
	{
		double dVals[10];
		gDeviceFactory.GetMotor()->GetTemperatureForAllCh(dVals);
		str.Format(_T("M %.1f %.1f, S %.1f %.1f"), dVals[gProcessINI.m_sProcessOption.nTCMasterCH1], 
			dVals[gProcessINI.m_sProcessOption.nTCMasterCH2], 
			dVals[gProcessINI.m_sProcessOption.nTCSlaveCH1], 
			dVals[gProcessINI.m_sProcessOption.nTCSlaveCH2]);
		GetDlgItem(IDC_STATIC_SB_TEMP)->SetWindowText(str);

		if(gProcessINI.m_sProcessOption.bTemperDetailLog)
		{
			CString strFile;
			strFile.Format(_T("TemperAll"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
		}
		memcpy(m_dOldVals, dVals, sizeof(dVals));
		gOPCParam.dScannerTemp[0] = dVals[gProcessINI.m_sProcessOption.nTCMasterCH1];
		gOPCParam.dScannerTemp[1] = dVals[gProcessINI.m_sProcessOption.nTCSlaveCH1];
	}

	str.ReleaseBuffer();
}

HBRUSH CPaneAutoRunViewStatus::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	if( GetDlgItem(IDC_STATIC_MOTOR)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0, 0, 255) );

	return hbr;
}

void CPaneAutoRunViewStatus::SaveStatus()
{
	int nIndex = 0, nSecondIndex = 0;
	CString str1;
	CString strPath;
	CTime curDate = CTime::GetCurrentTime();
	strPath.GetBuffer(512);
	strPath.Format(_T("%s\\Status_%d%02d%02d.txt"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), curDate.GetYear(), curDate.GetMonth(), curDate.GetDay());
	strPath.ReleaseBuffer();
	//�켱 ���� �˻�
	BOOL bExist;
	CFileFind find;
	bExist = find.FindFile((LPCTSTR)strPath);
	
	CString strBuf;
	strBuf.GetBuffer(512);
	CStdioFile file;
	if(FALSE == file.Open(strPath,CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite))
	{
		strBuf.ReleaseBuffer();
		return ;
	}
	
	TRY 
	{
		if(!bExist)
		{
			strBuf.Format(_T("Date\t\t| Time\t\t| MainAir\t| WaterFlow1\t| WaterFlow2\t| ChillerTemp1\t| ChillerTemp2\t| Humidity\t| Temperature\t| Current\t| Voltage\t| Power\t\t| Vacuum1\t| Vacuum2\t| DustSuction\n"));
			file.Write(strBuf, strBuf.GetLength());
		}
		file.SeekToEnd();
	
		strBuf.Format(_T("%04d/%02d/%02d\t| %02d:%02d:%02d\t| %.1f\t\t| %.1f\t\t| %.1f\t\t| %.1f\t\t| %.1f\t\t| %.1f\t\t| %.1f\t\t| %.1f\t\t| %.1f\t\t| %.1f\t\t| %.1f\t\t| %.1f\t\t| %.1f \n"),
		curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
		curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
		m_dMainAir, m_dWaterFlow1, m_dWaterFlow2, 
		m_dChillerTemp1,m_dChillerTemp2, m_dHumidity, m_dTemperatur,
		m_dCurrent, m_dVoltage, m_dPower,
		m_dTableVacuum1, m_dTableVacuum2, m_dDustSuction);
		
		strBuf.ReleaseBuffer();
		file.Write(strBuf, strBuf.GetLength());
	}
	CATCH (CMemoryException, e)
	{
		file.Close();
		e->Delete();
		return;
	}
	END_CATCH
		
	file.Close();
}

BOOL CPaneAutoRunViewStatus::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Add your specialized code here and/or call the base class
	CFormView::PreCreateWindow(cs);
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	return TRUE;
}

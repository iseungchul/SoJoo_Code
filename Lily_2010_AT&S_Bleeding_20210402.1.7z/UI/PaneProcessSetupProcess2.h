#if !defined(AFX_PANEPROCESSSETUPPROCESS2_H__908537A7_AFF3_431F_B901_036264887637__INCLUDED_)
#define AFX_PANEPROCESSSETUPPROCESS2_H__908537A7_AFF3_431F_B901_036264887637__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneProcessSetupProcess2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupProcess2 form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "..\model\globalvariable.h"

class CPaneProcessSetupProcess2 : public CFormView
{
protected:
	CPaneProcessSetupProcess2();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneProcessSetupProcess2)

// Form Data
public:
	//{{AFX_DATA(CPaneProcessSetupProcess2)
	enum { IDD = IDD_DLG_PROCESS_SETUP_PROCESS2 };

	CColorEdit	m_edtLP1Up;
	CColorEdit	m_edtLP1Align;
	CColorEdit	m_edtLP1Table;
	CColorEdit	m_edtLP2Up;
	CColorEdit	m_edtLP2Align;
	CColorEdit	m_edtLP2Table;
	CColorEdit	m_edtLP2Cart;
	CColorEdit	m_edtUP1Up;
	CColorEdit	m_edtUP1Align;
	CColorEdit	m_edtUP1Table;
	CColorEdit	m_edtUP2Up;
	CColorEdit	m_edtUP2Align;
	CColorEdit	m_edtUP2Table;
	CColorEdit	m_edtUP1Cart;

	UEasyButtonEx	m_btnLP1Up;
	UEasyButtonEx	m_btnLP1Align;
	UEasyButtonEx	m_btnLP1Table;
	UEasyButtonEx	m_btnLP2Up;
	UEasyButtonEx	m_btnLP2Align;
	UEasyButtonEx	m_btnLP2Table;
	UEasyButtonEx	m_btnLP2Cart;
	UEasyButtonEx	m_btnUP1Up;
	UEasyButtonEx	m_btnUP1Align;
	UEasyButtonEx	m_btnUP1Table;
	UEasyButtonEx	m_btnUP2Up;
	UEasyButtonEx	m_btnUP2Align;
	UEasyButtonEx	m_btnUP2Table;
	UEasyButtonEx	m_btnUP2Cart;

	//}}AFX_DATA

// Attributes
public:

// Attributes
protected :
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	CFont			m_fntBtn;
	CFont			m_fntList;
	CFont			m_fntCombo;

	SAUTOSETTING	m_sAutoSetting;

// Operations
public:
	void SetToolComboBox();
	CString GetChangeValueStr();
	void InitStaticControl();
	void InitEditControl();
	void InitBtnControl();
	void InitListControl();
	void InitComboControl();

	void SetProcessPosition(SAUTOSETTING sAutoSetting);
	void GetProcessPosition(SAUTOSETTING* pAutoSetting);
	void DispProcessPosition();
	BOOL OnApply();
	
	void EnableControl(BOOL bUse);
	void EnableBtnControl(BOOL nLevel);
	void SetAuthorityByLevel(int nLevel);


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneProcessSetupProcess2)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneProcessSetupProcess2();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneProcessSetupProcess2)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:

	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedButtonLP1Up();
	afx_msg void OnBnClickedButtonLP1Align();
	afx_msg void OnBnClickedButtonLP1Table();
	afx_msg void OnBnClickedButtonLP2Up();
	afx_msg void OnBnClickedButtonLP2Align();
	afx_msg void OnBnClickedButtonLP2Table();
	afx_msg void OnBnClickedButtonLP2Cart();
	afx_msg void OnBnClickedButtonUP1Up();
	afx_msg void OnBnClickedButtonUP1Align();
	afx_msg void OnBnClickedButtonUP1Table();
	afx_msg void OnBnClickedButtonUP2Up();
	afx_msg void OnBnClickedButtonUP2Align();
	afx_msg void OnBnClickedButtonUP2Table();
	afx_msg void OnBnClickedButtonUP2Cart();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEPROCESSSETUPPROCESS_H__908537A7_AFF3_431F_B901_036264887637__INCLUDED_)

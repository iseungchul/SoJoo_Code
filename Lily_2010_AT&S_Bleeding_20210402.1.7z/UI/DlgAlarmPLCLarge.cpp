// DlgAlarmPLCLarge.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgAlarmPLCLarge.h"
#include "..\device\hdevicefactory.h"
#include "..\device\devicemotor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgAlarmPLCPusan1 dialog


CDlgAlarmPLCLarge::CDlgAlarmPLCLarge(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgAlarmPLCLarge::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgAlarmPLCPusan2)
		// NOTE: the ClassWizard weill add member initialization here
	m_bOnTimer = FALSE;
	m_nMsg = 0;
	m_nTimerID = 0;
	m_nMaxError = 30;
	//}}AFX_DATA_INIT
}


void CDlgAlarmPLCLarge::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgAlarmPLCPusan2)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_LIST_ALARM, m_ctrlListMsg);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgAlarmPLCLarge, CDialog)
	//{{AFX_MSG_MAP(CDlgAlarmPLCLarge)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgAlarmPLCLarge message handlers


BOOL CDlgAlarmPLCLarge::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	for(int i=0; i<m_nMaxError; i++)
		m_strMsg[i] = _T("");
//		m_strMsg[i].Format(_T(""));
	
	m_ctrlListMsg.SetExtendedStyle(m_ctrlListMsg.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY | LVS_EX_GRIDLINES);
	InitListCtrl();
	m_lErrorNew = m_lErrorOld = 0;
	m_nTimerID = SetTimer(1212, 500, NULL);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgAlarmPLCLarge::InitListCtrl()
{
	m_ctrlListMsg.DeleteAllItems();
	
	m_ctrlListMsg.DeleteColumn(0);
	
	TCHAR* ColumnHeadText = _T("Message");
	
	int ColumnHeadSize = 422;
	
	//  List control�� Column ����
	m_ctrlListMsg.InsertColumn(0, _T(""), LVCFMT_CENTER, 1);
	LV_COLUMN lvcolumn;

	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_CENTER;
	lvcolumn.pszText = ColumnHeadText;
	lvcolumn.iSubItem = 0;
	lvcolumn.cx = ColumnHeadSize;
	m_ctrlListMsg.InsertColumn(1, &lvcolumn);

	AddItems();
}

void CDlgAlarmPLCLarge::AddItems()
{
	m_ctrlListMsg.DeleteAllItems();
	
	for(int i=0; i<m_nMaxError; i++)
	{
		m_ctrlListMsg.InsertItem(i, _T(""));

//		m_strMsg[i].Format(_T("msg #%d"), i+1);

		_stprintf_s(m_szText, "%s", m_strMsg[i]);
		m_ctrlListMsg.SetItemText(i, 1, m_szText);
	}
}

void CDlgAlarmPLCLarge::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_bOnTimer == TRUE)
	{
		CDialog::OnTimer(nIDEvent);
		return;
	}
	m_bOnTimer = TRUE;

	UpdateMsg();
	
	m_bOnTimer = FALSE;
	CDialog::OnTimer(nIDEvent);
}

void CDlgAlarmPLCLarge::UpdateMsg()
{
	m_nMsg = 0;

	BOOL bChange = FALSE;

//	for(int j=0; j<m_nMaxError; j++)
//		m_strMsg[j] = _T("");

	m_lErrorIoNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_IO);
	if (m_lErrorIoNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorIoNew;
		GetIoErrorMsg();
	}
	
#ifndef __ADD_MELSEC_MOTOR__
	m_lErrorLoadNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_LOAD);
	if (m_lErrorLoadNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorLoadNew;
		if(m_nMsg < m_nMaxError)
			GetLoadErrorMsg();
	}
	
	m_lErrorLoad2New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_LOAD2);
	if (m_lErrorLoad2New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorLoad2New;
		if(m_nMsg < m_nMaxError)
			GetLoad2ErrorMsg();
	}

	m_lErrorLoad3New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_LOAD3);
	if (m_lErrorLoad3New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorLoad3New;
		if(m_nMsg < m_nMaxError)
			GetLoad3ErrorMsg();
	}
	
	m_lErrorUnloadNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_UNLOAD);
	if (m_lErrorUnloadNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorUnloadNew;
		if(m_nMsg < m_nMaxError)
			GetUnloadErrorMsg();
	}

	m_lErrorUnload2New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_UNLOAD2);
	if (m_lErrorUnload2New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorUnload2New;
		if(m_nMsg < m_nMaxError)
			GetUnload2ErrorMsg();
	}

	m_lErrorUnload3New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_UNLOAD3);
	if (m_lErrorUnload3New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorUnload3New;
		if(m_nMsg < m_nMaxError)
			GetUnload3ErrorMsg();
	}
#endif
	
	m_lErrorTableLimitNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_TABLELIMIT);
	if (m_lErrorTableLimitNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorTableLimitNew;
		if(m_nMsg < m_nMaxError)
			GetTableLimitErrorMsg();
	}
	
	m_lErrorOtherLimitNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERLIMIT);
	if (m_lErrorOtherLimitNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorOtherLimitNew;
		if(m_nMsg < m_nMaxError)
			GetOtherLimitErrorMsg();
	}
	
	m_lErrorLaserNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_LASER);
	if (m_lErrorLaserNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorLaserNew;
		if(m_nMsg < m_nMaxError)
			GetLaserErrorMsg();
	}

	//m_lErrorOthersNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS);
	//if (m_lErrorOthersNew != 0)
	//{
	//	bChange = TRUE;
	//	m_lErrorNew += m_lErrorOthersNew;
	//	if(m_nMsg < m_nMaxError)
	//		GetOthersErrorMsg();
	//}

	//m_lErrorOthers2New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS2);
	//if (m_lErrorOthers2New != 0)
	//{
	//	bChange = TRUE;
	//	m_lErrorNew += m_lErrorOthers2New;
	//	if(m_nMsg < m_nMaxError)
	//		GetOthers2ErrorMsg();
	//}

	//m_lErrorOthers3New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS3);
	//if (m_lErrorOthers3New != 0)
	//{
	//	bChange = TRUE;
	//	m_lErrorNew += m_lErrorOthers3New;
	//	if(m_nMsg < m_nMaxError)
	//		GetOthers3ErrorMsg();
	//}

	//m_lErrorOthers4New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS4);
	//if (m_lErrorOthers4New != 0)
	//{
	//	bChange = TRUE;
	//	m_lErrorNew += m_lErrorOthers4New;
	//	if(m_nMsg < m_nMaxError)
	//		GetOthers4ErrorMsg();
	//}
	//
	//m_lErrorOthers5New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS5);
	//if (m_lErrorOthers5New != 0)
	//{
	//	bChange = TRUE;
	//	m_lErrorNew += m_lErrorOthers5New;
	//	if(m_nMsg < m_nMaxError)
	//		GetOthers5ErrorMsg();
	//}


	m_lErrorLoaderPicker1New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_LOADER_PICKER1);
	if (m_lErrorLoaderPicker1New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorLoaderPicker1New;
		if(m_nMsg < m_nMaxError)
			GetLoaderPicker1ErrorMsg();
	}
	m_lErrorUnLoaderPicker1New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_UNLOADER_PICKER1);
	if (m_lErrorUnLoaderPicker1New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorUnLoaderPicker1New;
		if(m_nMsg < m_nMaxError)
			GetUnLoaderPicker1ErrorMsg();
	}

/*	m_lErrorOthers6New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_OTHERS6);
	if (m_lErrorOthers6New != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorOthers6New;
		if(m_nMsg < m_nMaxError)
			GetOthers6ErrorMsg();
	}
*/
	m_lErrorTableNew = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_TABLE);
	if (m_lErrorTableNew != 0)
	{
		bChange = TRUE;
		m_lErrorNew += m_lErrorTableNew;
		if(m_nMsg < m_nMaxError)
			GetTableErrorMsg();
	}

	m_lErrorMelsec1060New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_HANDLER_1060);
	if(m_lErrorMelsec1060New != 0)
	{		
		bChange = TRUE;
		m_lErrorNew += m_lErrorMelsecEtc1New;
		if(m_nMsg < m_nMaxError)
			ReadErrorMelsec1060Msg();
	}

	m_lErrorMelsec1061New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_HANDLER_1061);
	if(m_lErrorMelsec1061New != 0)
	{		
		bChange = TRUE;
		m_lErrorNew += m_lErrorMelsecEtc1New;
		if(m_nMsg < m_nMaxError)
			ReadErrorMelsec1061Msg();
	}

	m_lErrorMelsec1062New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_HANDLER_1062);
	if(m_lErrorMelsec1062New != 0)
	{		
		bChange = TRUE;
		m_lErrorNew += m_lErrorMelsecEtc1New;
		if(m_nMsg < m_nMaxError)
			ReadErrorMelsec1062Msg();
	}

	m_lErrorMelsec1063New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_HANDLER_1063);
	if(m_lErrorMelsec1063New != 0)
	{		
		bChange = TRUE;
		m_lErrorNew += m_lErrorMelsecEtc1New;
		if(m_nMsg < m_nMaxError)
			ReadErrorMelsec1063Msg();
	}

	m_lErrorMelsec1064New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_HANDLER_1064);
	if(m_lErrorMelsec1064New != 0)
	{		
		bChange = TRUE;
		m_lErrorNew += m_lErrorMelsecEtc1New;
		if(m_nMsg < m_nMaxError)
			ReadErrorMelsec1064Msg();
	}

	m_lErrorMelsec1065New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_HANDLER_1065);
	if(m_lErrorMelsec1065New != 0)
	{		
		bChange = TRUE;
		m_lErrorNew += m_lErrorMelsecEtc1New;
		if(m_nMsg < m_nMaxError)
			ReadErrorMelsec1065Msg();
	}

	m_lErrorMelsec1066New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_HANDLER_1066);
	if(m_lErrorMelsec1066New != 0)
	{		
		bChange = TRUE;
		m_lErrorNew += m_lErrorMelsecEtc1New;
		if(m_nMsg < m_nMaxError)
			ReadErrorMelsec1066Msg();
	}

	m_lErrorMelsec1067New = gDeviceFactory.GetMotor()->GetCurrentError(ERROR_HANDLER_1067);
	if(m_lErrorMelsec1067New != 0)
	{		
		bChange = TRUE;
		m_lErrorNew += m_lErrorMelsecEtc1New;
		if(m_nMsg < m_nMaxError)
			ReadErrorMelsec1067Msg();
	}

	if(m_nMsg < 1 && !bChange && m_lErrorNew == m_lErrorOld) 
		return;
	
	m_lErrorOld = m_lErrorNew;
	m_lErrorNew = 0;
	
	for(int i=0; i<m_nMaxError; i++)
	{
		lstrcpy(m_szText, (LPCTSTR)m_strMsg[i]);
		m_ctrlListMsg.SetItemText(i, 1, m_szText);
	}
}

void CDlgAlarmPLCLarge::GetIoErrorMsg()
{
	if(m_lErrorIoNew & 0x0001) // em stop
	{	
		m_strMsg[m_nMsg++] = "[MB6100] EM Stop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0002) // servo power off
	{
		m_strMsg[m_nMsg++] = "[MB6101] ServoPower Off";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0004) // main station initial error
	{
		m_strMsg[m_nMsg++] = "[MB6102] Main InitErr";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0010) // Front Door Open
	{
		m_strMsg[m_nMsg++] = "[MB6104] FrontDoor Open";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0020) // Rear Door Open
	{
		m_strMsg[m_nMsg++] = "[MB6105] RearDoor Open";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0040) // LaserPower Off
	{
		m_strMsg[m_nMsg++] = "[MB6107] LaserPower Off";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0080) // MainAir Error
	{
		m_strMsg[m_nMsg++] = "[MB6108] MainAir Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0100) // HeightSensor Up Error
	{
		m_strMsg[m_nMsg++] = "[MB6132] HeightSensor UpErr";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0200) // HeightSensor Down Error
	{
		m_strMsg[m_nMsg++] = "[MB6133] HeightSensor DownErr";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0400) // LoaderDoor Open
	{
		m_strMsg[m_nMsg++] = "[MB6207] LoaderDoor Open";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x0800) // UnloaderDoor Open
	{
		m_strMsg[m_nMsg++] = "[MB6307] UnloaderDoor Open";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x1000) // Shutter1 open error
	{
		m_strMsg[m_nMsg++] = "[MB6128] 1stShutter OpenErr";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x2000) // Shutter1 close error
	{
		m_strMsg[m_nMsg++] = "[MB6129] 1stShutter CloseErr";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x4000) // Shutter2 open error
	{
		m_strMsg[m_nMsg++] = "[MB6130] 2ndShutter OpenErr";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x8000) // Shutter2 close error
	{
		m_strMsg[m_nMsg++] = "[MB6131] 2ndShutter CloseErr";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorIoNew & 0x10000) // MainDoor Inout Sensor Alarm
	{
		m_strMsg[m_nMsg++] = "[MB5412] MainDoor Inout Sensor Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetLoadErrorMsg()
{
	if (m_lErrorLoadNew & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6263] Loader Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if (m_lErrorLoadNew & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6262] Loader Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[5210] LoadCart No PCB";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6201] L-Picker1 PCB Exist";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6202] L-Picker1 PCB NonExist";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6203] L-Picker2 PCB Exist";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6204]L-Picker2 PCB NonExist";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6200] Loader Init Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6206] L-AlignTable PCB NonExist";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6205] L-AlignTable PCB Exist";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6216] L-Picker1 Pad1 Up Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6217] L-Picker1 Pad1 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6218] L-Picker1 Pad1 Down2 Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	/*if(m_lErrorLoadNew & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6219] L-Picker1 Pad2 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	*/if(m_lErrorLoadNew & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6220] L-Picker1 Vacuum On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoadNew & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6221] L-Picker1 Vacuum Off Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetLoad2ErrorMsg()
{
	if(m_lErrorLoad2New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6222] L-Picker1 Blow On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6223] L-Picker2 Pad1 Up Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6224] L-Picker2 Pad1 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6225] L-Picker2 Pad1 Down2 Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6226] L-Picker2 Pad2 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6227] L-Picker2 Vacuum On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6228] L-Picker2 Vacuum Off Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6229] L-Picker2 Blow On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6232] L-Cart Clamp Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6233] L-Cart Unclamp Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6234] L-AlignSheetTable Forward Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6235] L-AlignSheetTable Backward Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6236] L-AlignGuide Forward Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6237] L-AlignGuide Backward Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6238] L-AlignTable Left Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad2New & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6239] L-AlignTable Right Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetLoad3ErrorMsg()
{
	if(m_lErrorLoad3New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6240] L-Elevator LoadPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6241] L-Elevator OriginPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6242] L-Elevator Sensor Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6245] LC CartPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6246] LC LoadPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6247] LC Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6248] LC Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6249] LC FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6250] LC OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6253] LC Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6208] L-Picker1 PCB Ready Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6209] L-Picker2 PCB Ready Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6243] Loader Cart Detect Sensor Err";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorLoad3New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6244] Loader Elv. Axis Limit Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6254] Loader No PCB Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6256] Loader Carrier Axis Stop Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x10000)
	{
		m_strMsg[m_nMsg++] = "[MB6215] Loader Picker Danger Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x20000)
	{
		m_strMsg[m_nMsg++] = "[MB6257] Loader Left Picker Fall PCB Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoad3New & 0x40000)
	{
		m_strMsg[m_nMsg++] = "[MB6254] LC Align Pos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetUnloadErrorMsg()
{
	if(m_lErrorUnloadNew & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6363] Unloader Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6362] Unloader Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6305] U-Table PCB Exist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6306] U-Table PCB NonExist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6302] U-Picker1 PCB NonExist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6301] U-Picker1 PCB Exist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6304] U-Picker2 PCB NonExist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6303] U-Picker2 PCB Exist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6316] U-Picker1 Pad1 Up Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6317] U-Picker1 Pad1 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6318]U-Picker1 Pad1 Down2 Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6319] U-Picker1 Pad2 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6320] U-Picker1 Vacuum On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6321] U-Picker1 Vacuum Off Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6322] U-Picker1 Blow On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnloadNew & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6323] U-Picker2 Pad1 Up Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetUnload2ErrorMsg()
{
	if(m_lErrorUnload2New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6325] U-Picker2 Pad1 Down2 Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
/*	if(m_lErrorUnload2New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6325] U-Picker2 Pad2 Up Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6326] U-Picker2 Pad2 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
*/	if(m_lErrorUnload2New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6327] U-Picker2 Vacuum On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6328] U-Picker2 Vacuum Off Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
/*	if(m_lErrorUnload2New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6329]U-Picker2 Blow On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
*/	if(m_lErrorUnload2New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6332] U-Cart Clamp Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6333] U-Cart Unclamp Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6338] U-AlignTable Left Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6339] U-AlignTable Right Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6340] U-Elevator LoadPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6341] U-Elevator OriginPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6342] U-Elevator Sensor Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6345] UC UnloadPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6346] UC CartPos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6347] UC Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload2New & 0x10000)
	{
		m_strMsg[m_nMsg++] = "[MB6354] UC Align Pos Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetUnload3ErrorMsg()
{
	if(m_lErrorUnload3New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6348] UC Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6349] UC FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6350] UC OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6353] UC Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6308] U-Picker1 PCB Ready Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6309] U-Picker2 PCB Ready Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6300] Unloader Init Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6343] Unloader Cart Detect Sensor Err";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorUnload3New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6344] Unloader Elv. Axis Limit Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6315] Unloader Picker Danger Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB5310] Unloader Cart PCB Full";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnload3New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6356] Unloader Carrier Axis Stop Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetTableLimitErrorMsg()
{
	if(m_lErrorTableLimitNew & 0x0001) // X+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6003] X (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0002) // X- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6004] X (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0004) // Y+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6011] Y (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0008) // Y- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6012] Y (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0040) // Z1+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6019] Z1 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0080) // Z1- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6020] Z1 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0100) // Z2+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6027] Z2 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0200) // Z2- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6028] Z2 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0400) // A1+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6258] A1 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x0800) // A1- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6259] A1 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x1000) // A2+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6358] A2 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableLimitNew & 0x2000) // A2- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6359 A2 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetOtherLimitErrorMsg()
{
	if(m_lErrorOtherLimitNew & 0x0001) // C1+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6051] BET1 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0002) // C1- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6052] BET1 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0004) // P1+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6251] LC (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0008) // P1- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6252] LC (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0010) // C2+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6059] BET2 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0020) // C2- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6060] BET2 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0040) // P2+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6351] UC (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0080) // P2- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6352] UC (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0100) // M1+ Limit
	{
		m_strMsg[m_nMsg++] = "[MB6035] M (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0200) // M1- Limit
	{
		m_strMsg[m_nMsg++] = "[MB6036] M (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0400) // A1 + Limit 
	{
		m_strMsg[m_nMsg++] = "[MB6067] A1 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x0800) // A1 - Limit 
	{
		m_strMsg[m_nMsg++] = "[MB6068] A1 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x1000) // A2 + Limit 
	{
		m_strMsg[m_nMsg++] = "[MB6075] A2 (+)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOtherLimitNew & 0x2000) // A2 - Limit 
	{
		m_strMsg[m_nMsg++] = "[MB6076] A2 (-)Limit";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetLaserErrorMsg()
{
	if(m_lErrorLaserNew & 0x0001) // Chiller Alarm
	{
		m_strMsg[m_nMsg++] = "[MB5425] Chiller On Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetTableErrorMsg()
{
	if(m_lErrorTableNew & 0x0001) // xy move danger error
	{
		m_strMsg[m_nMsg++] = "[MB6109] XY Move Danger";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0002) // xy stop error
	{
		m_strMsg[m_nMsg++] = "[MB6143] XY Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0004) // X Fault
	{
		m_strMsg[m_nMsg++] = "[MB6000] X Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0008) // X Fatal Following Err
	{
		m_strMsg[m_nMsg++] = "[MB6001] X FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0010) // X Open Loop
	{
		m_strMsg[m_nMsg++] = "[MB6002] X OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0020) // X Homing TimeOver
	{
		m_strMsg[m_nMsg++] = "[MB6005] X Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0040) // Y Fault
	{
		m_strMsg[m_nMsg++] = "[MB6008] Y Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0080) // Y Fatal Following Err
	{
		m_strMsg[m_nMsg++] = "[MB6009] Y FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0100) // Y Open Loop
	{
		m_strMsg[m_nMsg++] = "[MB6010] Y OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0200) // Y Homing TimeOver
	{
		m_strMsg[m_nMsg++] = "[MB6013] Y Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0400) // Z1 Fault
	{
		m_strMsg[m_nMsg++] = "[MB6016] Z1 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x0800) // Z1 Fatal Following Err
	{
		m_strMsg[m_nMsg++] = "[MB6017] Z1 FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x1000) // Z1 Open Loop
	{
		m_strMsg[m_nMsg++] = "[MB6018] Z1 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x2000) // Z1 Homing TimeOver
	{
		m_strMsg[m_nMsg++] = "[MB6021] Z1 Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x4000) // Z2 Fault
	{
		m_strMsg[m_nMsg++] = "[MB6024] Z2 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x8000) // Z2 Fatal Following Err
	{
		m_strMsg[m_nMsg++] = "[MB6025] Z2 FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorTableNew & 0x10000) // 
	{
		m_strMsg[m_nMsg++] = "[MB6007] X Axis Servo Drive Over Temperature Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorTableNew & 0x20000) // 
	{
		m_strMsg[m_nMsg++] = "[MB6015] Y Axis Servo Drive Over Temperature Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetOthersErrorMsg()
{
	if(m_lErrorOthersNew & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB5425] Chiller Unit Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}

	/*if(m_lErrorOthersNew & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6212] M1 Servo Drive Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6213] B1 Servo Drive Alarm ";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6214] B2 Servo Drive Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0008)
	{
//		m_strMsg[m_nMsg++] = "[MB6045] M2 Homing TimeOut";
//		if(m_nMsg > m_nMaxError-1) return;
	}
	*/
	
	

	if(m_lErrorOthersNew & 0x0008)//20171227
	{
		m_strMsg[m_nMsg++] = "[M6103] Light Curtain Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6124] Table1 Vacuum On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6125] Table1 Vacuum Off Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6126] Table2 Vacuum On Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6127] Table2 Vacuum Off Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6134] PowerDetector Sensor Forward Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6135] PowerDetector Sensor Backward Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6038] M1 Servo Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6054] BET1 Servo Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6062] BET2 Servo Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x2000) // Axis A1 Fault 
	{
		m_strMsg[m_nMsg++] = "[MB6064] Axis A1 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x4000) // Axis A1 Fatal Following Err 
	{
		m_strMsg[m_nMsg++] = "[MB6065] Axis A1 Following Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x8000) // Axis A1 Open Loop 
	{
		m_strMsg[m_nMsg++] = "[MB6066] Axis A1 Open Loop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	
	if(m_lErrorOthersNew & 0x40000) // Axis A1 Homing Time out  
	{
		m_strMsg[m_nMsg++] = "[MB6069] Axis A1 Homing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x80000) // Axis A1 Servo
	{
		m_strMsg[m_nMsg++] = "[MB6070] Axis A1 Servo Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthersNew & 0x100000) // Axis A1 Param
	{
		m_strMsg[m_nMsg++] = "[MB6164] Axis A1 Parameter Err";
		if(m_nMsg > m_nMaxError-1) return;
	}

}

void CDlgAlarmPLCLarge::GetOthers2ErrorMsg()
{
	if(m_lErrorOthers2New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6157] XY Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6158] Z1 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6159] Z2 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6160] M1 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6162] BET1 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6062] TableClamp1 Sensor Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6032] M1 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6033] M1 FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6034] M1 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6037] M1 Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6048] BET1 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6049] BET1 FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6050] BET1 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6053] BET1 Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6063] TableClamp2 Sensor Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6161] M2 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x00010000)
	{
		m_strMsg[m_nMsg++] = "[MB6163] BET2 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x00020000)
	{
		m_strMsg[m_nMsg++] = "[MB6058] BET2 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x00040000)
	{
		m_strMsg[m_nMsg++] = "[MB6061] BET2 Homing TimeOut";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers2New & 0x00080000)
	{
		m_strMsg[m_nMsg++] = "[MB6056] BET2 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorOthers2New & 0x00100000)
	{
		m_strMsg[m_nMsg++] = "[MB6057] BET2 FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetOthers3ErrorMsg()
{
	if(m_lErrorOthers3New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "[MB6144] Z1 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6145] Z1 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6146] Z2 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6147] Z2 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[MB6148] M1 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6149] M1 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6152] BET1 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6153] BET1 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
/*	if(m_lErrorOthers3New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6150] M2 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6151] M2 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6154] BET2 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6155] BET2 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6106] MPG On";
		if(m_nMsg > m_nMaxError-1) return;
	}
*/	if(m_lErrorOthers3New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6026] Z2 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6029] Z2 Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x10000) 
	{
		m_strMsg[m_nMsg++] = "[MB5557] AOM Off Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x10000) // Axis A2 Fault 
	{
		m_strMsg[m_nMsg++] = "[MB6072] Axis A2 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x20000) // Axis A2 Fatal Following Err 
	{
		m_strMsg[m_nMsg++] = "[MB6073] Axis A2 Following Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x40000) // Axis A2 Open Loop 
	{
		m_strMsg[m_nMsg++] = "[MB6074] Axis A2 Open Loop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x200000) // Axis A2 Homing Time out  
	{
		m_strMsg[m_nMsg++] = "[MB6077] Axis A2 Homing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x400000) // Axis A2 Servo
	{
		m_strMsg[m_nMsg++] = "[MB6078] Axis A2 Servo Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers3New & 0x800000) // Axis A2 Param
	{
		m_strMsg[m_nMsg++] = "[MB6165] Axis A2 Parameter Err";
		if(m_nMsg > m_nMaxError-1) return;
	} 
}

void CDlgAlarmPLCLarge::GetOthers4ErrorMsg()
{
	if(m_lErrorOthers4New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "[MB6112] 1stTable PCB Exist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "[MB6113] 1stTable PCB NotExist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "[MB6114] 2ndTable PCB Exist Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[D289] Dust Collector Vacuum Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6106] MPG On Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6054] Beam Pass Up/Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6055] Beam Pass Fwd/Bwd Err";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorOthers4New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "[MB6116] Suction Hood Open Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "[MB6117] Suction Hood Close Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "[MB6122] Height Sensor2 Up Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "[MB6123] Height Sensor2 Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "[MB6210] L-Picker Not AllUp";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6310] UL-Picker Not AllUp";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6123] HeightSensor2 Up/Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x8000)
	{
		m_strMsg[m_nMsg++] = "[MB6120] Tophat Fwd Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x10000)
	{
		m_strMsg[m_nMsg++] = "[MB6121] Tophat Bwd Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
/*	if(m_lErrorOthers4New & 0x20000)
	{
		m_strMsg[m_nMsg++] = "[MB6311] Laser System Warning Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	*/
	if(m_lErrorOthers4New & 0x40000)
	{
		m_strMsg[m_nMsg++] = "[MB6137] Beam Pass Down Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	
	

	if(m_lErrorOthers4New & 0x80000)
	{
		m_strMsg[m_nMsg++] = "[MB6139] Beam Pass Down2 Err";
		if(m_nMsg > m_nMaxError-1) return;
	}

/*	if(m_lErrorOthers4New & 0x100000) // Laser Over Temp Fault Error 
	{
		m_strMsg[m_nMsg++] = "[MB6146] Laser Over Temp Fault Err";
		if(m_nMsg > m_nMaxError-1) return;
	}*/
	if(m_lErrorOthers4New & 0x200000)
	{
		m_strMsg[m_nMsg++] = "[MB6103] Melsec UMac Disconnect Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers4New & 0x400000)
	{
		m_strMsg[m_nMsg++] = "[MB5431] Dust Suction Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetOthers5ErrorMsg()
{
	if(m_lErrorOthers5New & 0x0001) //A1 Fault
	{
		m_strMsg[m_nMsg++] = "[MB6255] Att1 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0002) //A1 Fatal Following Error
	{
		m_strMsg[m_nMsg++] = "[MB6256] Att1 FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0004) //A1 Open Loop
	{
		m_strMsg[m_nMsg++] = "[MB6257] Att1 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0008) //A1 Homing TimeOut
	{
		m_strMsg[m_nMsg++] = "[MB6260] Att1 Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorOthers5New & 0x0010) //A1 MovePosition Error
	{
		m_strMsg[m_nMsg++] = "[MB6038] Att1 MovePosition Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0020) //A1 Stop Error
	{
		m_strMsg[m_nMsg++] = "[MB6039] Att1 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0040) //A1 MotionParameter Error
	{
		m_strMsg[m_nMsg++] = "[MB6030] Att1 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0080) //A2 Fault
	{
		m_strMsg[m_nMsg++] = "[MB6355] Att2 Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorOthers5New & 0x0100) //A2 Fatal Following Error
	{
		m_strMsg[m_nMsg++] = "[MB6356] Att2 FatalFollowing Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0200) //A2 Open Loop
	{
		m_strMsg[m_nMsg++] = "[MB6357] Att2 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0400) //A2 Homing TimeOut
	{
		m_strMsg[m_nMsg++] = "[MB6360] Att2 Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x0800) //A2 MovePosition Error
	{
		m_strMsg[m_nMsg++] = "[MB6046] Att2 Move Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorOthers5New & 0x1000) //A2 Stop Error
	{
		m_strMsg[m_nMsg++] = "[MB6047] Att2 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers5New & 0x2000) //A2 MotionParameter Error
	{
		m_strMsg[m_nMsg++] = "[MB6031] Att2 Motion Param Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetOthers6ErrorMsg()
{
/*	if(m_lErrorOthers6New & 0x0001) //ATT1 Axis Servo Drive Alarm
	{
		m_strMsg[m_nMsg++] = "[MB6211] Att1 ServoDrive Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers6New & 0x0002) //ATT2 Axis Servo Drive Alarm
	{
		m_strMsg[m_nMsg++] = "[MB6212] Att2 ServoDrive Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers6New & 0x0004) //BET1 Axis Servo Drive Alarm
	{
		m_strMsg[m_nMsg++] = "[MB6213] BET1 ServoDrive Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers6New & 0x0008) //BET2 Axis Servo Drive Alarm
	{
		m_strMsg[m_nMsg++] = "[MB6214] BET2 ServoDrive Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorOthers6New & 0x0010) //Laser System Warning
	{
		m_strMsg[m_nMsg++] = "[MB6311] Laser System Warning";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorOthers6New & 0x0020) //Laser Over Temp Fault
	{
		m_strMsg[m_nMsg++] = "[MB6312] Laser OverTemp.Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
*/
}

void CDlgAlarmPLCLarge::GetLoaderPicker1ErrorMsg()
{


	if(m_lErrorLoaderPicker1New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "Loader Picker1 Axis Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoaderPicker1New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "Loader Picker1 Axis Fatal Following Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoaderPicker1New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "Loader Picker1 Axis Open Loop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoaderPicker1New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "Loader Picker1 Axis Positive Limit Over";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoaderPicker1New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[Loader Picker1 Axis Negative Limit Over";
		if(m_nMsg > m_nMaxError-1) return;
	}
	/*
	if(m_lErrorLoaderPicker1New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6149] M1 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoaderPicker1New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6152] BET1 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoaderPicker1New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6153] BET1 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	*/
	if(m_lErrorLoaderPicker1New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "Loader Picker2 Axis Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoaderPicker1New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "Loader Picker2 Axis Fatal Following Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoaderPicker1New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "Loader Picker2 Axis Open Loop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoaderPicker1New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "Loader Picker2 Axis Positive Limit Over";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoaderPicker1New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "Loader Picker2 Axis Negative Limit Over";
		if(m_nMsg > m_nMaxError-1) return;
	}
	/*
	if(m_lErrorLoaderPicker1New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6026] Z2 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoaderPicker1New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6029] Z2 Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorLoaderPicker1New & 0x10000) 
	{
	m_strMsg[m_nMsg++] = "[MB5557] AOM Off Alarm";
	if(m_nMsg > m_nMaxError-1) return;
	}
	*/
}
void CDlgAlarmPLCLarge::GetUnLoaderPicker1ErrorMsg()
{

		if(m_lErrorUnLoaderPicker1New & 0x0001)
	{
		m_strMsg[m_nMsg++] = "UnLoader Picker1 Axis Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnLoaderPicker1New & 0x0002)
	{
		m_strMsg[m_nMsg++] = "UnLoader Picker1 Axis Fatal Following Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnLoaderPicker1New & 0x0004)
	{
		m_strMsg[m_nMsg++] = "UnLoader Picker1 Axis Open Loop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnLoaderPicker1New & 0x0008)
	{
		m_strMsg[m_nMsg++] = "UnLoader Picker1 Axis Positive Limit Over";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnLoaderPicker1New & 0x0010)
	{
		m_strMsg[m_nMsg++] = "[Loader Picker1 Axis Negative Limit Over";
		if(m_nMsg > m_nMaxError-1) return;
	}
	/*
	if(m_lErrorUnLoaderPicker1New & 0x0020)
	{
		m_strMsg[m_nMsg++] = "[MB6149] M1 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnLoaderPicker1New & 0x0040)
	{
		m_strMsg[m_nMsg++] = "[MB6152] BET1 Position Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnLoaderPicker1New & 0x0080)
	{
		m_strMsg[m_nMsg++] = "[MB6153] BET1 Stop Err";
		if(m_nMsg > m_nMaxError-1) return;
	}
	*/
	if(m_lErrorUnLoaderPicker1New & 0x0100)
	{
		m_strMsg[m_nMsg++] = "UnLoader Picker2 Axis Fault";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnLoaderPicker1New & 0x0200)
	{
		m_strMsg[m_nMsg++] = "UnLoader Picker2 Axis Fatal Following Error";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnLoaderPicker1New & 0x0400)
	{
		m_strMsg[m_nMsg++] = "UnLoader Picker2 Axis Open Loop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnLoaderPicker1New & 0x0800)
	{
		m_strMsg[m_nMsg++] = "UnLoader Picker2 Axis Positive Limit Over";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnLoaderPicker1New & 0x1000)
	{
		m_strMsg[m_nMsg++] = "UnLoader Picker2 Axis Negative Limit Over";
		if(m_nMsg > m_nMaxError-1) return;
	}
	/*
	if(m_lErrorUnLoaderPicker1New & 0x2000)
	{
		m_strMsg[m_nMsg++] = "[MB6026] Z2 OpenLoop";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnLoaderPicker1New & 0x4000)
	{
		m_strMsg[m_nMsg++] = "[MB6029] Z2 Homing TimeOver";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorUnLoaderPicker1New & 0x10000) 
	{
	m_strMsg[m_nMsg++] = "[MB5557] AOM Off Alarm";
	if(m_nMsg > m_nMaxError-1) return;
	}
	*/

}
void CDlgAlarmPLCLarge::GetMelsecMainErrorMsg()
{
	// Empty 7000

	if(m_lErrorMelsecMainNew & 0x0002 )
	{
		m_strMsg[m_nMsg++] = "[R1060.0] EStop ALARM";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x0004 )
	{
		m_strMsg[m_nMsg++] = "[R1060.1] PLC BAT ALARM";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x0008 )
	{
		m_strMsg[m_nMsg++] = "[R1060.2] AIR Down ALARM";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecMainNew & 0x0010 )
	{
		m_strMsg[m_nMsg++] = "[R1060.3] Door Open ALARM";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x0020 )
	{
		m_strMsg[m_nMsg++] = "[R1060.4] 1 Axis Drive ALARM";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x0040 )
	{
		m_strMsg[m_nMsg++] = "[R1060.5] 2 Axis Drive ALARM";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x0080 )
	{
		m_strMsg[m_nMsg++] = "[R1060.6] 3 Axis Drive ALARM";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecMainNew & 0x0100 )
	{
		m_strMsg[m_nMsg++] = "[R1060.7] 1 Axis Control ALARM";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecMainNew & 0x0200 )
	{
		m_strMsg[m_nMsg++] = "[R1060.8] 2 Axis Control ALARM";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecMainNew & 0x0400 )
	{
		m_strMsg[m_nMsg++] = "[R1060.8] 3 Axis Control ALARM";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetMelsecLoaderErrorMsg()
{
	if(m_lErrorMelsecLoaderNew & 0x0001 )
	{
		m_strMsg[m_nMsg++] = "[R1060.A] LD - Left Loader 1 UpDown CYL Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x0002 )
	{
		m_strMsg[m_nMsg++] = "[R1060.B] LD - Left Loader 2 UpDown CYL Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x0004 )
	{
		m_strMsg[m_nMsg++] = "[R1060.C] LD - Left Loader Vacuum Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x0008 )
	{
		m_strMsg[m_nMsg++] = "[R1060.D] LD - Right Loader 1 UpDown CYL Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x0010 )
	{
		m_strMsg[m_nMsg++] = "[R1060.E] LD - Right Loader 2 UpDown CYL Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x0020 )
	{
		m_strMsg[m_nMsg++] = "[R1060.F] LD - Right Loader Vacuum Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x0040 )
	{
		m_strMsg[m_nMsg++] = "[R1061.2] LD - Align Table For/Back Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x0080 )
	{
		m_strMsg[m_nMsg++] = "[R1061.3] LD - Align1 Left Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x0100 )
	{
		m_strMsg[m_nMsg++] = "[R1061.4] LD - Align1 Front Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecLoaderNew & 0x0200 )
	{
		m_strMsg[m_nMsg++] = "[R1061.5] LD - Palte Align Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x0400 )
	{
		m_strMsg[m_nMsg++] = "[R1061.6] LD - Align1 R OnOff Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x0800 )
	{
		m_strMsg[m_nMsg++] = "[R1061.7] LD - Cart Lock Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x1000 )
	{
		m_strMsg[m_nMsg++] = "[R1061.8] LD - Lifter Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x2000 )
	{
		m_strMsg[m_nMsg++] = "[R1061.A] LD - NG Table Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x4000 )
	{
		m_strMsg[m_nMsg++] = "[R1061.B] LD - PAPER Table  Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x8000 )
	{
		m_strMsg[m_nMsg++] = "[R1063.3] LD - Left Picker PCB Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x10000 )
	{
		m_strMsg[m_nMsg++] = "[R1063.4] LD - Right Picker PCB Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x40000 )
	{
		m_strMsg[m_nMsg++] = "[R1063.7] LD - Wrong Pos Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecLoaderNew & 0x80000 )
	{
		m_strMsg[m_nMsg++] = "[R1061.0] Load Unload Collision Pos Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetMelsecUnloaderErrorMsg()
{
	if(m_lErrorMelsecUnloaderNew & 0x0001 )
	{
		m_strMsg[m_nMsg++] = "[R1061.E] UD - Left Loader 1 UpDown CYL Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x0002 )
	{
		m_strMsg[m_nMsg++] = "[R1061.F] UD - Left Loader 2 UpDown CYL Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x0004 )
	{
		m_strMsg[m_nMsg++] = "[R1062.0] UD - Left Loader Vacuum Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x0008 )
	{
		m_strMsg[m_nMsg++] = "[R1062.1] UD - Right Loader 1 UpDown CYL Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x0010 )
	{
		m_strMsg[m_nMsg++] = "[R1062.2] UD - Right Loader 2 UpDown CYL Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x0020 )
	{
		m_strMsg[m_nMsg++] = "[R1062.3] UD - Right Loader Vacuum Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x0040 )
	{
		m_strMsg[m_nMsg++] = "[R1062.6] UD - Align Table For/Back Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x0080 )
	{
		m_strMsg[m_nMsg++] = "[R1062.7] UD - Align1 Left Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x0100 )
	{
		m_strMsg[m_nMsg++] = "[R1062.8] UD - Align1 Front Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}

	if(m_lErrorMelsecUnloaderNew & 0x0200 )
	{
		m_strMsg[m_nMsg++] = "[R1062.9] UD - Palte Align Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x0400 )
	{
		m_strMsg[m_nMsg++] = "[R1062.A] UD - Align1 R OnOff Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x0800 )
	{
		m_strMsg[m_nMsg++] = "[R1062.B] UD - Cart Lock Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x1000 )
	{
		m_strMsg[m_nMsg++] = "[R1062.C] UD - Lifter Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x2000 )
	{
		m_strMsg[m_nMsg++] = "[R1061.E] UD - NG Table Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x4000 )
	{
		m_strMsg[m_nMsg++] = "[R1061.F] UD - PAPER Table  Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x8000 )
	{
		m_strMsg[m_nMsg++] = "[R1063.5] UD - Left Picker PCB Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x10000 )
	{
		m_strMsg[m_nMsg++] = "[R1063.6] UD - Right Picker PCB Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecUnloaderNew & 0x40000  )
	{
		m_strMsg[m_nMsg++] = "[R1063.8] UD - Worng Pos Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetMelsecEtc1ErrorMsg()
{
	if(m_lErrorMelsecEtc1New & 0x00000001 )
	{
		m_strMsg[m_nMsg++] = "[R1063.0] Turn Table For/Back Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000002)
	{
		m_strMsg[m_nMsg++] = "[R1063.1] Trun Table Up/Down Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000004)
	{
		m_strMsg[m_nMsg++] = "[R1063.2] Turn Table Vacuum Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000008)
	{
		m_strMsg[m_nMsg++] = "[R1063.D] Paper No Exist";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000010)
	{
		m_strMsg[m_nMsg++] = "[R1063.E] Paper Box Full Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000020)
	{
		m_strMsg[m_nMsg++] = "[R1063.F] NG Box Full Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000040)
	{
		m_strMsg[m_nMsg++] = "[R1063.B] Paper Exist Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000080)
	{
		m_strMsg[m_nMsg++] = "[R1063.C] Paper Exist Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc1New & 0x00000100)
	{
		m_strMsg[m_nMsg++] = "[R1074] Fall PCB In Danger Pos Alarm";
		if(m_nMsg > m_nMaxError-1) return;
	}
}

void CDlgAlarmPLCLarge::GetMelsecEtc2ErrorMsg()
{
/*	if(m_lErrorMelsecEtc2New & 0x00000001)
	{
		m_strMsg[m_nMsg++] = "[M7112] UP2 Status";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc2New & 0x00000002)
	{
		m_strMsg[m_nMsg++] = "[M7113] UP3 Status";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc2New & 0x00000004)
	{
		m_strMsg[m_nMsg++] = "[M7114] Ud PCB Table Status";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc2New & 0x00000008)
	{
		m_strMsg[m_nMsg++] = "[M7115] Ud Paper Table Status";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc2New & 0x00000010)
	{
		m_strMsg[m_nMsg++] = "[M7116] Ld PCB Drop in Danger Place";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc2New & 0x00000020)
	{
		m_strMsg[m_nMsg++] = "[M7117] Ud PCB Drop in Danger Place";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc2New & 0x00000040)
	{
		m_strMsg[m_nMsg++] = "[M7038] Ld Basket Paper Full";
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsecEtc2New & 0x00000080)
	{
		m_strMsg[m_nMsg++] = "[M7058] Ud Elv PCB Full";
		if(m_nMsg > m_nMaxError-1) return;
	}
	*/
}

void CDlgAlarmPLCLarge::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

void CDlgAlarmPLCLarge::ReadErrorMelsec1060Msg()
{
	CString strLog;
	strLog.GetBuffer(256);

	if(m_lErrorMelsec1060New & 0x0001 )
	{
		strLog.Format(_T("[R1060.0] EStop ALARM"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x0002)
	{
		strLog.Format(_T("[R1060.1] PLC BAT ALARM"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x0004)
	{
		strLog.Format(_T("[R1060.2] AIR Down ALARM"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x0008)
	{
		strLog.Format(_T("[R1060.3] Door Open ALARM"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x0010)
	{
		strLog.Format(_T("[R1060.4] Loader X Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x0020)
	{
		strLog.Format(_T("[R1060.5] Loader Left Z Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x0040)
	{
		strLog.Format(_T("[R1060.6] Loader Right Z Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x0080)
	{
		strLog.Format(_T("[R1060.7] Unloader X Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x0100)
	{
		strLog.Format(_T("[R1060.8] Unloader Left Z Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x0200)
	{
		strLog.Format(_T("[R1060.9] Unloader Right Z Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x0400)
	{
		strLog.Format(_T("[R1060.A] Loader Align1 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x0800)
	{
		strLog.Format(_T("[R1060.B] Loader Align2 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x1000)
	{
		strLog.Format(_T("[R1060.C] Loader Align3 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x2000)
	{
		strLog.Format(_T("[R1060.D] Loader Align4 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x4000)
	{
		strLog.Format(_T("[R1060.E] Unloader Align1 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1060New & 0x8000)
	{
		strLog.Format(_T("[R1060.F] Unloader Align2 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	strLog.ReleaseBuffer();
}

void CDlgAlarmPLCLarge::ReadErrorMelsec1061Msg()
{
	CString strLog;
	strLog.GetBuffer(256);

	if(m_lErrorMelsec1061New & 0x0001 )
	{
		strLog.Format(_T("[R1061.0] Unloader Align3 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;

	}
	if(m_lErrorMelsec1061New & 0x0002)
	{
		strLog.Format(_T("[R1061.1] Unloader Align4 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1061New & 0x0004)
	{
		strLog.Format(_T("[R1061.2] Loader Not Start, Home Pos"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1061New & 0x0008)
	{
		strLog.Format(_T("[R1061.3] Loader Left PCB Exist"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1061New & 0x0010)
	{
		strLog.Format(_T("[R1061.4] Loader Right PCB Exist"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1061New & 0x0020)
	{
		strLog.Format(_T("[R1061.5] Loader Align PCB Exist"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1061New & 0x0040)
	{
		strLog.Format(_T("[R1061.6] Unloader Not Start, Home Pos"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1061New & 0x0080)
	{
		strLog.Format(_T("[R1061.7] Unloader Left PCB Exis"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1061New & 0x0100)
	{
		strLog.Format(_T("[R1061.8] Unloader Right PCB Exis"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1061New & 0x0200)
	{
		strLog.Format(_T("[R1061.9] Unloader Align PCB Exis"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1061New & 0x0400)
	{

	}
	if(m_lErrorMelsec1061New & 0x0800)
	{

	}
	if(m_lErrorMelsec1061New & 0x1000)
	{
		strLog.Format(_T("[R1061.C] Loader Ionizer1 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1061New & 0x2000)
	{
		strLog.Format(_T("[R1061.D] Loader Ionizer2 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1061New & 0x4000)
	{
		strLog.Format(_T("[R1061.E] Loader Ionizer3 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1061New & 0x8000)
	{
		strLog.Format(_T("[R1061.F] Loader Ionizer4 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	strLog.ReleaseBuffer();
}

void CDlgAlarmPLCLarge::ReadErrorMelsec1062Msg()
{
	CString strLog;
	strLog.GetBuffer(256);

	if(m_lErrorMelsec1062New & 0x0001 )
	{
		strLog.Format(_T("[R1062.0] Unloader Ionizer1 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1062New & 0x0002)
	{
		strLog.Format(_T("[R1062.1] Unloader Ionizer2 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1062New & 0x0004)
	{
		strLog.Format(_T("[R1062.2] Unloader Ionizer3 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1062New & 0x0008)
	{
		strLog.Format(_T("[R1062.3] Unloader Ionizer4 Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1062New & 0x0010)
	{
			
	}
	if(m_lErrorMelsec1062New & 0x0020)
	{
			
	}
	if(m_lErrorMelsec1062New & 0x0040)
	{
			
	}
	if(m_lErrorMelsec1062New & 0x0080)
	{
			
	}
	if(m_lErrorMelsec1062New & 0x0100)
	{
		strLog.Format(_T("[R1062.8] Loader Left Suction Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1062New & 0x0200)
	{
		strLog.Format(_T("[R1062.9] Loader Right Suction Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1062New & 0x0400)
	{
		strLog.Format(_T("[R1062.A] Loader 2PCB NG Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1062New & 0x0800)
	{
		strLog.Format(_T("[R1062.B] Loader Left PCB Size Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1062New & 0x1000)
	{
		strLog.Format(_T("[R1062.C] Loader Right PCB Size Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1062New & 0x2000)
	{
		strLog.Format(_T("[R1062.D] Loader Left PCB Exist Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1062New & 0x4000)
	{
		strLog.Format(_T("[R1062.E] Loader Right PCB Exist Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	strLog.ReleaseBuffer();
}

void CDlgAlarmPLCLarge::ReadErrorMelsec1063Msg()
{
	CString strLog;
	strLog.GetBuffer(256);

	if(m_lErrorMelsec1063New & 0x0001 )
	{
		strLog.Format(_T("[R1063.0] Unloader Left Suction Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1063New & 0x0002)
	{
		strLog.Format(_T("[R1063.1] Unloader Right Suction Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1063New & 0x0004)
	{
		strLog.Format(_T("[R1063.2] Unloader 2PCB NG Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1063New & 0x0008)
	{
		strLog.Format(_T("[R1063.3] Unloader Left PCB Size Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1063New & 0x0010)
	{
		strLog.Format(_T("[R1063.4] Unloader Right PCB Size Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1063New & 0x0020)
	{
		strLog.Format(_T("[R1063.5] Unloader Left PCB Exist Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1063New & 0x0040)
	{
		strLog.Format(_T("[R1063.6] Unloader Right PCB Exist"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1063New & 0x0080)
	{

	}
	if(m_lErrorMelsec1063New & 0x0100)
	{
		strLog.Format(_T("[R1063.8] Loader Align Suction Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1063New & 0x0200)
	{
		strLog.Format(_T("[R1063.9] Loader Align PCB Exist Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1063New & 0x0400)
	{
		strLog.Format(_T("[R1063.A] Loader Align Left Forward Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1063New & 0x0800)
	{
		strLog.Format(_T("[R1063.B] Loader Align Left Backward Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1063New & 0x1000)
	{
		strLog.Format(_T("[R1063.C] Loader Align Right Forward Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1063New & 0x2000)
	{
		strLog.Format(_T("[R1063.D] Loader Align Right Backward Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1063New & 0x4000)
	{

	}
	if(m_lErrorMelsec1063New & 0x8000)
	{

	}
	strLog.ReleaseBuffer();
}

void CDlgAlarmPLCLarge::ReadErrorMelsec1064Msg()
{
	CString strLog;
	strLog.GetBuffer(256);

	if(m_lErrorMelsec1064New & 0x0001 )
	{
		strLog.Format(_T("[R1064.0] Unloader Align Suction Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;

	}
	if(m_lErrorMelsec1064New & 0x0002)
	{
		strLog.Format(_T("[R1064.1] Unloader Align PCB Exist Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1064New & 0x0004)
	{
		strLog.Format(_T("[R1064.2] Unloader Left Forward Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1064New & 0x0008)
	{
		strLog.Format(_T("[R1064.3] Unloader Left Backward Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1064New & 0x0010)
	{
		strLog.Format(_T("[R1064.4] Unloader Right Forward Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1064New & 0x0020)
	{
		strLog.Format(_T("[R1064.5] Unloader Right Backward Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1064New & 0x0040)
	{

	}
	if(m_lErrorMelsec1064New & 0x0080)
	{

	}
	if(m_lErrorMelsec1064New & 0x0100)
	{
		strLog.Format(_T("[R1064.8] Loader Paper No Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1064New & 0x0200)
	{
		strLog.Format(_T("[R1064.9] Loader Paper Full Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1064New & 0x0400)
	{
		strLog.Format(_T("[R1064.A] Loader Paper Table Forward Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1064New & 0x0800)
	{
		strLog.Format(_T("[R1064.B] Loader Align Table Backward Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1064New & 0x1000)
	{

	}
	if(m_lErrorMelsec1064New & 0x2000)
	{

	}
	if(m_lErrorMelsec1064New & 0x4000)
	{
		strLog.Format(_T("[R1064.E] Loader No Use Paper, Paper Exist Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1064New & 0x8000)
	{

	}
	strLog.ReleaseBuffer();
}

void CDlgAlarmPLCLarge::ReadErrorMelsec1065Msg()
{
	CString strLog;
	strLog.GetBuffer(256);

	if(m_lErrorMelsec1065New & 0x0001 )
	{
		strLog.Format(_T("[R1065.0] Unloader Paper No Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1065New & 0x0002)
	{
		strLog.Format(_T("[R1065.1] Unloader Paper Full Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1065New & 0x0004)
	{
		strLog.Format(_T("[R1065.2] Unloader Paper Table Forward Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1065New & 0x0008)
	{
		strLog.Format(_T("[R1065.3] Unloader Paper Table Backward Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1065New & 0x0010)
	{

	}
	if(m_lErrorMelsec1065New & 0x0020)
	{

	}
	if(m_lErrorMelsec1065New & 0x0040)
	{
		strLog.Format(_T("[R1065.6] Unloader No Use Paper, Paper Exist Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1065New & 0x0080)
	{

	}
	if(m_lErrorMelsec1065New & 0x0100)
	{
		strLog.Format(_T("[R1065.8] Loader Box No Exist Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1065New & 0x0200)
	{
		strLog.Format(_T("[R1065.9] Loader Box PCB Drop Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1065New & 0x0400)
	{
		strLog.Format(_T("[R1065.A] Loader Lift Up Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1065New & 0x0800)
	{
		strLog.Format(_T("[R1065.B] Loader Lift Down Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1065New & 0x1000)
	{
		strLog.Format(_T("[R1065.C] Loader Cart Lock Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1065New & 0x2000)
	{
		strLog.Format(_T("[R1065.D] Loader Cart Unlock Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1065New & 0x4000)
	{

	}
	if(m_lErrorMelsec1065New & 0x8000)
	{

	}
	strLog.ReleaseBuffer();
}

void CDlgAlarmPLCLarge::ReadErrorMelsec1066Msg()
{
	CString strLog;
	strLog.GetBuffer(256);

	if(m_lErrorMelsec1066New & 0x0001 )
	{
		strLog.Format(_T("[R1066.0] Unloader Box No Exist ALARM"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1066New & 0x0002)
	{
		strLog.Format(_T("[R1066.1] Unloader Box PCB Drop ALARM"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1066New & 0x0004)
	{
		strLog.Format(_T("[R1066.2] Unloader Lift Up ALARM"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1066New & 0x0008)
	{
		strLog.Format(_T("[R1066.3] Unloader Lift Down ALARM"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1066New & 0x0010)
	{
		strLog.Format(_T("[R1066.4] Unloder Cart Lock Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1066New & 0x0020)
	{
		strLog.Format(_T("[R1066.5] Unloader Cart Unlock Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1066New & 0x0040)
	{
		strLog.Format(_T("[R1066.6] Unloader Lift Middle Pos Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1066New & 0x0080)
	{

	}
	if(m_lErrorMelsec1066New & 0x0100)
	{

	}
	if(m_lErrorMelsec1066New & 0x0200)
	{

	}
	if(m_lErrorMelsec1066New & 0x0400)
	{

	}
	if(m_lErrorMelsec1066New & 0x0800)
	{

	}
	if(m_lErrorMelsec1066New & 0x1000)
	{

	}
	if(m_lErrorMelsec1066New & 0x2000)
	{

	}
	if(m_lErrorMelsec1066New & 0x4000)
	{

	}
	if(m_lErrorMelsec1066New & 0x8000)
	{

	}
	strLog.ReleaseBuffer();
}

void CDlgAlarmPLCLarge::ReadErrorMelsec1067Msg()
{
	CString strLog;
	strLog.GetBuffer(256);

	if(m_lErrorMelsec1067New & 0x0001 )
	{
		strLog.Format(_T("[R1067.0] Turn PCB Exist ALARM"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1067New & 0x0002)
	{
		strLog.Format(_T("[R1067.1] Turn Suction ALARM"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1067New & 0x0004)
	{
		strLog.Format(_T("[R1067.2] turn PCB Size ALARM"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1067New & 0x0008)
	{
		strLog.Format(_T("[R1067.3] Turn PCB Drop ALARM"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1067New & 0x0010)
	{
		strLog.Format(_T("[R1067.4] Turn Unit Forward Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1067New & 0x0020)
	{
		strLog.Format(_T("[R1067.5] Turn Unit Backward Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1067New & 0x0040)
	{
		strLog.Format(_T("[R1067.6] Turn Unit Turn Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1067New & 0x0080)
	{
		strLog.Format(_T("[R1067.7] Turn Unit Return Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1067New & 0x0100)
	{
		strLog.Format(_T("[R1067.8] Turn Unit Up Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1067New & 0x0200)
	{
		strLog.Format(_T("[R1067.9] Turn Unit Down Alarm"));
		m_strMsg[m_nMsg++] = strLog;
		if(m_nMsg > m_nMaxError-1) return;
	}
	if(m_lErrorMelsec1067New & 0x0400)
	{

	}
	if(m_lErrorMelsec1067New & 0x0800)
	{

	}
	if(m_lErrorMelsec1067New & 0x1000)
	{

	}
	if(m_lErrorMelsec1067New & 0x2000)
	{

	}
	if(m_lErrorMelsec1067New & 0x4000)
	{

	}
	if(m_lErrorMelsec1067New & 0x8000)
	{

	}
	strLog.ReleaseBuffer();
}

// PaneManualControlIOMonitorInputSub4.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlIOMonitorInputSub4.h"
#include "..\device\HDeviceFactory.h"
#include "..\Model\DSystemINI.h"
#include "..\Model\DEasyDrillerINI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub4

IMPLEMENT_DYNCREATE(CPaneManualControlIOMonitorInputSub4, CFormView)

CPaneManualControlIOMonitorInputSub4::CPaneManualControlIOMonitorInputSub4()
	: CFormView(CPaneManualControlIOMonitorInputSub4::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlIOMonitorInputSub4)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nTimerID = 0;
	m_lStatusHandlerUnloader = m_lStatusHandlerUnloaderOld = 0;
}

CPaneManualControlIOMonitorInputSub4::~CPaneManualControlIOMonitorInputSub4()
{
}

void CPaneManualControlIOMonitorInputSub4::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlIOMonitorInputSub4)
	DDX_Control(pDX, IDC_CHECK_UC_READY, m_ledUCReady);
	DDX_Control(pDX, IDC_CHECK_UC_BUSY, m_ledUCBusy);
	DDX_Control(pDX, IDC_CHECK_UC_STOP, m_ledUCStop);
	DDX_Control(pDX, IDC_CHECK_UC_INIT_END, m_ledUCInitEnd);

	DDX_Control(pDX, IDC_CHECK_UD_PAPER_TRANS_FWD, m_ledUdPaperTransFwd);
	DDX_Control(pDX, IDC_CHECK_UD_PAPER_TRANS_BWD, m_ledUdPaperTransBwd);
	DDX_Control(pDX, IDC_CHECK_UD_PCB_TRANS_FWD, m_ledUdPCBTransFwd);
	DDX_Control(pDX, IDC_CHECK_UD_PCB_TRANS_BWD, m_ledUdPCBTransBwd);
	DDX_Control(pDX, IDC_CHECK_UD_CART_CLAMP_UP, m_ledUdCartClampUp);
	DDX_Control(pDX, IDC_CHECK_UD_CART_CLAMP_DOWN, m_ledUdCartClampDown);

	DDX_Control(pDX, IDC_CHECK_UP1_READY, m_ledUP1Ready);
	DDX_Control(pDX, IDC_CHECK_UP1_BUSY, m_ledUP1Busy);
	DDX_Control(pDX, IDC_CHECK_UP1_STOP, m_ledUP1Stop);
	DDX_Control(pDX, IDC_CHECK_UP1_INIT_END, m_ledUP1InitEnd);
	DDX_Control(pDX, IDC_CHECK_UP1_VACUUM_ON, m_ledUP1VacuumOn);
	DDX_Control(pDX, IDC_CHECK_UP1_VACUUM_OFF, m_ledUP1VacuumOff);

	DDX_Control(pDX, IDC_CHECK_UP2_READY, m_ledUP2Ready);
	DDX_Control(pDX, IDC_CHECK_UP2_BUSY, m_ledUP2Busy);
	DDX_Control(pDX, IDC_CHECK_UP2_STOP, m_ledUP2Stop);
	DDX_Control(pDX, IDC_CHECK_UP2_INIT_END, m_ledUP2InitEnd);
	DDX_Control(pDX, IDC_CHECK_UP2_VACUUM_ON, m_ledUP2VacuumOn);
	DDX_Control(pDX, IDC_CHECK_UP2_VACUUM_OFF, m_ledUP2VacuumOff);

	DDX_Control(pDX, IDC_CHECK_UP3_READY, m_ledUP3Ready);
	DDX_Control(pDX, IDC_CHECK_UP3_BUSY, m_ledUP3Busy);
	DDX_Control(pDX, IDC_CHECK_UP3_STOP, m_ledUP3Stop);
	DDX_Control(pDX, IDC_CHECK_UP3_INIT_END, m_ledUP3InitEnd);
	DDX_Control(pDX, IDC_CHECK_UP3_VACUUM_ON, m_ledUP3VacuumOn);
	DDX_Control(pDX, IDC_CHECK_UP3_VACUUM_OFF, m_ledUP3VacuumOff);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPaneManualControlIOMonitorInputSub4, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlIOMonitorInputSub4)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub4 diagnostics

#ifdef _DEBUG
void CPaneManualControlIOMonitorInputSub4::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlIOMonitorInputSub4::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub4 message handlers
void CPaneManualControlIOMonitorInputSub4::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
}

void CPaneManualControlIOMonitorInputSub4::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(100, "Arial Bold");
	
	m_ledUCReady.SetFont( &m_fntBtn );
	m_ledUCReady.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUCReady.Depress( TRUE );
	m_ledUCBusy.SetFont( &m_fntBtn );
	m_ledUCBusy.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUCBusy.Depress( TRUE );
	m_ledUCStop.SetFont( &m_fntBtn );
	m_ledUCStop.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUCStop.Depress( TRUE );
	m_ledUCInitEnd.SetFont( &m_fntBtn );
	m_ledUCInitEnd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUCInitEnd.Depress( TRUE );

	m_ledUdPaperTransFwd.SetFont( &m_fntBtn );
	m_ledUdPaperTransFwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUdPaperTransFwd.Depress( TRUE );
	m_ledUdPaperTransBwd.SetFont( &m_fntBtn );
	m_ledUdPaperTransBwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUdPaperTransBwd.Depress( TRUE );

	m_ledUdPCBTransFwd.SetFont( &m_fntBtn );
	m_ledUdPCBTransFwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUdPCBTransFwd.Depress( TRUE );
	m_ledUdPCBTransBwd.SetFont( &m_fntBtn );
	m_ledUdPCBTransBwd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUdPCBTransBwd.Depress( TRUE );

	m_ledUdCartClampUp.SetFont( &m_fntBtn );
	m_ledUdCartClampUp.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUdCartClampUp.Depress( TRUE );
	m_ledUdCartClampDown.SetFont( &m_fntBtn );
	m_ledUdCartClampDown.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUdCartClampDown.Depress( TRUE );
	
	m_ledUP1Ready.SetFont( &m_fntBtn );
	m_ledUP1Ready.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP1Ready.Depress( TRUE );
	m_ledUP1Busy.SetFont( &m_fntBtn );
	m_ledUP1Busy.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP1Busy.Depress( TRUE );
	m_ledUP1Stop.SetFont( &m_fntBtn );
	m_ledUP1Stop.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP1Stop.Depress( TRUE );
	m_ledUP1InitEnd.SetFont( &m_fntBtn );
	m_ledUP1InitEnd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP1InitEnd.Depress( TRUE );
	m_ledUP1VacuumOn.SetFont( &m_fntBtn );
	m_ledUP1VacuumOn.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP1VacuumOn.Depress( TRUE );
	m_ledUP1VacuumOff.SetFont( &m_fntBtn );
	m_ledUP1VacuumOff.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP1VacuumOff.Depress( TRUE );
	
	m_ledUP2Ready.SetFont( &m_fntBtn );
	m_ledUP2Ready.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP2Ready.Depress( TRUE );
	m_ledUP2Busy.SetFont( &m_fntBtn );
	m_ledUP2Busy.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP2Busy.Depress( TRUE );
	m_ledUP2Stop.SetFont( &m_fntBtn );
	m_ledUP2Stop.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP2Stop.Depress( TRUE );
	m_ledUP2InitEnd.SetFont( &m_fntBtn );
	m_ledUP2InitEnd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP2InitEnd.Depress( TRUE );
	m_ledUP1VacuumOn.SetFont( &m_fntBtn );
	m_ledUP2VacuumOn.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP2VacuumOn.Depress( TRUE );
	m_ledUP2VacuumOff.SetFont( &m_fntBtn );
	m_ledUP2VacuumOff.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP2VacuumOff.Depress( TRUE );
	
	m_ledUP3Ready.SetFont( &m_fntBtn );
	m_ledUP3Ready.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP3Ready.Depress( TRUE );
	m_ledUP3Busy.SetFont( &m_fntBtn );
	m_ledUP3Busy.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP3Busy.Depress( TRUE );
	m_ledUP3Stop.SetFont( &m_fntBtn );
	m_ledUP3Stop.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP3Stop.Depress( TRUE );
	m_ledUP3InitEnd.SetFont( &m_fntBtn );
	m_ledUP3InitEnd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP3InitEnd.Depress( TRUE );
	m_ledUP3VacuumOn.SetFont( &m_fntBtn );
	m_ledUP3VacuumOn.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP3VacuumOn.Depress( TRUE );
	m_ledUP3VacuumOff.SetFont( &m_fntBtn );
	m_ledUP3VacuumOff.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP3VacuumOff.Depress( TRUE );
}

void CPaneManualControlIOMonitorInputSub4::UpdateStatus()
{
	// UC
	if(m_pMotor->IsHandlerReady(HANDLER_UC))
		m_ledUCReady.Depress(FALSE);
	else
		m_ledUCReady.Depress(TRUE);
	
	if(m_pMotor->IsHandlerBusy(HANDLER_UC))
		m_ledUCBusy.Depress(FALSE);
	else
		m_ledUCBusy.Depress(TRUE);
	
	if(m_pMotor->IsHandlerStop(HANDLER_UC))
		m_ledUCStop.Depress(FALSE);
	else
		m_ledUCStop.Depress(TRUE);
	
	if(m_pMotor->IsHandlerInitEnd(HANDLER_UC))
		m_ledUCInitEnd.Depress(FALSE);
	else
		m_ledUCInitEnd.Depress(TRUE);
	
	// UP1
	if(m_pMotor->IsHandlerReady(HANDLER_UP1))
		m_ledUP1Ready.Depress(FALSE);
	else
		m_ledUP1Ready.Depress(TRUE);
	
	if(m_pMotor->IsHandlerBusy(HANDLER_UP1))
		m_ledUP1Busy.Depress(FALSE);
	else
		m_ledUP1Busy.Depress(TRUE);
	
	if(m_pMotor->IsHandlerStop(HANDLER_UP1))
		m_ledUP1Stop.Depress(FALSE);
	else
		m_ledUP1Stop.Depress(TRUE);
	
	if(m_pMotor->IsHandlerInitEnd(HANDLER_UP1))
		m_ledUP1InitEnd.Depress(FALSE);
	else
		m_ledUP1InitEnd.Depress(TRUE);
	
	// UP2
	if(m_pMotor->IsHandlerReady(HANDLER_UP2))
		m_ledUP2Ready.Depress(FALSE);
	else
		m_ledUP2Ready.Depress(TRUE);
	
	if(m_pMotor->IsHandlerBusy(HANDLER_UP2))
		m_ledUP2Busy.Depress(FALSE);
	else
		m_ledUP2Busy.Depress(TRUE);
	
	if(m_pMotor->IsHandlerStop(HANDLER_UP2))
		m_ledUP2Stop.Depress(FALSE);
	else
		m_ledUP2Stop.Depress(TRUE);
	
	if(m_pMotor->IsHandlerInitEnd(HANDLER_UP2))
		m_ledUP2InitEnd.Depress(FALSE);
	else
		m_ledUP2InitEnd.Depress(TRUE);
	
	// UP3
	if(m_pMotor->IsHandlerReady(HANDLER_UP3))
		m_ledUP3Ready.Depress(FALSE);
	else
		m_ledUP3Ready.Depress(TRUE);
	
	if(m_pMotor->IsHandlerBusy(HANDLER_UP3))
		m_ledUP3Busy.Depress(FALSE);
	else
		m_ledUP3Busy.Depress(TRUE);
	
	if(m_pMotor->IsHandlerStop(HANDLER_UP3))
		m_ledUP3Stop.Depress(FALSE);
	else
		m_ledUP3Stop.Depress(TRUE);
	
	if(m_pMotor->IsHandlerInitEnd(HANDLER_UP3))
		m_ledUP3InitEnd.Depress(FALSE);
	else
		m_ledUP3InitEnd.Depress(TRUE);

	m_lStatusHandlerUnloader = m_pMotor->GetCurrentError(STATUS_HANDLER_UNLOADER);
	if(m_lStatusHandlerUnloader != m_lStatusHandlerUnloaderOld)
	{
		m_lStatusHandlerUnloaderOld = m_lStatusHandlerUnloader;

		if(m_lStatusHandlerUnloader & 0x00000001)
			m_ledUdPaperTransFwd.Depress(FALSE);
		else
			m_ledUdPaperTransFwd.Depress(TRUE);

		if(m_lStatusHandlerUnloader & 0x00000002)
			m_ledUdPaperTransBwd.Depress(FALSE);
		else
			m_ledUdPaperTransBwd.Depress(TRUE);

		if(m_lStatusHandlerUnloader & 0x00000004)
			m_ledUdPCBTransFwd.Depress(FALSE);
		else
			m_ledUdPCBTransFwd.Depress(TRUE);

		if(m_lStatusHandlerUnloader & 0x00000008)
			m_ledUdPCBTransBwd.Depress(FALSE);
		else
			m_ledUdPCBTransBwd.Depress(TRUE);

		if(m_lStatusHandlerUnloader & 0x00000010)
			m_ledUdCartClampUp.Depress(FALSE);
		else
			m_ledUdCartClampUp.Depress(TRUE);

		if(m_lStatusHandlerUnloader & 0x00000020)
			m_ledUdCartClampDown.Depress(FALSE);
		else
			m_ledUdCartClampDown.Depress(TRUE);

		if(m_lStatusHandlerUnloader & 0x00000040)
			m_ledUP1VacuumOn.Depress(FALSE);
		else
			m_ledUP1VacuumOn.Depress(TRUE);

		if(m_lStatusHandlerUnloader & 0x00000080)
			m_ledUP1VacuumOff.Depress(FALSE);
		else
			m_ledUP1VacuumOff.Depress(TRUE);

		if(m_lStatusHandlerUnloader & 0x00000100)
			m_ledUP2VacuumOn.Depress(FALSE);
		else
			m_ledUP2VacuumOn.Depress(TRUE);

		if(m_lStatusHandlerUnloader & 0x00000200)
			m_ledUP2VacuumOff.Depress(FALSE);
		else
			m_ledUP2VacuumOff.Depress(TRUE);

		if(m_lStatusHandlerUnloader & 0x00000400)
			m_ledUP3VacuumOn.Depress(FALSE);
		else
			m_ledUP3VacuumOn.Depress(TRUE);

		if(m_lStatusHandlerUnloader & 0x00000800)
			m_ledUP3VacuumOff.Depress(FALSE);
		else
			m_ledUP3VacuumOff.Depress(TRUE);
	}
}

void CPaneManualControlIOMonitorInputSub4::OnTimer(UINT nIDEvent) 
{
	UpdateStatus();
	
	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlIOMonitorInputSub4::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_nTimerID = SetTimer(9974, 1000, NULL);
		m_pMotor = gDeviceFactory.GetMotor();
	}
}

void CPaneManualControlIOMonitorInputSub4::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

BOOL CPaneManualControlIOMonitorInputSub4::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}
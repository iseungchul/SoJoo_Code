#if !defined(AFX_PANEPROCESSSETUPPROCESSLARGE_H__908537A7_AFF3_431F_B901_036264887637__INCLUDED_)
#define AFX_PANEPROCESSSETUPPROCESSLARGE_H__908537A7_AFF3_431F_B901_036264887637__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneProcessSetupProcessLarge.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupProcessLarge form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "..\model\globalvariable.h"

class CPaneProcessSetupProcessLarge : public CFormView
{
protected:
	CPaneProcessSetupProcessLarge();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneProcessSetupProcessLarge)

// Form Data
public:
	//{{AFX_DATA(CPaneProcessSetupProcessLarge)
	enum { IDD = IDD_DLG_PROCESS_SETUP_PROCESS_LARGE };
	CColorEdit	m_edtSuctionNo;
	CColorEdit	m_edtSuctionTableX;
	CColorEdit	m_edtSuctionTableY;
	CColorEdit	m_edt2ndPowermeterY;
	CColorEdit	m_edt2ndPowermeterX;
	CColorEdit	m_edt1stPowermeterY;
	CColorEdit	m_edt1stPowermeterX;
	CColorEdit	m_edt2ndThicknessHeadZ;
	CColorEdit	m_edt2ndThicknessBaseZ;
	CColorEdit	m_edt2ndThicknessOffsetY;
	CColorEdit	m_edt2ndThicknessOffsetX;
	CColorEdit	m_edt2ndThicknessAutoY;
	CColorEdit	m_edt2ndThicknessAutoX;
	CColorEdit	m_edt2ndThicknessManualY;
	CColorEdit	m_edt2ndThicknessManualX;
	CColorEdit	m_edt1stThicknessHeadZ;
	CColorEdit	m_edt1stThicknessBaseZ;
	CColorEdit	m_edt1stThicknessOffsetY;
	CColorEdit	m_edt1stThicknessOffsetX;
	CColorEdit	m_edt1stThicknessAutoY;
	CColorEdit	m_edt1stThicknessAutoX;
	CColorEdit	m_edt1stThicknessManualY;
	CColorEdit	m_edt1stThicknessManualX;
	CColorEdit	m_edtUnloadY;
	CColorEdit	m_edtUnloadX;
	CColorEdit	m_edtUnloadY2;
	CColorEdit	m_edtUnloadX2;
	CColorEdit	m_edtLoadY;
	CColorEdit	m_edtLoadX;
	CColorEdit	m_edtLoadY2;
	CColorEdit	m_edtLoadX2;
	CColorEdit	m_edtLCCart;
	CColorEdit	m_edtLCAlign;
	CColorEdit	m_edtLCLoad;
	CColorEdit	m_edtLCLoad2;
	CColorEdit	m_edtUCCart;
	CColorEdit	m_edtUCAlign;
	CColorEdit	m_edtUCUnload;
	CColorEdit	m_edtUCUnload2;
	CColorEdit	m_edtUnclampLimit;
	UEasyButtonEx m_btnSuctionAdd;
	UEasyButtonEx m_btnSuctionDelete;
	UEasyButtonEx m_btnSuctionUpdate;
	CListCtrl	m_listPosition;
	
	UEasyButtonEx m_btnLoadPosition;
	UEasyButtonEx m_btnUnloadPosition;
	UEasyButtonEx m_btnLoadPosition2;
	UEasyButtonEx m_btnUnloadPosition2;
	UEasyButtonEx m_btnLCCartPosition;
	UEasyButtonEx m_btnLCLoadPosition;
	UEasyButtonEx m_btnLCAlignPosition;
	UEasyButtonEx m_btnUCCartPosition;
	UEasyButtonEx m_btnUCUnloadPosition;
	UEasyButtonEx m_btnUCAlignPosition;
	

	CColorEdit	m_edtSCalMinX;
	CColorEdit	m_edtSCalMinY;
	CColorEdit	m_edtSCalMaxX;
	CColorEdit	m_edtSCalMaxY;

	CColorEdit	m_edtIdleShotX;
	CColorEdit	m_edtIdleShotY;
	CColorEdit	m_edtIdleShotZ1;
	CColorEdit	m_edtIdleShotZ2;

	CComboBox	m_cmbTool;

	CColorEdit	m_edtTCCleanX;
	CColorEdit	m_edtTCCleanY;
	CColorEdit	m_edtTCCleanZ1;
	CColorEdit	m_edtTCCleanZ2;
	UEasyButtonEx	m_btnTCCleanPos;
	//}}AFX_DATA

// Attributes
public:
	CRefuseList* m_pRefuse;

// Attributes
protected :
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	CFont			m_fntBtn;
	CFont			m_fntList;
	CFont			m_fntCombo;

	SAUTOSETTING	m_sAutoSetting;

// Operations
public:
	void SetToolComboBox();
	CString GetChangeValueStr();
	void InitStaticControl();
	void InitEditControl();
	void InitBtnControl();
	void InitListControl();
	void InitComboControl();

	void SetProcessPosition(SAUTOSETTING sAutoSetting);
	void GetProcessPosition(SAUTOSETTING* pAutoSetting);
	void DispProcessPosition();
	BOOL OnApply();
	
	void EnableControl(BOOL bUse);
	void EnableBtnControl(BOOL nLevel);
	void SetAuthorityByLevel(int nLevel);

	void ChangeDisplay(int nIndex);
	void AddItems();
	void ChangeData(int nIndex);
	void UpdateList();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneProcessSetupProcessLarge)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneProcessSetupProcessLarge();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneProcessSetupProcessLarge)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	afx_msg void OnButtonSuctionAdd();
	afx_msg void OnButtonSuctionDelete();
	afx_msg void OnButtonSuctionUpdate();
	afx_msg void OnClickListRefuse(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonUdcartPos();
	afx_msg void OnBnClickedButtonUdunloadPos();
	afx_msg void OnBnClickedButtonUdalignPos();
	afx_msg void OnBnClickedButtonLdcartPos();
	afx_msg void OnBnClickedButtonLdloadPos();
	afx_msg void OnBnClickedButtonLdalignPos();
	afx_msg void OnBnClickedButtonLoadPos();
	afx_msg void OnBnClickedButtonUnloadPos();
	afx_msg void OnBnClickedButtonLoadPos2();
	afx_msg void OnBnClickedButtonUnloadPos2();
	CStatic m_stcLoadPosition;
	CStatic m_stcUnloadPosition;
	CStatic m_stcLoadPosition2;
	CStatic m_stcLoaderCarrierPosition;
	CStatic m_stcUnloadetCarrierPosition;
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedButtonTcCleanPos();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEPROCESSSETUPPROCESSLARGE_H__908537A7_AFF3_431F_B901_036264887637__INCLUDED_)

// PaneDrillDisplaySub.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneDrillDisplaySub.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneDrillDisplaySub

IMPLEMENT_DYNCREATE(CPaneDrillDisplaySub, CFormView)

CPaneDrillDisplaySub::CPaneDrillDisplaySub()
	: CFormView(CPaneDrillDisplaySub::IDD)
{
	//{{AFX_DATA_INIT(CPaneDrillDisplaySub)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nBackPaneNo		= 0;
}

CPaneDrillDisplaySub::~CPaneDrillDisplaySub()
{
}

void CPaneDrillDisplaySub::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneDrillDisplaySub)
	DDX_Control(pDX, IDC_BUTTON_ZOOM_OUT, m_btnZoomOut);
	DDX_Control(pDX, IDC_BUTTON_ZOOM_IN, m_btnZoomIn);
	DDX_Control(pDX, IDC_BUTTON_WINDOW, m_btnWindow);
	DDX_Control(pDX, IDC_BUTTON_POSITION, m_btnPosition);
	DDX_Control(pDX, IDC_BUTTON_ORIGINAL, m_btnOriginal);
	DDX_Control(pDX, IDC_BUTTON_FIELD, m_btnField);
	DDX_Control(pDX, IDC_BUTTON_CONVERT, m_btnConvert);
	DDX_Control(pDX, IDC_BUTTON_CLEAR, m_btnClear);
	DDX_Control(pDX, IDC_BUTTON_BACK, m_btnBack);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneDrillDisplaySub, CFormView)
	//{{AFX_MSG_MAP(CPaneDrillDisplaySub)
	ON_BN_CLICKED(IDC_BUTTON_BACK, OnButtonBack)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneDrillDisplaySub diagnostics

#ifdef _DEBUG
void CPaneDrillDisplaySub::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneDrillDisplaySub::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneDrillDisplaySub message handlers

void CPaneDrillDisplaySub::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
}

void CPaneDrillDisplaySub::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Zoom In
	m_btnZoomIn.SetFont( &m_fntBtn );
	m_btnZoomIn.SetFlat( FALSE );
	m_btnZoomIn.SetImageOrg( 10, 3 );
	m_btnZoomIn.SetIcon( IDI_ZOOM_IN, 32, 32 );
	m_btnZoomIn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnZoomIn.EnableBallonToolTip();
	m_btnZoomIn.SetToolTipText( _T("Zoom In") );
	m_btnZoomIn.SetBtnCursor( IDC_HAND_1 );

	// Zoom Out
	m_btnZoomOut.SetFont( &m_fntBtn );
	m_btnZoomOut.SetFlat( FALSE );
	m_btnZoomOut.SetImageOrg( 10, 3 );
	m_btnZoomOut.SetIcon( IDI_ZOOM_OUT, 32, 32 );
	m_btnZoomOut.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnZoomOut.EnableBallonToolTip();
	m_btnZoomOut.SetToolTipText( _T("Zoom Out") );
	m_btnZoomOut.SetBtnCursor( IDC_HAND_1 );

	// Position
	m_btnPosition.SetFont( &m_fntBtn );
	m_btnPosition.SetFlat( FALSE );
	m_btnPosition.SetImageOrg( 10, 3 );
	m_btnPosition.SetIcon( IDI_POSITION, 32, 32 );
	m_btnPosition.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPosition.EnableBallonToolTip();
	m_btnPosition.SetToolTipText( _T("Position") );
	m_btnPosition.SetBtnCursor( IDC_HAND_1 );

	// Window
	m_btnWindow.SetFont( &m_fntBtn );
	m_btnWindow.SetFlat( FALSE );
	m_btnWindow.SetImageOrg( 10, 3 );
	m_btnWindow.SetIcon( IDI_WINDOW, 32, 32 );
	m_btnWindow.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnWindow.EnableBallonToolTip();
	m_btnWindow.SetToolTipText( _T("Window") );
	m_btnWindow.SetBtnCursor( IDC_HAND_1 );

	// Field
	m_btnField.SetFont( &m_fntBtn );
	m_btnField.SetFlat( FALSE );
	m_btnField.SetImageOrg( 10, 3 );
	m_btnField.SetIcon( IDI_FIELD, 32, 32 );
	m_btnField.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnField.EnableBallonToolTip();
	m_btnField.SetToolTipText( _T("Field") );
	m_btnField.SetBtnCursor( IDC_HAND_1 );

	// CLEAN
	m_btnClear.SetFont( &m_fntBtn );
	m_btnClear.SetFlat( FALSE );
	m_btnClear.SetImageOrg( 10, 3 );
	m_btnClear.SetIcon( IDI_CLEAN, 32, 32 );
	m_btnClear.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnClear.EnableBallonToolTip();
	m_btnClear.SetToolTipText( _T("Clear") );
	m_btnClear.SetBtnCursor( IDC_HAND_1 );

	// Convert
	m_btnConvert.SetFont( &m_fntBtn );
	m_btnConvert.SetFlat( FALSE );
	m_btnConvert.SetImageOrg( 10, 3 );
	m_btnConvert.SetIcon( IDI_CONVERT, 32, 32 );
	m_btnConvert.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnConvert.EnableBallonToolTip();
	m_btnConvert.SetToolTipText( _T("Convert") );
	m_btnConvert.SetBtnCursor( IDC_HAND_1 );

	// Origin
	m_btnOriginal.SetFont( &m_fntBtn );
	m_btnOriginal.SetFlat( FALSE );
	m_btnOriginal.SetImageOrg( 10, 3 );
	m_btnOriginal.SetIcon( IDI_ORIGIN, 32, 32 );
	m_btnOriginal.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOriginal.EnableBallonToolTip();
	m_btnOriginal.SetToolTipText( _T("Original") );
	m_btnOriginal.SetBtnCursor( IDC_HAND_1 );

	m_btnBack.SetFont( &m_fntBtn );
	m_btnBack.SetFlat( FALSE );
	m_btnBack.SetImageOrg( 10, 3 );
	m_btnBack.SetIcon( IDI_BACK );
	m_btnBack.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBack.EnableBallonToolTip();
	m_btnBack.SetToolTipText( _T("Back") );
	m_btnBack.SetBtnCursor( IDC_HAND_1 );
}

void CPaneDrillDisplaySub::OnButtonBack() 
{
	WPARAM wParam = m_nBackPaneNo;

	int nBackPaneNo = ::AfxGetMainWnd()->SendMessage( GET_BACK_PANE_NO, wParam, 0 );

	::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, nBackPaneNo );
}

void CPaneDrillDisplaySub::OnDestroy() 
{
	m_fntBtn.DeleteObject();

	CFormView::OnDestroy();
}

// PaneManualControlIOMonitorOutputSub2Pusan2.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlIOMonitorOutputSub2Pusan2.h"
#include "..\device\devicemotor.h"
#include "..\device\hdevicefactory.h"
#include "..\Model\DSystemINI.h"
#include "..\alarmmsg.h"
#include "..\easydrillerdlg.h"
#include "..\model\deasydrillerini.h"

#include "..\MODEL\DProcessINI.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub2Pusan2

IMPLEMENT_DYNCREATE(CPaneManualControlIOMonitorOutputSub2Pusan2, CFormView)

CPaneManualControlIOMonitorOutputSub2Pusan2::CPaneManualControlIOMonitorOutputSub2Pusan2()
	: CFormView(CPaneManualControlIOMonitorOutputSub2Pusan2::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlIOMonitorOutputSub2Pusan2)
	m_nTimerID = 0;
	m_bStatusLoader1 = FALSE;
	m_bStatusLoader2 = FALSE;
	m_bStatusUnloader1 = FALSE;
	m_bStatusUnloader2 = FALSE;
	m_bStatusTable1 = FALSE;
	m_bStatusTable2 = FALSE;
	m_bStatusAligner = FALSE;
	m_bStatusAligner2 = FALSE;

	//}}AFX_DATA_INIT
}

CPaneManualControlIOMonitorOutputSub2Pusan2::~CPaneManualControlIOMonitorOutputSub2Pusan2()
{
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlIOMonitorOutputSub2Pusan2)
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER1_ORI_POS, m_btnLoadCarr1OriPos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER1_ALIGN_POS, m_btnLoadCarr1AlignPos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER1_TABLE_POS, m_btnLoadCarr1TablePos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER1_CART_POS, m_btnLoadCarr1CartPos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER2_ORI_POS, m_btnLoadCarr2OriPos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER2_ALIGN_POS, m_btnLoadCarr2AlignPos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER2_TABLE_POS, m_btnLoadCarr2TablePos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER2_CART_POS, m_btnLoadCarr2CartPos);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER1_SUCTION_ON, m_btnLoadCarr1SuctionOn);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER1_SUCTION_OFF, m_btnLoadCarr1SuctionOff);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER2_SUCTION_ON, m_btnLoadCarr2SuctionOn);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER2_SUCTION_OFF, m_btnLoadCarr2SuctionOff);
	DDX_Control(pDX, IDC_BUTTON_LOADER_CLAMP, m_btnLoadClamp);
	DDX_Control(pDX, IDC_BUTTON_LOADER_UNCLAMP, m_btnLoadUnclamp);
	DDX_Control(pDX, IDC_BUTTON_LOADER_TABLE_FORWARD, m_btnLoadTableFwd);
	DDX_Control(pDX, IDC_BUTTON_LOADER_TABLE_BACKWARD, m_btnLoadTableBwd);
	DDX_Control(pDX, IDC_BUTTON_LOADER_ALIGN_FORWARD, m_btnLoadAlignFwd);
	DDX_Control(pDX, IDC_BUTTON_LOADER_ALIGN_BACKWARD, m_btnLoadAlignBwd);
	DDX_Control(pDX, IDC_BUTTON_LOADER_SHEET_TABLE_FORWARD, m_btnLoadSheetTableFwd);
	DDX_Control(pDX, IDC_BUTTON_LOADER_SHEET_TABLE_BACKWARD, m_btnLoadSheetTableBwd);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER1_ORI_POS, m_btnUnloadCarr1OriPos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER1_ALIGN_POS, m_btnUnloadCarr1AlignPos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER1_TABLE_POS, m_btnUnloadCarr1TablePos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER1_CART_POS, m_btnUnloadCarr1CartPos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER2_ORI_POS, m_btnUnloadCarr2OriPos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER2_ALIGN_POS, m_btnUnloadCarr2AlignPos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER2_TABLE_POS, m_btnUnloadCarr2TablePos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER2_CART_POS, m_btnUnloadCarr2CartPos);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER1_SUCTION_ON, m_btnUnloadCarr1SuctionOn);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER1_SUCTION_OFF, m_btnUnloadCarr1SuctionOff);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER2_SUCTION_ON, m_btnUnloadCarr2SuctionOn);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER2_SUCTION_OFF, m_btnUnloadCarr2SuctionOff);
	DDX_Control(pDX, IDC_BUTTON_NGBOX_FORWARD, m_btnNGBoxFwd);
	DDX_Control(pDX, IDC_BUTTON_NGBOX_BACKWARD, m_btnNGBoxBwd);
	
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_CLAMP, m_btnUnloadClamp);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_UNCLAMP, m_btnUnloadUnclamp);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_TABLE_FORWARD, m_btnUnloadTableFwd);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_TABLE_BACKWARD, m_btnUnloadTableBwd);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_ELV_LOAD_POS, m_btnUnloadElvUnloadPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_ELV_ORI_POS, m_btnUnloadElvOriPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_ELV_LOAD_POS, m_btnLoadElvLoadPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_ELV_ORI_POS, m_btnLoadElvOriPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS, m_btnLoadCarrCartPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS2, m_btnLoadCarrCartPos2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_CARR_TABLE_POS, m_btnLoadCarrTablePos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_CARR_ALIGN_POS, m_btnLoadCarrAlignPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_CARR_ALIGN_POS2, m_btnLoadCarrAlignPos2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_CARR_CART_POS, m_btnUnloadCarrCartPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_CARR_TABLE_POS, m_btnUnloadCarrTablePos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_CARR_ALIGN_POS, m_btnUnloadCarrAlignPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_LOADER1, m_btnResetLoader1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_LOADER2, m_btnResetLoader2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_LOADER_TABLE, m_btnResetLoaderTable);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_UNLOADER1, m_btnResetUnLoader1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_UNLOADER2, m_btnResetUnLoader2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_UNLOADER_TABLE, m_btnResetUnLoaderTable);

	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER1_INIT, m_btnUnloadPicker1Init);
	DDX_Control(pDX, IDC_BUTTON_UNLOADER_PICKER2_INIT, m_btnUnloadPicker2Init);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER1_INIT, m_btnLoadPicker1Init);
	DDX_Control(pDX, IDC_BUTTON_LOADER_PICKER2_INIT, m_btnLoadPicker2Init);

	DDX_Control(pDX, IDC_BUTTON_ML3_RESET, m_btnML3Reset);
	
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlIOMonitorOutputSub2Pusan2, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlIOMonitorOutputSub2Pusan2)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_ORI_POS, OnButtonLoaderPicker1OriPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_ALIGN_POS, OnButtonLoaderPicker1AlignPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_TABLE_POS, OnButtonLoaderPicker1TablePos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_CART_POS, OnButtonLoaderPicker1CartPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER2_ORI_POS, OnButtonLoaderPicker2OriPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER2_ALIGN_POS, OnButtonLoaderPicker2AlignPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER2_TABLE_POS, OnButtonLoaderPicker2TablePos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER2_CART_POS, OnButtonLoaderPicker2CartPos)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_SUCTION_ON, OnButtonLoaderPicker1SuctionOn)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_SUCTION_OFF, OnButtonLoaderPicker1SuctionOff)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER2_SUCTION_ON, OnButtonLoaderPicker2SuctionOn)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER2_SUCTION_OFF, OnButtonLoaderPicker2SuctionOff)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_CLAMP, OnButtonLoaderClamp)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_UNCLAMP, OnButtonLoaderUnclamp)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_TABLE_FORWARD, OnButtonLoaderTableForward)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_TABLE_BACKWARD, OnButtonLoaderTableBackward)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_ALIGN_FORWARD, OnButtonLoaderAlignForward)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_ALIGN_BACKWARD, OnButtonLoaderAlignBackward)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_SHEET_TABLE_FORWARD, OnButtonLoaderSheetTableForward)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_SHEET_TABLE_BACKWARD, OnButtonLoaderSheetTableBackward)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER1_ORI_POS, OnButtonUnloaderPicker1OriPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER1_ALIGN_POS, OnButtonUnloaderPicker1AlignPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER1_TABLE_POS, OnButtonUnloaderPicker1TablePos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER1_CART_POS, OnButtonUnloaderPicker1CartPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER2_ORI_POS, OnButtonUnloaderPicker2OriPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER2_ALIGN_POS, OnButtonUnloaderPicker2AlignPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER2_TABLE_POS, OnButtonUnloaderPicker2TablePos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER2_CART_POS, OnButtonUnloaderPicker2CartPos)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER1_SUCTION_ON, OnButtonUnloaderPicker1SuctionOn)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER1_SUCTION_OFF, OnButtonUnloaderPicker1SuctionOff)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER2_SUCTION_ON, OnButtonUnloaderPicker2SuctionOn)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER2_SUCTION_OFF, OnButtonUnloaderPicker2SuctionOff)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_CLAMP, OnButtonUnloaderClamp)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_UNCLAMP, OnButtonUnloaderUnclamp)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_TABLE_FORWARD, OnButtonUnloaderTableForward)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_TABLE_BACKWARD, OnButtonUnloaderTableBackward)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_ELV_LOAD_POS, OnButtonOutputUnloaderElvLoadPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_ELV_ORI_POS, OnButtonOutputUnloaderElvOriPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_ELV_LOAD_POS, OnButtonOutputLoaderElvLoadPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_ELV_ORI_POS, OnButtonOutputLoaderElvOriPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_CARR_CART_POS, OnButtonOutputUnloaderCarrCartPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_CARR_ALIGN_POS, OnButtonOutputUnloaderCarrAlignPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_CARR_TABLE_POS, OnButtonOutputUnloaderCarrTablePos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_CARR_TABLE_POS, OnButtonOutputLoaderCarrTablePos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_CARR_ALIGN_POS, OnButtonOutputLoaderCarrAlignPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_CARR_ALIGN_POS2, OnButtonOutputLoaderCarrAlignPos2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS, OnButtonOutputLoaderCarrCartPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS2, OnButtonOutputLoaderCarrCartPos2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_LOADER1, OnButtonOutputResetLoader1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_LOADER2, OnButtonOutputResetLoader2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_LOADER_TABLE, OnButtonOutputResetLoaderTable)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_UNLOADER1, OnButtonOutputResetUnloader1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_UNLOADER2, OnButtonOutputResetUnloader2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_UNLOADER_TABLE, OnButtonOutputResetUnloaderTable)

	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_NGBOX_FORWARD, &CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonNgboxForward)
	ON_BN_CLICKED(IDC_BUTTON_NGBOX_BACKWARD, &CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonNgboxBackward)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER1_INIT, &CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonUnloaderPicker1Init)
	ON_BN_CLICKED(IDC_BUTTON_UNLOADER_PICKER2_INIT, &CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonUnloaderPicker2Init)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_INIT, &CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonLoaderPicker1Init)
	ON_BN_CLICKED(IDC_BUTTON_LOADER_PICKER1_INIT2, &CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonLoaderPicker1Init2)
	ON_BN_CLICKED(IDC_BUTTON_ML3_RESET, &CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonMl3Reset)
	ON_BN_CLICKED(IDC_BUTTON_ALL_REJECT, &CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonAllReject)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub2Pusan2 diagnostics

#ifdef _DEBUG
void CPaneManualControlIOMonitorOutputSub2Pusan2::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub2Pusan2 message handlers

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class

	InitBtnControl();


}

void CPaneManualControlIOMonitorOutputSub2Pusan2::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(95, "Arial Bold");

	GetDlgItem(IDC_STATIC_UNLOADER_CARRIER)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_LOADER_CARRIER)->SetFont( &m_fntBtn );
	
	m_btnLoadCarr1OriPos.SetFont( &m_fntBtn );
	m_btnLoadCarr1OriPos.SetFlat( FALSE );
	m_btnLoadCarr1OriPos.EnableBallonToolTip();
	m_btnLoadCarr1OriPos.SetToolTipText( _T("LoaderPicker1 Origin Pos") );
	m_btnLoadCarr1OriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr1OriPos.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarr1AlignPos.SetFont( &m_fntBtn );
	m_btnLoadCarr1AlignPos.SetFlat( FALSE );
	m_btnLoadCarr1AlignPos.EnableBallonToolTip();
	m_btnLoadCarr1AlignPos.SetToolTipText( _T("LoaderPicker1 Align Pos") );
	m_btnLoadCarr1AlignPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr1AlignPos.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarr1TablePos.SetFont( &m_fntBtn );
	m_btnLoadCarr1TablePos.SetFlat( FALSE );
	m_btnLoadCarr1TablePos.EnableBallonToolTip();
	m_btnLoadCarr1TablePos.SetToolTipText( _T("LoaderPicker1 Table Pos") );
	m_btnLoadCarr1TablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr1TablePos.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarr1CartPos.SetFont( &m_fntBtn );
	m_btnLoadCarr1CartPos.SetFlat( FALSE );
	m_btnLoadCarr1CartPos.EnableBallonToolTip();
	m_btnLoadCarr1CartPos.SetToolTipText( _T("LoaderPicker1 Cart Pos") );
	m_btnLoadCarr1CartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr1CartPos.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarr2OriPos.SetFont( &m_fntBtn );
	m_btnLoadCarr2OriPos.SetFlat( FALSE );
	m_btnLoadCarr2OriPos.EnableBallonToolTip();
	m_btnLoadCarr2OriPos.SetToolTipText( _T("LoaderPicker2 Origin Pos") );
	m_btnLoadCarr2OriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr2OriPos.SetBtnCursor(IDC_HAND_1);
	
	m_btnLoadCarr2AlignPos.SetFont( &m_fntBtn );
	m_btnLoadCarr2AlignPos.SetFlat( FALSE );
	m_btnLoadCarr2AlignPos.EnableBallonToolTip();
	m_btnLoadCarr2AlignPos.SetToolTipText( _T("LoaderPicker2 Align Pos") );
	m_btnLoadCarr2AlignPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr2AlignPos.SetBtnCursor(IDC_HAND_1);
	
	m_btnLoadCarr2TablePos.SetFont( &m_fntBtn );
	m_btnLoadCarr2TablePos.SetFlat( FALSE );
	m_btnLoadCarr2TablePos.EnableBallonToolTip();
	m_btnLoadCarr2TablePos.SetToolTipText( _T("LoaderPicker2 Table Pos") );
	m_btnLoadCarr2TablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr2TablePos.SetBtnCursor(IDC_HAND_1);
	
	m_btnLoadCarr2CartPos.SetFont( &m_fntBtn );
	m_btnLoadCarr2CartPos.SetFlat( FALSE );
	m_btnLoadCarr2CartPos.EnableBallonToolTip();
	m_btnLoadCarr2CartPos.SetToolTipText( _T("LoaderPicker2 Cart Pos") );
	m_btnLoadCarr2CartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr2CartPos.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarr1SuctionOn.SetFont( &m_fntBtn );
	m_btnLoadCarr1SuctionOn.SetFlat( FALSE );
	m_btnLoadCarr1SuctionOn.EnableBallonToolTip();
	m_btnLoadCarr1SuctionOn.SetToolTipText( _T("LoaderPicker1 Suction On") );
	m_btnLoadCarr1SuctionOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr1SuctionOn.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarr1SuctionOff.SetFont( &m_fntBtn );
	m_btnLoadCarr1SuctionOff.SetFlat( FALSE );
	m_btnLoadCarr1SuctionOff.EnableBallonToolTip();
	m_btnLoadCarr1SuctionOff.SetToolTipText( _T("LoaderPicker1 Suction Off") );
	m_btnLoadCarr1SuctionOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr1SuctionOff.SetBtnCursor(IDC_HAND_1);

	m_btnLoadCarr2SuctionOn.SetFont( &m_fntBtn );
	m_btnLoadCarr2SuctionOn.SetFlat( FALSE );
	m_btnLoadCarr2SuctionOn.EnableBallonToolTip();
	m_btnLoadCarr2SuctionOn.SetToolTipText( _T("LoaderPicker2 Suction On") );
	m_btnLoadCarr2SuctionOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr2SuctionOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnLoadCarr2SuctionOff.SetFont( &m_fntBtn );
	m_btnLoadCarr2SuctionOff.SetFlat( FALSE );
	m_btnLoadCarr2SuctionOff.EnableBallonToolTip();
	m_btnLoadCarr2SuctionOff.SetToolTipText( _T("LoaderPicker2 Suction Off") );
	m_btnLoadCarr2SuctionOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarr2SuctionOff.SetBtnCursor(IDC_HAND_1);

	m_btnLoadClamp.SetFont(&m_fntBtn );
	m_btnLoadClamp.SetFlat( FALSE );
	m_btnLoadClamp.EnableBallonToolTip();
	m_btnLoadClamp.SetToolTipText( _T("Loader Clamp") );
	m_btnLoadClamp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadClamp.SetBtnCursor(IDC_HAND_1);

	m_btnLoadUnclamp.SetFont(&m_fntBtn );
	m_btnLoadUnclamp.SetFlat( FALSE );
	m_btnLoadUnclamp.EnableBallonToolTip();
	m_btnLoadUnclamp.SetToolTipText( _T("Loader Unclamp") );
	m_btnLoadUnclamp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadUnclamp.SetBtnCursor(IDC_HAND_1);

	m_btnLoadTableFwd.SetFont(&m_fntBtn );
	m_btnLoadTableFwd.SetFlat( FALSE );
	m_btnLoadTableFwd.EnableBallonToolTip();
	m_btnLoadTableFwd.SetToolTipText( _T("LoadTable Left") );
	m_btnLoadTableFwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadTableFwd.SetBtnCursor(IDC_HAND_1);

	m_btnLoadTableBwd.SetFont(&m_fntBtn );
	m_btnLoadTableBwd.SetFlat( FALSE );
	m_btnLoadTableBwd.EnableBallonToolTip();
	m_btnLoadTableBwd.SetToolTipText( _T("LoadTable Right") );
	m_btnLoadTableBwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadTableBwd.SetBtnCursor(IDC_HAND_1);

	m_btnLoadAlignFwd.SetFont(&m_fntBtn );
	m_btnLoadAlignFwd.SetFlat( FALSE );
	m_btnLoadAlignFwd.EnableBallonToolTip();
	m_btnLoadAlignFwd.SetToolTipText( _T("LoadAlign Forward") );
	m_btnLoadAlignFwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadAlignFwd.SetBtnCursor(IDC_HAND_1);

	m_btnLoadAlignBwd.SetFont(&m_fntBtn );
	m_btnLoadAlignBwd.SetFlat( FALSE );
	m_btnLoadAlignBwd.EnableBallonToolTip();
	m_btnLoadAlignBwd.SetToolTipText( _T("LoadAlign Backward") );
	m_btnLoadAlignBwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadAlignBwd.SetBtnCursor(IDC_HAND_1);

	m_btnLoadSheetTableFwd.SetFont(&m_fntBtn );
	m_btnLoadSheetTableFwd.SetFlat( FALSE );
	m_btnLoadSheetTableFwd.EnableBallonToolTip();
	m_btnLoadSheetTableFwd.SetToolTipText( _T("LoadSheetTable Forward") );
	m_btnLoadSheetTableFwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadSheetTableFwd.SetBtnCursor(IDC_HAND_1);

	m_btnLoadSheetTableBwd.SetFont(&m_fntBtn );
	m_btnLoadSheetTableBwd.SetFlat( FALSE );
	m_btnLoadSheetTableBwd.EnableBallonToolTip();
	m_btnLoadSheetTableBwd.SetToolTipText( _T("LoadSheetTable Backward") );
	m_btnLoadSheetTableBwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadSheetTableBwd.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr1OriPos.SetFont( &m_fntBtn );
	m_btnUnloadCarr1OriPos.SetFlat( FALSE );
	m_btnUnloadCarr1OriPos.EnableBallonToolTip();
	m_btnUnloadCarr1OriPos.SetToolTipText( _T("UnloaderPicker1 Origin Pos") );
	m_btnUnloadCarr1OriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr1OriPos.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr1AlignPos.SetFont( &m_fntBtn );
	m_btnUnloadCarr1AlignPos.SetFlat( FALSE );
	m_btnUnloadCarr1AlignPos.EnableBallonToolTip();
	m_btnUnloadCarr1AlignPos.SetToolTipText( _T("UnloaderPicker1 Align Pos") );
	m_btnUnloadCarr1AlignPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr1AlignPos.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr1TablePos.SetFont( &m_fntBtn );
	m_btnUnloadCarr1TablePos.SetFlat( FALSE );
	m_btnUnloadCarr1TablePos.EnableBallonToolTip();
	m_btnUnloadCarr1TablePos.SetToolTipText( _T("UnloaderPicker1 Table Pos") );
	m_btnUnloadCarr1TablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr1TablePos.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr1CartPos.SetFont( &m_fntBtn );
	m_btnUnloadCarr1CartPos.SetFlat( FALSE );
	m_btnUnloadCarr1CartPos.EnableBallonToolTip();
	m_btnUnloadCarr1CartPos.SetToolTipText( _T("UnloaderPicker1 Cart Pos") );
	m_btnUnloadCarr1CartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr1CartPos.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr2OriPos.SetFont( &m_fntBtn );
	m_btnUnloadCarr2OriPos.SetFlat( FALSE );
	m_btnUnloadCarr2OriPos.EnableBallonToolTip();
	m_btnUnloadCarr2OriPos.SetToolTipText( _T("UnloaderPicker2 Origin Pos") );
	m_btnUnloadCarr2OriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr2OriPos.SetBtnCursor(IDC_HAND_1);
	
	m_btnUnloadCarr2AlignPos.SetFont( &m_fntBtn );
	m_btnUnloadCarr2AlignPos.SetFlat( FALSE );
	m_btnUnloadCarr2AlignPos.EnableBallonToolTip();
	m_btnUnloadCarr2AlignPos.SetToolTipText( _T("UnloaderPicker2 Align Pos") );
	m_btnUnloadCarr2AlignPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr2AlignPos.SetBtnCursor(IDC_HAND_1);
	
	m_btnUnloadCarr2TablePos.SetFont( &m_fntBtn );
	m_btnUnloadCarr2TablePos.SetFlat( FALSE );
	m_btnUnloadCarr2TablePos.EnableBallonToolTip();
	m_btnUnloadCarr2TablePos.SetToolTipText( _T("UnloaderPicker2 Table Pos") );
	m_btnUnloadCarr2TablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr2TablePos.SetBtnCursor(IDC_HAND_1);
	
	m_btnUnloadCarr2CartPos.SetFont( &m_fntBtn );
	m_btnUnloadCarr2CartPos.SetFlat( FALSE );
	m_btnUnloadCarr2CartPos.EnableBallonToolTip();
	m_btnUnloadCarr2CartPos.SetToolTipText( _T("UnloaderPicker2 Cart Pos") );
	m_btnUnloadCarr2CartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr2CartPos.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr1SuctionOn.SetFont( &m_fntBtn );
	m_btnUnloadCarr1SuctionOn.SetFlat( FALSE );
	m_btnUnloadCarr1SuctionOn.EnableBallonToolTip();
	m_btnUnloadCarr1SuctionOn.SetToolTipText( _T("UnloaderPicker1 Suction On") );
	m_btnUnloadCarr1SuctionOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr1SuctionOn.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr1SuctionOff.SetFont( &m_fntBtn );
	m_btnUnloadCarr1SuctionOff.SetFlat( FALSE );
	m_btnUnloadCarr1SuctionOff.EnableBallonToolTip();
	m_btnUnloadCarr1SuctionOff.SetToolTipText( _T("UnloaderPicker1 Suction Off") );
	m_btnUnloadCarr1SuctionOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr1SuctionOff.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadCarr2SuctionOn.SetFont( &m_fntBtn );
	m_btnUnloadCarr2SuctionOn.SetFlat( FALSE );
	m_btnUnloadCarr2SuctionOn.EnableBallonToolTip();
	m_btnUnloadCarr2SuctionOn.SetToolTipText( _T("UnloaderPicker2 Suction On") );
	m_btnUnloadCarr2SuctionOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr2SuctionOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnUnloadCarr2SuctionOff.SetFont( &m_fntBtn );
	m_btnUnloadCarr2SuctionOff.SetFlat( FALSE );
	m_btnUnloadCarr2SuctionOff.EnableBallonToolTip();
	m_btnUnloadCarr2SuctionOff.SetToolTipText( _T("UnloaderPicker2 Suction Off") );
	m_btnUnloadCarr2SuctionOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarr2SuctionOff.SetBtnCursor(IDC_HAND_1);

	m_btnNGBoxFwd.SetFont( &m_fntBtn );
	m_btnNGBoxFwd.SetFlat( FALSE );
	m_btnNGBoxFwd.EnableBallonToolTip();
	m_btnNGBoxFwd.SetToolTipText( _T("Unloader NG Box Forward") );
	m_btnNGBoxFwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnNGBoxFwd.SetBtnCursor(IDC_HAND_1);

	m_btnNGBoxBwd.SetFont( &m_fntBtn );
	m_btnNGBoxBwd.SetFlat( FALSE );
	m_btnNGBoxBwd.EnableBallonToolTip();
	m_btnNGBoxBwd.SetToolTipText( _T("Unloader NG Box Backward") );
	m_btnNGBoxBwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnNGBoxBwd.SetBtnCursor(IDC_HAND_1);

	if(gProcessINI.m_sProcessSystem.bNoUseNGBox)
	{
		m_btnNGBoxFwd.ShowWindow(SW_HIDE);
		m_btnNGBoxBwd.ShowWindow(SW_HIDE);
	}


	m_btnUnloadClamp.SetFont(&m_fntBtn );
	m_btnUnloadClamp.SetFlat( FALSE );
	m_btnUnloadClamp.EnableBallonToolTip();
	m_btnUnloadClamp.SetToolTipText( _T("Unloader Clamp") );
	m_btnUnloadClamp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadClamp.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadUnclamp.SetFont(&m_fntBtn );
	m_btnUnloadUnclamp.SetFlat( FALSE );
	m_btnUnloadUnclamp.EnableBallonToolTip();
	m_btnUnloadUnclamp.SetToolTipText( _T("Unloader Unclamp") );
	m_btnUnloadUnclamp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadUnclamp.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadTableFwd.SetFont(&m_fntBtn );
	m_btnUnloadTableFwd.SetFlat( FALSE );
	m_btnUnloadTableFwd.EnableBallonToolTip();
	m_btnUnloadTableFwd.SetToolTipText( _T("UnloadTable Left") );
	m_btnUnloadTableFwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadTableFwd.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadTableBwd.SetFont(&m_fntBtn );
	m_btnUnloadTableBwd.SetFlat( FALSE );
	m_btnUnloadTableBwd.EnableBallonToolTip();
	m_btnUnloadTableBwd.SetToolTipText( _T("UnloadTable Right") );
	m_btnUnloadTableBwd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadTableBwd.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadElvUnloadPos.SetFont( &m_fntBtn );
	m_btnUnloadElvUnloadPos.SetFlat( FALSE );
	m_btnUnloadElvUnloadPos.EnableBallonToolTip();
	m_btnUnloadElvUnloadPos.SetToolTipText( _T("UnloadElevator move to unload pos") );
	m_btnUnloadElvUnloadPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadElvUnloadPos.SetBtnCursor(IDC_HAND_1);	
	
	m_btnUnloadElvOriPos.SetFont( &m_fntBtn );
	m_btnUnloadElvOriPos.SetFlat( FALSE );
	m_btnUnloadElvOriPos.EnableBallonToolTip();
	m_btnUnloadElvOriPos.SetToolTipText( _T("UnloadElevator move to origin pos") );
	m_btnUnloadElvOriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadElvOriPos.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadElvLoadPos.SetFont( &m_fntBtn );
	m_btnLoadElvLoadPos.SetFlat( FALSE );
	m_btnLoadElvLoadPos.EnableBallonToolTip();
	m_btnLoadElvLoadPos.SetToolTipText( _T("LoadElevator move to loading pos") );
	m_btnLoadElvLoadPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadElvLoadPos.SetBtnCursor(IDC_HAND_1);	
	
	m_btnLoadElvOriPos.SetFont( &m_fntBtn );
	m_btnLoadElvOriPos.SetFlat( FALSE );
	m_btnLoadElvOriPos.EnableBallonToolTip();
	m_btnLoadElvOriPos.SetToolTipText( _T("LoadElevator move to origin pos") );
	m_btnLoadElvOriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadElvOriPos.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadCarrCartPos.SetFont( &m_fntBtn );
	m_btnLoadCarrCartPos.SetFlat( FALSE );
	m_btnLoadCarrCartPos.EnableBallonToolTip();
	m_btnLoadCarrCartPos.SetToolTipText( _T("LoaderCarrier move to cart pos") );
	m_btnLoadCarrCartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarrCartPos.SetBtnCursor(IDC_HAND_1);	
	
	m_btnLoadCarrCartPos2.SetFont( &m_fntBtn );
	m_btnLoadCarrCartPos2.SetFlat( FALSE );
	m_btnLoadCarrCartPos2.EnableBallonToolTip();
	m_btnLoadCarrCartPos2.SetToolTipText( _T("LoaderCarrier move to cart pos2") );
	m_btnLoadCarrCartPos2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarrCartPos2.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadCarrTablePos.SetFont( &m_fntBtn );
	m_btnLoadCarrTablePos.SetFlat( FALSE );
	m_btnLoadCarrTablePos.EnableBallonToolTip();
	m_btnLoadCarrTablePos.SetToolTipText( _T("LoaderCarrier move to table pos") );
	m_btnLoadCarrTablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarrTablePos.SetBtnCursor(IDC_HAND_1);	
	
	m_btnLoadCarrAlignPos.SetFont( &m_fntBtn );
	m_btnLoadCarrAlignPos.SetFlat( FALSE );
	m_btnLoadCarrAlignPos.EnableBallonToolTip();
	m_btnLoadCarrAlignPos.SetToolTipText( _T("LoaderCarrier move to align pos") );
	m_btnLoadCarrAlignPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarrAlignPos.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadCarrAlignPos2.SetFont( &m_fntBtn );
	m_btnLoadCarrAlignPos2.SetFlat( FALSE );
	m_btnLoadCarrAlignPos2.EnableBallonToolTip();
	m_btnLoadCarrAlignPos2.SetToolTipText( _T("LoaderCarrier move to align pos2") );
	m_btnLoadCarrAlignPos2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarrAlignPos2.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloadCarrCartPos.SetFont( &m_fntBtn );
	m_btnUnloadCarrCartPos.SetFlat( FALSE );
	m_btnUnloadCarrCartPos.EnableBallonToolTip();
	m_btnUnloadCarrCartPos.SetToolTipText( _T("UnloaderCarrier move to cart pos") );
	m_btnUnloadCarrCartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarrCartPos.SetBtnCursor(IDC_HAND_1);	
	
	m_btnUnloadCarrTablePos.SetFont( &m_fntBtn );
	m_btnUnloadCarrTablePos.SetFlat( FALSE );
	m_btnUnloadCarrTablePos.EnableBallonToolTip();
	m_btnUnloadCarrTablePos.SetToolTipText( _T("UnloaderCarrier move to table pos") );
	m_btnUnloadCarrTablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarrTablePos.SetBtnCursor(IDC_HAND_1);	
	
	m_btnUnloadCarrAlignPos.SetFont( &m_fntBtn );
	m_btnUnloadCarrAlignPos.SetFlat( FALSE );
	m_btnUnloadCarrAlignPos.EnableBallonToolTip();
	m_btnUnloadCarrAlignPos.SetToolTipText( _T("UnloaderCarrier move to align pos") );
	m_btnUnloadCarrAlignPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarrAlignPos.SetBtnCursor(IDC_HAND_1);

	m_btnResetLoader1.SetFont( &m_fntBtn );
	m_btnResetLoader1.SetFlat( FALSE );
	m_btnResetLoader1.EnableBallonToolTip();
	m_btnResetLoader1.SetToolTipText( _T("LoaderPicker1 Reset") );
	m_btnResetLoader1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetLoader1.SetBtnCursor(IDC_HAND_1);

	m_btnResetLoader2.SetFont( &m_fntBtn );
	m_btnResetLoader2.SetFlat( FALSE );
	m_btnResetLoader2.EnableBallonToolTip();
	m_btnResetLoader2.SetToolTipText( _T("LoaderPicker2 Reset") );
	m_btnResetLoader2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetLoader2.SetBtnCursor(IDC_HAND_1);

	m_btnResetLoaderTable.SetFont( &m_fntBtn );
	m_btnResetLoaderTable.SetFlat( FALSE );
	m_btnResetLoaderTable.EnableBallonToolTip();
	m_btnResetLoaderTable.SetToolTipText( _T("LoaderTable Reset") );
	m_btnResetLoaderTable.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetLoaderTable.SetBtnCursor(IDC_HAND_1);
	
	m_btnResetUnLoader1.SetFont( &m_fntBtn );
	m_btnResetUnLoader1.SetFlat( FALSE );
	m_btnResetUnLoader1.EnableBallonToolTip();
	m_btnResetUnLoader1.SetToolTipText( _T("UnloaderPicker1 Reset") );
	m_btnResetUnLoader1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetUnLoader1.SetBtnCursor(IDC_HAND_1);
	
	m_btnResetUnLoader2.SetFont( &m_fntBtn );
	m_btnResetUnLoader2.SetFlat( FALSE );
	m_btnResetUnLoader2.EnableBallonToolTip();
	m_btnResetUnLoader2.SetToolTipText( _T("UnloaderPicker2 Reset") );
	m_btnResetUnLoader2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetUnLoader2.SetBtnCursor(IDC_HAND_1);
	
	m_btnResetUnLoaderTable.SetFont( &m_fntBtn );
	m_btnResetUnLoaderTable.SetFlat( FALSE );
	m_btnResetUnLoaderTable.EnableBallonToolTip();
	m_btnResetUnLoaderTable.SetToolTipText( _T("UnloaderTable Reset") );
	m_btnResetUnLoaderTable.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetUnLoaderTable.SetBtnCursor(IDC_HAND_1);


	m_btnUnloadPicker1Init.SetFont( &m_fntBtn );
	m_btnUnloadPicker1Init.SetFlat( FALSE );
	m_btnUnloadPicker1Init.EnableBallonToolTip();
	m_btnUnloadPicker1Init.SetToolTipText( _T("UnloaderPicker1 Initialize") );
	m_btnUnloadPicker1Init.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadPicker1Init.SetBtnCursor(IDC_HAND_1);

	m_btnUnloadPicker2Init.SetFont( &m_fntBtn );
	m_btnUnloadPicker2Init.SetFlat( FALSE );
	m_btnUnloadPicker2Init.EnableBallonToolTip();
	m_btnUnloadPicker2Init.SetToolTipText( _T("UnloaderPicker2 Initialize") );
	m_btnUnloadPicker2Init.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadPicker2Init.SetBtnCursor(IDC_HAND_1);

	m_btnLoadPicker1Init.SetFont( &m_fntBtn );
	m_btnLoadPicker1Init.SetFlat( FALSE );
	m_btnLoadPicker1Init.EnableBallonToolTip();
	m_btnLoadPicker1Init.SetToolTipText( _T("LoaderPicker1 Initialize") );
	m_btnLoadPicker1Init.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadPicker1Init.SetBtnCursor(IDC_HAND_1);

	m_btnLoadPicker2Init.SetFont( &m_fntBtn );
	m_btnLoadPicker2Init.SetFlat( FALSE );
	m_btnLoadPicker2Init.EnableBallonToolTip();
	m_btnLoadPicker2Init.SetToolTipText( _T("LoaderPicker2 Initialize") );
	m_btnLoadPicker2Init.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadPicker2Init.SetBtnCursor(IDC_HAND_1);

	m_btnML3Reset.SetFont( &m_fntBtn );
	m_btnML3Reset.SetFlat( FALSE );
	m_btnML3Reset.EnableBallonToolTip();
	m_btnML3Reset.SetToolTipText( _T("ML3 Reset") );
	m_btnML3Reset.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnML3Reset.SetBtnCursor(IDC_HAND_1);

	


	m_btnUnloadPicker1Init.ShowWindow(SW_HIDE);
	m_btnUnloadPicker2Init.ShowWindow(SW_HIDE);
	m_btnLoadPicker1Init.ShowWindow(SW_HIDE);
	m_btnLoadPicker2Init.ShowWindow(SW_HIDE);
	m_btnML3Reset.ShowWindow(SW_HIDE);


	
	
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::UpdateStatus()
{
	BOOL bStatus1, bStatus2;

	// LP1
	bStatus1 = m_pMotor->IsLP1P1Up();
	bStatus2 = m_pMotor->IsLP1P2Up();
	if(bStatus1 && bStatus2)
	{
		m_btnLoadCarr1OriPos.SetSelection(TRUE);
		m_btnLoadCarr1AlignPos.SetSelection(FALSE);
		m_btnLoadCarr1TablePos.SetSelection(FALSE);
//		m_btnLoadCarr1CartPos.SetSelection(FALSE);
	}
	else if(!bStatus1 && bStatus2)
	{
		m_btnLoadCarr1OriPos.SetSelection(FALSE);
		m_btnLoadCarr1AlignPos.SetSelection(TRUE);
		m_btnLoadCarr1TablePos.SetSelection(FALSE);
//		m_btnLoadCarr1CartPos.SetSelection(FALSE);
	}
//	else if(bStatus1 && !bStatus2)
//	{
//		m_btnLoadCarr1OriPos.SetSelection(FALSE);
//		m_btnLoadCarr1AlignPos.SetSelection(FALSE);
//		m_btnLoadCarr1TablePos.SetSelection(TRUE);
//		m_btnLoadCarr1CartPos.SetSelection(FALSE);
//	}
	else
	{
		m_btnLoadCarr1OriPos.SetSelection(FALSE);
		m_btnLoadCarr1AlignPos.SetSelection(FALSE);
		m_btnLoadCarr1TablePos.SetSelection(TRUE);
//		m_btnLoadCarr1CartPos.SetSelection(TRUE);
	}
	
	// LP2
	bStatus1 = m_pMotor->IsLP2P1Up();
	bStatus2 = m_pMotor->IsLP2P2Up();
	if(bStatus1 && bStatus2)
	{
		m_btnLoadCarr2OriPos.SetSelection(TRUE);
		m_btnLoadCarr2AlignPos.SetSelection(FALSE);
		m_btnLoadCarr2TablePos.SetSelection(FALSE);
		m_btnLoadCarr2CartPos.SetSelection(FALSE);
	}
	else if(!bStatus1 && bStatus2)
	{
		m_btnLoadCarr2OriPos.SetSelection(FALSE);
		m_btnLoadCarr2AlignPos.SetSelection(TRUE);
		m_btnLoadCarr2TablePos.SetSelection(FALSE);
		m_btnLoadCarr2CartPos.SetSelection(FALSE);
	}
	else if(bStatus1 && !bStatus2)
	{
		m_btnLoadCarr2OriPos.SetSelection(FALSE);
		m_btnLoadCarr2AlignPos.SetSelection(FALSE);
		m_btnLoadCarr2TablePos.SetSelection(TRUE);
		m_btnLoadCarr2CartPos.SetSelection(FALSE);
	}
	else
	{
		m_btnLoadCarr2OriPos.SetSelection(FALSE);
		m_btnLoadCarr2AlignPos.SetSelection(FALSE);
		m_btnLoadCarr2TablePos.SetSelection(TRUE);
		m_btnLoadCarr2CartPos.SetSelection(TRUE);
	}
	
	// LoaderClamp
	bStatus1 = m_pMotor->IsLoaderCartClamp();
	m_btnLoadClamp.SetSelection(bStatus1);
	m_btnLoadUnclamp.SetSelection(!bStatus1);
	
	// Picker1Vacuum
	bStatus1 = m_pMotor->IsLoaderPicker1Vacuum();
	m_btnLoadCarr1SuctionOn.SetSelection(bStatus1);
	m_btnLoadCarr1SuctionOff.SetSelection(!bStatus1);
	
	// Picker2Vacuum
	bStatus1 = m_pMotor->IsLoaderPicker2Vacuum();
	m_btnLoadCarr2SuctionOn.SetSelection(bStatus1);
	m_btnLoadCarr2SuctionOff.SetSelection(!bStatus1);

	// AlignTable
	bStatus1 = m_pMotor->IsLoaderAlignTableForward();
	m_btnLoadTableFwd.SetSelection(!bStatus1);
	m_btnLoadTableBwd.SetSelection(bStatus1);
	
	// AlignGuide
	bStatus1 = m_pMotor->IsAlignGuideForward();
	if(bStatus1 == 3)
	{
		m_btnLoadAlignFwd.SetSelection(FALSE);
		m_btnLoadAlignBwd.SetSelection(FALSE);
	}
	else 
	{
		m_btnLoadAlignFwd.SetSelection(bStatus1);
		m_btnLoadAlignBwd.SetSelection(!bStatus1);
	}
		
	
	// AlignSheetTable
	bStatus1 = m_pMotor->IsAlignSheetTableForward();
	m_btnLoadSheetTableFwd.SetSelection(bStatus1);
	m_btnLoadSheetTableBwd.SetSelection(!bStatus1);

	// UP1
	bStatus1 = m_pMotor->IsULP1P1Up();
	bStatus2 = m_pMotor->IsULP1P2Up();
	if(bStatus1 && bStatus2)
	{
		m_btnUnloadCarr1OriPos.SetSelection(TRUE);
		m_btnUnloadCarr1AlignPos.SetSelection(FALSE);
		m_btnUnloadCarr1TablePos.SetSelection(FALSE);
		m_btnUnloadCarr1CartPos.SetSelection(FALSE);
	}
	else if(!bStatus1 && bStatus2)
	{
		m_btnUnloadCarr1OriPos.SetSelection(FALSE);
		m_btnUnloadCarr1AlignPos.SetSelection(TRUE);
		m_btnUnloadCarr1TablePos.SetSelection(FALSE);
		m_btnUnloadCarr1CartPos.SetSelection(FALSE);
	}
	else if(bStatus1 && !bStatus2)
	{
		m_btnUnloadCarr1OriPos.SetSelection(FALSE);
		m_btnUnloadCarr1AlignPos.SetSelection(FALSE);
		m_btnUnloadCarr1TablePos.SetSelection(TRUE);
		m_btnUnloadCarr1CartPos.SetSelection(FALSE);
	}
	else
	{
		m_btnUnloadCarr1OriPos.SetSelection(FALSE);
		m_btnUnloadCarr1AlignPos.SetSelection(FALSE);
		m_btnUnloadCarr1TablePos.SetSelection(TRUE);
		m_btnUnloadCarr1CartPos.SetSelection(TRUE);
	}
	
	// UP2
	bStatus1 = m_pMotor->IsULP2P1Up();
	bStatus2 = m_pMotor->IsULP2P2Up();
	if(bStatus1 && bStatus2)
	{
		m_btnUnloadCarr2OriPos.SetSelection(TRUE);
		m_btnUnloadCarr2AlignPos.SetSelection(FALSE);
		m_btnUnloadCarr2TablePos.SetSelection(FALSE);
		m_btnUnloadCarr2CartPos.SetSelection(FALSE);
	}
	else if(!bStatus1 && bStatus2)
	{
		m_btnUnloadCarr2OriPos.SetSelection(FALSE);
		m_btnUnloadCarr2AlignPos.SetSelection(TRUE);
		m_btnUnloadCarr2TablePos.SetSelection(FALSE);
		m_btnUnloadCarr2CartPos.SetSelection(FALSE);
	}
	else if(bStatus1 && !bStatus2)
	{
		m_btnUnloadCarr2OriPos.SetSelection(FALSE);
		m_btnUnloadCarr2AlignPos.SetSelection(FALSE);
		m_btnUnloadCarr2TablePos.SetSelection(TRUE);
		m_btnUnloadCarr2CartPos.SetSelection(FALSE);
	}
	else
	{
		m_btnUnloadCarr2OriPos.SetSelection(FALSE);
		m_btnUnloadCarr2AlignPos.SetSelection(FALSE);
		m_btnUnloadCarr2TablePos.SetSelection(TRUE);
		m_btnUnloadCarr2CartPos.SetSelection(TRUE);
	}
	
	// Picker1Vacuum
	bStatus1 = m_pMotor->IsUnloaderPicker1Vacuum();
	m_btnUnloadCarr1SuctionOn.SetSelection(bStatus1);
	m_btnUnloadCarr1SuctionOff.SetSelection(!bStatus1);
	
	// Picker2Vacuum
	bStatus1 = m_pMotor->IsUnloaderPicker2Vacuum();
	m_btnUnloadCarr2SuctionOn.SetSelection(bStatus1);
	m_btnUnloadCarr2SuctionOff.SetSelection(!bStatus1);

	// AlignTable
	bStatus1 = m_pMotor->IsUnloaderCartClamp();
	m_btnUnloadClamp.SetSelection(bStatus1);
	m_btnUnloadUnclamp.SetSelection(!bStatus1);
	
	// UnloaderClamp
	bStatus1 = m_pMotor->IsUnloaderAlignTableForward(); // 2010.1.21 �ݴ��
	m_btnUnloadTableFwd.SetSelection(!bStatus1);
	m_btnUnloadTableBwd.SetSelection(bStatus1);

	// Unloader NG Box
	if(!gProcessINI.m_sProcessSystem.bNoUseNGBox)
	{
		bStatus1 = m_pMotor->IsUnloaderNGBoxForward();
		m_btnNGBoxFwd.SetSelection(bStatus1);
		bStatus1 = m_pMotor->IsUnloaderNGBoxBackward();
		m_btnNGBoxBwd.SetSelection(bStatus1);
	}

	if(gDeviceFactory.GetMotor()->IsLCinCartPos())
		m_btnLoadCarrCartPos.SetSelection( 1 );
	else
		m_btnLoadCarrCartPos.SetSelection( 0 );

	if(gDeviceFactory.GetMotor()->IsLCinCartPos2())
		m_btnLoadCarrCartPos2.SetSelection( 1 );
	else
		m_btnLoadCarrCartPos2.SetSelection( 0 );
	
	if(gDeviceFactory.GetMotor()->IsLCinLoadPos())
		m_btnLoadCarrTablePos.SetSelection( 1 );
	else
		m_btnLoadCarrTablePos.SetSelection( 0 );

	if(gDeviceFactory.GetMotor()->IsLCinAlignPos())
		m_btnLoadCarrAlignPos.SetSelection( 1 );
	else
		m_btnLoadCarrAlignPos.SetSelection( 0 );

	if(gDeviceFactory.GetMotor()->IsLCinAlignPos2())
		m_btnLoadCarrAlignPos2.SetSelection( 1 );
	else
		m_btnLoadCarrAlignPos2.SetSelection( 0 );

	if(gDeviceFactory.GetMotor()->IsUCinCartPos())
		m_btnUnloadCarrCartPos.SetSelection( 1 );
	else
		m_btnUnloadCarrCartPos.SetSelection( 0 );
	
	if(gDeviceFactory.GetMotor()->IsUCinUnloadPos())
		m_btnUnloadCarrTablePos.SetSelection( 1 );
	else
		m_btnUnloadCarrTablePos.SetSelection( 0 );
	
	if(gDeviceFactory.GetMotor()->IsUCinAlignPos())
		m_btnUnloadCarrAlignPos.SetSelection( 1 );
	else
		m_btnUnloadCarrAlignPos.SetSelection( 0 );

	// Loader1 Status
	if(gDeviceFactory.GetMotor()->IsLoaderPicker1PCBExist())
		m_bStatusLoader1 = TRUE;
	else
		m_bStatusLoader1 = FALSE;
	
	m_btnResetLoader1.SetSelection(m_bStatusLoader1);
	
	// Loader2 Status
	if(gDeviceFactory.GetMotor()->IsLoaderPicker2PCBExist())
		m_bStatusLoader2 = TRUE;
	else
		m_bStatusLoader2 = FALSE;
	
	m_btnResetLoader2.SetSelection(m_bStatusLoader2);
	
	// Unloader1 Status
	if(gDeviceFactory.GetMotor()->IsUnloaderPicker1PCBExist())
		m_bStatusUnloader1 = TRUE;
	else
		m_bStatusUnloader1 = FALSE;
	
	m_btnResetUnLoader1.SetSelection(m_bStatusUnloader1);
	
	// Unloader2 Status
	if(gDeviceFactory.GetMotor()->IsUnloaderPicker2PCBExist())
		m_bStatusUnloader2 = TRUE;
	else
		m_bStatusUnloader2 = FALSE;
	
	m_btnResetUnLoader2.SetSelection(m_bStatusUnloader2);
	
	// Loader Aligner Status
	if(gDeviceFactory.GetMotor()->IsAlignerPCBExist())
		m_bStatusAligner = TRUE;
	else
		m_bStatusAligner = FALSE;
	
	m_btnResetLoaderTable.SetSelection(m_bStatusAligner);
	
	// Unloader Aligner Status
	if(gDeviceFactory.GetMotor()->IsULAlignerPCBExist())
		m_bStatusAligner2 = TRUE;
	else
		m_bStatusAligner2 = FALSE;
	
	m_btnResetUnLoaderTable.SetSelection(m_bStatusAligner2);


}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default

	UpdateStatus();
	
	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_nTimerID = SetTimer(9982, 300, NULL);
#ifndef __MP920_MOTOR__
		m_pMotor = gDeviceFactory.GetMotor();
#else
		m_pMotor = gDeviceFactory.GetMotor();
#endif
	}
//	SetTimer(9982, 1000, NULL);
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
//	KillTimer(9982);
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderPicker1OriPos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker1Init();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderPicker1AlignPos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker1Align();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderPicker1TablePos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker1P2();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderPicker1CartPos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker1Load();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderPicker2OriPos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker2Init();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderPicker2AlignPos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker2Align();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderPicker2TablePos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker2P2();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderPicker2CartPos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderPicker2Load();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderPicker1SuctionOn() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderVacuum1On();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderPicker1SuctionOff() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderVacuum1Off();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderPicker2SuctionOn() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderVacuum2On();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderPicker2SuctionOff() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderVacuum2Off();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderClamp() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderClampForward();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderUnclamp() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderClampBackward();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderTableForward() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderTableForward();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderTableBackward() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderTableBackward();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderAlignForward() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderAlignXForward();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderAlignBackward() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderAlignXBackward();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderSheetTableForward() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderAlignYForward();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonLoaderSheetTableBackward() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->LoaderAlignYBackward();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderPicker1OriPos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker1Init();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderPicker1AlignPos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker1P2();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderPicker1TablePos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker1Table();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderPicker1CartPos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker1Unload();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderPicker2OriPos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker2Init();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderPicker2AlignPos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker2P2();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderPicker2TablePos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker2Table();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderPicker2CartPos() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderPicker2Unload();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderPicker1SuctionOn() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderVacuum1On();	
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderPicker1SuctionOff() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderVacuum1Off();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderPicker2SuctionOn() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderVacuum2On();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderPicker2SuctionOff() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderVacuum2Off();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderClamp() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderClampForward();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderUnclamp() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderClampBackward();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderTableForward() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderTableForward();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonUnloaderTableBackward() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->UnloaderTableBackward();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputUnloaderElvLoadPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderElvUnloadPos();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputUnloaderElvOriPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderElvOriginPos();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputLoaderElvLoadPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderElvLoadPos();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputLoaderElvOriPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderElvOriginPos();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputUnloaderCarrCartPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderCarrierUnloadPos();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputUnloaderCarrAlignPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderCarrierAlignPos();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputUnloaderCarrTablePos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderCarrierTablePos();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputLoaderCarrTablePos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderCarrierLoadPos();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputLoaderCarrAlignPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderCarrierAlignPos();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputLoaderCarrAlignPos2() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderCarrierAlignPos2();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputLoaderCarrCartPos() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderCarrierCartPos();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputLoaderCarrCartPos2() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderCarrierCartPos2();
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputResetUnloader1() 
{
	// TODO: Add your control notification handler code here
	m_bStatusUnloader1 = !m_bStatusUnloader1;
	
	if(m_bStatusUnloader1)
		gDeviceFactory.GetMotor()->Unloader1PCBExist(TRUE);
	else
		gDeviceFactory.GetMotor()->Unloader1PCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputResetUnloader2() 
{
	// TODO: Add your control notification handler code here
	m_bStatusUnloader2 = !m_bStatusUnloader2;
	
	if(m_bStatusUnloader2)
		gDeviceFactory.GetMotor()->Unloader2PCBExist(TRUE);
	else
		gDeviceFactory.GetMotor()->Unloader2PCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputResetLoader1() 
{
	// TODO: Add your control notification handler code here
	m_bStatusLoader1 = !m_bStatusLoader1;
	
	if(m_bStatusLoader1)
		gDeviceFactory.GetMotor()->Loader1PCBExist(TRUE);
	else
		gDeviceFactory.GetMotor()->Loader1PCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputResetLoader2() 
{
	// TODO: Add your control notification handler code here
	m_bStatusLoader2 = !m_bStatusLoader2;
	
	if(m_bStatusLoader2)
		gDeviceFactory.GetMotor()->Loader2PCBExist(TRUE);
	else
		gDeviceFactory.GetMotor()->Loader2PCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputResetUnloaderTable() 
{
	// TODO: Add your control notification handler code here
	m_bStatusAligner2 = !m_bStatusAligner2;
	
	if(m_bStatusAligner2)
		gDeviceFactory.GetMotor()->ULAlignTablePCBExist(TRUE);
	else
		gDeviceFactory.GetMotor()->ULAlignTablePCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub2Pusan2::OnButtonOutputResetLoaderTable() 
{
	// TODO: Add your control notification handler code here
	m_bStatusAligner = !m_bStatusAligner;
	
	if(m_bStatusAligner)
		gDeviceFactory.GetMotor()->AlignTablePCBExist(TRUE);
	else
		gDeviceFactory.GetMotor()->AlignTablePCBExist(FALSE);
}


BOOL CPaneManualControlIOMonitorOutputSub2Pusan2::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_IO_Output2) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonNgboxForward()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	m_pMotor->UnloaderNGBoxForward();
}


void CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonNgboxBackward()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	m_pMotor->UnloaderNGBoxBackward();
}


void CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonUnloaderPicker1Init()
{
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	m_pMotor->SetOrigin(AXIS_UP1);
}


void CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonUnloaderPicker2Init()
{
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	m_pMotor->SetOrigin(AXIS_UP2);
}


void CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonLoaderPicker1Init()
{
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	m_pMotor->SetOrigin(AXIS_LP1);
}


void CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonLoaderPicker1Init2()
{
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	m_pMotor->SetOrigin(AXIS_LP2);
}


void CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonMl3Reset()
{
	// TODO: Add your control notification handler code here

	if(gDeviceFactory.GetMotor()->IsML3ResetEnd())
		return;
	BOOL bSuccess = FALSE;
	gDeviceFactory.GetMotor()->SetOutPort(PORT_ML3_RESET, TRUE);
	int nCount = 0;
	while(TRUE)
	{
		MessageLoopWait(10);
		nCount++;

		if(gDeviceFactory.GetMotor()->IsML3ResetEnd())
		{
			bSuccess = TRUE;
			break;
		}

		if(nCount > 100 * 60)//1��
			break;
	}

	if(bSuccess == FALSE)
	{
		AfxMessageBox("ML3 Reset Fail");
	}
}


void CPaneManualControlIOMonitorOutputSub2Pusan2::OnBnClickedButtonAllReject()
{
	gDeviceFactory.GetMotor()->TablePCBReset();
}

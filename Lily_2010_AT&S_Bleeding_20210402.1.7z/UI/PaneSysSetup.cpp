﻿// PaneSysSetup.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetup.h"
#include "..\MODEL\DProcessINI.h"
#include "PaneSysSetupDir.h"


	#include "PaneSysSetupLaserScannerLarge.h"
	#include "PaneSysSetupMotorPusan1.h"
	#include "PaneSysSetupBeamDumperPusan1.h"


#include "PaneSysSetupTableCal.h"
#include "PaneSysSetupCollimator.h"

#include "PaneSysSetupMGC.h"
#include "PaneSysSetupMGC2.h"
#include "PaneSysSetupZCal.h"
#include "PaneSysSetupTophat.h"
#include "..\model\DSystemINI.h"
#include "..\model\deasydrillerini.h"
#include "..\EasyDrillerDlg.h"
#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "DlgMatroxVisionView.h"
#include "..\alarmmsg.h"
#include "..\device\hdevicefactory.h"
#include "..\device\devicemotor.h"
#include "..\device\heocard.h"
#include "..\device\hvision.h"
#include "..\device\hvisionomi.h"
#include "PaneSysSetupThetaCal.h"
#include "PaneSysSetupComponentTime.h"
#include "PaneSysSetupVacuum.h"

#include "PaneAutoRun.h"
#include "PaneAutoRunViewSystem.h"
#include "model\BeamPathINIFile.h"
#include "model\DBeampathINI.h"
#include "..\model\DTextData.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetup

IMPLEMENT_DYNCREATE(CPaneSysSetup, CFormView)

CPaneSysSetup::CPaneSysSetup()
	: CFormView(CPaneSysSetup::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetup)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pDir					= NULL;
	m_pLaserScanner			= NULL;
	m_pMotor				= NULL;
	m_pTableCal				= NULL;
	m_pCollimator			= NULL;
	m_pBeamDumper			= NULL;
	m_pMGC					= NULL;
	m_pMGC2					= NULL;
	m_pThetaCal				= NULL;
	m_pComponent			= NULL;
	m_pVacuum				= NULL;

	m_pTophat				= NULL;
	m_pZCal				= NULL;
	m_nSel					= 0;
}

CPaneSysSetup::~CPaneSysSetup()
{

}

void CPaneSysSetup::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetup)
	DDX_Control(pDX, IDC_TAB_SYS_SETUP, m_tabSysSetup);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetup, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetup)
	ON_WM_DESTROY()
	ON_NOTIFY(NM_CLICK, IDC_TAB_SYS_SETUP, OnClickTabSysSetup)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetup diagnostics

#ifdef _DEBUG
void CPaneSysSetup::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetup::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetup message handlers

void CPaneSysSetup::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitTabControl();
}

void CPaneSysSetup::InitTabControl()
{
	// Set Button Font
	m_fntTab.CreatePointFont(150, "Arial Bold");

	BOOL bRet = 0;
	CString strCh;
	m_tabSysSetup.SetFont( &m_fntTab );

	// Directory Setting
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = Uni2Multi(L" 路径 ");
	else
		strCh = " Path ";
	bRet = m_tabSysSetup.AddPane( strCh, RUNTIME_CLASS(CPaneSysSetupDir) );
	if( FALSE != bRet )
	{
		m_pDir = static_cast<CPaneSysSetupDir*>(m_tabSysSetup.GetPane(0));
		m_pDir->OnInitialUpdate();
	}
	// Laser Beam Hole
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = Uni2Multi(L" 排列 ");
	else
		strCh = " Align ";
	bRet = m_tabSysSetup.AddPane( strCh, RUNTIME_CLASS(CPaneSysSetupLaserScannerLarge) );
	if( FALSE != bRet )
	{
		m_pLaserScanner = static_cast<CPaneSysSetupLaserScannerLarge*>(m_tabSysSetup.GetPane(1));
		m_pLaserScanner->OnInitialUpdate();
	}
	// Motor Setting
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = Uni2Multi(L" 装置 ");
	else
		strCh = " Device ";
	bRet = m_tabSysSetup.AddPane( strCh, RUNTIME_CLASS(CPaneSysSetupMotorPusan1) );
	if( FALSE != bRet )
	{
		m_pMotor = static_cast<CPaneSysSetupMotorPusan1*>(m_tabSysSetup.GetPane(2));
		m_pMotor->OnInitialUpdate();
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}


	int nPanel = 3;

		// Table Calibration
		if(gSystemINI.m_sHardWare.nLanguageType == 1)
			strCh = Uni2Multi(L" 台面精度 ");
		else
			strCh = " TableCal ";
		bRet = m_tabSysSetup.AddPane( strCh, RUNTIME_CLASS(CPaneSysSetupTableCal) );
		if( FALSE != bRet )
		{
			m_pTableCal = static_cast<CPaneSysSetupTableCal*>(m_tabSysSetup.GetPane(nPanel++));
			m_pTableCal->OnInitialUpdate();
		}

		// Z Calibration
		if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() != 0)
		{
			if(gSystemINI.m_sHardWare.nLanguageType == 1)
				strCh = Uni2Multi(L" Z 轴精度 ");
			else
				strCh = " Z Cal ";
			bRet = m_tabSysSetup.AddPane( strCh, RUNTIME_CLASS(CPaneSysSetupZCal) );
			if( FALSE != bRet )
			{
				m_pZCal = static_cast<CPaneSysSetupZCal*>(m_tabSysSetup.GetPane(nPanel++));
				m_pZCal->OnInitialUpdate();

			}
		}

	

	// MGC
	if(gEasyDrillerINI.m_clsHwOption.m_nMGCMode == 0)
	{
		bRet = m_tabSysSetup.AddPane( _T(" MGC "), RUNTIME_CLASS(CPaneSysSetupMGC) );
		if( FALSE != bRet )
		{
			m_pMGC = static_cast<CPaneSysSetupMGC*>(m_tabSysSetup.GetPane(nPanel++));
			m_pMGC->OnInitialUpdate();
		}
	}
	else
	{
		bRet = m_tabSysSetup.AddPane( _T(" MGC "), RUNTIME_CLASS(CPaneSysSetupMGC2) );
		if( FALSE != bRet )
		{
			m_pMGC2 = static_cast<CPaneSysSetupMGC2*>(m_tabSysSetup.GetPane(nPanel++));
			m_pMGC2->OnInitialUpdate();
		}
	}
	


/*	// Vacuum
	bRet = m_tabSysSetup.AddPane( _T(" Vacuum "), RUNTIME_CLASS(CPaneSysSetupVacuum) );
	if( FALSE != bRet )
	{
		m_pVacuum = static_cast<CPaneSysSetupVacuum*>(m_tabSysSetup.GetPane(nPanel++));
		m_pVacuum->OnInitialUpdate();
		m_pVacuum->SetSystemVacuum( gSystemINI.m_sSystemVacuum );
	}
*/
	// component date npanel =9		//디버깅이 아직 안끝남.  막아놓았음 
	if(gSystemINI.m_sHardWare.nLanguageType == 1)
		strCh = Uni2Multi(L" 组件 ");
	else
		strCh = " Component ";
	bRet = m_tabSysSetup.AddPane( strCh, RUNTIME_CLASS(CPaneSysSetupComponentTime) );
	if( FALSE != bRet )
	{
		m_pComponent = static_cast<CPaneSysSetupComponentTime*>(m_tabSysSetup.GetPane(nPanel++));
		m_pComponent->OnInitialUpdate();
		m_pComponent->SetSystemComponent(gSystemINI.m_sSystemComponent);
		m_pComponent->SetComponentData();
		m_pComponent->DBConnect();
		m_pComponent->SelectComponentList();
		m_pComponent->UpdateUsingTime();
		m_pComponent->CheckComponentOverDate();	
	}



	if(gProcessINI.m_sProcessOption.bTemperCompensationMode || gSystemINI.m_sHardWare.nUseBeamDumper )
	{
		if(gSystemINI.m_sHardWare.nLanguageType == 1)
			strCh = Uni2Multi(L" 过滤光 ");
		else
			strCh = " Dummy Free ";
		bRet = m_tabSysSetup.AddPane( strCh, RUNTIME_CLASS(CPaneSysSetupBeamDumperPusan1) );
		if( FALSE != bRet )
		{
			m_pBeamDumper = static_cast<CPaneSysSetupBeamDumperPusan1*>(m_tabSysSetup.GetPane(nPanel++));
			m_pBeamDumper->OnInitialUpdate();
			m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
		}
		m_nBeamDumperNo = nPanel - 1;
	}

	m_tabSysSetup.ShowPane( m_nSel );
}

void CPaneSysSetup::OnDestroy() 
{
	m_fntTab.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneSysSetup::OnApply()
{
	CString strMessage, strDir, strMotor, strCollimator, strDumper, strTophat, strComponent,strBeamPath;
	if( NULL != m_pDir )
	{
		strDir = m_pDir->GetChangeValueStr();
		if(0 != strDir.CompareNoCase(""))
		{
			strMessage.Format(_T("Directory Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strDir));
			m_pDir->GetDirData();
		}
		

/*		TCHAR sz1stFile[255], sz2ndFile[255];
		lstrcpy(sz1stFile, gEasyDrillerINI.m_clsDirPath.Get1stMasterCalFilePath());
		lstrcpy(sz2ndFile, gEasyDrillerINI.m_clsDirPath.Get2ndMasterCalFilePath());
		
		if(!gDeviceFactory.GetEocard()->LoadCalibrationFile(sz1stFile, sz2ndFile))
		{
#ifndef __TEST__
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
			strMsg.Format(strString, _T("ASC"));
			ErrMessage(strMsg);

			CString strTemp;
			strTemp.Format(_T("%s or %s"), gEasyDrillerINI.m_clsDirPath.Get1stMasterCalFilePath(), gEasyDrillerINI.m_clsDirPath.Get2ndMasterCalFilePath());
			strMsg.Format(strString, strTemp);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
			return;
#endif
		}
*/	}

	if( NULL != m_pMotor )
	{
		m_pMotor->OnApply();
		strMotor = m_pMotor->GetChangeValueStr();
		m_pMotor->GetSystemDevice( &gSystemINI.m_sSystemDevice );

		gDeviceFactory.GetMotor()->SetAxisInfo( gSystemINI.m_sAxisInfo );
		gDeviceFactory.GetMotor()->DownloadAxisInfo();
		gDeviceFactory.GetEocard()->SetFieldSizeToEocard();
		gDeviceFactory.GetMotor()->SetWaterFlow1Value(gSystemINI.m_sSystemDevice.dWaterFlowSetting1);
		gDeviceFactory.GetMotor()->SetWaterFlow2Value(gSystemINI.m_sSystemDevice.dWaterFlowSetting2);
		gDeviceFactory.GetMotor()->SetMainAirValue(gSystemINI.m_sSystemDevice.dMainAirSetting);
		gDeviceFactory.GetMotor()->SetDustSuctionValue(gSystemINI.m_sSystemDevice.dDustSuctionSetting);
		gDeviceFactory.GetMotor()->SetTableVauumValue(TRUE, gSystemINI.m_sSystemDevice.dTableVacuumSetting1);
		gDeviceFactory.GetMotor()->SetTableVauumValue(FALSE, gSystemINI.m_sSystemDevice.dTableVacuumSetting2);
//		gDeviceFactory.GetVision()->SetPixel( 0, gSystemINI.m_sSystemDevice.d1stHighPixel );
//		gDeviceFactory.GetVision()->SetPixel( 1, gSystemINI.m_sSystemDevice.d1stLowPixel );
//		gDeviceFactory.GetVision()->SetPixel( 2, gSystemINI.m_sSystemDevice.d2ndHighPixel );
//		gDeviceFactory.GetVision()->SetPixel( 3, gSystemINI.m_sSystemDevice.d2ndLowPixel );

		gDeviceFactory.GetVision()->TransformPixel();
		if(0 != strMotor.CompareNoCase(""))
		{
			strMessage.Format(_T("Device Setting Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strMotor));
		}
	}

	if( NULL != m_pCollimator )
	{
		m_pCollimator->OnApply();
		strCollimator = m_pCollimator->GetChangeValueStr();
		m_pCollimator->GetSystemCollimator( &gSystemINI.m_sSystemCollimator );

//		gDeviceFactory.GetMotor()->SetFixedMaskPos( gBeamPathINI.m_sBeampath.nFixedMask);

		if(0 != strCollimator.CompareNoCase(""))
		{
			strMessage.Format(_T("Collimator Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strCollimator));
		}
	}

	if( NULL != m_pTophat )
	{
		m_pTophat->OnApply();
		strTophat = m_pTophat->GetChangeValueStr();
		m_pTophat->GetSystemTophat( &gSystemINI.m_sSystemTophat );
		
		
		if(0 != strTophat.CompareNoCase(""))
		{
			strMessage.Format(_T("Tophat Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strTophat));
		}
	}

	//2011604
	if( NULL != m_pComponent )
	{
		m_pComponent->OnApply();
		strComponent = m_pComponent->GetChangeValueStr();
		m_pComponent->GetSystemComponent( &gSystemINI.m_sSystemComponent );
 		
 		
 		if(0 != strComponent.CompareNoCase(""))
 		{
 			strMessage.Format(_T("Component Save "));
 			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strComponent));
 		}
	}


	if( NULL != m_pBeamDumper) // 20070730
	{
		m_pBeamDumper->OnApply();
		strDumper = m_pBeamDumper->GetChangeValueStr();
		m_pBeamDumper->GetSystemDevice( &gSystemINI.m_sSystemDump );

		if(!gDeviceFactory.GetEocard()->DummyParamSet())
		{
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("Dump Parameter Set Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			ErrMessage(_T("Error : Dummy shot parameter download Failure"));
		}

		if(!gDeviceFactory.GetEocard()->StandbyParamSet())
		{
#ifndef __TEST__
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("Standby Parameter Set Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			ErrMessage(_T("Error : Standby shot parameter download Failure"));
#endif
		}
		
		if(0 != strDumper.CompareNoCase(""))
		{
			strMessage.Format(_T("Beam Dumper Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strDumper));
		}

//		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pAutoRun->m_pSystem->SetSystemData(gSystemINI.m_sSystemDump);
	}

	if( NULL != m_pVacuum )
	{
		m_pVacuum->OnApply();
		strMotor = m_pVacuum->GetChangeValueStr();
		m_pVacuum->GetSystemVacuum( &gSystemINI.m_sSystemVacuum );
		
//		gDeviceFactory.GetMotor()->SetTableVacuumLimit(gSystemINI.m_sSystemVacuum.dTable1Vacuum, gSystemINI.m_sSystemVacuum.dTable2Vacuum);
		
		if(0 != strMotor.CompareNoCase(""))
		{
			strMessage.Format(_T("Vacuum Setting Save "));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strMotor));
		}
	}



	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, EASYDRILL_INI))
	{
		ErrMsgDlg(STDGNALM109);
	}
	else
	{
		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, SYSTEM_INI))
		{
			ErrMsgDlg(STDGNALM110);
		}
		else
		{
			ErrMessage(IDS_DATA_CHANGED);
			
			gTextData.RemoveAllCharInfo();
			gTextData.RemoveResultData();
			gTextData.InitCharData();
		}

		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, BEAMPATH_INI))
		{
			ErrMsgDlg(STDGNALM114);
		}
	}
}

int CPaneSysSetup::GetTabCurSel()
{
	return m_tabSysSetup.GetCurSel();
}

void CPaneSysSetup::EnableTab(BOOL bEnable)
{
//	m_tabSysSetup.EnableWindow(bEnable);
	m_tabSysSetup.TabChangeEnable(bEnable);
}

void CPaneSysSetup::OnClickTabSysSetup(NMHDR* pNMHDR, LRESULT* pResult) 
{
	((CEasyDrillerDlg*)::AfxGetMainWnd())->ActiveStaticForKeyboardError();
	int nSel = m_tabSysSetup.GetCurSel();
	BOOL bSideVision = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetSideStatus();
	::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_TABLE, FALSE);
	if( nSel == m_nSel )
		return;
	
	if( 1 == nSel )
	{
		m_pLaserScanner->SetAOMDrawMember(0);

		m_pLaserScanner->SetShutterStatus();
		if(!bSideVision)
		{
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
		}
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_TABLE, TRUE);
		::AfxGetMainWnd()->SendMessage(UM_TABLE_MODE, TABLE_ELSE);
	}
	else if( 3 == nSel )
	{

			m_pLaserScanner->StopExternalLaser();
			if(!bSideVision)
				m_pTableCal->ConnectView();
		
	}

	else if( 4 == nSel)
	{

		
			m_pLaserScanner->StopExternalLaser();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
		
	}
	else if( 5 == nSel)
	{
			m_pLaserScanner->StopExternalLaser();
		
	}
	else if( 6 == nSel)
	{

			m_pLaserScanner->StopExternalLaser();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
		
	}
	else if(7 == nSel)
	{

			m_pLaserScanner->StopExternalLaser();
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
		
	}
	else if( 7 == nSel)
	{

			m_pLaserScanner->StopExternalLaser();
			
			if(!bSideVision)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
				else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
			}
		
	}
	else
	{
		m_pLaserScanner->StopExternalLaser();
		
		if(!bSideVision)
		{
			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow(SW_HIDE);
			else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow(SW_HIDE);
		}
	}

	m_nSel = nSel;
	ChangeTab();
	
	*pResult = 0;
}

void CPaneSysSetup::ChangeTab()
{
	//gDeviceFactory.GetEocard()->SetApplyCalibrationFile(0, TRUE);
	//gDeviceFactory.GetEocard()->SetApplyCalibrationFile(1, TRUE);

	if( 0 == m_nSel )
	{
		m_pDir->SetDirData();
	}
	else if( 1 == m_nSel )
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);
		//gDeviceFactory.GetEocard()->SetApplyCalibrationFile(0, FALSE);
		//gDeviceFactory.GetEocard()->SetApplyCalibrationFile(1, FALSE);
		m_pLaserScanner->SetAOMDrawMember(0);

		m_pLaserScanner->m_chkApplyAsc.SetCheck(FALSE);
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_TABLE, TRUE);
		::AfxGetMainWnd()->SendMessage(UM_TABLE_MODE, TABLE_ELSE);
		
	}
	else if( 2 == m_nSel )
	{
		m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}

	else if( 6 == m_nSel)
	{
		m_pComponent->SetSystemComponent(gSystemINI.m_sSystemComponent);
	}
	else if( 8 == m_nSel)
	{

	}


	if( m_nBeamDumperNo == m_nSel ) //20070730
	{
		if(m_pBeamDumper)
		{
			m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
//			m_pBeamDumper->SetBeamDumperData();
		}
	}
	else
	{

	}
	::AfxGetMainWnd()->SendMessage( UM_SYSTEMSUB_UI_CHANGE, m_nSel, 0 );
}

void CPaneSysSetup::SetAuthorityByLevel(int nLevel)
{

	if(m_pLaserScanner != NULL)
		m_pLaserScanner->SetAuthorityByLevel(nLevel);

	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 && m_pCollimator != NULL)
		m_pCollimator->SetAuthorityByLevel(nLevel);

	if(m_pDir != NULL)
		m_pDir->SetAuthorityByLevel(nLevel);

	if(m_pMGC != NULL)
		m_pMGC->SetAuthorityByLevel(nLevel);

	if(m_pMGC2 != NULL)
		m_pMGC2->SetAuthorityByLevel(nLevel);

	if(m_pMotor != NULL)
		m_pMotor->SetAuthorityByLevel(nLevel);

	if(m_pTableCal != NULL)
		m_pTableCal->SetAuthorityByLevel(nLevel);

	if(m_pThetaCal != NULL)
		m_pThetaCal->SetAuthorityByLevel(nLevel);



	if(m_pZCal)
		m_pZCal->SetAuthorityByLevel(nLevel);

	if(m_pComponent)
		m_pComponent->SetAuthorityByLevel(nLevel);
	//201161 사용건한 주기 
	//	if(m_pComponent != NULL)	
//		m_pComponent->SetAuthorityByLevel(nLevel);
}

void CPaneSysSetup::CheckComponentPreAcq()
{
	//m_pComponent->ShowComponentOverDate();
	m_pComponent->CheckComponentOverDate();
}

void CPaneSysSetup::UpdateIniUI(int nVal)
{
	if(UI_ALL == nVal || (nVal & SYSTEM_PATH))
	{
		if(m_pDir != NULL)
			m_pDir->SetDirData();
	}
	if(UI_ALL == nVal || (nVal & SYSTEM_DEVICE))
	{
		if(m_pMotor != NULL)
			m_pMotor->SetSystemDevice( gSystemINI.m_sSystemDevice );
	}

	if(UI_ALL == nVal || (nVal & SYSTEM_DUMPER))
	{
		if(m_pBeamDumper != NULL)
			m_pBeamDumper->SetSystemDevice( gSystemINI.m_sSystemDump );
	}
}

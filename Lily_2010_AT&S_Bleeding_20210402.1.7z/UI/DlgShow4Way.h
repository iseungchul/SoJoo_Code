#if !defined(AFX_DlgShow4Way_H__604C9ABC_9B6A_41B5_889A_EABBBDC3B000__INCLUDED_)
#define AFX_DlgShow4Way_H__604C9ABC_9B6A_41B5_889A_EABBBDC3B000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgShow4Way.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGen form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "USimpleTab.h"
#include "UEasyButtonEx.h"
#include "ColorStatic.h"
#include "..\Model\DProject.h"




class CDlgShow4Way : public CDialog
{
DECLARE_DYNCREATE(CDlgShow4Way)

// Form Data
public:
		  	CDlgShow4Way(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgShow4Way();
	enum { IDD = IDD_DLG_SHOW_4WAY };
	CListBox	m_lboxResult;
	//}}AFX_DATA

// Attributes
public:
	void DisplayShow4Way(CString strStatus);
	void InitBtnControl();
// Operations
public:


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgShow4Way)
public:
	virtual BOOL Create(CWnd* pParentWnd);

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:


	CFont						m_fntBtn;
	CFont		m_fntList;
	// Generated message map functions
	//{{AFX_MSG(CDlgShow4Way)
		virtual BOOL OnInitDialog();

	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnProductClear();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DlgShow4Way_H__604C9ABC_9B6A_41B5_889A_EABBBDC3B000__INCLUDED_)

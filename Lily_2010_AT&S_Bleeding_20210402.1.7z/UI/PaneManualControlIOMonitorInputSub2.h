#if !defined(AFX_PANEMANUALCONTROLIOMONITORINPUTSUB2_H__F6D3152F_D5A0_4F47_91EA_E647F282597D__INCLUDED_)
#define AFX_PANEMANUALCONTROLIOMONITORINPUTSUB2_H__F6D3152F_D5A0_4F47_91EA_E647F282597D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlIOMonitorInputSub2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub2 form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CPaneManualControlIOMonitorInputSub2 : public CFormView
{
protected:
	CPaneManualControlIOMonitorInputSub2();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlIOMonitorInputSub2)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlIOMonitorInputSub2)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_IO_MONITOR_INPUT_SUB2 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	int m_nTimerID;

// Operations
public:
	void UpdateStatus();

	void InitTimer();
	void DestroyTimer();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlIOMonitorInputSub2)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlIOMonitorInputSub2();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlIOMonitorInputSub2)
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLIOMONITORINPUTSUB2_H__F6D3152F_D5A0_4F47_91EA_E647F282597D__INCLUDED_)

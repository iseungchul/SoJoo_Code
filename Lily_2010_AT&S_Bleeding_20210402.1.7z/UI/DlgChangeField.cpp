// DlgChangeField.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgChangeField.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgChangeField dialog


CDlgChangeField::CDlgChangeField(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgChangeField::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgChangeField)
	m_dFieldSizeX = 0.0;
	m_dFieldSizeY = 0.0;
	//}}AFX_DATA_INIT
}


void CDlgChangeField::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgChangeField)
	DDX_Text(pDX, IDC_EDT_FIELD_SIZE_X, m_dFieldSizeX);
	DDX_Text(pDX, IDC_EDT_FIELD_SIZE_Y, m_dFieldSizeY);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgChangeField, CDialog)
	//{{AFX_MSG_MAP(CDlgChangeField)
	ON_EN_CHANGE(IDC_EDT_FIELD_SIZE_X, OnChangeEdtFieldSizeX)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgChangeField message handlers
void CDlgChangeField::SetDlgFont()
{
	m_dlgFont.CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDC_STATIC1)->SetFont(&m_dlgFont);
	GetDlgItem(IDC_STATIC2)->SetFont(&m_dlgFont);
	GetDlgItem(IDC_STATIC3)->SetFont(&m_dlgFont);
	GetDlgItem(IDC_STATIC4)->SetFont(&m_dlgFont);
	GetDlgItem(IDC_STATIC5)->SetFont(&m_dlgFont);

	m_editFont.CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDC_EDT_FIELD_SIZE_X)->SetFont(&m_editFont);
	GetDlgItem(IDC_EDT_FIELD_SIZE_Y)->SetFont(&m_editFont);

	m_btnFont.CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDOK)->SetFont(&m_btnFont);
	GetDlgItem(IDCANCEL)->SetFont(&m_btnFont);
}

BOOL CDlgChangeField::OnInitDialog()
{
	CDialog::OnInitDialog();
	SetDlgFont();

	return TRUE;
}

void CDlgChangeField::OnChangeEdtFieldSizeX() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	CString strX;
	GetDlgItemText(IDC_EDT_FIELD_SIZE_X, strX);

	SetDlgItemText(IDC_EDT_FIELD_SIZE_Y, strX);
	
}

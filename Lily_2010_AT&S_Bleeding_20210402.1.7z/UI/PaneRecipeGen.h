#if !defined(AFX_PANERECIPEGEN_H__604C9ABC_9B6A_41B5_889A_EABBBDC3B000__INCLUDED_)
#define AFX_PANERECIPEGEN_H__604C9ABC_9B6A_41B5_889A_EABBBDC3B000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneRecipeGen.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGen form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "USimpleTab.h"
#include "UEasyButtonEx.h"
#include "ColorStatic.h"
#include "..\Model\DProject.h"

class	CPaneRecipeGenLayout;

class	CPaneRecipeGenParameter;
class	CPaneRecipeGenData;
class   CPaneRecipeGenParameterNew;
class	CPaneRecipeGenFiducialNew;
class	CPaneRecipeGenParameterNewNext;

class CPaneRecipeGen : public CFormView
{
protected:
	CPaneRecipeGen();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneRecipeGen)

// Form Data
public:
	//{{AFX_DATA(CPaneRecipeGen)
	enum { IDD = IDD_DLG_RECIPE_GEN };
	CColorStatic	m_stcCadPath;
	UEasyButtonEx	m_btnCadData;
	USimpleTab	m_tabRecipe;
	//}}AFX_DATA

// Attributes
public:
	BOOL	m_bProjectOpen;
	int			m_nPaneNo;

// Operations
public:
	void EnableTab(BOOL bEnable);
	BOOL SortArea();
	int	GetShowPane() {return m_nPaneNo;};
	void ShowTabPane(int nPaneNo);
	void SetShowPane(int nPaneNo);
	void OnMoveVisionView();
	void SetDataLoadStep(int nStep);
	void SetWindowForSkiving(BOOL bSkiving);
	void SetFocusViewer();
	BOOL CheckSameName(CString strPath);

	CPaneRecipeGenData*			m_pDataLoad;
	CPaneRecipeGenLayout*		m_pLayout;
	CPaneRecipeGenParameter*	m_pParam;
	CPaneRecipeGenParameterNew* m_pParamNew;
	CPaneRecipeGenFiducialNew*	m_pFiducialNew;
	CPaneRecipeGenParameterNewNext* m_pParamNewNext;

	BOOL ApplyProject();
	BOOL OpenProject(CString strPath);
	BOOL SetData();
	BOOL SaveProject(CString strPath);
	void InitTabControl();
	void InitBtnControl();
	void InitStaticControl();
	void GetDutyOffset();
	void SetDutyOffset();

	void SetAuthorityByLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneRecipeGen)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPaneRecipeGen();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	CFont						m_fntTab;
	CFont						m_fntBtn;
	CFont						m_fntStatic;
	DProject					m_DProject;

	// Generated message map functions
	//{{AFX_MSG(CPaneRecipeGen)
	afx_msg void OnButtonCadData();
	afx_msg void OnClickTabRecipe(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANERECIPEGEN_H__604C9ABC_9B6A_41B5_889A_EABBBDC3B000__INCLUDED_)

#if !defined(AFX_PANERECIPEGENFIDUCIAL_H__A02AD981_0393_4383_AD8C_4E34698AA413__INCLUDED_)
#define AFX_PANERECIPEGENFIDUCIAL_H__A02AD981_0393_4383_AD8C_4E34698AA413__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneRecipeGenFiducial.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenFiducial form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

class DProject;

class CPaneRecipeGenFiducial : public CFormView
{
protected:
	CPaneRecipeGenFiducial();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneRecipeGenFiducial)

// Form Data
public:
	//{{AFX_DATA(CPaneRecipeGenFiducial)
	enum { IDD = IDD_DLG_RECIPE_GEN_FIDUCIAL };
	CColorEdit	m_edtOrientation;
	CStatic	m_stcPic;
	CColorEdit	m_edtPath;
	CColorEdit	m_edtSizeC;
	CColorEdit	m_edtSizeB;
	CColorEdit	m_edtSizeA;
	CColorEdit	m_edtSize;
	CColorEdit	m_edtRing;
	CColorEdit	m_edtContrast;
	CColorEdit	m_edtCoaxial;
	CColorEdit	m_edtBrightness;
	CColorEdit	m_edtAspectRatio;
	CColorEdit	m_edtAngle;
	CComboBox	m_cmbType;
	int		m_nPolarity;
	CComboBox	m_cmbCamNo;
	UEasyButtonEx	m_btnJobFile;
	//}}AFX_DATA

// Attributes
public:
	double	m_dContrast[4];
	double	m_dBrightness[4];
	int		m_nCoaxial[4];
	int		m_nRing[4];

	CBitmap m_imgAnnulus;
	CBitmap m_imgCircle;
	CBitmap m_imgCross;
	CBitmap m_imgDiamond;
	CBitmap m_imgDouble;
	CBitmap m_imgRect;
	CBitmap m_imgTriangle;
	CBitmap	m_imgUserImage;

	int		m_nModelType;

	CString m_strPath;

// Operations
public:
	void EnableAllWindow(BOOL bEnable);
	BOOL m_bSkiving;
	void SetSkiving(BOOL bSkiving);
	BOOL SetData();
	BOOL GetData(DProject& tempDProject);
	void		InitBtnControl();
	void		InitEditControl();
	void		InitStaticControl();
	void		InitComboControl();
	void		InitBitmap();
	void		SelectPic(int nType);
	void		SetValue(int nNumber);
	void		ChangeControl(BOOL bUse);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneRecipeGenFiducial)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneRecipeGenFiducial();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntEdit;
	CFont		m_fntEdit2;
	CFont		m_fntStatic;
	CFont		m_fntCombo;
	CFont		m_fntBtn;
	CFont		m_fntBtn2;

	// Generated message map functions
	//{{AFX_MSG(CPaneRecipeGenFiducial)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnSelchangeComboType();
	afx_msg void OnSelchangeComboCamNo();
	afx_msg void OnDestroy();
	afx_msg void OnKillfocusEdit();
	afx_msg void OnButtonJobFileOpen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANERECIPEGENFIDUCIAL_H__A02AD981_0393_4383_AD8C_4E34698AA413__INCLUDED_)

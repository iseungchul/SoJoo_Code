// UnitEdit.cpp : implementation file
//

#include "stdafx.h"
#include "UnitEdit.h"
#include "UI\UnitLength.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifndef MAKEDWORD
#define MAKEDWORD(low, high)		((DWORD)(((WORD)(low))|((DWORD)((WORD)(high))) << 16))
#endif

#define SZ_FORMAT_DEGREE	_T("%.3f")

/////////////////////////////////////////////////////////////////////////////
// CUnitEdit

CUnitEdit::CUnitEdit() : m_rcUnitText(0, 0, 0, 0), m_rcUnitBkgnd(0, 0, 0, 0)
{
	m_pUnitFont = NULL;
	m_nRightMargin = 0;
}

CUnitEdit::~CUnitEdit()
{
}

BEGIN_MESSAGE_MAP(CUnitEdit, CEdit)
	//{{AFX_MSG_MAP(CUnitEdit)
	ON_WM_NCCALCSIZE()
	ON_WM_SIZE()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_UNITCHANGE, OnChangeUnit)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUnitEdit message handlers

void CUnitEdit::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	CEdit::OnNcCalcSize(bCalcValidRects, lpncsp);

	// Unit�� �� Width�� ���Ѵ�.
	CDC* pDC = GetDC();
	CFont* pOldFont = pDC->SelectObject(m_pUnitFont);
	int nUnitWidth = pDC->GetTextExtent(m_strUnit).cx + 4;	// Margin�� ���ʿ� 2�� �ش�.
	pDC->SelectObject(pOldFont);
	ReleaseDC(pDC);

	// Unit�� �� Rect�� ���Ѵ�.
	CRect rcText, rcClient;
	GetRect(rcText);
	GetClientRect(rcClient);

	m_rcUnitBkgnd.top = rcClient.top;
	m_rcUnitBkgnd.bottom = rcClient.bottom;
	m_rcUnitBkgnd.left = max(rcClient.left, m_rcUnitBkgnd.right - nUnitWidth - m_nRightMargin);
	m_rcUnitBkgnd.right = rcClient.left + lpncsp->rgrc[0].right - lpncsp->rgrc[0].left;

	m_rcUnitText.top = rcText.top;
	m_rcUnitText.bottom = rcText.bottom;
	m_rcUnitText.left = m_rcUnitBkgnd.left;
	m_rcUnitText.right = m_rcUnitBkgnd.right - m_nRightMargin;
	
	// Client ������ �ٽ� �����ش�.
	lpncsp->rgrc[0].right -= nUnitWidth + m_nRightMargin;
}

void CUnitEdit::OnPaint()
{
	CEdit::Default();

	BOOL bEnabled = IsWindowEnabled();
	BOOL bReadOnly = GetStyle() & ES_READONLY;
	CDC* pDC = GetDC();

	// Unit�� ����� ĥ�Ѵ�.
	::FillRect(pDC->m_hDC, m_rcUnitBkgnd,(bReadOnly || !bEnabled)?
		(HBRUSH)(COLOR_BTNFACE + 1) : (HBRUSH)(COLOR_WINDOW + 1));

	// Unit�� Text Color�� �����Ѵ�.
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(::GetSysColor(bEnabled? COLOR_WINDOWTEXT : COLOR_GRAYTEXT));
	CFont* pOldFont = pDC->SelectObject(m_pUnitFont);
	pDC->DrawText(m_strUnit, m_rcUnitText, DT_CENTER|DT_BOTTOM|DT_SINGLELINE);
	pDC->SelectObject(pOldFont);

	ReleaseDC(pDC);
}

void CUnitEdit::OnSize(UINT nType, int cx, int cy) 
{
	CEdit::OnSize(nType, cx, cy);
	SetWindowPos(NULL, 0, 0, 0, 0, SWP_FRAMECHANGED|SWP_NOMOVE|SWP_NOZORDER|SWP_NOSIZE|SWP_NOACTIVATE);
}

void CUnitEdit::SetUnitText(LPCTSTR lpszUnit)
{
	m_strUnit = lpszUnit;
	SetWindowPos(NULL, 0, 0, 0, 0, SWP_FRAMECHANGED|SWP_NOMOVE|SWP_NOZORDER|SWP_NOSIZE|SWP_NOACTIVATE);
}

void CUnitEdit::SetUnitFont(CFont *pFont)
{
	m_pUnitFont = pFont;
	SetWindowPos(NULL, 0, 0, 0, 0, SWP_FRAMECHANGED|SWP_NOMOVE|SWP_NOZORDER|SWP_NOSIZE|SWP_NOACTIVATE);
}

void CUnitEdit::SetMargins(UINT nLeft, UINT nRight, UINT nMid)
{
	CEdit::SetMargins(nLeft, nMid);

	if (nRight < 0)
		return;
	m_nRightMargin = nRight;
	SetWindowPos(NULL, 0, 0, 0, 0, SWP_FRAMECHANGED|SWP_NOMOVE|SWP_NOZORDER|SWP_NOSIZE|SWP_NOACTIVATE);
}

void CUnitEdit::GetMargins(UINT &nLeft, UINT &nRight, UINT &nMid)
{
	DWORD dwMargins = CEdit::GetMargins();
	nLeft = LOWORD(dwMargins);
	nRight = m_nRightMargin;
	nMid = HIWORD(dwMargins);	
}

DWORD CUnitEdit::GetMargins()
{
	return MAKEDWORD(LOWORD(CEdit::GetMargins()), m_nRightMargin);
}

void CUnitEdit::SetFont(CFont* pFont, BOOL bRedraw)
{
	// ��Ʈ�� �����ϸ� ������ �ٽ� �ٲ�� �ȹǷ� �����Ѵ�.
	UINT nMid = HIWORD(CEdit::GetMargins());

	CEdit::SetFont(pFont, bRedraw);

	DWORD dwMargins = CEdit::GetMargins();
	SetMargins(LOWORD(dwMargins), HIWORD(dwMargins), nMid);
}

LRESULT CUnitEdit::OnChangeUnit(WPARAM wParam, LPARAM lParam)
{
	enLength nOldUnit = (enLength)wParam;
	enLength nNewUnit = (enLength)lParam;
	
	CString str;
	GetWindowText(str);
	double dValue = _tcstod(str, NULL);
	str.Format(CUnitLength::GetFormat(nNewUnit), CUnitLength::GetDisplayValue(CUnitLength::GetInternalValue(dValue, nOldUnit), nNewUnit));
	SetWindowText(str);

	int nLength = (int)lParam;
	SetUnitText(CUnitLength::GetUnit(nNewUnit));

	return TRUE;
}

void CUnitEdit::SetLength(double dLength)
{
	CString str;
	str.Format(CUnitLength::GetFormat(), CUnitLength::GetDisplayValue(dLength));
	SetWindowText(str);
}

double CUnitEdit::GetLength()
{
	CString str;
	GetWindowText(str);
	return CUnitLength::GetInternalValue(_tcstod(str, NULL));
}

void CUnitEdit::SetAngle(double dAngle)
{
	CString str;
	str.Format(SZ_FORMAT_DEGREE, dAngle);
	SetWindowText(str);
}

double CUnitEdit::GetAngle()
{
	CString str;
	GetWindowText(str);
	return _tcstod(str, NULL);
}
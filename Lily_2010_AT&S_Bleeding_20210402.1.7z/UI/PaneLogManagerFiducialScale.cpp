// CPaneLogManagerFiducialScale.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneLogManagerFiducialScale.h"
#include <cfloat>
#include "..\Model\DEasyDrillerIni.h"
#include "..\model\dsystemini.h"
#include "..\Model\DProject.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerFiducialScale
IMPLEMENT_DYNCREATE(CPaneLogManagerFiducialScale, CFormView)

CPaneLogManagerFiducialScale::CPaneLogManagerFiducialScale()
	: CFormView(CPaneLogManagerFiducialScale::IDD)
{
	//{{AFX_DATA_INIT(CPaneLogManagerFiducialScale)
	m_ctEnd = CTime::GetCurrentTime();
	m_ctStart = CTime::GetCurrentTime();

	m_nTimerID = 0;
	m_bShow = FALSE;
	m_bOnTimer = FALSE;
	m_nSelectHead = -1;
	m_strFilePath = "";


	//}}AFX_DATA_INIT
	
	memset(&m_lpszColumnHead2, 0, sizeof(m_lpszColumnHead2));

}

CPaneLogManagerFiducialScale::~CPaneLogManagerFiducialScale()
{
}

void CPaneLogManagerFiducialScale::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneLogManagerFiducialScale)
	DDX_Control(pDX, IDC_LIST_FIDUCIAL_SCALE, m_listFiducialScale);
	DDX_Control(pDX, IDC_DATETIMEPICKER_START, m_dtcStart);
	DDX_Control(pDX, IDC_DATETIMEPICKER_END, m_dtcEnd);
	DDX_Control(pDX, IDC_BUTTON_VIEW, m_btnView);
	DDX_Control(pDX, IDC_BUTTON_FIDSAVE, m_btnSave);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER_END, m_ctEnd);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER_START, m_ctStart);
	DDX_Control(pDX, IDC_DATETIMEPICKER_START, m_dtcStart);
	DDX_Control(pDX, IDC_DATETIMEPICKER_END, m_dtcEnd);
	DDX_Control(pDX, IDC_COMBO_CHOICE, m_cmbHead);

	DDX_Control(pDX, IDC_EDIT_FIDUCIALLOG_HOUR_START, m_edtHourStart);
	DDX_Control(pDX, IDC_EDIT_FIDUCIALLOG_HOUR_END, m_edtHourEnd);
	DDX_Control(pDX, IDC_EDIT_LOTID, m_edtLotID);
	//DDX_CBIndex(pDX, IDC_COMBO_HEAD, m_nSelectHead);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneLogManagerFiducialScale, CFormView)
	//{{AFX_MSG_MAP(CPaneLogManagerFiducialScale)
	ON_WM_TIMER()
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BUTTON_VIEW, OnButtonView)
	ON_BN_CLICKED(IDC_BUTTON_FIDSAVE,OnButtonSave)
	ON_WM_DESTROY()
	ON_NOTIFY(NM_CLICK, IDC_LIST_FIDUCIAL_SCALE, OnClickListLog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerFiducialScale diagnostics

#ifdef _DEBUG
void CPaneLogManagerFiducialScale::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneLogManagerFiducialScale::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerFiducialScale message handlers






void CPaneLogManagerFiducialScale::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitStaticControl();
	InitListControl();
	InitEtcControl();
	InitEditControl();

	m_cmbHead.SetCurSel(0);
	m_nSelectHead = 0;

}

BOOL CPaneLogManagerFiducialScale::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}


void CPaneLogManagerFiducialScale::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	
	// View
	m_btnView.SetFont( &m_fntBtn );
	m_btnView.SetFlat( FALSE );
	m_btnView.EnableBallonToolTip();
	m_btnView.SetToolTipText( _T("View") );
	m_btnView.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnView.SetBtnCursor(IDC_HAND_1);

	// save
	m_btnSave.SetFont( &m_fntBtn );
	m_btnSave.SetFlat( FALSE );
	m_btnSave.EnableBallonToolTip();
	m_btnSave.SetToolTipText( _T("Save") );
	m_btnSave.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSave.SetBtnCursor(IDC_HAND_1);

}

void CPaneLogManagerFiducialScale::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");
	
// 	m_edtHourStart.SetFont( &m_fntEdit );
// 	m_edtHourStart.SetReceivedFlag( 5 ); 
// 
// 	m_edtHourEnd.SetFont( &m_fntEdit );
// 	m_edtHourEnd.SetReceivedFlag( 5 ); 



	m_edtHourStart.SetFont( &m_fntEdit );
	m_edtHourStart.SetForeColor( BLACK_COLOR );
	m_edtHourStart.SetBackColor( WHITE_COLOR );
	m_edtHourStart.SetReceivedFlag( 1 ); 
	m_edtHourStart.SetWindowText( _T("0") );


	m_edtHourEnd.SetFont( &m_fntEdit );
	m_edtHourEnd.SetForeColor( BLACK_COLOR );
	m_edtHourEnd.SetBackColor( WHITE_COLOR );
	m_edtHourEnd.SetReceivedFlag( 1 ); // Floating-Point
	m_edtHourEnd.SetWindowText( _T("24") );

	m_edtLotID.SetFont( &m_fntEdit );
	m_edtLotID.SetForeColor( BLACK_COLOR );
	m_edtLotID.SetBackColor( WHITE_COLOR );
	m_edtLotID.SetWindowText( _T("") );


}


void CPaneLogManagerFiducialScale::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	
	GetDlgItem(IDC_STATIC_1)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_LOTID)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_TIME)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_DATE)->SetFont( &m_fntStatic );
}

void CPaneLogManagerFiducialScale::InitListControl()
{
	// Set List Font
	m_fntList.CreatePointFont(100, "Arial Bold");
	
	m_listFiducialScale.SetFont(&m_fntList);
	
	m_listFiducialScale.SetExtendedStyle(m_listFiducialScale.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);
	
	m_ImageList.DeleteImageList();
	m_ImageList.Create(IDB_SMALL_TYPE, 16, 1, RGB(0, 0, 0));
	
	m_listFiducialScale.DeleteAllItems();
	m_listFiducialScale.SetImageList(&m_ImageList, LVSIL_SMALL);

	lstrcpy(m_lpszColumnHead[0], "Date");
	lstrcpy(m_lpszColumnHead[1], "FidTime");
	lstrcpy(m_lpszColumnHead[2], "Lot ID");
	lstrcpy(m_lpszColumnHead[3], "PNL"); 
	lstrcpy(m_lpszColumnHead[4], "Status");
	lstrcpy(m_lpszColumnHead[5], "Scale X");
	lstrcpy(m_lpszColumnHead[6], "Scale Y");
	lstrcpy(m_lpszColumnHead[7], "Scale R1");
	lstrcpy(m_lpszColumnHead[8], "Scale R2");

	lstrcpy(m_lpszColumnHead[9], "Length Diff.X");
	lstrcpy(m_lpszColumnHead[10], "Length Diff.Y");
	lstrcpy(m_lpszColumnHead[11], "Block");


	m_listFiducialScale.InsertColumn(0, _T(" "), LVCFMT_CENTER, 1);
	m_listFiducialScale.InsertColumn(1, m_lpszColumnHead[0], LVCFMT_CENTER, 80);
	m_listFiducialScale.InsertColumn(2, m_lpszColumnHead[1], LVCFMT_CENTER, 75);
	m_listFiducialScale.InsertColumn(3, m_lpszColumnHead[2], LVCFMT_CENTER, 140);
	m_listFiducialScale.InsertColumn(4 , m_lpszColumnHead[3], LVCFMT_CENTER, 50);
	m_listFiducialScale.InsertColumn(5, m_lpszColumnHead[4], LVCFMT_CENTER, 65);
	m_listFiducialScale.InsertColumn(6, m_lpszColumnHead[5], LVCFMT_CENTER, 70);
	m_listFiducialScale.InsertColumn(7, m_lpszColumnHead[6], LVCFMT_CENTER, 70);
	m_listFiducialScale.InsertColumn(8, m_lpszColumnHead[7], LVCFMT_CENTER, 70);
	m_listFiducialScale.InsertColumn(9, m_lpszColumnHead[8], LVCFMT_CENTER, 70);

	m_listFiducialScale.InsertColumn(10, m_lpszColumnHead[9], LVCFMT_CENTER, 110);
	m_listFiducialScale.InsertColumn(11, m_lpszColumnHead[10], LVCFMT_CENTER, 110);
	m_listFiducialScale.InsertColumn(12, m_lpszColumnHead[11], LVCFMT_CENTER, 50);

	

}

void CPaneLogManagerFiducialScale::InitEtcControl()
{
	// Set Etc Font
	m_fntEtc.CreatePointFont(150, "Arial Bold");	
	m_dtcStart.SetFont( &m_fntEtc );
	m_dtcEnd.SetFont( &m_fntEtc );

	m_cmbHead.SetFont( &m_fntEtc );
	m_nSelectHead = 0;
	m_cmbHead.ResetContent();
	m_cmbHead.AddString(_T("All Scale Log"));
	m_cmbHead.AddString(_T("Over Scale Log"));
	m_cmbHead.SetCurSel(m_nSelectHead);
}



void CPaneLogManagerFiducialScale::OnTimer(UINT nIDEvent) 
{	
	CFormView::OnTimer(nIDEvent);
}



void CPaneLogManagerFiducialScale::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntEtc.DeleteObject();
	m_fntList.DeleteObject();
	m_fntStatic.DeleteObject();
	m_fntEdit.DeleteObject();
	
	CFormView::OnDestroy();
}

void CPaneLogManagerFiducialScale::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

}


void CPaneLogManagerFiducialScale::OnButtonView()
{
	UpdateData(TRUE);
	if(!CheckHour())
		return ;

	UpdateTime();

	m_listFiducialScale.DeleteAllItems();
	m_strLogDetailArray.RemoveAll();
	
	int i,j;
	
	if( (m_ctStart.GetYear() != m_ctEnd.GetYear() ) && (m_ctStart.GetMonth() != m_ctEnd.GetMonth()))
	{
		for(i = m_ctStart.GetYear() ; i <= m_ctEnd.GetYear(); i++)
		{
			if(i == m_ctStart.GetYear() )
			{
				for(j =  m_ctStart.GetMonth(); j <= 12; j++)
				{
					MakeFileString(i ,j);			
					FillList();
				}
			}
			else if( i == m_ctEnd.GetYear() )
			{
				for(j =  m_ctStart.GetMonth(); j <= m_ctEnd.GetMonth(); j++)
				{
					MakeFileString(i ,j);			
					FillList();
				}
			}
			else
			{
				for(j =  1; j <= 12; j++)
				{
					MakeFileString(i ,j);			
					FillList();
				}
			}
		}
	}
	else if( (m_ctStart.GetMonth() != m_ctEnd.GetMonth() ) )
	{
		for(int i = m_ctStart.GetMonth(); i <= m_ctEnd.GetMonth(); i++)
		{
			MakeFileString(m_ctEnd.GetYear() ,i);		
			FillList();
		}
	}
	else
	{
		MakeFileString(m_ctEnd.GetYear(),m_ctEnd.GetMonth());
		FillList();
	}
}

void CPaneLogManagerFiducialScale::UpdateTime()
{
	if (m_ctStart > m_ctEnd)
	{
		m_ctStart = m_ctEnd;
		UpdateData(FALSE);
	}

	int nStartHour, nEndHour;
	CString strData;
	
	m_edtHourStart.GetWindowText( strData );
	nStartHour = atoi((LPSTR)(LPCTSTR) strData);
	
	m_edtHourEnd.GetWindowText( strData );
	nEndHour = atoi((LPSTR)(LPCTSTR) strData);
	
	int nYear = m_ctStart.GetYear();
	int nMon = m_ctStart.GetMonth();
	int nDay = m_ctStart.GetDay();
	
	m_ctStart = CTime(nYear, nMon, nDay, nStartHour, 0, 0);
	
	nYear = m_ctEnd.GetYear();
	nMon = m_ctEnd.GetMonth();
	nDay = m_ctEnd.GetDay();
	
	if(nEndHour == 24)
		m_ctEnd = CTime(nYear, nMon, nDay, nEndHour-1, 59, 59);
	else
		m_ctEnd = CTime(nYear, nMon, nDay, nEndHour, 0, 0);

}

void CPaneLogManagerFiducialScale::MakeFileString(int nYear, int nMonth)
{
	CString strProcessLog;
	strProcessLog.Format(_T("%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());	
	CString strFiducialScaleFile(strProcessLog);
	strFiducialScaleFile += _T("FiducialScale");
	CString strTime;
	strTime.Format(_T("%02d%02d"),nYear,nMonth);
	//strTime.Format(_T("%04d%02d"),nYear,nMonth);
	m_strFilePath = strFiducialScaleFile + strTime;	
}

void CPaneLogManagerFiducialScale::FillList()
{
	CString strFiducialScaleFile = m_strFilePath;

	FILE *fp;

	if(NULL != fopen_s(&fp, (LPCTSTR) strFiducialScaleFile,_T("r")))
		return ;

	TCHAR szBuf[8192];
	TCHAR *token, seps[] = _T(",\r\n");
	TCHAR *szNext;

	CString strCheckOverScale, strDate, strTime, strManage, strScale, strTemp, strMode, strLotID, strTemp2;
	CString  strScaleX, strScaleY, strScaleR1, strScaleR2, strCompare, strSumData, strSearchLotID, strLengthTolerenceLimit, strLengthTolerenceX, strLengthTolerenceY, strFidBlock;
	strSumData = "";
	int nYear, nMon, nDay, nHour;
	BOOL bLoadNewData = FALSE;
	int	nFidCount = 0;
	BOOL bOnlyOver = m_cmbHead.GetCurSel(); // 0 : all, 1 : over
	BOOL bLotIDSearch = FALSE;
	BOOL bDetailfind;

	CString strDateOld,strTimeOld,strLotIDOld,strModeOld,strCheckOverScaleOld,strScaleXOld,strScaleYOld, strScaleR1Old,strScaleR2Old, strLengthXOld, strLengthYOld, strFidBlockOld;
	
	m_edtLotID.GetWindowText(strTemp);
	if(strTemp.GetLength()  != 0 )
	{
		bLotIDSearch = TRUE;
		strSearchLotID = strTemp;
	}
	int nStart = 0;
	for(nStart = m_listFiducialScale.GetItemCount(); fgets(szBuf, 8192, fp); nStart++)
	{

		if( NULL == (token = strtok_s(szBuf, seps, &szNext)))
		{
			if(feof(fp))
				break;
			else
				continue;
		}

	
		strTemp = token;
		strTemp.TrimLeft(); strTemp.TrimRight();
		if(strTemp.CompareNoCase("Date") == 0 || strTemp.CompareNoCase("Time") == 0 || strTemp.CompareNoCase("Program") == 0 ||
		   strTemp.CompareNoCase("Panel") == 0 || strTemp.CompareNoCase("Judge") == 0 || strTemp.CompareNoCase("Item") == 0 ||strTemp.CompareNoCase("Data") == 0)
		{
			continue;
		}

		strDate = token;
		strDate.TrimLeft();
		strDate.TrimRight();

		// ��, ��, ��  �̱� 
		int nPos = strDate.Find(_T('/'));
		int nLen = strDate.GetLength();
		nYear = atoi(strDate.Left(nPos));
		strTemp = strDate.Right(nLen - nPos - 1);
		nPos = strTemp.Find(_T('/'));
		nLen = strTemp.GetLength();
		nMon = atoi(strTemp.Left(nPos));
		nDay = atoi(strTemp.Right(nLen - nPos - 1));

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
			continue;
		
		strTime = token;
		strTime.TrimLeft();
		strTime.TrimRight();
		
		// �ð� �̱�	
		nPos = strTime.Find(_T(':'));
		nLen = strTime.GetLength();
		nHour = atoi(strTime.Left(nPos));

		CTime cTime(nYear, nMon, nDay, nHour, 1, 1);
		if (cTime < m_ctStart || cTime > m_ctEnd)
			continue;

		//lot id
		if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
			continue;
		strLotID = token;
		strLotID.TrimLeft();
		strLotID.TrimRight();

		if(bLotIDSearch)
		{	
			if(strLotID.CompareNoCase(strSearchLotID) != 0)
				continue;
		}
		
		if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
			continue;
		strMode = token;
		strMode.TrimLeft();
		strMode.TrimRight();

		if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
			continue;
		strCheckOverScale = token;
		strCheckOverScale.TrimLeft();
		strCheckOverScale.TrimRight();

		if(strCheckOverScale.CompareNoCase("OK") == 0 && bOnlyOver)
			continue;
		
		
		if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
			continue;
		strTemp = token;
		strTemp.TrimLeft();
		strTemp.TrimRight();

		bDetailfind = FALSE;
		if(strTemp.CompareNoCase("Scale X") == 0)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
				continue;
			strScaleX = token;
			strScaleX.TrimLeft();
			strScaleX.TrimRight();
//			continue;
		}
		else if(strTemp.CompareNoCase("Scale Y") == 0)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
				continue;
			strScaleY = token;
			strScaleY.TrimLeft();
			strScaleY.TrimRight();
//			continue;
		}
		if(strTemp.CompareNoCase("Scale R1") == 0)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
				continue;
			strScaleR1 = token;
			strScaleR1.TrimLeft();
			strScaleR1.TrimRight();
			//			continue;
		}
		else if(strTemp.CompareNoCase("Scale R2") == 0)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
				continue;
			strScaleR2 = token;
			strScaleR2.TrimLeft();
			strScaleR2.TrimRight();
			//			continue;
		}
		else if(strTemp.CompareNoCase("Tolerence Limit") == 0)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
				continue;
			strLengthTolerenceLimit = token;
			strLengthTolerenceLimit.TrimLeft();
			strLengthTolerenceLimit.TrimRight();
			//			continue;
		}
		else if(strTemp.CompareNoCase("Calculated Tolerance X") == 0)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
				continue;
			strLengthTolerenceX = token;
			strLengthTolerenceX.TrimLeft();
			strLengthTolerenceX.TrimRight();
			//			continue;
		}
		else if(strTemp.CompareNoCase("Calculated Tolerance Y") == 0)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
				continue;
			strLengthTolerenceY = token;
			strLengthTolerenceY.TrimLeft();
			strLengthTolerenceY.TrimRight();
			//			continue;
		}
		else if(strTemp.CompareNoCase("Fiducial Block") == 0)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
				continue;
			strFidBlock = token;
			strFidBlock.TrimLeft();
			strFidBlock.TrimRight();
			//			continue;
		}
		else if(strTemp.CompareNoCase("Avg Scale X") == 0)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
				continue;
			strCompare = token;
			strCompare.TrimLeft();
			strCompare.TrimRight();

			strTemp2.Format(_T("%s : %s\n"), strTemp, strCompare);
			strSumData += strTemp2;
		}
		else if(strTemp.CompareNoCase("Avg Scale Y") == 0)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
				continue;
			strCompare = token;
			strCompare.TrimLeft();
			strCompare.TrimRight();

			strTemp2.Format(_T("%s : %s\n"), strTemp, strCompare);
			strSumData += strTemp2;
		}
		else if(strTemp.CompareNoCase("Plus Limit X") == 0)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
				continue;
			strCompare = token;
			strCompare.TrimLeft();
			strCompare.TrimRight();

			strTemp2.Format(_T("%s : %s\n"), strTemp, strCompare);
			strSumData += strTemp2;
		}
		else if(strTemp.CompareNoCase("Minus Limit X") == 0)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
				continue;
			strCompare = token;
			strCompare.TrimLeft();
			strCompare.TrimRight();

			strTemp2.Format(_T("%s : %s\n"), strTemp, strCompare);
			strSumData += strTemp2;
		}
		else if(strTemp.CompareNoCase("Plus Limit Y") == 0)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
				continue;
			strCompare = token;
			strCompare.TrimLeft();
			strCompare.TrimRight();

			strTemp2.Format(_T("%s : %s\n"), strTemp, strCompare);
			strSumData += strTemp2;

		}
		else if(strTemp.CompareNoCase("Minus Limit Y") == 0)
		{
			if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
				continue;
			strCompare = token;
			strCompare.TrimLeft();
			strCompare.TrimRight();

			strTemp2.Format(_T("%s : %s\n"), strTemp, strCompare);
			strSumData += strTemp2;
		}
		else
		{
			
			for(int i =0; i<4; i++)
			{
				strCompare.Format(_T("Measure %d X"), i+1);
				if(strTemp.CompareNoCase(strCompare) == 0)
				{
					if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
						continue;
					strTemp = token;
					strTemp.TrimLeft();
					strTemp.TrimRight();

					strTemp2.Format(_T("%s : %s\n"), strCompare, strTemp);
					strSumData += strTemp2;
					nFidCount++;
					bDetailfind = TRUE;
					continue;
				}

				strCompare.Format(_T("Measure %d Y"), i+1);
				if(strTemp.CompareNoCase(strCompare) == 0)
				{
					if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
						continue;
					strTemp = token;
					strTemp.TrimLeft();
					strTemp.TrimRight();
					
					strTemp2.Format(_T("%s : %s\n"), strCompare, strTemp);
					strSumData += strTemp2;
					bDetailfind = TRUE;
					continue;
				}

				strCompare.Format(_T("Command %d X"), i+1);
				if(strTemp.CompareNoCase(strCompare) == 0)
				{
					if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
						continue;
					strTemp = token;
					strTemp.TrimLeft();
					strTemp.TrimRight();
					
					strTemp2.Format(_T("%s : %s\n"), strCompare, strTemp);
					strSumData += strTemp2;
					bDetailfind = TRUE;
					continue;
				}
					
				strCompare.Format(_T("Command %d Y"), i+1);
				if(strTemp.CompareNoCase(strCompare) == 0)
				{
					if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
						continue;
					strTemp = token;
					strTemp.TrimLeft();
					strTemp.TrimRight();
					
					strTemp2.Format(_T("%s : %s\n"), strCompare, strTemp);
					strSumData += strTemp2;
					bDetailfind = TRUE;

					if(nFidCount == i+1)
						bLoadNewData = TRUE;

					continue;
				}
			}
		}

		

/*		{
			//��� ���� ����
			strScale.Replace("Fid","F");
			strScale.Replace(" Point ","");
			//strScale.Replace("Offset","O");
			//strScale.Replace("Scale","S");
			strScale.Replace("/","  /  ");
		}
*/		if(bDetailfind)
		{
			strDateOld.Format(_T("%s"), strDate);
			strTimeOld.Format(_T("%s"), strTime);
			strLotIDOld.Format(_T("%s"), strLotID);
			strModeOld.Format(_T("%s"), strMode);
			strCheckOverScaleOld.Format(_T("%s"), strCheckOverScale);
			strScaleXOld.Format(_T("%s"), strScaleX);
			strScaleYOld.Format(_T("%s"), strScaleY);
			strScaleR1Old.Format(_T("%s"), strScaleR1);
			strScaleR2Old.Format(_T("%s"), strScaleR2);
			strLengthXOld.Format(_T("%s"), strLengthTolerenceX);
			strLengthYOld.Format(_T("%s"), strLengthTolerenceY);
			strFidBlockOld.Format(_T("%s"), strFidBlock);
		}
		if(!bDetailfind && nFidCount > 0)
		{	
			CString strFidCount;
			strFidCount.Format(_T("Fiducial Count : %d\n"), nFidCount);

			strSumData = strFidCount+strSumData;
			m_strLogDetailArray.Add(strSumData);
			int nInsert = m_listFiducialScale.InsertItem(nStart,_T(""));
			m_listFiducialScale.SetItemText(nInsert,1,strDateOld);
			m_listFiducialScale.SetItemText(nInsert,2,strTimeOld);
			m_listFiducialScale.SetItemText(nInsert,3,strLotIDOld);
			m_listFiducialScale.SetItemText(nInsert,4,strModeOld);
			m_listFiducialScale.SetItemText(nInsert,5,strCheckOverScaleOld);
			m_listFiducialScale.SetItemText(nInsert,6,strScaleXOld);
			m_listFiducialScale.SetItemText(nInsert,7,strScaleYOld);
			m_listFiducialScale.SetItemText(nInsert,8,strScaleR1Old);
			m_listFiducialScale.SetItemText(nInsert,9,strScaleR2Old);

			m_listFiducialScale.SetItemText(nInsert,10,strLengthXOld);
			m_listFiducialScale.SetItemText(nInsert,11,strLengthYOld);
			m_listFiducialScale.SetItemText(nInsert,12,strFidBlockOld);

			bLoadNewData = FALSE;
			strSumData = "";
			nFidCount = 0;
		}
	}
	if(nFidCount > 0)
	{	
		CString strFidCount;
		strFidCount.Format(_T("Fiducial Count : %d\n"), nFidCount);
		
		strSumData = strFidCount+strSumData;
		m_strLogDetailArray.Add(strSumData);
		int nInsert = m_listFiducialScale.InsertItem(nStart,_T(""));
		m_listFiducialScale.SetItemText(nInsert,1,strDateOld);
		m_listFiducialScale.SetItemText(nInsert,2,strTimeOld);
		m_listFiducialScale.SetItemText(nInsert,3,strLotIDOld);
		m_listFiducialScale.SetItemText(nInsert,4,strModeOld);
		m_listFiducialScale.SetItemText(nInsert,5,strCheckOverScaleOld);
		m_listFiducialScale.SetItemText(nInsert,6,strScaleXOld);
		m_listFiducialScale.SetItemText(nInsert,7,strScaleYOld);
		m_listFiducialScale.SetItemText(nInsert,8,strScaleR1Old);
		m_listFiducialScale.SetItemText(nInsert,9,strScaleR2Old);

		m_listFiducialScale.SetItemText(nInsert,10,strLengthXOld);
		m_listFiducialScale.SetItemText(nInsert,11,strLengthYOld);
		m_listFiducialScale.SetItemText(nInsert,12,strFidBlockOld);

		bLoadNewData = FALSE;
		strSumData = "";
		nFidCount = 0;
	}
	fclose(fp);
}

void CPaneLogManagerFiducialScale::OnClickListLog(NMHDR* pNMHDR, LRESULT* pResult) 
{
	ShowDetailInformation();
	*pResult = 0;
}

void CPaneLogManagerFiducialScale::ShowDetailInformation()
{
	int nSel = m_listFiducialScale.GetSelectionMark();
	if(-1 == nSel)
		return;

	CString strCaption;
	strCaption.Format(_T("Detail Log\n"));
	
	// year
	CString strText1(m_listFiducialScale.GetItemText(nSel, 1));
	strText1 +=" ";
	
	//time
	CString strText2(m_listFiducialScale.GetItemText(nSel, 2));
	strText1 +=strText2;
	//Lot ID
	strText1 += _T("\r\n");
	strText1 += "Lot ID: ";
	CString strText3(m_listFiducialScale.GetItemText(nSel, 3));
	strText1 += strText3;
	strText1 += _T("\r\n");
	//project
	strText1 += _T("\r\n");
	strText1 += "Mode: ";
	CString strText4(m_listFiducialScale.GetItemText(nSel, 4));
	strText1 += strText4;
	strText1 += _T("\r\n");
	//mode
	strText1 += "Status: ";
	CString strText5(m_listFiducialScale.GetItemText(nSel, 5));
	strText1 += strText5;
	strText1 += _T("\r\n");
	//mode
	strText1 += "ScaleX: ";
	CString strText6(m_listFiducialScale.GetItemText(nSel, 6));
	strText1 += strText6;
	strText1 += _T("\r\n");  
	//mode
	strText1 += "ScaleY: ";
	CString strText7(m_listFiducialScale.GetItemText(nSel, 7));
	strText1 += strText7;
	strText1 += _T("\r\n");

	//mode
	strText1 += "Length Diff X: ";
	CString strText8(m_listFiducialScale.GetItemText(nSel, 8));
	strText1 += strText8;
	strText1 += _T("\r\n");
	//mode
	strText1 += "Length Diff Y: ";
	CString strText9(m_listFiducialScale.GetItemText(nSel, 9));
	strText1 += strText9;
	strText1 += _T("\r\n\n");
	//mode
	strText1 += "Fiducial Block: ";
	CString strText10(m_listFiducialScale.GetItemText(nSel, 10));
	strText1 += strText10;
	strText1 += _T("\r\n\n");

	strText1 += "Detail Fiducial Scale Log";
	
	CString strDetail = m_strLogDetailArray.ElementAt(nSel);
	strDetail.Replace("/","\r\n");
	
	if (strDetail.IsEmpty())
		return;
	strDetail += _T("      ");
	strDetail.Insert(0, _T("\r\n\r\n"));
	strDetail.Insert(0, strText1);
	strDetail += _T("      ");
	
	ErrMessage(strCaption + strDetail, MB_ICONINFORMATION);
	
}

void CPaneLogManagerFiducialScale::OnButtonSave()
{
	UpdateData(TRUE);
	
	if (0 == m_listFiducialScale.GetItemCount())
		return;
	
	TCHAR szFilter[] = _T("FiducialScale File(*.txt)|*.txt||");
	CFileDialog filedlg(FALSE, _T("txt"), _T(""), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);
	
	//	filedlg.m_ofn.lpstrInitialDir = _T("C:\\");
	
	if(IDOK == filedlg.DoModal())
	{
		CString strSaveAsProjectFileName = filedlg.GetPathName();
		WriteLogFile(strSaveAsProjectFileName);
	}
	else
		return;	
}

void CPaneLogManagerFiducialScale::WriteLogFile(CString& strSaveFileName)
{
	CStdioFile cFile;
	TCHAR seps[] = _T(":\n");
	const CString strSeps = _T(":\n");
	TCHAR szBuf[2048] ={0,};
	CString strDetail, strTemp, strCompare, strVal, strLine;
	CString strDate, strTime, strStatus, strPanel, strLotID;
	int nMax = m_listFiducialScale.GetItemCount();
	int k=0, nFidCount = 0;

	if (FALSE == cFile.Open(strSaveFileName, CFile::modeCreate | CFile::modeWrite))
	{
		ErrMessage(IDS_CREATE_FILE_ERR, MB_ICONERROR);
		return;
	}
	
	TRY
	{
	
		strLine.Format(_T("  Date , Time , Lot ID , Panel , Status , Scale , Data\n"));
		strDetail += strLine;
		
		for (int i = 0; i < nMax; i++)
		{	
			strDate = m_listFiducialScale.GetItemText(i, 1);
			strTime = m_listFiducialScale.GetItemText(i, 2);
			strLotID = m_listFiducialScale.GetItemText(i, 3);
			strPanel = m_listFiducialScale.GetItemText(i, 4);
			strStatus = m_listFiducialScale.GetItemText(i, 5);

			strLine.Format(_T("%s, %s, %s , %s , %s , %s , %s\n"),
				strDate, strTime, strLotID, strPanel, strStatus,"Scale X", m_listFiducialScale.GetItemText(i, 6));
			strDetail += strLine;
			
			strLine.Format(_T("%s, %s, %s , %s , %s , %s , %s\n"),
				strDate, strTime, strLotID, strPanel, strStatus,"Scale Y", m_listFiducialScale.GetItemText(i, 7));
			strDetail += strLine;

			cFile.WriteString(strDetail);
			strDetail ="";		
			/*strcpy_s(szBuf, (LPCTSTR)m_strLogDetailArray[i]);
			
			if(NULL == (token = strtok_s(szBuf, (LPCTSTR)strSeps)))
				continue;			
		
			strTemp = token;
			strTemp.TrimLeft(); strTemp.TrimRight();
			if(strcmp(strTemp, "Fiducial Count") == 0)
			{
				if(NULL == (token = strtok_s(NULL, (LPCTSTR)strSeps)))
					continue;	
				strTemp.Format(_T("%s"), token);
				nFidCount = atoi(strTemp);
			}

			if(NULL == (token = strtok_s(NULL, (LPCTSTR)strSeps)))
				continue;
			strTemp = token;
			strTemp.TrimLeft(); strTemp.TrimRight();
		

			for(int k =  0; k < nFidCount; k++)
			{
				strCompare.Format(_T("Measure %d X"), k+1);
				if(strcmp(strTemp, (LPCTSTR)strCompare) == 0)
				{
					if (NULL == (token = strtok_s(NULL, (LPCTSTR)strSeps)))	
						continue;
					
					strLine.Format(_T("%s, %s, %s\t, %s\t, %s\t, %s\t, %s\n"), 
						strDate, strTime, strLotID, strPanel, strStatus, strCompare, token);
 					strDetail += strLine;
				
					if (NULL == (token = strtok_s(NULL, (LPCTSTR)strSeps)))	
						continue;
					strTemp.Format(_T("%s"), token);
					strTemp.TrimLeft(); strTemp.TrimRight();
				}
								
				strCompare.Format(_T("Measure %d Y"), k+1);
				if(strcmp(strTemp, (LPCTSTR)strCompare) == 0)
				{
					if (NULL == (token = strtok_s(NULL, (LPCTSTR)strSeps)))	
						continue;

					strLine.Format(_T("%s, %s, %s\t, %s\t, %s\t, %s\t, %s\n"), 
						strDate, strTime, strLotID, strPanel, strStatus, strCompare, token);
					strDetail += strLine;

					if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
						continue;
					strTemp.Format(_T("%s"), token);
					strTemp.TrimLeft(); strTemp.TrimRight();
			
					if(k +1 == nFidCount)
						break;
				}
			
			}
			if(nFidCount != 0)
			{
				cFile.WriteString(strDetail);
				strDetail.Empty();
			}
				
			for(int k =  0; k < nFidCount; k++)
			{
				strCompare.Format(_T("Command %d X"), k+1);
				if(strcmp(strTemp, (LPCTSTR)strCompare) == 0)
				{
					if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
						continue;
					
					strLine.Format(_T("%s, %s, %s\t, %s\t, %s\t, %s\t, %s\n"), 
						strDate, strTime, strLotID, strPanel, strStatus, strCompare, token);
					strDetail += strLine;

					if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
						continue;
					strTemp.Format(_T("%s"), token);
					strTemp.TrimLeft(); strTemp.TrimRight();
				}
			
				strCompare.Format(_T("Command %d Y"), k+1);
				if(strcmp(strTemp, (LPCTSTR)strCompare) == 0)
				{
					if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
						continue;

					strLine.Format(_T("%s, %s, %s\t, %s\t, %s\t, %s\t, %s\n"), 
						strDate, strTime, strLotID, strPanel, strStatus, strCompare, token);
					strDetail += strLine;
				
					if(k +1 == nFidCount)
						break;

					if (NULL == (token = strtok_s(NULL, seps, &szNext)))	
						continue;
					strTemp.Format(_T("%s"), token);
					strTemp.TrimLeft(); strTemp.TrimRight();

				
				}
			}
			
			if(nFidCount != 0)
			{
				cFile.WriteString(strDetail);
				strDetail.Empty();
			}
			*/
		}

		
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
	}
	END_CATCH
		
	cFile.Close();
}

BOOL CPaneLogManagerFiducialScale::CheckHour()
{
	UpdateData(TRUE);

	int nStartHour, nEndHour;
	CString strData;
	
	m_edtHourStart.GetWindowText( strData );
	nStartHour = atoi((LPSTR)(LPCTSTR) strData);
	
	m_edtHourEnd.GetWindowText( strData );
	nEndHour = atoi((LPSTR)(LPCTSTR) strData);


	if( (nStartHour >  nEndHour)  || ( nStartHour > 24 || 0 > nStartHour) || ( nEndHour > 24 || 0 > nEndHour) )
	{	
		ErrMessage(_T("Pleas Change Time Value "));
		return FALSE;
	}

	return TRUE;


}

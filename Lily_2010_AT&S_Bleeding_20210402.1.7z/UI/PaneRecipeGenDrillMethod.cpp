// PaneRecipeGenDrillMethod.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneRecipeGenDrillMethod.h"
#include "DlgMeasuringPCBThickness.h"
#include "..\model\DProject.h"
#include "..\model\dprocessini.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenDrillMethod

IMPLEMENT_DYNCREATE(CPaneRecipeGenDrillMethod, CFormView)

CPaneRecipeGenDrillMethod::CPaneRecipeGenDrillMethod()
	: CFormView(CPaneRecipeGenDrillMethod::IDD)
{
	//{{AFX_DATA_INIT(CPaneRecipeGenDrillMethod)
	m_nUsePanel = USE_DUAL;
	m_nFieldRotation = 0;
	m_nMirro = 0;
	m_nStageMovingDir = 0;
//	m_nScannerMovingDir = 0;
	m_nDrillMethod = 0;
	//}}AFX_DATA_INIT
}

CPaneRecipeGenDrillMethod::~CPaneRecipeGenDrillMethod()
{
}

void CPaneRecipeGenDrillMethod::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneRecipeGenDrillMethod)
	DDX_Control(pDX, IDC_CHECK_TOOL_ORDER, m_chkToolOrder);
	DDX_Control(pDX, IDC_EDIT_PCB_THICKNESS, m_edtPCBThickness);
	DDX_Control(pDX, IDC_BUTTON_MEASURING_THICKNESS, m_btnMeasuringThickness);
	DDX_Radio(pDX, IDC_RADIO_FIELD_ROTATION_NONE, m_nFieldRotation);
	DDX_Radio(pDX, IDC_RADIO_USE_DUAL, m_nUsePanel);
	DDX_Radio(pDX, IDC_RADIO_X_FLIP, m_nMirro);
	DDX_Radio(pDX, IDC_RADIO_STAGE_X_DIR, m_nStageMovingDir);
//	DDX_Radio(pDX, IDC_RADIO_SCANNER_Y_DIR, m_nScannerMovingDir);
	DDX_Radio(pDX, IDC_RADIO_DRILL_METHOD_BURST, m_nDrillMethod);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneRecipeGenDrillMethod, CFormView)
	//{{AFX_MSG_MAP(CPaneRecipeGenDrillMethod)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_MEASURING_THICKNESS, OnButtonMeasuringThickness)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenDrillMethod diagnostics

#ifdef _DEBUG
void CPaneRecipeGenDrillMethod::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneRecipeGenDrillMethod::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenDrillMethod message handlers

void CPaneRecipeGenDrillMethod::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitStaticControl();
	InitEditControl();
}

BOOL CPaneRecipeGenDrillMethod::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneRecipeGenDrillMethod::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Measuring Thickness
	m_btnMeasuringThickness.SetFont( &m_fntBtn );
	m_btnMeasuringThickness.SetFlat( FALSE );
	m_btnMeasuringThickness.EnableBallonToolTip();
	m_btnMeasuringThickness.SetToolTipText( _T("Measuring PCB Thickness") );
	m_btnMeasuringThickness.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnMeasuringThickness.SetBtnCursor(IDC_HAND_1);

	// Drill Method
	GetDlgItem(IDC_RADIO_DRILL_METHOD_BURST)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_DRILL_METHOD_CYCLE)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_RADIO_DRILL_METHOD_STEP)->SetFont( &m_fntBtn );

	// Tool Order
	m_chkToolOrder.SetFont( &m_fntBtn );
	m_chkToolOrder.SetImageOrg( 10, 3 );
	m_chkToolOrder.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkToolOrder.EnableBallonToolTip();
	m_chkToolOrder.SetToolTipText( _T("Tool Order") );
	m_chkToolOrder.SetBtnCursor(IDC_HAND_1);

	m_fntBtn2.CreateFont(20, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDC_RADIO_USE_DUAL)->SetFont(&m_fntBtn2);
	GetDlgItem(IDC_RADIO_USE_1ST)->SetFont(&m_fntBtn2);
	GetDlgItem(IDC_RADIO_USE_2ND)->SetFont(&m_fntBtn2);
}

void CPaneRecipeGenDrillMethod::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// Drill Method
	GetDlgItem(IDC_STATIC_DRILL_METHOD)->SetFont( &m_fntBtn );

	// Use Panel
	GetDlgItem(IDC_STATIC_USE_PANEL)->SetFont( &m_fntBtn );

	// PCB Thickness
	GetDlgItem(IDC_STATIC_PCB_THICKNESS)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_STATIC_THICKNESS)->SetFont( &m_fntBtn );

	// Tool Order
	GetDlgItem(IDC_STATIC_TOOL_ORDER)->SetFont( &m_fntBtn );

	// Gen Preview
	GetDlgItem(IDC_STATIC_GEN_PREVIEW)->SetFont( &m_fntBtn );

	// Field Rotation
	GetDlgItem(IDC_STATIC_FIELD_ROTATION)->SetFont( &m_fntBtn );

	// Mirror
	GetDlgItem(IDC_STATIC_MIRROR)->SetFont( &m_fntBtn );

	// Stage Moving Direciton
	GetDlgItem(IDC_STATIC_STAGE_MOVING_DIR)->SetFont( &m_fntBtn );

	// Scanner Moving Direction
//	GetDlgItem(IDC_STATIC_SCANNER_MOVING_DIR)->SetFont( &m_fntBtn );
}

void CPaneRecipeGenDrillMethod::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	m_edtPCBThickness.SetFont( &m_fntEdit );
	m_edtPCBThickness.SetForeColor( BLACK_COLOR );
	m_edtPCBThickness.SetBackColor( WHITE_COLOR );
	m_edtPCBThickness.SetReceivedFlag( 3 ); // Floating-Point
	m_edtPCBThickness.SetWindowText( _T("0.0") );
}

HBRUSH CPaneRecipeGenDrillMethod::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_DRILL_METHOD)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_PCB_THICKNESS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TOOL_ORDER)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_GEN_PREVIEW)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_FIELD_ROTATION)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MIRROR)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_USE_PANEL)->GetSafeHwnd() == pWnd->m_hWnd)
		GetDlgItem(IDC_STATIC_STAGE_MOVING_DIR)->GetSafeHwnd() == pWnd->m_hWnd ||
//		GetDlgItem(IDC_STATIC_SCANNER_MOVING_DIR)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneRecipeGenDrillMethod::OnButtonMeasuringThickness() 
{
	CDlgMeasuringPCBThickness dlg;

	dlg.SetBaseZ( gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dBaseZ,
		gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dBaseZ);
	dlg.SetPosition( gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dAutoX,
					 gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dAutoY,
					 gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dHeadZ,
					 gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dHeadZ);
	dlg.AutoStart();

	CString strData;
/*	if(dlg.m_nSelectHead == 0)
	{
		double dThickness = dlg.GetHeight();
		strData.Format(_T("%.2f"), dThickness);
		m_edtPCBThickness.SetWindowText( (LPCTSTR)strData );

		if( dThickness <=0. )
		{
			ErrMsgDlg(STDGNALM702);
			return;
		}

		dThickness = dlg.GetHeight(FALSE);
		strData.Format(_T("%.2f"), dThickness);
		m_edtPCBThickness2nd.SetWindowText( (LPCTSTR)strData );
	}
	else if(dlg.m_nSelectHead == 1)
*///	{
		double dThickness = dlg.GetHeight();
		strData.Format(_T("%.2f"), dThickness);
		m_edtPCBThickness.SetWindowText( (LPCTSTR)strData );
//	}
/*	else
	{
		double dThickness = dlg.GetHeight(FALSE);
		strData.Format(_T("%.2f"), dThickness);
		m_edtPCBThickness2.SetWindowText( (LPCTSTR)strData );
	}
*/
	if( dThickness <=0. )
	{
		ErrMsgDlg(STDGNALM702);
		return;
	}
	
}

void CPaneRecipeGenDrillMethod::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntBtn2.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();

	CFormView::OnDestroy();
}

BOOL CPaneRecipeGenDrillMethod::GetData(DProject& tempDProject)
{
	UpdateData(TRUE);
	CString str;
	m_edtPCBThickness.GetWindowText(str);
	if(atof(str) > MAX_PCB_THICK || atof(str) <= MIN_PCB_THICK) // ��ȿ�� ����
	{
		m_edtPCBThickness.SetFocus();
		ErrMessage(_T("PCB Thickness is not normal."));
		return FALSE;
	}
	tempDProject.m_dPcbThick = atof(str);
	tempDProject.m_dPcbThick2 = tempDProject.m_dPcbThick;

//	BOOL bCheck = m_chkToolOrder.GetCheck();
//	if(!bCheck) // ���������� �ƴϸ鼭 aperture�� ����Ѹ� �����ȴ�
//	{
//		ErrMessage(_T("Aperture ������ �Ҷ��� ���������� �� �� �ֽ��ϴ�."));
//		return FALSE;
//	}
//	tempDProject.m_cToolOrder = bCheck;

//	tempDProject.m_bCheckXMir = FALSE;
//	tempDProject.m_bCheckYMir = FALSE;
//	if(m_nMirro == 0)
//		tempDProject.m_bCheckYMir = TRUE;
//	else if(m_nMirro == 1)
//		tempDProject.m_bCheckXMir = TRUE;

//	tempDProject.m_ScanPref = (short)m_nScannerMovingDir;
//	tempDProject.m_AxisPref = (short)m_nStageMovingDir;
//	tempDProject.m_nCheckR90 = (short)m_nFieldRotation;
	return TRUE;
}

BOOL CPaneRecipeGenDrillMethod::SetData()
{
	CString str;
	str.Format(_T("%.3f"), gDProject.m_dPcbThick);
	m_edtPCBThickness.SetWindowText(str);
	
//	m_chkToolOrder.SetCheck((BOOL)gDProject.m_cToolOrder);

//	if(gDProject.m_bCheckXMir)
//	{
//		if(gDProject.m_bCheckYMir)	m_nMirro = 2;
//		else						m_nMirro = 1;
//	}
//	else
//	{
//		if(gDProject.m_bCheckYMir)	m_nMirro = 0;
//		else						m_nMirro = 2;
//	}
	
//	m_nScannerMovingDir	= (int)gDProject.m_ScanPref;
//	m_nStageMovingDir	= (int)gDProject.m_AxisPref;
//	m_nFieldRotation	= (int)gDProject.m_nCheckR90;

	UpdateData(FALSE);
	
	return TRUE;
}

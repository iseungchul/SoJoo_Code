#ifndef __NAnswer
#define __NAnswer
namespace NAnswer
{
	enum enumAnswer { answerYes, answerNo, answerCancel };
};
#endif // __NAnswer
// ui\DlgDispatch.cpp : implementation file
//

#include "stdafx.h"
#include "EasyDriller.h"
#include "ui\DlgDispatch.h"
#include "afxdialogex.h"
#include "..\MODEL\DProject.h"
#include "..\EasyDrillerDlg.h"
#include "..\MODEL\DSystemINI.h"
#include "..\alarmmsg.h"
#include "..\MODEL\DProcessINI.h"

// CDlgDispatch dialog

IMPLEMENT_DYNAMIC(CDlgDispatch, CDialog)

CDlgDispatch::CDlgDispatch(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgDispatch::IDD, pParent)
{
	m_nErrCode = 0;
	m_nSelectPrjIndex = 0;
	m_nDispatchCode = 0;
	memset(m_szLot1, 0, sizeof(m_szLot1));
	memset(m_szLot2, 0, sizeof(m_szLot2));
	memset(m_szResult, 0, sizeof(m_szResult));
	memset(m_szMessage, 0, sizeof(m_szMessage));
}

CDlgDispatch::~CDlgDispatch()
{
}

void CDlgDispatch::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_CODE, m_cmbCode);
	DDX_Control(pDX, IDC_EDIT_1ST_LOT, m_edt1stLot);
	DDX_Control(pDX, IDC_EDIT_CHANGE_INFO, m_edtChangeInfo);
	DDX_Control(pDX, IDC_EDIT_CURRENT_LOT, m_edtCurrentLot);
	DDX_Control(pDX, IDC_EDIT_REASON, m_edtReason);
}


BEGIN_MESSAGE_MAP(CDlgDispatch, CDialog)
	ON_CBN_SELCHANGE(IDC_COMBO_CODE, &CDlgDispatch::OnCbnSelchangeComboCode)
	ON_BN_CLICKED(IDOK, &CDlgDispatch::OnBnClickedOk)
END_MESSAGE_MAP()


// CDlgDispatch message handlers


BOOL CDlgDispatch::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
	InitEditControl();
	InitStaticControl();
	InitCmbControl();

	ChangeDisplay();


	m_dlgOPCWait.Create(IDD_DLG_LASER_MEASUREMENT);
	m_dlgOPCWait.SetUseOnlyOPCWait(TRUE);
	m_dlgOPCWait.ShowWindow(SW_HIDE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
void CDlgDispatch::InitEditControl()
{
	m_fntEdit.CreatePointFont(100, "Arial Bold");
	
	m_edt1stLot.SetFont( &m_fntEdit );
	m_edt1stLot.SetForeColor( RGB(0, 0, 255 ) ); //255, 0, 0 ) );
	m_edt1stLot.SetBackColor( RGB(192, 192, 192 ) ); //WHITE_COLOR );
	m_edt1stLot.SetWindowText( _T("") );
	
	m_edtChangeInfo.SetFont( &m_fntEdit );
	m_edtChangeInfo.SetForeColor( RGB(0, 0, 255 ) ); //255, 0, 0 ) );
	m_edtChangeInfo.SetBackColor( RGB(192, 192, 192 ) ); //WHITE_COLOR );
	m_edtChangeInfo.SetWindowText( _T("") );

	m_edtCurrentLot.SetFont( &m_fntEdit );
	m_edtCurrentLot.SetForeColor( RGB(0, 0, 255 ) ); //255, 0, 0 ) );
	m_edtCurrentLot.SetBackColor( RGB(192, 192, 192 ) ); //WHITE_COLOR );
	m_edtCurrentLot.SetWindowText( _T("") );
	m_edtCurrentLot.EnableWindow(FALSE);

	m_edtReason.SetFont( &m_fntEdit );
	m_edtReason.SetForeColor( RGB(0, 0, 255 ) ); //255, 0, 0 ) );
	m_edtReason.SetBackColor( RGB(192, 192, 192 ) ); //WHITE_COLOR );
	m_edtReason.SetWindowText( _T("") );

}
void CDlgDispatch::InitStaticControl()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");
}
void CDlgDispatch::InitCmbControl()
{
	m_fntCmb.CreatePointFont(100, "Arial Bold");
	m_cmbCode.SetFont( &m_fntCmb);
	m_cmbCode.SetCurSel(-1);
}

void CDlgDispatch::OnCbnSelchangeComboCode()
{
	// TODO: Add your control notification handler code here
	m_nDispatchCode = m_cmbCode.GetCurSel();
}
void CDlgDispatch::ChangeDisplay()
{
	CString strTemp;

	strTemp.Format(_T("%s"), m_szLot1);
	m_edtCurrentLot.SetWindowText(strTemp);

	strTemp.Format(_T("%s"), m_szLot2);
	m_edt1stLot.SetWindowText(strTemp);

	if(!m_nVal1)
	{
		GetDlgItem(IDC_COMBO_CODE)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_REASON)->EnableWindow(FALSE);
	}
	if(!m_nVal2)
	{
		GetDlgItem(IDC_EDIT_CHANGE_INFO)->EnableWindow(FALSE);
	}
}
void CDlgDispatch::GetResult(int& nErrCode, BOOL& bResult, char* szMessage)
{
	nErrCode = m_nErrCode;

	if(strcmp(m_szResult, "PASS") == 0)
		bResult = TRUE;
	else
		bResult = FALSE;
	strcpy(szMessage, m_szMessage);
}
void CDlgDispatch::OnBnClickedOk()
{
	
	CString strOPCTag;
	CString strText1, strText2, strDispatch, strLot1, strLot2, strUserID;

	UpdateData(TRUE);
	strLot1 = m_szLot1;
	strLot2 = m_szLot2;
	
	int nIndex = m_cmbCode.GetCurSel();
	if(nIndex == -1)
	{
		::ErrMessage(_T("Please select Not Following Code"));
		return;
	}

	m_cmbCode.GetLBText(nIndex, strDispatch);

	m_edtReason.GetWindowText(strText1);
	m_edtChangeInfo.GetWindowText(strText2);
	m_edt1stLot.GetWindowText(strLot2);
	strUserID = gDProject.m_strUserID;

	strDispatch = strDispatch.Left(1);

	strOPCTag.Format(_T("%s;%s;%s;%s;%s;%s"), strLot1, strUserID, strLot2, strDispatch, strText1, strText2);
	nIndex = 119;//118 Working Table�� ����PNL ���� : D_000_000002_01   /// ???? 
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
		
	if(!WaitOPCRecvMessage())
	{
		ErrMsgDlg(STDGNALM250);
		return;
	}

	CString strTemp;
	strTemp.Format(_T("%s"), ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDispatchErr, sizeof(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDispatchErr));
	m_nErrCode = atoi(strTemp);

	strcpy(m_szResult,  ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDispatchResult);//, sizeof(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDispatchResult));

	strTemp.Format(_T("%s"), ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_strDispatchMessage);
	strTemp.MakeUpper();
	strcpy(m_szMessage,  strTemp);//, sizeof(strTemp));

	
	CDialog::OnOK();
}
void CDlgDispatch::SetPrjIndex(int nIndex)
{
	m_nSelectPrjIndex = nIndex;
}
void CDlgDispatch::SetLotInfo(char* strLot1, char* strLot2, int nVal1, int nVal2)
{
	memset(m_szLot1, 0, sizeof(m_szLot1));
	memset(m_szLot2, 0, sizeof(m_szLot2));
		
	strcpy(m_szLot1, strLot1);
	strcpy(m_szLot2, strLot2);
	m_nVal1 = nVal1;
	m_nVal2 = nVal2;
}

BOOL CDlgDispatch::PreTranslateMessage(MSG* pMsg)
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_LBUTTONDOWN)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CDialog::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CDialog::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Dlg_Dispatch) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CDlgDispatch::WaitOPCRecvMessage()
{

#ifdef __NO_USE_OPC__
	return TRUE;
#endif
	if( ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc == NULL)
		return TRUE;

	int nWaitTime = gProcessINI.m_sProcessOption.nOPCTimeOut * 100; // sec 

	BOOL bRecv = FALSE;
	int nCount = 0;
	m_dlgOPCWait.ShowWindow(SW_SHOW);
	m_dlgOPCWait.StartMeasurement(nWaitTime);

	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->ResetRecvSignal();
	do
	{
		if(nCount > nWaitTime) //���Ƿ� 5��
		{
			m_dlgOPCWait.ShowWindow(SW_HIDE);
			return FALSE;
		}
		bRecv =  ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_bRecv;
		Sleep(10);
		nCount++;
		MessageLoop();
		m_dlgOPCWait.UpdateMeasurement(nCount);
	}while(!bRecv);
	if(bRecv)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_bRecv = FALSE;
	}
	m_dlgOPCWait.ShowWindow(SW_HIDE);
	return TRUE;
}
void CDlgDispatch::ResetOPCRecvMessage()
{
	 ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->ResetRecvSignal();
}
void CDlgDispatch::MessageLoop()
{
	MSG msg;

	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG )&msg);
	}
}
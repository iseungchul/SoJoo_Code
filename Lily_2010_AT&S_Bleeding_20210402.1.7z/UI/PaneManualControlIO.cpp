// PaneManualControlIO.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlIO.h"

#include "PaneManualControlIOMonitorInputSub2.h"
#include "PaneManualControlIOMonitorNullSub.h"


	#include "PaneManualControlIOMonitorInputSub2.h"

	#include "PaneManualControlIOMonitorInputSub1Pusan1.h"

	#include "PaneManualControlIOMonitorOutputSub1Large.h"
	#include "PaneManualControlIOMonitorOutputSub2Pusan2.h"

#include "..\model\deasydrillerini.h"
#include "..\easydrillerdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIO

IMPLEMENT_DYNCREATE(CPaneManualControlIO, CFormView)

CPaneManualControlIO::CPaneManualControlIO()
	: CFormView(CPaneManualControlIO::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlIO)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_nPaneNo = -1;
	m_pSubInput1 = NULL;
	m_pSubInput2 = NULL;
	m_pSubInput3 = NULL;
	m_pSubInput4 = NULL;
	m_pSubNull = NULL;
	m_pSubOutput1 = NULL;
	m_pSubOutput2 = NULL;
}

CPaneManualControlIO::~CPaneManualControlIO()
{
}

void CPaneManualControlIO::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlIO)
	DDX_Control(pDX, IDC_TAB_MANUAL_CONTROL, m_tabManualControl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlIO, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlIO)
	ON_WM_CTLCOLOR()
	ON_NOTIFY(NM_CLICK, IDC_TAB_MANUAL_CONTROL, OnClickTabManualControl)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIO diagnostics

#ifdef _DEBUG
void CPaneManualControlIO::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlIO::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIO message handlers

void CPaneManualControlIO::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitTabControl();
}

BOOL CPaneManualControlIO::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

HBRUSH CPaneManualControlIO::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneManualControlIO::InitTabControl()
{
	// Set Button Font
	m_fntTab.CreatePointFont(150, "Arial Bold");
	
	BOOL bRet = 0;
	
	m_tabManualControl.SetFont( &m_fntTab );
	
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_PMAC)
	{


		// Input
		bRet = m_tabManualControl.AddPane( _T(" Input1 "), RUNTIME_CLASS(CPaneManualControlIOMonitorInputSub1Pusan1) );
		if( FALSE != bRet )
		{
			m_pSubInput1 = static_cast<CPaneManualControlIOMonitorInputSub1Pusan1*>(m_tabManualControl.GetPane(0));
			m_pSubInput1->OnInitialUpdate();
		}
		
		bRet = m_tabManualControl.AddPane( _T("                  "), RUNTIME_CLASS(CPaneManualControlIOMonitorNullSub) );
		if( FALSE != bRet )
		{
			m_pSubNull = static_cast<CPaneManualControlIOMonitorNullSub*>(m_tabManualControl.GetPane(1));
		}
		
		// Output
		bRet = m_tabManualControl.AddPane( _T(" Output1 "), RUNTIME_CLASS(CPaneManualControlIOMonitorOutputSub1Large) );
		if( FALSE != bRet )
		{
			m_pSubOutput1 = static_cast<CPaneManualControlIOMonitorOutputSub1Large*>(m_tabManualControl.GetPane(2));
			m_pSubOutput1->OnInitialUpdate();
		}



		m_tabManualControl.ShowPane(0);
		m_tabManualControl.SetSkipIndex(4); // �׳� Input�� Ouput�� ���п��̶� ��ɾ���
	}
}

void CPaneManualControlIO::ShowTabPane(int nPaneNo)
{
	if( nPaneNo >= 0 && nPaneNo < 7 && nPaneNo != 4 )
	{
		m_tabManualControl.ShowPane( nPaneNo );
		
		m_nPaneNo = nPaneNo;
	}
}

void CPaneManualControlIO::ChangeSubPane()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;
	
	if(m_nPaneNo == -1)
		m_nPaneNo = 0;

	if(m_nPaneNo == 4)
		return;

	m_tabManualControl.ShowPane(m_nPaneNo);

	switch(m_nPaneNo)
	{

	case 0:
		m_pSubInput1->InitTimer();
		break;
/*	case 1:
		m_pSubInput2->InitTimer();
		break;
	case 2:
		m_pSubInput3->InitTimer();
		break;
	case 3:
		m_pSubInput4->InitTimer();
		break;
*/	case 2:
		m_pSubOutput1->InitTimer();
		break;
	case 3:
		m_pSubOutput2->InitTimer();
		break;

	}
}

void CPaneManualControlIO::KillSubTimer()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;
	
	if(m_nPaneNo == -1)
		return;
	else
	{
		switch(m_nPaneNo)
		{

		case 0:
			m_pSubInput1->DestroyTimer();
			break;
		case 1:
			m_pSubInput2->DestroyTimer();
			break;
/*		case 2:
			m_pSubInput3->DestroyTimer();
			break;
		case 3:
			m_pSubInput4->DestroyTimer();
			break;
*/		case 2:
			m_pSubOutput1->DestroyTimer();
			break;
		case 3:
			m_pSubOutput2->DestroyTimer();
			break;

		}
	}
}

void CPaneManualControlIO::OnClickTabManualControl(NMHDR* pNMHDR, LRESULT* pResult) 
{
	((CEasyDrillerDlg*)::AfxGetMainWnd())->ActiveStaticForKeyboardError();

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		return;
	
	int nSel = m_tabManualControl.GetCurSel();

	if( nSel == m_nPaneNo )
		return;
	
	// 090805 shutter close
	if(m_nPaneNo == 1)
		((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);
	
	switch(m_nPaneNo)
	{

	case 0:
		m_pSubInput1->DestroyTimer();
		break;
/*	case 1:
		m_pSubInput2->DestroyTimer();
		break;
	case 2:
		m_pSubInput3->DestroyTimer();
		break;
	case 3:
		m_pSubInput4->DestroyTimer();
		break;
*/	case 2:
		m_pSubOutput1->DestroyTimer();
		break;
	case 3:
		m_pSubOutput2->DestroyTimer();
		break;

	}

	if(nSel == 1)
		return;
	
	switch( nSel )
	{

	case 0:
		m_pSubInput1->InitTimer();
		break;
/*	case 1:
		m_pSubInput2->InitTimer();
		break;
	case 2:
		m_pSubInput3->InitTimer();
		break;
	case 3:
		m_pSubInput4->InitTimer();
		break;
*/	case 2:
		m_pSubOutput1->InitTimer();
		break;
	case 3:
		m_pSubOutput2->InitTimer();
		break;

	}
	
	m_nPaneNo = nSel;
	
	*pResult = 0;
}

void CPaneManualControlIO::OnDestroy() 
{
	m_fntTab.DeleteObject();
	
	CFormView::OnDestroy();
}
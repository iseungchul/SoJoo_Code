// PaneSysSetupThetaCal.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetupThetaCal.h"
#include "DlgVisionOnly.h"
#include "..\EasyDrillerDlg.h"
#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "DlgMatroxVisionView.h"
#include "..\device\hdevicefactory.h"
#include "..\device\hvision.h"
#include "..\device\hvisionomi.h"
#include "..\model\DEasyDrillerINI.h"
#include <fstream>
#include "..\device\devicemotor.h"
#include "PaneManualControl.h"
#include "PaneManualControlVision.h"
#include <math.h>
#include "..\device\hlaser.h"
#include "..\model\dsystemini.h"
#include "..\alarmmsg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//#define PI 3.1415926535897932384626433832795
#define DBL_MAX         1.7976931348623158e+308 /* max value */

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupThetaCal

IMPLEMENT_DYNCREATE(CPaneSysSetupThetaCal, CFormView)

CPaneSysSetupThetaCal::CPaneSysSetupThetaCal()
	: CFormView(CPaneSysSetupThetaCal::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupThetaCal)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneSysSetupThetaCal::~CPaneSysSetupThetaCal()
{
	
}

void CPaneSysSetupThetaCal::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupThetaCal)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_STATIC_RANGE_MIN, m_stcRangeMin);
	DDX_Control(pDX, IDC_STATIC_RANGE_MAX, m_stcRangeMax);
	DDX_Control(pDX, IDC_EDIT_POS1_X, m_edtPos1X);
	DDX_Control(pDX, IDC_EDIT_POS1_Y, m_edtPos1Y);
	DDX_Control(pDX, IDC_EDIT_POS2_X, m_edtPos2X);
	DDX_Control(pDX, IDC_EDIT_POS2_Y, m_edtPos2Y);
	DDX_Control(pDX, IDC_EDIT_INTERVAL, m_edtInterval);
	DDX_Control(pDX, IDC_EDIT_THETA, m_edtTheta);
	DDX_Control(pDX, IDC_BUTTON_START, m_btnStart);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_btnStop);
	DDX_Control(pDX, IDC_BUTTON_APPLY, m_btnApply);
	DDX_Control(pDX, IDC_BUTTON_PROOF, m_btnProof);
	DDX_Control(pDX, IDC_BUTTON_GETPOS1, m_btnGetPos1);
	DDX_Control(pDX, IDC_BUTTON_GETPOS2, m_btnGetPos2);
	DDX_Control(pDX, IDC_BUTTON_MOVE_THETA, m_btnTheta);
	DDX_Control(pDX, IDC_LIST_RESULT, m_lboxResult);
	DDX_Control(pDX, IDC_COMBO_USE_VISION, m_cmbUseVision);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupThetaCal, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupThetaCal)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_START, OnButtonStart)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_APPLY, OnButtonApply)
	ON_BN_CLICKED(IDC_BUTTON_PROOF, OnButtonProof)
	ON_BN_CLICKED(IDC_BUTTON_GETPOS1, OnButtonGetPos1)
	ON_BN_CLICKED(IDC_BUTTON_GETPOS2, OnButtonGetPos2)
	ON_BN_CLICKED(IDC_BUTTON_MOVE_THETA, OnButtonTheta)
	ON_CBN_SELCHANGE(IDC_COMBO_USE_VISION, OnSelchangeComboUseVision)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupThetaCal diagnostics

#ifdef _DEBUG
void CPaneSysSetupThetaCal::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupThetaCal::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupThetaCal message handlers

void CPaneSysSetupThetaCal::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitBtnControl();
	InitEditControl();
	InitListBoxControl();
	InitComboControl();
	
	m_bStop = FALSE;
	m_bFinish = FALSE;
}

void CPaneSysSetupThetaCal::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130,_T("Arial Bold"));

	// Group
	GetDlgItem(IDC_STATIC_1ST_PANEL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MEASURE_RESULT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS1_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS1_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS2_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS2_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_INTERVAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_THETA)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CAL_RESULT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_1)->SetFont( &m_fntStatic );
	
	// Range
	m_stcRangeMin.SetFont( &m_fntStatic );
	m_stcRangeMin.SetForeColor( RGB(255, 0, 0) );
	m_stcRangeMin.SetBackColor( WHITE_COLOR );
	m_stcRangeMin.SetWindowText( _T("0.0") );

	m_stcRangeMax.SetFont( &m_fntStatic );
	m_stcRangeMax.SetForeColor( RGB(255, 0, 0) );
	m_stcRangeMax.SetBackColor( WHITE_COLOR );
	m_stcRangeMax.SetWindowText( _T("0.0") );
}

void CPaneSysSetupThetaCal::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130,_T("Arial Bold"));

	// GetPosition1
	m_btnGetPos1.SetFont( &m_fntBtn );
	m_btnGetPos1.SetFlat( FALSE );
	m_btnGetPos1.EnableBallonToolTip();
	m_btnGetPos1.SetToolTipText( _T("GetPosition1") );
	m_btnGetPos1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGetPos1.SetBtnCursor(IDC_HAND_1);

	// GetPosition2
	m_btnGetPos2.SetFont( &m_fntBtn );
	m_btnGetPos2.SetFlat( FALSE );
	m_btnGetPos2.EnableBallonToolTip();
	m_btnGetPos2.SetToolTipText( _T("GetPosition2") );
	m_btnGetPos2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGetPos2.SetBtnCursor(IDC_HAND_1);

	// Move Theta
	m_btnTheta.SetFont( &m_fntBtn );
	m_btnTheta.SetFlat( FALSE );
	m_btnTheta.EnableBallonToolTip();
	m_btnTheta.SetToolTipText( _T("Move Theta") );
	m_btnTheta.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTheta.SetBtnCursor(IDC_HAND_1);

	// Start
	m_btnStart.SetFont( &m_fntBtn );
	m_btnStart.SetFlat( FALSE );
	m_btnStart.EnableBallonToolTip();
	m_btnStart.SetToolTipText( _T("Calibration Start") );
	m_btnStart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStart.SetBtnCursor( IDC_HAND_1 );

	// Stop
	m_btnStop.SetFont( &m_fntBtn );
	m_btnStop.SetFlat( FALSE );
	m_btnStop.EnableBallonToolTip();
	m_btnStop.SetToolTipText( _T("Calibration Stop") );
	m_btnStop.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnStop.SetBtnCursor( IDC_HAND_1 );

	// Apply
	m_btnApply.SetFont( &m_fntBtn );
	m_btnApply.SetFlat( FALSE );
	m_btnApply.EnableBallonToolTip();
	m_btnApply.SetToolTipText( _T("Apply") );
	m_btnApply.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApply.SetBtnCursor(IDC_HAND_1);

	// Proof
	m_btnProof.SetFont( &m_fntBtn );
	m_btnProof.SetFlat( FALSE );
	m_btnProof.EnableBallonToolTip();
	m_btnProof.SetToolTipText( _T("Proof") );
	m_btnProof.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnProof.SetBtnCursor(IDC_HAND_1);
}

void CPaneSysSetupThetaCal::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150,_T("Arial Bold"));

	// Pos1
	m_edtPos1X.SetFont( &m_fntEdit );
	m_edtPos1X.SetForeColor( BLACK_COLOR );
	m_edtPos1X.SetBackColor( WHITE_COLOR );
	m_edtPos1X.SetReceivedFlag( 3 );
	m_edtPos1X.SetWindowText( _T("300.0") );

	m_edtPos1Y.SetFont( &m_fntEdit );
	m_edtPos1Y.SetForeColor( BLACK_COLOR );
	m_edtPos1Y.SetBackColor( WHITE_COLOR );
	m_edtPos1Y.SetReceivedFlag( 3 );
	m_edtPos1Y.SetWindowText( _T("300.0") );

	// Pos2
	m_edtPos2X.SetFont( &m_fntEdit );
	m_edtPos2X.SetForeColor( BLACK_COLOR );
	m_edtPos2X.SetBackColor( WHITE_COLOR );
	m_edtPos2X.SetReceivedFlag( 3 );
	m_edtPos2X.SetWindowText( _T("200.0") );
	
	m_edtPos2Y.SetFont( &m_fntEdit );
	m_edtPos2Y.SetForeColor( BLACK_COLOR );
	m_edtPos2Y.SetBackColor( WHITE_COLOR );
	m_edtPos2Y.SetReceivedFlag( 3 );
	m_edtPos2Y.SetWindowText( _T("300.0") );

	// Interval
	m_edtInterval.SetFont( &m_fntEdit );
	m_edtInterval.SetForeColor( BLACK_COLOR );
	m_edtInterval.SetBackColor( WHITE_COLOR );
	m_edtInterval.SetReceivedFlag( 1 );
	m_edtInterval.SetWindowText( _T("5") );

	// Theta
	m_edtTheta.SetFont( &m_fntEdit );
	m_edtTheta.SetForeColor( BLACK_COLOR );
	m_edtTheta.SetBackColor( WHITE_COLOR );
	m_edtTheta.SetReceivedFlag( 3 );
	m_edtTheta.SetWindowText( _T("0.0") );
}

void CPaneSysSetupThetaCal::InitListBoxControl()
{
	// Set ListBox Font
	m_fntListBox.CreatePointFont(130,_T("Arial Bold"));
}

void CPaneSysSetupThetaCal::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(130,_T("Arial Bold"));
	
	m_cmbUseVision.SetFont( &m_fntCombo );
	
	switch( gEasyDrillerINI.m_clsHwOption.GetCameraNum() )
	{
	case 1 :
		m_cmbUseVision.ResetContent();
		m_cmbUseVision.AddString("Vision");
		m_cmbUseVision.EnableWindow(FALSE);
		break;
	case 2 :
		m_cmbUseVision.ResetContent();
		m_cmbUseVision.AddString("High Vision");
		m_cmbUseVision.AddString("Low Vision");
		break;
	}
	
	m_cmbUseVision.SetCurSel( 0 );
}

BOOL CPaneSysSetupThetaCal::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

HBRUSH CPaneSysSetupThetaCal::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_SETTING)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_CAL_RESULT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MEASURE_RESULT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_1ST_PANEL)->GetSafeHwnd() == pWnd->m_hWnd)
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneSysSetupThetaCal::OnDestroy() 
{	
	m_fntStatic.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntListBox.DeleteObject();
	m_fntCombo.DeleteObject();
	
	CFormView::OnDestroy();
}

void CPaneSysSetupThetaCal::ConnectView()
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
//		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->SetPanelNo(THETA_CAL_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_THETA_CAL_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_SHOW );
		

	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetPanelNo(THETA_CAL_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->ShowWindow( SW_SHOW );
		

	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->SetPanelNo(THETA_CAL_VISION_VIEW);
		
		CRect rtPos;
		GetDlgItem(IDC_STATIC_THETA_CAL_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_SHOW );
		

	}
			GetDlgItem(IDC_STATIC_VISION_VIEW)->ShowWindow(SW_HIDE);
					GetDlgItem(IDC_STATIC_THETA_CAL_VIEW)->ShowWindow(SW_HIDE);
	int nCamNo = m_cmbUseVision.GetCurSel();
	OnCamChange( nCamNo );
}

void CPaneSysSetupThetaCal::OnCamChange(int nCamNo)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnCamChange( nCamNo );
}

void CPaneSysSetupThetaCal::OnSelchangeComboUseVision() 
{
	int nCamNo = m_cmbUseVision.GetCurSel();
	HVision* pVision = gDeviceFactory.GetVision();
	
	pVision->OnCamChange( nCamNo );
}

void CPaneSysSetupThetaCal::OnMoveVisionView()
{
	CRect rtPos;
	
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		GetDlgItem(IDC_STATIC_THETA_CAL_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->MoveWindow( &rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		GetDlgItem(IDC_STATIC_THETA_CAL_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->MoveWindow( &rtPos );
	}
}

void CPaneSysSetupThetaCal::SetButtonControl(BOOL bStart, BOOL bStop, BOOL bApply, BOOL bProof)
{
	GetDlgItem(IDC_BUTTON_MOVE_THETA)->EnableWindow(bStart);
	GetDlgItem(IDC_BUTTON_GETPOS1)->EnableWindow(bStart);
	GetDlgItem(IDC_BUTTON_GETPOS2)->EnableWindow(bStart);
	GetDlgItem(IDC_BUTTON_START)->EnableWindow(bStart);
	GetDlgItem(IDC_BUTTON_STOP)->EnableWindow(bStop);
	GetDlgItem(IDC_BUTTON_APPLY)->EnableWindow(bApply);
	GetDlgItem(IDC_BUTTON_PROOF)->EnableWindow(bProof);
	
	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, bStart);
}

void CPaneSysSetupThetaCal::AddList(CString strList)
{
	if(m_lboxResult.GetCount() > 100)
		m_lboxResult.DeleteString(0);
	
	m_lboxResult.AddString(strList);
	m_lboxResult.SetCurSel(m_lboxResult.GetCount()-1);
}

void CPaneSysSetupThetaCal::OnButtonGetPos1()
{
	double dPosX, dPosY;
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY);

	CString strVal;
	strVal.Format(_T("%.3f"), dPosX);
	GetDlgItem(IDC_EDIT_POS1_X)->SetWindowText(strVal);

	strVal.Format(_T("%.3f"), dPosY);
	GetDlgItem(IDC_EDIT_POS1_Y)->SetWindowText(strVal);

	UpdateData(FALSE);
}

void CPaneSysSetupThetaCal::OnButtonGetPos2()
{
	double dPosX, dPosY;
	gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX);
	gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY);
	
	CString strVal;
	strVal.Format(_T("%.3f"), dPosX);
	GetDlgItem(IDC_EDIT_POS2_X)->SetWindowText(strVal);
	
	strVal.Format(_T("%.3f"), dPosY);
	GetDlgItem(IDC_EDIT_POS2_Y)->SetWindowText(strVal);
	
	UpdateData(FALSE);	
}

void CPaneSysSetupThetaCal::OnButtonTheta()
{
	UpdateData();

	double dPosT;
	CString strVal;
	GetDlgItem(IDC_EDIT_THETA)->GetWindowText(strVal);
	dPosT = atof(strVal);

	GetDlgItem(IDC_BUTTON_MOVE_THETA)->EnableWindow(FALSE);

	GetDlgItem(IDC_BUTTON_MOVE_THETA)->EnableWindow(TRUE);
}

void CPaneSysSetupThetaCal::OnButtonStart()
{
	UpdateData();

	CString strVal;
	GetDlgItem(IDC_EDIT_INTERVAL)->GetWindowText(strVal);
	double dInterval = atof(strVal);

	double dVal = (360.0 / dInterval) + 1;
	int nVal = (int)dVal;
	if(dVal != nVal)
	{
		ErrMessage(_T("Please check interval value."));
		return;
	}

	SetButtonControl(FALSE, TRUE, FALSE, FALSE);

	m_bStop = FALSE;
	m_bFinish = FALSE;

	DPOINT dpStartPos[2];
	GetDlgItem(IDC_EDIT_POS1_X)->GetWindowText(strVal);
	dpStartPos[0].x = atof(strVal);

	GetDlgItem(IDC_EDIT_POS1_Y)->GetWindowText(strVal);
	dpStartPos[0].y = atof(strVal);

	GetDlgItem(IDC_EDIT_POS2_X)->GetWindowText(strVal);
	dpStartPos[1].x = atof(strVal);

	GetDlgItem(IDC_EDIT_POS2_Y)->GetWindowText(strVal);
	dpStartPos[1].y = atof(strVal);

	double dStandardDegree, dStandardTheta;
	GetTheta(dpStartPos[0], dpStartPos[1], dStandardDegree, dStandardTheta);

	double* dOffset = NULL;
	TRY
	{
		dOffset = new double[nVal];
	}
	CATCH (CMemoryException, e)
	{
		e->ReportError();
		e->Delete();
		ErrMessage(_T("Can't create Data."));
		SetButtonControl(TRUE, FALSE, TRUE, FALSE);
		return;
	}
	END_CATCH

	AddList("Start measurement.");

	double dPosDegree, dPosTheta;
	double dMoveX, dMoveY;
	double dCenterX = 0., dCenterY = 0.; // theta ȸ���� �߽�
	DPOINT dpPos[2], dpResult;
	double dDegree, dTheta;
	int nCamNo = m_cmbUseVision.GetCurSel();

	double dMax = -DBL_MAX;
	double dMin = DBL_MAX;

	for(int i=0; i<nVal; i++)
	{
		dPosDegree = i * dInterval;
		dPosTheta = dPosDegree * PI / 180.0;
		if(!MoveT(dPosDegree)) // t�� ������
		{
			ErrMessage(_T("Can't move motor."));
			SetButtonControl(TRUE, FALSE, TRUE, FALSE);
			delete [] dOffset;
			return;	
		}
		
		for(int j=0; j<2; j++) // ��ġ 2��
		{
			MessageLoop();
			if(m_bStop)
			{
				ErrMessage(_T("Stop process"));
				SetButtonControl(TRUE, FALSE, TRUE, FALSE);
				delete [] dOffset;
				return;
			}

			RotatePT(&dMoveX, &dMoveY, dpStartPos[j].x, dpStartPos[j].y, dCenterX, dCenterY, dPosTheta);

			if(!MoveTable(dMoveX, dMoveY)) // ����Ʈ�� �̵�
			{
				ErrMessage(_T("Can't move motor."));
				SetButtonControl(TRUE, FALSE, TRUE, FALSE);
				delete [] dOffset;
				return;	
			}

#ifndef __TEST__	
			::Sleep(100);
#endif

			BOOL bResult = FALSE;
			for(int k=0; k<5; k++)
			{
				MessageLoop();
				if(m_bStop)
				{
					ErrMessage(_T("Stop process"));
					SetButtonControl(TRUE, FALSE, TRUE, FALSE);
					delete [] dOffset;
					return;
				}

				::Sleep(10);

				bResult = gDeviceFactory.GetVision()->GetRealPos(&dpResult, nCamNo, 0, FALSE);
				if(bResult)
					break;
			}

			if(!bResult)
			{
				ErrMessage(_T("Fail to find model."));
				SetButtonControl(TRUE, FALSE, TRUE, FALSE);
				delete [] dOffset;
				return;
			}

			dpPos[j].x = dMoveX + dpResult.x;
			dpPos[j].y = dMoveY + dpResult.y;
		}
		
		// 2�� �� ã������ ����
		GetTheta(dpPos[0], dpPos[1], dDegree, dTheta);
		dOffset[i] = dStandardDegree - dDegree;

		strVal.Format(_T("[%.2f] : %.2f"), dPosDegree, dOffset[i]);
		AddList(strVal);

		if(dMin > dOffset[i]) dMin = dOffset[i];
		if(dMax < dOffset[i]) dMax = dOffset[i];
	}

	m_bFinish = TRUE;
	m_bStop = FALSE;

	m_CalData.nCount = nVal;
	m_CalData.dInterval = dInterval;
	m_CalData.dOffset = dOffset;

	strVal.Format(_T("%.3f"), dMin);
	m_stcRangeMin.SetWindowText( strVal );
	strVal.Format(_T("%.3f"), dMax);
	m_stcRangeMax.SetWindowText( strVal );

	AddList("End measuremenet.");

	SetButtonControl(TRUE, FALSE, TRUE, FALSE);
}

void CPaneSysSetupThetaCal::GetTheta(DPOINT dpA, DPOINT dpB, double& dDegree, double& dTheta)
{
	dTheta = atan2( dpB.y - dpA.y, dpB.x - dpA.x ) * -1;
	dDegree = (dTheta*180.0) / double(PI);
}

void CPaneSysSetupThetaCal::RotatePT(  double* nx, double* ny, double tx, double ty, double cx, double cy,  double q )
{
    double cosq = cos( q ), sinq = sin( q );
	
    // ȸ���߽��� C�� ����  O�� ��ġ�ϵ��� ȸ���� �� T�� �Բ� �����̵�
    tx -= cx, ty -= cy;
	
    // ���� O�� ���Ͽ� ȸ���� �� T�� q���� ��ŭ ȸ��
    *nx  =  tx *  cosq - ty * sinq;
    *ny =  ty * cosq + tx * sinq;
	
    // ���� O�� ������ ȸ�� �߽��� C�� ��ġ�ϵ��� ȸ���� �� N�� �Բ� �̵�
    *nx += cx, *ny += cy;
}

void CPaneSysSetupThetaCal::MessageLoop()
{
	MSG msg;
	
	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG)&msg);
	}
}

void CPaneSysSetupThetaCal::OnButtonStop()
{
	m_bStop = TRUE;

	AddList("Stop measurement.");
	
	SetButtonControl(TRUE, FALSE, FALSE, FALSE);
}

void CPaneSysSetupThetaCal::OnButtonApply()
{
	SetButtonControl(FALSE, FALSE, FALSE, FALSE);

	if(!m_bFinish)
	{
		ErrMessage(_T("You don't need to apply."));
		return;
	}

	gDeviceFactory.GetMotor()->UpdateTCalibrationFile(m_CalData);

	m_bFinish = FALSE;

	SetButtonControl(TRUE, FALSE, FALSE, TRUE);
}

void CPaneSysSetupThetaCal::OnButtonProof()
{
	UpdateData();

	CString strVal;
	GetDlgItem(IDC_EDIT_INTERVAL)->GetWindowText(strVal);
	double dInterval = atof(strVal);

	double dVal = (360.0 / dInterval) + 1;
	int nVal = (int)dVal;
	if(dVal != nVal)
	{
		ErrMessage(_T("Please check interval value."));
		return;
	}

	SetButtonControl(FALSE, TRUE, FALSE, FALSE);

	m_bStop = FALSE;
	m_bFinish = FALSE;

	DPOINT dpStartPos[2];
	GetDlgItem(IDC_EDIT_POS1_X)->GetWindowText(strVal);
	dpStartPos[0].x = atof(strVal);

	GetDlgItem(IDC_EDIT_POS1_Y)->GetWindowText(strVal);
	dpStartPos[0].y = atof(strVal);

	GetDlgItem(IDC_EDIT_POS2_X)->GetWindowText(strVal);
	dpStartPos[1].x = atof(strVal);

	GetDlgItem(IDC_EDIT_POS2_Y)->GetWindowText(strVal);
	dpStartPos[1].y = atof(strVal);

//	double dStandardDegree, dStandardTheta;
//	GetTheta(dpStartPos[0], dpStartPos[1], dStandardDegree, dStandardTheta);

	AddList("Start measurement.");

	double dOffset;
	double dPosDegree, dPosTheta;
	double dMoveX, dMoveY;
	double dCenterX = 0., dCenterY = 0.; // theta ȸ���� �߽�
	DPOINT dpPos[2], dpResult;
	double dDegree, dTheta;
	int nCamNo = m_cmbUseVision.GetCurSel();

	double dMax = -DBL_MAX;
	double dMin = DBL_MAX;

	for(int i=0; i<nVal; i++)
	{
		dPosDegree = i * dInterval;
		dPosTheta = dPosDegree * PI / 180.0;
		if(!MoveT(dPosDegree)) // t�� ������
		{
			ErrMessage(_T("Can't move motor."));
			SetButtonControl(TRUE, FALSE, FALSE, TRUE);
			return;	
		}
		
		for(int j=0; j<2; j++) // ��ġ 2��
		{
			MessageLoop();
			if(m_bStop)
			{
				ErrMessage(_T("Stop process"));
				SetButtonControl(TRUE, FALSE, FALSE, TRUE);
				return;
			}

			RotatePT(&dMoveX, &dMoveY, dpStartPos[j].x, dpStartPos[j].y, dCenterX, dCenterY, dPosTheta);

			if(!MoveTable(dMoveX, dMoveY)) // ����Ʈ�� �̵�
			{
				ErrMessage(_T("Can't move motor."));
				SetButtonControl(TRUE, FALSE, FALSE, TRUE);
				return;	
			}

#ifndef __TEST__	
			::Sleep(100);
#endif

			BOOL bResult = FALSE;
			for(int k=0; k<5; k++)
			{
				MessageLoop();
				if(m_bStop)
				{
					ErrMessage(_T("Stop process"));
					SetButtonControl(TRUE, FALSE, FALSE, TRUE);
					return;
				}

				::Sleep(10);

				bResult = gDeviceFactory.GetVision()->GetRealPos(&dpResult, nCamNo, 0, FALSE);
				if(bResult)
					break;
			}

			if(!bResult)
			{
				ErrMessage(_T("Fail to find model."));
				SetButtonControl(TRUE, FALSE, FALSE, TRUE);
				return;
			}

			dpPos[j].x = dMoveX + dpResult.x;
			dpPos[j].y = dMoveY + dpResult.y;
		}
		
		// 2�� �� ã������ ����
		GetTheta(dpPos[0], dpPos[1], dDegree, dTheta);
		dOffset = dDegree;

		strVal.Format(_T("[%.2f] : %.2f"), dPosDegree, dOffset);
		AddList(strVal);

		if(dMin > dOffset) dMin = dOffset;
		if(dMax < dOffset) dMax = dOffset;
	}

	m_bFinish = TRUE;
	m_bStop = FALSE;

	strVal.Format(_T("%.3f"), dMin);
	m_stcRangeMin.SetWindowText( strVal );
	strVal.Format(_T("%.3f"), dMax);
	m_stcRangeMax.SetWindowText( strVal );

	AddList("End measuremenet.");

	SetButtonControl(TRUE, FALSE, FALSE, TRUE);
}

void CPaneSysSetupThetaCal::EnableControl(BOOL bUse)
{
	GetDlgItem(IDC_BUTTON_MOVE_THETA)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_GETPOS1)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_GETPOS2)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_START)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_STOP)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_APPLY)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_PROOF)->EnableWindow(bUse);
}

void CPaneSysSetupThetaCal::SetAuthorityByLevel(int nLevel)
{
	switch(nLevel)
	{
	case 0:
	case 1:
		EnableControl(FALSE);
		break;
	case 2:
	case 3:
		EnableControl(TRUE);
		break;
	}
}

BOOL CPaneSysSetupThetaCal::MoveT(double dPos)
{
	return TRUE;
}

BOOL CPaneSysSetupThetaCal::MoveTable(double dPosX, double dPosY)
{
	if(!gDeviceFactory.GetMotor()->MoveXY(dPosX, dPosY))
	{
		if(!gDeviceFactory.GetMotor()->MoveXY(dPosX, dPosY))
			return FALSE;	
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return FALSE;
	}
	else
	{
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
			return FALSE;
	}
	
	return TRUE;
} 
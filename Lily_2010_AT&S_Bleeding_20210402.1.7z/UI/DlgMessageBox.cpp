// DlgMessageBox.cpp : implementation file
//

#include "stdafx.h"
#include "..\EasyDriller.h"
#include "DlgMessageBox.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// CDlgMessageBox dialog

IMPLEMENT_DYNAMIC(CDlgMessageBox, CDialog)

CDlgMessageBox::CDlgMessageBox(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgMessageBox::IDD, pParent)
{
	m_strErrMessage = _T("");
	m_nRrefreshTimer = 0;
	m_bEasyDrillerDlgStart = FALSE;
}

CDlgMessageBox::~CDlgMessageBox()
{
}

void CDlgMessageBox::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

//	DDX_Text(pDX, IDC_EDIT_MESSAGE, m_strErrMessage);
//	DDX_Control(pDX, IDC_STATIC_ICON, m_stcIcon);
//	DDX_Control(pDX, IDC_EDIT_ERROR_MESSAGE, m_edtErrMessage);
	DDX_Control(pDX, IDOK, m_btnOk);
}


BEGIN_MESSAGE_MAP(CDlgMessageBox, CDialog)
	ON_BN_CLICKED(IDOK, &CDlgMessageBox::OnButtonOk)
	ON_WM_MOUSEWHEEL()
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CDlgMessageBox message handlers



BOOL CDlgMessageBox::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here
	InitBtnControl();
	InitEditControl();
	InitStaticControl();
//	this->GetSystemMenu(NULL)->EnableMenuItem(SC_CLOSE, MF_DISABLED);
	::SetWindowPos(this->m_hWnd, HWND_TOPMOST, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOREDRAW);

//	ResizeWindow();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgMessageBox::InitBtnControl()
{
	// Set Button Font
	CRect rect;
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	m_btnOk.SetFont( &m_fntBtn );
	m_btnOk.SetFlat( FALSE );
//	m_btnOk.SetImageOrg( 8, 3 );
//	m_btnOk.SetIcon( IDI_OK );
	m_btnOk.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOk.EnableBallonToolTip();
	m_btnOk.SetToolTipText( _T("OK") );
	m_btnOk.SetBtnCursor(IDC_HAND_1);
}

void CDlgMessageBox::InitEditControl()
{
	// Set Edit Font
	// Error Code
	m_edtFont.CreateFont(25, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
//	GetDlgItem(IDC_EDIT_MESSAGE)->SetFont(&m_edtFont);
//	m_edtErrMessage.SetBackColor(RGB(255,250,205));//lemonchiffon color

}

void CDlgMessageBox::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	
//	m_stcIcon.Create(_T("zz"), WS_CHILD | WS_VISIBLE | SS_ICON | SS_CENTERIMAGE, CRect(0,0,50, 700), this, 0xffff);

//	CWinApp* pApp = AfxGetApp();

//	if(m_nType & MB_YESNO || m_nType & MB_ICONQUESTION || m_nType & MB_YESNOCANCEL)
//		m_stcIcon.SetIcon(AfxGetApp()->LoadIcon(IDI_QUESTION2));
//	else if (m_nType & MB_ICONSTOP || m_nType & MB_ICONERROR)
//		m_stcIcon.SetIcon(AfxGetApp()->LoadIcon(IDI_STOP2));
//	else
//		m_stcIcon.SetIcon(AfxGetApp()->LoadIcon(IDI_WARNING2));


}

int CDlgMessageBox::SetErrMsg(CString strErrMessage, UINT nType, BOOL bLog)
{
	CString strResult = _T("");
	CString strLog = _T("");
	m_strErrMessage.Format("%s", strErrMessage);
	strLog.Format(_T("(MSG_ON)%s"), m_strErrMessage);
	m_nType = nType;
	
	if( bLog && m_bEasyDrillerDlgStart)
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));

	m_strErrMessage.Replace(_T("\n"),_T("\r\n"));
	
	DoModal();
	if(m_nResult == IDOK)
		strResult.Format(_T("%s_OK"),strErrMessage);
	else if(m_nResult == IDNO)
		strResult.Format(_T("%s_NO"),strErrMessage);
	else if(m_nResult == IDYES)
		strResult.Format(_T("%s_YES"),strErrMessage);
	else
		strResult.Format(_T("%s_CANCEL"),strErrMessage);

	strResult.Replace(_T("\r\n"),_T(" "));
	
	strLog.Format("(MSG_OFF)%s", strResult);
	if( bLog && m_bEasyDrillerDlgStart )
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));
	
	return m_nResult;
}

BOOL CDlgMessageBox::DestroyWindow()
{
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	
	return CDialog::DestroyWindow();
}


void CDlgMessageBox::OnButtonOk()
{
	// TODO: Add your control notification handler code here
	m_nResult = IDOK;
	EndDialog(m_nResult);
}


BOOL CDlgMessageBox::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	// TODO: Add your message handler code here and/or call default
	return CDialog::OnMouseWheel(nFlags, zDelta, pt);
}


HBRUSH CDlgMessageBox::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	// TODO: Change any attributes of the DC here
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CDlgMessageBox::ResizeWindow()
{
	CRect rect, rectBtn;
	this->GetWindowRect(&rect);
	
	char* pToken;
	CString strToken = _T("");
	int nMaxLength = -1;
	int nCount = 0;
	pToken = strtok((LPSTR)(LPCTSTR)m_strErrMessage, _T("\r\n"));
	while(pToken != NULL)
	{
		strToken = pToken;
		if(nMaxLength < strToken.GetLength())
			nMaxLength = strToken.GetLength();
		pToken = strtok(NULL, _T("\r\n"));
		nCount++;
	}

	this->MoveWindow(rect.left, rect.top,15 * nMaxLength + 10, 150 + nCount*25);
//	GetDlgItem(IDC_EDIT_MESSAGE)->GetClientRect(&rectBtn);
//	GetDlgItem(IDC_EDIT_MESSAGE)->MoveWindow(rectBtn.left, rectBtn.top, 15 * nMaxLength, nCount*25 + 20);

	this->GetClientRect(&rect);
	if ((m_nType & MB_YESNO) == MB_YESNO)
	{
		m_btnOk.ShowWindow(SW_HIDE);
	}
	else if ((m_nType & MB_YESNOCANCEL) == MB_YESNOCANCEL)
	{
		m_btnOk.ShowWindow(SW_HIDE);
	}
	else if(( m_nType & MB_OKCANCEL) == MB_OKCANCEL)
	{
		m_btnOk.ShowWindow(SW_SHOW);
		m_btnOk.MoveWindow(rect.Width()/2 - rectBtn.Width(), rect.bottom - 80, rectBtn.Width(), rectBtn.Height(),TRUE);

	}
	else
	{
		m_btnOk.ShowWindow(SW_SHOW);
		m_btnOk.GetClientRect(&rectBtn);
		m_btnOk.MoveWindow(rect.Width()/2 - rectBtn.Width()/2, rect.bottom - 80, rectBtn.Width(), rectBtn.Height(),TRUE);

	}
}

BOOL CDlgMessageBox::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN)
	{
		switch (pMsg->wParam)
		{
		case VK_ESCAPE:
			return TRUE;

		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}
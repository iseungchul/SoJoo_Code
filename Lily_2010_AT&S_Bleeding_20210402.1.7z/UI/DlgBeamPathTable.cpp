// DlgBeamPathTable.cpp: implementation of the CDlgBeamPathTable class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgBeamPathTable.h"
#include "..\model\DBeampathINI.h"
#include "..\EasyDrillerDlg.h"
#include "PaneAutoRun.h"
#include "GridCtrl_src\GridCtrl.h"
#include "model\DSystemINI.h"
#include "..\MODEL\DEasyDrillerINI.h"
#include "DlgShotTable.h"
#include "NewCellTypes/GridCellCombo.h"
#include "NewCellTypes/GridCellCheck.h"
#include "..\model\GlobalVariable.h"
#include "..\Alarmmsg.h"


#define		USETOPHAT_POSITION	 1 
#define		POLARITY_POSITION	 2
#define		VISION_POSION		 6 
#define		COLOR_BEAMPATH		RGB(255, 255, 162)
#define		COLOR_POWEROFFSET	RGB(243, 255, 72)
#define		COLOR_COMPENSATION	RGB(207, 255, 36)
#define		COLOR_SCANNERFACTS	RGB(255, 202, 108)
#define		COLOR_HOLEFACTS		RGB(180, 255, 255)
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CDlgBeamPathTable, CDialog)




CDlgBeamPathTable::CDlgBeamPathTable(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgBeamPathTable::IDD)
{
	//{{AFX_DATA_INIT(CDlgBeamPathTable)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	//memset( &m_sSystemCollimator, 0, sizeof(m_sSystemCollimator) );

	m_bInfoCheck = FALSE;
	m_bBeamPathCheck = FALSE;
	m_bPowerOffsetCheck = FALSE;
	m_bpowerCompensationCheck = FALSE;
	m_bScannerFactCheck = FALSE;
	m_nUserLevel = 0;
	m_bCheckBox[0] =TRUE;
	for(int i = 1;i < 6; i++)
	{
		m_bCheckBox[i] = FALSE;
	}

	m_bClickList = FALSE;		// ����Ʈ�� Ŭ�������� �� 
	m_ClickID = FALSE;			// ����Ʈ�� �ε����� Ŭ�������� �� 
	m_IdNoToAddDel = 0;	

	strTable0[0] = "No";
	strTable0[1] = "Name";
	strTable0[2] = "MSize";
	

	strTable1[0] = "B1";
	strTable1[1] = "B2";
	strTable1[2] = "B1";
	strTable1[3] = "B2";
	strTable1[4] = "M1";
	strTable1[5] = "M2";
	strTable1[6] = "Z1";
	strTable1[7] = "Z2";
	strTable1[8] = "Asc File";


	strTable2[0] = "Duty";

	strTable3[0] = "Shot Set";
	strTable3[1] = "Frequency";
	strTable3[2] = "Duty";
	strTable3[3] = "Target Min";
	strTable3[4] = "Target Max";
	strTable3[5] = "Duty Offset";
	strTable3[6] = "Target Value";
	strTable3[7] = "Target Percent";
	
	strTable4[0] = "Duty";

	strTable4[1] = "Frquency";


	strTable4[2] = "Shot";
	strTable4[3] = "Vision";
	strTable4[4] = "Size";
	strTable4[5] = "Tol.";
	strTable4[6] = "Ratio";
	strTable4[7] = "Polarity";
	strTable4[8] = "Contrast";
	strTable4[9] = "Brightness";

	strTable4[10] = "High_M Ring";
	strTable4[11] = "High_M Coaxial";
	strTable4[12] = "High_M IR";
	strTable4[13] = "High_S Ring";
	strTable4[14] = "High_S Coaxial";
	strTable4[15] = "High_S IR";

	strTable4[16] = "Low_M Ring";
	strTable4[17] = "Low_M Coaxial";
	strTable4[18] = "Low_M IR";
	strTable4[19] = "Low_S Ring";
	strTable4[20] = "Low_S Coaxial";
	strTable4[21] = "Low_S IR";



	strTable5[0] = "Vision";
	strTable5[1] = "Size";
	strTable5[2] = "Tol";
	strTable5[3] = "Ratio";
	strTable5[4] = "Polarity";
	strTable5[5] = "Contrast";
	strTable5[6] = "Brightness";
	strTable5[7] = "Ring";
	strTable5[8] = "Coaxial";
	strTable5[9] = "IR";

	m_bDeleteAndSaveClick = FALSE;
}

CDlgBeamPathTable::~CDlgBeamPathTable()
{

}

void CDlgBeamPathTable::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgBeamPathTable)
	DDX_Control(pDX, IDC_CHECK_BEAMPATH, m_ChkSubBox[1]);
	DDX_Control(pDX, IDC_CHECK_POWER_OFFSET, m_ChkSubBox[2]);
	DDX_Control(pDX, IDC_CHECK_COMPENSATIO, m_ChkSubBox[3]);
	DDX_Control(pDX, IDC_CHECK_SCANNER_FACT, m_ChkSubBox[4]);
	DDX_Control(pDX, IDC_CHECK_HOLE_FACT, m_ChkSubBox[5]);
	DDX_Control(pDX, IDC_BUTTON_REFRESH, m_btnRefresh);
	DDX_Control(pDX, IDC_EDIT_BEAMPATH_FIXED_MASK_POS, m_edtFixMask);
	DDX_Control(pDX, IDC_LIST_INFO, m_list);
	DDX_Control(pDX, IDC_BUTTON_ADD, m_btnAdd);
	DDX_Control(pDX, IDC_BUTTON_DEL, m_btnDel);
	DDX_Control(pDX, IDC_BUTTON_UP, m_btnUp);
	DDX_Control(pDX, IDC_BUTTON_DOWN, m_btnDown);
	DDX_Control(pDX, IDC_BUTTON_SHOT_EDIT, m_btnShotEdit);

	//if( 0 == gSystemINI.m_sHardWare.nLanguageType ) // English Version
	{
		DDX_GridControl(pDX, IDC_GRID, m_Grid);
	}



	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgBeamPathTable, CDialog)
	//{{AFX_MSG_MAP(CDlgBeamPathTable)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHECK_BEAMPATH, OnCheckBeamPath)
	ON_BN_CLICKED(IDC_CHECK_POWER_OFFSET, OnCheckPowerOffset)
	ON_BN_CLICKED(IDC_CHECK_COMPENSATIO, OnCheckPowerCompensation)
	ON_BN_CLICKED(IDC_CHECK_SCANNER_FACT,OnCheckScannerFact)
	ON_BN_CLICKED(IDC_CHECK_HOLE_FACT,OnCheckHoleFact)
	ON_BN_CLICKED(IDC_BUTTON_REFRESH,OnCheckRefresh)
	ON_NOTIFY(NM_CLICK, IDC_LIST_INFO, OnClickList)
	ON_BN_CLICKED(IDC_BUTTON_ADD,OnCheckAdd)
	ON_BN_CLICKED(IDC_BUTTON_DEL,OnCheckDel)
	ON_BN_CLICKED(IDC_BUTTON_UP,OnCheckUp)
	ON_BN_CLICKED(IDC_BUTTON_DOWN,OnCheckDown)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_LIST_INFO, OnNMCustomdrawListTest)
	ON_BN_CLICKED(IDC_BUTTON_SHOT_EDIT, OnBnClickedButtonShotEdit)

	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BTN_SAVE, &CDlgBeamPathTable::OnBnClickedBtnSave)
	ON_BN_CLICKED(IDC_BTN_CANCEL, &CDlgBeamPathTable::OnBnClickedBtnCancel)
END_MESSAGE_MAP()



/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupBeamPath message handlers

BOOL CDlgBeamPathTable::OnInitDialog() 
{
	CDialog::OnInitDialog();

	InitBtnControl();
	InitStaticControl();
	InitEditControl();
	InitGrid();

OnCheckRefresh();
	// TODO: Add your specialized code here and/or call the base class
	return 1;
}



void CDlgBeamPathTable::InitGrid()
{
	//if( 1 == gSystemINI.m_sHardWare.nLanguageType ) // Chinese Version
	//{
	//	CRect rt;
	//	GetDlgItem(IDC_LIST_INFO)->GetWindowRect(rt);// GetWindowRect(rt);
	//	ScreenToClient(rt);
	//	m_Grid.Create(rt,this,0xffffff);
	//}
	m_Grid.SetEditable(TRUE);
    m_Grid.SetListMode(FALSE);
    m_Grid.EnableDragAndDrop(FALSE);
    m_Grid.SetTextBkColor(RGB(0xFF, 0xFF, 0xE0));
	m_Grid.SetHeaderSort(FALSE);
	m_Grid.SetSingleRowSelection(FALSE);
	
	
    m_Grid.SetFixedRowCount(1);        //1���� ��
    m_Grid.SetFixedColumnCount(1);    //1���� ��
	m_Grid.SetRowResize(FALSE);		  //ũ�� ����
	m_Grid.SetColumnResize(FALSE);	  //ũ�� ����
}
void CDlgBeamPathTable::InitBtnControl()
{
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	
	m_ChkSubBox[1].SetFont( &m_fntBtn );
	m_ChkSubBox[1].SetImageOrg( 10, 3 );
	m_ChkSubBox[1].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[1].EnableBallonToolTip();
	m_ChkSubBox[1].SetToolTipText( _T("Beam Path") );
	m_ChkSubBox[1].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[1].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_BEAMPATH );
	
	m_ChkSubBox[2].SetFont( &m_fntBtn );
	m_ChkSubBox[2].SetImageOrg( 10, 3 );
	m_ChkSubBox[2].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[2].EnableBallonToolTip();
	m_ChkSubBox[2].SetToolTipText( _T("Power Offset") );
	m_ChkSubBox[2].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[2].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_POWEROFFSET );
	
	m_ChkSubBox[3].SetFont( &m_fntBtn );
	m_ChkSubBox[3].SetImageOrg( 10, 3 );
	m_ChkSubBox[3].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[3].EnableBallonToolTip();
	m_ChkSubBox[3].SetToolTipText( _T("Power Compensation") );
	m_ChkSubBox[3].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[3].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_COMPENSATION );
	
	m_ChkSubBox[4].SetFont( &m_fntBtn );
	m_ChkSubBox[4].SetImageOrg( 10, 3 );
	m_ChkSubBox[4].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[4].EnableBallonToolTip();
	m_ChkSubBox[4].SetToolTipText( _T("Scanner Facts") );
	m_ChkSubBox[4].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[4].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_SCANNERFACTS );

	m_ChkSubBox[5].SetFont( &m_fntBtn );
	m_ChkSubBox[5].SetImageOrg( 10, 3 );
	m_ChkSubBox[5].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[5].EnableBallonToolTip();
	m_ChkSubBox[5].SetToolTipText( _T("Hole Facts") );
	m_ChkSubBox[5].SetBtnCursor(IDC_HAND_1);
	m_ChkSubBox[5].SetColor( UEasyButtonEx::COLOR_BG_IN, COLOR_HOLEFACTS );

	m_btnRefresh.SetFont( &m_fntBtn );
	m_btnRefresh.SetFlat( FALSE );
	m_btnRefresh.EnableBallonToolTip();
	m_btnRefresh.SetToolTipText( _T("Refresh") );
	m_btnRefresh.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRefresh.SetBtnCursor(IDC_HAND_1);


	m_btnAdd.SetFont( &m_fntBtn );
	m_btnAdd.SetFlat( FALSE );
	m_btnAdd.EnableBallonToolTip();
	m_btnAdd.SetToolTipText( _T("Refresh") );
	m_btnAdd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAdd.SetBtnCursor(IDC_HAND_1);

	m_btnDel.SetFont( &m_fntBtn );
	m_btnDel.SetFlat( FALSE );
	m_btnDel.EnableBallonToolTip();
	m_btnDel.SetToolTipText( _T("Refresh") );
	m_btnDel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDel.SetBtnCursor(IDC_HAND_1);

	m_btnUp.SetFont( &m_fntBtn );
	m_btnUp.SetFlat( FALSE );
	m_btnUp.EnableBallonToolTip();
	m_btnUp.SetToolTipText( _T("Refresh") );
	m_btnUp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUp.SetBtnCursor(IDC_HAND_1);

	m_btnDown.SetFont( &m_fntBtn );
	m_btnDown.SetFlat( FALSE );
	m_btnDown.EnableBallonToolTip();
	m_btnDown.SetToolTipText( _T("Refresh") );
	m_btnDown.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDown.SetBtnCursor(IDC_HAND_1);

	m_btnShotEdit.SetFont( &m_fntBtn );
	m_btnShotEdit.SetFlat( FALSE );
	m_btnShotEdit.EnableBallonToolTip();
	m_btnShotEdit.SetToolTipText( _T("Edit Shot Parameter") );
	m_btnShotEdit.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShotEdit.SetBtnCursor(IDC_HAND_1);


	GetDlgItem(IDC_BTN_SAVE)->SetFont( &m_fntBtn );
	GetDlgItem(IDC_BTN_CANCEL)->SetFont( &m_fntBtn );

}
void CDlgBeamPathTable::InitStaticControl()
{

}
void CDlgBeamPathTable::InitEditControl()
{
	m_editwnd.Create(WS_CHILD|ES_NOHIDESEL|ES_AUTOHSCROLL|WS_VISIBLE, CRect(0,0,0,0), this, IDC_EDIT_BOX);
	m_editwnd.SetFont(GetFont(), FALSE);
	m_editwnd.SetMargins(4,4);
	SetWindowLong(m_editwnd.m_hWnd, GWL_EXSTYLE, WS_EX_CLIENTEDGE);

	m_edtFixMask.SetFont( &m_fntEdit );
	m_edtFixMask.SetReceivedFlag( 1 );
	m_edtFixMask.SetWindowText( _T("0") );
}

void CDlgBeamPathTable::OnCheckBeamPath()
{
	if(m_bCheckBox[1])
		GetCurrentASC();
	m_bCheckBox[1] = !m_bCheckBox[1];
	OnCheckRefresh();
}

void CDlgBeamPathTable::OnCheckPowerOffset()
{
	m_bCheckBox[2] = !m_bCheckBox[2];
	if(m_bCheckBox[1])
		GetCurrentASC();
	OnCheckRefresh();
}

void CDlgBeamPathTable::OnCheckPowerCompensation()
{
	m_bCheckBox[3] = !m_bCheckBox[3];
	if(m_bCheckBox[1])
		GetCurrentASC();
	OnCheckRefresh();
}

void CDlgBeamPathTable::OnCheckScannerFact()
{
	m_bCheckBox[4] = !m_bCheckBox[4];
	if(m_bCheckBox[1])
		GetCurrentASC();
	OnCheckRefresh();
}

void CDlgBeamPathTable::OnCheckHoleFact()
{
	m_bCheckBox[5] = !m_bCheckBox[5];
	if(m_bCheckBox[1])
		GetCurrentASC();
	OnCheckRefresh();
}

void CDlgBeamPathTable::OnCheckRefresh()
{
	m_editwnd.ShowWindow(SW_HIDE);

	DeleteList();
	int nlistcount = GetListIndex();
	SetDrawMember(nlistcount);
	Invalidate(FALSE);
}


void CDlgBeamPathTable::InitListControl() 
{
	for(int i = 1; i< 5; i++)
	{
		if( TRUE == m_bCheckBox[i])
			m_ChkSubBox[i].SetCheck(1);
		else
			m_ChkSubBox[i].SetCheck(0);
	}

	// ����Ʈ ��Ʈ�ѳ� �ѱ� �߰� ��ƾ 
	CFont m_Font;
	m_Font.CreateFont(12, 0,      // Height, Width
		0, 0,      // Escapement, Orientation
		FW_NORMAL, FALSE,              // Weight, Italic
		FALSE, FALSE,                // Underline, StrikeOut
		HANGEUL_CHARSET,                // Character Set
		OUT_DEFAULT_PRECIS,   // OutPrecision
		CLIP_DEFAULT_PRECIS,   // ClipPrecision
		DEFAULT_QUALITY,             // Quality
		DEFAULT_PITCH,               // PitchAndFamily
		"SYSTEM");  
	
	m_list.SetFont(&m_Font);
	m_Font.DeleteObject();

	m_list.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_FULLROWSELECT|LVS_EX_INFOTIP|LVS_EX_CHECKBOXES);

	// ����Ʈ ��Ʈ�ѿ� �޺� �ڽ��� �־��µ� ù��° ���� �޺� �ڽ��� �׷��� ������ ������ ����Ʈ�� �ٿ� �ȵǾ���. �׷��� �ణ�� ������ ���� �÷� �ذ� �� ;;;(�ؿ� ���� )
	CImageList image;
	image.Create(1, 23, ILC_COLORDDB, 1, 0); //���� ������ �ι�° �Ķ���� ���� ����
	m_list.SetImageList(&image, LVSIL_SMALL); 
	
	DeleteList();
	int nlistcount = GetListIndex();
	SetDrawMember(nlistcount);
	Invalidate();

	CString strData;
	strData.Format(_T("%d"), gVariable.m_sgBeamPath.nFixedMask);
	m_edtFixMask.SetWindowText( (LPCTSTR)strData );
}

int CDlgBeamPathTable::GetListIndex()		//1: 1���̺� ���, 2: 2���̺� ���, 4: 3�� ���̺� ��� , 8 :4�� ���̺� ���, 16: 5�� ���̺� ��� 
{
	int nCount = 0;

	if(m_bCheckBox[0])
		nCount+=1;
	if(m_bCheckBox[1])
		nCount+=2;
	if(m_bCheckBox[2])
		nCount+=4;
	if(m_bCheckBox[3])
		nCount+=8;
	if(m_bCheckBox[4])
		nCount+=16;
	if(m_bCheckBox[5])
		nCount+=32;
	return nCount;
	
}

int CDlgBeamPathTable::GetListRowIndexCount()
{
	int nRowCount = 0;

	if(m_bCheckBox[0])
		nRowCount += TABLE0_COLUMN_COUNT;
	if(m_bCheckBox[1])
		nRowCount += TABLE1_COLUMN_COUNT;
	if(m_bCheckBox[2])
		nRowCount += TABLE2_COLUMN_COUNT;
	if(m_bCheckBox[3])
		nRowCount += TABLE3_COLUMN_COUNT;
	if(m_bCheckBox[4])
		nRowCount += TABLE4_COLUMN_COUNT;

	return nRowCount;
}

void CDlgBeamPathTable::InsertGridValue(GV_ITEM Gvitem, int startNo, int TableNo, int ColCount)
{
	int ColumnNo = startNo;
	CString strData;	

	if(TableNo == TABLE0)
	{
		Gvitem.row = ColCount + 1;
	
		strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		
		strData.Format(_T("%s"), gVariable.m_sgBeamPath.strInfoName[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dInfoMaskSize[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;	
	}

	if(TableNo == TABLE1)
	{
		Gvitem.row = ColCount + 1;

		strData.Format(_T("%.2f"),  gVariable.m_sgBeamPath.dBeamPathBetPos1[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;
		

		strData.Format(_T("%.2f"),  gVariable.m_sgBeamPath.dBeamPathBetPos2[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		strData.Format(_T("%.2f"),  gVariable.m_sgBeamPath.dBeamPathBetPos3[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;

		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		strData.Format(_T("%.2f"),  gVariable.m_sgBeamPath.dBeamPathBetPos4[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;

		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nBeamPathMaskPos1[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nBeamPathMaskPos2[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		strData.Format(_T("%.3f"),  gVariable.m_sgBeamPath.dBeamPathZAxisPos1[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		strData.Format(_T("%.3f"),  gVariable.m_sgBeamPath.dBeamPathZAxisPos2[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

		strData.Format(_T("%s"),  gVariable.m_sgBeamPath.strBeamPathAscFile[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_BEAMPATH);
		ColumnNo++;

	}

	if(TableNo == TABLE2)
	{
		Gvitem.row = ColCount + 1;

		strData.Format(_T("%.2f"),  gVariable.m_sgBeamPath.dPowOffsetDuty[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_POWEROFFSET);
		ColumnNo++;
			
	}

	if(TableNo == TABLE3)
	{
		Gvitem.row = ColCount + 1;

		DWORD dwTextStyle = DT_LEFT|DT_VCENTER|DT_SINGLELINE; 

		int nSel = 0;
		nSel = gVariable.m_sgBeamPath.nSelectShot[ColCount];

		strData.Format(_T("[%d] %s"),nSel, gShotTableINI.m_sShotGroupTable.strInfoName[nSel]);

		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));
		CStringArray options;

		for(int a = 0; a <= gShotTableINI.m_sShotGroupTable.nGroupLastIndex; a++)
		{
			strData.Format(_T("[%d] %s"),a, gShotTableINI.m_sShotGroupTable.strInfoName[a]);
			options.Add(_T(strData));
		}


		CGridCellCombo *pCell = (CGridCellCombo*) m_Grid.GetCell(Gvitem.row, Gvitem.col);
		pCell->SetOptions(options);
		pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE
		Gvitem = Gvitem;//20160624
		Gvitem.nFormat = dwTextStyle;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;


		strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nPowCompensationFrequency[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_COMPENSATION);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowCompensationDuty[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_COMPENSATION);
		ColumnNo++;
	
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowCompensationTargetMin[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_COMPENSATION);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowCompensationTargetMax[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_COMPENSATION);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowCompensationDutyOffset[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_COMPENSATION);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowCompensationTarget[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_COMPENSATION);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowCompensationTargetPercent[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_COMPENSATION);
		ColumnNo++;
	}
	
	if(TableNo == TABLE4)
	{
		Gvitem.row = ColCount + 1;

		strData.Format(_T("%.2f"),  gVariable.m_sgBeamPath.dScannerDuty[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;
			
		strData.Format(_T("%d"),  (int)gVariable.m_sgBeamPath.dScannerFrq[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;



		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerTotalShot[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;

		int nVisionNo = gVariable.m_sgBeamPath.nScannerVisionCam[ColCount];
		if(nVisionNo ==0)
		{
			strData.Format(_T("%s"), "High");
		}
		else if( nVisionNo == 1 )
		{
			strData.Format(_T("%s"), "Low");
		}

		else
		{
			strData.Format(_T("%s"), "error");
		}
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));// Gvitem.iCombo = GV_COMBO;

		CStringArray options;
		options.Add(_T("High"));
		options.Add(_T("Low"));

		CGridCellCombo *pCell = (CGridCellCombo*) m_Grid.GetCell(Gvitem.row, Gvitem.col);
		pCell->SetOptions(options);
		pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE


		//Gvitem.iComboType = GVC_VISION;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dScannerVisionModelSize[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;


		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dScannerAcceptScoreSize[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;

		int nPolarity = gVariable.m_sgBeamPath.nScannerPolarity[ColCount];
		if( nPolarity ==0 )
		{
			strData.Format(_T("%s"), "Black");
		}
		else if( nPolarity == 1)
		{
			strData.Format(_T("%s"), "White");
		}
		else if( nPolarity == 2)
		{
			strData.Format(_T("%s"), "Ignore");
		}
		else
		{
			strData.Format(_T("%s"), "error");
		}
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));// Gvitem.iCombo = GV_COMBO;

		options.RemoveAll();
		options.Add(_T("Black"));
		options.Add(_T("White"));
		options.Add(_T("Ignore"));

		pCell = (CGridCellCombo*) m_Grid.GetCell(Gvitem.row, Gvitem.col);
		pCell->SetOptions(options);
		pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE


		//Gvitem.iComboType = GVC_POLARITY;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dScannerContrast[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dScannerBrightness[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerRing[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerCoaxial[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerIR[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerRing2[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerCoaxial2[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerIR2[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_SCANNERFACTS);
		ColumnNo++;


		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerRing3[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerCoaxial3[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerIR3[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;


		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerRing4[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerCoaxial4[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerIR4[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;


	}	
	if(TableNo == TABLE5)
	{
		Gvitem.row = ColCount + 1;
		
		int nVisionNo = gVariable.m_sgBeamPath.nHoleVisionCam[ColCount];
		if(nVisionNo ==0)
		{
			strData.Format(_T("%s"), "High");
		}
		else if( nVisionNo == 1 )
		{
			strData.Format(_T("%s"), "Low");
		}
		
		else
		{
			strData.Format(_T("%s"), "error");
		}
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));// Gvitem.iCombo = GV_COMBO;

		CStringArray options;
		options.Add(_T("high"));
		options.Add(_T("Low"));

		CGridCellCombo *pCell = (CGridCellCombo*) m_Grid.GetCell(Gvitem.row, Gvitem.col);
		pCell->SetOptions(options);
		pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE


		//Gvitem.iComboType = GVC_VISION;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dHoleVisionModelSize[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;
		
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dHoleAcceptScoreSize[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;
		
		int nPolarity = gVariable.m_sgBeamPath.nHolePolarity[ColCount];
		if( nPolarity ==0 )
		{
			strData.Format(_T("%s"), "Black");
		}
		else if( nPolarity == 1)
		{
			strData.Format(_T("%s"), "White");
		}
		else if( nPolarity == 2)
		{
			strData.Format(_T("%s"), "Ignore");
		}
		else
		{
			strData.Format(_T("%s"), "error");
		}
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCellCombo));// Gvitem.iCombo = GV_COMBO;

		options.RemoveAll();
		options.Add(_T("Black"));
		options.Add(_T("White"));
		options.Add(_T("Ignore"));

		pCell = (CGridCellCombo*) m_Grid.GetCell(Gvitem.row, Gvitem.col);
		pCell->SetOptions(options);
		pCell->SetStyle(CBS_DROPDOWNLIST); //CBS_DROPDOWN, CBS_DROPDOWNLIST, CBS_SIMPLE

		//Gvitem.iComboType = GVC_POLARITY;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dHoleContrast[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dHoleBrightness[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nHoleRing[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nHoleCoaxial[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nHoleIR[ColCount]);
		Gvitem.strText = strData;
		Gvitem.col = ColumnNo;
		m_Grid.SetCellType(Gvitem.row, Gvitem.col, RUNTIME_CLASS(CGridCell)); //Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		m_Grid.SetItemBkColour(Gvitem.row, Gvitem.col, COLOR_HOLEFACTS);
		ColumnNo++;
	}
	m_Grid.AutoSize();
}

void CDlgBeamPathTable::InsertListValue(LV_ITEM lvitem, int startNo, int TableNo, int ColCount)
{
	int ColumnNo = startNo;
	CString strData;	

	if(TableNo == TABLE0)
	{
		if( ColumnNo == 0)
		{
			ColumnNo++;
		}
		else
		{
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[ColCount]);
			m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
			ColumnNo++;
		}	
		
		strData.Format(_T("%s"), gVariable.m_sgBeamPath.strInfoName[ColCount]);
		strData = gVariable.m_sgBeamPath.strInfoName[ColCount];
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dInfoMaskSize[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;	
	}

	if(TableNo == TABLE1)
	{
		if( ColumnNo == 0)
		{
			ColumnNo++;
		}
		else
		{
			strData.Format(_T("%.2f"),  gVariable.m_sgBeamPath.dBeamPathBetPos1[ColCount]);
			m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
			ColumnNo++;
		}

		strData.Format(_T("%.2f"),  gVariable.m_sgBeamPath.dBeamPathBetPos2[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nBeamPathMaskPos1[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nBeamPathMaskPos2[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nBeamPathMaskPos3[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;


		strData.Format(_T("%.3f"),  gVariable.m_sgBeamPath.dBeamPathZAxisPos1[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%.3f"),  gVariable.m_sgBeamPath.dBeamPathZAxisPos2[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		BOOL bBeamPath = gVariable.m_sgBeamPath.bBeamPathLaserPath[ColCount];
		if(bBeamPath == FALSE)
		{
			strData.Format(_T("%s"), "Long");
		}
		else if( bBeamPath == TRUE )
		{
			strData.Format(_T("%s"), "Short");
		}
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%s"),  gVariable.m_sgBeamPath.strBeamPathAscFile[ColCount]);
		strData = gVariable.m_sgBeamPath.strBeamPathAscFile[ColCount];
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;


		strData.Format(_T("%.3f"),  gVariable.m_sgBeamPath.dBeamPathTopHat[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

#ifdef __PKG_MODIFY__
		strData.Format(_T("%.3f"),  gVariable.m_sgBeamPath.dBeamPathRotator[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
#else
		BOOL bUseTophHat = gVariable.m_sgBeamPath.bBeamPathUseTophat[ColCount];
		if(bUseTophHat == FALSE)
		{
			strData.Format(_T("%s"), "OFF");
		}
		else if( bUseTophHat == TRUE )
		{
			strData.Format(_T("%s"), "ON");
		}
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
#endif


	}

	if(TableNo == TABLE2)
	{
		if( ColumnNo == 0)
		{
			ColumnNo++;
		}
		else
		{
			strData.Format(_T("%.2f"),  gVariable.m_sgBeamPath.dPowOffsetDuty[ColCount]);
			m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
			ColumnNo++;
		}	
	}

	if(TableNo == TABLE3)
	{
		if( ColumnNo == 0)
		{
			ColumnNo++;
		}
		else
		{
			int nSel = 0;
			nSel = gVariable.m_sgBeamPath.nSelectShot[ColCount];

			strData.Format(_T("[%d] %s"),nSel, gShotTableINI.m_sShotGroupTable.strInfoName[nSel]);
			m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
			ColumnNo++;
		}	
		
		strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nPowCompensationFrequency[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowCompensationDuty[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
	
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowCompensationTargetMin[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowCompensationTargetMax[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowCompensationDutyOffset[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;	

		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowCompensationTarget[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowCompensationTargetPercent[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
	}

	if(TableNo == TABLE4)
	{
		if( ColumnNo == 0)
		{
			ColumnNo++;
		}
		else
		{
			strData.Format(_T("%.2f"),  gVariable.m_sgBeamPath.dScannerDuty[ColCount]);
			m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
			ColumnNo++;
		}	
		

		strData.Format(_T("%d"),  (int)gVariable.m_sgBeamPath.dScannerFrq[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

	


		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerTotalShot[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		int nVisionNo = gVariable.m_sgBeamPath.nScannerVisionCam[ColCount];
		if(nVisionNo ==0)
		{
			strData.Format(_T("%s"), "High");
		}
		else if( nVisionNo == 1 )
		{
			strData.Format(_T("%s"), "Low");
		}
		
		else
		{
			strData.Format(_T("%s"), "error");
		}
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dScannerVisionModelSize[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dScannerAcceptScoreSize[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		int nPolarity = gVariable.m_sgBeamPath.nScannerPolarity[ColCount];
		if( nPolarity ==0 )
		{
			strData.Format(_T("%s"), "Black");
		}
		else if( nPolarity == 1)
		{
			strData.Format(_T("%s"), "White");
		}
		else if( nPolarity == 2)
		{
			strData.Format(_T("%s"), "Ignore");
		}
		else
		{
			strData.Format(_T("%s"), "error");
		}
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dScannerContrast[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dScannerBrightness[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;	

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerRing[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerCoaxial[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;	

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerIR[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerRing2[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerCoaxial2[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerIR2[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerRing3[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerCoaxial3[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerIR3[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;


		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerRing4[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerCoaxial4[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nScannerIR4[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
	}	
	
	if(TableNo == TABLE5)
	{
		if( ColumnNo == 0)
		{
			ColumnNo++;
		}
		else
		{
			
			int nVisionNo = gVariable.m_sgBeamPath.nHoleVisionCam[ColCount];
			if(nVisionNo ==0)
			{
				strData.Format(_T("%s"), "High");
			}
			else if( nVisionNo == 1 )
			{
				strData.Format(_T("%s"), "Low");
			}
			
			else
			{
				strData.Format(_T("%s"), "error");
			}
			m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
			ColumnNo++;
		}	
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dHoleVisionModelSize[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dHoleAcceptScoreSize[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		int nPolarity = gVariable.m_sgBeamPath.nHolePolarity[ColCount];
		if( nPolarity ==0 )
		{
			strData.Format(_T("%s"), "Black");
		}
		else if( nPolarity == 1)
		{
			strData.Format(_T("%s"), "White");
		}
		else if( nPolarity == 2)
		{
			strData.Format(_T("%s"), "Ignore");
		}
		else
		{
			strData.Format(_T("%s"), "error");
		}
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dHoleContrast[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dHoleBrightness[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;	

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nHoleRing[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nHoleCoaxial[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;	

		strData.Format(_T("%d"), gVariable.m_sgBeamPath.nHoleIR[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;	
	}	
}

int CDlgBeamPathTable::GetColumnSize(int nStrlen)
{

	if( nStrlen < 3)
		nStrlen = (nStrlen * COLUMNWIDTH) + 25;
	else if(nStrlen < 6 )
		nStrlen *= ( COLUMNWIDTH -2);
	else
		nStrlen = (4 * COLUMNWIDTH) + 25 ;	

	return nStrlen;
}

void CDlgBeamPathTable::InsertListComumn(int startNo, int TableNo)
{
	int ColumnNo = startNo;
	m_list.SetExtendedStyle(LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT);

	int nSize =0 ;
	int nStrLen = 0;

	if(TableNo == TABLE0) 
	{
		m_Grid.SetColumnCount(TABLE0_COLUMN_COUNT);
		for(int i = 0 ;i < TABLE0_COLUMN_COUNT; i++)  
		{
			nSize = strTable0[i].GetLength();
			nStrLen = GetColumnSize(nSize);
			if (i == 0)
				nStrLen = 30 ;		// ����Ʈ�� ���� �R�׸��� No���� �÷� ������ 

			if ( i ==1 )
				nStrLen = 130;		// name �÷��� ������ 

			m_list.InsertColumn(ColumnNo, strTable0[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = i;
			Item.strText = strTable0[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else if(TableNo == TABLE1)
	{
		m_Grid.SetColumnCount(m_nColumnCount + TABLE1_COLUMN_COUNT);
		int nColumnCount = m_nColumnCount;
		for(int i = 0 ;i < TABLE1_COLUMN_COUNT; i++)
		{
			nSize = strTable1[i].GetLength();
			nStrLen = GetColumnSize(nSize);
			
			m_list.InsertColumn(ColumnNo, strTable1[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = nColumnCount + i;
			Item.strText = strTable1[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else if(TableNo == TABLE2)
	{
 		m_Grid.SetColumnCount(m_nColumnCount + TABLE2_COLUMN_COUNT);
		int nColumnCount = m_nColumnCount;
		for(int i = 0 ;i < TABLE2_COLUMN_COUNT; i++)
		{	
			nSize = strTable2[i].GetLength();
			nStrLen = GetColumnSize(nSize);
			
			m_list.InsertColumn(ColumnNo, strTable2[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = nColumnCount + i;
			Item.strText = strTable2[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else if(TableNo == TABLE3)
	{
		m_Grid.SetColumnCount(m_nColumnCount + TABLE3_COLUMN_COUNT);
		int nColumnCount = m_nColumnCount;
		for(int i = 0 ;i < TABLE3_COLUMN_COUNT; i++)
		{
			nSize = strTable3[i].GetLength();
			nStrLen = GetColumnSize(nSize);
			
			m_list.InsertColumn(ColumnNo, strTable3[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = nColumnCount + i;
			Item.strText = strTable3[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else if(TableNo == TABLE4)
	{
		m_Grid.SetColumnCount(m_nColumnCount + TABLE4_COLUMN_COUNT);
		int nColumnCount = m_nColumnCount;
		for(int i = 0 ;i < TABLE4_COLUMN_COUNT; i++)
		{	
			nSize = strTable4[i].GetLength();
			nStrLen = GetColumnSize( nSize);
			
			m_list.InsertColumn(ColumnNo, strTable4[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = nColumnCount + i;
			Item.strText = strTable4[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else if(TableNo == TABLE5)
	{
		m_Grid.SetColumnCount(m_nColumnCount + TABLE5_COLUMN_COUNT);
		int nColumnCount = m_nColumnCount;
		for(int i = 0 ;i < TABLE5_COLUMN_COUNT; i++)
		{	
			nSize = strTable5[i].GetLength();
			nStrLen = GetColumnSize( nSize);
			
			m_list.InsertColumn(ColumnNo, strTable5[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;
			
			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = nColumnCount + i;
			Item.strText = strTable5[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else
	{
		//error
	}
}

void CDlgBeamPathTable::DeleteList()
{
/*	CListCtrl &ctrllist = m_list;
	CHeaderCtrl	*pHeaderCtrl;

	pHeaderCtrl = ctrllist.GetHeaderCtrl();
	int nCount = pHeaderCtrl->GetItemCount();
*/
	m_nColumnCount = 0;
/*
	if( -1 ==nCount)
	{
		AfxMessageBox(_T("Header Column not exist"));
		return;
	}
	else if( 0 < nCount)
	{
		ctrllist.DeleteAllItems();
		for(int i = 0;i <nCount; i++)
		{
			ctrllist.DeleteColumn(0);
		}
	}
*/
}

void CDlgBeamPathTable::SetDrawMember(int listcount)
{
	int i;
	LV_ITEM lvitem;
	GV_ITEM Item;
	CString strData;
	DWORD dwTextStyle = DT_CENTER|DT_VCENTER|DT_SINGLELINE;    //Text ��Ÿ�� ����
	Item.mask = GVIF_TEXT|GVIF_FORMAT;
	Item.nFormat = dwTextStyle;

	if(listcount == 0)
	{

	}
	else if(listcount == 1) //1
	{
		InsertListComumn(0,TABLE0);
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);

			InsertListValue(lvitem, 0,TABLE0,i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
		}

	}
	else if(listcount ==2 )  //2
	{
		InsertListComumn(0,TABLE1);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);

			InsertListValue(lvitem, 0 ,TABLE1, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE1, i);
		}
	}
	else if(listcount ==4) //4
	{
		InsertListComumn(0,TABLE2);

	
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);

			InsertListValue(lvitem, 0 ,TABLE2, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE2, i);
		}
	}
	else if(listcount == 8) //8
	{
		InsertListComumn(0,TABLE3);

	
		for( i = m_nRepeatCount-1 ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);

			InsertListValue(lvitem, 0 ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE3, i);
		}
	}
	else if( listcount == 16) //16
	{
		InsertListComumn(0,TABLE4);
	
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);

			InsertListValue(lvitem, 0 ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			InsertGridValue(Item, 0, TABLE4, i);
		}
	}
	else if(listcount == 32)
	{
		InsertListComumn(0, TABLE5);
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			InsertGridValue(Item, 0, TABLE5, i);
		}

	}

	else if(listcount == 3) //1,2
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);// 3�� �÷� ���� ���� 

			InsertListValue(lvitem, 0 ,TABLE0, i);						// 0�� �÷� ���� ���� 
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);// 3�� �÷� ���� ���� 
		}
	}
	else if(listcount ==5) //1,4
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE2);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
		}
	}
	else if(listcount ==9) //1,8
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE3);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE3, i);
		}
	}
	else if(listcount == 17) //1,16
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE4);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE4, i);
		}
	}
	else if(listcount == 33) // 1, 32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE5);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE5, i);
		}
	}
	else if(listcount == 7)  //1,2,4
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2, i);
		}
	}
	else if(listcount ==11)//1,2,8
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE3);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE3, i);
		}
	}
	else if(listcount == 19)//1,2,16
	{

		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE4, i);
		}
	}
	else if(listcount == 35)//1,2,32
	{
		
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT,TABLE5);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE5, i);
		}
	}
	else if(listcount == 13)//1,4.8
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT,TABLE3);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE3, i);
		}
	}
	else if(listcount == 21) //1,4,16
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT ,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE4, i);
		}
	}
	else if(listcount == 37) //1,4,32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT ,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT,TABLE5);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE5, i);
		}
	}
	else if(listcount == 25) //1,8,16
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE3); //3
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT,TABLE4);//11

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);
		}
	}
	else if(listcount == 41) //1,8,32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE3); //3
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT,TABLE5);//11
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE5, i);
		}
	}
	else if(listcount == 49) //1,16,32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE4); //3
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE4_COLUMN_COUNT,TABLE5);//11
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE4, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE4_COLUMN_COUNT ,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE4, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE4_COLUMN_COUNT ,TABLE5, i);
		}
	}
	else if(listcount == 15) //1,2,4,8
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT,TABLE3);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);

		}
	}

	else if(listcount ==23) //1,2,4,16
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE4, i);
		}
	}
	else if(listcount ==39) //1,2,4,32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT,TABLE5);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE5, i);
		}
	}
	else if(listcount ==27) //1,2,8,16
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);
		}

	}
	else if(listcount ==43) //1,2,8,32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT,TABLE5);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE5, i);
		}
		
	}
	else if(listcount ==51) //1,2,16,32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT,TABLE4);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE4_COLUMN_COUNT,TABLE5);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE4, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE4_COLUMN_COUNT ,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE4, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE4_COLUMN_COUNT ,TABLE5, i);
		}
		
	}
	else if(listcount == 29)// 1,4,8,16
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);

			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);
		}
	}
	else if(listcount == 45)// 1,4,8,32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT,TABLE5);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE5, i);
		}
	}

	else if(listcount == 53)// 1,4,16,32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT,TABLE4);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE4_COLUMN_COUNT,TABLE5);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE4, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE4_COLUMN_COUNT ,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE4, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE4_COLUMN_COUNT ,TABLE5, i);
		}
	}
	else if(listcount == 57)// 1,8,16,32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT,TABLE4);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT +TABLE4_COLUMN_COUNT,TABLE5);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE4, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT +TABLE4_COLUMN_COUNT ,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE4, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT +TABLE4_COLUMN_COUNT ,TABLE5, i);
		}
	}
	else if(listcount == 31) //1,2,4,8,16
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT,TABLE2);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT,TABLE3);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);

			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE4, i);
		}
	}
	else if(listcount == 47) //1,2,4,8,32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT,TABLE2);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT,TABLE3);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT,TABLE5);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE5, i);
		}
	}
	else if(listcount == 61)// 1,4,8,16,32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT,TABLE4);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT,TABLE5);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT ,TABLE5, i);
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT,TABLE5, i);
		}
	}
	else if(listcount == 59)// 1,2,8,16,32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT,TABLE4);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT,TABLE5);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT ,TABLE5, i);
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT,TABLE5, i);
		}
	}
	else if(listcount == 55)// 1,2,4,16,32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT,TABLE4);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT,TABLE5);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE4, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT ,TABLE5, i);
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE4, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT,TABLE5, i);
		}
	}
	else if(listcount == 63) //1,2,4,8,16,32
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT,TABLE2);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT,TABLE3);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT,TABLE4);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT,TABLE5);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  gVariable.m_sgBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT,TABLE4, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT,TABLE4, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT,TABLE5, i);
		}
	}
	// start 2
	else if(listcount == 6)
	{
		InsertListComumn(0,TABLE1);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT ,TABLE2);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dBeamPathBetPos1[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT  ,TABLE2, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT  ,TABLE2, i);
		}
	}
	else if(listcount == 10)
	{
		InsertListComumn(0,TABLE1);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT ,TABLE3);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dBeamPathBetPos1[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT  ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT  ,TABLE3, i);
		}
	}

	else if(listcount == 18)
	{
		InsertListComumn(0,TABLE1);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT ,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dBeamPathBetPos1[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT  ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT  ,TABLE4, i);

		}
	}

	else if(listcount == 14)
	{
		InsertListComumn(0,TABLE1);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT ,TABLE2);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE3);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dBeamPathBetPos1[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE3, i);

		}
	}

	else if(listcount == 22)
	{
		InsertListComumn(0,TABLE1);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dBeamPathBetPos1[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE4, i);
		}
	}
	else if(listcount == 26)
	{
		InsertListComumn(0,TABLE1);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dBeamPathBetPos1[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 , TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 , TABLE1, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE4, i);
		}
	}

	else if(listcount == 30)
	{
		InsertListComumn(0,TABLE1);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dBeamPathBetPos1[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE4, i);
		}
	}

	//start 4
	else if(listcount == 12)
	{
		InsertListComumn(0,TABLE2);
		InsertListComumn(0 + TABLE2_COLUMN_COUNT,TABLE3);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowOffsetDuty[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE2_COLUMN_COUNT ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE2_COLUMN_COUNT ,TABLE3, i);
		}


	}
	else if(listcount == 20)
	{
		InsertListComumn(0,TABLE2);
		InsertListComumn(0 + TABLE2_COLUMN_COUNT,TABLE4);
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowOffsetDuty[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE2_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);

			InsertGridValue(Item, 0 ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE2_COLUMN_COUNT ,TABLE4, i);
		}
	}

	else if(listcount == 28)
	{
		InsertListComumn(0,TABLE2);
		InsertListComumn(0 + TABLE2_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4);
		for( i = m_nRepeatCount; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), gVariable.m_sgBeamPath.dPowOffsetDuty[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);
		}
	}


	//start 8
	else if(listcount == 24)
	{
		InsertListComumn(0,TABLE3);
		InsertListComumn(0 + TABLE3_COLUMN_COUNT,TABLE4);


		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"), gVariable.m_sgBeamPath.nPowCompensationFrequency[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);

			InsertGridValue(Item, 0 ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE3_COLUMN_COUNT ,TABLE4, i);
		}

	}

	//start 16
	else if(listcount == 48) // 16, 32
	{
		InsertListComumn(0,TABLE4);
		InsertListComumn(0 + TABLE4_COLUMN_COUNT,TABLE5);
		
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"), gVariable.m_sgBeamPath.nPowCompensationFrequency[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE4_COLUMN_COUNT ,TABLE5, i);
			
			m_Grid.SetRowCount(2 + m_nRepeatCount);
			
			InsertGridValue(Item, 0 ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE4_COLUMN_COUNT ,TABLE5, i);
		}
		
	}

}

void CDlgBeamPathTable::SetBeamPath(SBEAMPATH sBeamPath)
{
	memcpy( &gVariable.m_sgBeamPath, &sBeamPath, sizeof(gVariable.m_sgBeamPath) );	
	m_nRepeatCount= gVariable.m_sgBeamPath.nLastIndex ;	
}


void CDlgBeamPathTable::OnClickList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NMITEMACTIVATE* pnmia=(NMITEMACTIVATE*)pNMHDR;

	// �ʱ�ȭ 
	m_ClickID = FALSE;
	SetIdNoToAddDel(0);
	m_bClickList = TRUE;
	
	//���õ� ����Ʈ �׸� ��� 
	m_posClicked.x=pnmia->iSubItem;
	m_posClicked.y=pnmia->iItem;

	// �ε����׸� Ŭ�� �� �׸� ADD,Del�Ҷ� ���
	if(m_posClicked.x ==0) 
	{
		m_ClickID = TRUE;
		SetIdNoToAddDel(m_posClicked.y);
		return ;
	}	

	// id�� ,����Ʈ�� ���� ���� �κд����� �� ����
	if(m_posClicked.x == 0 || m_posClicked.y  == -1 )
	{
		m_bClickList = FALSE;
		m_ClickID = FALSE;
		return ;
	}


	// �޺��ڽ�, ����Ʈ �ڽ� ����
	int bSelectShowBoxMode = GetShowBoxMode( m_posClicked.x );	// return (0: edit �ڽ� �׸���, 1: use top hat combobox �׸���, 2: polarity combobox �׸���  )


	CString str;
	CRect rectCell;
	str=m_list.GetItemText(pnmia->iItem, pnmia->iSubItem);
	m_editwnd.SetWindowText(str);

	if( 0 ==bSelectShowBoxMode )
	{
		//����Ʈ �ڽ� �׸��� 
		
		m_list.GetSubItemRect(pnmia->iItem, pnmia->iSubItem, LVIR_BOUNDS, rectCell);
		m_editwnd.SetWindowPos(NULL, rectCell.left+16, rectCell.top+34, rectCell.right-rectCell.left, rectCell.bottom-rectCell.top, SWP_NOZORDER|SWP_SHOWWINDOW);
		m_editwnd.SetFocus();
		m_editwnd.SetSel(0, -1);

	//	m_bClickList = TRUE;	// ����Ű�� ����Ʈ �ڽ��� ��� 
		
	}
	else if( 1 == bSelectShowBoxMode )
	{
		//use top hat �޺� �ڽ� �׸����  
		
 		m_list.GetSubItemRect(pnmia->iItem, pnmia->iSubItem, LVIR_BOUNDS, rectCell);

		m_list.GetSubItemRect(pnmia->iItem, pnmia->iSubItem, LVIR_BOUNDS, rectCell);

		m_editwnd.ShowWindow(SW_HIDE);

	//	m_bClickList = TRUE;	// ����Ű�� ����Ʈ �ڽ��� ��� 

	}
	else if( 2 == bSelectShowBoxMode)
	{
		// poloarity �޺��ڽ� �׸���
		m_list.GetSubItemRect(pnmia->iItem, pnmia->iSubItem, LVIR_BOUNDS, rectCell);

		m_editwnd.ShowWindow(SW_HIDE);

	//	m_bClickList = TRUE;	// ����Ű�� ����Ʈ �ڽ��� ��� 

	}
	else if(3 == bSelectShowBoxMode)
	{
		//vision �޺��ڽ� �׸��� 
		m_list.GetSubItemRect(pnmia->iItem, pnmia->iSubItem, LVIR_BOUNDS, rectCell);

		m_editwnd.ShowWindow(SW_HIDE);

		//m_bClickList = TRUE;	// ����Ű�� ����Ʈ �ڽ��� ��� 

	}
	else
	{
		//error
	}
	
	*pResult = 0;
}

void CDlgBeamPathTable::GetBeamPath(SBEAMPATH* pBeamPath)
{

	gVariable.m_sgBeamPath.nLastIndex = m_nRepeatCount;	//����Ʈ�� �� ������ �ε��� ���� 
	memcpy( pBeamPath, &gVariable.m_sgBeamPath, sizeof(gVariable.m_sgBeamPath) );
}

BOOL CDlgBeamPathTable::PreTranslateMessage(MSG* pMsg) 
{



	if(m_Grid.m_bMouseOn && GetKeyState(VK_CONTROL) < 0)
	{
		CCellID cCellId;
		cCellId = m_Grid.GetFocusCell();
		if(m_Grid.m_bFixedColumnClick)
		{
			gVariable.m_sgBeamPath.bSelectedList[cCellId.row] = TRUE;
			m_Grid.m_bFixedColumnClick = FALSE;
		}
		
	}
	else if(m_Grid.m_bMouseOn)
	{
		CCellID cCellId;
		cCellId = m_Grid.GetFocusCell();
		//if(m_Grid.m_bFixedColumnClick)
		{
			for(int i = 0; i < BEAMPATH_COUNT; i++)
			{
				gVariable.m_sgBeamPath.bSelectedList[i] = FALSE;
			}
			gVariable.m_sgBeamPath.bSelectedList[cCellId.row] = TRUE;
			m_Grid.m_bFixedColumnClick = FALSE;
		}
	}

	if(m_Grid.m_bKeyboardOn)
	{
		CCellID cCellId;
		CPoint cpClickedCell;
		CString str;
		int nCol = 0;
		int nRow = 0;
		nCol = m_Grid.GetColumnCount();
		nRow = m_Grid.GetRowCount();
		cCellId = m_Grid.GetEditedCell();

		for(int i = 1; i < nCol; i++)
		{
			cpClickedCell.x = i;
			for(int j = 1; j < nRow; j++)
			{
				cpClickedCell.y = j - 1;
				str = m_Grid.GetItemText(j, i);
				ListUpdate(cpClickedCell, str);
			}
		}
		m_Grid.m_bKeyboardOn = FALSE;
	}
	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CDlgBeamPathTable::MoveFocus(int nXpos, int nYpos, int nMoveType) //nXpos,nypos �̵� ���� �� �����ϰ� ���� 
{
	CString str;
	CRect rectCell;	
	
	// Ŭ�� ���� ������ ������Ʈ 
	int bSelectShowBoxMode = GetShowBoxMode( m_posClicked.x );

	if( 0 ==bSelectShowBoxMode )
	{
		//����Ʈ �ڽ�
		m_editwnd.GetWindowText(str);		
	}
	ListUpdate(m_posClicked, str);

	DeleteList();
	int nlistcount = GetListIndex();
	SetDrawMember(nlistcount);


	//�̵� ��ġ�� ����Ʈ �ڽ� �̵� 
	if(TRUE == m_bClickList)		// m_bClickList ==TRUE �� :����Ʈ�� �׸��� ��Ʈ���� �� 
	{

		switch (nMoveType)
		{
		case VK_UP:
			m_posClicked.y--;
			break;
			
		case VK_DOWN:
			m_posClicked.y++;
			break;
			
		case VK_RIGHT:
			m_posClicked.x++;
			break;
			
		case VK_LEFT:
			m_posClicked.x--;
			break;
			
		default:
			break;
		}
		
		// ���� üũ ����Ʈ�� ���� �¿� üũ 
		if(m_posClicked.x == 0 || m_posClicked.y  == -1 )		//id��, �÷� �������� ��Ŀ�� �̵��� 
		{
			//bClickList = FALSE;
			m_posClicked.x = nXpos;		// ��ǥ�� ���� 
			m_posClicked.y = nYpos;
			SetCurrentScrollPos(m_posClicked.x,m_posClicked.y);
			return TRUE;
		}
		
		int nChecOutofListX, nChecOutofListY;
		nChecOutofListX = GetListRowIndexCount();		//����Ʈ ���� ũ��
		nChecOutofListY = m_nRepeatCount + 1;			//����Ʈ ���� ũ�� (������ �׸��ε��� + 0�� ��)

		if ( (m_posClicked.x >= nChecOutofListX) || (m_posClicked.y >= nChecOutofListY) )
		{
			//bClickList = FALSE;
			m_posClicked.x = nXpos;
			m_posClicked.y = nYpos;
			SetCurrentScrollPos(m_posClicked.x,m_posClicked.y);
			return TRUE;
		}

		// ��ũ�� �̵� ��ƾ 
		SetCurrentScrollPos(m_posClicked.x,m_posClicked.y);

		//�̵��� ��Ʈ�� �ڽ� �ٽ� �׸���
		bSelectShowBoxMode = GetShowBoxMode( m_posClicked.x );
		if( 0 ==bSelectShowBoxMode )
		{

			//����Ʈ �ڽ� �׸��� 		
			m_list.GetSubItemRect(m_posClicked.y, m_posClicked.x, LVIR_BOUNDS, rectCell);
			str=m_list.GetItemText(m_posClicked.y, m_posClicked.x);
			m_editwnd.SetWindowText(str);

			m_editwnd.SetWindowPos(NULL, rectCell.left+16, rectCell.top+34, rectCell.right-rectCell.left, rectCell.bottom-rectCell.top, SWP_NOZORDER|SWP_SHOWWINDOW);
			m_editwnd.SetFocus();
			m_editwnd.SetSel(0, -1);
			
	
			//m_bClickList = TRUE;
			
		}
		else if( 1 == bSelectShowBoxMode )
		{
			//use top hat �޺� �ڽ� �׸����  
			
			m_list.GetSubItemRect(m_posClicked.y, m_posClicked.x, LVIR_BOUNDS, rectCell);
			
			m_editwnd.ShowWindow(SW_HIDE);
			
			//m_bClickList = TRUE;

		}
		else if( 2 == bSelectShowBoxMode)
		{
			// poloarity �޺��ڽ� �׸���
			m_list.GetSubItemRect(m_posClicked.y, m_posClicked.x, LVIR_BOUNDS, rectCell);
			m_editwnd.ShowWindow(SW_HIDE);
			
			//m_bClickList = TRUE;

		}
		else if(3 == bSelectShowBoxMode)
		{
			//vision �޺��ڽ� �׸��� 
			m_list.GetSubItemRect(m_posClicked.y, m_posClicked.x, LVIR_BOUNDS, rectCell);
			m_editwnd.ShowWindow(SW_HIDE);


		//	m_bClickList = TRUE;

		}
		else
		{
			//error
		}
	
	}
	return TRUE;
}

void CDlgBeamPathTable::OnKillfocusEditGrid()
{
	//EditBox�� �����ش�.
	m_editwnd.ShowWindow(SW_HIDE);
	
	if (m_posClicked.x==-1 || m_posClicked.y==-1) return;
	
	//�ڷ��� ������ ������. ��������.
	CString str;
	m_editwnd.GetWindowText(str);

	ListUpdate(m_posClicked, str);
	OnCheckRefresh();	
}

void CDlgBeamPathTable::FillTable0Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	if(xPos == 0)
		gVariable.m_sgBeamPath.nInfoId[yPos] = atoi(str);
	else if(xPos ==1 )
	{
		//name�� ������ ������ ���ɶ� ��� �Ұ���.  

		// �ߺ��Ǵ� name�� �� �ִ��� �˻� 
// 		CString strTemp;
// 		CString strCompare1, strCompare2;
// 		
// 		for(int i = 0 ;i < m_nRepeatCount;i++)
// 		{
// 			if(i == yPos)
// 				continue; // �������� �н� 
// 
// 			strCompare1.Format(_T("%s"), gVariable.m_sgBeamPath.strInfoName[i]);
// 			strCompare2 = str;
// 
// 			strCompare1.MakeLower();			// ��ҹ��ڴ� �������� �ʴ´�. 
// 			strCompare2.MakeLower();
// 
// 			if ( 0 == strCompare1.Compare(strCompare2))
// 			{
// 				strTemp.Format(_T("%d �׸�� �ߺ��˴ϴ�."), i);
// 				AfxMessageBox(strTemp);
// 				return;
// 			}
// 
// 		}
		strcpy_s(gVariable.m_sgBeamPath.strInfoName[yPos], str);

	}
	else if(xPos == 2)
			gVariable.m_sgBeamPath.dInfoMaskSize[yPos] = atof(str);
	
	m_list.SetItemText(y, x,str);
}

void CDlgBeamPathTable::FillTable1Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	int nTemp;

	if(xPos ==0)
		gVariable.m_sgBeamPath.dBeamPathBetPos1[yPos] = atof(str);
	else if(xPos ==1 )
		gVariable.m_sgBeamPath.dBeamPathBetPos2[yPos] = atof(str);
	else if(xPos ==2)
		gVariable.m_sgBeamPath.dBeamPathBetPos3[yPos] = atof(str);
	else if(xPos ==3 )
		gVariable.m_sgBeamPath.dBeamPathBetPos4[yPos] = atof(str);
	else if(xPos == 4)
	{
		nTemp = atoi(str);
		if(nTemp < 0 || nTemp >= 3600 )
		{
			AfxMessageBox(_T("Mask range : 0 <= Mask < 3600"));
			return ;
		}
		gVariable.m_sgBeamPath.nBeamPathMaskPos1[yPos] = atoi(str);
	}
	else if(xPos == 5 )
	{
		nTemp = atoi(str);
		if(nTemp < 0 || nTemp >= 3600 )
		{
			AfxMessageBox(_T("Mask range : 0 <= Mask < 3600"));	
			return ;
		}

		gVariable.m_sgBeamPath.nBeamPathMaskPos2[yPos] = atoi(str);
	}
	else if(xPos == 6)
		gVariable.m_sgBeamPath.dBeamPathZAxisPos1[yPos] = atof(str);
	else if(xPos == 7)
		gVariable.m_sgBeamPath.dBeamPathZAxisPos2[yPos] = atof(str);
	else if(xPos == 8)
		strcpy_s(gVariable.m_sgBeamPath.strBeamPathAscFile[yPos], str);

	m_list.SetItemText(y, x,str);
}

void CDlgBeamPathTable::FillTable2Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	double dTemp;
	if(xPos ==0)
	{
		dTemp = atof(str);
		gVariable.m_sgBeamPath.dPowOffsetDuty[yPos] = atof(str);
	}

	m_list.SetItemText(y, x,str);

}

void CDlgBeamPathTable::FillTable3Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;
	double dTarget = 10, dTargetMin = 10, dTargetMax = 10; 
	double	dTemp;
	CGridCellCombo *pCell;

	if(xPos == 0)
	{
		pCell = (CGridCellCombo*) m_Grid.GetCell(yPos + 1, xPos + 2);

		CString strShotName =  str;//pCell->GetText();
		for(int i = 0; i <=gShotTableINI.m_sShotGroupTable.nGroupLastIndex; i++)
		{
			CString str;
			str.Format("[%d] %s",i,gShotTableINI.m_sShotGroupTable.strInfoName[i]);

			if(strcmp(strShotName, str) == 0)
			{
				gVariable.m_sgBeamPath.nSelectShot[yPos] = i;
				break;
			}
		}
	}
	else if(xPos ==1)
	{
		gVariable.m_sgBeamPath.nPowCompensationFrequency[yPos] = atoi(str);
	}
	else if(xPos ==2 )
	{
		dTemp = atof(str);
		//if( dTemp < 0 || dTemp > 100)
		//{
		//	ErrMessage(_T("Duty range : 0 < Duty < 100 %"));
		//	return ;
		//}

		gVariable.m_sgBeamPath.dPowCompensationDuty[yPos] = atof(str);
	}
	else if(xPos == 3)
	{
		dTarget = gVariable.m_sgBeamPath.dPowCompensationTarget[yPos] * gVariable.m_sgBeamPath.dPowCompensationTargetPercent[yPos] / 100;
		dTargetMin = gVariable.m_sgBeamPath.dPowCompensationTarget[yPos] - dTarget;
		dTargetMax = gVariable.m_sgBeamPath.dPowCompensationTarget[yPos] + dTarget;
		dTemp = dTargetMin;
		if( dTemp < 0 || dTemp >=100 )
		{
			AfxMessageBox(_T("0 < Min.Value < 100"));
			return ;
		}
		gVariable.m_sgBeamPath.dPowCompensationTargetMin[yPos] = dTargetMin;
	}
	else if(xPos == 4)
	{
		dTarget = gVariable.m_sgBeamPath.dPowCompensationTarget[yPos] * gVariable.m_sgBeamPath.dPowCompensationTargetPercent[yPos] / 100;
		dTargetMin = gVariable.m_sgBeamPath.dPowCompensationTarget[yPos] - dTarget;
		dTargetMax = gVariable.m_sgBeamPath.dPowCompensationTarget[yPos] + dTarget;
		dTemp = dTargetMax;
		if( dTemp < 0 || dTemp >=100 )
		{
			AfxMessageBox(_T("0 < Min.Value < 100"));
			return ;
		}
		gVariable.m_sgBeamPath.dPowCompensationTargetMax[yPos] = dTargetMax;
	}
	else if(xPos == 5)
		gVariable.m_sgBeamPath.dPowCompensationDutyOffset[yPos] = atof(str);	
	else if(xPos == 6)
	{
		dTemp = atof(str);
		if( dTemp < 0 || dTemp >=100 )
		{
			AfxMessageBox(_T("0 < Value < 100"));
			return ;
		}
		gVariable.m_sgBeamPath.dPowCompensationTarget[yPos] = atof(str);
		dTarget = gVariable.m_sgBeamPath.dPowCompensationTarget[yPos] * gVariable.m_sgBeamPath.dPowCompensationTargetPercent[yPos] / 100;
		gVariable.m_sgBeamPath.dPowCompensationTargetMin[yPos] = gVariable.m_sgBeamPath.dPowCompensationTarget[yPos] - dTarget;
		gVariable.m_sgBeamPath.dPowCompensationTargetMax[yPos] = gVariable.m_sgBeamPath.dPowCompensationTarget[yPos] + dTarget;
	}
	else if(xPos == 7)
	{
		dTemp = atof(str);
		if( dTemp < 0 || dTemp >=100 )
		{
			AfxMessageBox(_T("0 < Value < 100"));
			return ;
		}
		gVariable.m_sgBeamPath.dPowCompensationTargetPercent[yPos] = atof(str);
		dTarget = gVariable.m_sgBeamPath.dPowCompensationTarget[yPos] * gVariable.m_sgBeamPath.dPowCompensationTargetPercent[yPos] / 100;
		gVariable.m_sgBeamPath.dPowCompensationTargetMin[yPos] = gVariable.m_sgBeamPath.dPowCompensationTarget[yPos] - dTarget;
		gVariable.m_sgBeamPath.dPowCompensationTargetMax[yPos] = gVariable.m_sgBeamPath.dPowCompensationTarget[yPos] + dTarget;
	}
	
	m_list.SetItemText(y, x,str);
}

void CDlgBeamPathTable::FillTable4Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	int		nTemp;
	double	dTemp;

	if(xPos ==0)
	{
		dTemp = atof(str);
		//if( dTemp < 0 || dTemp > 100)
		//{
		//	ErrMessage(_T("Duty range : 0 < Duty < 100 %"));
		//	return ;
		//}
		gVariable.m_sgBeamPath.dScannerDuty[yPos] = atof(str);
	}
	else if(xPos ==1)
	{
		dTemp = atof(str);
		//if( dTemp < 0 || dTemp > 100)
		//{
		//	ErrMessage(_T("Duty range : 0 < Duty < 100 %"));
		//	return ;
		//}
		gVariable.m_sgBeamPath.dScannerFrq[yPos] = atof(str);
	}




	else if(xPos == 2)
	{
		nTemp = atoi(str);
		if( nTemp <= 0 || nTemp >15)
		{
			AfxMessageBox(_T("Shot Range : 0 < shot < 15"));
			return ;
		}
		gVariable.m_sgBeamPath.nScannerTotalShot[yPos] = atoi(str);
	}
	else if(xPos == 3)
	{
/*		int nVisionMode = GetVisionMode();
		if( (nVisionMode ==0) || (nVisionMode ==1))
		{
			gVariable.m_sgBeamPath.nScannerVisionCam[yPos] = nVisionMode;
		}
		else
		{
			AfxMessageBox(_T("Vision (High: 0, Low: 1)"));
			return;
		}
*/
		if(strcmp(str, "High") == 0)
			gVariable.m_sgBeamPath.nScannerVisionCam[yPos] = 0;
		else if(strcmp(str, "Low") == 0)
			gVariable.m_sgBeamPath.nScannerVisionCam[yPos] = 1;
	}

	else if(xPos == 4)
		gVariable.m_sgBeamPath.dScannerVisionModelSize[yPos] = atof(str);
	else if(xPos == 5)
		gVariable.m_sgBeamPath.dScannerAcceptScoreSize[yPos] = atof(str);
	else if(xPos == 6)
		gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[yPos] = atof(str);
	else if(xPos == 7)
	{
/*		int nCheckPolarity = GetPolarityMode();
		if((nCheckPolarity ==0 ) || (nCheckPolarity ==1 ) ||(nCheckPolarity ==2 ))
		{
			gVariable.m_sgBeamPath.nScannerPolarity[yPos] = nCheckPolarity;
		}
		else
		{
			AfxMessageBox(_T("Polarity (Black: 0, White: 1, Ignore: 2)"));	 
			return ;
		}
*/
		if(strcmp(str, "Black") == 0)
			gVariable.m_sgBeamPath.nScannerPolarity[yPos] = 0;
		else if(strcmp(str, "White") == 0)
			gVariable.m_sgBeamPath.nScannerPolarity[yPos] = 1;
		else if(strcmp(str, "Ignore") == 0)
			gVariable.m_sgBeamPath.nScannerPolarity[yPos] = 2;

	}
	else if(xPos == 8)
	{
		dTemp = atof(str);
		if(dTemp > 1.0 || dTemp < 0.0) 
		{
			AfxMessageBox(_T("Contrast Range : 0 <  Contrast < 1") );
			return ;
		}
		gVariable.m_sgBeamPath.dScannerContrast[yPos] = atof(str);
	}
	else if(xPos == 9)
	{
		dTemp = atof(str);
		if(dTemp > 1.0 || dTemp < 0.0) 
		{
			AfxMessageBox(_T("Brightness Range : 0 <  Brightness < 1") );
			return ;
		}
		gVariable.m_sgBeamPath.dScannerBrightness[yPos] = atof(str);
	}
	else if(xPos == 10)
	{
		dTemp = atoi(str);
		if(dTemp < 0|| dTemp > 255) 
		{
			AfxMessageBox(_T("Ring Range : 0 <  Ring < 255") );
			return ;
		}
		gVariable.m_sgBeamPath.nScannerRing[yPos] = atoi(str);
	}
	else if(xPos == 11)
	{
		dTemp = atoi(str);
		if(dTemp < 0 || dTemp > 255) 
		{
			AfxMessageBox(_T("Coaxial Range : 0 <  Coaxial < 255") );
			return ;
		}
		gVariable.m_sgBeamPath.nScannerCoaxial[yPos] = atoi(str);
	}
	else if(xPos == 12)
	{
		dTemp = atoi(str);
		if(dTemp < 0 || dTemp > 255) 
		{
			AfxMessageBox(_T("IR Range : 0 <  IR < 255") );
			return ;
		}
		gVariable.m_sgBeamPath.nScannerIR[yPos] = atoi(str);
	}
	else if(xPos == 13)
	{
		dTemp = atoi(str);
		if(dTemp < 0|| dTemp > 255) 
		{
			AfxMessageBox(_T("Ring 2 Range : 0 <  Ring 2 < 255") );
			return ;
		}
		gVariable.m_sgBeamPath.nScannerRing2[yPos] = atoi(str);
	}
	else if(xPos == 14)
	{
		dTemp = atoi(str);
		if(dTemp < 0 || dTemp > 255) 
		{
			AfxMessageBox(_T("Coaxial 2 Range : 0 <  Coaxial 2 < 255") );
			return ;
		}
		gVariable.m_sgBeamPath.nScannerCoaxial2[yPos] = atoi(str);
	}
	else if(xPos == 15)
	{
		dTemp = atoi(str);
		if(dTemp < 0 || dTemp > 255) 
		{
			AfxMessageBox(_T("IR 2 Range : 0 <  IR 2 < 255") );
			return ;
		}
		gVariable.m_sgBeamPath.nScannerIR2[yPos] = atoi(str);
	}

	else if(xPos == 16)
	{
		dTemp = atoi(str);
		if(dTemp < 0|| dTemp > 255) 
		{
			AfxMessageBox(_T("Ring 3 Range : 0 <  Ring 3 < 255") );
			return ;
		}
		gVariable.m_sgBeamPath.nScannerRing3[yPos] = atoi(str);
	}
	else if(xPos == 17)
	{
		dTemp = atoi(str);
		if(dTemp < 0 || dTemp > 255) 
		{
			AfxMessageBox(_T("Coaxial 3 Range : 0 <  Coaxial 3 < 255") );
			return ;
		}
		gVariable.m_sgBeamPath.nScannerCoaxial3[yPos] = atoi(str);
	}
	else if(xPos == 18)
	{
		dTemp = atoi(str);
		if(dTemp < 0 || dTemp > 255) 
		{
			AfxMessageBox(_T("IR 3 Range : 0 <  IR 3 < 255") );
			return ;
		}
		gVariable.m_sgBeamPath.nScannerIR3[yPos] = atoi(str);
	}
	else if(xPos == 19)
	{
		dTemp = atoi(str);
		if(dTemp < 0|| dTemp > 255) 
		{
			AfxMessageBox(_T("Ring 4 Range : 0 <  Ring 4 < 255") );
			return ;
		}
		gVariable.m_sgBeamPath.nScannerRing4[yPos] = atoi(str);
	}
	else if(xPos == 20)
	{
		dTemp = atoi(str);
		if(dTemp < 0 || dTemp > 255) 
		{
			AfxMessageBox(_T("Coaxial 4 Range : 0 <  Coaxial 4 < 255") );
			return ;
		}
		gVariable.m_sgBeamPath.nScannerCoaxial4[yPos] = atoi(str);
	}
	else if(xPos == 21)
	{
		dTemp = atoi(str);
		if(dTemp < 0 || dTemp > 255) 
		{
			AfxMessageBox(_T("IR 4 Range : 0 <  IR 4 < 255") );
			return ;
		}
		gVariable.m_sgBeamPath.nScannerIR4[yPos] = atoi(str);
	}

	m_list.SetItemText(y, x,str);
}
void CDlgBeamPathTable::FillTable5Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	double	dTemp;

	if(xPos ==0)
	{
		if(strcmp(str, "High") == 0)
			gVariable.m_sgBeamPath.nHoleVisionCam[yPos] = 0;
		else if(strcmp(str, "Low") == 0)
			gVariable.m_sgBeamPath.nHoleVisionCam[yPos] = 1;
	}
	else if(xPos == 1)
		gVariable.m_sgBeamPath.dHoleVisionModelSize[yPos] = atof(str);
	else if(xPos == 2)
		gVariable.m_sgBeamPath.dHoleAcceptScoreSize[yPos] = atof(str);
	else if(xPos == 3)
		gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[yPos] = atof(str);
	else if(xPos == 4)
	{

		if(strcmp(str, "Black") == 0)
			gVariable.m_sgBeamPath.nHolePolarity[yPos] = 0;
		else if(strcmp(str, "White") == 0)
			gVariable.m_sgBeamPath.nHolePolarity[yPos] = 1;
		else if(strcmp(str, "Ignore") == 0)
			gVariable.m_sgBeamPath.nHolePolarity[yPos] = 2;

	}
	else if(xPos == 5)
	{
		dTemp = atof(str);
		if(dTemp > 1.0 || dTemp < 0.0) 
		{
			AfxMessageBox(_T("Contrast Range : 0 <  Contrast < 1") );
			return ;
		}
		gVariable.m_sgBeamPath.dHoleContrast[yPos] = atof(str);
	}
	else if(xPos == 6)
	{
		dTemp = atof(str);
		if(dTemp > 1.0 || dTemp < 0.0) 
		{
			AfxMessageBox(_T("Brightness Range : 0 <  Brightness < 1") );
			return ;
		}
		gVariable.m_sgBeamPath.dHoleBrightness[yPos] = atof(str);
	}
	else if(xPos == 7)
	{
		dTemp = atoi(str);
		if(dTemp < 0|| dTemp > 255) 
		{
			AfxMessageBox(_T("Ring Range : 0 <  Contrast < 255") );
			return ;
		}
		gVariable.m_sgBeamPath.nHoleRing[yPos] = atoi(str);
	}
	else if(xPos == 8)
	{
		dTemp = atoi(str);
		if(dTemp < 0 || dTemp > 255) 
		{
			AfxMessageBox(_T("Coaxial Range : 0 <  Brightness < 255") );
			return ;
		}
		gVariable.m_sgBeamPath.nHoleCoaxial[yPos] = atoi(str);
	}
	else if(xPos == 9)
	{
		dTemp = atoi(str);
		if(dTemp < 0 || dTemp > 250) 
		{
			AfxMessageBox(_T("IR Range : 0 <  Brightness < 250") );
			return ;
		}
		gVariable.m_sgBeamPath.nHoleIR[yPos] = atoi(str);
	}
	m_list.SetItemText(y, x,str);
}

void CDlgBeamPathTable::ListUpdate(CPoint ClickedPos, CString str)
{
	int listcount = GetListIndex();

	int xPos = ClickedPos.x;
	int yPos = ClickedPos.y;

	if(listcount == 0)
	{
		return ;
	}
	else if(listcount == 1) //1
	{
		FillTable0Data(xPos,yPos, str);	
	}
	else if(listcount ==2 )  //2
	{
		FillTable1Data(xPos,yPos, str);	

	}
	else if(listcount ==4) //4
	{
		FillTable2Data(xPos,yPos, str);	
	}
	else if(listcount == 8) //8
	{
		FillTable3Data(xPos,yPos, str);		
	}
	else if( listcount == 16) //16
	{
		FillTable4Data(xPos,yPos, str);	
	}
	else if( listcount == 32) // 32
	{
		FillTable5Data(xPos,yPos, str);
	}
	else if(listcount == 3) //1,2
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);
		}	
			
	}

	else if(listcount ==5) //1,4
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);
		}	
	}
	else if(listcount ==9) //1,8
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);
		}
	}
	else if(listcount == 17) //1,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable4Data(xPos,yPos, str);
		}
	}
	else if(listcount == 33) //1,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable5Data(xPos,yPos, str);
		}
	}
	else if(listcount == 7)  //1,2,4
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos,str);
		}
	}
	else if(listcount ==11)//1,2,8
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT+ TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT+ TABLE1_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
	}
	else if(listcount == 19)//1,2,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT+ TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT+ TABLE1_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}
	else if(listcount == 35)//1,2,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT+ TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT+ TABLE1_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
	else if(listcount == 13)//1,4.8
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
	}
	else if(listcount == 21) //1,4,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}
	else if(listcount == 37) //1,4,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
	else if(listcount == 25) //1,8,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}
	else if(listcount == 41) //1,8,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
	else if(listcount == 49) //1,16,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE4_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable4Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE4_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
	else if(listcount == 15) //1,2,4,8
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos,str);
		}
		else
		{
			xPos-=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
	}

	else if(listcount ==23) //1,2,4,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos,str);
		}
		else
		{
			xPos-=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}
	else if(listcount == 37) //1,2,4,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos,str);
		}
		else
		{
			xPos-=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
	

	else if(listcount ==27) //1,2,8,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE3_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else
		{
			xPos-= TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}

	}

	else if(listcount ==59) //1,2,8,16,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE3_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE3_COLUMN_COUNT +TABLE4_COLUMN_COUNT)
		{
			xPos-= TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
		else
		{
			xPos-= TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);

		}
			
	}
	
	else if(listcount ==43) //1,2,8,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE3_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else
		{
			xPos-= TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
		
	}
	else if(listcount == 51) //1,2,16,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE4_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
		else
		{
			xPos-= TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT + TABLE4_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
		
	}
	else if(listcount == 29)// 1,4,8,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else
		{
			xPos-=TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}
	else if(listcount == 45)// 1,4,8,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else
		{
			xPos-=TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
	else if(listcount == 53)// 1,4,16,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
		else
		{
			xPos-=TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
	else if(listcount == 57)// 1,8,16,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
		else
		{
			xPos-=TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
	else if(listcount == 61)// 1,4,8,16,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos < TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable2Data(xPos, yPos, str);
		}
		else if(TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
		else
		{
			xPos-=TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}

	else if(listcount == 31) //1,2,4,8,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos,str);
		}
		else if( TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else 
		{
			xPos-=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}
	else if(listcount == 31) //1,2,4,8,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos,str);
		}
		else if( TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else 
		{
			xPos-=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
	else if(listcount == 63) //1,2,4,8,16,32
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos,str);
		}
		else if( TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else if( TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
		else 
		{
			xPos-=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}

	// start 2
	else if(listcount == 6) //2,4
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);
		}
	}
	else if(listcount == 10)	//2,8
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);
		}
	}

	else if(listcount == 18) //2,16
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable4Data(xPos,yPos, str);
		}
	}
	else if(listcount == 34) //2,32
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable5Data(xPos,yPos, str);
		}
	}

	else if(listcount == 14) //2,4,8
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
	}

	else if(listcount == 22) //2,4,16
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}
	else if(listcount == 38) //2,4,32
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
	else if(listcount == 26) //2,8,16
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}
	else if(listcount == 42) //2,8,32
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
	else if(listcount == 50) //2,16,32
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE4_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable4Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE4_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
	else if(listcount == 30) //2,4,8,16
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else if(TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT)
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}

	}
	else if(listcount == 46) //2,4,8,32
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else if(TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT)
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
		
	}
	else if(listcount == 58) //2,8,16,32
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else if(TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT +TABLE4_COLUMN_COUNT)
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT +TABLE4_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
		
	}
	else if(listcount == 62) //2,4,8,16,32
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);	
		}
		else if(TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT + TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT +TABLE4_COLUMN_COUNT)
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
		else
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT +TABLE4_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}

	//start 4
	else if(listcount == 12)	//4,8
	{

		if(xPos < TABLE2_COLUMN_COUNT)
			FillTable2Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);
		}

	}
	else if(listcount == 20) //4,16
	{
		if(xPos < TABLE2_COLUMN_COUNT)
			FillTable2Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE2_COLUMN_COUNT;
			FillTable4Data(xPos,yPos, str);
		}
	}
	else if(listcount == 36) //4,32
	{
		if(xPos < TABLE2_COLUMN_COUNT)
			FillTable2Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE2_COLUMN_COUNT;
			FillTable5Data(xPos,yPos, str);
		}
	}
	else if(listcount == 28) //4,8,16
	{
		if(xPos < TABLE2_COLUMN_COUNT)
			FillTable2Data(xPos,yPos, str);	
		else if(TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -= TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}
	else if(listcount == 28) //4,8,32
	{
		if(xPos < TABLE2_COLUMN_COUNT)
			FillTable2Data(xPos,yPos, str);	
		else if(TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -= TABLE2_COLUMN_COUNT;
			FillTable5Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}
	else if(listcount == 52) //4,16,32
	{
		if(xPos < TABLE2_COLUMN_COUNT)
			FillTable2Data(xPos,yPos, str);	
		else if(TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT)
		{
			xPos -= TABLE4_COLUMN_COUNT;
			FillTable4Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
	else if(listcount == 60) //4,8,16,32
	{
		if(xPos < TABLE2_COLUMN_COUNT)
			FillTable2Data(xPos,yPos, str);	
		else if(TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -= TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);	
		}
		else if(TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT<= xPos && xPos <TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT)
		{
			xPos -= TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}

	//start 8	//8,16
	else if(listcount == 24)
	{
		if(xPos <TABLE3_COLUMN_COUNT)
			FillTable3Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos, str);
		}
	}
	else if(listcount == 40) // 8, 32
	{
		if(xPos <TABLE3_COLUMN_COUNT)
			FillTable3Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE3_COLUMN_COUNT;
			FillTable5Data(xPos,yPos, str);
		}
	}
	else if(listcount == 56) //8,16,32
	{
		if(xPos < TABLE3_COLUMN_COUNT)
			FillTable3Data(xPos,yPos, str);	
		else if(TABLE3_COLUMN_COUNT <= xPos && xPos <TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT)
		{
			xPos -= TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
	else if(listcount == 48) //16,32
	{
		if(xPos < TABLE4_COLUMN_COUNT)
			FillTable4Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE4_COLUMN_COUNT;
			FillTable5Data(xPos,yPos,str);
		}
	}
}

void CDlgBeamPathTable::SaveChangeValue()
{
	CTime ctTime = CTime::GetCurrentTime();	

	CString str, strDetail;
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CString strCurProcessLogFileName;
	strCurProcessLogFileName.Format(_T("ChangeBeamPath_%02d%02d"), ctTime.GetYear(), ctTime.GetMonth()) ;
	
	CStdioFile file;
	if (FALSE == file.Open(strPathName + strCurProcessLogFileName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
	{
		return;
	}

	TRY
	{
		file.SeekToEnd();

		strDetail = _T("----------------------------------------------------------------------------------------------\n");
		file.Write(strDetail, strDetail.GetLength());

		strDetail.Format(_T("%02d%02d%02d  %02d:%02d:%02d\n"),ctTime.GetYear(), ctTime.GetMonth(),ctTime.GetDay(), ctTime.GetHour(), ctTime.GetMinute(), ctTime.GetSecond());
		file.Write(strDetail, strDetail.GetLength());


		for(int i = 0 ;i <= m_nRepeatCount; i++)
		{
			if(gVariable.m_sgBeamPath.nInfoId[i] != gBeamPathINI.m_sBeampath.nInfoId[i])
			{
				str.Format(_T("%d Info ID : %d -> %d\n"), i,gBeamPathINI.m_sBeampath.nInfoId[i], gVariable.m_sgBeamPath.nInfoId[i]);
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.dInfoMaskSize[i] != gBeamPathINI.m_sBeampath.dInfoMaskSize[i])
			{
				str.Format(_T("%d Mask Size : %.3f -> %.3f\n"),  i,gBeamPathINI.m_sBeampath.dInfoMaskSize[i], gVariable.m_sgBeamPath.dInfoMaskSize[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.dBeamPathBetPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1[i])
			{
				str.Format(_T("%d BET1 Pos : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dBeamPathBetPos1[i], gVariable.m_sgBeamPath.dBeamPathBetPos1[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.dBeamPathBetPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2[i])
			{
				str.Format(_T("%d BET2 Pos : %.3f -> %.3f\n"),  i, gBeamPathINI.m_sBeampath.dBeamPathBetPos2[i], gVariable.m_sgBeamPath.dBeamPathBetPos2[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.dBeamPathBetPos3[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos3[i])
			{
				str.Format(_T("%d BET3 Pos : %.3f -> %.3f\n"),  i, gBeamPathINI.m_sBeampath.dBeamPathBetPos3[i], gVariable.m_sgBeamPath.dBeamPathBetPos3[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.dBeamPathBetPos4[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos4[i])
			{
				str.Format(_T("%d BET4 Pos : %.3f -> %.3f\n"),  i, gBeamPathINI.m_sBeampath.dBeamPathBetPos4[i], gVariable.m_sgBeamPath.dBeamPathBetPos4[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.nBeamPathMaskPos1[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[i])
			{
				str.Format(_T("%d M1 Pos : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[i], gVariable.m_sgBeamPath.nBeamPathMaskPos1[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.nBeamPathMaskPos2[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[i])
			{
				str.Format(_T("%d M2 Pos : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[i], gVariable.m_sgBeamPath.nBeamPathMaskPos2[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.nBeamPathMaskPos3[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[i])
			{
				str.Format(_T("%d M3 Pos : %d -> %d\n"),  i,gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[i], gVariable.m_sgBeamPath.nBeamPathMaskPos3[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.nBeamPathMaskPos4[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos4[i])
			{
				str.Format(_T("%d M4 Pos : %d -> %d\n"),  i,gBeamPathINI.m_sBeampath.nBeamPathMaskPos4[i], gVariable.m_sgBeamPath.nBeamPathMaskPos4[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.dBeamPathRotator[i] != gBeamPathINI.m_sBeampath.dBeamPathRotator[i])
			{
				str.Format(_T("%d Rot Pos : %.3f -> %.3f\n"),  i,gBeamPathINI.m_sBeampath.dBeamPathRotator[i], gVariable.m_sgBeamPath.dBeamPathRotator[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dBeamPathTopHat[i] != gBeamPathINI.m_sBeampath.dBeamPathTopHat[i])
			{
#ifdef __PKG_MODIFY__
				str.Format(_T("%d Collimator Pos : %.3f -> %.3f\n"),  i,gBeamPathINI.m_sBeampath.dBeamPathTopHat[i], gVariable.m_sgBeamPath.dBeamPathTopHat[i] );
#else
			str.Format(_T("%d TopHat Pos : %.3f -> %.3f\n"),  i,gBeamPathINI.m_sBeampath.dBeamPathTopHat[i], gVariable.m_sgBeamPath.dBeamPathTopHat[i] );
#endif
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[i] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[i])
			{
				str.Format(_T("%d A1 Pos : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[i], gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[i] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[i])
			{
				str.Format(_T("%d A2 Pos : %d -> %d\n"),  i,gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[i], gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i])
			{
				str.Format(_T("%d Z1 Pos : %.3f -> %.3f\n"), i,  gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i], gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i])
			{
				str.Format(_T("%d Z2 Pos : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i], gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.bBeamPathUseTophat[i] != gBeamPathINI.m_sBeampath.bBeamPathUseTophat[i])
			{
#ifdef __PKG_MODIFY__
				str.Format(_T("%d Collimator : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.bBeamPathUseTophat[i], gVariable.m_sgBeamPath.bBeamPathUseTophat[i] );
#else
				str.Format(_T("%d Tophat : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.bBeamPathUseTophat[i], gVariable.m_sgBeamPath.bBeamPathUseTophat[i] );
#endif
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.bBeamPathLaserPath[i] != gBeamPathINI.m_sBeampath.bBeamPathLaserPath[i])
			{
				str.Format(_T("%d Laser Path : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.bBeamPathLaserPath[i], gVariable.m_sgBeamPath.bBeamPathLaserPath[i] );
				file.Write(str, str.GetLength());
			}
			/*if(gVariable.m_sgBeamPath.bBeamPathUseAom[i] != gBeamPathINI.m_sBeampath.bBeamPathUseAom[i])
			{
				str.Format(_T("%d Use AOM : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.bBeamPathUseAom[i], gVariable.m_sgBeamPath.bBeamPathUseAom[i] );
				file.Write(str, str.GetLength());
			}*/
			if(gVariable.m_sgBeamPath.dPowOffsetDuty[i] != gBeamPathINI.m_sBeampath.dPowOffsetDuty[i])
			{
				str.Format(_T("%d Power Duty Offset : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dPowOffsetDuty[i], gVariable.m_sgBeamPath.dPowOffsetDuty[i] );
				file.Write(str, str.GetLength());
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&str));
			}
			if(gVariable.m_sgBeamPath.nSelectShot[i] != gBeamPathINI.m_sBeampath.nSelectShot[i])
			{
				str.Format(_T("%d Select Shot : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nSelectShot[i], gVariable.m_sgBeamPath.nSelectShot[i] );
				file.Write(str, str.GetLength());
			}

			if(gVariable.m_sgBeamPath.nPowCompensationFrequency[i] != gBeamPathINI.m_sBeampath.nPowCompensationFrequency[i])
			{
				str.Format(_T("%d Power Compensation Freq : %d -> %d\n"),  i, gBeamPathINI.m_sBeampath.nPowCompensationFrequency[i], gVariable.m_sgBeamPath.nPowCompensationFrequency[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dPowCompensationDuty[i] != gBeamPathINI.m_sBeampath.dPowCompensationDuty[i])
			{
				str.Format(_T("%d Power Compensation Duty : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dPowCompensationDuty[i], gVariable.m_sgBeamPath.dPowCompensationDuty[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dPowCompensationTargetMin[i] != gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[i])
			{
				str.Format(_T("%d Power Compensation Min : %.3f -> %.3f\n"), i,  gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[i], gVariable.m_sgBeamPath.dPowCompensationTargetMin[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dPowCompensationTargetMax[i] != gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[i])
			{
				str.Format(_T("%d Power Compensation Max : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[i], gVariable.m_sgBeamPath.dPowCompensationTargetMax[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dPowCompensationDutyOffset[i] != gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[i])
			{
				str.Format(_T("%d Power Compensation Offset : %.3f -> %.3f\n"), i,  gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[i], gVariable.m_sgBeamPath.dPowCompensationDutyOffset[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dPowCompensationTarget[i] != gBeamPathINI.m_sBeampath.dPowCompensationTarget[i])
			{
				str.Format(_T("%d Power Compensation Value : %.3f -> %.3f\n"), i,  gBeamPathINI.m_sBeampath.dPowCompensationTarget[i], gVariable.m_sgBeamPath.dPowCompensationTarget[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dPowCompensationTargetPercent[i] != gBeamPathINI.m_sBeampath.dPowCompensationTargetPercent[i])
			{
				str.Format(_T("%d Power Compensation Percent : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dPowCompensationTargetPercent[i], gVariable.m_sgBeamPath.dPowCompensationTargetPercent[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dScannerDuty[i] != gBeamPathINI.m_sBeampath.dScannerDuty[i])
			{
				str.Format(_T("%d Scanner Duty : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dScannerDuty[i], gVariable.m_sgBeamPath.dScannerDuty[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerTotalShot[i] != gBeamPathINI.m_sBeampath.nScannerTotalShot[i])
			{
				str.Format(_T("%d Scanner Total Shot : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerTotalShot[i], gVariable.m_sgBeamPath.nScannerTotalShot[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerVisionCam[i] != gBeamPathINI.m_sBeampath.nScannerVisionCam[i])
			{
				str.Format(_T("%d Scanner Cam : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerVisionCam[i], gVariable.m_sgBeamPath.nScannerVisionCam[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dScannerVisionModelSize[i] != gBeamPathINI.m_sBeampath.dScannerVisionModelSize[i])
			{
				str.Format(_T("%d Scanner Size : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dScannerVisionModelSize[i], gVariable.m_sgBeamPath.dScannerVisionModelSize[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dScannerAcceptScoreSize[i] != gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[i])
			{
				str.Format(_T("%d Scanner Accept Size : %.3f -> %.3f\n"), i,  gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[i], gVariable.m_sgBeamPath.dScannerAcceptScoreSize[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[i] != gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[i])
			{
				str.Format(_T("%d Scanner Accept Ratio : %.3f -> %.3f\n"),  i, gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[i], gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerPolarity[i] != gBeamPathINI.m_sBeampath.nScannerPolarity[i])
			{
				str.Format(_T("%d Scanner Polarity : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerPolarity[i], gVariable.m_sgBeamPath.nScannerPolarity[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dScannerBrightness[i] != gBeamPathINI.m_sBeampath.dScannerBrightness[i])
			{
				str.Format(_T("%d Scanner Bright : %.3f -> %.3f\n"), i,  gBeamPathINI.m_sBeampath.dScannerBrightness[i], gVariable.m_sgBeamPath.dScannerBrightness[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerRing[i] != gBeamPathINI.m_sBeampath.nScannerRing[i])
			{
				str.Format(_T("%d Scanner Ring : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerRing[i], gVariable.m_sgBeamPath.nScannerRing[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerCoaxial[i] != gBeamPathINI.m_sBeampath.nScannerCoaxial[i])
			{
				str.Format(_T("%d Scanner Coaxial : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerCoaxial[i], gVariable.m_sgBeamPath.nScannerCoaxial[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerIR[i] != gBeamPathINI.m_sBeampath.nScannerIR[i])
			{
				str.Format(_T("%d Scanner IR : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerIR[i], gVariable.m_sgBeamPath.nScannerIR[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerRing2[i] != gBeamPathINI.m_sBeampath.nScannerRing2[i])
			{
				str.Format(_T("%d Scanner Ring 2 : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerRing2[i], gVariable.m_sgBeamPath.nScannerRing2[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerCoaxial2[i] != gBeamPathINI.m_sBeampath.nScannerCoaxial2[i])
			{
				str.Format(_T("%d Scanner Coaxial 2 : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerCoaxial2[i], gVariable.m_sgBeamPath.nScannerCoaxial2[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nScannerIR2[i] != gBeamPathINI.m_sBeampath.nScannerIR2[i])
			{
				str.Format(_T("%d Scanner IR 2 : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nScannerIR2[i], gVariable.m_sgBeamPath.nScannerIR2[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nHoleVisionCam[i] != gBeamPathINI.m_sBeampath.nHoleVisionCam[i])
			{
				str.Format(_T("%d Hole Cam : %d -> %d\n"), i,  gBeamPathINI.m_sBeampath.nHoleVisionCam[i], gVariable.m_sgBeamPath.nHoleVisionCam[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dHoleVisionModelSize[i] != gBeamPathINI.m_sBeampath.dHoleVisionModelSize[i])
			{
				str.Format(_T("%d Hole Size : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dHoleVisionModelSize[i], gVariable.m_sgBeamPath.dHoleVisionModelSize[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dHoleAcceptScoreSize[i] != gBeamPathINI.m_sBeampath.dHoleAcceptScoreSize[i])
			{
				str.Format(_T("%d Hole Accept Size : %.3f -> %.3f\n"), i,  gBeamPathINI.m_sBeampath.dHoleAcceptScoreSize[i], gVariable.m_sgBeamPath.dHoleAcceptScoreSize[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[i] != gBeamPathINI.m_sBeampath.dHoleAcceptScoreRatio[i])
			{
				str.Format(_T("%d Hole Accept Ratio : %.3f -> %.3f\n"), i, gBeamPathINI.m_sBeampath.dHoleAcceptScoreRatio[i], gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nHolePolarity[i] != gBeamPathINI.m_sBeampath.nHolePolarity[i])
			{
				str.Format(_T("%d Hole Polarity : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nHolePolarity[i], gVariable.m_sgBeamPath.nHolePolarity[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.dHoleBrightness[i] != gBeamPathINI.m_sBeampath.dHoleBrightness[i])
			{
				str.Format(_T("%d Hole Brightn : %.3f -> %.3f\n"), i,  gBeamPathINI.m_sBeampath.dHoleBrightness[i], gVariable.m_sgBeamPath.dHoleBrightness[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nHoleRing[i] != gBeamPathINI.m_sBeampath.nHoleRing[i])
			{
				str.Format(_T("%d Hole Ring : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nHoleRing[i], gVariable.m_sgBeamPath.nHoleRing[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nHoleCoaxial[i] != gBeamPathINI.m_sBeampath.nHoleCoaxial[i])
			{
				str.Format(_T("%d Hole Coaxial : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nHoleCoaxial[i], gVariable.m_sgBeamPath.nHoleCoaxial[i] );
				file.Write(str, str.GetLength());
			}
			if(gVariable.m_sgBeamPath.nHoleIR[i] != gBeamPathINI.m_sBeampath.nHoleIR[i])
			{
				str.Format(_T("%d Hole IR : %d -> %d\n"), i, gBeamPathINI.m_sBeampath.nHoleIR[i], gVariable.m_sgBeamPath.nHoleIR[i] );
				file.Write(str, str.GetLength());
			}
			if(strcmp( gVariable.m_sgBeamPath.strBeamPathAscFile[i] , gBeamPathINI.m_sBeampath.strBeamPathAscFile[i]) !=0)
			{
				str.Format(_T("%d Hole Coaxial : %s -> %s\n"), i, gBeamPathINI.m_sBeampath.strBeamPathAscFile[i], gVariable.m_sgBeamPath.strBeamPathAscFile[i] );
				file.Write(str, str.GetLength());
			}
		}
	}
	CATCH (CFileException, e)
	{
		e->Delete();
			file.Close();
		return;
	}
	END_CATCH

	file.Close();
}
CString CDlgBeamPathTable::GetChangeValueStr()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));

	for(int i = 0 ;i <= m_nRepeatCount; i++)
	{
		if(
		gVariable.m_sgBeamPath.nInfoId[i] != gBeamPathINI.m_sBeampath.nInfoId[i]||
		gVariable.m_sgBeamPath.dInfoMaskSize[i] != gBeamPathINI.m_sBeampath.dInfoMaskSize[i]||

		gVariable.m_sgBeamPath.dBeamPathBetPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1[i]||
		gVariable.m_sgBeamPath.dBeamPathBetPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2[i]||
		gVariable.m_sgBeamPath.dBeamPathBetPos3[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos3[i]||
		gVariable.m_sgBeamPath.dBeamPathBetPos4[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos4[i]||
		gVariable.m_sgBeamPath.nBeamPathMaskPos1[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[i]||
		gVariable.m_sgBeamPath.nBeamPathMaskPos2[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[i]||
		gVariable.m_sgBeamPath.nBeamPathMaskPos3[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[i]||
		gVariable.m_sgBeamPath.nBeamPathMaskPos4[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos4[i]||

		gVariable.m_sgBeamPath.dBeamPathRotator[i] != gBeamPathINI.m_sBeampath.dBeamPathRotator[i]||
		gVariable.m_sgBeamPath.dBeamPathTopHat[i] != gBeamPathINI.m_sBeampath.dBeamPathTopHat[i]||


		gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[i] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[i]||
		gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[i] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[i]||
		gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i]||
		gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i]||
		gVariable.m_sgBeamPath.bBeamPathUseTophat[i] != gBeamPathINI.m_sBeampath.bBeamPathUseTophat[i]||
		gVariable.m_sgBeamPath.bBeamPathLaserPath[i] != gBeamPathINI.m_sBeampath.bBeamPathLaserPath[i]||
		//gVariable.m_sgBeamPath.bBeamPathUseAom[i] != gBeamPathINI.m_sBeampath.bBeamPathUseAom[i]||


		
	
		gVariable.m_sgBeamPath.dPowOffsetDuty[i] != gBeamPathINI.m_sBeampath.dPowOffsetDuty[i]||
	
		gVariable.m_sgBeamPath.nSelectShot[i] != gBeamPathINI.m_sBeampath.nSelectShot[i]||
		gVariable.m_sgBeamPath.nPowCompensationFrequency[i] != gBeamPathINI.m_sBeampath.nPowCompensationFrequency[i]||
		gVariable.m_sgBeamPath.dPowCompensationDuty[i] != gBeamPathINI.m_sBeampath.dPowCompensationDuty[i]||
		gVariable.m_sgBeamPath.dPowCompensationTargetMin[i] != gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[i]||
		gVariable.m_sgBeamPath.dPowCompensationTargetMax[i] != gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[i]||
		gVariable.m_sgBeamPath.dPowCompensationDutyOffset[i] != gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[i]||
		gVariable.m_sgBeamPath.dPowCompensationTarget[i] != gBeamPathINI.m_sBeampath.dPowCompensationTarget[i]||
		gVariable.m_sgBeamPath.dPowCompensationTargetPercent[i] != gBeamPathINI.m_sBeampath.dPowCompensationTargetPercent[i]||

		gVariable.m_sgBeamPath.dScannerDuty[i] != gBeamPathINI.m_sBeampath.dScannerDuty[i]||
		gVariable.m_sgBeamPath.nScannerTotalShot[i] != gBeamPathINI.m_sBeampath.nScannerTotalShot[i]||
		gVariable.m_sgBeamPath.nScannerVisionCam[i] != gBeamPathINI.m_sBeampath.nScannerVisionCam[i]||
		gVariable.m_sgBeamPath.dScannerVisionModelSize[i] != gBeamPathINI.m_sBeampath.dScannerVisionModelSize[i]||
		gVariable.m_sgBeamPath.dScannerAcceptScoreSize[i] != gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[i]||
		gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[i] != gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[i]||
		gVariable.m_sgBeamPath.nScannerPolarity[i] != gBeamPathINI.m_sBeampath.nScannerPolarity[i]||
		gVariable.m_sgBeamPath.dScannerBrightness[i] != gBeamPathINI.m_sBeampath.dScannerBrightness[i]||
		gVariable.m_sgBeamPath.nScannerRing[i] != gBeamPathINI.m_sBeampath.nScannerRing[i]||
		gVariable.m_sgBeamPath.nScannerCoaxial[i] != gBeamPathINI.m_sBeampath.nScannerCoaxial[i]||
		gVariable.m_sgBeamPath.nScannerRing2[i] != gBeamPathINI.m_sBeampath.nScannerRing2[i]||
		gVariable.m_sgBeamPath.nScannerCoaxial2[i] != gBeamPathINI.m_sBeampath.nScannerCoaxial2[i]||
		gVariable.m_sgBeamPath.nScannerIR[i] != gBeamPathINI.m_sBeampath.nScannerIR[i]||
		gVariable.m_sgBeamPath.nScannerIR2[i] != gBeamPathINI.m_sBeampath.nScannerIR2[i]||

		gVariable.m_sgBeamPath.nHoleVisionCam[i] != gBeamPathINI.m_sBeampath.nHoleVisionCam[i]||
		gVariable.m_sgBeamPath.dHoleVisionModelSize[i] != gBeamPathINI.m_sBeampath.dHoleVisionModelSize[i]||
		gVariable.m_sgBeamPath.dHoleAcceptScoreSize[i] != gBeamPathINI.m_sBeampath.dHoleAcceptScoreSize[i]||
		gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[i] != gBeamPathINI.m_sBeampath.dHoleAcceptScoreRatio[i]||
		gVariable.m_sgBeamPath.nHolePolarity[i] != gBeamPathINI.m_sBeampath.nHolePolarity[i]||
		gVariable.m_sgBeamPath.dHoleBrightness[i] != gBeamPathINI.m_sBeampath.dHoleBrightness[i] ||
		gVariable.m_sgBeamPath.nHoleRing[i] != gBeamPathINI.m_sBeampath.nHoleRing[i]||
		gVariable.m_sgBeamPath.nHoleCoaxial[i] != gBeamPathINI.m_sBeampath.nHoleCoaxial[i]||
		gVariable.m_sgBeamPath.nHoleIR[i] != gBeamPathINI.m_sBeampath.nHoleIR[i]
		)
		{
			strTemp.Format(_T("| %d : ( %.d, %.3f, %.3f, %.3f,%.3f,%.3f, %d, %d, %d, %d, %d, %d, %.3f, %.3f,%.3f, %.3f, %d, %d, %.1f, %.1f, %.3f, %.3f, %.1f, %.1f, %.3f ,%.1f , %.1f, %d, %.3f, %.3f, %.3f, %.3f, %.3f, %.3f, %d, %d, %.3f, %.3f, %.3f, %d,%.3f, %d, %d, %d, %.3f, %.3f, %.3f, %d, %.3f, %d, %d, %d"), 
				i,
				gVariable.m_sgBeamPath.nInfoId[i] ,
				gVariable.m_sgBeamPath.dInfoMaskSize[i] ,	
				
				gVariable.m_sgBeamPath.dBeamPathBetPos1[i],
				gVariable.m_sgBeamPath.dBeamPathBetPos2[i],
				gVariable.m_sgBeamPath.dBeamPathBetPos3[i],
				gVariable.m_sgBeamPath.dBeamPathBetPos4[i],
				gVariable.m_sgBeamPath.nBeamPathMaskPos1[i] ,
				gVariable.m_sgBeamPath.nBeamPathMaskPos2[i],
				gVariable.m_sgBeamPath.nBeamPathMaskPos3[i],
				gVariable.m_sgBeamPath.nBeamPathMaskPos4[i],
				gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[i],
				gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[i] ,

				gVariable.m_sgBeamPath.dBeamPathRotator[i] ,
				gVariable.m_sgBeamPath.dBeamPathTopHat[i] ,

				gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i] ,
				gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i] ,
				gVariable.m_sgBeamPath.bBeamPathUseTophat[i] ,	
				gVariable.m_sgBeamPath.bBeamPathLaserPath[i] ,	
				/*gVariable.m_sgBeamPath.bBeamPathUseAom[i] ,*/

				
				
				gVariable.m_sgBeamPath.dPowOffsetDuty[i] ,
				
				gVariable.m_sgBeamPath.nSelectShot[i] ,
				gVariable.m_sgBeamPath.nPowCompensationFrequency[i] ,
				gVariable.m_sgBeamPath.dPowCompensationDuty[i] ,		
				gVariable.m_sgBeamPath.dPowCompensationTargetMin[i] ,
				gVariable.m_sgBeamPath.dPowCompensationTargetMax[i], 
				gVariable.m_sgBeamPath.dPowCompensationDutyOffset[i] ,	
				gVariable.m_sgBeamPath.dPowCompensationTarget[i] ,
				gVariable.m_sgBeamPath.dPowCompensationTargetPercent[i], 
				
				gVariable.m_sgBeamPath.dScannerDuty[i] ,
				gVariable.m_sgBeamPath.nScannerTotalShot[i] ,
				gVariable.m_sgBeamPath.nScannerVisionCam[i] ,
				gVariable.m_sgBeamPath.dScannerVisionModelSize[i] ,
				gVariable.m_sgBeamPath.dScannerAcceptScoreSize[i] ,
				gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[i] ,
				gVariable.m_sgBeamPath.nScannerPolarity[i] ,
				gVariable.m_sgBeamPath.dScannerBrightness[i],
				gVariable.m_sgBeamPath.nScannerRing[i],
				gVariable.m_sgBeamPath.nScannerCoaxial[i],
				gVariable.m_sgBeamPath.nScannerRing2[i],
				gVariable.m_sgBeamPath.nScannerCoaxial2[i],
				gVariable.m_sgBeamPath.nScannerIR[i],
				gVariable.m_sgBeamPath.nScannerIR2[i],

				gVariable.m_sgBeamPath.nHoleVisionCam[i] ,
				gVariable.m_sgBeamPath.dHoleVisionModelSize[i] ,
				gVariable.m_sgBeamPath.dHoleAcceptScoreSize[i] ,
				gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[i] ,
				gVariable.m_sgBeamPath.nHolePolarity[i] ,
				gVariable.m_sgBeamPath.dHoleBrightness[i],
				gVariable.m_sgBeamPath.nHoleRing[i],
				gVariable.m_sgBeamPath.nHoleCoaxial[i],
				gVariable.m_sgBeamPath.nHoleIR[i]
		);
			strMessage += strTemp;
		}		

	}

	if(
		strcmp ( gVariable.m_sgBeamPath.strPowCompensationAomFile, gBeamPathINI.m_sBeampath.strPowCompensationAomFile) !=0||
		gVariable.m_sgBeamPath.dScannerJumpDelay != gBeamPathINI.m_sBeampath.dScannerJumpDelay||
		gVariable.m_sgBeamPath.nFixedMask!= gBeamPathINI.m_sBeampath.nFixedMask)
	{
		strTemp.Format(_T(", %d,%d "), gVariable.m_sgBeamPath.dScannerJumpDelay,
			gVariable.m_sgBeamPath.nFixedMask	);
		strMessage += strTemp;
	}

	for(int i = 0 ;i <= m_nRepeatCount; i++)
	{
		if(
			strcmp(gVariable.m_sgBeamPath.strInfoName[i], gBeamPathINI.m_sBeampath.strInfoName[i]) !=0 ||
			strcmp( gVariable.m_sgBeamPath.strBeamPathAscFile[i] , gBeamPathINI.m_sBeampath.strBeamPathAscFile[i]) !=0
		)
		{
			strTemp.Format(_T(",%s,%s "),gVariable.m_sgBeamPath.strBeamPathAscFile[i] , gVariable.m_sgBeamPath.strBeamPathAscFile[i]);
		}
		strMessage += strTemp;
		gVariable.m_bLPCRangeReset = TRUE;
	}

	if(0 != strMessage.Compare( _T("") ))
	{
		strTemp.Format(_T(" )"));
		strMessage += strTemp;
	}
	
	return strMessage;
}

void CDlgBeamPathTable::OnCheckAdd()
{
	//GetCurrentASC();
	BOOL bSelect= FALSE;
	m_nRepeatCount++;

	if(m_nRepeatCount >= BEAMPATH_COUNT)
	{
		m_nRepeatCount--;
		return ;
	}
	for(int i =0; i <BEAMPATH_COUNT; i++)
	{
		if(gVariable.m_sgBeamPath.bSelectedList[i])
			bSelect = TRUE;
	}
	if(bSelect)
		m_ClickID = TRUE;
	else
		m_ClickID = FALSE;

	gVariable.m_sgBeamPath.nInfoId[m_nRepeatCount] = m_nRepeatCount;

	if(TRUE == m_ClickID)
	{
//		int nCopyNo = GetIdNoToAddDel();
		int nCopyNo = 0;
		for(int i = 0; i < BEAMPATH_COUNT; i++)
		{
			if(gVariable.m_sgBeamPath.bSelectedList[i])
			{
				nCopyNo = i - 1;
				break;
			}
		}

		gVariable.m_sgBeamPath.dInfoMaskSize[m_nRepeatCount]			=	gVariable.m_sgBeamPath.dInfoMaskSize[nCopyNo];			
		gVariable.m_sgBeamPath.dBeamPathBetPos1[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathBetPos1[nCopyNo];
		gVariable.m_sgBeamPath.dBeamPathBetPos2[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathBetPos2[nCopyNo];
		gVariable.m_sgBeamPath.dBeamPathBetPos3[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathBetPos3[nCopyNo];
		gVariable.m_sgBeamPath.dBeamPathBetPos4[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathBetPos4[nCopyNo];
		gVariable.m_sgBeamPath.nBeamPathMaskPos1[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos1[nCopyNo];
		gVariable.m_sgBeamPath.nBeamPathMaskPos2[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos2[nCopyNo];
		gVariable.m_sgBeamPath.nBeamPathMaskPos3[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos3[nCopyNo];
		gVariable.m_sgBeamPath.nBeamPathMaskPos4[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos4[nCopyNo];


		gVariable.m_sgBeamPath.dBeamPathRotator[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathRotator[nCopyNo];
		gVariable.m_sgBeamPath.dBeamPathTopHat[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathTopHat[nCopyNo];

		gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[m_nRepeatCount]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[nCopyNo];
		gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[m_nRepeatCount]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[nCopyNo];
		gVariable.m_sgBeamPath.dBeamPathZAxisPos1[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos1[nCopyNo];
		gVariable.m_sgBeamPath.dBeamPathZAxisPos2[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos2[nCopyNo]; 
		gVariable.m_sgBeamPath.bBeamPathUseTophat[m_nRepeatCount]		=	gVariable.m_sgBeamPath.bBeamPathUseTophat[nCopyNo];
		gVariable.m_sgBeamPath.bBeamPathLaserPath[m_nRepeatCount]		=   gVariable.m_sgBeamPath.bBeamPathLaserPath[nCopyNo];
		//gVariable.m_sgBeamPath.bBeamPathUseAom[m_nRepeatCount]		=   gVariable.m_sgBeamPath.bBeamPathUseAom[nCopyNo];


		
		gVariable.m_sgBeamPath.dPowOffsetDuty[m_nRepeatCount]			=	gVariable.m_sgBeamPath.dPowOffsetDuty[nCopyNo];

		gVariable.m_sgBeamPath.nSelectShot[m_nRepeatCount] = gVariable.m_sgBeamPath.nSelectShot[nCopyNo];

		gVariable.m_sgBeamPath.nPowCompensationFrequency[m_nRepeatCount] = gVariable.m_sgBeamPath.nPowCompensationFrequency[nCopyNo];
		gVariable.m_sgBeamPath.dPowCompensationDuty[m_nRepeatCount]	 =	gVariable.m_sgBeamPath.dPowCompensationDuty[nCopyNo];
		gVariable.m_sgBeamPath.dPowCompensationTargetMin[m_nRepeatCount] = gVariable.m_sgBeamPath.dPowCompensationTargetMin[nCopyNo];
		gVariable.m_sgBeamPath.dPowCompensationTargetMax[m_nRepeatCount] = gVariable.m_sgBeamPath.dPowCompensationTargetMax[nCopyNo];
		gVariable.m_sgBeamPath.dPowCompensationDutyOffset[m_nRepeatCount] =gVariable.m_sgBeamPath.dPowCompensationDutyOffset[nCopyNo];
		gVariable.m_sgBeamPath.dPowCompensationTarget[m_nRepeatCount] = gVariable.m_sgBeamPath.dPowCompensationTarget[nCopyNo];
		gVariable.m_sgBeamPath.dPowCompensationTargetPercent[m_nRepeatCount] = gVariable.m_sgBeamPath.dPowCompensationTargetPercent[nCopyNo];
		gVariable.m_sgBeamPath.dScannerDuty[m_nRepeatCount]			=	gVariable.m_sgBeamPath.dScannerDuty[nCopyNo];

		gVariable.m_sgBeamPath.dScannerFrq[m_nRepeatCount]			=	gVariable.m_sgBeamPath.dScannerFrq[nCopyNo];


		gVariable.m_sgBeamPath.nScannerTotalShot[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerTotalShot[nCopyNo];
		gVariable.m_sgBeamPath.nScannerVisionCam[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerVisionCam[nCopyNo] ;
		gVariable.m_sgBeamPath.dScannerVisionModelSize[m_nRepeatCount] =	gVariable.m_sgBeamPath.dScannerVisionModelSize[nCopyNo];
		gVariable.m_sgBeamPath.nScannerPolarity[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerPolarity[nCopyNo];
		gVariable.m_sgBeamPath.dScannerAcceptScoreSize[m_nRepeatCount] =	gVariable.m_sgBeamPath.dScannerAcceptScoreSize[nCopyNo];
		gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[m_nRepeatCount] =	gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[nCopyNo];
		gVariable.m_sgBeamPath.dScannerContrast[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dScannerContrast[nCopyNo];
		gVariable.m_sgBeamPath.dScannerBrightness[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dScannerBrightness[nCopyNo];
		gVariable.m_sgBeamPath.nScannerRing[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerRing[nCopyNo];
		gVariable.m_sgBeamPath.nScannerCoaxial[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerCoaxial[nCopyNo];
		gVariable.m_sgBeamPath.nScannerIR[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerIR[nCopyNo];


		gVariable.m_sgBeamPath.nScannerRing2[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerRing2[nCopyNo];
		gVariable.m_sgBeamPath.nScannerCoaxial2[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerCoaxial2[nCopyNo];
		gVariable.m_sgBeamPath.nScannerIR2[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerIR2[nCopyNo];

		gVariable.m_sgBeamPath.nScannerRing3[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerRing3[nCopyNo];
		gVariable.m_sgBeamPath.nScannerCoaxial3[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerCoaxial3[nCopyNo];
		gVariable.m_sgBeamPath.nScannerIR3[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerIR3[nCopyNo];

		gVariable.m_sgBeamPath.nScannerRing4[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerRing4[nCopyNo];
		gVariable.m_sgBeamPath.nScannerCoaxial4[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerCoaxial4[nCopyNo];
		gVariable.m_sgBeamPath.nScannerIR4[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerIR4[nCopyNo];



		
		gVariable.m_sgBeamPath.nHoleVisionCam[m_nRepeatCount]			=	gVariable.m_sgBeamPath.nHoleVisionCam[nCopyNo] ;
		gVariable.m_sgBeamPath.dHoleVisionModelSize[m_nRepeatCount]	=	gVariable.m_sgBeamPath.dHoleVisionModelSize[nCopyNo];
		gVariable.m_sgBeamPath.nHolePolarity[m_nRepeatCount]			=	gVariable.m_sgBeamPath.nHolePolarity[nCopyNo];
		gVariable.m_sgBeamPath.dHoleAcceptScoreSize[m_nRepeatCount]	=	gVariable.m_sgBeamPath.dHoleAcceptScoreSize[nCopyNo];
		gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[m_nRepeatCount]	=	gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[nCopyNo];
		gVariable.m_sgBeamPath.dHoleContrast[m_nRepeatCount]			=	gVariable.m_sgBeamPath.dHoleContrast[nCopyNo];
		gVariable.m_sgBeamPath.dHoleBrightness[m_nRepeatCount]			=	gVariable.m_sgBeamPath.dHoleBrightness[nCopyNo];
		gVariable.m_sgBeamPath.nHoleRing[m_nRepeatCount]			=	gVariable.m_sgBeamPath.nHoleRing[nCopyNo];
		gVariable.m_sgBeamPath.nHoleCoaxial[m_nRepeatCount]			=	gVariable.m_sgBeamPath.nHoleCoaxial[nCopyNo];
		gVariable.m_sgBeamPath.nHoleIR[m_nRepeatCount]			=	gVariable.m_sgBeamPath.nHoleIR[nCopyNo];

		strcpy_s(gVariable.m_sgBeamPath.strInfoName[m_nRepeatCount],gVariable.m_sgBeamPath.strInfoName[nCopyNo]);
		strcpy_s( gVariable.m_sgBeamPath.strBeamPathAscFile[m_nRepeatCount] ,gVariable.m_sgBeamPath.strBeamPathAscFile[nCopyNo]);

//		m_ClickID = FALSE; //111021
	}
	else
	{
		gVariable.m_sgBeamPath.dInfoMaskSize[m_nRepeatCount]			=	gVariable.m_sgBeamPath.dInfoMaskSize[m_nRepeatCount-1];			
		gVariable.m_sgBeamPath.dBeamPathBetPos1[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathBetPos1[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dBeamPathBetPos2[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathBetPos2[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dBeamPathBetPos3[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathBetPos3[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dBeamPathBetPos4[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathBetPos4[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nBeamPathMaskPos1[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos1[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nBeamPathMaskPos2[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos2[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nBeamPathMaskPos3[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos3[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nBeamPathMaskPos4[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos4[m_nRepeatCount-1];

		gVariable.m_sgBeamPath.dBeamPathRotator[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathRotator[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dBeamPathTopHat[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathTopHat[m_nRepeatCount-1];

		gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[m_nRepeatCount]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[m_nRepeatCount]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dBeamPathZAxisPos1[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos1[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dBeamPathZAxisPos2[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos2[m_nRepeatCount-1]; 
		gVariable.m_sgBeamPath.bBeamPathUseTophat[m_nRepeatCount]		=	gVariable.m_sgBeamPath.bBeamPathUseTophat[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.bBeamPathLaserPath[m_nRepeatCount]		=   gVariable.m_sgBeamPath.bBeamPathLaserPath[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dPowOffsetDuty[m_nRepeatCount]			=	gVariable.m_sgBeamPath.dPowOffsetDuty[m_nRepeatCount-1];
		//gVariable.m_sgBeamPath.bBeamPathUseAom[m_nRepeatCount]		=   gVariable.m_sgBeamPath.bBeamPathUseAom[m_nRepeatCount-1];
		
		
		gVariable.m_sgBeamPath.nSelectShot[m_nRepeatCount] = gVariable.m_sgBeamPath.nSelectShot[m_nRepeatCount-1];

		gVariable.m_sgBeamPath.nPowCompensationFrequency[m_nRepeatCount] = gVariable.m_sgBeamPath.nPowCompensationFrequency[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dPowCompensationDuty[m_nRepeatCount]	 =	gVariable.m_sgBeamPath.dPowCompensationDuty[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dPowCompensationTargetMin[m_nRepeatCount] = gVariable.m_sgBeamPath.dPowCompensationTargetMin[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dPowCompensationTargetMax[m_nRepeatCount] = gVariable.m_sgBeamPath.dPowCompensationTargetMax[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dPowCompensationTarget[m_nRepeatCount] = gVariable.m_sgBeamPath.dPowCompensationTarget[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dPowCompensationTargetPercent[m_nRepeatCount] = gVariable.m_sgBeamPath.dPowCompensationTargetPercent[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dPowCompensationDutyOffset[m_nRepeatCount] =gVariable.m_sgBeamPath.dPowCompensationDutyOffset[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dScannerDuty[m_nRepeatCount]			=	gVariable.m_sgBeamPath.dScannerDuty[m_nRepeatCount-1];

		gVariable.m_sgBeamPath.dScannerFrq[m_nRepeatCount]			=	gVariable.m_sgBeamPath.dScannerFrq[m_nRepeatCount-1];
	
		gVariable.m_sgBeamPath.nScannerTotalShot[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerTotalShot[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nScannerVisionCam[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerVisionCam[m_nRepeatCount-1] ;
		gVariable.m_sgBeamPath.dScannerVisionModelSize[m_nRepeatCount] =	gVariable.m_sgBeamPath.dScannerVisionModelSize[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nScannerPolarity[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerPolarity[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dScannerAcceptScoreSize[m_nRepeatCount] =	gVariable.m_sgBeamPath.dScannerAcceptScoreSize[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[m_nRepeatCount] =	gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dScannerContrast[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dScannerContrast[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dScannerBrightness[m_nRepeatCount]		=	gVariable.m_sgBeamPath.dScannerBrightness[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nScannerRing[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerRing[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nScannerCoaxial[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerCoaxial[m_nRepeatCount-1];

		gVariable.m_sgBeamPath.nScannerIR[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerIR[m_nRepeatCount-1];


		gVariable.m_sgBeamPath.nScannerRing2[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerRing2[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nScannerCoaxial2[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerCoaxial2[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nScannerIR2[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerIR2[m_nRepeatCount-1];

		gVariable.m_sgBeamPath.nScannerRing3[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerRing3[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nScannerCoaxial3[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerCoaxial3[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nScannerIR3[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerIR3[m_nRepeatCount-1];

		gVariable.m_sgBeamPath.nScannerRing4[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerRing4[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nScannerCoaxial4[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerCoaxial4[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nScannerIR4[m_nRepeatCount]		=	gVariable.m_sgBeamPath.nScannerIR4[m_nRepeatCount-1];



		gVariable.m_sgBeamPath.nHoleVisionCam[m_nRepeatCount]			=	gVariable.m_sgBeamPath.nHoleVisionCam[m_nRepeatCount-1] ;
		gVariable.m_sgBeamPath.dHoleVisionModelSize[m_nRepeatCount]	=	gVariable.m_sgBeamPath.dHoleVisionModelSize[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nHolePolarity[m_nRepeatCount]			=	gVariable.m_sgBeamPath.nHolePolarity[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dHoleAcceptScoreSize[m_nRepeatCount]	=	gVariable.m_sgBeamPath.dHoleAcceptScoreSize[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[m_nRepeatCount]	=	gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dHoleContrast[m_nRepeatCount]			=	gVariable.m_sgBeamPath.dHoleContrast[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.dHoleBrightness[m_nRepeatCount]			=	gVariable.m_sgBeamPath.dHoleBrightness[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nHoleRing[m_nRepeatCount]			=	gVariable.m_sgBeamPath.nHoleRing[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nHoleCoaxial[m_nRepeatCount]			=	gVariable.m_sgBeamPath.nHoleCoaxial[m_nRepeatCount-1];
		gVariable.m_sgBeamPath.nHoleIR[m_nRepeatCount]			=	gVariable.m_sgBeamPath.nHoleIR[m_nRepeatCount-1];

		strcpy_s(gVariable.m_sgBeamPath.strInfoName[m_nRepeatCount],gVariable.m_sgBeamPath.strInfoName[m_nRepeatCount-1]);
		strcpy_s( gVariable.m_sgBeamPath.strBeamPathAscFile[m_nRepeatCount] ,gVariable.m_sgBeamPath.strBeamPathAscFile[m_nRepeatCount-1]);
	}

	OnCheckRefresh();
}

void CDlgBeamPathTable::OnCheckDel()
{
	if(m_bCheckBox[1])
		GetCurrentASC();
	BOOL bSelect = FALSE;
	if(m_posClicked.y == -1)
		return ;

	for(int i =0; i <BEAMPATH_COUNT; i++)
	{
		if(gVariable.m_sgBeamPath.bSelectedList[i])
			bSelect = TRUE;
	}
	if(bSelect)
		m_ClickID = TRUE;
	else
		m_ClickID = FALSE;

	if(FALSE == m_ClickID)
	{
		AfxMessageBox(_T("Please select the items you want to delete."));
		return ;
	}

	if(m_nRepeatCount < 0)
	{
		return ;
	}

	for(int i = 0; i <BEAMPATH_COUNT; i++)
	{
//		int nDelNo = GetIdNoToAddDel();
		int nDelNo;
		if(gVariable.m_sgBeamPath.bSelectedList[i])
			nDelNo = i - 1;
		else 
			continue;
			
		
		// 	CString str;									/// �����Ҵ� yes,no ����
		// 	str.Format(_T("%d �׸��� �����մϴ� "),nDelNo);
		// 
		// 	if (AfxMessageBox(str,MB_YESNO,NULL) ==  IDYES)
		// 	{
		CopyFromOriginaltoTemp(nDelNo,m_nRepeatCount);
		m_nRepeatCount--;	
		
		CopyFromTempToOriginal();
		OnCheckRefresh();
		InitDataStruct();		// �ӽ� ����ü �ʱ�ȭ 
		//	}
	}

	for(int i = 0; i <BEAMPATH_COUNT; i++) //���û����� ���������� ������ 
	{
		gVariable.m_sgBeamPath.bSelectedList[i] = FALSE;
	}

	m_ClickID = FALSE;
}

//del �� ����׸��� �Ѵٰ� �Ͽ��� �� 
//ó�� ����� ������ �׸� ���� ���� ������  temp ����������-> ������ ������ �������� ������ ������ ���� temp ������ ����->
// ������������ ������ ���� ������ �ʱ�ȭ 
void CDlgBeamPathTable::CopyFromOriginaltoTemp(int nSelectNo, int RepeatNo)
{
	int i = 0;

	for(i = 0 ;i < nSelectNo; i++)
	{
		m_sTempBeamPath.dInfoMaskSize[i]			=	gVariable.m_sgBeamPath.dInfoMaskSize[i];			
		m_sTempBeamPath.dBeamPathBetPos1[i]			=	gVariable.m_sgBeamPath.dBeamPathBetPos1[i];
		m_sTempBeamPath.dBeamPathBetPos2[i]			=	gVariable.m_sgBeamPath.dBeamPathBetPos2[i];
		m_sTempBeamPath.dBeamPathBetPos3[i]			=	gVariable.m_sgBeamPath.dBeamPathBetPos3[i];
		m_sTempBeamPath.dBeamPathBetPos4[i]			=	gVariable.m_sgBeamPath.dBeamPathBetPos4[i];
		m_sTempBeamPath.nBeamPathMaskPos1[i]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos1[i];
		m_sTempBeamPath.nBeamPathMaskPos2[i]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos2[i];
		m_sTempBeamPath.nBeamPathMaskPos3[i]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos3[i];
		m_sTempBeamPath.nBeamPathMaskPos4[i]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos4[i];

		m_sTempBeamPath.dBeamPathRotator[i]		=	gVariable.m_sgBeamPath.dBeamPathRotator[i];
		m_sTempBeamPath.dBeamPathTopHat[i]		=	gVariable.m_sgBeamPath.dBeamPathTopHat[i];


		m_sTempBeamPath.nBeamPathAttenuatePos1[i]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[i];
		m_sTempBeamPath.nBeamPathAttenuatePos2[i]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[i];
		m_sTempBeamPath.dBeamPathZAxisPos1[i]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i];
		m_sTempBeamPath.dBeamPathZAxisPos2[i]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i]; 
		m_sTempBeamPath.bBeamPathUseTophat[i]		=	gVariable.m_sgBeamPath.bBeamPathUseTophat[i];
		m_sTempBeamPath.bBeamPathLaserPath[i]		=	gVariable.m_sgBeamPath.bBeamPathLaserPath[i];
		//m_sTempBeamPath.bBeamPathUseAom[i]		=	gVariable.m_sgBeamPath.bBeamPathUseAom[i];

		

		m_sTempBeamPath.dPowOffsetDuty[i]			=	gVariable.m_sgBeamPath.dPowOffsetDuty[i];
		
		
		m_sTempBeamPath.nSelectShot[i] = gVariable.m_sgBeamPath.nSelectShot[i];
		m_sTempBeamPath.nPowCompensationFrequency[i] = gVariable.m_sgBeamPath.nPowCompensationFrequency[i];
		m_sTempBeamPath.dPowCompensationDuty[i]		 =	gVariable.m_sgBeamPath.dPowCompensationDuty[i];
		m_sTempBeamPath.dPowCompensationTargetMin[i] = gVariable.m_sgBeamPath.dPowCompensationTargetMin[i];
		m_sTempBeamPath.dPowCompensationTargetMax[i] = gVariable.m_sgBeamPath.dPowCompensationTargetMax[i];
		m_sTempBeamPath.dPowCompensationDutyOffset[i] =gVariable.m_sgBeamPath.dPowCompensationDutyOffset[i];
		m_sTempBeamPath.dPowCompensationTarget[i] = gVariable.m_sgBeamPath.dPowCompensationTarget[i];
		m_sTempBeamPath.dPowCompensationTargetPercent[i] = gVariable.m_sgBeamPath.dPowCompensationTargetPercent[i];
		m_sTempBeamPath.dScannerDuty[i]				=	gVariable.m_sgBeamPath.dScannerDuty[i];

		m_sTempBeamPath.dScannerFrq[i]				=	gVariable.m_sgBeamPath.dScannerFrq[i];

		m_sTempBeamPath.nScannerTotalShot[i]		=	gVariable.m_sgBeamPath.nScannerTotalShot[i];
		m_sTempBeamPath.nScannerVisionCam[i]		=	gVariable.m_sgBeamPath.nScannerVisionCam[i] ;
		m_sTempBeamPath.dScannerVisionModelSize[i]	=	gVariable.m_sgBeamPath.dScannerVisionModelSize[i];
		m_sTempBeamPath.nScannerPolarity[i]			=	gVariable.m_sgBeamPath.nScannerPolarity[i];
		m_sTempBeamPath.dScannerAcceptScoreSize[i]	=	gVariable.m_sgBeamPath.dScannerAcceptScoreSize[i];
		m_sTempBeamPath.dScannerAcceptScoreRatio[i] =	gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[i];
		m_sTempBeamPath.dScannerContrast[i]			=	gVariable.m_sgBeamPath.dScannerContrast[i];
		m_sTempBeamPath.dScannerBrightness[i]		=	gVariable.m_sgBeamPath.dScannerBrightness[i];
		m_sTempBeamPath.nScannerRing[i]			=	gVariable.m_sgBeamPath.nScannerRing[i];
		m_sTempBeamPath.nScannerCoaxial[i]		=	gVariable.m_sgBeamPath.nScannerCoaxial[i];
				m_sTempBeamPath.nScannerIR[i]		=	gVariable.m_sgBeamPath.nScannerIR[i];
		m_sTempBeamPath.nScannerRing2[i]			=	gVariable.m_sgBeamPath.nScannerRing2[i];
		m_sTempBeamPath.nScannerCoaxial2[i]		=	gVariable.m_sgBeamPath.nScannerCoaxial2[i];
		m_sTempBeamPath.nScannerIR2[i]		=	gVariable.m_sgBeamPath.nScannerIR2[i];

		m_sTempBeamPath.nScannerRing3[i]			=	gVariable.m_sgBeamPath.nScannerRing3[i];
		m_sTempBeamPath.nScannerCoaxial3[i]		=	gVariable.m_sgBeamPath.nScannerCoaxial3[i];
		m_sTempBeamPath.nScannerIR3[i]		=	gVariable.m_sgBeamPath.nScannerIR3[i];

		m_sTempBeamPath.nScannerRing4[i]			=	gVariable.m_sgBeamPath.nScannerRing4[i];
		m_sTempBeamPath.nScannerCoaxial4[i]		=	gVariable.m_sgBeamPath.nScannerCoaxial4[i];
		m_sTempBeamPath.nScannerIR4[i]		=	gVariable.m_sgBeamPath.nScannerIR4[i];



		m_sTempBeamPath.nHoleVisionCam[i]			=	gVariable.m_sgBeamPath.nHoleVisionCam[i] ;
		m_sTempBeamPath.dHoleVisionModelSize[i]		=	gVariable.m_sgBeamPath.dHoleVisionModelSize[i];
		m_sTempBeamPath.nHolePolarity[i]			=	gVariable.m_sgBeamPath.nHolePolarity[i];
		m_sTempBeamPath.dHoleAcceptScoreSize[i]		=	gVariable.m_sgBeamPath.dHoleAcceptScoreSize[i];
		m_sTempBeamPath.dHoleAcceptScoreRatio[i]	=	gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[i];
		m_sTempBeamPath.dHoleContrast[i]			=	gVariable.m_sgBeamPath.dHoleContrast[i];
		m_sTempBeamPath.dHoleBrightness[i]			=	gVariable.m_sgBeamPath.dHoleBrightness[i];
		m_sTempBeamPath.nHoleRing[i]			=	gVariable.m_sgBeamPath.nHoleRing[i];
		m_sTempBeamPath.nHoleCoaxial[i]			=	gVariable.m_sgBeamPath.nHoleCoaxial[i];
		m_sTempBeamPath.nHoleIR[i]			=	gVariable.m_sgBeamPath.nHoleIR[i];

		strcpy_s(m_sTempBeamPath.strInfoName[i],gVariable.m_sgBeamPath.strInfoName[i]);
		strcpy_s( m_sTempBeamPath.strBeamPathAscFile[i] ,gVariable.m_sgBeamPath.strBeamPathAscFile[i]);
	}

	for(i = nSelectNo + 1; i <= RepeatNo;i++)
	{
		m_sTempBeamPath.dInfoMaskSize[i-1]			=	gVariable.m_sgBeamPath.dInfoMaskSize[i];			
		m_sTempBeamPath.dBeamPathBetPos1[i-1]		=	gVariable.m_sgBeamPath.dBeamPathBetPos1[i];
		m_sTempBeamPath.dBeamPathBetPos2[i-1]		=	gVariable.m_sgBeamPath.dBeamPathBetPos2[i];
		m_sTempBeamPath.dBeamPathBetPos3[i-1]		=	gVariable.m_sgBeamPath.dBeamPathBetPos3[i];
		m_sTempBeamPath.dBeamPathBetPos4[i-1]		=	gVariable.m_sgBeamPath.dBeamPathBetPos4[i];
		m_sTempBeamPath.nBeamPathMaskPos1[i-1]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos1[i];
		m_sTempBeamPath.nBeamPathMaskPos2[i-1]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos2[i];
		m_sTempBeamPath.nBeamPathMaskPos3[i-1]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos3[i];
		m_sTempBeamPath.nBeamPathMaskPos4[i-1]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos4[i];

		m_sTempBeamPath.dBeamPathRotator[i-1]		=	gVariable.m_sgBeamPath.dBeamPathRotator[i];
		m_sTempBeamPath.dBeamPathTopHat[i-1]		=	gVariable.m_sgBeamPath.dBeamPathTopHat[i];

		m_sTempBeamPath.nBeamPathAttenuatePos1[i-1]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[i];
		m_sTempBeamPath.nBeamPathAttenuatePos2[i-1]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[i];
		m_sTempBeamPath.dBeamPathZAxisPos1[i-1]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i];
		m_sTempBeamPath.dBeamPathZAxisPos2[i-1]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i]; 
		m_sTempBeamPath.bBeamPathUseTophat[i-1]		=	gVariable.m_sgBeamPath.bBeamPathUseTophat[i];	
		m_sTempBeamPath.bBeamPathLaserPath[i-1]		=	gVariable.m_sgBeamPath.bBeamPathLaserPath[i];
		//m_sTempBeamPath.bBeamPathUseAom[i-1]		=	gVariable.m_sgBeamPath.bBeamPathUseAom[i];

		
		m_sTempBeamPath.dPowOffsetDuty[i-1]			=	gVariable.m_sgBeamPath.dPowOffsetDuty[i];
	
		
		
		m_sTempBeamPath.nSelectShot[i-1]	= gVariable.m_sgBeamPath.nSelectShot[i];
		m_sTempBeamPath.nPowCompensationFrequency[i-1]	= gVariable.m_sgBeamPath.nPowCompensationFrequency[i];
		m_sTempBeamPath.dPowCompensationDuty[i-1]		=	gVariable.m_sgBeamPath.dPowCompensationDuty[i];
		m_sTempBeamPath.dPowCompensationTargetMin[i-1]	= gVariable.m_sgBeamPath.dPowCompensationTargetMin[i];
		m_sTempBeamPath.dPowCompensationTargetMax[i-1]	= gVariable.m_sgBeamPath.dPowCompensationTargetMax[i];
		m_sTempBeamPath.dPowCompensationDutyOffset[i-1] =gVariable.m_sgBeamPath.dPowCompensationDutyOffset[i];
		m_sTempBeamPath.dPowCompensationTarget[i-1]	= gVariable.m_sgBeamPath.dPowCompensationTarget[i];
		m_sTempBeamPath.dPowCompensationTargetPercent[i-1]	= gVariable.m_sgBeamPath.dPowCompensationTargetPercent[i];
		m_sTempBeamPath.dScannerDuty[i-1]				=	gVariable.m_sgBeamPath.dScannerDuty[i];

		m_sTempBeamPath.dScannerFrq[i-1]				=	gVariable.m_sgBeamPath.dScannerFrq[i];

		m_sTempBeamPath.nScannerTotalShot[i-1]			=	gVariable.m_sgBeamPath.nScannerTotalShot[i];
		m_sTempBeamPath.nScannerVisionCam[i-1]			=	gVariable.m_sgBeamPath.nScannerVisionCam[i] ;
		m_sTempBeamPath.dScannerVisionModelSize[i-1]	=	gVariable.m_sgBeamPath.dScannerVisionModelSize[i];
		m_sTempBeamPath.nScannerPolarity[i-1]			=	gVariable.m_sgBeamPath.nScannerPolarity[i];
		m_sTempBeamPath.dScannerAcceptScoreSize[i-1]	=	gVariable.m_sgBeamPath.dScannerAcceptScoreSize[i];
		m_sTempBeamPath.dScannerAcceptScoreRatio[i-1]	=	gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[i];
		m_sTempBeamPath.dScannerContrast[i-1]			=	gVariable.m_sgBeamPath.dScannerContrast[i];
		m_sTempBeamPath.dScannerBrightness[i-1]			=	gVariable.m_sgBeamPath.dScannerBrightness[i];
		m_sTempBeamPath.nScannerRing[i-1]				=	gVariable.m_sgBeamPath.nScannerRing[i];
		m_sTempBeamPath.nScannerCoaxial[i-1]			=	gVariable.m_sgBeamPath.nScannerCoaxial[i];

		m_sTempBeamPath.nScannerIR[i-1]					=	gVariable.m_sgBeamPath.nScannerIR[i];

		m_sTempBeamPath.nScannerRing2[i-1]				=	gVariable.m_sgBeamPath.nScannerRing2[i];
		m_sTempBeamPath.nScannerCoaxial2[i-1]			=	gVariable.m_sgBeamPath.nScannerCoaxial2[i];
		m_sTempBeamPath.nScannerIR2[i-1]				=	gVariable.m_sgBeamPath.nScannerIR2[i];

		m_sTempBeamPath.nScannerRing3[i-1]				=	gVariable.m_sgBeamPath.nScannerRing3[i];
		m_sTempBeamPath.nScannerCoaxial3[i-1]			=	gVariable.m_sgBeamPath.nScannerCoaxial3[i];
		m_sTempBeamPath.nScannerIR3[i-1]				=	gVariable.m_sgBeamPath.nScannerIR3[i];

		m_sTempBeamPath.nScannerRing4[i-1]				=	gVariable.m_sgBeamPath.nScannerRing4[i];
		m_sTempBeamPath.nScannerCoaxial4[i-1]			=	gVariable.m_sgBeamPath.nScannerCoaxial4[i];
		m_sTempBeamPath.nScannerIR4[i-1]				=	gVariable.m_sgBeamPath.nScannerIR4[i];



		m_sTempBeamPath.nHoleVisionCam[i-1]				=	gVariable.m_sgBeamPath.nHoleVisionCam[i] ;
		m_sTempBeamPath.dHoleVisionModelSize[i-1]		=	gVariable.m_sgBeamPath.dHoleVisionModelSize[i];
		m_sTempBeamPath.nHolePolarity[i-1]				=	gVariable.m_sgBeamPath.nHolePolarity[i];
		m_sTempBeamPath.dHoleAcceptScoreSize[i-1]		=	gVariable.m_sgBeamPath.dHoleAcceptScoreSize[i];
		m_sTempBeamPath.dHoleAcceptScoreRatio[i-1]		=	gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[i];
		m_sTempBeamPath.dHoleContrast[i-1]				=	gVariable.m_sgBeamPath.dHoleContrast[i];
		m_sTempBeamPath.dHoleBrightness[i-1]			=	gVariable.m_sgBeamPath.dHoleBrightness[i];
		m_sTempBeamPath.nHoleRing[i-1]					=	gVariable.m_sgBeamPath.nHoleRing[i];
		m_sTempBeamPath.nHoleCoaxial[i-1]				=	gVariable.m_sgBeamPath.nHoleCoaxial[i];
		m_sTempBeamPath.nHoleIR[i-1]				=	gVariable.m_sgBeamPath.nHoleIR[i];

		strcpy_s(m_sTempBeamPath.strInfoName[i-1],gVariable.m_sgBeamPath.strInfoName[i]);
		strcpy_s( m_sTempBeamPath.strBeamPathAscFile[i-1] ,gVariable.m_sgBeamPath.strBeamPathAscFile[i]);
	}


	// ���� �����Ͱ� ��ĭ�� ���� �ö󰬱� ������ ������ �� ������ ���� �ʱ�ȭ �Ѵ�. 
	gVariable.m_sgBeamPath.nInfoId[RepeatNo] = i;
	gVariable.m_sgBeamPath.dInfoMaskSize[RepeatNo]= 0;
	
	gVariable.m_sgBeamPath.dBeamPathBetPos1[RepeatNo]= 0;
	gVariable.m_sgBeamPath.dBeamPathBetPos2[RepeatNo]= 0;
	gVariable.m_sgBeamPath.dBeamPathBetPos3[RepeatNo]= 0;
	gVariable.m_sgBeamPath.dBeamPathBetPos4[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nBeamPathMaskPos1[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nBeamPathMaskPos2[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nBeamPathMaskPos3[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nBeamPathMaskPos4[RepeatNo]= 0;

	gVariable.m_sgBeamPath.dBeamPathRotator[RepeatNo]= 0;
	gVariable.m_sgBeamPath.dBeamPathTopHat[RepeatNo]= 0;

	gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dBeamPathZAxisPos1[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dBeamPathZAxisPos2[RepeatNo]= 0; 
	gVariable.m_sgBeamPath.bBeamPathUseTophat[RepeatNo] = 0;	
	
	gVariable.m_sgBeamPath.dPowOffsetDuty[RepeatNo] = 0;
	
	gVariable.m_sgBeamPath.nSelectShot[RepeatNo] = 0;
	gVariable.m_sgBeamPath.nPowCompensationFrequency[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dPowCompensationDuty[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dPowCompensationTargetMin[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dPowCompensationTargetMax[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dPowCompensationDutyOffset[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dPowCompensationTarget[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dPowCompensationTargetPercent[RepeatNo] = 0;
	
	gVariable.m_sgBeamPath.dScannerDuty[RepeatNo] = 0;

	gVariable.m_sgBeamPath.dScannerFrq[RepeatNo] = 0;

	gVariable.m_sgBeamPath.nScannerTotalShot[RepeatNo] = 0;
	gVariable.m_sgBeamPath.nScannerVisionCam[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dScannerVisionModelSize[RepeatNo] = 0;
	gVariable.m_sgBeamPath.nScannerPolarity[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dScannerAcceptScoreSize[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dScannerContrast[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dScannerBrightness[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nScannerPolarity[RepeatNo] = 0;
	gVariable.m_sgBeamPath.nScannerCoaxial[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nScannerRing[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nScannerIR[RepeatNo]= 0;

	gVariable.m_sgBeamPath.nScannerCoaxial2[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nScannerRing2[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nScannerIR2[RepeatNo]= 0;

	gVariable.m_sgBeamPath.nScannerCoaxial3[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nScannerRing3[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nScannerIR3[RepeatNo]= 0;

	gVariable.m_sgBeamPath.nScannerCoaxial4[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nScannerRing4[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nScannerIR4[RepeatNo]= 0;

	gVariable.m_sgBeamPath.nHoleVisionCam[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dHoleVisionModelSize[RepeatNo] = 0;
	gVariable.m_sgBeamPath.nHolePolarity[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dHoleAcceptScoreSize[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dHoleContrast[RepeatNo] = 0;
	gVariable.m_sgBeamPath.dHoleBrightness[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nHoleRing[RepeatNo] = 0;
	gVariable.m_sgBeamPath.nHoleCoaxial[RepeatNo]= 0;
	gVariable.m_sgBeamPath.nHoleIR[RepeatNo]= 0;

	strcpy_s(gVariable.m_sgBeamPath.strInfoName[RepeatNo],"-");
	strcpy_s( gVariable.m_sgBeamPath.strBeamPathAscFile[RepeatNo] ,"-");
}

void CDlgBeamPathTable::CopyFromTempToOriginal()
{
	for(int i = 0 ;i <= m_nRepeatCount; i++)
	{
		gVariable.m_sgBeamPath.dInfoMaskSize[i]			=	m_sTempBeamPath.dInfoMaskSize[i];
		
		gVariable.m_sgBeamPath.dBeamPathBetPos1[i]			=	m_sTempBeamPath.dBeamPathBetPos1[i];
		gVariable.m_sgBeamPath.dBeamPathBetPos2[i]			=	m_sTempBeamPath.dBeamPathBetPos2[i];
		gVariable.m_sgBeamPath.dBeamPathBetPos3[i]			=	m_sTempBeamPath.dBeamPathBetPos3[i];
		gVariable.m_sgBeamPath.dBeamPathBetPos4[i]			=	m_sTempBeamPath.dBeamPathBetPos4[i];
		gVariable.m_sgBeamPath.nBeamPathMaskPos1[i]		=	m_sTempBeamPath.nBeamPathMaskPos1[i];
		gVariable.m_sgBeamPath.nBeamPathMaskPos2[i]		=	m_sTempBeamPath.nBeamPathMaskPos2[i];
		gVariable.m_sgBeamPath.nBeamPathMaskPos3[i]		=	m_sTempBeamPath.nBeamPathMaskPos3[i];
		gVariable.m_sgBeamPath.nBeamPathMaskPos4[i]		=	m_sTempBeamPath.nBeamPathMaskPos4[i];

		gVariable.m_sgBeamPath.dBeamPathRotator[i]		=	m_sTempBeamPath.dBeamPathRotator[i];
		gVariable.m_sgBeamPath.dBeamPathTopHat[i]		=	m_sTempBeamPath.dBeamPathTopHat[i];


		gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[i]	=	m_sTempBeamPath.nBeamPathAttenuatePos1[i];
		gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[i]	=	m_sTempBeamPath.nBeamPathAttenuatePos2[i];
		gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i]		=	m_sTempBeamPath.dBeamPathZAxisPos1[i];
		gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i]		=	m_sTempBeamPath.dBeamPathZAxisPos2[i]; 
		gVariable.m_sgBeamPath.bBeamPathUseTophat[i]		=	m_sTempBeamPath.bBeamPathUseTophat[i];
		gVariable.m_sgBeamPath.bBeamPathLaserPath[i]		=	m_sTempBeamPath.bBeamPathLaserPath[i];
		//gVariable.m_sgBeamPath.bBeamPathUseAom[i]		=	m_sTempBeamPath.bBeamPathUseAom[i];

		
		
		gVariable.m_sgBeamPath.dPowOffsetDuty[i]			=	m_sTempBeamPath.dPowOffsetDuty[i];
		
		gVariable.m_sgBeamPath.nSelectShot[i] = m_sTempBeamPath.nSelectShot[i];
		gVariable.m_sgBeamPath.nPowCompensationFrequency[i] = m_sTempBeamPath.nPowCompensationFrequency[i];
		gVariable.m_sgBeamPath.dPowCompensationDuty[i]		=	m_sTempBeamPath.dPowCompensationDuty[i];
		gVariable.m_sgBeamPath.dPowCompensationTargetMin[i] = m_sTempBeamPath.dPowCompensationTargetMin[i];
		gVariable.m_sgBeamPath.dPowCompensationTargetMax[i] = m_sTempBeamPath.dPowCompensationTargetMax[i];
		gVariable.m_sgBeamPath.dPowCompensationDutyOffset[i] =m_sTempBeamPath.dPowCompensationDutyOffset[i];
		gVariable.m_sgBeamPath.dPowCompensationTarget[i] = m_sTempBeamPath.dPowCompensationTarget[i];
		gVariable.m_sgBeamPath.dPowCompensationTargetPercent[i] = m_sTempBeamPath.dPowCompensationTargetPercent[i];

		gVariable.m_sgBeamPath.dScannerDuty[i]				=	m_sTempBeamPath.dScannerDuty[i];

		gVariable.m_sgBeamPath.dScannerFrq[i]				=	m_sTempBeamPath.dScannerFrq[i];


		gVariable.m_sgBeamPath.nScannerTotalShot[i]		=	m_sTempBeamPath.nScannerTotalShot[i];
		gVariable.m_sgBeamPath.nScannerVisionCam[i]		=	m_sTempBeamPath.nScannerVisionCam[i] ;
		gVariable.m_sgBeamPath.dScannerVisionModelSize[i]	=	m_sTempBeamPath.dScannerVisionModelSize[i];
		gVariable.m_sgBeamPath.nScannerPolarity[i]			=	m_sTempBeamPath.nScannerPolarity[i];
		gVariable.m_sgBeamPath.dScannerAcceptScoreSize[i]	=	m_sTempBeamPath.dScannerAcceptScoreSize[i];
		gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[i] =	m_sTempBeamPath.dScannerAcceptScoreRatio[i];
		gVariable.m_sgBeamPath.dScannerContrast[i]			=	m_sTempBeamPath.dScannerContrast[i];
		gVariable.m_sgBeamPath.dScannerBrightness[i]		=	m_sTempBeamPath.dScannerBrightness[i];
		gVariable.m_sgBeamPath.nScannerRing[i]				=	m_sTempBeamPath.nScannerRing[i];
		gVariable.m_sgBeamPath.nScannerCoaxial[i]			=	m_sTempBeamPath.nScannerCoaxial[i];

		gVariable.m_sgBeamPath.nScannerIR[i]				=	m_sTempBeamPath.nScannerIR[i];

		gVariable.m_sgBeamPath.nScannerRing2[i]				=	m_sTempBeamPath.nScannerRing2[i];
		gVariable.m_sgBeamPath.nScannerCoaxial2[i]			=	m_sTempBeamPath.nScannerCoaxial2[i];
		gVariable.m_sgBeamPath.nScannerIR2[i]				=	m_sTempBeamPath.nScannerIR2[i];

		gVariable.m_sgBeamPath.nScannerRing3[i]				=	m_sTempBeamPath.nScannerRing3[i];
		gVariable.m_sgBeamPath.nScannerCoaxial3[i]			=	m_sTempBeamPath.nScannerCoaxial3[i];
		gVariable.m_sgBeamPath.nScannerIR3[i]				=	m_sTempBeamPath.nScannerIR3[i];

		gVariable.m_sgBeamPath.nScannerRing4[i]				=	m_sTempBeamPath.nScannerRing4[i];
		gVariable.m_sgBeamPath.nScannerCoaxial4[i]			=	m_sTempBeamPath.nScannerCoaxial4[i];
		gVariable.m_sgBeamPath.nScannerIR4[i]				=	m_sTempBeamPath.nScannerIR4[i];




		gVariable.m_sgBeamPath.nHoleVisionCam[i]			=	m_sTempBeamPath.nHoleVisionCam[i] ;
		gVariable.m_sgBeamPath.dHoleVisionModelSize[i]		=	m_sTempBeamPath.dHoleVisionModelSize[i];
		gVariable.m_sgBeamPath.nHolePolarity[i]			=	m_sTempBeamPath.nHolePolarity[i];
		gVariable.m_sgBeamPath.dHoleAcceptScoreSize[i]		=	m_sTempBeamPath.dHoleAcceptScoreSize[i];
		gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[i]	=	m_sTempBeamPath.dHoleAcceptScoreRatio[i];
		gVariable.m_sgBeamPath.dHoleContrast[i]			=	m_sTempBeamPath.dHoleContrast[i];
		gVariable.m_sgBeamPath.dHoleBrightness[i]			=	m_sTempBeamPath.dHoleBrightness[i];
		gVariable.m_sgBeamPath.nHoleRing[i]				=	m_sTempBeamPath.nHoleRing[i];
		gVariable.m_sgBeamPath.nHoleCoaxial[i]			=	m_sTempBeamPath.nHoleCoaxial[i];
		gVariable.m_sgBeamPath.nHoleIR[i]			=	m_sTempBeamPath.nHoleIR[i];

		strcpy_s(gVariable.m_sgBeamPath.strInfoName[i],m_sTempBeamPath.strInfoName[i]);
		strcpy_s( gVariable.m_sgBeamPath.strBeamPathAscFile[i] ,m_sTempBeamPath.strBeamPathAscFile[i]);
	}
}

void CDlgBeamPathTable::SetIdNoToAddDel(int nIdYPos)
{
	m_IdNoToAddDel = nIdYPos;
}

int CDlgBeamPathTable::GetIdNoToAddDel()
{
	return m_IdNoToAddDel;
}

void CDlgBeamPathTable::InitDataStruct()
{
	m_sTempBeamPath.nLastIndex = m_nRepeatCount;


	for(int i = 0 ;i < BEAMPATH_COUNT; i++)
	{
		m_sTempBeamPath.nInfoId[i] = i;
		m_sTempBeamPath.dInfoMaskSize[i]= 0;
		
		m_sTempBeamPath.dBeamPathBetPos1[i]= 0;
		m_sTempBeamPath.dBeamPathBetPos2[i]= 0;
		m_sTempBeamPath.dBeamPathBetPos3[i]= 0;
		m_sTempBeamPath.dBeamPathBetPos4[i]= 0;
		m_sTempBeamPath.nBeamPathMaskPos1[i]= 0;
		m_sTempBeamPath.nBeamPathMaskPos2[i]= 0;
		m_sTempBeamPath.nBeamPathMaskPos3[i]= 0;
		m_sTempBeamPath.nBeamPathMaskPos4[i]= 0;

		m_sTempBeamPath.dBeamPathRotator[i]= 0;
		m_sTempBeamPath.dBeamPathTopHat[i]= 0;

		m_sTempBeamPath.nBeamPathAttenuatePos1[i]= 0;
		m_sTempBeamPath.nBeamPathAttenuatePos2[i] = 0;
		m_sTempBeamPath.dBeamPathZAxisPos1[i] = 0;
		m_sTempBeamPath.dBeamPathZAxisPos2[i]= 0; 
		m_sTempBeamPath.bBeamPathUseTophat[i] = 0;	
		m_sTempBeamPath.bBeamPathLaserPath[i] = 0;
		//m_sTempBeamPath.bBeamPathUseAom[i] = 0;
		
		
		m_sTempBeamPath.dPowOffsetDuty[i] = 0;
		
		m_sTempBeamPath.nSelectShot[i] = 0;
		m_sTempBeamPath.nPowCompensationFrequency[i] = 0;
		m_sTempBeamPath.dPowCompensationDuty[i] = 0;
		m_sTempBeamPath.dPowCompensationTargetMin[i] = 0;
		m_sTempBeamPath.dPowCompensationTargetMax[i] = 0;
		m_sTempBeamPath.dPowCompensationDutyOffset[i] = 0;
		m_sTempBeamPath.dPowCompensationTarget[i] = 0;
		m_sTempBeamPath.dPowCompensationTargetPercent[i] = 0;

		m_sTempBeamPath.dScannerDuty[i] = 0;

		m_sTempBeamPath.dScannerFrq[i] = 0;

		m_sTempBeamPath.nScannerTotalShot[i] = 0;
		m_sTempBeamPath.nScannerVisionCam[i] = 0;
		m_sTempBeamPath.dScannerVisionModelSize[i] = 0;
		m_sTempBeamPath.nScannerPolarity[i] = 0;
		m_sTempBeamPath.dScannerAcceptScoreSize[i] = 0;
		m_sTempBeamPath.dScannerAcceptScoreRatio[i] = 0;
		m_sTempBeamPath.dScannerContrast[i] = 0;
		m_sTempBeamPath.dScannerBrightness[i]= 0;
		m_sTempBeamPath.nScannerRing[i] = 0;
		m_sTempBeamPath.nScannerCoaxial[i]= 0;

		m_sTempBeamPath.bSelectedList[i] = FALSE;
		m_sTempBeamPath.nScannerIR[i]= 0;

		m_sTempBeamPath.nScannerRing2[i] = 0;
		m_sTempBeamPath.nScannerCoaxial2[i]= 0;
		m_sTempBeamPath.nScannerIR2[i] = 0;
		
		m_sTempBeamPath.nScannerRing3[i] = 0;
		m_sTempBeamPath.nScannerCoaxial3[i]= 0;
		m_sTempBeamPath.nScannerIR3[i] = 0;

		m_sTempBeamPath.nScannerRing4[i] = 0;
		m_sTempBeamPath.nScannerCoaxial4[i]= 0;
		m_sTempBeamPath.nScannerIR4[i] = 0;


		m_sTempBeamPath.nHoleVisionCam[i] = 0;
		m_sTempBeamPath.dHoleVisionModelSize[i] = 0;
		m_sTempBeamPath.nHolePolarity[i] = 0;
		m_sTempBeamPath.dHoleAcceptScoreSize[i] = 0;
		m_sTempBeamPath.dHoleAcceptScoreRatio[i] = 0;
		m_sTempBeamPath.dHoleContrast[i] = 0;
		m_sTempBeamPath.nHoleRing[i] = 0;
		m_sTempBeamPath.nHoleCoaxial[i]= 0;
		m_sTempBeamPath.nHoleIR[i]= 0;

		strcpy_s(m_sTempBeamPath.strInfoName[i],"-");
//		strcpy_s( gVariable.m_sgBeamPath.strBeamPathAscFile[i] ,"-");
	}

	// 	strcpy_s( gVariable.m_sgBeamPath.strPowCompensationAomFile ,"-");
	// 	m_sTempBeamPath.dScannerJumpDelay = 0;
	//	m_sTempBeamPath.dFixedMask = 0;
}


// up, down��  �迭�� ���Ʒ��� �ٲٸ� �Ǳ� ������ ��ü ���縦 ���� �ʰ�
// m_sTempBeamPath ������ 0�� �δ콺 �������� �̿��Ͽ� m_sBeamPath ������ ������ ���� �Ѵ�. 

void CDlgBeamPathTable::OnCheckUp()
{
	if(FALSE == m_ClickID)
		return ;

	int SelectNo = GetIdNoToAddDel();
	if(SelectNo <= 0)
		return ;


	//round 1
	//temp[0] ������ ���õ� �׸��� ������ ���� 
	m_sTempBeamPath.dInfoMaskSize[0]			=	gVariable.m_sgBeamPath.dInfoMaskSize[SelectNo-1];			
	m_sTempBeamPath.dBeamPathBetPos1[0]			=	gVariable.m_sgBeamPath.dBeamPathBetPos1[SelectNo-1];
	m_sTempBeamPath.dBeamPathBetPos2[0]			=	gVariable.m_sgBeamPath.dBeamPathBetPos2[SelectNo-1];
	m_sTempBeamPath.dBeamPathBetPos3[0]			=	gVariable.m_sgBeamPath.dBeamPathBetPos3[SelectNo-1];
	m_sTempBeamPath.dBeamPathBetPos4[0]			=	gVariable.m_sgBeamPath.dBeamPathBetPos4[SelectNo-1];
	m_sTempBeamPath.nBeamPathMaskPos1[0]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos1[SelectNo-1];
	m_sTempBeamPath.nBeamPathMaskPos2[0]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos2[SelectNo-1];
	m_sTempBeamPath.nBeamPathMaskPos3[0]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos3[SelectNo-1];
	m_sTempBeamPath.nBeamPathMaskPos4[0]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos4[SelectNo-1];

	m_sTempBeamPath.dBeamPathRotator[0]		=	gVariable.m_sgBeamPath.dBeamPathRotator[SelectNo-1];
	m_sTempBeamPath.dBeamPathTopHat[0]		=	gVariable.m_sgBeamPath.dBeamPathTopHat[SelectNo-1];


	m_sTempBeamPath.nBeamPathAttenuatePos1[0]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[SelectNo-1];
	m_sTempBeamPath.nBeamPathAttenuatePos2[0]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[SelectNo-1];
	m_sTempBeamPath.dBeamPathZAxisPos1[0]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos1[SelectNo-1];
	m_sTempBeamPath.dBeamPathZAxisPos2[0]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos2[SelectNo-1]; 
	m_sTempBeamPath.bBeamPathUseTophat[0]		=	gVariable.m_sgBeamPath.bBeamPathUseTophat[SelectNo-1];	
	m_sTempBeamPath.bBeamPathLaserPath[0]		=	gVariable.m_sgBeamPath.bBeamPathLaserPath[SelectNo-1];	
	//m_sTempBeamPath.bBeamPathUseAom[0]		=	gVariable.m_sgBeamPath.bBeamPathUseAom[SelectNo-1];	
	
	m_sTempBeamPath.dPowOffsetDuty[0]			=	gVariable.m_sgBeamPath.dPowOffsetDuty[SelectNo-1];
	
	m_sTempBeamPath.nSelectShot[0] = gVariable.m_sgBeamPath.nSelectShot[SelectNo-1];
	m_sTempBeamPath.nPowCompensationFrequency[0] = gVariable.m_sgBeamPath.nPowCompensationFrequency[SelectNo-1];
	m_sTempBeamPath.dPowCompensationDuty[0]		=	gVariable.m_sgBeamPath.dPowCompensationDuty[SelectNo-1];
	m_sTempBeamPath.dPowCompensationTargetMin[0] = gVariable.m_sgBeamPath.dPowCompensationTargetMin[SelectNo-1];
	m_sTempBeamPath.dPowCompensationTargetMax[0] = gVariable.m_sgBeamPath.dPowCompensationTargetMax[SelectNo-1];
	m_sTempBeamPath.dPowCompensationDutyOffset[0] =gVariable.m_sgBeamPath.dPowCompensationDutyOffset[SelectNo-1];
	m_sTempBeamPath.dPowCompensationTarget[0] = gVariable.m_sgBeamPath.dPowCompensationTarget[SelectNo-1];
	m_sTempBeamPath.dPowCompensationTargetPercent[0] = gVariable.m_sgBeamPath.dPowCompensationTargetPercent[SelectNo-1];
	m_sTempBeamPath.dScannerDuty[0]				=	gVariable.m_sgBeamPath.dScannerDuty[SelectNo-1];

	m_sTempBeamPath.dScannerFrq[0]				=	gVariable.m_sgBeamPath.dScannerFrq[SelectNo-1];

	m_sTempBeamPath.nScannerTotalShot[0]		=	gVariable.m_sgBeamPath.nScannerTotalShot[SelectNo-1];
	m_sTempBeamPath.nScannerVisionCam[0]		=	gVariable.m_sgBeamPath.nScannerVisionCam[SelectNo-1] ;
	m_sTempBeamPath.dScannerVisionModelSize[0]	=	gVariable.m_sgBeamPath.dScannerVisionModelSize[SelectNo-1];
	m_sTempBeamPath.nScannerPolarity[0]			=	gVariable.m_sgBeamPath.nScannerPolarity[SelectNo-1];
	m_sTempBeamPath.dScannerAcceptScoreSize[0]	=	gVariable.m_sgBeamPath.dScannerAcceptScoreSize[SelectNo-1];
	m_sTempBeamPath.dScannerAcceptScoreRatio[0] =	gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[SelectNo-1];
	m_sTempBeamPath.dScannerContrast[0]			=	gVariable.m_sgBeamPath.dScannerContrast[SelectNo-1];
	m_sTempBeamPath.dScannerBrightness[0]		=	gVariable.m_sgBeamPath.dScannerBrightness[SelectNo-1];
	m_sTempBeamPath.nScannerRing[0]				=	gVariable.m_sgBeamPath.nScannerRing[SelectNo-1];
	m_sTempBeamPath.nScannerCoaxial[0]		=	gVariable.m_sgBeamPath.nScannerCoaxial[SelectNo-1];

	m_sTempBeamPath.nScannerIR[0]		=	gVariable.m_sgBeamPath.nScannerIR[SelectNo-1];

	m_sTempBeamPath.nScannerRing2[0]				=	gVariable.m_sgBeamPath.nScannerRing2[SelectNo-1];
	m_sTempBeamPath.nScannerCoaxial2[0]		=	gVariable.m_sgBeamPath.nScannerCoaxial2[SelectNo-1];
	m_sTempBeamPath.nScannerIR2[0]				=	gVariable.m_sgBeamPath.nScannerIR2[SelectNo-1];


	m_sTempBeamPath.nScannerRing3[0]				=	gVariable.m_sgBeamPath.nScannerRing3[SelectNo-1];
	m_sTempBeamPath.nScannerCoaxial3[0]		=	gVariable.m_sgBeamPath.nScannerCoaxial3[SelectNo-1];
	m_sTempBeamPath.nScannerIR3[0]				=	gVariable.m_sgBeamPath.nScannerIR3[SelectNo-1];

	m_sTempBeamPath.nScannerRing4[0]				=	gVariable.m_sgBeamPath.nScannerRing4[SelectNo-1];
	m_sTempBeamPath.nScannerCoaxial4[0]		=	gVariable.m_sgBeamPath.nScannerCoaxial4[SelectNo-1];
	m_sTempBeamPath.nScannerIR4[0]				=	gVariable.m_sgBeamPath.nScannerIR4[SelectNo-1];



	m_sTempBeamPath.nHoleVisionCam[0]		=	gVariable.m_sgBeamPath.nHoleVisionCam[SelectNo-1] ;
	m_sTempBeamPath.dHoleVisionModelSize[0]	=	gVariable.m_sgBeamPath.dHoleVisionModelSize[SelectNo-1];
	m_sTempBeamPath.nHolePolarity[0]			=	gVariable.m_sgBeamPath.nHolePolarity[SelectNo-1];
	m_sTempBeamPath.dHoleAcceptScoreSize[0]	=	gVariable.m_sgBeamPath.dHoleAcceptScoreSize[SelectNo-1];
	m_sTempBeamPath.dHoleAcceptScoreRatio[0] =	gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[SelectNo-1];
	m_sTempBeamPath.dHoleContrast[0]			=	gVariable.m_sgBeamPath.dHoleContrast[SelectNo-1];
	m_sTempBeamPath.dHoleBrightness[0]		=	gVariable.m_sgBeamPath.dHoleBrightness[SelectNo-1];
	m_sTempBeamPath.nHoleRing[0]			=	gVariable.m_sgBeamPath.nHoleRing[SelectNo-1];
	m_sTempBeamPath.nHoleCoaxial[0]		=	gVariable.m_sgBeamPath.nHoleCoaxial[SelectNo-1];
	m_sTempBeamPath.nHoleIR[0]		=	gVariable.m_sgBeamPath.nHoleIR[SelectNo-1];

	strcpy_s(m_sTempBeamPath.strInfoName[0],gVariable.m_sgBeamPath.strInfoName[SelectNo-1]);
	strcpy_s( m_sTempBeamPath.strBeamPathAscFile[0] ,gVariable.m_sgBeamPath.strBeamPathAscFile[SelectNo-1]);



	//round2
	//���õ� ���� ��ĭ ���� �����Ѵ�. 
	gVariable.m_sgBeamPath.dInfoMaskSize[SelectNo-1]			=	gVariable.m_sgBeamPath.dInfoMaskSize[SelectNo];			
	gVariable.m_sgBeamPath.dBeamPathBetPos1[SelectNo-1]		=	gVariable.m_sgBeamPath.dBeamPathBetPos1[SelectNo];
	gVariable.m_sgBeamPath.dBeamPathBetPos2[SelectNo-1]		=	gVariable.m_sgBeamPath.dBeamPathBetPos2[SelectNo];
	gVariable.m_sgBeamPath.dBeamPathBetPos3[SelectNo-1]		=	gVariable.m_sgBeamPath.dBeamPathBetPos3[SelectNo];
	gVariable.m_sgBeamPath.dBeamPathBetPos4[SelectNo-1]		=	gVariable.m_sgBeamPath.dBeamPathBetPos4[SelectNo];
	gVariable.m_sgBeamPath.nBeamPathMaskPos1[SelectNo-1]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos1[SelectNo];
	gVariable.m_sgBeamPath.nBeamPathMaskPos2[SelectNo-1]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos2[SelectNo];
	gVariable.m_sgBeamPath.nBeamPathMaskPos3[SelectNo-1]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos3[SelectNo];
	gVariable.m_sgBeamPath.nBeamPathMaskPos4[SelectNo-1]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos4[SelectNo];

	gVariable.m_sgBeamPath.dBeamPathRotator[SelectNo-1]		=	gVariable.m_sgBeamPath.dBeamPathRotator[SelectNo];
	gVariable.m_sgBeamPath.dBeamPathTopHat[SelectNo-1]		=	gVariable.m_sgBeamPath.dBeamPathTopHat[SelectNo];


	gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[SelectNo-1]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[SelectNo];
	gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[SelectNo-1]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[SelectNo];
	gVariable.m_sgBeamPath.dBeamPathZAxisPos1[SelectNo-1]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos1[SelectNo];
	gVariable.m_sgBeamPath.dBeamPathZAxisPos2[SelectNo-1]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos2[SelectNo]; 
	gVariable.m_sgBeamPath.bBeamPathUseTophat[SelectNo-1]		=	gVariable.m_sgBeamPath.bBeamPathUseTophat[SelectNo];
	gVariable.m_sgBeamPath.bBeamPathLaserPath[SelectNo-1]	=	gVariable.m_sgBeamPath.bBeamPathLaserPath[SelectNo];	
	//gVariable.m_sgBeamPath.bBeamPathUseAom[SelectNo-1]	=	gVariable.m_sgBeamPath.bBeamPathUseAom[SelectNo];
	
	
	gVariable.m_sgBeamPath.dPowOffsetDuty[SelectNo-1]			=	gVariable.m_sgBeamPath.dPowOffsetDuty[SelectNo];
	
	gVariable.m_sgBeamPath.nSelectShot[SelectNo-1] = gVariable.m_sgBeamPath.nSelectShot[SelectNo];
	gVariable.m_sgBeamPath.nPowCompensationFrequency[SelectNo-1] = gVariable.m_sgBeamPath.nPowCompensationFrequency[SelectNo];
	gVariable.m_sgBeamPath.dPowCompensationDuty[SelectNo-1]	 =	gVariable.m_sgBeamPath.dPowCompensationDuty[SelectNo];
	gVariable.m_sgBeamPath.dPowCompensationTargetMin[SelectNo-1] = gVariable.m_sgBeamPath.dPowCompensationTargetMin[SelectNo];
	gVariable.m_sgBeamPath.dPowCompensationTargetMax[SelectNo-1] = gVariable.m_sgBeamPath.dPowCompensationTargetMax[SelectNo];
	gVariable.m_sgBeamPath.dPowCompensationDutyOffset[SelectNo-1] =gVariable.m_sgBeamPath.dPowCompensationDutyOffset[SelectNo];
	gVariable.m_sgBeamPath.dPowCompensationTarget[SelectNo-1] = gVariable.m_sgBeamPath.dPowCompensationTarget[SelectNo];
	gVariable.m_sgBeamPath.dPowCompensationTargetPercent[SelectNo-1] = gVariable.m_sgBeamPath.dPowCompensationTargetPercent[SelectNo];
	gVariable.m_sgBeamPath.dScannerDuty[SelectNo-1]			=	gVariable.m_sgBeamPath.dScannerDuty[SelectNo];

	gVariable.m_sgBeamPath.dScannerFrq[SelectNo-1]			=	gVariable.m_sgBeamPath.dScannerFrq[SelectNo];


	gVariable.m_sgBeamPath.nScannerTotalShot[SelectNo-1]		=	gVariable.m_sgBeamPath.nScannerTotalShot[SelectNo];
	gVariable.m_sgBeamPath.nScannerVisionCam[SelectNo-1]		=	gVariable.m_sgBeamPath.nScannerVisionCam[SelectNo] ;
	gVariable.m_sgBeamPath.dScannerVisionModelSize[SelectNo-1] =	gVariable.m_sgBeamPath.dScannerVisionModelSize[SelectNo];
	gVariable.m_sgBeamPath.nScannerPolarity[SelectNo-1]		=	gVariable.m_sgBeamPath.nScannerPolarity[SelectNo];
	gVariable.m_sgBeamPath.dScannerAcceptScoreSize[SelectNo-1] =	gVariable.m_sgBeamPath.dScannerAcceptScoreSize[SelectNo];
	gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[SelectNo-1] =	gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[SelectNo];
	gVariable.m_sgBeamPath.dScannerContrast[SelectNo-1]		=	gVariable.m_sgBeamPath.dScannerContrast[SelectNo];
	gVariable.m_sgBeamPath.dScannerBrightness[SelectNo-1]		=	gVariable.m_sgBeamPath.dScannerBrightness[SelectNo];
	gVariable.m_sgBeamPath.nScannerRing[SelectNo-1]			=	gVariable.m_sgBeamPath.nScannerRing[SelectNo];
	gVariable.m_sgBeamPath.nScannerCoaxial[SelectNo-1]			=	gVariable.m_sgBeamPath.nScannerCoaxial[SelectNo];

	gVariable.m_sgBeamPath.nScannerIR[SelectNo-1]			=	gVariable.m_sgBeamPath.nScannerIR[SelectNo];



	gVariable.m_sgBeamPath.nScannerRing2[SelectNo-1]			=	gVariable.m_sgBeamPath.nScannerRing2[SelectNo];
	gVariable.m_sgBeamPath.nScannerCoaxial2[SelectNo-1]			=	gVariable.m_sgBeamPath.nScannerCoaxial2[SelectNo];
	gVariable.m_sgBeamPath.nScannerIR2[SelectNo-1]			=	gVariable.m_sgBeamPath.nScannerIR2[SelectNo];

	gVariable.m_sgBeamPath.nScannerRing3[SelectNo-1]			=	gVariable.m_sgBeamPath.nScannerRing3[SelectNo];
	gVariable.m_sgBeamPath.nScannerCoaxial3[SelectNo-1]			=	gVariable.m_sgBeamPath.nScannerCoaxial3[SelectNo];
	gVariable.m_sgBeamPath.nScannerIR3[SelectNo-1]			=	gVariable.m_sgBeamPath.nScannerIR3[SelectNo];

	gVariable.m_sgBeamPath.nScannerRing4[SelectNo-1]			=	gVariable.m_sgBeamPath.nScannerRing4[SelectNo];
	gVariable.m_sgBeamPath.nScannerCoaxial4[SelectNo-1]			=	gVariable.m_sgBeamPath.nScannerCoaxial4[SelectNo];
	gVariable.m_sgBeamPath.nScannerIR4[SelectNo-1]			=	gVariable.m_sgBeamPath.nScannerIR4[SelectNo];



	gVariable.m_sgBeamPath.nHoleVisionCam[SelectNo-1]		=	gVariable.m_sgBeamPath.nHoleVisionCam[SelectNo] ;
	gVariable.m_sgBeamPath.dHoleVisionModelSize[SelectNo-1] =	gVariable.m_sgBeamPath.dHoleVisionModelSize[SelectNo];
	gVariable.m_sgBeamPath.nHolePolarity[SelectNo-1]		=	gVariable.m_sgBeamPath.nHolePolarity[SelectNo];
	gVariable.m_sgBeamPath.dHoleAcceptScoreSize[SelectNo-1] =	gVariable.m_sgBeamPath.dHoleAcceptScoreSize[SelectNo];
	gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[SelectNo-1] =	gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[SelectNo];
	gVariable.m_sgBeamPath.dHoleContrast[SelectNo-1]		=	gVariable.m_sgBeamPath.dHoleContrast[SelectNo];
	gVariable.m_sgBeamPath.dHoleBrightness[SelectNo-1]		=	gVariable.m_sgBeamPath.dHoleBrightness[SelectNo];
	gVariable.m_sgBeamPath.nHoleRing[SelectNo-1]		=	gVariable.m_sgBeamPath.nHoleRing[SelectNo];
	gVariable.m_sgBeamPath.nHoleCoaxial[SelectNo-1]		=	gVariable.m_sgBeamPath.nHoleCoaxial[SelectNo];
	gVariable.m_sgBeamPath.nHoleIR[SelectNo-1]		=	gVariable.m_sgBeamPath.nHoleIR[SelectNo];

	strcpy_s(gVariable.m_sgBeamPath.strInfoName[SelectNo-1],gVariable.m_sgBeamPath.strInfoName[SelectNo]);
	strcpy_s( gVariable.m_sgBeamPath.strBeamPathAscFile[SelectNo-1] ,gVariable.m_sgBeamPath.strBeamPathAscFile[SelectNo]);




	//round3
	// temp[0]�� ����� ���� ���õ� �׸����� �����Ѵ�.
	gVariable.m_sgBeamPath.dInfoMaskSize[SelectNo]			=	m_sTempBeamPath.dInfoMaskSize[0];			
	gVariable.m_sgBeamPath.dBeamPathBetPos1[SelectNo]		=	m_sTempBeamPath.dBeamPathBetPos1[0];
	gVariable.m_sgBeamPath.dBeamPathBetPos2[SelectNo]		=	m_sTempBeamPath.dBeamPathBetPos2[0];
	gVariable.m_sgBeamPath.dBeamPathBetPos3[SelectNo]		=	m_sTempBeamPath.dBeamPathBetPos3[0];
	gVariable.m_sgBeamPath.dBeamPathBetPos4[SelectNo]		=	m_sTempBeamPath.dBeamPathBetPos4[0];
	gVariable.m_sgBeamPath.nBeamPathMaskPos1[SelectNo]		=	m_sTempBeamPath.nBeamPathMaskPos1[0];
	gVariable.m_sgBeamPath.nBeamPathMaskPos2[SelectNo]		=	m_sTempBeamPath.nBeamPathMaskPos2[0];
	gVariable.m_sgBeamPath.nBeamPathMaskPos3[SelectNo]		=	m_sTempBeamPath.nBeamPathMaskPos3[0];
	gVariable.m_sgBeamPath.nBeamPathMaskPos4[SelectNo]		=	m_sTempBeamPath.nBeamPathMaskPos4[0];

	gVariable.m_sgBeamPath.dBeamPathRotator[SelectNo]		=	m_sTempBeamPath.dBeamPathRotator[0];
	gVariable.m_sgBeamPath.dBeamPathTopHat[SelectNo]		=	m_sTempBeamPath.dBeamPathTopHat[0];

	gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[SelectNo]	=	m_sTempBeamPath.nBeamPathAttenuatePos1[0];
	gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[SelectNo]	=	m_sTempBeamPath.nBeamPathAttenuatePos2[0];
	gVariable.m_sgBeamPath.dBeamPathZAxisPos1[SelectNo]		=	m_sTempBeamPath.dBeamPathZAxisPos1[0];
	gVariable.m_sgBeamPath.dBeamPathZAxisPos2[SelectNo]		=	m_sTempBeamPath.dBeamPathZAxisPos2[0]; 
	gVariable.m_sgBeamPath.bBeamPathUseTophat[SelectNo]		=	m_sTempBeamPath.bBeamPathUseTophat[0];	
	gVariable.m_sgBeamPath.bBeamPathLaserPath[SelectNo]		=	gVariable.m_sgBeamPath.bBeamPathLaserPath[0];	
	//gVariable.m_sgBeamPath.bBeamPathUseAom[SelectNo]		=	gVariable.m_sgBeamPath.bBeamPathUseAom[0];

	

	gVariable.m_sgBeamPath.dPowOffsetDuty[SelectNo]			=	m_sTempBeamPath.dPowOffsetDuty[0];
	
	gVariable.m_sgBeamPath.nSelectShot[SelectNo] = m_sTempBeamPath.nSelectShot[0];
	gVariable.m_sgBeamPath.nPowCompensationFrequency[SelectNo] = m_sTempBeamPath.nPowCompensationFrequency[0];
	gVariable.m_sgBeamPath.dPowCompensationDuty[SelectNo]		=	m_sTempBeamPath.dPowCompensationDuty[0];
	gVariable.m_sgBeamPath.dPowCompensationTargetMin[SelectNo] = m_sTempBeamPath.dPowCompensationTargetMin[0];
	gVariable.m_sgBeamPath.dPowCompensationTargetMax[SelectNo] = m_sTempBeamPath.dPowCompensationTargetMax[0];
	gVariable.m_sgBeamPath.dPowCompensationDutyOffset[SelectNo] =m_sTempBeamPath.dPowCompensationDutyOffset[0];
	gVariable.m_sgBeamPath.dPowCompensationTarget[SelectNo] = m_sTempBeamPath.dPowCompensationTarget[0];
	gVariable.m_sgBeamPath.dPowCompensationTargetPercent[SelectNo] = m_sTempBeamPath.dPowCompensationTargetPercent[0];
	gVariable.m_sgBeamPath.dScannerDuty[SelectNo]				=	m_sTempBeamPath.dScannerDuty[0];

	gVariable.m_sgBeamPath.dScannerFrq[SelectNo]				=	m_sTempBeamPath.dScannerFrq[0];


	gVariable.m_sgBeamPath.nScannerTotalShot[SelectNo]			=	m_sTempBeamPath.nScannerTotalShot[0];
	gVariable.m_sgBeamPath.nScannerVisionCam[SelectNo]			=	m_sTempBeamPath.nScannerVisionCam[0] ;
	gVariable.m_sgBeamPath.dScannerVisionModelSize[SelectNo]	=	m_sTempBeamPath.dScannerVisionModelSize[0];
	gVariable.m_sgBeamPath.nScannerPolarity[SelectNo]			=	m_sTempBeamPath.nScannerPolarity[0];
	gVariable.m_sgBeamPath.dScannerAcceptScoreSize[SelectNo]	=	m_sTempBeamPath.dScannerAcceptScoreSize[0];
	gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[SelectNo]	=	m_sTempBeamPath.dScannerAcceptScoreRatio[0];
	gVariable.m_sgBeamPath.dScannerContrast[SelectNo]			=	m_sTempBeamPath.dScannerContrast[0];
	gVariable.m_sgBeamPath.dScannerBrightness[SelectNo]		=	m_sTempBeamPath.dScannerBrightness[0];
	gVariable.m_sgBeamPath.nScannerRing[SelectNo]				=	m_sTempBeamPath.nScannerRing[0];
	gVariable.m_sgBeamPath.nScannerCoaxial[SelectNo]			=	m_sTempBeamPath.nScannerCoaxial[0];

	gVariable.m_sgBeamPath.nScannerIR[SelectNo]				=	m_sTempBeamPath.nScannerIR[0];

	gVariable.m_sgBeamPath.nScannerRing2[SelectNo]				=	m_sTempBeamPath.nScannerRing2[0];
	gVariable.m_sgBeamPath.nScannerCoaxial2[SelectNo]			=	m_sTempBeamPath.nScannerCoaxial2[0];
	gVariable.m_sgBeamPath.nScannerIR2[SelectNo]				=	m_sTempBeamPath.nScannerIR2[0];

	gVariable.m_sgBeamPath.nScannerRing3[SelectNo]				=	m_sTempBeamPath.nScannerRing3[0];
	gVariable.m_sgBeamPath.nScannerCoaxial3[SelectNo]			=	m_sTempBeamPath.nScannerCoaxial3[0];
	gVariable.m_sgBeamPath.nScannerIR3[SelectNo]				=	m_sTempBeamPath.nScannerIR3[0];

	gVariable.m_sgBeamPath.nScannerRing4[SelectNo]				=	m_sTempBeamPath.nScannerRing4[0];
	gVariable.m_sgBeamPath.nScannerCoaxial4[SelectNo]			=	m_sTempBeamPath.nScannerCoaxial4[0];
	gVariable.m_sgBeamPath.nScannerIR4[SelectNo]				=	m_sTempBeamPath.nScannerIR4[0];



	gVariable.m_sgBeamPath.nHoleVisionCam[SelectNo]		=	m_sTempBeamPath.nHoleVisionCam[0] ;
	gVariable.m_sgBeamPath.dHoleVisionModelSize[SelectNo]	=	m_sTempBeamPath.dHoleVisionModelSize[0];
	gVariable.m_sgBeamPath.nHolePolarity[SelectNo]			=	m_sTempBeamPath.nHolePolarity[0];
	gVariable.m_sgBeamPath.dHoleAcceptScoreSize[SelectNo]	=	m_sTempBeamPath.dHoleAcceptScoreSize[0];
	gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[SelectNo]	=	m_sTempBeamPath.dHoleAcceptScoreRatio[0];
	gVariable.m_sgBeamPath.dHoleContrast[SelectNo]			=	m_sTempBeamPath.dHoleContrast[0];
	gVariable.m_sgBeamPath.dHoleBrightness[SelectNo]		=	m_sTempBeamPath.dHoleBrightness[0];
	gVariable.m_sgBeamPath.nHoleRing[SelectNo]				=	m_sTempBeamPath.nHoleRing[0];
	gVariable.m_sgBeamPath.nHoleCoaxial[SelectNo]			=	m_sTempBeamPath.nHoleCoaxial[0];
	gVariable.m_sgBeamPath.nHoleIR[SelectNo]			=	m_sTempBeamPath.nHoleIR[0];

	strcpy_s(gVariable.m_sgBeamPath.strInfoName[SelectNo],m_sTempBeamPath.strInfoName[0]);
	strcpy_s( gVariable.m_sgBeamPath.strBeamPathAscFile[SelectNo] ,m_sTempBeamPath.strBeamPathAscFile[0]);


	m_ClickID = FALSE;
	OnCheckRefresh();
	InitDataStruct();		// �ӽ� ����ü �ʱ�ȭ 

}

void CDlgBeamPathTable::OnCheckDown()
{
	if(FALSE == m_ClickID)
		return ;
	
	int SelectNo = GetIdNoToAddDel();
	if(SelectNo >= m_nRepeatCount)
		return ;


	//round 1
	//temp[0] ������ ���õ� �׸��� �Ʒ��� ���� 
	m_sTempBeamPath.dInfoMaskSize[0]			=	gVariable.m_sgBeamPath.dInfoMaskSize[SelectNo+1];			
	m_sTempBeamPath.dBeamPathBetPos1[0]			=	gVariable.m_sgBeamPath.dBeamPathBetPos1[SelectNo+1];
	m_sTempBeamPath.dBeamPathBetPos2[0]			=	gVariable.m_sgBeamPath.dBeamPathBetPos2[SelectNo+1];
	m_sTempBeamPath.dBeamPathBetPos3[0]			=	gVariable.m_sgBeamPath.dBeamPathBetPos3[SelectNo+1];
	m_sTempBeamPath.dBeamPathBetPos4[0]			=	gVariable.m_sgBeamPath.dBeamPathBetPos4[SelectNo+1];
	m_sTempBeamPath.nBeamPathMaskPos1[0]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos1[SelectNo+1];
	m_sTempBeamPath.nBeamPathMaskPos2[0]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos2[SelectNo+1];
	m_sTempBeamPath.nBeamPathMaskPos3[0]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos3[SelectNo+1];
	m_sTempBeamPath.nBeamPathMaskPos4[0]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos4[SelectNo+1];

	m_sTempBeamPath.dBeamPathRotator[0]		=	gVariable.m_sgBeamPath.dBeamPathRotator[SelectNo+1];
	m_sTempBeamPath.dBeamPathTopHat[0]		=	gVariable.m_sgBeamPath.dBeamPathTopHat[SelectNo+1];

	m_sTempBeamPath.nBeamPathAttenuatePos1[0]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[SelectNo+1];
	m_sTempBeamPath.nBeamPathAttenuatePos2[0]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[SelectNo+1];
	m_sTempBeamPath.dBeamPathZAxisPos1[0]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos1[SelectNo+1];
	m_sTempBeamPath.dBeamPathZAxisPos2[0]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos2[SelectNo+1]; 
	m_sTempBeamPath.bBeamPathUseTophat[0]		=	gVariable.m_sgBeamPath.bBeamPathUseTophat[SelectNo+1];	
	m_sTempBeamPath.bBeamPathLaserPath[0]		=	gVariable.m_sgBeamPath.bBeamPathLaserPath[SelectNo+1];	
	//m_sTempBeamPath.bBeamPathUseAom[0]		=	gVariable.m_sgBeamPath.bBeamPathUseAom[SelectNo+1];
	
	m_sTempBeamPath.dPowOffsetDuty[0]			=	gVariable.m_sgBeamPath.dPowOffsetDuty[SelectNo+1];
	
	m_sTempBeamPath.nSelectShot[0] = gVariable.m_sgBeamPath.nSelectShot[SelectNo+1];
	m_sTempBeamPath.nPowCompensationFrequency[0] = gVariable.m_sgBeamPath.nPowCompensationFrequency[SelectNo+1];
	m_sTempBeamPath.dPowCompensationDuty[0]		 =	gVariable.m_sgBeamPath.dPowCompensationDuty[SelectNo+1];
	m_sTempBeamPath.dPowCompensationTargetMin[0] = gVariable.m_sgBeamPath.dPowCompensationTargetMin[SelectNo+1];
	m_sTempBeamPath.dPowCompensationTargetMax[0] = gVariable.m_sgBeamPath.dPowCompensationTargetMax[SelectNo+1];
	m_sTempBeamPath.dPowCompensationTarget[0] = gVariable.m_sgBeamPath.dPowCompensationTarget[SelectNo+1];
	m_sTempBeamPath.dPowCompensationTargetPercent[0] = gVariable.m_sgBeamPath.dPowCompensationTargetPercent[SelectNo+1];
	m_sTempBeamPath.dPowCompensationDutyOffset[0] =gVariable.m_sgBeamPath.dPowCompensationDutyOffset[SelectNo+1];
	m_sTempBeamPath.dScannerDuty[0]				=	gVariable.m_sgBeamPath.dScannerDuty[SelectNo+1];

	m_sTempBeamPath.dScannerFrq[0]				=	gVariable.m_sgBeamPath.dScannerFrq[SelectNo+1];

	m_sTempBeamPath.nScannerTotalShot[0]		=	gVariable.m_sgBeamPath.nScannerTotalShot[SelectNo+1];
	m_sTempBeamPath.nScannerVisionCam[0]		=	gVariable.m_sgBeamPath.nScannerVisionCam[SelectNo+1] ;
	m_sTempBeamPath.dScannerVisionModelSize[0]	=	gVariable.m_sgBeamPath.dScannerVisionModelSize[SelectNo+1];
	m_sTempBeamPath.nScannerPolarity[0]			=	gVariable.m_sgBeamPath.nScannerPolarity[SelectNo+1];
	m_sTempBeamPath.dScannerAcceptScoreSize[0]	=	gVariable.m_sgBeamPath.dScannerAcceptScoreSize[SelectNo+1];
	m_sTempBeamPath.dScannerAcceptScoreRatio[0] =	gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[SelectNo+1];
	m_sTempBeamPath.dScannerContrast[0]			=	gVariable.m_sgBeamPath.dScannerContrast[SelectNo+1];
	m_sTempBeamPath.dScannerBrightness[0]		=	gVariable.m_sgBeamPath.dScannerBrightness[SelectNo+1];
	m_sTempBeamPath.nScannerRing[0]				=	gVariable.m_sgBeamPath.nScannerRing[SelectNo+1];
	m_sTempBeamPath.nScannerCoaxial[0]			=	gVariable.m_sgBeamPath.nScannerCoaxial[SelectNo+1];

	m_sTempBeamPath.nScannerIR[0]			=	gVariable.m_sgBeamPath.nScannerIR[SelectNo+1];


	m_sTempBeamPath.nScannerRing2[0]				=	gVariable.m_sgBeamPath.nScannerRing2[SelectNo+1];
	m_sTempBeamPath.nScannerCoaxial2[0]			=	gVariable.m_sgBeamPath.nScannerCoaxial2[SelectNo+1];
	m_sTempBeamPath.nScannerIR2[0]				=	gVariable.m_sgBeamPath.nScannerIR2[SelectNo+1];

	m_sTempBeamPath.nScannerRing3[0]				=	gVariable.m_sgBeamPath.nScannerRing3[SelectNo+1];
	m_sTempBeamPath.nScannerCoaxial3[0]			=	gVariable.m_sgBeamPath.nScannerCoaxial3[SelectNo+1];
	m_sTempBeamPath.nScannerIR3[0]				=	gVariable.m_sgBeamPath.nScannerIR3[SelectNo+1];

	m_sTempBeamPath.nScannerRing4[0]				=	gVariable.m_sgBeamPath.nScannerRing4[SelectNo+1];
	m_sTempBeamPath.nScannerCoaxial4[0]			=	gVariable.m_sgBeamPath.nScannerCoaxial4[SelectNo+1];
	m_sTempBeamPath.nScannerIR4[0]				=	gVariable.m_sgBeamPath.nScannerIR4[SelectNo+1];




	m_sTempBeamPath.nHoleVisionCam[0]			=	gVariable.m_sgBeamPath.nHoleVisionCam[SelectNo+1] ;
	m_sTempBeamPath.dHoleVisionModelSize[0]		=	gVariable.m_sgBeamPath.dHoleVisionModelSize[SelectNo+1];
	m_sTempBeamPath.nHolePolarity[0]			=	gVariable.m_sgBeamPath.nHolePolarity[SelectNo+1];
	m_sTempBeamPath.dHoleAcceptScoreSize[0]		=	gVariable.m_sgBeamPath.dHoleAcceptScoreSize[SelectNo+1];
	m_sTempBeamPath.dHoleAcceptScoreRatio[0]	=	gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[SelectNo+1];
	m_sTempBeamPath.dHoleContrast[0]			=	gVariable.m_sgBeamPath.dHoleContrast[SelectNo+1];
	m_sTempBeamPath.dHoleBrightness[0]			=	gVariable.m_sgBeamPath.dHoleBrightness[SelectNo+1];
	m_sTempBeamPath.nHoleRing[0]				=	gVariable.m_sgBeamPath.nHoleRing[SelectNo+1];
	m_sTempBeamPath.nHoleCoaxial[0]				=	gVariable.m_sgBeamPath.nHoleCoaxial[SelectNo+1];
	m_sTempBeamPath.nHoleIR[0]				=	gVariable.m_sgBeamPath.nHoleIR[SelectNo+1];

	strcpy_s(m_sTempBeamPath.strInfoName[0],gVariable.m_sgBeamPath.strInfoName[SelectNo+1]);
	strcpy_s( m_sTempBeamPath.strBeamPathAscFile[0] ,gVariable.m_sgBeamPath.strBeamPathAscFile[SelectNo+1]);



	//round2
	//���õ� ���� ��ĭ �Ʒ��� �����Ѵ�. 
	gVariable.m_sgBeamPath.dInfoMaskSize[SelectNo+1]			=	gVariable.m_sgBeamPath.dInfoMaskSize[SelectNo];			
	gVariable.m_sgBeamPath.dBeamPathBetPos1[SelectNo+1]		=	gVariable.m_sgBeamPath.dBeamPathBetPos1[SelectNo];
	gVariable.m_sgBeamPath.dBeamPathBetPos2[SelectNo+1]		=	gVariable.m_sgBeamPath.dBeamPathBetPos2[SelectNo];
	gVariable.m_sgBeamPath.dBeamPathBetPos3[SelectNo+1]		=	gVariable.m_sgBeamPath.dBeamPathBetPos3[SelectNo];
	gVariable.m_sgBeamPath.dBeamPathBetPos4[SelectNo+1]		=	gVariable.m_sgBeamPath.dBeamPathBetPos4[SelectNo];
	gVariable.m_sgBeamPath.nBeamPathMaskPos1[SelectNo+1]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos1[SelectNo];
	gVariable.m_sgBeamPath.nBeamPathMaskPos2[SelectNo+1]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos2[SelectNo];
	gVariable.m_sgBeamPath.nBeamPathMaskPos3[SelectNo+1]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos3[SelectNo];
	gVariable.m_sgBeamPath.nBeamPathMaskPos4[SelectNo+1]		=	gVariable.m_sgBeamPath.nBeamPathMaskPos4[SelectNo];

	gVariable.m_sgBeamPath.dBeamPathRotator[SelectNo+1]		=	gVariable.m_sgBeamPath.dBeamPathRotator[SelectNo];
	gVariable.m_sgBeamPath.dBeamPathTopHat[SelectNo+1]		=	gVariable.m_sgBeamPath.dBeamPathTopHat[SelectNo];

	gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[SelectNo+1]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[SelectNo];
	gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[SelectNo+1]	=	gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[SelectNo];
	gVariable.m_sgBeamPath.dBeamPathZAxisPos1[SelectNo+1]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos1[SelectNo];
	gVariable.m_sgBeamPath.dBeamPathZAxisPos2[SelectNo+1]		=	gVariable.m_sgBeamPath.dBeamPathZAxisPos2[SelectNo]; 
	gVariable.m_sgBeamPath.bBeamPathUseTophat[SelectNo+1]		=	gVariable.m_sgBeamPath.bBeamPathUseTophat[SelectNo];	
	gVariable.m_sgBeamPath.bBeamPathLaserPath[SelectNo+1]		=	gVariable.m_sgBeamPath.bBeamPathLaserPath[SelectNo];
	//gVariable.m_sgBeamPath.bBeamPathUseAom[SelectNo+1]		=	gVariable.m_sgBeamPath.bBeamPathUseAom[SelectNo];
	
	gVariable.m_sgBeamPath.dPowOffsetDuty[SelectNo+1]			=	gVariable.m_sgBeamPath.dPowOffsetDuty[SelectNo];
	
	gVariable.m_sgBeamPath.nSelectShot[SelectNo+1] = gVariable.m_sgBeamPath.nSelectShot[SelectNo];
	gVariable.m_sgBeamPath.nPowCompensationFrequency[SelectNo+1] = gVariable.m_sgBeamPath.nPowCompensationFrequency[SelectNo];
	gVariable.m_sgBeamPath.dPowCompensationDuty[SelectNo+1]	 =	gVariable.m_sgBeamPath.dPowCompensationDuty[SelectNo];
	gVariable.m_sgBeamPath.dPowCompensationTargetMin[SelectNo+1] = gVariable.m_sgBeamPath.dPowCompensationTargetMin[SelectNo];
	gVariable.m_sgBeamPath.dPowCompensationTargetMax[SelectNo+1] = gVariable.m_sgBeamPath.dPowCompensationTargetMax[SelectNo];
	gVariable.m_sgBeamPath.dPowCompensationDutyOffset[SelectNo+1] =gVariable.m_sgBeamPath.dPowCompensationDutyOffset[SelectNo];
	gVariable.m_sgBeamPath.dPowCompensationTarget[SelectNo+1] = gVariable.m_sgBeamPath.dPowCompensationTarget[SelectNo];
	gVariable.m_sgBeamPath.dPowCompensationTargetPercent[SelectNo+1] = gVariable.m_sgBeamPath.dPowCompensationTargetPercent[SelectNo];
	gVariable.m_sgBeamPath.dScannerDuty[SelectNo+1]			=	gVariable.m_sgBeamPath.dScannerDuty[SelectNo];

	gVariable.m_sgBeamPath.dScannerFrq[SelectNo+1]			=	gVariable.m_sgBeamPath.dScannerFrq[SelectNo];

	gVariable.m_sgBeamPath.nScannerTotalShot[SelectNo+1]		=	gVariable.m_sgBeamPath.nScannerTotalShot[SelectNo];
	gVariable.m_sgBeamPath.nScannerVisionCam[SelectNo+1]		=	gVariable.m_sgBeamPath.nScannerVisionCam[SelectNo] ;
	gVariable.m_sgBeamPath.dScannerVisionModelSize[SelectNo+1] =	gVariable.m_sgBeamPath.dScannerVisionModelSize[SelectNo];
	gVariable.m_sgBeamPath.nScannerPolarity[SelectNo+1]		=	gVariable.m_sgBeamPath.nScannerPolarity[SelectNo];
	gVariable.m_sgBeamPath.dScannerAcceptScoreSize[SelectNo+1] =	gVariable.m_sgBeamPath.dScannerAcceptScoreSize[SelectNo];
	gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[SelectNo+1] =	gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[SelectNo];
	gVariable.m_sgBeamPath.dScannerContrast[SelectNo+1]		=	gVariable.m_sgBeamPath.dScannerContrast[SelectNo];
	gVariable.m_sgBeamPath.dScannerBrightness[SelectNo+1]		=	gVariable.m_sgBeamPath.dScannerBrightness[SelectNo];
	gVariable.m_sgBeamPath.nScannerRing[SelectNo+1]			=	gVariable.m_sgBeamPath.nScannerRing[SelectNo];
	gVariable.m_sgBeamPath.nScannerCoaxial[SelectNo+1]		=	gVariable.m_sgBeamPath.nScannerCoaxial[SelectNo];

	gVariable.m_sgBeamPath.nScannerIR[SelectNo+1]		=	gVariable.m_sgBeamPath.nScannerIR[SelectNo];


	gVariable.m_sgBeamPath.nScannerRing2[SelectNo+1]			=	gVariable.m_sgBeamPath.nScannerRing2[SelectNo];
	gVariable.m_sgBeamPath.nScannerCoaxial2[SelectNo+1]		=	gVariable.m_sgBeamPath.nScannerCoaxial2[SelectNo];
	gVariable.m_sgBeamPath.nScannerIR2[SelectNo+1]			=	gVariable.m_sgBeamPath.nScannerIR2[SelectNo];


	gVariable.m_sgBeamPath.nScannerRing3[SelectNo+1]			=	gVariable.m_sgBeamPath.nScannerRing3[SelectNo];
	gVariable.m_sgBeamPath.nScannerCoaxial3[SelectNo+1]		=	gVariable.m_sgBeamPath.nScannerCoaxial3[SelectNo];
	gVariable.m_sgBeamPath.nScannerIR3[SelectNo+1]			=	gVariable.m_sgBeamPath.nScannerIR3[SelectNo];

	gVariable.m_sgBeamPath.nScannerRing4[SelectNo+1]			=	gVariable.m_sgBeamPath.nScannerRing4[SelectNo];
	gVariable.m_sgBeamPath.nScannerCoaxial4[SelectNo+1]		=	gVariable.m_sgBeamPath.nScannerCoaxial4[SelectNo];
	gVariable.m_sgBeamPath.nScannerIR4[SelectNo+1]			=	gVariable.m_sgBeamPath.nScannerIR4[SelectNo];




	gVariable.m_sgBeamPath.nHoleVisionCam[SelectNo+1]		=	gVariable.m_sgBeamPath.nHoleVisionCam[SelectNo] ;
	gVariable.m_sgBeamPath.dHoleVisionModelSize[SelectNo+1] =	gVariable.m_sgBeamPath.dHoleVisionModelSize[SelectNo];
	gVariable.m_sgBeamPath.nHolePolarity[SelectNo+1]		=	gVariable.m_sgBeamPath.nHolePolarity[SelectNo];
	gVariable.m_sgBeamPath.dHoleAcceptScoreSize[SelectNo+1] =	gVariable.m_sgBeamPath.dHoleAcceptScoreSize[SelectNo];
	gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[SelectNo+1] =	gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[SelectNo];
	gVariable.m_sgBeamPath.dHoleContrast[SelectNo+1]		=	gVariable.m_sgBeamPath.dHoleContrast[SelectNo];
	gVariable.m_sgBeamPath.dHoleBrightness[SelectNo+1]		=	gVariable.m_sgBeamPath.dHoleBrightness[SelectNo];
	gVariable.m_sgBeamPath.nHoleRing[SelectNo+1]			=	gVariable.m_sgBeamPath.nHoleRing[SelectNo];
	gVariable.m_sgBeamPath.nHoleCoaxial[SelectNo+1]		=	gVariable.m_sgBeamPath.nHoleCoaxial[SelectNo];
	gVariable.m_sgBeamPath.nHoleIR[SelectNo+1]		=	gVariable.m_sgBeamPath.nHoleIR[SelectNo];

	strcpy_s(gVariable.m_sgBeamPath.strInfoName[SelectNo+1],gVariable.m_sgBeamPath.strInfoName[SelectNo]);
	strcpy_s( gVariable.m_sgBeamPath.strBeamPathAscFile[SelectNo+1] ,gVariable.m_sgBeamPath.strBeamPathAscFile[SelectNo]);




	//round3
	// temp[0]�� ����� ���� ���õ� �׸����� �����Ѵ�.
	gVariable.m_sgBeamPath.dInfoMaskSize[SelectNo]				=	m_sTempBeamPath.dInfoMaskSize[0];			
	gVariable.m_sgBeamPath.dBeamPathBetPos1[SelectNo]			=	m_sTempBeamPath.dBeamPathBetPos1[0];
	gVariable.m_sgBeamPath.dBeamPathBetPos2[SelectNo]			=	m_sTempBeamPath.dBeamPathBetPos2[0];
	gVariable.m_sgBeamPath.dBeamPathBetPos3[SelectNo]			=	m_sTempBeamPath.dBeamPathBetPos3[0];
	gVariable.m_sgBeamPath.dBeamPathBetPos4[SelectNo]			=	m_sTempBeamPath.dBeamPathBetPos4[0];
	gVariable.m_sgBeamPath.nBeamPathMaskPos1[SelectNo]			=	m_sTempBeamPath.nBeamPathMaskPos1[0];
	gVariable.m_sgBeamPath.nBeamPathMaskPos2[SelectNo]			=	m_sTempBeamPath.nBeamPathMaskPos2[0];
	gVariable.m_sgBeamPath.nBeamPathMaskPos3[SelectNo]			=	m_sTempBeamPath.nBeamPathMaskPos3[0];
	gVariable.m_sgBeamPath.nBeamPathMaskPos4[SelectNo]			=	m_sTempBeamPath.nBeamPathMaskPos4[0];

	gVariable.m_sgBeamPath.dBeamPathRotator[SelectNo]			=	m_sTempBeamPath.dBeamPathRotator[0];
	gVariable.m_sgBeamPath.dBeamPathTopHat[SelectNo]			=	m_sTempBeamPath.dBeamPathTopHat[0];

	gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[SelectNo]	=	m_sTempBeamPath.nBeamPathAttenuatePos1[0];
	gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[SelectNo]	=	m_sTempBeamPath.nBeamPathAttenuatePos2[0];
	gVariable.m_sgBeamPath.dBeamPathZAxisPos1[SelectNo]		=	m_sTempBeamPath.dBeamPathZAxisPos1[0];
	gVariable.m_sgBeamPath.dBeamPathZAxisPos2[SelectNo]		=	m_sTempBeamPath.dBeamPathZAxisPos2[0]; 
	gVariable.m_sgBeamPath.bBeamPathUseTophat[SelectNo]		=	m_sTempBeamPath.bBeamPathUseTophat[0];	
	gVariable.m_sgBeamPath.bBeamPathLaserPath[SelectNo]		=	m_sTempBeamPath.bBeamPathLaserPath[0];	
	//gVariable.m_sgBeamPath.bBeamPathUseAom[SelectNo]		=	m_sTempBeamPath.bBeamPathUseAom[0];
	
	
	gVariable.m_sgBeamPath.dPowOffsetDuty[SelectNo]			=	m_sTempBeamPath.dPowOffsetDuty[0];
	
	gVariable.m_sgBeamPath.nSelectShot[SelectNo] = m_sTempBeamPath.nSelectShot[0];
	gVariable.m_sgBeamPath.nPowCompensationFrequency[SelectNo] = m_sTempBeamPath.nPowCompensationFrequency[0];
	gVariable.m_sgBeamPath.dPowCompensationDuty[SelectNo]		=	m_sTempBeamPath.dPowCompensationDuty[0];
	gVariable.m_sgBeamPath.dPowCompensationTargetMin[SelectNo] = m_sTempBeamPath.dPowCompensationTargetMin[0];
	gVariable.m_sgBeamPath.dPowCompensationTargetMax[SelectNo] = m_sTempBeamPath.dPowCompensationTargetMax[0];
	gVariable.m_sgBeamPath.dPowCompensationDutyOffset[SelectNo] =m_sTempBeamPath.dPowCompensationDutyOffset[0];
	gVariable.m_sgBeamPath.dPowCompensationTarget[SelectNo] = m_sTempBeamPath.dPowCompensationTarget[0];
	gVariable.m_sgBeamPath.dPowCompensationTargetPercent[SelectNo] = m_sTempBeamPath.dPowCompensationTargetPercent[0];
	gVariable.m_sgBeamPath.dScannerDuty[SelectNo]				=	m_sTempBeamPath.dScannerDuty[0];

	gVariable.m_sgBeamPath.dScannerFrq[SelectNo]				=	m_sTempBeamPath.dScannerFrq[0];

	gVariable.m_sgBeamPath.nScannerTotalShot[SelectNo]			=	m_sTempBeamPath.nScannerTotalShot[0];
	gVariable.m_sgBeamPath.nScannerVisionCam[SelectNo]			=	m_sTempBeamPath.nScannerVisionCam[0] ;
	gVariable.m_sgBeamPath.dScannerVisionModelSize[SelectNo]	=	m_sTempBeamPath.dScannerVisionModelSize[0];
	gVariable.m_sgBeamPath.nScannerPolarity[SelectNo]			=	m_sTempBeamPath.nScannerPolarity[0];
	gVariable.m_sgBeamPath.dScannerAcceptScoreSize[SelectNo]	=	m_sTempBeamPath.dScannerAcceptScoreSize[0];
	gVariable.m_sgBeamPath.dScannerAcceptScoreRatio[SelectNo]	=	m_sTempBeamPath.dScannerAcceptScoreRatio[0];
	gVariable.m_sgBeamPath.dScannerContrast[SelectNo]			=	m_sTempBeamPath.dScannerContrast[0];
	gVariable.m_sgBeamPath.dScannerBrightness[SelectNo]		=	m_sTempBeamPath.dScannerBrightness[0];
	gVariable.m_sgBeamPath.nScannerRing[SelectNo]				=	m_sTempBeamPath.nScannerRing[0];
	gVariable.m_sgBeamPath.nScannerCoaxial[SelectNo]			=	m_sTempBeamPath.nScannerCoaxial[0];

	gVariable.m_sgBeamPath.nScannerIR[SelectNo]			=	m_sTempBeamPath.nScannerIR[0];


	gVariable.m_sgBeamPath.nScannerRing2[SelectNo]				=	m_sTempBeamPath.nScannerRing2[0];
	gVariable.m_sgBeamPath.nScannerCoaxial2[SelectNo]			=	m_sTempBeamPath.nScannerCoaxial2[0];
	gVariable.m_sgBeamPath.nScannerIR2[SelectNo]				=	m_sTempBeamPath.nScannerIR2[0];


	gVariable.m_sgBeamPath.nScannerRing3[SelectNo]				=	m_sTempBeamPath.nScannerRing3[0];
	gVariable.m_sgBeamPath.nScannerCoaxial3[SelectNo]			=	m_sTempBeamPath.nScannerCoaxial3[0];
	gVariable.m_sgBeamPath.nScannerIR3[SelectNo]				=	m_sTempBeamPath.nScannerIR3[0];

	gVariable.m_sgBeamPath.nScannerRing4[SelectNo]				=	m_sTempBeamPath.nScannerRing4[0];
	gVariable.m_sgBeamPath.nScannerCoaxial4[SelectNo]			=	m_sTempBeamPath.nScannerCoaxial4[0];
	gVariable.m_sgBeamPath.nScannerIR4[SelectNo]				=	m_sTempBeamPath.nScannerIR4[0];



	gVariable.m_sgBeamPath.nHoleVisionCam[SelectNo]			=	m_sTempBeamPath.nHoleVisionCam[0] ;
	gVariable.m_sgBeamPath.dHoleVisionModelSize[SelectNo]		=	m_sTempBeamPath.dHoleVisionModelSize[0];
	gVariable.m_sgBeamPath.nHolePolarity[SelectNo]				=	m_sTempBeamPath.nHolePolarity[0];
	gVariable.m_sgBeamPath.dHoleAcceptScoreSize[SelectNo]		=	m_sTempBeamPath.dHoleAcceptScoreSize[0];
	gVariable.m_sgBeamPath.dHoleAcceptScoreRatio[SelectNo]		=	m_sTempBeamPath.dHoleAcceptScoreRatio[0];
	gVariable.m_sgBeamPath.dHoleContrast[SelectNo]				=	m_sTempBeamPath.dHoleContrast[0];
	gVariable.m_sgBeamPath.dHoleBrightness[SelectNo]			=	m_sTempBeamPath.dHoleBrightness[0];
	gVariable.m_sgBeamPath.nHoleRing[SelectNo]					=	m_sTempBeamPath.nHoleRing[0];
	gVariable.m_sgBeamPath.nHoleCoaxial[SelectNo]				=	m_sTempBeamPath.nHoleCoaxial[0];
	gVariable.m_sgBeamPath.nHoleIR[SelectNo]					=	m_sTempBeamPath.nHoleIR[0];

	strcpy_s(gVariable.m_sgBeamPath.strInfoName[SelectNo],m_sTempBeamPath.strInfoName[0]);
	strcpy_s( gVariable.m_sgBeamPath.strBeamPathAscFile[SelectNo] ,m_sTempBeamPath.strBeamPathAscFile[0]);


	m_ClickID = FALSE;
	OnCheckRefresh();
	InitDataStruct();		// �ӽ� ����ü �ʱ�ȭ 
}

void CDlgBeamPathTable::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	
	CDialog::OnDestroy();
}

void CDlgBeamPathTable::SetCurrentScrollPos(int xPos, int yPos)
{
	CRect rectCell;
	m_list.GetSubItemRect(yPos, xPos, LVIR_BOUNDS, rectCell);

	CSize size;
	if(yPos <25)
		size.cy = 0;
	else
		size.cy = yPos* rectCell.Height();	
	
	if(xPos <10 )
		size.cx = 0;
	else if( xPos < 20)
		size.cx = xPos*30;
	else
		size.cx = xPos*50;
	
	if(m_list.Scroll(size))
	{
		m_list.SetItemState(m_posClicked.y,LVIS_SELECTED,LVIS_SELECTED);  
	}
}

int CDlgBeamPathTable::GetShowBoxMode(int nXPos)
{
	int listcount = GetListIndex();

	if(listcount == 0)
	{
		return 0;
	}
	else if(listcount == 1) //1
	{
		return 0;
	}
	else if(listcount ==2 )  //2
	{
		if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else return 0;
	}
	else if(listcount ==4) //4
	{
		return 0;
	}
	else if(listcount == 8) //8
	{
		return 0;	
	}
	else if( listcount == 16) //16
	{
		if(nXPos == TABLE4_COLUMN_COUNT - POLARITY_POSITION  - 1)
			return 2;
		else if(nXPos == TABLE4_COLUMN_COUNT - VISION_POSION  - 1)
			return 3;
		else
			return 0;
	}

	else if(listcount == 3) //1,2
	{
	
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else return 0;			
	}

	else if(listcount ==5) //1,4
	{
		return 0;
	}
	else if(listcount ==9) //1,8
	{
		return 0;
	}
	else if(listcount == 17) //1,16
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION  - 1)
			return 2;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION - 1)
			return 3;
		else
			return 0;
	}
	else if(listcount == 7)  //1,2,4
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else return 0;	
	}
	else if(listcount ==11)//1,2,8
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else return 0;	
	}
	else if(listcount == 19)//1,2,16
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION - 1)
			return 2;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION - 1)
			return 3;
		else
			return 0;	

	}

	else if(listcount == 13)//1,4.8
	{
		return 0;
	}
	else if(listcount == 21) //1,4,16
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION - 1)
			return 2;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION - 1)
			return 3;
		else 
			return 0;
	}
	else if(listcount == 25) //1,8,16
	{
	if(nXPos == TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
		return 2;
	else if(nXPos == TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION -1)
		return 3;
	else 
		return 0;
	}

	else if(listcount == 15) //1,2,4,8
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else return 0;
	}

	else if(listcount ==23) //1,2,4,16
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT  +TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
			return 2;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT  +TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION -1)
			return 3;
		else 
			return 0;
	}

	else if(listcount ==27) //1,2,8,16
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT  +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
			return 2;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT  +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION -1)
			return 3;
		else
			return 0;
	}
	else if(listcount == 29)// 1,4,8,16
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT  +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
			return 2;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT  +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION -1)
			return 3;
		else 
			return 0;
	}
	else if(listcount == 31) //1,2,4,8,16
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT+TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
			return 2;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT+TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION -1)
			return 3;
		else 
			return 0;
	}

	// start 2
	else if(listcount == 6) //2,4
	{
	if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION -1)
		return 1;
	else return 0;
	}
	else if(listcount == 10)	//2,8
	{
		if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION -1)
			return 1;
		else return 0;
	}

	else if(listcount == 18) //2,16
	{
		if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION -1)
			return 1;
		else if(nXPos ==TABLE1_COLUMN_COUNT+TABLE4_COLUMN_COUNT - POLARITY_POSITION - 1 )
			return 2;
		else if(nXPos ==TABLE1_COLUMN_COUNT+TABLE4_COLUMN_COUNT - VISION_POSION - 1 )
			return 3;
		else
			return 0;
	}

	else if(listcount == 14) //2,4,8
	{
		if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION -1)
			return 1;
		else return 0;
	}

	else if(listcount == 22) //2,4,16
	{
		if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION -1)
			return 1;
		else if(nXPos == TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT+TABLE4_COLUMN_COUNT - POLARITY_POSITION - 1)
			return 2;
		else if(nXPos == TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT+TABLE4_COLUMN_COUNT - VISION_POSION - 1)
			return 3;
		else return 0;
	}
	else if(listcount == 26) //2,8,16
	{
		if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION -1)
			return 1;
		else if(nXPos == TABLE1_COLUMN_COUNT+TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - POLARITY_POSITION - 1)
			return 2;
		else if(nXPos == TABLE1_COLUMN_COUNT+TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - VISION_POSION - 1)
			return 3;
		else return 0;
	}

	else if(listcount == 30) //2,4,8,16
	{
		if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION -1)
			return 1;
		else if(nXPos == TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT+TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - POLARITY_POSITION - 1)
			return 2;
		else if(nXPos == TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT+TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - VISION_POSION - 1)
			return 3;
		else return 0;
	}

	//start 4
	else if(listcount == 12)	//4,8
	{
		return 0;
	}
	else if(listcount == 20) //4,16
	{
		if(nXPos == TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
			return 2;
		else if(nXPos == TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION -1)
			return 3;
		else 
			return 0;
	}
	else if(listcount == 28) //4,8,16
	{
		if(nXPos == TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
			return 2;
		else if(nXPos == TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - VISION_POSION -1)
			return 3;
		else 
			return 0;
	}

	//start 8	//8,16
	else if(listcount == 24)
	{
		if(nXPos == TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
			return 2;
		else if(nXPos == TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - VISION_POSION -1)
			return 3;
		else
			return 0;
	}

	return TRUE;
}

void CDlgBeamPathTable::OnNMCustomdrawListTest(NMHDR *pNMHDR, LRESULT *pResult)  //����ֱ� �κ�..
{
	NMLVCUSTOMDRAW* pLVCD = reinterpret_cast<NMLVCUSTOMDRAW*>( pNMHDR );
	COLORREF clrNewTextColor, clrNewBkColor;   

    *pResult = CDRF_DODEFAULT;
	
	if ( CDDS_PREPAINT == pLVCD->nmcd.dwDrawStage )
	{
        *pResult = CDRF_NOTIFYITEMDRAW;
	}
    else if ( CDDS_ITEMPREPAINT == pLVCD->nmcd.dwDrawStage )
	{	
        *pResult = CDRF_NOTIFYSUBITEMDRAW;
	}
    else if ( (CDDS_ITEMPREPAINT | CDDS_SUBITEM) == pLVCD->nmcd.dwDrawStage )
	{		   

		int listcount = GetListIndex();

		int xPos = pLVCD->iSubItem;

		if(listcount == 0)
		{	
			clrNewTextColor =TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if(listcount == 1) //1
		{
			clrNewTextColor = TABLETEXT_COLOR;   		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if(listcount ==2 )  //2
		{
			clrNewTextColor = TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if(listcount ==4) //4
		{
			clrNewTextColor = TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if(listcount == 8) //8
		{
			clrNewTextColor =TABLETEXT_COLOR;     		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if( listcount == 16) //16
		{
			clrNewTextColor = TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;     
		}

		else if(listcount == 3) //1,2
		{
			clrNewTextColor = TABLETEXT_COLOR;   		
			clrNewBkColor = TABLE1_COLOR;    			
		}

		else if(listcount ==5) //1,4
		{
			clrNewTextColor = TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;    
		}
		else if(listcount ==9) //1,8
		{
			clrNewTextColor = TABLETEXT_COLOR;     		
			clrNewBkColor = TABLE1_COLOR;    
		}
		else if(listcount == 17) //1,16
		{
			clrNewTextColor = TABLETEXT_COLOR;     		
			clrNewBkColor = TABLE1_COLOR;    
		}
		else if(listcount == 7)  //1,2,4
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE1_COLOR;     
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else
			{
				clrNewTextColor =TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR; 
			}
		}
		else if(listcount ==11)//1,2,8
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;    		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT+ TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE2_COLOR;  
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;  
			}
		}
		else if(listcount == 19)//1,2,16
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT+ TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR  ;   		
				clrNewBkColor = TABLE2_COLOR;  
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE5_COLOR;  
			}

		}

		else if(listcount == 13)//1,4.8
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor =TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE3_COLOR; 
			}
			else
			{
				clrNewTextColor =TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE4_COLOR; 
			}
		}
		else if(listcount == 21) //1,4,16
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor =TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE3_COLOR; 
			}
			else
			{
				clrNewTextColor =TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE5_COLOR; 
			}
		}
		else if(listcount == 25) //1,8,16
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR  ;   		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   	
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}

		else if(listcount == 15) //1,2,4,8
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE4_COLOR;   
			}
		}

		else if(listcount ==23) //1,2,4,16
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}

		else if(listcount ==27) //1,2,8,16
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE3_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE5_COLOR;   
			}

		}
		else if(listcount == 29)// 1,4,8,16
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else if( TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
			{
					clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}
		else if(listcount == 31) //1,2,4,8,16
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if( TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else if( TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE4_COLOR;   
			}
			else 
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}

		// start 2
		else if(listcount == 6) //2,4
		{
			if(xPos < TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
		}
		else if(listcount == 10)	//2,8
		{
			if(xPos < TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   
			}
		}

		else if(listcount == 18) //2,16
		{
			if(xPos < TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}

		else if(listcount == 14) //2,4,8
		{
			if(xPos < TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE4_COLOR;   
			}
		}

		else if(listcount == 22) //2,4,16
		{
			if(xPos < TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}
		else if(listcount == 26) //2,8,16
		{
			if(xPos < TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR  ;   		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}

		else if(listcount == 30) //2,4,8,16
		{
			if(xPos < TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else if(TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}

		}

		//start 4
		else if(listcount == 12)	//4,8
		{

			if(xPos < TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   
			}

		}
		else if(listcount == 20) //4,16
		{
			if(xPos < TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}

		else if(listcount == 28) //4,8,16
		{
			if(xPos < TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else if(TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   	
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}

		//start 8	//8,16
		else if(listcount == 24)
		{
			if(xPos <TABLE3_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}

		}
		pLVCD->clrText = clrNewTextColor;
		pLVCD->clrTextBk = clrNewBkColor;     
        *pResult = CDRF_DODEFAULT;  
	}

}

void CDlgBeamPathTable::CheckAnyDoPrework()
{
	BOOL bPowerChange = FALSE, bScalChange = FALSE;
	if(gVariable.m_sgBeamPath.nFixedMask != gBeamPathINI.m_sBeampath.nFixedMask)
	{
		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER + DO_SCANNER));
		bPowerChange = TRUE; bScalChange = TRUE;
	}

	for(int i = 0; i < m_nRepeatCount; i++)
	{
		if(gVariable.m_sgBeamPath.dBeamPathBetPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1[i]||
		gVariable.m_sgBeamPath.dBeamPathBetPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2[i]||
		gVariable.m_sgBeamPath.dBeamPathBetPos3[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos3[i]||
		gVariable.m_sgBeamPath.dBeamPathBetPos4[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos4[i]||
		gVariable.m_sgBeamPath.nBeamPathMaskPos1[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[i]||
		gVariable.m_sgBeamPath.nBeamPathMaskPos2[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[i]||
		gVariable.m_sgBeamPath.nBeamPathMaskPos3[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[i]||
		gVariable.m_sgBeamPath.nBeamPathMaskPos4[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos4[i]||

		gVariable.m_sgBeamPath.dBeamPathRotator[i] != gBeamPathINI.m_sBeampath.dBeamPathRotator[i]||
		gVariable.m_sgBeamPath.dBeamPathTopHat[i] != gBeamPathINI.m_sBeampath.dBeamPathTopHat[i]||

		gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[i] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[i]||
		gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[i] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[i]||
		gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i]||
		gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i]||
		gVariable.m_sgBeamPath.bBeamPathUseTophat[i] != gBeamPathINI.m_sBeampath.bBeamPathUseTophat[i]||
		gVariable.m_sgBeamPath.bBeamPathLaserPath[i] != gBeamPathINI.m_sBeampath.bBeamPathLaserPath[i]||
		//gVariable.m_sgBeamPath.bBeamPathUseAom[i] != gBeamPathINI.m_sBeampath.bBeamPathUseAom[i]||
		
		
		gVariable.m_sgBeamPath.dPowOffsetDuty[i] != gBeamPathINI.m_sBeampath.dPowOffsetDuty[i]||
		
		gVariable.m_sgBeamPath.nSelectShot[i] != gBeamPathINI.m_sBeampath.nSelectShot[i]||
		gVariable.m_sgBeamPath.nPowCompensationFrequency[i] != gBeamPathINI.m_sBeampath.nPowCompensationFrequency[i]||
		gVariable.m_sgBeamPath.dPowCompensationDuty[i] != gBeamPathINI.m_sBeampath.dPowCompensationDuty[i]||
		gVariable.m_sgBeamPath.dPowCompensationTargetMax[i] != gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[i]||
		gVariable.m_sgBeamPath.dPowCompensationTargetMin[i] != gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[i]||
		gVariable.m_sgBeamPath.dPowCompensationDutyOffset[i] != gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[i]||
		gVariable.m_sgBeamPath.dPowCompensationTarget[i] != gBeamPathINI.m_sBeampath.dPowCompensationTarget[i]||
		gVariable.m_sgBeamPath.dPowCompensationTargetPercent[i] != gBeamPathINI.m_sBeampath.dPowCompensationTargetPercent[i])
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER));
			bPowerChange = TRUE;
		}

		if(gVariable.m_sgBeamPath.dBeamPathBetPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1[i]||
			gVariable.m_sgBeamPath.dBeamPathBetPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2[i]||
			gVariable.m_sgBeamPath.dBeamPathBetPos3[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos3[i]||
			gVariable.m_sgBeamPath.dBeamPathBetPos4[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos4[i]||
			gVariable.m_sgBeamPath.nBeamPathMaskPos1[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[i]||
			gVariable.m_sgBeamPath.nBeamPathMaskPos2[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[i]||
			gVariable.m_sgBeamPath.nBeamPathMaskPos3[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[i]||
			gVariable.m_sgBeamPath.nBeamPathMaskPos4[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos4[i]||

			gVariable.m_sgBeamPath.dBeamPathRotator[i] != gBeamPathINI.m_sBeampath.dBeamPathRotator[i]||
			gVariable.m_sgBeamPath.dBeamPathTopHat[i] != gBeamPathINI.m_sBeampath.dBeamPathTopHat[i]||

			gVariable.m_sgBeamPath.nBeamPathAttenuatePos1[i] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[i]||
			gVariable.m_sgBeamPath.nBeamPathAttenuatePos2[i] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[i]||
			gVariable.m_sgBeamPath.dBeamPathZAxisPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i]||
			gVariable.m_sgBeamPath.dBeamPathZAxisPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i]||
			gVariable.m_sgBeamPath.bBeamPathLaserPath[i] != gBeamPathINI.m_sBeampath.bBeamPathLaserPath[i]||
			/*gVariable.m_sgBeamPath.bBeamPathUseAom[i] != gBeamPathINI.m_sBeampath.bBeamPathUseAom[i]||*/			
			gVariable.m_sgBeamPath.bBeamPathUseTophat[i] != gBeamPathINI.m_sBeampath.bBeamPathUseTophat[i])
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)DO_SCANNER);
			bScalChange = TRUE;
		}
		
		if(strcmp( gVariable.m_sgBeamPath.strBeamPathAscFile[i] , gBeamPathINI.m_sBeampath.strBeamPathAscFile[i]) !=0)
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)DO_SCANNER);
			bScalChange = TRUE;
		}
	}
	OnCheckRefresh();
	if(bPowerChange)
	{
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (CPaneSysSetupBeamPathPusan1) : P"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
	if(bScalChange)
	{
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (CPaneSysSetupBeamPathPusan1) : S"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}

}

BOOL CDlgBeamPathTable::CheckApply()
{
	for(int i = 0; i<= m_nRepeatCount; i++)
	{
		if(gVariable.m_sgBeamPath.dPowOffsetAomDual1[i] + gVariable.m_sgBeamPath.dPowOffsetAomDual2[i] != 100)
		{
			AfxMessageBox(_T("Please insert aom percentage total 100"));
			return FALSE;
		}	
	}
	return TRUE;
}

void CDlgBeamPathTable::GetCurrentASC()
{
	int nIndex = gVariable.m_sgBeamPath.nLastIndex;
	CString str;
	for(int i = 0; i <= nIndex; i++)
	{
		str = m_Grid.GetItemText( i+1,TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - 1);
		FillTable1Data(TABLE1_COLUMN_COUNT - 1, i, str);
	}
}

void CDlgBeamPathTable::CellDisable(int y)
{
	for(int x = 0; x < m_Grid.GetRowCount(); x++)
		m_Grid.SetItemState(x, y, m_Grid.GetItemState(x,y) | GVIS_READONLY);
}


void CDlgBeamPathTable::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;
	switch(nLevel)
	{
	case 0:
	case 1:
		EnableControl(FALSE);
		break;
	case 2:
	case 3:
		EnableControl(TRUE);
		break;
	}
}
void CDlgBeamPathTable::EnableControl(BOOL bEnable)
{
	//m_Grid.EnableWindow(bEnable);
	//m_btnAdd.EnableWindow(bEnable);
	//m_btnDel.EnableWindow(bEnable);
	//m_chkBeamPath.EnableWindow(bEnable);
	//m_chkPowerOffset.EnableWindow(bEnable);
	//m_chkPowerCompensation.EnableWindow(bEnable);
	//m_chkScannerFact.EnableWindow(bEnable);


	//for(int i = 1 ; i < 6; i++)
	//{
	/*	if((i == 5 || i == 4) && m_nUserLevel == 2)
		{
			m_ChkSubBox[i].SetCheck(FALSE);
			m_ChkSubBox[i].EnableWindow(FALSE);
			continue;
		}
		*/
		//m_ChkSubBox[i].EnableWindow(bEnable);

	//}
}

void CDlgBeamPathTable::OnBnClickedButtonShotEdit()
{

	//for(int a = 0; a <= gToolTableINI.m_sToolTable.nLastIndex; a++)
	//	gVariable.m_sgToolTable.nSelectShot[a] = gToolTableINI.m_sToolTable.nSelectShot[a];


	CDlgShotTable dlg;

	dlg.SetShotGroupTable(gShotTableINI.m_sShotGroupTable);
	dlg.SetAuthorityByLevel(m_nUserLevel);
	if(dlg.DoModal() == IDOK)
	{

	}

	/*if(dlg.m_bDeleteAndSaveClick)
	{
		for(int a = 0; a <= gToolTableINI.m_sToolTable.nLastIndex; a++)
		{
			gToolTableINI.m_sToolTable.nSelectShot[a] = gVariable.m_sgToolTable.nSelectShot[a];
			m_sToolTable.nSelectShot[a] = gVariable.m_sgToolTable.nSelectShot[a];
		}
	}*/

	OnCheckRefresh();
	//if(dlg.m_bDeleteAndSaveClick)
	//	OnBnClickedButtonToolSet();
}
void CDlgBeamPathTable::OnBnClickedBtnSave()
{
	CString strBeamPath = GetChangeValueStr();

	CheckAnyDoPrework();
	SaveChangeValue();
	GetBeamPath( &gBeamPathINI.m_sBeampath );

	CString strMessage,strDumper;

	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_DO_CHAGNE_SCAL_PREWORK);
	if(0 != strBeamPath.CompareNoCase(""))
	{
		strMessage.Format(_T("BeamPath Save "));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<WPARAM>(&strDumper));
	}
//	if(m_bDelClick)
		m_bDeleteAndSaveClick = TRUE;

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, BEAMPATH_INI))
	{
		ErrMsgDlg(STDGNALM114);
	}
	else
	{
		ErrMessage(IDS_DATA_CHANGED);
	}


	memcpy( &gVariable.m_sgShotGroupTable, &gShotTableINI.m_sShotGroupTable, sizeof(gVariable.m_sgShotGroupTable) );	
	memcpy( &gVariable.m_sgBeamPath, &gBeamPathINI.m_sBeampath, sizeof(gVariable.m_sgBeamPath) );	
	
}


void CDlgBeamPathTable::OnBnClickedBtnCancel()
{
		::AfxGetMainWnd()->SendMessage(UM_REDRAW_TABLE_DATA);//20170929
	OnCancel();
}
#if !defined(AFX_DLGCOMSETUP_H__C62C2504_EA68_42D5_A11A_B28F5E954F56__INCLUDED_)
#define AFX_DLGCOMSETUP_H__C62C2504_EA68_42D5_A11A_B28F5E954F56__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgComSetup.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgComSetup dialog

#include "ColorEdit.h"

class CDlgComSetup : public CDialog
{
// Construction
public:
	void SetMode(int nMode);
	CDlgComSetup(CWnd* pParent = NULL);   // standard constructor

	// Member Function List
	void		Init_Control();
	void		SavePortInfo();

	void		SetComPortData(SCOMPORT* psComPort);
	void		GetComPortData(SCOMPORT* psComPort);
	//SCOMPORT	GetComPortData()	{ return m_sComPort; }

	// COM PORT STRUCT
	SCOMPORT		m_sComPort;
	int				m_nMode;
// Dialog Data
	//{{AFX_DATA(CDlgComSetup)
	enum { IDD = IDD_COM_SETUP_DLG };
	CColorEdit	m_edtTimeOut;
	CComboBox	m_cmbFlowControl;
	CComboBox	m_cmbStopbit;
	CComboBox	m_cmbParity;
	CComboBox	m_cmbDatabit;
	CComboBox	m_cmbBaudRate;
	CComboBox	m_cmbPort;
	UINT	m_nTimeOut;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgComSetup)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgComSetup)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCOMSETUP_H__C62C2504_EA68_42D5_A11A_B28F5E954F56__INCLUDED_)

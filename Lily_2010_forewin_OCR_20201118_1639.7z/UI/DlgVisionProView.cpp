// DlgVisionProView.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgVisionProView.h"
#include "..\device\hvision.h"
#include "..\device\HDeviceFactory.h"
#include "PaneHV1.h"
#include "PaneHV2.h"
#include "PaneLV1.h"
#include "PaneLV2.h"
#include "..\EasyDrillerDlg.h"
#include "PaneManualControl.h"
#include "PaneManualControlScannerCalibration.h"
#include "PaneManualControlVision.h"
#include "PaneRecipeGen.h"
#include "PaneRecipeGenFiducialNew.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const UINT UM_VISION_ROI_SET		= WM_APP + 60;

/////////////////////////////////////////////////////////////////////////////
// CDlgVisionProView dialog


CDlgVisionProView::CDlgVisionProView(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgVisionProView::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgVisionProView)
		// NOTE: the ClassWizard will add member initialization here
	m_bTopMost = FALSE;
	m_bInit = FALSE;
	m_nCamNo = 0;
	//}}AFX_DATA_INIT
}


void CDlgVisionProView::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgVisionProView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgVisionProView, CDialog)
	//{{AFX_MSG_MAP(CDlgVisionProView)
	ON_WM_DESTROY()
	ON_WM_MOVE()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_MOUSEWHEEL()
	ON_MESSAGE(UM_VISION_ROI_SET, SetROI)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgVisionProView message handlers

BOOL CDlgVisionProView::Create(CWnd* pParentWnd) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::Create(IDD, pParentWnd);
}

BOOL CDlgVisionProView::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	InitTabControl();

	GetDlgItem(IDC_STATIC_SUB_PANEL_VISION)->ShowWindow(SW_HIDE);
	// TODO: Add extra initialization here
/*	gVPro.SetDisplayWindow( 0, GetDlgItem(IDC_VISIONPRO_1H) );
	gVPro.SetDisplayWindow( 1, GetDlgItem(IDC_VISIONPRO_1L) );
	gVPro.SetDisplayWindow( 2, GetDlgItem(IDC_VISIONPRO_2H) );
	gVPro.SetDisplayWindow( 3, GetDlgItem(IDC_VISIONPRO_2L) );
*/	
	m_bInit = TRUE;
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgVisionProView::SetPanelNo(int nNo)
{

}

void CDlgVisionProView::ShowSelectCamera(int nCamNo)
{
	if(nCamNo < 0 || nCamNo > 3)
		return;

	m_nCamNo = nCamNo;

	if(nCamNo == 0)
	{
		m_pHighVision1->ShowWindow(TRUE);
		m_pLowVision1->ShowWindow(FALSE);
		m_pHighVision2->ShowWindow(FALSE);
		m_pLowVision2->ShowWindow(FALSE);
//		GetDlgItem(IDC_VISIONPRO_1H)->SetFocus();
	}
	else if(nCamNo == 1)
	{
		m_pHighVision1->ShowWindow(FALSE);
		m_pLowVision1->ShowWindow(TRUE);
		m_pHighVision2->ShowWindow(FALSE);
		m_pLowVision2->ShowWindow(FALSE);
	}
	else if(nCamNo == 2)
	{
		m_pHighVision1->ShowWindow(FALSE);
		m_pLowVision1->ShowWindow(FALSE);
		m_pHighVision2->ShowWindow(TRUE);
		m_pLowVision2->ShowWindow(FALSE);
	}
	else
	{
		m_pHighVision1->ShowWindow(FALSE);
		m_pLowVision1->ShowWindow(FALSE);
		m_pHighVision2->ShowWindow(FALSE);
		m_pLowVision2->ShowWindow(TRUE);
	}

}

void CDlgVisionProView::InitTabControl()
{
	CFormView* pPane = NULL;
	CRect rcPanePos;
	
	GetDlgItem(IDC_STATIC_SUB_PANEL_VISION)->GetWindowRect( rcPanePos );
	ScreenToClient( &rcPanePos );

	CWnd* pWnd	= DYNAMIC_DOWNCAST( CWnd, RUNTIME_CLASS(CPaneHV1)->CreateObject() );		
	pWnd->Create( NULL, NULL, WS_CHILD, CRect(0,0,0,0), this, 0x01, NULL );
	pPane	= DYNAMIC_DOWNCAST( CFormView, pWnd );
	
	CSize szSize = pPane->GetTotalSize();
	CRect rcPane;
	
	rcPane.top		= rcPanePos.top;
	rcPane.left		= rcPanePos.left;
	rcPane.right	= rcPanePos.left + szSize.cx;
	rcPane.bottom	= rcPanePos.top + szSize.cy;
	
	pPane->MoveWindow( rcPane );
	
	m_pHighVision1 = DYNAMIC_DOWNCAST( CPaneHV1, pPane );
	m_pHighVision1->OnInitialUpdate();
	//----------------------------------------------------


	CFormView* pPane2 = NULL;
	
	CWnd* pWnd2	= DYNAMIC_DOWNCAST( CWnd, RUNTIME_CLASS(CPaneLV1)->CreateObject() );		
	pWnd2->Create( NULL, NULL, WS_CHILD, CRect(0,0,0,0), this, 0x01, NULL );
	pPane2	= DYNAMIC_DOWNCAST( CFormView, pWnd2 );
	
	pPane2->MoveWindow( rcPane );
	
	m_pLowVision1 = DYNAMIC_DOWNCAST( CPaneLV1, pPane2 );
	m_pLowVision1->OnInitialUpdate();

	//-------------------------------------
	CFormView* pPane3 = NULL;
	
	CWnd* pWnd3	= DYNAMIC_DOWNCAST( CWnd, RUNTIME_CLASS(CPaneHV2)->CreateObject() );		
	pWnd3->Create( NULL, NULL, WS_CHILD, CRect(0,0,0,0), this, 0x01, NULL );
	pPane3	= DYNAMIC_DOWNCAST( CFormView, pWnd3 );
	
	pPane3->MoveWindow( rcPane );
	
	m_pHighVision2 = DYNAMIC_DOWNCAST( CPaneHV2, pPane3 );
	m_pHighVision2->OnInitialUpdate();

	//-------------------------------------
	CFormView* pPane4 = NULL;
	
	CWnd* pWnd4	= DYNAMIC_DOWNCAST( CWnd, RUNTIME_CLASS(CPaneLV2)->CreateObject() );		
	pWnd4->Create( NULL, NULL, WS_CHILD, CRect(0,0,0,0), this, 0x01, NULL );
	pPane4	= DYNAMIC_DOWNCAST( CFormView, pWnd4 );
	
	pPane4->MoveWindow( rcPane );
	
	m_pLowVision2 = DYNAMIC_DOWNCAST( CPaneLV2, pPane4 );
	m_pLowVision2->OnInitialUpdate();

	m_pHighVision1->ShowWindow(TRUE);
}

void CDlgVisionProView::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
}

void CDlgVisionProView::OnMove(int x, int y) 
{
	CDialog::OnMove(x, y);
	
	// TODO: Add your message handler code here
	if(m_bTopMost)
		::SetWindowPos(GetSafeHwnd(), HWND_TOPMOST, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOREDRAW);
	else
		::SetWindowPos(GetSafeHwnd(), HWND_NOTOPMOST, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOREDRAW);
}

void CDlgVisionProView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CDialog::OnLButtonDblClk(nFlags, point);
}

BOOL CDlgVisionProView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	// TODO: Add your message handler code here and/or call default
	/*
	switch( nFlags )
	{
	case MK_CONTROL :
		if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pScannerCalibration->m_chkInspArea.GetCheck() ||
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->m_pFiducialNew->m_chkSetROI.GetCheck() ||
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pVision->m_chkInspArea.GetCheck() )
		{
			if(zDelta >= WHEEL_DELTA) // 20130411 ��� �׽�Ʈ �� �����ϱ�� ��
			{
				this->SendMessage(UM_VISION_ROI_SET, (int)gVPro.m_SearchAreach[0]+1, HIGH_1ST_CAM);
				this->SendMessage(UM_VISION_ROI_SET, (int)gVPro.m_SearchAreach[1]+1, LOW_1ST_CAM);
				this->SendMessage(UM_VISION_ROI_SET, (int)gVPro.m_SearchAreach[2]+1, HIGH_2ND_CAM);
				this->SendMessage(UM_VISION_ROI_SET, (int)gVPro.m_SearchAreach[3]+1, LOW_2ND_CAM);
				gDeviceFactory.GetVision()->ShowArea(2, MODEL_CIRCLE, m_nCamNo);
			}
			else
			{
				this->SendMessage(UM_VISION_ROI_SET, (int)gVPro.m_SearchAreach[0]-1, HIGH_1ST_CAM);
				this->SendMessage(UM_VISION_ROI_SET, (int)gVPro.m_SearchAreach[1]-1, LOW_1ST_CAM);
				this->SendMessage(UM_VISION_ROI_SET, (int)gVPro.m_SearchAreach[2]-1, HIGH_2ND_CAM);
				this->SendMessage(UM_VISION_ROI_SET, (int)gVPro.m_SearchAreach[3]-1, LOW_2ND_CAM);
				gDeviceFactory.GetVision()->ShowArea(2, MODEL_CIRCLE, m_nCamNo);
			}
		}
	}*/
	return CDialog::OnMouseWheel(nFlags, zDelta, pt);
}

void CDlgVisionProView::ReSize(CRect rc)
{
	if(!m_bInit)
		return;

	m_pHighVision1->MoveWindow( &rc);
	m_pLowVision1->MoveWindow( &rc);
	m_pHighVision2->MoveWindow( &rc);
	m_pLowVision2->MoveWindow( &rc);
}

LRESULT CDlgVisionProView::SetROI(WPARAM wParam, LPARAM lParam)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->SetInspectionArea((int)wParam, (int)lParam);
	return 1L;
}
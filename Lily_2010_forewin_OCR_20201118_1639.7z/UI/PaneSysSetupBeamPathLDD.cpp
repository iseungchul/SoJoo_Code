// PaneSysSetupBeamPathPusan1.cpp: implementation of the CPaneSysSetupBeamPathLDD class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSysSetupBeamPathLDD.h"
#include "..\model\DBeampathINI.h"
#include "..\EasyDrillerDlg.h"
#include "PaneAutoRun.h"
#include "GridCtrl.h"

#define		USETOPHAT_POSITION	 1 
#define		POLARITY_POSITION	 2
#define		VISION_POSION		 6 

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


IMPLEMENT_DYNCREATE(CPaneSysSetupBeamPathLDD, CFormView)

CPaneSysSetupBeamPathLDD::CPaneSysSetupBeamPathLDD()
	: CFormView(CPaneSysSetupBeamPathLDD::IDD)
{
	//{{AFX_DATA_INIT(CPaneSysSetupBeamPath)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	//memset( &m_sSystemCollimator, 0, sizeof(m_sSystemCollimator) );

	m_bInfoCheck = FALSE;
	m_bBeamPathCheck = FALSE;
	m_bPowerOffsetCheck = FALSE;
	m_bpowerCompensationCheck = FALSE;
	m_bScannerFactCheck = FALSE;

	m_bCheckBox[0] =TRUE;
	for(int i = 1;i < 5; i++)
	{
		m_bCheckBox[i] = FALSE;
	}

	m_bClickList = FALSE;		// ����Ʈ�� Ŭ�������� �� 
	m_ClickID = FALSE;			// ����Ʈ�� �ε����� Ŭ�������� �� 
	m_IdNoToAddDel = 0;	

	m_nPolarityMode = FALSE;
	m_bUseTopHatMode = 0;

	strTable0[0] = "No";
	strTable0[1] = "Name";
	strTable0[2] = "MSize";

	strTable1[0] = "C1";
	strTable1[1] = "M1";
	strTable1[2] = "Z1";
	strTable1[3] = "Z2";
//	strTable1[4] = "TopHat";
//	strTable1[5] = "LongPath";
	strTable1[4] = "Voltage1(%)";
	strTable1[5] = "Voltage2(%)";
	strTable1[6] = "Asc File";

	strTable2[0] = "Duty";
	strTable2[1] = "Aom Delay";
	strTable2[2] = "Aom Duty";
	strTable2[3] = "DualAom1";
	strTable2[4] = "DualAom2";
	strTable2[5] = "VolOffset(%)";
	strTable2[6] = "VolOffset(%)";

	strTable3[0] = "Frequency";
	strTable3[1] = "Duty";
	strTable3[2] = "Aom Delay";
	strTable3[3] = "Aom Duty";
	strTable3[4] = "Target Min";
	strTable3[5] = "Target Max";
	strTable3[6] = "Duty Offset";
	
	strTable4[0] = "Duty";
	strTable4[1] = "Aom Delay";
	strTable4[2] = "Aom Duty";
	strTable4[3] = "Shot";
	strTable4[4] = "Vision";
	strTable4[5] = "Size";
	strTable4[6] = "Tol.";
	strTable4[7] = "Ratio";
	strTable4[8] = "Polarity";
	strTable4[9] = "Contrast";
	strTable4[10] = "Brightness";

}

CPaneSysSetupBeamPathLDD::~CPaneSysSetupBeamPathLDD()
{

}

void CPaneSysSetupBeamPathLDD::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSysSetupBeamPath)
	DDX_Control(pDX, IDC_CHECK_BEAMPATH, m_ChkSubBox[1]);
	DDX_Control(pDX, IDC_CHECK_POWER_OFFSET, m_ChkSubBox[2]);
	DDX_Control(pDX, IDC_CHECK_COMPENSATIO, m_ChkSubBox[3]);
	DDX_Control(pDX, IDC_CHECK_SCANNER_FACT, m_ChkSubBox[4]);
	DDX_Control(pDX, IDC_BUTTON_REFRESH, m_btnRefresh);
	DDX_Control(pDX, IDC_EDIT_BEAMPATH_FIXED_MASK_POS, m_edtFixMask);
	DDX_Control(pDX, IDC_LIST_INFO, m_list);
	DDX_Control(pDX, IDC_BUTTON_ADD, m_btnAdd);
	DDX_Control(pDX, IDC_BUTTON_DEL, m_btnDel);
	DDX_Control(pDX, IDC_BUTTON_UP, m_btnUp);
	DDX_Control(pDX, IDC_BUTTON_DOWN, m_btnDown);
	DDX_GridControl(pDX, IDC_GRID, m_Grid);



	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSysSetupBeamPathLDD, CFormView)
	//{{AFX_MSG_MAP(CPaneSysSetupBeamPath)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHECK_BEAMPATH, OnCheckBeamPath)
	ON_BN_CLICKED(IDC_CHECK_POWER_OFFSET, OnCheckPowerOffset)
	ON_BN_CLICKED(IDC_CHECK_COMPENSATIO, OnCheckPowerCompensation)
	ON_BN_CLICKED(IDC_CHECK_SCANNER_FACT,OnCheckScannerFact)
	ON_BN_CLICKED(IDC_BUTTON_REFRESH,OnCheckRefresh)
	ON_NOTIFY(NM_CLICK, IDC_LIST_INFO, OnClickList)
	ON_BN_CLICKED(IDC_BUTTON_ADD,OnCheckAdd)
	ON_BN_CLICKED(IDC_BUTTON_DEL,OnCheckDel)
	ON_BN_CLICKED(IDC_BUTTON_UP,OnCheckUp)
	ON_BN_CLICKED(IDC_BUTTON_DOWN,OnCheckDown)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_LIST_INFO, OnNMCustomdrawListTest)


	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupBeamPath diagnostics

#ifdef _DEBUG
void CPaneSysSetupBeamPathLDD::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSysSetupBeamPathLDD::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupBeamPath message handlers

void CPaneSysSetupBeamPathLDD::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();

	InitBtnControl();
	InitStaticControl();
	InitEditControl();
	InitGrid();

	// TODO: Add your specialized code here and/or call the base class

}

BOOL CPaneSysSetupBeamPathLDD::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneSysSetupBeamPathLDD::InitGrid()
{
	m_Grid.SetEditable(TRUE);
    m_Grid.SetListMode(FALSE);
    m_Grid.EnableDragAndDrop(FALSE);
    m_Grid.SetTextBkColor(RGB(0xFF, 0xFF, 0xE0));
	m_Grid.SetHeaderSort(FALSE);
	m_Grid.SetSingleRowSelection(FALSE);
	
	
    m_Grid.SetFixedRowCount(1);        //1���� ��
    m_Grid.SetFixedColumnCount(1);    //1���� ��
	m_Grid.SetRowResize(FALSE);		  //ũ�� ����
	m_Grid.SetColumnResize(FALSE);	  //ũ�� ����
}
void CPaneSysSetupBeamPathLDD::InitBtnControl()
{
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	
	m_ChkSubBox[1].SetFont( &m_fntBtn );
	m_ChkSubBox[1].SetImageOrg( 10, 3 );
	m_ChkSubBox[1].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[1].EnableBallonToolTip();
	m_ChkSubBox[1].SetToolTipText( _T("Beam Path") );
	m_ChkSubBox[1].SetBtnCursor(IDC_HAND_1);
	
	m_ChkSubBox[2].SetFont( &m_fntBtn );
	m_ChkSubBox[2].SetImageOrg( 10, 3 );
	m_ChkSubBox[2].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[2].EnableBallonToolTip();
	m_ChkSubBox[2].SetToolTipText( _T("Power Offset") );
	m_ChkSubBox[2].SetBtnCursor(IDC_HAND_1);
	
	m_ChkSubBox[3].SetFont( &m_fntBtn );
	m_ChkSubBox[3].SetImageOrg( 10, 3 );
	m_ChkSubBox[3].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[3].EnableBallonToolTip();
	m_ChkSubBox[3].SetToolTipText( _T("Power Compensation") );
	m_ChkSubBox[3].SetBtnCursor(IDC_HAND_1);
	
	m_ChkSubBox[4].SetFont( &m_fntBtn );
	m_ChkSubBox[4].SetImageOrg( 10, 3 );
	m_ChkSubBox[4].SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_ChkSubBox[4].EnableBallonToolTip();
	m_ChkSubBox[4].SetToolTipText( _T("Scanner Facts") );
	m_ChkSubBox[4].SetBtnCursor(IDC_HAND_1);

	m_btnRefresh.SetFont( &m_fntBtn );
	m_btnRefresh.SetFlat( FALSE );
	m_btnRefresh.EnableBallonToolTip();
	m_btnRefresh.SetToolTipText( _T("Refresh") );
	m_btnRefresh.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRefresh.SetBtnCursor(IDC_HAND_1);


	m_btnAdd.SetFont( &m_fntBtn );
	m_btnAdd.SetFlat( FALSE );
	m_btnAdd.EnableBallonToolTip();
	m_btnAdd.SetToolTipText( _T("Refresh") );
	m_btnAdd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAdd.SetBtnCursor(IDC_HAND_1);

	m_btnDel.SetFont( &m_fntBtn );
	m_btnDel.SetFlat( FALSE );
	m_btnDel.EnableBallonToolTip();
	m_btnDel.SetToolTipText( _T("Refresh") );
	m_btnDel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDel.SetBtnCursor(IDC_HAND_1);

	m_btnUp.SetFont( &m_fntBtn );
	m_btnUp.SetFlat( FALSE );
	m_btnUp.EnableBallonToolTip();
	m_btnUp.SetToolTipText( _T("Refresh") );
	m_btnUp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUp.SetBtnCursor(IDC_HAND_1);

	m_btnDown.SetFont( &m_fntBtn );
	m_btnDown.SetFlat( FALSE );
	m_btnDown.EnableBallonToolTip();
	m_btnDown.SetToolTipText( _T("Refresh") );
	m_btnDown.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDown.SetBtnCursor(IDC_HAND_1);



}
void CPaneSysSetupBeamPathLDD::InitStaticControl()
{

}
void CPaneSysSetupBeamPathLDD::InitEditControl()
{
	m_editwnd.Create(WS_CHILD|ES_NOHIDESEL|ES_AUTOHSCROLL|WS_VISIBLE, CRect(0,0,0,0), this, IDC_EDIT_BOX);
	m_editwnd.SetFont(GetFont(), FALSE);
	m_editwnd.SetMargins(4,4);
	SetWindowLong(m_editwnd.m_hWnd, GWL_EXSTYLE, WS_EX_CLIENTEDGE);

	m_edtFixMask.SetFont( &m_fntEdit );
	m_edtFixMask.SetReceivedFlag( 1 );
	m_edtFixMask.SetWindowText( _T("0") );
}

void CPaneSysSetupBeamPathLDD::OnCheckBeamPath()
{
	if(m_bCheckBox[1])
		GetCurrentASC();

	m_bCheckBox[1] = !m_bCheckBox[1];
	OnCheckRefresh();
}

void CPaneSysSetupBeamPathLDD::OnCheckPowerOffset()
{
	m_bCheckBox[2] = !m_bCheckBox[2];
	if(m_bCheckBox[1])
		GetCurrentASC();
	OnCheckRefresh();
}

void CPaneSysSetupBeamPathLDD::OnCheckPowerCompensation()
{
	m_bCheckBox[3] = !m_bCheckBox[3];
	if(m_bCheckBox[1])
		GetCurrentASC();
	OnCheckRefresh();
}

void CPaneSysSetupBeamPathLDD::OnCheckScannerFact()
{
	m_bCheckBox[4] = !m_bCheckBox[4];
	if(m_bCheckBox[1])
		GetCurrentASC();
	OnCheckRefresh();
}



void CPaneSysSetupBeamPathLDD::OnCheckRefresh()
{
	m_editwnd.ShowWindow(SW_HIDE);

	DeleteList();
	int nlistcount = GetListIndex();
	SetDrawMember(nlistcount);
	Invalidate(FALSE);
}


void CPaneSysSetupBeamPathLDD::InitListControl() 
{
	for(int i = 1; i< 5; i++)
	{
		if( TRUE == m_bCheckBox[i])
			m_ChkSubBox[i].SetCheck(1);
		else
			m_ChkSubBox[i].SetCheck(0);
	}

	// ����Ʈ ��Ʈ�ѳ� �ѱ� �߰� ��ƾ 
	CFont m_Font;
	m_Font.CreateFont(12, 0,      // Height, Width
		0, 0,      // Escapement, Orientation
		FW_NORMAL, FALSE,              // Weight, Italic
		FALSE, FALSE,                // Underline, StrikeOut
		HANGEUL_CHARSET,                // Character Set
		OUT_DEFAULT_PRECIS,   // OutPrecision
		CLIP_DEFAULT_PRECIS,   // ClipPrecision
		DEFAULT_QUALITY,             // Quality
		DEFAULT_PITCH,               // PitchAndFamily
		"SYSTEM");  
	
	m_list.SetFont(&m_Font);
	m_Font.DeleteObject();

	m_list.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_FULLROWSELECT|LVS_EX_INFOTIP|LVS_EX_CHECKBOXES);

	// ����Ʈ ��Ʈ�ѿ� �޺� �ڽ��� �־��µ� ù��° ���� �޺� �ڽ��� �׷��� ������ ������ ����Ʈ�� �ٿ� �ȵǾ���. �׷��� �ణ�� ������ ���� �÷� �ذ� �� ;;;(�ؿ� ���� )
	CImageList image;
	image.Create(1, 23, ILC_COLORDDB, 1, 0); //���� ������ �ι�° �Ķ���� ���� ����
	m_list.SetImageList(&image, LVSIL_SMALL); 
	
	DeleteList();
	int nlistcount = GetListIndex();
	SetDrawMember(nlistcount);
	Invalidate();

	CString strData;
	strData.Format(_T("%d"), m_sBeamPath.nFixedMask);
	m_edtFixMask.SetWindowText( (LPCTSTR)strData );
}

int CPaneSysSetupBeamPathLDD::GetListIndex()		//1: 1���̺� ���, 2: 2���̺� ���, 4: 3�� ���̺� ��� , 8 :4�� ���̺� ���, 16: 5�� ���̺� ��� 
{
	int nCount = 0;

	if(m_bCheckBox[0])
		nCount+=1;
	if(m_bCheckBox[1])
		nCount+=2;
	if(m_bCheckBox[2])
		nCount+=4;
	if(m_bCheckBox[3])
		nCount+=8;
	if(m_bCheckBox[4])
		nCount+=16;
	
	return nCount;
	
}

int CPaneSysSetupBeamPathLDD::GetListRowIndexCount()
{
	int nRowCount = 0;

	if(m_bCheckBox[0])
		nRowCount += TABLE0_COLUMN_COUNT;
	if(m_bCheckBox[1])
		nRowCount += TABLE1_COLUMN_COUNT;
	if(m_bCheckBox[2])
		nRowCount += TABLE2_COLUMN_COUNT;
	if(m_bCheckBox[3])
		nRowCount += TABLE3_COLUMN_COUNT;
	if(m_bCheckBox[4])
		nRowCount += TABLE4_COLUMN_COUNT;

	return nRowCount;
}

void CPaneSysSetupBeamPathLDD::InsertGridValue(GV_ITEM Gvitem, int startNo, int TableNo, int ColCount)
{
	int ColumnNo = startNo;
	CString strData;	

	if(TableNo == TABLE0)
	{
		Gvitem.row = ColCount + 1;
	
		strData.Format(_T("%d"),  m_sBeamPath.nInfoId[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		
		strData.Format(_T("%s"), m_sBeamPath.strInfoName[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), m_sBeamPath.dInfoMaskSize[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;	
	}

	if(TableNo == TABLE1)
	{
		Gvitem.row = ColCount + 1;

		strData.Format(_T("%.2f"),  m_sBeamPath.dBeamPathBetPos1[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
		

// 		strData.Format(_T("%.2f"),  m_sBeamPath.dBeamPathBetPos2[ColCount]);
// 		Gvitem.szText = strData;
// 		Gvitem.col = ColumnNo;
// 		Gvitem.iCombo = GV_EDIT;
// 		
// 		m_Grid.SetItem(&Gvitem);
// 		ColumnNo++;

		strData.Format(_T("%d"),  m_sBeamPath.nBeamPathMaskPos1[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

/*		strData.Format(_T("%d"),  m_sBeamPath.nBeamPathMaskPos2[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%d"),  m_sBeamPath.nBeamPathAttenuatePos1[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%d"),  m_sBeamPath.nBeamPathAttenuatePos2[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
*/

		strData.Format(_T("%.3f"),  m_sBeamPath.dBeamPathZAxisPos1[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%.3f"),  m_sBeamPath.dBeamPathZAxisPos2[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

// 		BOOL bUseTophHat = m_sBeamPath.bBeamPathUseTophat[ColCount];
// 		if(bUseTophHat == FALSE)
// 		{
// 			strData.Format(_T("%s"), "Off"));
// 		}
// 		else if( bUseTophHat == TRUE )
// 		{
// 			strData.Format(_T("%s"), "On"));
// 		}
// 		Gvitem.szText = strData;
// 		Gvitem.col = ColumnNo;
// 		Gvitem.iCombo = GV_COMBO;
// 		Gvitem.iComboType = GVC_TOPHAT;
// 		
// 		m_Grid.SetItem(&Gvitem);
// 		ColumnNo++;
// 
// 		BOOL bBeamPath = m_sBeamPath.bBeamPathLaserPath[ColCount];
// 		if(bBeamPath == FALSE)
// 		{
// 			strData.Format(_T("%s"), "Long"));
// 		}
// 		else if( bBeamPath == TRUE )
// 		{
// 			strData.Format(_T("%s"), "Short"));
// 		}
// 		Gvitem.szText = strData;
// 		Gvitem.col = ColumnNo;
// 		Gvitem.iCombo = GV_COMBO;
// 		Gvitem.iComboType = GVC_LASERPATH;
// 		
// 		m_Grid.SetItem(&Gvitem);
// 		ColumnNo++;

		strData.Format(_T("%.1f"),  m_sBeamPath.dBeamPathVoltage1[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
		
		strData.Format(_T("%.1f"),  m_sBeamPath.dBeamPathVoltage2[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%s"),  m_sBeamPath.strBeamPathAscFile[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
	}

	if(TableNo == TABLE2)
	{
		Gvitem.row = ColCount + 1;

		strData.Format(_T("%.2f"),  m_sBeamPath.dPowOffsetDuty[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
			
		
		strData.Format(_T("%.2f"), m_sBeamPath.dPowOffsetAomDelay[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), m_sBeamPath.dPowOffsetAomDuty[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%.1f"), m_sBeamPath.dPowOffsetAomDual1[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
		
		strData.Format(_T("%.1f"), m_sBeamPath.dPowOffsetAomDual2[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%.1f"), m_sBeamPath.dPowOffsetVoltage1[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
		
		strData.Format(_T("%.1f"), m_sBeamPath.dPowOffsetVoltage2[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
	}

	if(TableNo == TABLE3)
	{
		Gvitem.row = ColCount + 1;

		strData.Format(_T("%d"),  m_sBeamPath.nPowCompensationFrequency[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
		
		
		strData.Format(_T("%.2f"), m_sBeamPath.dPowCompensationDuty[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), m_sBeamPath.dPowCompensationAomDelay[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%.2f"), m_sBeamPath.dPowCompensationAomDuty[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%.2f"), m_sBeamPath.dPowCompensationTargetMin[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%.2f"), m_sBeamPath.dPowCompensationTargetMax[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%.2f"), m_sBeamPath.dPowCompensationDutyOffset[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
	}
	
	if(TableNo == TABLE4)
	{
		Gvitem.row = ColCount + 1;

		strData.Format(_T("%.2f"),  m_sBeamPath.dScannerDuty[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
			
		strData.Format(_T("%.2f"), m_sBeamPath.dScannerAomdelay[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%.2f"), m_sBeamPath.dScannerAomDuty[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%d"), m_sBeamPath.nScannerTotalShot[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		int nVisionNo = m_sBeamPath.nScannerVisionCam[ColCount];
		if(nVisionNo ==0)
		{
			strData.Format(_T("%s"), "High");
		}
		else if( nVisionNo == 1 )
		{
			strData.Format(_T("%s"), "Low");
		}

		else
		{
			strData.Format(_T("%s"), "error");
		}
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_COMBO;
		Gvitem.iComboType = GVC_VISION;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%.2f"), m_sBeamPath.dScannerVisionModelSize[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;


		strData.Format(_T("%.2f"), m_sBeamPath.dScannerAcceptScoreSize[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), m_sBeamPath.dScannerAcceptScoreRatio[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		int nPolarity = m_sBeamPath.nScannerPolarity[ColCount];
		if( nPolarity ==0 )
		{
			strData.Format(_T("%s"), "Black");
		}
		else if( nPolarity == 1)
		{
			strData.Format(_T("%s"), "White");
		}
		else if( nPolarity == 2)
		{
			strData.Format(_T("%s"), "Ignore");
		}
		else
		{
			strData.Format(_T("%s"), "error");
		}
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_COMBO;
		Gvitem.iComboType = GVC_POLARITY;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;

		strData.Format(_T("%.2f"), m_sBeamPath.dScannerContrast[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), m_sBeamPath.dScannerBrightness[ColCount]);
		Gvitem.szText = strData;
		Gvitem.col = ColumnNo;
		Gvitem.iCombo = GV_EDIT;
		m_Grid.SetItem(&Gvitem);
		ColumnNo++;
	}	
	m_Grid.AutoSize();
}

void CPaneSysSetupBeamPathLDD::InsertListValue(LV_ITEM lvitem, int startNo, int TableNo, int ColCount)
{
	int ColumnNo = startNo;
	CString strData;	

	if(TableNo == TABLE0)
	{
		if( ColumnNo == 0)
		{
			ColumnNo++;
		}
		else
		{
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[ColCount]);
			m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
			ColumnNo++;
		}	
		
		strData.Format(_T("%s"), m_sBeamPath.strInfoName[ColCount]);
		strData = m_sBeamPath.strInfoName[ColCount];
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), m_sBeamPath.dInfoMaskSize[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;	
	}

	if(TableNo == TABLE1)
	{
		if( ColumnNo == 0)
		{
			ColumnNo++;
		}
		else
		{
			strData.Format(_T("%.2f"),  m_sBeamPath.dBeamPathBetPos1[ColCount]);
			m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
			ColumnNo++;
		}

		strData.Format(_T("%.2f"),  m_sBeamPath.dBeamPathBetPos2[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"),  m_sBeamPath.nBeamPathMaskPos1[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
#ifdef __SERVO_MOTOR__
		strData.Format(_T("%d"),  m_sBeamPath.nBeamPathMaskPos2[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"),  m_sBeamPath.nBeamPathMaskPos3[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
#endif
/*
		strData.Format(_T("%d"),  m_sBeamPath.nBeamPathAttenuatePos1[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"),  m_sBeamPath.nBeamPathAttenuatePos2[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
*/
		strData.Format(_T("%.3f"),  m_sBeamPath.dBeamPathZAxisPos1[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%.3f"),  m_sBeamPath.dBeamPathZAxisPos2[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		BOOL bUseTophHat = m_sBeamPath.bBeamPathUseTophat[ColCount];
		if(bUseTophHat == FALSE)
		{
			strData.Format(_T("%s"), "OFF");
		}
		else if( bUseTophHat == TRUE )
		{
			strData.Format(_T("%s"), "ON");
		}
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		BOOL bBeamPath = m_sBeamPath.bBeamPathLaserPath[ColCount];
		if(bBeamPath == FALSE)
		{
			strData.Format(_T("%s"), "Long");
		}
		else if( bBeamPath == TRUE )
		{
			strData.Format(_T("%s"), "Short");
		}
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.1f"),  m_sBeamPath.dBeamPathVoltage1[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.1f"),  m_sBeamPath.dBeamPathVoltage2[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%s"),  m_sBeamPath.strBeamPathAscFile[ColCount]);
		strData = m_sBeamPath.strBeamPathAscFile[ColCount];
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
	}

	if(TableNo == TABLE2)
	{
		if( ColumnNo == 0)
		{
			ColumnNo++;
		}
		else
		{
			strData.Format(_T("%.2f"),  m_sBeamPath.dPowOffsetDuty[ColCount]);
			m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
			ColumnNo++;
		}	
		
		strData.Format(_T("%.2f"), m_sBeamPath.dPowOffsetAomDelay[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), m_sBeamPath.dPowOffsetAomDuty[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;		

		strData.Format(_T("%.1f"), m_sBeamPath.dPowOffsetAomDual1[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.1f"), m_sBeamPath.dPowOffsetAomDual2[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;	

		strData.Format(_T("%.1f"), m_sBeamPath.dPowOffsetVoltage1[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.1f"), m_sBeamPath.dPowOffsetVoltage2[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;	
	}

	if(TableNo == TABLE3)
	{
		if( ColumnNo == 0)
		{
			ColumnNo++;
		}
		else
		{
			strData.Format(_T("%d"),  m_sBeamPath.nPowCompensationFrequency[ColCount]);
			m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
			ColumnNo++;
		}	
		
		strData.Format(_T("%.2f"), m_sBeamPath.dPowCompensationDuty[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), m_sBeamPath.dPowCompensationAomDelay[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%.2f"), m_sBeamPath.dPowCompensationAomDuty[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%.2f"), m_sBeamPath.dPowCompensationTargetMin[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%.2f"), m_sBeamPath.dPowCompensationTargetMax[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%.2f"), m_sBeamPath.dPowCompensationDutyOffset[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;	
	}
	
	if(TableNo == TABLE4)
	{
		if( ColumnNo == 0)
		{
			ColumnNo++;
		}
		else
		{
			strData.Format(_T("%.2f"),  m_sBeamPath.dScannerDuty[ColCount]);
			m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
			ColumnNo++;
		}	
			
		strData.Format(_T("%.2f"), m_sBeamPath.dScannerAomdelay[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%.2f"), m_sBeamPath.dScannerAomDuty[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%d"), m_sBeamPath.nScannerTotalShot[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		int nVisionNo = m_sBeamPath.nScannerVisionCam[ColCount];
		if(nVisionNo ==0)
		{
			strData.Format(_T("%s"), "High");
		}
		else if( nVisionNo == 1 )
		{
			strData.Format(_T("%s"), "Low");
		}

		else
		{
			strData.Format(_T("%s"), "error");
		}
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%.2f"), m_sBeamPath.dScannerVisionModelSize[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;


		strData.Format(_T("%.2f"), m_sBeamPath.dScannerAcceptScoreSize[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), m_sBeamPath.dScannerAcceptScoreRatio[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		int nPolarity = m_sBeamPath.nScannerPolarity[ColCount];
		if( nPolarity ==0 )
		{
			strData.Format(_T("%s"), "Black");
		}
		else if( nPolarity == 1)
		{
			strData.Format(_T("%s"), "White");
		}
		else if( nPolarity == 2)
		{
			strData.Format(_T("%s"), "Ignore");
		}
		else
		{
			strData.Format(_T("%s"), "error");
		}
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;

		strData.Format(_T("%.2f"), m_sBeamPath.dScannerContrast[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;
		
		strData.Format(_T("%.2f"), m_sBeamPath.dScannerBrightness[ColCount]);
		m_list.SetItemText(lvitem.iItem, ColumnNo, strData);
		ColumnNo++;	
	}	
}

int CPaneSysSetupBeamPathLDD::GetColumnSize(int nStrlen)
{

	if( nStrlen < 3)
		nStrlen = (nStrlen * COLUMNWIDTH) + 25;
	else if(nStrlen < 6 )
		nStrlen *= ( COLUMNWIDTH -2);
	else
		nStrlen = (4 * COLUMNWIDTH) + 25 ;	

	return nStrlen;
}

void CPaneSysSetupBeamPathLDD::InsertListComumn(int startNo, int TableNo)
{
	int ColumnNo = startNo;
	m_list.SetExtendedStyle(LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT);

	int nSize =0 ;
	int nStrLen = 0;

	if(TableNo == TABLE0) 
	{
		m_Grid.SetColumnCount(TABLE0_COLUMN_COUNT);
		for(int i = 0 ;i < TABLE0_COLUMN_COUNT; i++)  
		{
			nSize = strTable0[i].GetLength();
			nStrLen = GetColumnSize(nSize);
			if (i == 0)
				nStrLen = 30 ;		// ����Ʈ�� ���� �R�׸��� No���� �÷� ������ 

			if ( i ==1 )
				nStrLen = 130;		// name �÷��� ������ 

			m_list.InsertColumn(ColumnNo, strTable0[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = i;
			Item.szText = strTable0[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else if(TableNo == TABLE1)
	{
		m_Grid.SetColumnCount(m_nColumnCount + TABLE1_COLUMN_COUNT);
		int nColumnCount = m_nColumnCount;
		for(int i = 0 ;i < TABLE1_COLUMN_COUNT; i++)
		{
			nSize = strTable1[i].GetLength();
			nStrLen = GetColumnSize(nSize);
			
			m_list.InsertColumn(ColumnNo, strTable1[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = nColumnCount + i;
			Item.szText = strTable1[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else if(TableNo == TABLE2)
	{
 		m_Grid.SetColumnCount(m_nColumnCount + TABLE2_COLUMN_COUNT);
		int nColumnCount = m_nColumnCount;
		for(int i = 0 ;i < TABLE2_COLUMN_COUNT; i++)
		{	
			nSize = strTable2[i].GetLength();
			nStrLen = GetColumnSize(nSize);
			
			m_list.InsertColumn(ColumnNo, strTable2[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = nColumnCount + i;
			Item.szText = strTable2[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else if(TableNo == TABLE3)
	{
		m_Grid.SetColumnCount(m_nColumnCount + TABLE3_COLUMN_COUNT);
		int nColumnCount = m_nColumnCount;
		for(int i = 0 ;i < TABLE3_COLUMN_COUNT; i++)
		{
			nSize = strTable3[i].GetLength();
			nStrLen = GetColumnSize(nSize);
			
			m_list.InsertColumn(ColumnNo, strTable3[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = nColumnCount + i;
			Item.szText = strTable3[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else if(TableNo == TABLE4)
	{
		m_Grid.SetColumnCount(m_nColumnCount + TABLE4_COLUMN_COUNT);
		int nColumnCount = m_nColumnCount;
		for(int i = 0 ;i < TABLE4_COLUMN_COUNT; i++)
		{	
			nSize = strTable4[i].GetLength();
			nStrLen = GetColumnSize( nSize);
			
			m_list.InsertColumn(ColumnNo, strTable4[i], LVCFMT_CENTER, nStrLen );
			ColumnNo++;
			nStrLen = 0;

			GV_ITEM Item;
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			Item.nFormat = DT_LEFT|DT_WORDBREAK;
			Item.row = 0;
			Item.col = nColumnCount + i;
			Item.szText = strTable4[i];
			m_Grid.SetItem(&Item);	
			m_Grid.AutoSize();
			m_nColumnCount++;
		}
	}
	else
	{
		//error
	}
}

void CPaneSysSetupBeamPathLDD::DeleteList()
{
/*	CListCtrl &ctrllist = m_list;
	CHeaderCtrl	*pHeaderCtrl;

	pHeaderCtrl = ctrllist.GetHeaderCtrl();
	int nCount = pHeaderCtrl->GetItemCount();
*/
	m_nColumnCount = 0;
/*
	if( -1 ==nCount)
	{
		ErrMessage(_T("Header Column not exist"));
		return;
	}
	else if( 0 < nCount)
	{
		ctrllist.DeleteAllItems();
		for(int i = 0;i <nCount; i++)
		{
			ctrllist.DeleteColumn(0);
		}
	}
*/
}

void CPaneSysSetupBeamPathLDD::SetDrawMember(int listcount)
{
	int i;
	LV_ITEM lvitem;
	GV_ITEM Item;
	CString strData;
	DWORD dwTextStyle = DT_CENTER|DT_VCENTER|DT_SINGLELINE;    //Text ��Ÿ�� ����
	Item.mask = GVIF_TEXT|GVIF_FORMAT;
	Item.nFormat = dwTextStyle;

	if(listcount == 0)
	{

	}
	else if(listcount == 1) //1
	{
		InsertListComumn(0,TABLE0);
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);

			InsertListValue(lvitem, 0,TABLE0,i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
		}

	}
	else if(listcount ==2 )  //2
	{
		InsertListComumn(0,TABLE1);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);

			InsertListValue(lvitem, 0 ,TABLE1, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE1, i);
		}
	}
	else if(listcount ==4) //4
	{
		InsertListComumn(0,TABLE2);

	
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);

			InsertListValue(lvitem, 0 ,TABLE2, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE2, i);
		}
	}
	else if(listcount == 8) //8
	{
		InsertListComumn(0,TABLE3);

	
		for( i = m_nRepeatCount-1 ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);

			InsertListValue(lvitem, 0 ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE3, i);
		}
	}
	else if( listcount == 16) //16
	{
		InsertListComumn(0,TABLE4);
	
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);

			InsertListValue(lvitem, 0 ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			Item.mask = GVIF_TEXT|GVIF_FORMAT;
			InsertGridValue(Item, 0, TABLE4, i);
		}
	}

	else if(listcount == 3) //1,2
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);// 3�� �÷� ���� ���� 

			InsertListValue(lvitem, 0 ,TABLE0, i);						// 0�� �÷� ���� ���� 
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);// 3�� �÷� ���� ���� 
		}
	}
	else if(listcount ==5) //1,4
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE2);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
		}
	}
	else if(listcount ==9) //1,8
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE3);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE3, i);
		}
	}
	else if(listcount == 17) //1,16
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE4);
		
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE4, i);
		}
	}
	else if(listcount == 7)  //1,2,4
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0, TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2, i);
		}
	}
	else if(listcount ==11)//1,2,8
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE3);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE3, i);
		}
	}
	else if(listcount == 19)//1,2,16
	{

		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE4, i);
		}
	}

	else if(listcount == 13)//1,4.8
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT,TABLE3);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE3, i);
		}
	}
	else if(listcount == 21) //1,4,16
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT ,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE4, i);
		}
	}
	else if(listcount == 25) //1,8,16
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE3); //3
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT,TABLE4);//11

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);
		}
	}

	else if(listcount == 15) //1,2,4,8
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT,TABLE3);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);

		}
	}

	else if(listcount ==23) //1,2,4,16
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE4, i);
		}
	}

	else if(listcount ==27) //1,2,8,16
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);
		}

	}
	else if(listcount == 29)// 1,4,8,16
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);

			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);
		}
	}
	else if(listcount == 31) //1,2,4,8,16
	{
		InsertListComumn(0,TABLE0);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT,TABLE1);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT,TABLE2);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT,TABLE3);
		InsertListComumn( 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"),  m_sBeamPath.nInfoId[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE0, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);

			InsertGridValue(Item, 0 ,TABLE0, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE4, i);
		}
	}

	// start 2
	else if(listcount == 6)
	{
		InsertListComumn(0,TABLE1);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT ,TABLE2);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), m_sBeamPath.dBeamPathBetPos1[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT  ,TABLE2, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT  ,TABLE2, i);
		}
	}
	else if(listcount == 10)
	{
		InsertListComumn(0,TABLE1);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT ,TABLE3);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), m_sBeamPath.dBeamPathBetPos1[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT  ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT  ,TABLE3, i);
		}
	}

	else if(listcount == 18)
	{
		InsertListComumn(0,TABLE1);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT ,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), m_sBeamPath.dBeamPathBetPos1[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT  ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT  ,TABLE4, i);

		}
	}

	else if(listcount == 14)
	{
		InsertListComumn(0,TABLE1);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT ,TABLE2);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE3);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), m_sBeamPath.dBeamPathBetPos1[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE3, i);

		}
	}

	else if(listcount == 22)
	{
		InsertListComumn(0,TABLE1);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), m_sBeamPath.dBeamPathBetPos1[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT ,TABLE4, i);
		}
	}
	else if(listcount == 26)
	{
		InsertListComumn(0,TABLE1);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), m_sBeamPath.dBeamPathBetPos1[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 , TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 , TABLE1, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE4, i);
		}
	}

	else if(listcount == 30)
	{
		InsertListComumn(0,TABLE1);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT,TABLE2);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT,TABLE4);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), m_sBeamPath.dBeamPathBetPos1[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE1, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE1, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT ,TABLE4, i);
		}
	}

	//start 4
	else if(listcount == 12)
	{
		InsertListComumn(0,TABLE2);
		InsertListComumn(0 + TABLE2_COLUMN_COUNT,TABLE3);

		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), m_sBeamPath.dPowOffsetDuty[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE2_COLUMN_COUNT ,TABLE3, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE2_COLUMN_COUNT ,TABLE3, i);
		}


	}
	else if(listcount == 20)
	{
		InsertListComumn(0,TABLE2);
		InsertListComumn(0 + TABLE2_COLUMN_COUNT,TABLE4);
		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), m_sBeamPath.dPowOffsetDuty[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE2_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);

			InsertGridValue(Item, 0 ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE2_COLUMN_COUNT ,TABLE4, i);
		}
	}

	else if(listcount == 28)
	{
		InsertListComumn(0,TABLE2);
		InsertListComumn(0 + TABLE2_COLUMN_COUNT,TABLE3);
		InsertListComumn(0 + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4);
		for( i = m_nRepeatCount; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%.2f"), m_sBeamPath.dPowOffsetDuty[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE2, i);
			InsertListValue(lvitem, 0 + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);
			InsertGridValue(Item, 0 ,TABLE2, i);
			InsertGridValue(Item, 0 + TABLE2_COLUMN_COUNT ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT ,TABLE4, i);
		}
	}

	//start 8
	else if(listcount == 24)
	{
		InsertListComumn(0,TABLE3);
		InsertListComumn(0 + TABLE3_COLUMN_COUNT,TABLE4);


		for( i = m_nRepeatCount ; i >= 0 ;i--)
		{
			lvitem.iItem = 0;
			lvitem.mask = LVIF_TEXT;
			lvitem.iSubItem = 0;
			strData.Format(_T("%d"), m_sBeamPath.nPowCompensationFrequency[i]);
			lvitem.pszText = (LPSTR)(LPCTSTR)strData;
			m_list.InsertItem(&lvitem);
			
			InsertListValue(lvitem, 0 ,TABLE3, i);
			InsertListValue(lvitem, 0 + TABLE3_COLUMN_COUNT ,TABLE4, i);

			m_Grid.SetRowCount(2 + m_nRepeatCount);

			InsertGridValue(Item, 0 ,TABLE3, i);
			InsertGridValue(Item, 0 + TABLE3_COLUMN_COUNT ,TABLE4, i);
		}

	}
}

void CPaneSysSetupBeamPathLDD::SetBeamPath(SBEAMPATH sBeamPath)
{
	memcpy( &m_sBeamPath, &sBeamPath, sizeof(m_sBeamPath) );	
	m_nRepeatCount= m_sBeamPath.nLastIndex ;	
	OnCheckRefresh();
}
void CPaneSysSetupBeamPathLDD::GetBeamPath(SBEAMPATH* pBeamPath)
{
	CString strData;	 
	m_edtFixMask.GetWindowText( strData );
	m_sBeamPath.nFixedMask = atoi( (LPSTR)(LPCTSTR)strData );	 
	m_sBeamPath.nLastIndex = m_nRepeatCount;	//����Ʈ�� �� ������ �ε��� ���� 
	memcpy( pBeamPath, &m_sBeamPath, sizeof(m_sBeamPath) );
}

void CPaneSysSetupBeamPathLDD::OnClickList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NMITEMACTIVATE* pnmia=(NMITEMACTIVATE*)pNMHDR;

	// �ʱ�ȭ 
	m_ClickID = FALSE;
	SetIdNoToAddDel(0);
	m_bClickList = TRUE;
	
	//���õ� ����Ʈ �׸� ��� 
	m_posClicked.x=pnmia->iSubItem;
	m_posClicked.y=pnmia->iItem;

	// �ε����׸� Ŭ�� �� �׸� ADD,Del�Ҷ� ���
	if(m_posClicked.x ==0) 
	{
		m_ClickID = TRUE;
		SetIdNoToAddDel(m_posClicked.y);
		return ;
	}	

	// id�� ,����Ʈ�� ���� ���� �κд����� �� ����
	if(m_posClicked.x == 0 || m_posClicked.y  == -1 )
	{
		m_bClickList = FALSE;
		m_ClickID = FALSE;
		return ;
	}

	// M1, M2 ��뿩�� Ȯ�� â 
/*	if(m_sBeamPath.bBeamPathUseTophat[m_posClicked.y] == FALSE && m_bCheckBox[1] ==TRUE && m_posClicked.x == 6 )
	{
		m_sBeamPath.nBeamPathMaskPos1[m_posClicked.y] = 0;
		OnKillfocusEditGrid();
		ErrMessage(_T("Tophat mode OFF�Դϴ�, M1�� ����ϼ���"));
		return ;
	}

	if(m_sBeamPath.bBeamPathUseTophat[m_posClicked.y] == TRUE && m_bCheckBox[1] ==TRUE &&m_posClicked.x == 5)
	{
		m_sBeamPath.nBeamPathMaskPos2[m_posClicked.y] = 0;
		OnKillfocusEditGrid();
		ErrMessage(_T("Tophat mode ON�Դϴ�, M2�� ����ϼ���"));
		return ;
	}
*/	
	// �޺��ڽ�, ����Ʈ �ڽ� ����
	int bSelectShowBoxMode = GetShowBoxMode( m_posClicked.x );	// return (0: edit �ڽ� �׸���, 1: use top hat combobox �׸���, 2: polarity combobox �׸���  )


	CString str;
	CRect rectCell;
	str=m_list.GetItemText(pnmia->iItem, pnmia->iSubItem);
	m_editwnd.SetWindowText(str);

	if( 0 ==bSelectShowBoxMode )
	{
		//����Ʈ �ڽ� �׸��� 
		
		m_list.GetSubItemRect(pnmia->iItem, pnmia->iSubItem, LVIR_BOUNDS, rectCell);
		m_editwnd.SetWindowPos(NULL, rectCell.left+16, rectCell.top+34, rectCell.right-rectCell.left, rectCell.bottom-rectCell.top, SWP_NOZORDER|SWP_SHOWWINDOW);
		m_editwnd.SetFocus();
		m_editwnd.SetSel(0, -1);

	//	m_bClickList = TRUE;	// ����Ű�� ����Ʈ �ڽ��� ��� 
		
	}
	else if( 1 == bSelectShowBoxMode )
	{
		//use top hat �޺� �ڽ� �׸����  
		
 		m_list.GetSubItemRect(pnmia->iItem, pnmia->iSubItem, LVIR_BOUNDS, rectCell);

		m_list.GetSubItemRect(pnmia->iItem, pnmia->iSubItem, LVIR_BOUNDS, rectCell);

		m_editwnd.ShowWindow(SW_HIDE);

	//	m_bClickList = TRUE;	// ����Ű�� ����Ʈ �ڽ��� ��� 

	}
	else if( 2 == bSelectShowBoxMode)
	{
		// poloarity �޺��ڽ� �׸���
		m_list.GetSubItemRect(pnmia->iItem, pnmia->iSubItem, LVIR_BOUNDS, rectCell);

		m_editwnd.ShowWindow(SW_HIDE);

	//	m_bClickList = TRUE;	// ����Ű�� ����Ʈ �ڽ��� ��� 

	}
	else if(3 == bSelectShowBoxMode)
	{
		//vision �޺��ڽ� �׸��� 
		m_list.GetSubItemRect(pnmia->iItem, pnmia->iSubItem, LVIR_BOUNDS, rectCell);

		m_editwnd.ShowWindow(SW_HIDE);

		//m_bClickList = TRUE;	// ����Ű�� ����Ʈ �ڽ��� ��� 

	}
	else
	{
		//error
	}
	
	*pResult = 0;
}

BOOL CPaneSysSetupBeamPathLDD::PreTranslateMessage(MSG* pMsg) 
{
/*	if (pMsg->message==WM_KEYDOWN && GetFocus()->m_hWnd==m_editwnd.m_hWnd)
	{
		
		switch (pMsg->wParam)
		{
		case VK_RETURN:
			OnKillfocusEditGrid();
			SetCurrentScrollPos(m_posClicked.x,m_posClicked.y);
			m_bClickList = FALSE;
			return TRUE;
		
		case VK_ESCAPE:
			m_posClicked.y = -1;
			m_bClickList  = FALSE;
			OnKillfocusEditGrid();
			SetCurrentScrollPos(m_posClicked.x,m_posClicked.y);
			return TRUE;

		case VK_UP:
			MoveFocus(m_posClicked.x, m_posClicked.y, VK_UP);
			return TRUE;

		case VK_DOWN:
			MoveFocus(m_posClicked.x, m_posClicked.y,VK_DOWN);
			return TRUE;

		case VK_RIGHT:
		case VK_TAB:
			MoveFocus(m_posClicked.x, m_posClicked.y,VK_RIGHT);
			return TRUE;

		case VK_LEFT:
			MoveFocus(m_posClicked.x, m_posClicked.y, VK_LEFT);
			return TRUE;

		default:
			break;
		}		
	}
*/


	if(m_Grid.m_bMouseOn && GetKeyState(VK_CONTROL) < 0)
	{
		CCellID cCellId;
		cCellId = m_Grid.GetFocusCell();
		if(m_Grid.m_bFixedColumnClick)
		{
			m_sBeamPath.bSelectedList[cCellId.row] = TRUE;
			m_Grid.m_bFixedColumnClick = FALSE;
		}
		
	}
	else if(m_Grid.m_bMouseOn)
	{
		CCellID cCellId;
		cCellId = m_Grid.GetFocusCell();
		if(m_Grid.m_bFixedColumnClick)
		{
			for(int i = 0; i < BEAMPATH_COUNT; i++)
			{
				m_sBeamPath.bSelectedList[i] = FALSE;
			}
			m_sBeamPath.bSelectedList[cCellId.row] = TRUE;
			m_Grid.m_bFixedColumnClick = FALSE;
		}
	}

	if(m_Grid.m_bKeyboardOn)
	{
		CCellID cCellId;
		CPoint cpClickedCell;
		CString str;
		int nCol = 0;
		int nRow = 0;
		nCol = m_Grid.GetColumnCount();
		nRow = m_Grid.GetRowCount();
		cCellId = m_Grid.GetEditedCell();

		for(int i = 1; i < nCol; i++)
		{
			cpClickedCell.x = i;
			for(int j = 1; j < nRow; j++)
			{
				cpClickedCell.y = j - 1;
				str = m_Grid.GetItemText(j, i);
				ListUpdate(cpClickedCell, str);
			}
		}
		m_Grid.m_bKeyboardOn = FALSE;
	}
	return CFormView::PreTranslateMessage(pMsg);
}

BOOL CPaneSysSetupBeamPathLDD::MoveFocus(int nXpos, int nYpos, int nMoveType) //nXpos,nypos �̵� ���� �� �����ϰ� ���� 
{
	CString str;
	CRect rectCell;	
	
	// Ŭ�� ���� ������ ������Ʈ 
	int bSelectShowBoxMode = GetShowBoxMode( m_posClicked.x );

	if( 0 ==bSelectShowBoxMode )
	{
		//����Ʈ �ڽ�
		m_editwnd.GetWindowText(str);		
	}

	ListUpdate(m_posClicked, str);

	DeleteList();
	int nlistcount = GetListIndex();
	SetDrawMember(nlistcount);


	//�̵� ��ġ�� ����Ʈ �ڽ� �̵� 
	if(TRUE == m_bClickList)		// m_bClickList ==TRUE �� :����Ʈ�� �׸��� ��Ʈ���� �� 
	{

		switch (nMoveType)
		{
		case VK_UP:
			m_posClicked.y--;
			break;
			
		case VK_DOWN:
			m_posClicked.y++;
			break;
			
		case VK_RIGHT:
			m_posClicked.x++;
			break;
			
		case VK_LEFT:
			m_posClicked.x--;
			break;
			
		default:
			break;
		}
		
		// ���� üũ ����Ʈ�� ���� �¿� üũ 
		if(m_posClicked.x == 0 || m_posClicked.y  == -1 )		//id��, �÷� �������� ��Ŀ�� �̵��� 
		{
			//bClickList = FALSE;
			m_posClicked.x = nXpos;		// ��ǥ�� ���� 
			m_posClicked.y = nYpos;
			SetCurrentScrollPos(m_posClicked.x,m_posClicked.y);
			return TRUE;
		}
		
		int nChecOutofListX, nChecOutofListY;
		nChecOutofListX = GetListRowIndexCount();		//����Ʈ ���� ũ��
		nChecOutofListY = m_nRepeatCount + 1;			//����Ʈ ���� ũ�� (������ �׸��ε��� + 0�� ��)

		if ( (m_posClicked.x >= nChecOutofListX) || (m_posClicked.y >= nChecOutofListY) )
		{
			//bClickList = FALSE;
			m_posClicked.x = nXpos;
			m_posClicked.y = nYpos;
			SetCurrentScrollPos(m_posClicked.x,m_posClicked.y);
			return TRUE;
		}

		// ��ũ�� �̵� ��ƾ 
		SetCurrentScrollPos(m_posClicked.x,m_posClicked.y);

		//�̵��� ��Ʈ�� �ڽ� �ٽ� �׸���
		bSelectShowBoxMode = GetShowBoxMode( m_posClicked.x );
		if( 0 ==bSelectShowBoxMode )
		{

			//����Ʈ �ڽ� �׸��� 		
			m_list.GetSubItemRect(m_posClicked.y, m_posClicked.x, LVIR_BOUNDS, rectCell);
			str=m_list.GetItemText(m_posClicked.y, m_posClicked.x);
			m_editwnd.SetWindowText(str);

			m_editwnd.SetWindowPos(NULL, rectCell.left+16, rectCell.top+34, rectCell.right-rectCell.left, rectCell.bottom-rectCell.top, SWP_NOZORDER|SWP_SHOWWINDOW);
			m_editwnd.SetFocus();
			m_editwnd.SetSel(0, -1);

			//m_bClickList = TRUE;
			
		}
		else if( 1 == bSelectShowBoxMode )
		{
			//use top hat �޺� �ڽ� �׸����  
			
			m_list.GetSubItemRect(m_posClicked.y, m_posClicked.x, LVIR_BOUNDS, rectCell);

			m_editwnd.ShowWindow(SW_HIDE);
	
			//m_bClickList = TRUE;

		}
		else if( 2 == bSelectShowBoxMode)
		{
			// poloarity �޺��ڽ� �׸���
			m_list.GetSubItemRect(m_posClicked.y, m_posClicked.x, LVIR_BOUNDS, rectCell);

			m_editwnd.ShowWindow(SW_HIDE);

			//m_bClickList = TRUE;

		}
		else if(3 == bSelectShowBoxMode)
		{
			//vision �޺��ڽ� �׸��� 
			m_list.GetSubItemRect(m_posClicked.y, m_posClicked.x, LVIR_BOUNDS, rectCell);

			m_editwnd.ShowWindow(SW_HIDE);

		//	m_bClickList = TRUE;

		}
		else
		{
			//error
		}
	
	}
	return TRUE;
}

void CPaneSysSetupBeamPathLDD::OnKillfocusEditGrid()
{
	//EditBox�� �����ش�.
	m_editwnd.ShowWindow(SW_HIDE);
	
	if (m_posClicked.x==-1 || m_posClicked.y==-1) return;
	
	//�ڷ��� ������ ������. ��������.
	CString str;
	m_editwnd.GetWindowText(str);

	ListUpdate(m_posClicked, str);
	OnCheckRefresh();	
}

void CPaneSysSetupBeamPathLDD::FillTable0Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	if(xPos == 0)
		m_sBeamPath.nInfoId[yPos] = atoi(str);
	else if(xPos ==1 )
	{
		//name�� ������ ������ ���ɶ� ��� �Ұ���.  

		// �ߺ��Ǵ� name�� �� �ִ��� �˻� 
// 		CString strTemp;
// 		CString strCompare1, strCompare2;
// 		
// 		for(int i = 0 ;i < m_nRepeatCount;i++)
// 		{
// 			if(i == yPos)
// 				continue; // �������� �н� 
// 
// 			strCompare1.Format(_T("%s"), m_sBeamPath.strInfoName[i]);
// 			strCompare2 = str;
// 
// 			strCompare1.MakeLower();			// ��ҹ��ڴ� �������� �ʴ´�. 
// 			strCompare2.MakeLower();
// 
// 			if ( 0 == strCompare1.Compare(strCompare2))
// 			{
// 				strTemp.Format(_T("%d �׸�� �ߺ��˴ϴ�."), i);
// 				ErrMessage(strTemp);
// 				return;
// 			}
// 
// 		}
		strcpy_s(m_sBeamPath.strInfoName[yPos], str);

	}
	else if(xPos == 2)
			m_sBeamPath.dInfoMaskSize[yPos] = atof(str);
	
	m_list.SetItemText(y, x,str);
}

void CPaneSysSetupBeamPathLDD::FillTable1Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	if(xPos ==0)
		m_sBeamPath.dBeamPathBetPos1[yPos] = atof(str);
	else if(xPos == 1)
		m_sBeamPath.nBeamPathMaskPos1[yPos] = atoi(str);
	else if(xPos == 2)
		m_sBeamPath.dBeamPathZAxisPos1[yPos] = atof(str);
	else if(xPos == 3)
		m_sBeamPath.dBeamPathZAxisPos2[yPos] = atof(str);
	else if(xPos == 4)
		m_sBeamPath.dBeamPathVoltage1[yPos] = atof(str);
	else if(xPos == 5 )
		m_sBeamPath.dBeamPathVoltage2[yPos] = atof(str);
	else if(xPos == 6)
		strcpy_s(m_sBeamPath.strBeamPathAscFile[yPos], str);	

	m_list.SetItemText(y, x,str);
}

void CPaneSysSetupBeamPathLDD::FillTable2Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	double dTemp;
	if(xPos ==0)
	{
		dTemp = atof(str);
		//if( dTemp < 0 || dTemp > 100)
		//{
		//	ErrMessage(_T("Duty range : 0 < Duty < 100 %"));
		//	return ;
		//}
		m_sBeamPath.dPowOffsetDuty[yPos] = atof(str);
	}
	else if(xPos ==1 )
		m_sBeamPath.dPowOffsetAomDelay[yPos] = atof(str);
	else if(xPos == 2)
		m_sBeamPath.dPowOffsetAomDuty[yPos] = atof(str);
	else if(xPos == 3)
	{
	//	dTemp = atof(str);
	//	if(dTemp + m_sBeamPath.dPowOffsetAomDual2[yPos] > 100)
	//	{
	//		ErrMessage(_T("Please insert AOM Offset Percentage 100%") );
	//		return;
	//	}
		m_sBeamPath.dPowOffsetAomDual1[yPos] = atof(str);
	}
	else if(xPos == 4)
	{
	//	dTemp = atof(str);
	//	if(dTemp + m_sBeamPath.dPowOffsetAomDual1[yPos] > 100)
	//	{
	//		ErrMessage(_T("Please insert AOM Offset Percentage 100%") );
	//		return;
	//	}
		m_sBeamPath.dPowOffsetAomDual2[yPos] = atof(str);
	}
	else if(xPos == 5)
		m_sBeamPath.dPowOffsetVoltage1[yPos] = atof(str);
	else if(xPos == 6)
		m_sBeamPath.dPowOffsetVoltage2[yPos] = atof(str);
	
	m_list.SetItemText(y, x,str);

}

void CPaneSysSetupBeamPathLDD::FillTable3Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	double	dTemp;

	if(xPos ==0)
		m_sBeamPath.nPowCompensationFrequency[yPos] = atoi(str);
	else if(xPos ==1 )
	{
		dTemp = atof(str);
		//if( dTemp < 0 || dTemp > 100)
		//{
		//	ErrMessage(_T("Duty range : 0 < Duty < 100 %"));
		//	return ;
		//}

		m_sBeamPath.dPowCompensationDuty[yPos] = atof(str);
	}
	else if(xPos == 2)
		m_sBeamPath.dPowCompensationAomDelay[yPos] = atof(str);
	else if(xPos == 3)
		m_sBeamPath.dPowCompensationAomDuty[yPos] = atof(str);
	else if(xPos == 4)
	{
		dTemp = atof(str);
		if( dTemp <=0 || dTemp >=100 )
		{
			ErrMessage(_T("0 < Min.Value < 100"));
			return ;
		}
		m_sBeamPath.dPowCompensationTargetMin[yPos] = atof(str);
	}
	else if(xPos == 5)
	{
		dTemp = atof(str);
		if( dTemp <=0 || dTemp >=100 )
		{
			ErrMessage(_T("0 < Min.Value < 100"));
			return ;
		}
		m_sBeamPath.dPowCompensationTargetMax[yPos] = atof(str);
	}
	else if(xPos == 6)
		m_sBeamPath.dPowCompensationDutyOffset[yPos] = atof(str);	

	m_list.SetItemText(y, x,str);
}

void CPaneSysSetupBeamPathLDD::FillTable4Data(int x, int y, CString str)
{
	int xPos = x; 
	int yPos = y;

	int		nTemp;
	double	dTemp;

	if(xPos ==0)
	{
		dTemp = atof(str);
		//if( dTemp < 0 || dTemp > 100)
		//{
		//	ErrMessage(_T("Duty range : 0 < Duty < 100 %"));
		//	return ;
		//}
		m_sBeamPath.dScannerDuty[yPos] = atof(str);
	}
	else if(xPos == 1)
		m_sBeamPath.dScannerAomdelay[yPos] = atof(str);
	else if(xPos == 2)
		m_sBeamPath.dScannerAomDuty[yPos] = atof(str);
	else if(xPos == 3)
	{
		nTemp = atoi(str);
		if( nTemp <= 0 || nTemp >15)
		{
			ErrMessage(_T("Shot Range : 0 < shot < 15"));
			return ;
		}
		m_sBeamPath.nScannerTotalShot[yPos] = atoi(str);
	}
	else if(xPos == 4)
	{
/*		int nVisionMode = GetVisionMode();
		if( (nVisionMode ==0) || (nVisionMode ==1))
		{
			m_sBeamPath.nScannerVisionCam[yPos] = nVisionMode;
		}
		else
		{
			ErrMessage(_T("Vision (High: 0, Low: 1)"));
			return;
		}
*/
		if(strcmp(str, "HIGH") == 0)
			m_sBeamPath.nScannerVisionCam[yPos] = 0;
		else if(strcmp(str, "LOW") == 0)
			m_sBeamPath.nScannerVisionCam[yPos] = 1;
	}

	else if(xPos == 5)
		m_sBeamPath.dScannerVisionModelSize[yPos] = atof(str);
	else if(xPos == 6)
		m_sBeamPath.dScannerAcceptScoreSize[yPos] = atof(str);
	else if(xPos == 7)
		m_sBeamPath.dScannerAcceptScoreRatio[yPos] = atof(str);
	else if(xPos == 8)
	{
/*		int nCheckPolarity = GetPolarityMode();
		if((nCheckPolarity ==0 ) || (nCheckPolarity ==1 ) ||(nCheckPolarity ==2 ))
		{
			m_sBeamPath.nScannerPolarity[yPos] = nCheckPolarity;
		}
		else
		{
			ErrMessage(_T("Polarity (Black: 0, White: 1, Ignore: 2)"));	 
			return ;
		}
*/
		if(strcmp(str, "BLACK") == 0)
			m_sBeamPath.nScannerPolarity[yPos] = 0;
		else if(strcmp(str, "WHITE") == 0)
			m_sBeamPath.nScannerPolarity[yPos] = 1;
		else if(strcmp(str, "IGNORE") == 0)
			m_sBeamPath.nScannerPolarity[yPos] = 2;

	}
	else if(xPos == 9)
	{
		dTemp = atof(str);
		if(dTemp > 1.0 || dTemp < 0.0) 
		{
			ErrMessage(_T("Contrast Range : 0 <  Contrast < 1") );
			return ;
		}
		m_sBeamPath.dScannerContrast[yPos] = atof(str);
	}
	else if(xPos == 10)
	{
		dTemp = atof(str);
		if(dTemp > 1.0 || dTemp < 0.0) 
		{
			ErrMessage(_T("Brightness Range : 0 <  Brightness < 1") );
			return ;
		}
		m_sBeamPath.dScannerBrightness[yPos] = atof(str);
	}
	m_list.SetItemText(y, x,str);
}

void CPaneSysSetupBeamPathLDD::ListUpdate(CPoint ClickedPos, CString str)
{
	int listcount = GetListIndex();

	int xPos = ClickedPos.x;
	int yPos = ClickedPos.y;

	if(listcount == 0)
	{
		return ;
	}
	else if(listcount == 1) //1
	{
		FillTable0Data(xPos,yPos, str);	
	}
	else if(listcount ==2 )  //2
	{
		FillTable1Data(xPos,yPos, str);	

	}
	else if(listcount ==4) //4
	{
		FillTable2Data(xPos,yPos, str);	
	}
	else if(listcount == 8) //8
	{
		FillTable3Data(xPos,yPos, str);		
	}
	else if( listcount == 16) //16
	{
		FillTable4Data(xPos,yPos, str);	
	}

	else if(listcount == 3) //1,2
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);
		}	
			
	}

	else if(listcount ==5) //1,4
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);
		}	
	}
	else if(listcount ==9) //1,8
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);
		}
	}
	else if(listcount == 17) //1,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable4Data(xPos,yPos, str);
		}
	}
	else if(listcount == 7)  //1,2,4
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos,str);
		}
	}
	else if(listcount ==11)//1,2,8
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT+ TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT+ TABLE1_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
	}
	else if(listcount == 19)//1,2,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT+ TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT+ TABLE1_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}
	else if(listcount == 13)//1,4.8
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
	}
	else if(listcount == 21) //1,4,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}
	else if(listcount == 25) //1,8,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}

	else if(listcount == 15) //1,2,4,8
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos,str);
		}
		else
		{
			xPos-=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
	}

	else if(listcount ==23) //1,2,4,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos,str);
		}
		else
		{
			xPos-=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}

	else if(listcount ==27) //1,2,8,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE3_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else
		{
			xPos-= TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}

	}
	else if(listcount == 29)// 1,4,8,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else
		{
			xPos-=TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}
	else if(listcount == 31) //1,2,4,8,16
	{
		if(xPos < TABLE0_COLUMN_COUNT)
			FillTable0Data(xPos,yPos, str);	
		else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT)
		{
			xPos -= TABLE0_COLUMN_COUNT;
			FillTable1Data(xPos,yPos, str);	
		}
		else if( TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos,str);
		}
		else if( TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT)
		{
			xPos -=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else 
		{
			xPos-=TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}

	// start 2
	else if(listcount == 6) //2,4
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);
		}
	}
	else if(listcount == 10)	//2,8
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);
		}
	}

	else if(listcount == 18) //2,16
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable4Data(xPos,yPos, str);
		}
	}

	else if(listcount == 14) //2,4,8
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
	}

	else if(listcount == 22) //2,4,16
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}
	else if(listcount == 26) //2,8,16
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}

	else if(listcount == 30) //2,4,8,16
	{
		if(xPos < TABLE1_COLUMN_COUNT)
			FillTable1Data(xPos,yPos, str);	
		else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
		{
			xPos -= TABLE1_COLUMN_COUNT;
			FillTable2Data(xPos,yPos, str);	
		}
		else if(TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT)
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos,str);
		}
		else
		{
			xPos -=TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}

	}

	//start 4
	else if(listcount == 12)	//4,8
	{

		if(xPos < TABLE2_COLUMN_COUNT)
			FillTable2Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);
		}

	}
	else if(listcount == 20) //4,16
	{
		if(xPos < TABLE2_COLUMN_COUNT)
			FillTable2Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE2_COLUMN_COUNT;
			FillTable4Data(xPos,yPos, str);
		}
	}

	else if(listcount == 28) //4,8,16
	{
		if(xPos < TABLE2_COLUMN_COUNT)
			FillTable2Data(xPos,yPos, str);	
		else if(TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
		{
			xPos -= TABLE2_COLUMN_COUNT;
			FillTable3Data(xPos,yPos, str);	
		}
		else
		{
			xPos -=TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos,str);
		}
	}

	//start 8	//8,16
	else if(listcount == 24)
	{
		if(xPos <TABLE3_COLUMN_COUNT)
			FillTable3Data(xPos,yPos, str);	
		else
		{
			xPos -= TABLE3_COLUMN_COUNT;
			FillTable4Data(xPos,yPos, str);
		}
	}
}

CString CPaneSysSetupBeamPathLDD::GetChangeValueStr()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));

	for(int i = 0 ;i <= m_nRepeatCount; i++)
	{
		if(
		m_sBeamPath.nInfoId[i] != gBeamPathINI.m_sBeampath.nInfoId[i]||
		m_sBeamPath.dInfoMaskSize[i] != gBeamPathINI.m_sBeampath.dInfoMaskSize[i]||

		m_sBeamPath.dBeamPathBetPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1[i]||
		m_sBeamPath.dBeamPathBetPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2[i]||
		m_sBeamPath.nBeamPathMaskPos1[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[i]||
		m_sBeamPath.nBeamPathMaskPos2[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[i]||
		m_sBeamPath.nBeamPathMaskPos3[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[i]||
		m_sBeamPath.nBeamPathAttenuatePos1[i] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[i]||
		m_sBeamPath.nBeamPathAttenuatePos2[i] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[i]||
		m_sBeamPath.dBeamPathZAxisPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i]||
		m_sBeamPath.dBeamPathZAxisPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i]||
		m_sBeamPath.bBeamPathUseTophat[i] != gBeamPathINI.m_sBeampath.bBeamPathUseTophat[i]||
		m_sBeamPath.bBeamPathLaserPath[i] != gBeamPathINI.m_sBeampath.bBeamPathLaserPath[i]||
		m_sBeamPath.dBeamPathVoltage1[i] != gBeamPathINI.m_sBeampath.dBeamPathVoltage1[i]||
		m_sBeamPath.dBeamPathVoltage2[i] != gBeamPathINI.m_sBeampath.dBeamPathVoltage2[i]||

		m_sBeamPath.dPowOffsetDuty[i] != gBeamPathINI.m_sBeampath.dPowOffsetDuty[i]||
		m_sBeamPath.dPowOffsetAomDelay[i] != gBeamPathINI.m_sBeampath.dPowOffsetAomDelay[i]||
		m_sBeamPath.dPowOffsetAomDuty[i] != gBeamPathINI.m_sBeampath.dPowOffsetAomDuty[i]||
		m_sBeamPath.dPowOffsetAomDual1[i] != gBeamPathINI.m_sBeampath.dPowOffsetAomDual1[i]||
		m_sBeamPath.dPowOffsetAomDual2[i] != gBeamPathINI.m_sBeampath.dPowOffsetAomDual2[i]||
		m_sBeamPath.dPowOffsetVoltage1[i] != gBeamPathINI.m_sBeampath.dPowOffsetVoltage1[i]||
		m_sBeamPath.dPowOffsetVoltage2[i] != gBeamPathINI.m_sBeampath.dPowOffsetVoltage2[i]||

		m_sBeamPath.nPowCompensationFrequency[i] != gBeamPathINI.m_sBeampath.nPowCompensationFrequency[i]||
		m_sBeamPath.dPowCompensationDuty[i] != gBeamPathINI.m_sBeampath.dPowCompensationDuty[i]||
		m_sBeamPath.dPowCompensationAomDelay[i] != gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[i]||
		m_sBeamPath.dPowCompensationAomDuty[i] != gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[i]||
		m_sBeamPath.dPowCompensationTargetMin[i] != gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[i]||
		m_sBeamPath.dPowCompensationTargetMax[i] != gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[i]||
		m_sBeamPath.dPowCompensationDutyOffset[i] != gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[i]||

		m_sBeamPath.dScannerDuty[i] != gBeamPathINI.m_sBeampath.dScannerDuty[i]||
		m_sBeamPath.dScannerAomdelay[i] != gBeamPathINI.m_sBeampath.dScannerAomdelay[i]||
		m_sBeamPath.dScannerAomDuty[i] != gBeamPathINI.m_sBeampath.dScannerAomDuty[i]||
		m_sBeamPath.nScannerTotalShot[i] != gBeamPathINI.m_sBeampath.nScannerTotalShot[i]||
		m_sBeamPath.nScannerVisionCam[i] != gBeamPathINI.m_sBeampath.nScannerVisionCam[i]||
		m_sBeamPath.dScannerVisionModelSize[i] != gBeamPathINI.m_sBeampath.dScannerVisionModelSize[i]||
		m_sBeamPath.dScannerAcceptScoreSize[i] != gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[i]||
		m_sBeamPath.dScannerAcceptScoreRatio[i] != gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[i]||
		m_sBeamPath.nScannerPolarity[i] != gBeamPathINI.m_sBeampath.nScannerPolarity[i]||
		m_sBeamPath.dScannerBrightness[i] != gBeamPathINI.m_sBeampath.dScannerBrightness[i]
		)
		{
			strTemp.Format(_T("| %d : ( %.d, %.3f, %.3f, %.3f, %d, %d, %d, %d, %d, %.3f, %.3f, %d, %d, %.1f, %.1f, %.3f, %.3f, %.1f, %.1f, %.3f ,%.1f , %.1f, %d,%.3f, %.3f, %.3f, %.3f, %.3f,%.3f, %d, %d, %.3f,%.3f, %.3f, %d,%.3f,"), 
				i,
				m_sBeamPath.nInfoId[i] ,
				m_sBeamPath.dInfoMaskSize[i] ,	
				
				m_sBeamPath.dBeamPathBetPos1[i],
				m_sBeamPath.dBeamPathBetPos2[i],
				m_sBeamPath.nBeamPathMaskPos1[i] ,
				m_sBeamPath.nBeamPathMaskPos2[i],
				m_sBeamPath.nBeamPathMaskPos3[i],
				m_sBeamPath.nBeamPathAttenuatePos1[i],
				m_sBeamPath.nBeamPathAttenuatePos2[i] ,
				m_sBeamPath.dBeamPathZAxisPos1[i] ,
				m_sBeamPath.dBeamPathZAxisPos2[i] ,
				m_sBeamPath.bBeamPathUseTophat[i] ,	
				m_sBeamPath.bBeamPathLaserPath[i] ,	
				m_sBeamPath.dBeamPathVoltage1[i] ,	
				m_sBeamPath.dBeamPathVoltage2[i] ,	

				m_sBeamPath.dPowOffsetDuty[i] ,
				m_sBeamPath.dPowOffsetAomDelay[i] ,
				m_sBeamPath.dPowOffsetAomDuty[i] ,	
				m_sBeamPath.dPowOffsetAomDual1[i],
				m_sBeamPath.dPowOffsetAomDual2[i],
				m_sBeamPath.dPowOffsetVoltage1[i],
				m_sBeamPath.dPowOffsetVoltage2[i],

				m_sBeamPath.nPowCompensationFrequency[i] ,
				m_sBeamPath.dPowCompensationDuty[i] ,		
				m_sBeamPath.dPowCompensationAomDelay[i],
				m_sBeamPath.dPowCompensationAomDuty[i] ,
				m_sBeamPath.dPowCompensationTargetMin[i] ,
				m_sBeamPath.dPowCompensationTargetMax[i], 
				m_sBeamPath.dPowCompensationDutyOffset[i] ,	
				
				m_sBeamPath.dScannerDuty[i] ,
				m_sBeamPath.dScannerAomdelay[i],
				m_sBeamPath.dScannerAomDuty[i] ,
				m_sBeamPath.nScannerTotalShot[i] ,
				m_sBeamPath.nScannerVisionCam[i] ,
				m_sBeamPath.dScannerVisionModelSize[i] ,
				m_sBeamPath.dScannerAcceptScoreSize[i] ,
				m_sBeamPath.dScannerAcceptScoreRatio[i] ,
				m_sBeamPath.nScannerPolarity[i] ,
				m_sBeamPath.dScannerBrightness[i]
		);
			strMessage += strTemp;
		}		

	}

	if(
		strcmp ( m_sBeamPath.strPowCompensationAomFile, gBeamPathINI.m_sBeampath.strPowCompensationAomFile) !=0||
		m_sBeamPath.dScannerJumpDelay != gBeamPathINI.m_sBeampath.dScannerJumpDelay||
		m_sBeamPath.nFixedMask!= gBeamPathINI.m_sBeampath.nFixedMask)
	{
		strTemp.Format(_T(", %d,%d "), m_sBeamPath.dScannerJumpDelay,
			m_sBeamPath.nFixedMask	);
		strMessage += strTemp;
	}

	for(int i = 0 ;i <= m_nRepeatCount; i++)
	{
		if(
			strcmp(m_sBeamPath.strInfoName[i], gBeamPathINI.m_sBeampath.strInfoName[i]) !=0 ||
			strcmp( m_sBeamPath.strBeamPathAscFile[i] , gBeamPathINI.m_sBeampath.strBeamPathAscFile[i]) !=0
		)
		{
			strTemp.Format(_T(",%s,%s "),m_sBeamPath.strBeamPathAscFile[i] , m_sBeamPath.strBeamPathAscFile[i]);
		}
		strMessage += strTemp;
	}

	if(0 != strMessage.Compare( _T("") ))
	{
		strTemp.Format(_T(" )"));
		strMessage += strTemp;
	}
	
	return strMessage;
}

void CPaneSysSetupBeamPathLDD::OnCheckAdd()
{
	//GetCurrentASC();
	BOOL bSelect = FALSE;
	m_nRepeatCount++;

	if(m_nRepeatCount >= BEAMPATH_COUNT)
	{
		m_nRepeatCount--;
		return ;
	}
	for(int i =0; i <BEAMPATH_COUNT; i++)
	{
		if(m_sBeamPath.bSelectedList[i])
			bSelect = TRUE;
	}
	if(bSelect)
		m_ClickID = TRUE;
	else
		m_ClickID = FALSE;

	m_sBeamPath.nInfoId[m_nRepeatCount] = m_nRepeatCount;

	if(TRUE == m_ClickID)
	{
//		int nCopyNo = GetIdNoToAddDel();
		int nCopyNo = 0;
		for(int i = 0; i < BEAMPATH_COUNT; i++)
		{
			if(m_sBeamPath.bSelectedList[i])
			{
				nCopyNo = i - 1;
				break;
			}
		}

		m_sBeamPath.dInfoMaskSize[m_nRepeatCount]			=	m_sBeamPath.dInfoMaskSize[nCopyNo];			
		m_sBeamPath.dBeamPathBetPos1[m_nRepeatCount]		=	m_sBeamPath.dBeamPathBetPos1[nCopyNo];
		m_sBeamPath.dBeamPathBetPos2[m_nRepeatCount]		=	m_sBeamPath.dBeamPathBetPos2[nCopyNo];
		m_sBeamPath.nBeamPathMaskPos1[m_nRepeatCount]		=	m_sBeamPath.nBeamPathMaskPos1[nCopyNo];
		m_sBeamPath.nBeamPathMaskPos2[m_nRepeatCount]		=	m_sBeamPath.nBeamPathMaskPos2[nCopyNo];
		m_sBeamPath.nBeamPathMaskPos3[m_nRepeatCount]		=	m_sBeamPath.nBeamPathMaskPos3[nCopyNo];
		m_sBeamPath.nBeamPathAttenuatePos1[m_nRepeatCount]	=	m_sBeamPath.nBeamPathAttenuatePos1[nCopyNo];
		m_sBeamPath.nBeamPathAttenuatePos2[m_nRepeatCount]	=	m_sBeamPath.nBeamPathAttenuatePos2[nCopyNo];
		m_sBeamPath.dBeamPathZAxisPos1[m_nRepeatCount]		=	m_sBeamPath.dBeamPathZAxisPos1[nCopyNo];
		m_sBeamPath.dBeamPathZAxisPos2[m_nRepeatCount]		=	m_sBeamPath.dBeamPathZAxisPos2[nCopyNo]; 
		m_sBeamPath.bBeamPathUseTophat[m_nRepeatCount]		=	m_sBeamPath.bBeamPathUseTophat[nCopyNo];
		m_sBeamPath.bBeamPathLaserPath[m_nRepeatCount]		=   m_sBeamPath.bBeamPathLaserPath[nCopyNo];
		m_sBeamPath.dBeamPathVoltage1[m_nRepeatCount]		=	m_sBeamPath.dBeamPathVoltage1[nCopyNo];
		m_sBeamPath.dBeamPathVoltage2[m_nRepeatCount]		=	m_sBeamPath.dBeamPathVoltage2[nCopyNo];
		m_sBeamPath.dPowOffsetDuty[m_nRepeatCount]			=	m_sBeamPath.dPowOffsetDuty[nCopyNo];
		m_sBeamPath.dPowOffsetAomDelay[m_nRepeatCount]		=	m_sBeamPath.dPowOffsetAomDelay[nCopyNo];
		m_sBeamPath.dPowOffsetAomDuty[m_nRepeatCount]		=	m_sBeamPath.dPowOffsetAomDuty[nCopyNo];	
		m_sBeamPath.dPowOffsetAomDual1[m_nRepeatCount]		=	m_sBeamPath.dPowOffsetAomDual1[nCopyNo];
		m_sBeamPath.dPowOffsetAomDual2[m_nRepeatCount]		=	m_sBeamPath.dPowOffsetAomDual2[nCopyNo];	
		m_sBeamPath.dPowOffsetVoltage1[m_nRepeatCount]		=	m_sBeamPath.dPowOffsetVoltage1[nCopyNo];
		m_sBeamPath.dPowOffsetVoltage2[m_nRepeatCount]		=	m_sBeamPath.dPowOffsetVoltage2[nCopyNo];	
		m_sBeamPath.nPowCompensationFrequency[m_nRepeatCount] = m_sBeamPath.nPowCompensationFrequency[nCopyNo];
		m_sBeamPath.dPowCompensationDuty[m_nRepeatCount]	 =	m_sBeamPath.dPowCompensationDuty[nCopyNo];
		m_sBeamPath.dPowCompensationAomDelay[m_nRepeatCount]=	m_sBeamPath.dPowCompensationAomDelay[nCopyNo];
		m_sBeamPath.dPowCompensationAomDuty[m_nRepeatCount] =	m_sBeamPath.dPowCompensationAomDuty[nCopyNo];
		m_sBeamPath.dPowCompensationTargetMin[m_nRepeatCount] = m_sBeamPath.dPowCompensationTargetMin[nCopyNo];
		m_sBeamPath.dPowCompensationTargetMax[m_nRepeatCount] = m_sBeamPath.dPowCompensationTargetMax[nCopyNo];
		m_sBeamPath.dPowCompensationDutyOffset[m_nRepeatCount] =m_sBeamPath.dPowCompensationDutyOffset[nCopyNo];
		m_sBeamPath.dScannerDuty[m_nRepeatCount]			=	m_sBeamPath.dScannerDuty[nCopyNo];
		m_sBeamPath.dScannerAomDuty[m_nRepeatCount]			=	m_sBeamPath.dScannerAomDuty[nCopyNo];
		m_sBeamPath.dScannerAomdelay[m_nRepeatCount]		=	m_sBeamPath.dScannerAomdelay[nCopyNo];
		m_sBeamPath.nScannerTotalShot[m_nRepeatCount]		=	m_sBeamPath.nScannerTotalShot[nCopyNo];
		m_sBeamPath.nScannerVisionCam[m_nRepeatCount]		=	m_sBeamPath.nScannerVisionCam[nCopyNo] ;
		m_sBeamPath.dScannerVisionModelSize[m_nRepeatCount] =	m_sBeamPath.dScannerVisionModelSize[nCopyNo];
		m_sBeamPath.nScannerPolarity[m_nRepeatCount]		=	m_sBeamPath.nScannerPolarity[nCopyNo];
		m_sBeamPath.dScannerAcceptScoreSize[m_nRepeatCount] =	m_sBeamPath.dScannerAcceptScoreSize[nCopyNo];
		m_sBeamPath.dScannerAcceptScoreRatio[m_nRepeatCount] =	m_sBeamPath.dScannerAcceptScoreRatio[nCopyNo];
		m_sBeamPath.dScannerContrast[m_nRepeatCount]		=	m_sBeamPath.dScannerContrast[nCopyNo];
		m_sBeamPath.dScannerBrightness[m_nRepeatCount]		=	m_sBeamPath.dScannerBrightness[nCopyNo];
		
		strcpy_s(m_sBeamPath.strInfoName[m_nRepeatCount],m_sBeamPath.strInfoName[nCopyNo]);
		strcpy_s( m_sBeamPath.strBeamPathAscFile[m_nRepeatCount] ,m_sBeamPath.strBeamPathAscFile[nCopyNo]);

//		m_ClickID = FALSE; //111021
	}
	else
	{
		m_sBeamPath.dInfoMaskSize[m_nRepeatCount]			=	m_sBeamPath.dInfoMaskSize[m_nRepeatCount-1];			
		m_sBeamPath.dBeamPathBetPos1[m_nRepeatCount]		=	m_sBeamPath.dBeamPathBetPos1[m_nRepeatCount-1];
		m_sBeamPath.dBeamPathBetPos2[m_nRepeatCount]		=	m_sBeamPath.dBeamPathBetPos2[m_nRepeatCount-1];
		m_sBeamPath.nBeamPathMaskPos1[m_nRepeatCount]		=	m_sBeamPath.nBeamPathMaskPos1[m_nRepeatCount-1];
		m_sBeamPath.nBeamPathMaskPos2[m_nRepeatCount]		=	m_sBeamPath.nBeamPathMaskPos2[m_nRepeatCount-1];
		m_sBeamPath.nBeamPathMaskPos3[m_nRepeatCount]		=	m_sBeamPath.nBeamPathMaskPos3[m_nRepeatCount-1];
		m_sBeamPath.nBeamPathAttenuatePos1[m_nRepeatCount]	=	m_sBeamPath.nBeamPathAttenuatePos1[m_nRepeatCount-1];
		m_sBeamPath.nBeamPathAttenuatePos2[m_nRepeatCount]	=	m_sBeamPath.nBeamPathAttenuatePos2[m_nRepeatCount-1];
		m_sBeamPath.dBeamPathZAxisPos1[m_nRepeatCount]		=	m_sBeamPath.dBeamPathZAxisPos1[m_nRepeatCount-1];
		m_sBeamPath.dBeamPathZAxisPos2[m_nRepeatCount]		=	m_sBeamPath.dBeamPathZAxisPos2[m_nRepeatCount-1]; 
		m_sBeamPath.bBeamPathUseTophat[m_nRepeatCount]		=	m_sBeamPath.bBeamPathUseTophat[m_nRepeatCount-1];
		m_sBeamPath.bBeamPathLaserPath[m_nRepeatCount]		=   m_sBeamPath.bBeamPathLaserPath[m_nRepeatCount-1];
		m_sBeamPath.dBeamPathVoltage1[m_nRepeatCount]		=	m_sBeamPath.dBeamPathVoltage1[m_nRepeatCount-1];
		m_sBeamPath.dBeamPathVoltage2[m_nRepeatCount]		=	m_sBeamPath.dBeamPathVoltage2[m_nRepeatCount-1];
		m_sBeamPath.dPowOffsetDuty[m_nRepeatCount]			=	m_sBeamPath.dPowOffsetDuty[m_nRepeatCount-1];
		m_sBeamPath.dPowOffsetAomDelay[m_nRepeatCount]		=	m_sBeamPath.dPowOffsetAomDelay[m_nRepeatCount-1];
		m_sBeamPath.dPowOffsetAomDuty[m_nRepeatCount]		=	m_sBeamPath.dPowOffsetAomDuty[m_nRepeatCount-1];	
		m_sBeamPath.dPowOffsetAomDual1[m_nRepeatCount]		=	m_sBeamPath.dPowOffsetAomDual1[m_nRepeatCount-1];
		m_sBeamPath.dPowOffsetAomDual2[m_nRepeatCount]		=	m_sBeamPath.dPowOffsetAomDual2[m_nRepeatCount-1];	
		m_sBeamPath.dPowOffsetVoltage1[m_nRepeatCount]		=	m_sBeamPath.dPowOffsetVoltage1[m_nRepeatCount-1];
		m_sBeamPath.dPowOffsetVoltage2[m_nRepeatCount]		=	m_sBeamPath.dPowOffsetVoltage2[m_nRepeatCount-1];	
		m_sBeamPath.nPowCompensationFrequency[m_nRepeatCount] = m_sBeamPath.nPowCompensationFrequency[m_nRepeatCount-1];
		m_sBeamPath.dPowCompensationDuty[m_nRepeatCount]	 =	m_sBeamPath.dPowCompensationDuty[m_nRepeatCount-1];
		m_sBeamPath.dPowCompensationAomDelay[m_nRepeatCount]=	m_sBeamPath.dPowCompensationAomDelay[m_nRepeatCount-1];
		m_sBeamPath.dPowCompensationAomDuty[m_nRepeatCount] =	m_sBeamPath.dPowCompensationAomDuty[m_nRepeatCount-1];
		m_sBeamPath.dPowCompensationTargetMin[m_nRepeatCount] = m_sBeamPath.dPowCompensationTargetMin[m_nRepeatCount-1];
		m_sBeamPath.dPowCompensationTargetMax[m_nRepeatCount] = m_sBeamPath.dPowCompensationTargetMax[m_nRepeatCount-1];
		m_sBeamPath.dPowCompensationDutyOffset[m_nRepeatCount] =m_sBeamPath.dPowCompensationDutyOffset[m_nRepeatCount-1];
		m_sBeamPath.dScannerDuty[m_nRepeatCount]			=	m_sBeamPath.dScannerDuty[m_nRepeatCount-1];
		m_sBeamPath.dScannerAomDuty[m_nRepeatCount]			=	m_sBeamPath.dScannerAomDuty[m_nRepeatCount-1];
		m_sBeamPath.dScannerAomdelay[m_nRepeatCount]		=	m_sBeamPath.dScannerAomdelay[m_nRepeatCount-1];
		m_sBeamPath.nScannerTotalShot[m_nRepeatCount]		=	m_sBeamPath.nScannerTotalShot[m_nRepeatCount-1];
		m_sBeamPath.nScannerVisionCam[m_nRepeatCount]		=	m_sBeamPath.nScannerVisionCam[m_nRepeatCount-1] ;
		m_sBeamPath.dScannerVisionModelSize[m_nRepeatCount] =	m_sBeamPath.dScannerVisionModelSize[m_nRepeatCount-1];
		m_sBeamPath.nScannerPolarity[m_nRepeatCount]		=	m_sBeamPath.nScannerPolarity[m_nRepeatCount-1];
		m_sBeamPath.dScannerAcceptScoreSize[m_nRepeatCount] =	m_sBeamPath.dScannerAcceptScoreSize[m_nRepeatCount-1];
		m_sBeamPath.dScannerAcceptScoreRatio[m_nRepeatCount] =	m_sBeamPath.dScannerAcceptScoreRatio[m_nRepeatCount-1];
		m_sBeamPath.dScannerContrast[m_nRepeatCount]		=	m_sBeamPath.dScannerContrast[m_nRepeatCount-1];
		m_sBeamPath.dScannerBrightness[m_nRepeatCount]		=	m_sBeamPath.dScannerBrightness[m_nRepeatCount-1];

		m_sBeamPath.nHoleVisionCam[m_nRepeatCount]			=	m_sBeamPath.nHoleVisionCam[m_nRepeatCount-1] ;
		m_sBeamPath.dHoleVisionModelSize[m_nRepeatCount]	=	m_sBeamPath.dHoleVisionModelSize[m_nRepeatCount-1];
		m_sBeamPath.nHolePolarity[m_nRepeatCount]			=	m_sBeamPath.nHolePolarity[m_nRepeatCount-1];
		m_sBeamPath.dHoleAcceptScoreSize[m_nRepeatCount]	=	m_sBeamPath.dHoleAcceptScoreSize[m_nRepeatCount-1];
		m_sBeamPath.dHoleAcceptScoreRatio[m_nRepeatCount]	=	m_sBeamPath.dHoleAcceptScoreRatio[m_nRepeatCount-1];
		m_sBeamPath.dHoleContrast[m_nRepeatCount]			=	m_sBeamPath.dHoleContrast[m_nRepeatCount-1];
		m_sBeamPath.dHoleBrightness[m_nRepeatCount]			=	m_sBeamPath.dHoleBrightness[m_nRepeatCount-1];

		strcpy_s(m_sBeamPath.strInfoName[m_nRepeatCount],m_sBeamPath.strInfoName[m_nRepeatCount-1]);
		strcpy_s( m_sBeamPath.strBeamPathAscFile[m_nRepeatCount] ,m_sBeamPath.strBeamPathAscFile[m_nRepeatCount-1]);
	}

	OnCheckRefresh();
}

void CPaneSysSetupBeamPathLDD::OnCheckDel()
{
	if(m_bCheckBox[1])
		GetCurrentASC();
	BOOL bSelect = FALSE;
	if(m_posClicked.y == -1)
		return ;

	for(int i =0; i <BEAMPATH_COUNT; i++)
	{
		if(m_sBeamPath.bSelectedList[i])
			bSelect = TRUE;
	}
	if(bSelect)
		m_ClickID = TRUE;
	else
		m_ClickID = FALSE;

	if(FALSE == m_ClickID)
	{
		ErrMessage(_T("Please select the items you want to delete."));
		return ;
	}

	if(m_nRepeatCount < 0)
	{
		return ;
	}

	for(int i = 0; i <BEAMPATH_COUNT; i++)
	{
//		int nDelNo = GetIdNoToAddDel();
		int nDelNo;
		if(m_sBeamPath.bSelectedList[i])
			nDelNo = i - 1;
		else 
			continue;
			
		
		// 	CString str;									/// �����Ҵ� yes,no ����
		// 	str.Format(_T("%d �׸��� �����մϴ� "),nDelNo);
		// 
		// 	if (ErrMessage(str,MB_YESNO,NULL) ==  IDYES)
		// 	{
		CopyFromOriginaltoTemp(nDelNo,m_nRepeatCount);
		m_nRepeatCount--;	
		
		CopyFromTempToOriginal();
		OnCheckRefresh();
		InitDataStruct();		// �ӽ� ����ü �ʱ�ȭ 
		//	}
	}
	m_ClickID = FALSE;
}

//del �� ����׸��� �Ѵٰ� �Ͽ��� �� 
//ó�� ����� ������ �׸� ���� ���� ������  temp ����������-> ������ ������ �������� ������ ������ ���� temp ������ ����->
// ������������ ������ ���� ������ �ʱ�ȭ 
void CPaneSysSetupBeamPathLDD::CopyFromOriginaltoTemp(int nSelectNo, int RepeatNo)
{
	int i = 0;

	for(i = 0 ;i < nSelectNo; i++)
	{
		m_sTempBeamPath.dInfoMaskSize[i]			=	m_sBeamPath.dInfoMaskSize[i];			
		m_sTempBeamPath.dBeamPathBetPos1[i]			=	m_sBeamPath.dBeamPathBetPos1[i];
		m_sTempBeamPath.dBeamPathBetPos2[i]			=	m_sBeamPath.dBeamPathBetPos2[i];
		m_sTempBeamPath.nBeamPathMaskPos1[i]		=	m_sBeamPath.nBeamPathMaskPos1[i];
		m_sTempBeamPath.nBeamPathMaskPos2[i]		=	m_sBeamPath.nBeamPathMaskPos2[i];
		m_sTempBeamPath.nBeamPathMaskPos3[i]		=	m_sBeamPath.nBeamPathMaskPos3[i];
		m_sTempBeamPath.nBeamPathAttenuatePos1[i]	=	m_sBeamPath.nBeamPathAttenuatePos1[i];
		m_sTempBeamPath.nBeamPathAttenuatePos2[i]	=	m_sBeamPath.nBeamPathAttenuatePos2[i];
		m_sTempBeamPath.dBeamPathZAxisPos1[i]		=	m_sBeamPath.dBeamPathZAxisPos1[i];
		m_sTempBeamPath.dBeamPathZAxisPos2[i]		=	m_sBeamPath.dBeamPathZAxisPos2[i]; 
		m_sTempBeamPath.bBeamPathUseTophat[i]		=	m_sBeamPath.bBeamPathUseTophat[i];
		m_sTempBeamPath.bBeamPathLaserPath[i]		=	m_sBeamPath.bBeamPathLaserPath[i];
		m_sTempBeamPath.dBeamPathVoltage1[i]		=	m_sBeamPath.dBeamPathVoltage1[i];
		m_sTempBeamPath.dBeamPathVoltage2[i]		=	m_sBeamPath.dBeamPathVoltage2[i];
		
		m_sTempBeamPath.dPowOffsetDuty[i]			=	m_sBeamPath.dPowOffsetDuty[i];
		m_sTempBeamPath.dPowOffsetAomDelay[i]		=	m_sBeamPath.dPowOffsetAomDelay[i];
		m_sTempBeamPath.dPowOffsetAomDuty[i]		=	m_sBeamPath.dPowOffsetAomDuty[i];	
		m_sTempBeamPath.dPowOffsetAomDual1[i]		=	m_sBeamPath.dPowOffsetAomDual1[i];
		m_sTempBeamPath.dPowOffsetAomDual2[i]		=	m_sBeamPath.dPowOffsetAomDual2[i];	
		m_sTempBeamPath.dPowOffsetVoltage1[i]		=	m_sBeamPath.dPowOffsetVoltage1[i];
		m_sTempBeamPath.dPowOffsetVoltage2[i]		=	m_sBeamPath.dPowOffsetVoltage2[i];

		m_sTempBeamPath.nPowCompensationFrequency[i] = m_sBeamPath.nPowCompensationFrequency[i];
		m_sTempBeamPath.dPowCompensationDuty[i]		 =	m_sBeamPath.dPowCompensationDuty[i];
		m_sTempBeamPath.dPowCompensationAomDelay[i]	 =	m_sBeamPath.dPowCompensationAomDelay[i];
		m_sTempBeamPath.dPowCompensationAomDuty[i]   =	m_sBeamPath.dPowCompensationAomDuty[i];
		m_sTempBeamPath.dPowCompensationTargetMin[i] = m_sBeamPath.dPowCompensationTargetMin[i];
		m_sTempBeamPath.dPowCompensationTargetMax[i] = m_sBeamPath.dPowCompensationTargetMax[i];
		m_sTempBeamPath.dPowCompensationDutyOffset[i] =m_sBeamPath.dPowCompensationDutyOffset[i];
		m_sTempBeamPath.dScannerDuty[i]				=	m_sBeamPath.dScannerDuty[i];
		m_sTempBeamPath.dScannerAomDuty[i]			=	m_sBeamPath.dScannerAomDuty[i];
		m_sTempBeamPath.dScannerAomdelay[i]			=	m_sBeamPath.dScannerAomdelay[i];
		m_sTempBeamPath.nScannerTotalShot[i]		=	m_sBeamPath.nScannerTotalShot[i];
		m_sTempBeamPath.nScannerVisionCam[i]		=	m_sBeamPath.nScannerVisionCam[i] ;
		m_sTempBeamPath.dScannerVisionModelSize[i]	=	m_sBeamPath.dScannerVisionModelSize[i];
		m_sTempBeamPath.nScannerPolarity[i]			=	m_sBeamPath.nScannerPolarity[i];
		m_sTempBeamPath.dScannerAcceptScoreSize[i]	=	m_sBeamPath.dScannerAcceptScoreSize[i];
		m_sTempBeamPath.dScannerAcceptScoreRatio[i] =	m_sBeamPath.dScannerAcceptScoreRatio[i];
		m_sTempBeamPath.dScannerContrast[i]			=	m_sBeamPath.dScannerContrast[i];
		m_sTempBeamPath.dScannerBrightness[i]		=	m_sBeamPath.dScannerBrightness[i];
		
		strcpy_s(m_sTempBeamPath.strInfoName[i],m_sBeamPath.strInfoName[i]);
		strcpy_s( m_sTempBeamPath.strBeamPathAscFile[i] ,m_sBeamPath.strBeamPathAscFile[i]);
	}

	for(i = nSelectNo + 1; i <= RepeatNo;i++)
	{
		m_sTempBeamPath.dInfoMaskSize[i-1]			=	m_sBeamPath.dInfoMaskSize[i];			
		m_sTempBeamPath.dBeamPathBetPos1[i-1]		=	m_sBeamPath.dBeamPathBetPos1[i];
		m_sTempBeamPath.dBeamPathBetPos2[i-1]		=	m_sBeamPath.dBeamPathBetPos2[i];
		m_sTempBeamPath.nBeamPathMaskPos1[i-1]		=	m_sBeamPath.nBeamPathMaskPos1[i];
		m_sTempBeamPath.nBeamPathMaskPos2[i-1]		=	m_sBeamPath.nBeamPathMaskPos2[i];
		m_sTempBeamPath.nBeamPathMaskPos3[i-1]		=	m_sBeamPath.nBeamPathMaskPos3[i];
		m_sTempBeamPath.nBeamPathAttenuatePos1[i-1]	=	m_sBeamPath.nBeamPathAttenuatePos1[i];
		m_sTempBeamPath.nBeamPathAttenuatePos2[i-1]	=	m_sBeamPath.nBeamPathAttenuatePos2[i];
		m_sTempBeamPath.dBeamPathZAxisPos1[i-1]		=	m_sBeamPath.dBeamPathZAxisPos1[i];
		m_sTempBeamPath.dBeamPathZAxisPos2[i-1]		=	m_sBeamPath.dBeamPathZAxisPos2[i]; 
		m_sTempBeamPath.bBeamPathUseTophat[i-1]		=	m_sBeamPath.bBeamPathUseTophat[i];	
		m_sTempBeamPath.bBeamPathLaserPath[i-1]		=	m_sBeamPath.bBeamPathLaserPath[i];	
		m_sTempBeamPath.dBeamPathVoltage1[i-1]		=	m_sBeamPath.dBeamPathVoltage1[i];
		m_sTempBeamPath.dBeamPathVoltage2[i-1]		=	m_sBeamPath.dBeamPathVoltage2[i];
		m_sTempBeamPath.dPowOffsetDuty[i-1]			=	m_sBeamPath.dPowOffsetDuty[i];
		m_sTempBeamPath.dPowOffsetAomDelay[i-1]		=	m_sBeamPath.dPowOffsetAomDelay[i];
		m_sTempBeamPath.dPowOffsetAomDuty[i-1]		=	m_sBeamPath.dPowOffsetAomDuty[i];
		m_sTempBeamPath.dPowOffsetAomDual1[i-1]		=	m_sBeamPath.dPowOffsetAomDual1[i];
		m_sTempBeamPath.dPowOffsetAomDual2[i-1]		=	m_sBeamPath.dPowOffsetAomDual2[i];
		m_sTempBeamPath.dPowOffsetVoltage1[i-1]		=	m_sBeamPath.dPowOffsetVoltage1[i];
		m_sTempBeamPath.dPowOffsetVoltage2[i-1]		=	m_sBeamPath.dPowOffsetVoltage2[i];
		m_sTempBeamPath.nPowCompensationFrequency[i-1]	= m_sBeamPath.nPowCompensationFrequency[i];
		m_sTempBeamPath.dPowCompensationDuty[i-1]		=	m_sBeamPath.dPowCompensationDuty[i];
		m_sTempBeamPath.dPowCompensationAomDelay[i-1]	=	m_sBeamPath.dPowCompensationAomDelay[i];
		m_sTempBeamPath.dPowCompensationAomDuty[i-1]	=	m_sBeamPath.dPowCompensationAomDuty[i];
		m_sTempBeamPath.dPowCompensationTargetMin[i-1]	= m_sBeamPath.dPowCompensationTargetMin[i];
		m_sTempBeamPath.dPowCompensationTargetMax[i-1]	= m_sBeamPath.dPowCompensationTargetMax[i];
		m_sTempBeamPath.dPowCompensationDutyOffset[i-1] =m_sBeamPath.dPowCompensationDutyOffset[i];
		m_sTempBeamPath.dScannerDuty[i-1]				=	m_sBeamPath.dScannerDuty[i];
		m_sTempBeamPath.dScannerAomDuty[i-1]			=	m_sBeamPath.dScannerAomDuty[i];
		m_sTempBeamPath.dScannerAomdelay[i-1]			=	m_sBeamPath.dScannerAomdelay[i];
		m_sTempBeamPath.nScannerTotalShot[i-1]			=	m_sBeamPath.nScannerTotalShot[i];
		m_sTempBeamPath.nScannerVisionCam[i-1]			=	m_sBeamPath.nScannerVisionCam[i] ;
		m_sTempBeamPath.dScannerVisionModelSize[i-1]	=	m_sBeamPath.dScannerVisionModelSize[i];
		m_sTempBeamPath.nScannerPolarity[i-1]			=	m_sBeamPath.nScannerPolarity[i];
		m_sTempBeamPath.dScannerAcceptScoreSize[i-1]	=	m_sBeamPath.dScannerAcceptScoreSize[i];
		m_sTempBeamPath.dScannerAcceptScoreRatio[i-1]	=	m_sBeamPath.dScannerAcceptScoreRatio[i];
		m_sTempBeamPath.dScannerContrast[i-1]			=	m_sBeamPath.dScannerContrast[i];
		m_sTempBeamPath.dScannerBrightness[i-1]			=	m_sBeamPath.dScannerBrightness[i];
		
		strcpy_s(m_sTempBeamPath.strInfoName[i-1],m_sBeamPath.strInfoName[i]);
		strcpy_s( m_sTempBeamPath.strBeamPathAscFile[i-1] ,m_sBeamPath.strBeamPathAscFile[i]);
	}


	// ���� �����Ͱ� ��ĭ�� ���� �ö󰬱� ������ ������ �� ������ ���� �ʱ�ȭ �Ѵ�. 
	m_sBeamPath.nInfoId[RepeatNo] = i;
	m_sBeamPath.dInfoMaskSize[RepeatNo]= 0;
	
	m_sBeamPath.dBeamPathBetPos1[RepeatNo]= 0;
	m_sBeamPath.dBeamPathBetPos2[RepeatNo]= 0;
	m_sBeamPath.nBeamPathMaskPos1[RepeatNo]= 0;
	m_sBeamPath.nBeamPathMaskPos2[RepeatNo]= 0;
	m_sBeamPath.nBeamPathMaskPos3[RepeatNo]= 0;
	m_sBeamPath.nBeamPathAttenuatePos1[RepeatNo]= 0;
	m_sBeamPath.nBeamPathAttenuatePos2[RepeatNo] = 0;
	m_sBeamPath.dBeamPathZAxisPos1[RepeatNo] = 0;
	m_sBeamPath.dBeamPathZAxisPos2[RepeatNo]= 0; 
	m_sBeamPath.bBeamPathUseTophat[RepeatNo] = 0;	
	
	m_sBeamPath.dPowOffsetDuty[RepeatNo] = 0;
	m_sBeamPath.dPowOffsetAomDelay[RepeatNo] = 0;
	m_sBeamPath.dPowOffsetAomDuty[RepeatNo] = 0;	
	m_sBeamPath.dPowOffsetAomDual1[RepeatNo] = 0;
	m_sBeamPath.dPowOffsetAomDual2[RepeatNo] = 0;
	m_sBeamPath.dPowOffsetVoltage1[RepeatNo] = 0;
	m_sBeamPath.dPowOffsetVoltage2[RepeatNo] = 0;	

	m_sBeamPath.nPowCompensationFrequency[RepeatNo] = 0;
	m_sBeamPath.dPowCompensationDuty[RepeatNo] = 0;
	m_sBeamPath.dPowCompensationAomDelay[RepeatNo]= 0;
	m_sBeamPath.dPowCompensationAomDuty[RepeatNo] = 0;
	m_sBeamPath.dPowCompensationTargetMin[RepeatNo] = 0;
	m_sBeamPath.dPowCompensationTargetMax[RepeatNo] = 0;
	m_sBeamPath.dPowCompensationDutyOffset[RepeatNo] = 0;
	
	m_sBeamPath.dScannerDuty[RepeatNo] = 0;
	m_sBeamPath.dScannerAomDuty[RepeatNo]= 0;
	m_sBeamPath.dScannerAomdelay[RepeatNo] = 0;
	m_sBeamPath.nScannerTotalShot[RepeatNo] = 0;
	m_sBeamPath.nScannerVisionCam[RepeatNo] = 0;
	m_sBeamPath.dScannerVisionModelSize[RepeatNo] = 0;
	m_sBeamPath.nScannerPolarity[RepeatNo] = 0;
	m_sBeamPath.dScannerAcceptScoreSize[RepeatNo] = 0;
	m_sBeamPath.dScannerAcceptScoreRatio[RepeatNo] = 0;
	m_sBeamPath.dScannerContrast[RepeatNo] = 0;
	m_sBeamPath.dScannerBrightness[RepeatNo]= 0;
	
	strcpy_s(m_sBeamPath.strInfoName[RepeatNo],"-");
	strcpy_s( m_sBeamPath.strBeamPathAscFile[RepeatNo] ,"-");
}

void CPaneSysSetupBeamPathLDD::CopyFromTempToOriginal()
{
	for(int i = 0 ;i <= m_nRepeatCount; i++)
	{
		m_sBeamPath.dInfoMaskSize[i]			=	m_sTempBeamPath.dInfoMaskSize[i];
		
		m_sBeamPath.dBeamPathBetPos1[i]			=	m_sTempBeamPath.dBeamPathBetPos1[i];
		m_sBeamPath.dBeamPathBetPos2[i]			=	m_sTempBeamPath.dBeamPathBetPos2[i];
		m_sBeamPath.nBeamPathMaskPos1[i]		=	m_sTempBeamPath.nBeamPathMaskPos1[i];
		m_sBeamPath.nBeamPathMaskPos2[i]		=	m_sTempBeamPath.nBeamPathMaskPos2[i];
		m_sBeamPath.nBeamPathMaskPos3[i]		=	m_sTempBeamPath.nBeamPathMaskPos3[i];
		m_sBeamPath.nBeamPathAttenuatePos1[i]	=	m_sTempBeamPath.nBeamPathAttenuatePos1[i];
		m_sBeamPath.nBeamPathAttenuatePos2[i]	=	m_sTempBeamPath.nBeamPathAttenuatePos2[i];
		m_sBeamPath.dBeamPathZAxisPos1[i]		=	m_sTempBeamPath.dBeamPathZAxisPos1[i];
		m_sBeamPath.dBeamPathZAxisPos2[i]		=	m_sTempBeamPath.dBeamPathZAxisPos2[i]; 
		m_sBeamPath.bBeamPathUseTophat[i]		=	m_sTempBeamPath.bBeamPathUseTophat[i];
		m_sBeamPath.bBeamPathLaserPath[i]		=	m_sTempBeamPath.bBeamPathLaserPath[i];
		m_sBeamPath.dBeamPathVoltage1[i]		=	m_sTempBeamPath.dBeamPathVoltage1[i];
		m_sBeamPath.dBeamPathVoltage2[i]		=	m_sTempBeamPath.dBeamPathVoltage2[i];
		
		m_sBeamPath.dPowOffsetDuty[i]			=	m_sTempBeamPath.dPowOffsetDuty[i];
		m_sBeamPath.dPowOffsetAomDelay[i]		=	m_sTempBeamPath.dPowOffsetAomDelay[i];
		m_sBeamPath.dPowOffsetAomDuty[i]		=	m_sTempBeamPath.dPowOffsetAomDuty[i];	
		m_sBeamPath.dPowOffsetAomDual1[i]		=	m_sTempBeamPath.dPowOffsetAomDual1[i];
		m_sBeamPath.dPowOffsetAomDual2[i]		=	m_sTempBeamPath.dPowOffsetAomDual2[i];	
		m_sBeamPath.dPowOffsetVoltage1[i]		=	m_sTempBeamPath.dPowOffsetVoltage1[i];
		m_sBeamPath.dPowOffsetVoltage2[i]		=	m_sTempBeamPath.dPowOffsetVoltage2[i];
		
		m_sBeamPath.nPowCompensationFrequency[i] = m_sTempBeamPath.nPowCompensationFrequency[i];
		m_sBeamPath.dPowCompensationDuty[i]		=	m_sTempBeamPath.dPowCompensationDuty[i];
		m_sBeamPath.dPowCompensationAomDelay[i]	=	m_sTempBeamPath.dPowCompensationAomDelay[i];
		m_sBeamPath.dPowCompensationAomDuty[i]	=	m_sTempBeamPath.dPowCompensationAomDuty[i];
		m_sBeamPath.dPowCompensationTargetMin[i] = m_sTempBeamPath.dPowCompensationTargetMin[i];
		m_sBeamPath.dPowCompensationTargetMax[i] = m_sTempBeamPath.dPowCompensationTargetMax[i];
		m_sBeamPath.dPowCompensationDutyOffset[i] =m_sTempBeamPath.dPowCompensationDutyOffset[i];

		m_sBeamPath.dScannerDuty[i]				=	m_sTempBeamPath.dScannerDuty[i];
		m_sBeamPath.dScannerAomDuty[i]			=	m_sTempBeamPath.dScannerAomDuty[i];
		m_sBeamPath.dScannerAomdelay[i]			=	m_sTempBeamPath.dScannerAomdelay[i];
		m_sBeamPath.nScannerTotalShot[i]		=	m_sTempBeamPath.nScannerTotalShot[i];
		m_sBeamPath.nScannerVisionCam[i]		=	m_sTempBeamPath.nScannerVisionCam[i] ;
		m_sBeamPath.dScannerVisionModelSize[i]	=	m_sTempBeamPath.dScannerVisionModelSize[i];
		m_sBeamPath.nScannerPolarity[i]			=	m_sTempBeamPath.nScannerPolarity[i];
		m_sBeamPath.dScannerAcceptScoreSize[i]	=	m_sTempBeamPath.dScannerAcceptScoreSize[i];
		m_sBeamPath.dScannerAcceptScoreRatio[i] =	m_sTempBeamPath.dScannerAcceptScoreRatio[i];
		m_sBeamPath.dScannerContrast[i]			=	m_sTempBeamPath.dScannerContrast[i];
		m_sBeamPath.dScannerBrightness[i]		=	m_sTempBeamPath.dScannerBrightness[i];
		
		strcpy_s(m_sBeamPath.strInfoName[i],m_sTempBeamPath.strInfoName[i]);
		strcpy_s( m_sBeamPath.strBeamPathAscFile[i] ,m_sTempBeamPath.strBeamPathAscFile[i]);
	}
}

void CPaneSysSetupBeamPathLDD::SetIdNoToAddDel(int nIdYPos)
{
	m_IdNoToAddDel = nIdYPos;
}

int CPaneSysSetupBeamPathLDD::GetIdNoToAddDel()
{
	return m_IdNoToAddDel;
}

void CPaneSysSetupBeamPathLDD::InitDataStruct()
{
	m_sTempBeamPath.nLastIndex = m_nRepeatCount;


	for(int i = 0 ;i < BEAMPATH_COUNT; i++)
	{
		m_sTempBeamPath.nInfoId[i] = i;
		m_sTempBeamPath.dInfoMaskSize[i]= 0;
		
		m_sTempBeamPath.dBeamPathBetPos1[i]= 0;
		m_sTempBeamPath.dBeamPathBetPos2[i]= 0;
		m_sTempBeamPath.nBeamPathMaskPos1[i]= 0;
		m_sTempBeamPath.nBeamPathMaskPos2[i]= 0;
		m_sTempBeamPath.nBeamPathMaskPos3[i]= 0;
		m_sTempBeamPath.nBeamPathAttenuatePos1[i]= 0;
		m_sTempBeamPath.nBeamPathAttenuatePos2[i] = 0;
		m_sTempBeamPath.dBeamPathZAxisPos1[i] = 0;
		m_sTempBeamPath.dBeamPathZAxisPos2[i]= 0; 
		m_sTempBeamPath.bBeamPathUseTophat[i] = 0;	
		m_sTempBeamPath.dBeamPathVoltage1[i] = 0;
		m_sTempBeamPath.dBeamPathVoltage2[i]= 0; 
		m_sTempBeamPath.bBeamPathLaserPath[i] = 0;
		
		m_sTempBeamPath.dPowOffsetDuty[i] = 0;
		m_sTempBeamPath.dPowOffsetAomDelay[i] = 0;
		m_sTempBeamPath.dPowOffsetAomDuty[i] = 0;	
		m_sTempBeamPath.dPowOffsetAomDual1[i] = 0;
		m_sTempBeamPath.dPowOffsetAomDual2[i] = 0;	
		m_sTempBeamPath.dPowOffsetVoltage1[i] = 0;
		m_sTempBeamPath.dPowOffsetVoltage2[i] = 0;

		m_sTempBeamPath.nPowCompensationFrequency[i] = 0;
		m_sTempBeamPath.dPowCompensationDuty[i] = 0;
		m_sTempBeamPath.dPowCompensationAomDelay[i]= 0;
		m_sTempBeamPath.dPowCompensationAomDuty[i] = 0;
		m_sTempBeamPath.dPowCompensationTargetMin[i] = 0;
		m_sTempBeamPath.dPowCompensationTargetMax[i] = 0;
		m_sTempBeamPath.dPowCompensationDutyOffset[i] = 0;

		m_sTempBeamPath.dScannerDuty[i] = 0;
		m_sTempBeamPath.dScannerAomDuty[i]= 0;
		m_sTempBeamPath.dScannerAomdelay[i] = 0;
		m_sTempBeamPath.nScannerTotalShot[i] = 0;
		m_sTempBeamPath.nScannerVisionCam[i] = 0;
		m_sTempBeamPath.dScannerVisionModelSize[i] = 0;
		m_sTempBeamPath.nScannerPolarity[i] = 0;
		m_sTempBeamPath.dScannerAcceptScoreSize[i] = 0;
		m_sTempBeamPath.dScannerAcceptScoreRatio[i] = 0;
		m_sTempBeamPath.dScannerContrast[i] = 0;
		m_sTempBeamPath.dScannerBrightness[i]= 0;
		m_sTempBeamPath.bSelectedList[i] = FALSE;
		
		strcpy_s(m_sTempBeamPath.strInfoName[i],"-");
//		strcpy_s( m_sBeamPath.strBeamPathAscFile[i] ,"-");
	}

	// 	strcpy_s( m_sBeamPath.strPowCompensationAomFile ,"-");
	// 	m_sTempBeamPath.dScannerJumpDelay = 0;
	//	m_sTempBeamPath.dFixedMask = 0;
}


// up, down��  �迭�� ���Ʒ��� �ٲٸ� �Ǳ� ������ ��ü ���縦 ���� �ʰ�
// m_sTempBeamPath ������ 0�� �δ콺 �������� �̿��Ͽ� m_sBeamPath ������ ������ ���� �Ѵ�. 

void CPaneSysSetupBeamPathLDD::OnCheckUp()
{
	if(FALSE == m_ClickID)
		return ;

	int SelectNo = GetIdNoToAddDel();
	if(SelectNo <= 0)
		return ;


	//round 1
	//temp[0] ������ ���õ� �׸��� ������ ���� 
	m_sTempBeamPath.dInfoMaskSize[0]			=	m_sBeamPath.dInfoMaskSize[SelectNo-1];			
	m_sTempBeamPath.dBeamPathBetPos1[0]			=	m_sBeamPath.dBeamPathBetPos1[SelectNo-1];
	m_sTempBeamPath.dBeamPathBetPos2[0]			=	m_sBeamPath.dBeamPathBetPos2[SelectNo-1];
	m_sTempBeamPath.nBeamPathMaskPos1[0]		=	m_sBeamPath.nBeamPathMaskPos1[SelectNo-1];
	m_sTempBeamPath.nBeamPathMaskPos2[0]		=	m_sBeamPath.nBeamPathMaskPos2[SelectNo-1];
	m_sTempBeamPath.nBeamPathMaskPos3[0]		=	m_sBeamPath.nBeamPathMaskPos3[SelectNo-1];
	m_sTempBeamPath.nBeamPathAttenuatePos1[0]	=	m_sBeamPath.nBeamPathAttenuatePos1[SelectNo-1];
	m_sTempBeamPath.nBeamPathAttenuatePos2[0]	=	m_sBeamPath.nBeamPathAttenuatePos2[SelectNo-1];
	m_sTempBeamPath.dBeamPathZAxisPos1[0]		=	m_sBeamPath.dBeamPathZAxisPos1[SelectNo-1];
	m_sTempBeamPath.dBeamPathZAxisPos2[0]		=	m_sBeamPath.dBeamPathZAxisPos2[SelectNo-1]; 
	m_sTempBeamPath.bBeamPathUseTophat[0]		=	m_sBeamPath.bBeamPathUseTophat[SelectNo-1];	
	m_sTempBeamPath.bBeamPathLaserPath[0]		=	m_sBeamPath.bBeamPathLaserPath[SelectNo-1];	
	m_sTempBeamPath.dBeamPathVoltage1[0]		=	m_sBeamPath.dBeamPathVoltage1[SelectNo-1];
	m_sTempBeamPath.dBeamPathVoltage2[0]		=	m_sBeamPath.dBeamPathVoltage2[SelectNo-1];
	m_sTempBeamPath.dPowOffsetDuty[0]			=	m_sBeamPath.dPowOffsetDuty[SelectNo-1];
	m_sTempBeamPath.dPowOffsetAomDelay[0]		=	m_sBeamPath.dPowOffsetAomDelay[SelectNo-1];
	m_sTempBeamPath.dPowOffsetAomDuty[0]		=	m_sBeamPath.dPowOffsetAomDuty[SelectNo-1];	
	m_sTempBeamPath.dPowOffsetAomDual1[0]		=	m_sBeamPath.dPowOffsetAomDual1[SelectNo-1];
	m_sTempBeamPath.dPowOffsetAomDual2[0]		=	m_sBeamPath.dPowOffsetAomDual2[SelectNo-1];	
	m_sTempBeamPath.dPowOffsetVoltage1[0]		=	m_sBeamPath.dPowOffsetVoltage1[SelectNo-1];
	m_sTempBeamPath.dPowOffsetVoltage2[0]		=	m_sBeamPath.dPowOffsetVoltage2[SelectNo-1];

	m_sTempBeamPath.nPowCompensationFrequency[0] = m_sBeamPath.nPowCompensationFrequency[SelectNo-1];
	m_sTempBeamPath.dPowCompensationDuty[0]		=	m_sBeamPath.dPowCompensationDuty[SelectNo-1];
	m_sTempBeamPath.dPowCompensationAomDelay[0]	=	m_sBeamPath.dPowCompensationAomDelay[SelectNo-1];
	m_sTempBeamPath.dPowCompensationAomDuty[0]	=	m_sBeamPath.dPowCompensationAomDuty[SelectNo-1];
	m_sTempBeamPath.dPowCompensationTargetMin[0] = m_sBeamPath.dPowCompensationTargetMin[SelectNo-1];
	m_sTempBeamPath.dPowCompensationTargetMax[0] = m_sBeamPath.dPowCompensationTargetMax[SelectNo-1];
	m_sTempBeamPath.dPowCompensationDutyOffset[0] =m_sBeamPath.dPowCompensationDutyOffset[SelectNo-1];
	m_sTempBeamPath.dScannerDuty[0]				=	m_sBeamPath.dScannerDuty[SelectNo-1];
	m_sTempBeamPath.dScannerAomDuty[0]			=	m_sBeamPath.dScannerAomDuty[SelectNo-1];
	m_sTempBeamPath.dScannerAomdelay[0]			=	m_sBeamPath.dScannerAomdelay[SelectNo-1];
	m_sTempBeamPath.nScannerTotalShot[0]		=	m_sBeamPath.nScannerTotalShot[SelectNo-1];
	m_sTempBeamPath.nScannerVisionCam[0]		=	m_sBeamPath.nScannerVisionCam[SelectNo-1] ;
	m_sTempBeamPath.dScannerVisionModelSize[0]	=	m_sBeamPath.dScannerVisionModelSize[SelectNo-1];
	m_sTempBeamPath.nScannerPolarity[0]			=	m_sBeamPath.nScannerPolarity[SelectNo-1];
	m_sTempBeamPath.dScannerAcceptScoreSize[0]	=	m_sBeamPath.dScannerAcceptScoreSize[SelectNo-1];
	m_sTempBeamPath.dScannerAcceptScoreRatio[0] =	m_sBeamPath.dScannerAcceptScoreRatio[SelectNo-1];
	m_sTempBeamPath.dScannerContrast[0]			=	m_sBeamPath.dScannerContrast[SelectNo-1];
	m_sTempBeamPath.dScannerBrightness[0]		=	m_sBeamPath.dScannerBrightness[SelectNo-1];
	
	strcpy_s(m_sTempBeamPath.strInfoName[0],m_sBeamPath.strInfoName[SelectNo-1]);
	strcpy_s( m_sTempBeamPath.strBeamPathAscFile[0] ,m_sBeamPath.strBeamPathAscFile[SelectNo-1]);



	//round2
	//���õ� ���� ��ĭ ���� �����Ѵ�. 
	m_sBeamPath.dInfoMaskSize[SelectNo-1]			=	m_sBeamPath.dInfoMaskSize[SelectNo];			
	m_sBeamPath.dBeamPathBetPos1[SelectNo-1]		=	m_sBeamPath.dBeamPathBetPos1[SelectNo];
	m_sBeamPath.dBeamPathBetPos2[SelectNo-1]		=	m_sBeamPath.dBeamPathBetPos2[SelectNo];
	m_sBeamPath.nBeamPathMaskPos1[SelectNo-1]		=	m_sBeamPath.nBeamPathMaskPos1[SelectNo];
	m_sBeamPath.nBeamPathMaskPos2[SelectNo-1]		=	m_sBeamPath.nBeamPathMaskPos2[SelectNo];
	m_sBeamPath.nBeamPathMaskPos3[SelectNo-1]		=	m_sBeamPath.nBeamPathMaskPos3[SelectNo];
	m_sBeamPath.nBeamPathAttenuatePos1[SelectNo-1]	=	m_sBeamPath.nBeamPathAttenuatePos1[SelectNo];
	m_sBeamPath.nBeamPathAttenuatePos2[SelectNo-1]	=	m_sBeamPath.nBeamPathAttenuatePos2[SelectNo];
	m_sBeamPath.dBeamPathZAxisPos1[SelectNo-1]		=	m_sBeamPath.dBeamPathZAxisPos1[SelectNo];
	m_sBeamPath.dBeamPathZAxisPos2[SelectNo-1]		=	m_sBeamPath.dBeamPathZAxisPos2[SelectNo]; 
	m_sBeamPath.bBeamPathUseTophat[SelectNo-1]		=	m_sBeamPath.bBeamPathUseTophat[SelectNo];
	m_sBeamPath.bBeamPathLaserPath[SelectNo-1]	=	m_sBeamPath.bBeamPathLaserPath[SelectNo];	
	m_sBeamPath.dBeamPathVoltage1[SelectNo-1]		=	m_sBeamPath.dBeamPathVoltage1[SelectNo];
	m_sBeamPath.dBeamPathVoltage2[SelectNo-1]		=	m_sBeamPath.dBeamPathVoltage2[SelectNo];
	
	m_sBeamPath.dPowOffsetDuty[SelectNo-1]			=	m_sBeamPath.dPowOffsetDuty[SelectNo];
	m_sBeamPath.dPowOffsetAomDelay[SelectNo-1]		=	m_sBeamPath.dPowOffsetAomDelay[SelectNo];
	m_sBeamPath.dPowOffsetAomDuty[SelectNo-1]		=	m_sBeamPath.dPowOffsetAomDuty[SelectNo];
	m_sBeamPath.dPowOffsetAomDual1[SelectNo-1]		=	m_sBeamPath.dPowOffsetAomDual1[SelectNo];
	m_sBeamPath.dPowOffsetAomDual2[SelectNo-1]		=	m_sBeamPath.dPowOffsetAomDual2[SelectNo];
	m_sBeamPath.dPowOffsetVoltage1[SelectNo-1]		=	m_sBeamPath.dPowOffsetVoltage1[SelectNo];
	m_sBeamPath.dPowOffsetVoltage2[SelectNo-1]		=	m_sBeamPath.dPowOffsetVoltage2[SelectNo];
	
	m_sBeamPath.nPowCompensationFrequency[SelectNo-1] = m_sBeamPath.nPowCompensationFrequency[SelectNo];
	m_sBeamPath.dPowCompensationDuty[SelectNo-1]	 =	m_sBeamPath.dPowCompensationDuty[SelectNo];
	m_sBeamPath.dPowCompensationAomDelay[SelectNo-1]=	m_sBeamPath.dPowCompensationAomDelay[SelectNo];
	m_sBeamPath.dPowCompensationAomDuty[SelectNo-1] =	m_sBeamPath.dPowCompensationAomDuty[SelectNo];
	m_sBeamPath.dPowCompensationTargetMin[SelectNo-1] = m_sBeamPath.dPowCompensationTargetMin[SelectNo];
	m_sBeamPath.dPowCompensationTargetMax[SelectNo-1] = m_sBeamPath.dPowCompensationTargetMax[SelectNo];
	m_sBeamPath.dPowCompensationDutyOffset[SelectNo-1] =m_sBeamPath.dPowCompensationDutyOffset[SelectNo];
	m_sBeamPath.dScannerDuty[SelectNo-1]			=	m_sBeamPath.dScannerDuty[SelectNo];
	m_sBeamPath.dScannerAomDuty[SelectNo-1]			=	m_sBeamPath.dScannerAomDuty[SelectNo];
	m_sBeamPath.dScannerAomdelay[SelectNo-1]		=	m_sBeamPath.dScannerAomdelay[SelectNo];
	m_sBeamPath.nScannerTotalShot[SelectNo-1]		=	m_sBeamPath.nScannerTotalShot[SelectNo];
	m_sBeamPath.nScannerVisionCam[SelectNo-1]		=	m_sBeamPath.nScannerVisionCam[SelectNo] ;
	m_sBeamPath.dScannerVisionModelSize[SelectNo-1] =	m_sBeamPath.dScannerVisionModelSize[SelectNo];
	m_sBeamPath.nScannerPolarity[SelectNo-1]		=	m_sBeamPath.nScannerPolarity[SelectNo];
	m_sBeamPath.dScannerAcceptScoreSize[SelectNo-1] =	m_sBeamPath.dScannerAcceptScoreSize[SelectNo];
	m_sBeamPath.dScannerAcceptScoreRatio[SelectNo-1] =	m_sBeamPath.dScannerAcceptScoreRatio[SelectNo];
	m_sBeamPath.dScannerContrast[SelectNo-1]		=	m_sBeamPath.dScannerContrast[SelectNo];
	m_sBeamPath.dScannerBrightness[SelectNo-1]		=	m_sBeamPath.dScannerBrightness[SelectNo];
	
	strcpy_s(m_sBeamPath.strInfoName[SelectNo-1],m_sBeamPath.strInfoName[SelectNo]);
	strcpy_s( m_sBeamPath.strBeamPathAscFile[SelectNo-1] ,m_sBeamPath.strBeamPathAscFile[SelectNo]);




	//round3
	// temp[0]�� ����� ���� ���õ� �׸����� �����Ѵ�.
	m_sBeamPath.dInfoMaskSize[SelectNo]			=	m_sTempBeamPath.dInfoMaskSize[0];			
	m_sBeamPath.dBeamPathBetPos1[SelectNo]		=	m_sTempBeamPath.dBeamPathBetPos1[0];
	m_sBeamPath.dBeamPathBetPos2[SelectNo]		=	m_sTempBeamPath.dBeamPathBetPos2[0];
	m_sBeamPath.nBeamPathMaskPos1[SelectNo]		=	m_sTempBeamPath.nBeamPathMaskPos1[0];
	m_sBeamPath.nBeamPathMaskPos2[SelectNo]		=	m_sTempBeamPath.nBeamPathMaskPos2[0];
	m_sBeamPath.nBeamPathMaskPos3[SelectNo]		=	m_sTempBeamPath.nBeamPathMaskPos3[0];
	m_sBeamPath.nBeamPathAttenuatePos1[SelectNo]	=	m_sTempBeamPath.nBeamPathAttenuatePos1[0];
	m_sBeamPath.nBeamPathAttenuatePos2[SelectNo]	=	m_sTempBeamPath.nBeamPathAttenuatePos2[0];
	m_sBeamPath.dBeamPathZAxisPos1[SelectNo]		=	m_sTempBeamPath.dBeamPathZAxisPos1[0];
	m_sBeamPath.dBeamPathZAxisPos2[SelectNo]		=	m_sTempBeamPath.dBeamPathZAxisPos2[0]; 
	m_sBeamPath.bBeamPathUseTophat[SelectNo]		=	m_sTempBeamPath.bBeamPathUseTophat[0];	
	m_sBeamPath.bBeamPathLaserPath[SelectNo]		=	m_sBeamPath.bBeamPathLaserPath[0];	
	m_sBeamPath.dBeamPathVoltage1[SelectNo]			=	m_sBeamPath.dBeamPathVoltage1[0];
	m_sBeamPath.dBeamPathVoltage2[SelectNo]			=	m_sBeamPath.dBeamPathVoltage2[0];
	
	m_sBeamPath.dPowOffsetDuty[SelectNo]			=	m_sTempBeamPath.dPowOffsetDuty[0];
	m_sBeamPath.dPowOffsetAomDelay[SelectNo]		=	m_sTempBeamPath.dPowOffsetAomDelay[0];
	m_sBeamPath.dPowOffsetAomDuty[SelectNo]			=	m_sTempBeamPath.dPowOffsetAomDuty[0];	
	m_sBeamPath.dPowOffsetAomDual1[SelectNo]		=	m_sTempBeamPath.dPowOffsetAomDual1[0];
	m_sBeamPath.dPowOffsetAomDual2[SelectNo]		=	m_sTempBeamPath.dPowOffsetAomDual2[0];
	m_sBeamPath.dPowOffsetVoltage1[SelectNo]		=	m_sTempBeamPath.dPowOffsetVoltage1[0];
	m_sBeamPath.dPowOffsetVoltage2[SelectNo]		=	m_sTempBeamPath.dPowOffsetVoltage2[0];
	
	m_sBeamPath.nPowCompensationFrequency[SelectNo] = m_sTempBeamPath.nPowCompensationFrequency[0];
	m_sBeamPath.dPowCompensationDuty[SelectNo]		=	m_sTempBeamPath.dPowCompensationDuty[0];
	m_sBeamPath.dPowCompensationAomDelay[SelectNo]	=	m_sTempBeamPath.dPowCompensationAomDelay[0];
	m_sBeamPath.dPowCompensationAomDuty[SelectNo]	=	m_sTempBeamPath.dPowCompensationAomDuty[0];
	m_sBeamPath.dPowCompensationTargetMin[SelectNo] = m_sTempBeamPath.dPowCompensationTargetMin[0];
	m_sBeamPath.dPowCompensationTargetMax[SelectNo] = m_sTempBeamPath.dPowCompensationTargetMax[0];
	m_sBeamPath.dPowCompensationDutyOffset[SelectNo] =m_sTempBeamPath.dPowCompensationDutyOffset[0];
	m_sBeamPath.dScannerDuty[SelectNo]				=	m_sTempBeamPath.dScannerDuty[0];
	m_sBeamPath.dScannerAomDuty[SelectNo]			=	m_sTempBeamPath.dScannerAomDuty[0];
	m_sBeamPath.dScannerAomdelay[SelectNo]			=	m_sTempBeamPath.dScannerAomdelay[0];
	m_sBeamPath.nScannerTotalShot[SelectNo]			=	m_sTempBeamPath.nScannerTotalShot[0];
	m_sBeamPath.nScannerVisionCam[SelectNo]			=	m_sTempBeamPath.nScannerVisionCam[0] ;
	m_sBeamPath.dScannerVisionModelSize[SelectNo]	=	m_sTempBeamPath.dScannerVisionModelSize[0];
	m_sBeamPath.nScannerPolarity[SelectNo]			=	m_sTempBeamPath.nScannerPolarity[0];
	m_sBeamPath.dScannerAcceptScoreSize[SelectNo]	=	m_sTempBeamPath.dScannerAcceptScoreSize[0];
	m_sBeamPath.dScannerAcceptScoreRatio[SelectNo]	=	m_sTempBeamPath.dScannerAcceptScoreRatio[0];
	m_sBeamPath.dScannerContrast[SelectNo]			=	m_sTempBeamPath.dScannerContrast[0];
	m_sBeamPath.dScannerBrightness[SelectNo]		=	m_sTempBeamPath.dScannerBrightness[0];
	
	strcpy_s(m_sBeamPath.strInfoName[SelectNo],m_sTempBeamPath.strInfoName[0]);
	strcpy_s( m_sBeamPath.strBeamPathAscFile[SelectNo] ,m_sTempBeamPath.strBeamPathAscFile[0]);


	m_ClickID = FALSE;
	OnCheckRefresh();
	InitDataStruct();		// �ӽ� ����ü �ʱ�ȭ 

}

void CPaneSysSetupBeamPathLDD::OnCheckDown()
{
	if(FALSE == m_ClickID)
		return ;
	
	int SelectNo = GetIdNoToAddDel();
	if(SelectNo >= m_nRepeatCount)
		return ;


	//round 1
	//temp[0] ������ ���õ� �׸��� �Ʒ��� ���� 
	m_sTempBeamPath.dInfoMaskSize[0]			=	m_sBeamPath.dInfoMaskSize[SelectNo+1];			
	m_sTempBeamPath.dBeamPathBetPos1[0]			=	m_sBeamPath.dBeamPathBetPos1[SelectNo+1];
	m_sTempBeamPath.dBeamPathBetPos2[0]			=	m_sBeamPath.dBeamPathBetPos2[SelectNo+1];
	m_sTempBeamPath.nBeamPathMaskPos1[0]		=	m_sBeamPath.nBeamPathMaskPos1[SelectNo+1];
	m_sTempBeamPath.nBeamPathMaskPos2[0]		=	m_sBeamPath.nBeamPathMaskPos2[SelectNo+1];
	m_sTempBeamPath.nBeamPathMaskPos3[0]		=	m_sBeamPath.nBeamPathMaskPos3[SelectNo+1];
	m_sTempBeamPath.nBeamPathAttenuatePos1[0]	=	m_sBeamPath.nBeamPathAttenuatePos1[SelectNo+1];
	m_sTempBeamPath.nBeamPathAttenuatePos2[0]	=	m_sBeamPath.nBeamPathAttenuatePos2[SelectNo+1];
	m_sTempBeamPath.dBeamPathZAxisPos1[0]		=	m_sBeamPath.dBeamPathZAxisPos1[SelectNo+1];
	m_sTempBeamPath.dBeamPathZAxisPos2[0]		=	m_sBeamPath.dBeamPathZAxisPos2[SelectNo+1]; 
	m_sTempBeamPath.bBeamPathUseTophat[0]		=	m_sBeamPath.bBeamPathUseTophat[SelectNo+1];	
	m_sTempBeamPath.bBeamPathLaserPath[0]		=	m_sBeamPath.bBeamPathLaserPath[SelectNo+1];	
	m_sTempBeamPath.dBeamPathVoltage1[0]		=	m_sBeamPath.dBeamPathVoltage1[SelectNo+1];
	m_sTempBeamPath.dBeamPathVoltage2[0]		=	m_sBeamPath.dBeamPathVoltage2[SelectNo+1];
	m_sTempBeamPath.dPowOffsetDuty[0]			=	m_sBeamPath.dPowOffsetDuty[SelectNo+1];
	m_sTempBeamPath.dPowOffsetAomDelay[0]		=	m_sBeamPath.dPowOffsetAomDelay[SelectNo+1];
	m_sTempBeamPath.dPowOffsetAomDuty[0]		=	m_sBeamPath.dPowOffsetAomDuty[SelectNo+1];	
	m_sTempBeamPath.dPowOffsetAomDual1[0]		=	m_sBeamPath.dPowOffsetAomDual1[SelectNo+1];
	m_sTempBeamPath.dPowOffsetAomDual2[0]		=	m_sBeamPath.dPowOffsetAomDual2[SelectNo+1];	
	m_sTempBeamPath.dPowOffsetVoltage1[0]		=	m_sBeamPath.dPowOffsetVoltage1[SelectNo+1];
	m_sTempBeamPath.dPowOffsetVoltage2[0]		=	m_sBeamPath.dPowOffsetVoltage2[SelectNo+1];	
	
	m_sTempBeamPath.nPowCompensationFrequency[0] = m_sBeamPath.nPowCompensationFrequency[SelectNo+1];
	m_sTempBeamPath.dPowCompensationDuty[0]		 =	m_sBeamPath.dPowCompensationDuty[SelectNo+1];
	m_sTempBeamPath.dPowCompensationAomDelay[0]	=	m_sBeamPath.dPowCompensationAomDelay[SelectNo+1];
	m_sTempBeamPath.dPowCompensationAomDuty[0]	=	m_sBeamPath.dPowCompensationAomDuty[SelectNo+1];
	m_sTempBeamPath.dPowCompensationTargetMin[0] = m_sBeamPath.dPowCompensationTargetMin[SelectNo+1];
	m_sTempBeamPath.dPowCompensationTargetMax[0] = m_sBeamPath.dPowCompensationTargetMax[SelectNo+1];
	m_sTempBeamPath.dPowCompensationDutyOffset[0] =m_sBeamPath.dPowCompensationDutyOffset[SelectNo+1];
	m_sTempBeamPath.dScannerDuty[0]				=	m_sBeamPath.dScannerDuty[SelectNo+1];
	m_sTempBeamPath.dScannerAomDuty[0]			=	m_sBeamPath.dScannerAomDuty[SelectNo+1];
	m_sTempBeamPath.dScannerAomdelay[0]			=	m_sBeamPath.dScannerAomdelay[SelectNo+1];
	m_sTempBeamPath.nScannerTotalShot[0]		=	m_sBeamPath.nScannerTotalShot[SelectNo+1];
	m_sTempBeamPath.nScannerVisionCam[0]		=	m_sBeamPath.nScannerVisionCam[SelectNo+1] ;
	m_sTempBeamPath.dScannerVisionModelSize[0]	=	m_sBeamPath.dScannerVisionModelSize[SelectNo+1];
	m_sTempBeamPath.nScannerPolarity[0]			=	m_sBeamPath.nScannerPolarity[SelectNo+1];
	m_sTempBeamPath.dScannerAcceptScoreSize[0]	=	m_sBeamPath.dScannerAcceptScoreSize[SelectNo+1];
	m_sTempBeamPath.dScannerAcceptScoreRatio[0] =	m_sBeamPath.dScannerAcceptScoreRatio[SelectNo+1];
	m_sTempBeamPath.dScannerContrast[0]			=	m_sBeamPath.dScannerContrast[SelectNo+1];
	m_sTempBeamPath.dScannerBrightness[0]		=	m_sBeamPath.dScannerBrightness[SelectNo+1];
	
	strcpy_s(m_sTempBeamPath.strInfoName[0],m_sBeamPath.strInfoName[SelectNo+1]);
	strcpy_s( m_sTempBeamPath.strBeamPathAscFile[0] ,m_sBeamPath.strBeamPathAscFile[SelectNo+1]);



	//round2
	//���õ� ���� ��ĭ �Ʒ��� �����Ѵ�. 
	m_sBeamPath.dInfoMaskSize[SelectNo+1]			=	m_sBeamPath.dInfoMaskSize[SelectNo];			
	m_sBeamPath.dBeamPathBetPos1[SelectNo+1]		=	m_sBeamPath.dBeamPathBetPos1[SelectNo];
	m_sBeamPath.dBeamPathBetPos2[SelectNo+1]		=	m_sBeamPath.dBeamPathBetPos2[SelectNo];
	m_sBeamPath.nBeamPathMaskPos1[SelectNo+1]		=	m_sBeamPath.nBeamPathMaskPos1[SelectNo];
	m_sBeamPath.nBeamPathMaskPos2[SelectNo+1]		=	m_sBeamPath.nBeamPathMaskPos2[SelectNo];
	m_sBeamPath.nBeamPathMaskPos3[SelectNo+1]		=	m_sBeamPath.nBeamPathMaskPos3[SelectNo];
	m_sBeamPath.nBeamPathAttenuatePos1[SelectNo+1]	=	m_sBeamPath.nBeamPathAttenuatePos1[SelectNo];
	m_sBeamPath.nBeamPathAttenuatePos2[SelectNo+1]	=	m_sBeamPath.nBeamPathAttenuatePos2[SelectNo];
	m_sBeamPath.dBeamPathZAxisPos1[SelectNo+1]		=	m_sBeamPath.dBeamPathZAxisPos1[SelectNo];
	m_sBeamPath.dBeamPathZAxisPos2[SelectNo+1]		=	m_sBeamPath.dBeamPathZAxisPos2[SelectNo]; 
	m_sBeamPath.bBeamPathUseTophat[SelectNo+1]		=	m_sBeamPath.bBeamPathUseTophat[SelectNo];	
	m_sBeamPath.bBeamPathLaserPath[SelectNo+1]		=	m_sBeamPath.bBeamPathLaserPath[SelectNo];	
	m_sBeamPath.dBeamPathVoltage1[SelectNo+1]		=	m_sBeamPath.dBeamPathVoltage1[SelectNo];
	m_sBeamPath.dBeamPathVoltage2[SelectNo+1]		=	m_sBeamPath.dBeamPathVoltage2[SelectNo];	
	m_sBeamPath.dPowOffsetDuty[SelectNo+1]			=	m_sBeamPath.dPowOffsetDuty[SelectNo];
	m_sBeamPath.dPowOffsetAomDelay[SelectNo+1]		=	m_sBeamPath.dPowOffsetAomDelay[SelectNo];
	m_sBeamPath.dPowOffsetAomDuty[SelectNo+1]		=	m_sBeamPath.dPowOffsetAomDuty[SelectNo];
	m_sBeamPath.dPowOffsetAomDual1[SelectNo+1]		=	m_sBeamPath.dPowOffsetAomDual1[SelectNo];
	m_sBeamPath.dPowOffsetAomDual2[SelectNo+1]		=	m_sBeamPath.dPowOffsetAomDual2[SelectNo];
	m_sBeamPath.dPowOffsetVoltage1[SelectNo+1]		=	m_sBeamPath.dPowOffsetVoltage1[SelectNo];
	m_sBeamPath.dPowOffsetVoltage2[SelectNo+1]		=	m_sBeamPath.dPowOffsetVoltage2[SelectNo];
	
	m_sBeamPath.nPowCompensationFrequency[SelectNo+1] = m_sBeamPath.nPowCompensationFrequency[SelectNo];
	m_sBeamPath.dPowCompensationDuty[SelectNo+1]	 =	m_sBeamPath.dPowCompensationDuty[SelectNo];
	m_sBeamPath.dPowCompensationAomDelay[SelectNo+1]=	m_sBeamPath.dPowCompensationAomDelay[SelectNo];
	m_sBeamPath.dPowCompensationAomDuty[SelectNo+1] =	m_sBeamPath.dPowCompensationAomDuty[SelectNo];
	m_sBeamPath.dPowCompensationTargetMin[SelectNo+1] = m_sBeamPath.dPowCompensationTargetMin[SelectNo];
	m_sBeamPath.dPowCompensationTargetMax[SelectNo+1] = m_sBeamPath.dPowCompensationTargetMax[SelectNo];
	m_sBeamPath.dPowCompensationDutyOffset[SelectNo+1] =m_sBeamPath.dPowCompensationDutyOffset[SelectNo];
	m_sBeamPath.dScannerDuty[SelectNo+1]			=	m_sBeamPath.dScannerDuty[SelectNo];
	m_sBeamPath.dScannerAomDuty[SelectNo+1]			=	m_sBeamPath.dScannerAomDuty[SelectNo];
	m_sBeamPath.dScannerAomdelay[SelectNo+1]		=	m_sBeamPath.dScannerAomdelay[SelectNo];
	m_sBeamPath.nScannerTotalShot[SelectNo+1]		=	m_sBeamPath.nScannerTotalShot[SelectNo];
	m_sBeamPath.nScannerVisionCam[SelectNo+1]		=	m_sBeamPath.nScannerVisionCam[SelectNo] ;
	m_sBeamPath.dScannerVisionModelSize[SelectNo+1] =	m_sBeamPath.dScannerVisionModelSize[SelectNo];
	m_sBeamPath.nScannerPolarity[SelectNo+1]		=	m_sBeamPath.nScannerPolarity[SelectNo];
	m_sBeamPath.dScannerAcceptScoreSize[SelectNo+1] =	m_sBeamPath.dScannerAcceptScoreSize[SelectNo];
	m_sBeamPath.dScannerAcceptScoreRatio[SelectNo+1] =	m_sBeamPath.dScannerAcceptScoreRatio[SelectNo];
	m_sBeamPath.dScannerContrast[SelectNo+1]		=	m_sBeamPath.dScannerContrast[SelectNo];
	m_sBeamPath.dScannerBrightness[SelectNo+1]		=	m_sBeamPath.dScannerBrightness[SelectNo];
	
	strcpy_s(m_sBeamPath.strInfoName[SelectNo+1],m_sBeamPath.strInfoName[SelectNo]);
	strcpy_s( m_sBeamPath.strBeamPathAscFile[SelectNo+1] ,m_sBeamPath.strBeamPathAscFile[SelectNo]);




	//round3
	// temp[0]�� ����� ���� ���õ� �׸����� �����Ѵ�.
	m_sBeamPath.dInfoMaskSize[SelectNo]				=	m_sTempBeamPath.dInfoMaskSize[0];			
	m_sBeamPath.dBeamPathBetPos1[SelectNo]			=	m_sTempBeamPath.dBeamPathBetPos1[0];
	m_sBeamPath.dBeamPathBetPos2[SelectNo]			=	m_sTempBeamPath.dBeamPathBetPos2[0];
	m_sBeamPath.nBeamPathMaskPos1[SelectNo]			=	m_sTempBeamPath.nBeamPathMaskPos1[0];
	m_sBeamPath.nBeamPathMaskPos2[SelectNo]			=	m_sTempBeamPath.nBeamPathMaskPos2[0];
	m_sBeamPath.nBeamPathMaskPos3[SelectNo]			=	m_sTempBeamPath.nBeamPathMaskPos3[0];
	m_sBeamPath.nBeamPathAttenuatePos1[SelectNo]	=	m_sTempBeamPath.nBeamPathAttenuatePos1[0];
	m_sBeamPath.nBeamPathAttenuatePos2[SelectNo]	=	m_sTempBeamPath.nBeamPathAttenuatePos2[0];
	m_sBeamPath.dBeamPathZAxisPos1[SelectNo]		=	m_sTempBeamPath.dBeamPathZAxisPos1[0];
	m_sBeamPath.dBeamPathZAxisPos2[SelectNo]		=	m_sTempBeamPath.dBeamPathZAxisPos2[0]; 
	m_sBeamPath.bBeamPathUseTophat[SelectNo]		=	m_sTempBeamPath.bBeamPathUseTophat[0];	
	m_sBeamPath.bBeamPathLaserPath[SelectNo]		=	m_sTempBeamPath.bBeamPathLaserPath[0];	
	m_sBeamPath.dBeamPathVoltage1[SelectNo]			=	m_sTempBeamPath.dBeamPathVoltage1[0];
	m_sBeamPath.dBeamPathVoltage2[SelectNo]			=	m_sTempBeamPath.dBeamPathVoltage2[0];	
	
	m_sBeamPath.dPowOffsetDuty[SelectNo]			=	m_sTempBeamPath.dPowOffsetDuty[0];
	m_sBeamPath.dPowOffsetAomDelay[SelectNo]		=	m_sTempBeamPath.dPowOffsetAomDelay[0];
	m_sBeamPath.dPowOffsetAomDuty[SelectNo]			=	m_sTempBeamPath.dPowOffsetAomDuty[0];
	m_sBeamPath.dPowOffsetAomDual1[SelectNo]		=	m_sTempBeamPath.dPowOffsetAomDual1[0];
	m_sBeamPath.dPowOffsetAomDual2[SelectNo]		=	m_sTempBeamPath.dPowOffsetAomDual2[0];	
	m_sBeamPath.dPowOffsetVoltage1[SelectNo]		=	m_sTempBeamPath.dPowOffsetVoltage1[0];
	m_sBeamPath.dPowOffsetVoltage2[SelectNo]		=	m_sTempBeamPath.dPowOffsetVoltage2[0];	
	
	m_sBeamPath.nPowCompensationFrequency[SelectNo] = m_sTempBeamPath.nPowCompensationFrequency[0];
	m_sBeamPath.dPowCompensationDuty[SelectNo]		=	m_sTempBeamPath.dPowCompensationDuty[0];
	m_sBeamPath.dPowCompensationAomDelay[SelectNo]	=	m_sTempBeamPath.dPowCompensationAomDelay[0];
	m_sBeamPath.dPowCompensationAomDuty[SelectNo]	=	m_sTempBeamPath.dPowCompensationAomDuty[0];
	m_sBeamPath.dPowCompensationTargetMin[SelectNo] = m_sTempBeamPath.dPowCompensationTargetMin[0];
	m_sBeamPath.dPowCompensationTargetMax[SelectNo] = m_sTempBeamPath.dPowCompensationTargetMax[0];
	m_sBeamPath.dPowCompensationDutyOffset[SelectNo] =m_sTempBeamPath.dPowCompensationDutyOffset[0];
	m_sBeamPath.dScannerDuty[SelectNo]				=	m_sTempBeamPath.dScannerDuty[0];
	m_sBeamPath.dScannerAomDuty[SelectNo]			=	m_sTempBeamPath.dScannerAomDuty[0];
	m_sBeamPath.dScannerAomdelay[SelectNo]			=	m_sTempBeamPath.dScannerAomdelay[0];
	m_sBeamPath.nScannerTotalShot[SelectNo]			=	m_sTempBeamPath.nScannerTotalShot[0];
	m_sBeamPath.nScannerVisionCam[SelectNo]			=	m_sTempBeamPath.nScannerVisionCam[0] ;
	m_sBeamPath.dScannerVisionModelSize[SelectNo]	=	m_sTempBeamPath.dScannerVisionModelSize[0];
	m_sBeamPath.nScannerPolarity[SelectNo]			=	m_sTempBeamPath.nScannerPolarity[0];
	m_sBeamPath.dScannerAcceptScoreSize[SelectNo]	=	m_sTempBeamPath.dScannerAcceptScoreSize[0];
	m_sBeamPath.dScannerAcceptScoreRatio[SelectNo]	=	m_sTempBeamPath.dScannerAcceptScoreRatio[0];
	m_sBeamPath.dScannerContrast[SelectNo]			=	m_sTempBeamPath.dScannerContrast[0];
	m_sBeamPath.dScannerBrightness[SelectNo]		=	m_sTempBeamPath.dScannerBrightness[0];
	
	strcpy_s(m_sBeamPath.strInfoName[SelectNo],m_sTempBeamPath.strInfoName[0]);
	strcpy_s( m_sBeamPath.strBeamPathAscFile[SelectNo] ,m_sTempBeamPath.strBeamPathAscFile[0]);


	m_ClickID = FALSE;
	OnCheckRefresh();
	InitDataStruct();		// �ӽ� ����ü �ʱ�ȭ 
}

void CPaneSysSetupBeamPathLDD::OnDestroy() 
{
	m_fntStatic.DeleteObject();
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	
	CFormView::OnDestroy();
}

void CPaneSysSetupBeamPathLDD::SetCurrentScrollPos(int xPos, int yPos)
{
	CRect rectCell;
	m_list.GetSubItemRect(yPos, xPos, LVIR_BOUNDS, rectCell);

	CSize size;
	if(yPos <25)
		size.cy = 0;
	else
		size.cy = yPos* rectCell.Height();	
	
	if(xPos <10 )
		size.cx = 0;
	else if( xPos < 20)
		size.cx = xPos*30;
	else
		size.cx = xPos*50;
	
	if(m_list.Scroll(size))
	{
		m_list.SetItemState(m_posClicked.y,LVIS_SELECTED,LVIS_SELECTED);  
	}
}

int CPaneSysSetupBeamPathLDD::GetShowBoxMode(int nXPos)
{
	int listcount = GetListIndex();

	if(listcount == 0)
	{
		return 0;
	}
	else if(listcount == 1) //1
	{
		return 0;
	}
	else if(listcount ==2 )  //2
	{
		if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else return 0;
	}
	else if(listcount ==4) //4
	{
		return 0;
	}
	else if(listcount == 8) //8
	{
		return 0;	
	}
	else if( listcount == 16) //16
	{
		if(nXPos == TABLE4_COLUMN_COUNT - POLARITY_POSITION  - 1)
			return 2;
		else if(nXPos == TABLE4_COLUMN_COUNT - VISION_POSION  - 1)
			return 3;
		else
			return 0;
	}

	else if(listcount == 3) //1,2
	{
	
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else return 0;			
	}

	else if(listcount ==5) //1,4
	{
		return 0;
	}
	else if(listcount ==9) //1,8
	{
		return 0;
	}
	else if(listcount == 17) //1,16
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION  - 1)
			return 2;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION - 1)
			return 3;
		else
			return 0;
	}
	else if(listcount == 7)  //1,2,4
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else return 0;	
	}
	else if(listcount ==11)//1,2,8
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else return 0;	
	}
	else if(listcount == 19)//1,2,16
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION - 1)
			return 2;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION - 1)
			return 3;
		else
			return 0;	

	}

	else if(listcount == 13)//1,4.8
	{
		return 0;
	}
	else if(listcount == 21) //1,4,16
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION - 1)
			return 2;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION - 1)
			return 3;
		else 
			return 0;
	}
	else if(listcount == 25) //1,8,16
	{
	if(nXPos == TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
		return 2;
	else if(nXPos == TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION -1)
		return 3;
	else 
		return 0;
	}

	else if(listcount == 15) //1,2,4,8
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else return 0;
	}

	else if(listcount ==23) //1,2,4,16
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT  +TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
			return 2;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT  +TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION -1)
			return 3;
		else 
			return 0;
	}

	else if(listcount ==27) //1,2,8,16
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT  +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
			return 2;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT  +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION -1)
			return 3;
		else
			return 0;
	}
	else if(listcount == 29)// 1,4,8,16
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT  +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
			return 2;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT  +TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION -1)
			return 3;
		else 
			return 0;
	}
	else if(listcount == 31) //1,2,4,8,16
	{
		if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - USETOPHAT_POSITION  - 1)
			return 1;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT+TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
			return 2;
		else if(nXPos == TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT +TABLE2_COLUMN_COUNT+TABLE3_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION -1)
			return 3;
		else 
			return 0;
	}

	// start 2
	else if(listcount == 6) //2,4
	{
	if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION -1)
		return 1;
	else return 0;
	}
	else if(listcount == 10)	//2,8
	{
		if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION -1)
			return 1;
		else return 0;
	}

	else if(listcount == 18) //2,16
	{
		if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION -1)
			return 1;
		else if(nXPos ==TABLE1_COLUMN_COUNT+TABLE4_COLUMN_COUNT - POLARITY_POSITION - 1 )
			return 2;
		else if(nXPos ==TABLE1_COLUMN_COUNT+TABLE4_COLUMN_COUNT - VISION_POSION - 1 )
			return 3;
		else
			return 0;
	}

	else if(listcount == 14) //2,4,8
	{
		if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION -1)
			return 1;
		else return 0;
	}

	else if(listcount == 22) //2,4,16
	{
		if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION -1)
			return 1;
		else if(nXPos == TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT+TABLE4_COLUMN_COUNT - POLARITY_POSITION - 1)
			return 2;
		else if(nXPos == TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT+TABLE4_COLUMN_COUNT - VISION_POSION - 1)
			return 3;
		else return 0;
	}
	else if(listcount == 26) //2,8,16
	{
		if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION -1)
			return 1;
		else if(nXPos == TABLE1_COLUMN_COUNT+TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - POLARITY_POSITION - 1)
			return 2;
		else if(nXPos == TABLE1_COLUMN_COUNT+TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - VISION_POSION - 1)
			return 3;
		else return 0;
	}

	else if(listcount == 30) //2,4,8,16
	{
		if(nXPos == TABLE1_COLUMN_COUNT - USETOPHAT_POSITION -1)
			return 1;
		else if(nXPos == TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT+TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - POLARITY_POSITION - 1)
			return 2;
		else if(nXPos == TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT+TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - VISION_POSION - 1)
			return 3;
		else return 0;
	}

	//start 4
	else if(listcount == 12)	//4,8
	{
		return 0;
	}
	else if(listcount == 20) //4,16
	{
		if(nXPos == TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
			return 2;
		else if(nXPos == TABLE2_COLUMN_COUNT + TABLE4_COLUMN_COUNT - VISION_POSION -1)
			return 3;
		else 
			return 0;
	}
	else if(listcount == 28) //4,8,16
	{
		if(nXPos == TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
			return 2;
		else if(nXPos == TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - VISION_POSION -1)
			return 3;
		else 
			return 0;
	}

	//start 8	//8,16
	else if(listcount == 24)
	{
		if(nXPos == TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - POLARITY_POSITION -1)
			return 2;
		else if(nXPos == TABLE3_COLUMN_COUNT+TABLE4_COLUMN_COUNT - VISION_POSION -1)
			return 3;
		else
			return 0;
	}

	return TRUE;
}

BOOL CPaneSysSetupBeamPathLDD::GetUseTopHatMode()
{
	BOOL bMode = m_bUseTopHatMode;
	return bMode;
}
void CPaneSysSetupBeamPathLDD::SetUseTopHatMode(BOOL bMode)
{
	m_bUseTopHatMode = bMode;
}

int CPaneSysSetupBeamPathLDD::GetPolarityMode()
{
	int nMode = m_nPolarityMode;
	return nMode;
}

void CPaneSysSetupBeamPathLDD::SetPolarityMode(int nMode)
{
	m_nPolarityMode = nMode;
}

int CPaneSysSetupBeamPathLDD::GetVisionMode()
{
	int nMode = m_nVisionMode;
	return nMode;
}

void CPaneSysSetupBeamPathLDD::SetVisionMode(int nMode)
{
	m_nVisionMode = nMode;	
}

void CPaneSysSetupBeamPathLDD::OnNMCustomdrawListTest(NMHDR *pNMHDR, LRESULT *pResult)  //����ֱ� �κ�..
{
	NMLVCUSTOMDRAW* pLVCD = reinterpret_cast<NMLVCUSTOMDRAW*>( pNMHDR );
	COLORREF clrNewTextColor, clrNewBkColor;   

    *pResult = CDRF_DODEFAULT;
	
	if ( CDDS_PREPAINT == pLVCD->nmcd.dwDrawStage )
	{
        *pResult = CDRF_NOTIFYITEMDRAW;
	}
    else if ( CDDS_ITEMPREPAINT == pLVCD->nmcd.dwDrawStage )
	{	
        *pResult = CDRF_NOTIFYSUBITEMDRAW;
	}
    else if ( (CDDS_ITEMPREPAINT | CDDS_SUBITEM) == pLVCD->nmcd.dwDrawStage )
	{		   

		int listcount = GetListIndex();

		int xPos = pLVCD->iSubItem;

		if(listcount == 0)
		{	
			clrNewTextColor =TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if(listcount == 1) //1
		{
			clrNewTextColor = TABLETEXT_COLOR;   		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if(listcount ==2 )  //2
		{
			clrNewTextColor = TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if(listcount ==4) //4
		{
			clrNewTextColor = TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if(listcount == 8) //8
		{
			clrNewTextColor =TABLETEXT_COLOR;     		
			clrNewBkColor = TABLE1_COLOR;     
		}
		else if( listcount == 16) //16
		{
			clrNewTextColor = TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;     
		}

		else if(listcount == 3) //1,2
		{
			clrNewTextColor = TABLETEXT_COLOR;   		
			clrNewBkColor = TABLE1_COLOR;    			
		}

		else if(listcount ==5) //1,4
		{
			clrNewTextColor = TABLETEXT_COLOR;    		
			clrNewBkColor = TABLE1_COLOR;    
		}
		else if(listcount ==9) //1,8
		{
			clrNewTextColor = TABLETEXT_COLOR;     		
			clrNewBkColor = TABLE1_COLOR;    
		}
		else if(listcount == 17) //1,16
		{
			clrNewTextColor = TABLETEXT_COLOR;     		
			clrNewBkColor = TABLE1_COLOR;    
		}
		else if(listcount == 7)  //1,2,4
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE1_COLOR;     
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else
			{
				clrNewTextColor =TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR; 
			}
		}
		else if(listcount ==11)//1,2,8
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;    		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT+ TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE2_COLOR;  
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;  
			}
		}
		else if(listcount == 19)//1,2,16
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT+ TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR  ;   		
				clrNewBkColor = TABLE2_COLOR;  
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE5_COLOR;  
			}

		}

		else if(listcount == 13)//1,4.8
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor =TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE3_COLOR; 
			}
			else
			{
				clrNewTextColor =TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE4_COLOR; 
			}
		}
		else if(listcount == 21) //1,4,16
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor =TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE3_COLOR; 
			}
			else
			{
				clrNewTextColor =TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE5_COLOR; 
			}
		}
		else if(listcount == 25) //1,8,16
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR  ;   		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   	
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}

		else if(listcount == 15) //1,2,4,8
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE4_COLOR;   
			}
		}

		else if(listcount ==23) //1,2,4,16
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}

		else if(listcount ==27) //1,2,8,16
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if( TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE1_COLUMN_COUNT+TABLE3_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE5_COLOR;   
			}

		}
		else if(listcount == 29)// 1,4,8,16
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else if( TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT +TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
			{
					clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}
		else if(listcount == 31) //1,2,4,8,16
		{
			if(xPos < TABLE0_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE1_COLOR;   
			}
			else if(TABLE0_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if( TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else if( TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE4_COLOR;   
			}
			else 
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}

		// start 2
		else if(listcount == 6) //2,4
		{
			if(xPos < TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
		}
		else if(listcount == 10)	//2,8
		{
			if(xPos < TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   
			}
		}

		else if(listcount == 18) //2,16
		{
			if(xPos < TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}

		else if(listcount == 14) //2,4,8
		{
			if(xPos < TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE4_COLOR;   
			}
		}

		else if(listcount == 22) //2,4,16
		{
			if(xPos < TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}
		else if(listcount == 26) //2,8,16
		{
			if(xPos < TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR  ;   		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}

		else if(listcount == 30) //2,4,8,16
		{
			if(xPos < TABLE1_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR ;    		
				clrNewBkColor = TABLE2_COLOR;   
			}
			else if(TABLE1_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else if(TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE1_COLUMN_COUNT + TABLE2_COLUMN_COUNT +TABLE3_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}

		}

		//start 4
		else if(listcount == 12)	//4,8
		{

			if(xPos < TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   
			}

		}
		else if(listcount == 20) //4,16
		{
			if(xPos < TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}

		else if(listcount == 28) //4,8,16
		{
			if(xPos < TABLE2_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE3_COLOR;   
			}
			else if(TABLE2_COLUMN_COUNT <= xPos && xPos <TABLE2_COLUMN_COUNT + TABLE3_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   	
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}
		}

		//start 8	//8,16
		else if(listcount == 24)
		{
			if(xPos <TABLE3_COLUMN_COUNT)
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE4_COLOR;   
			}
			else
			{
				clrNewTextColor = TABLETEXT_COLOR;     		
				clrNewBkColor = TABLE5_COLOR;   
			}

		}
		pLVCD->clrText = clrNewTextColor;
		pLVCD->clrTextBk = clrNewBkColor;     
        *pResult = CDRF_DODEFAULT;  
	}

}

void CPaneSysSetupBeamPathLDD::CheckAnyDoPrework()
{
	BOOL bPowerChange = FALSE, bScalChange = FALSE;
	if(m_sBeamPath.nFixedMask != gBeamPathINI.m_sBeampath.nFixedMask)
	{
		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER + DO_SCANNER));
		bPowerChange = TRUE; bScalChange = TRUE;
	}

	for(int i = 0; i < m_nRepeatCount; i++)
	{
		if(m_sBeamPath.dBeamPathBetPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1[i]||
		m_sBeamPath.dBeamPathBetPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2[i]||
		m_sBeamPath.nBeamPathMaskPos1[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[i]||
		m_sBeamPath.nBeamPathMaskPos2[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[i]||
		m_sBeamPath.nBeamPathMaskPos3[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[i]||
		m_sBeamPath.nBeamPathAttenuatePos1[i] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[i]||
		m_sBeamPath.nBeamPathAttenuatePos2[i] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[i]||
		m_sBeamPath.dBeamPathZAxisPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i]||
		m_sBeamPath.dBeamPathZAxisPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i]||
		m_sBeamPath.bBeamPathUseTophat[i] != gBeamPathINI.m_sBeampath.bBeamPathUseTophat[i]||
		m_sBeamPath.bBeamPathLaserPath[i] != gBeamPathINI.m_sBeampath.bBeamPathLaserPath[i]||
		m_sBeamPath.dBeamPathVoltage1[i] != gBeamPathINI.m_sBeampath.dBeamPathVoltage1[i]||
		m_sBeamPath.dBeamPathVoltage2[i] != gBeamPathINI.m_sBeampath.dBeamPathVoltage2[i]||
		
		m_sBeamPath.dPowOffsetDuty[i] != gBeamPathINI.m_sBeampath.dPowOffsetDuty[i]||
		m_sBeamPath.dPowOffsetAomDelay[i] != gBeamPathINI.m_sBeampath.dPowOffsetAomDelay[i]||
		m_sBeamPath.dPowOffsetAomDuty[i] != gBeamPathINI.m_sBeampath.dPowOffsetAomDuty[i]||
		m_sBeamPath.dPowOffsetAomDual1[i] != gBeamPathINI.m_sBeampath.dPowOffsetAomDual1[i]||
		m_sBeamPath.dPowOffsetAomDual2[i] != gBeamPathINI.m_sBeampath.dPowOffsetAomDual2[i]||
		m_sBeamPath.dPowOffsetVoltage1[i] != gBeamPathINI.m_sBeampath.dPowOffsetVoltage1[i]||
		m_sBeamPath.dPowOffsetVoltage2[i] != gBeamPathINI.m_sBeampath.dPowOffsetVoltage2[i]||
		
		m_sBeamPath.nPowCompensationFrequency[i] != gBeamPathINI.m_sBeampath.nPowCompensationFrequency[i]||
		m_sBeamPath.dPowCompensationDuty[i] != gBeamPathINI.m_sBeampath.dPowCompensationDuty[i]||
		m_sBeamPath.dPowCompensationAomDelay[i] != gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[i]||
		m_sBeamPath.dPowCompensationAomDuty[i] != gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[i]||
		m_sBeamPath.dPowCompensationTargetMax[i] != gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[i]||
		m_sBeamPath.dPowCompensationTargetMin[i] != gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[i]||
		m_sBeamPath.dPowCompensationDutyOffset[i] != gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[i])
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER));
			bPowerChange = TRUE;
		}

		if(m_sBeamPath.dBeamPathBetPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1[i]||
			m_sBeamPath.dBeamPathBetPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2[i]||
			m_sBeamPath.nBeamPathMaskPos1[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[i]||
			m_sBeamPath.nBeamPathMaskPos2[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[i]||
			m_sBeamPath.nBeamPathMaskPos3[i] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[i]||
			m_sBeamPath.nBeamPathAttenuatePos1[i] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[i]||
			m_sBeamPath.nBeamPathAttenuatePos2[i] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[i]||
			m_sBeamPath.dBeamPathZAxisPos1[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[i]||
			m_sBeamPath.dBeamPathZAxisPos2[i] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[i]||
			m_sBeamPath.bBeamPathLaserPath[i] != gBeamPathINI.m_sBeampath.bBeamPathLaserPath[i]||
			m_sBeamPath.bBeamPathUseTophat[i] != gBeamPathINI.m_sBeampath.bBeamPathUseTophat[i]||
			m_sBeamPath.dBeamPathVoltage1[i] != gBeamPathINI.m_sBeampath.dBeamPathVoltage1[i]||
			m_sBeamPath.dBeamPathVoltage2[i] != gBeamPathINI.m_sBeampath.dBeamPathVoltage2[i])
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)DO_SCANNER);
			bScalChange = TRUE;
		}

		if(strcmp( m_sBeamPath.strBeamPathAscFile[i] , gBeamPathINI.m_sBeampath.strBeamPathAscFile[i]) !=0)
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)DO_SCANNER);
			bScalChange = TRUE;
		}
	}
	OnCheckRefresh();
	if(bPowerChange)
	{
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (CPaneSysSetupBeamPathLDD) : P"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
	if(bScalChange)
	{
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (CPaneSysSetupBeamPathLDD) : S"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}

}
BOOL CPaneSysSetupBeamPathLDD::CheckApply()
{
	for(int i = 0; i<= m_nRepeatCount; i++)
	{
		if(m_sBeamPath.dPowOffsetAomDual1[i] + m_sBeamPath.dPowOffsetAomDual2[i] != 100)
		{
			ErrMessage(_T("Please insert aom percentage total 100"));
			return FALSE;
		}	
	}
	return TRUE;
}

void CPaneSysSetupBeamPathLDD::GetCurrentASC()
{
	int nIndex = m_sBeamPath.nLastIndex;
	CString str;
	for(int i = 0; i <= nIndex; i++)
	{
		str = m_Grid.GetItemText( i+1,TABLE0_COLUMN_COUNT + TABLE1_COLUMN_COUNT - 1);
		FillTable1Data(TABLE1_COLUMN_COUNT - 1, i, str);
	}
}

// PaneManualControlIOMonitorOutputSub1Osan.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlIOMonitorOutputSub1Osan.h"
#include "..\device\devicemotor.h"
#include "..\device\hdevicefactory.h"
#include "..\Model\DSystemINI.h"
#include "..\alarmmsg.h"
#include "..\easydrillerdlg.h"
#include "..\model\deasydrillerini.h"
#include "paneautorun.h"
#include "..\model\dprocessini.h"
#include "..\EasyDrillerDlg.h"
#include "PaneManualControl.h"
#include "PaneManualControlMotor.h"
#include "..\device\HEocard.h"
#include "..\InterfaceMotorModule.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub1Osan

IMPLEMENT_DYNCREATE(CPaneManualControlIOMonitorOutputSub1Osan, CFormView)

CPaneManualControlIOMonitorOutputSub1Osan::CPaneManualControlIOMonitorOutputSub1Osan()
	: CFormView(CPaneManualControlIOMonitorOutputSub1Osan::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlIOMonitorOutputSub1Osan)
		// NOTE: the ClassWizard will add member initialization here
	m_nTimerID = 0;
	m_lStatus1 = m_lStatus1Old = 0;
	m_lStatus2 = m_lStatus2Old = 0;
	m_lStatus3 = m_lStatus3old = 0;
	m_lStatus4 = m_lStatus4old = 0;
	m_lStatus5 = m_lStatus5old = 0;	//2011518
	m_nSuction = m_nSuctionOld = 0;
	m_nSuction1 = m_nSuction1Old = 0;
	m_nSuction2 = m_nSuction2Old = 0;
	m_bMotor = m_bMotorOld = FALSE;
	m_bMotor2 = m_bMotor2Old = FALSE;
	m_bLamp = m_bLampOld = FALSE;
	m_bChuck = m_bChuckOld = FALSE;
	m_bLoadingShutter = m_bLoadingShutterOld = FALSE;
	m_bBrushSol = m_bBrushSolOld = FALSE;
	m_bStatusLoader1 = FALSE;
	m_bStatusLoader2 = FALSE;
	m_bStatusUnloader1 = FALSE;
	m_bStatusUnloader2 = FALSE;
	m_bStatusTable1 = FALSE;
	m_bStatusTable2 = FALSE;
	m_bStatusAligner = FALSE;
	m_bStatusAligner2 = FALSE;

	m_nVacuumType = VACUUM_A;

	//2011524
	m_RadioVacuumTable = 0;
	m_bAcrMotorOn = FALSE;
	//}}AFX_DATA_INIT
}

CPaneManualControlIOMonitorOutputSub1Osan::~CPaneManualControlIOMonitorOutputSub1Osan()
{
}

void CPaneManualControlIOMonitorOutputSub1Osan::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlIOMonitorOutputSub1Osan)
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_ROLL_USE_ON, m_btnRollUseOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_ROLL_USE_OFF, m_btnRollUseOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LASER_HEAD_PURGE_ON, m_btnLaserHeadPurgeOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LASER_HEAD_PURGE_OFF, m_btnLaserHeadPurgeOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LAMP_ON, m_btnLampOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LAMP_OFF, m_btnLampOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_SAFETY_MODE_ON, m_btnSafeOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_SAFETY_MODE_OFF, m_btnSafeOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_X, m_btnInitX);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_Y, m_btnInitY);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_Z1, m_btnInitZ1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_Z2, m_btnInitZ2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_M, m_btnInitM);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_M2, m_btnInitM2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_M3, m_btnInitM3);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_C, m_btnInitC);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_C2, m_btnInitC2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_A1, m_btnInitA1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_A2, m_btnInitA2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_LC, m_btnInitLC);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_INITIALIZE_UC, m_btnInitUC);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_POWERMETER_OPEN, m_btnPowermeterOpen);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_POWERMETER_CLOSE, m_btnPowermeterClose);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP, m_btnHeightSensorUp);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN, m_btnHeightSensorDown);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP2, m_btnHeightSensorUp2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN2, m_btnHeightSensorDown2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LASERSHUTTER1_OPEN, m_btnShutter1Open);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LASERSHUTTER1_CLOSE, m_btnShutter1Close);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LASERSHUTTER2_OPEN, m_btnShutter2Open);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LASERSHUTTER2_CLOSE, m_btnShutter2Close);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION1_ON, m_btnSuction1On);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION1_OFF, m_btnSuction1Off);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION2_ON, m_btnSuction2On);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION2_OFF, m_btnSuction2Off);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_VACUUM_MOTOR_ON, m_btnVacuumMotorOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_VACUUM_MOTOR_OFF, m_btnVacuumMotorOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_VACUUM_MOTOR2_ON, m_btnVacuumMotor2On);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_VACUUM_MOTOR2_OFF, m_btnVacuumMotor2Off);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_ALIGN, m_btnLoaderAlign);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_LOAD, m_btnLoaderLoad);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_ELV_LOAD_POS, m_btnLoadElvLoadPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_ELV_ORI_POS, m_btnLoadElvOriPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS, m_btnLoadCarrCartPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADER_CARR_TABLE_POS, m_btnLoadCarrTablePos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_UNLOAD, m_btnUnloaderUnload);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_ELV_LOAD_POS, m_btnUnloadElvUnloadPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_ELV_ORI_POS, m_btnUnloadElvOriPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_CARR_CART_POS, m_btnUnloadCarrCartPos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_UNLOADER_CARR_TABLE_POS, m_btnUnloadCarrTablePos);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLE_CLAMP, m_btnTableClamp);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLE_UNCLAMP, m_btnTableUnclamp);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLE_CLAMP2, m_btnTableClamp2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLE_UNCLAMP2, m_btnTableUnclamp2);
	DDX_Control(pDX, IDC_BUTTON_DOOR_BY_PASS_ON, m_btnDoorByPassOn);
	DDX_Control(pDX, IDC_BUTTON_DOOR_BY_PASS_OFF, m_btnDoorByPassOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADING_SHUTTER_OPEN, m_btnLoadingShutterOpen);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_LOADING_SHUTTER_CLOSE, m_btnLoadingShutterClose);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BUZZER_ON, m_btnBuzzerOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BUZZER_OFF, m_btnBuzzerOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AIR_BLOWER_ON, m_btnAirBlowerOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AIR_BLOWER_OFF, m_btnAirBlowerOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BRUSH_MOTOR_ON, m_btnBrushMotorOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BRUSH_MOTOR_OFF, m_btnBrushMotorOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BRUSH_SOL_UP, m_btnBrushSolUp);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BRUSH_SOL_DOWN, m_btnBrushSolDown);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_GREEN_LAMP_ON, m_btnGreenLampOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_GREEN_LAMP_OFF, m_btnGreenLampOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_YELLOW_LAMP_ON, m_btnYellowLampOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_YELLOW_LAMP_OFF, m_btnYellowLampOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RED_LAMP_ON, m_btnRedLampOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RED_LAMP_OFF, m_btnRedLampOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_LOADER1, m_btnResetLoader1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_LOADER2, m_btnResetLoader2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_LOADER_TABLE, m_btnResetLoaderTable);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_UNLOADER1, m_btnResetUnLoader1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_UNLOADER2, m_btnResetUnLoader2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_UNLOADER_TABLE, m_btnResetUnLoaderTable);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_TABLE1, m_btnResetTable1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_RESET_TABLE2, m_btnResetTable2);
	DDX_Radio(pDX,	IDC_RADIO_TABLE_VACUMM_A,	m_RadioVacuumTable);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_AOMPOWER_ON, m_btnAOMPower);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION_DEFUALT_ON, m_btnTable1DefaultOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION_DEFUALT_OFF, m_btnTable1DefaultOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION_DEFUALT_ON2, m_btnTable2DefaultOn);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_TABLESUCTION_DEFUALT_OFF2, m_btnTable2DefaultOff);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_HOOD_SHUTTER_OPEN, m_btnHoodShutterOpen);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_HOOD_SHUTTER_CLOSE, m_btnHoodShutterClose);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BEAMPASS_MASTER_UP, m_btnBeamPassUp1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BEAMPASS_MASTER_DOWN, m_btnBeamPassDown1);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BEAMPASS_SLAVE_UP, m_btnBeamPassUp2);
	DDX_Control(pDX, IDC_BUTTON_OUTPUT_BEAMPASS_SLAVE_DOWN, m_btnBeamPassDown2);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlIOMonitorOutputSub1Osan, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlIOMonitorOutputSub1Osan)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_ROLL_USE_ON, OnButtonOutputRollUseOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_ROLL_USE_OFF, OnButtonOutputRollUseOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LASER_HEAD_PURGE_ON, OnButtonOutputLaserHeadPurgeOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LASER_HEAD_PURGE_OFF, OnButtonOutputLaserHeadPurgeOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LAMP_ON, OnButtonOutputLampOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LAMP_OFF, OnButtonOutputLampOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_SAFETY_MODE_ON, OnButtonOutputSafetyModeOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_SAFETY_MODE_OFF, OnButtonOutputSafetyModeOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_X, OnButtonOutputInitializeX)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_Y, OnButtonOutputInitializeY)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_Z1, OnButtonOutputInitializeZ1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_Z2, OnButtonOutputInitializeZ2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_M, OnButtonOutputInitializeM)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_M2, OnButtonOutputInitializeM2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_M3, OnButtonOutputInitializeM3)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_C, OnButtonOutputInitializeC)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_C2, OnButtonOutputInitializeC2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_LC, OnButtonOutputInitializeLC)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_UC, OnButtonOutputInitializeUC)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_POWERMETER_OPEN, OnButtonOutputPowermeterOpen)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_POWERMETER_CLOSE, OnButtonOutputPowermeterClose)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP, OnButtonOutputHeightSensorUp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN, OnButtonOutputHeightSensorDown)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP2, OnButtonOutputHeightSensorUp2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN2, OnButtonOutputHeightSensorDown2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LASERSHUTTER1_OPEN, OnButtonOutputLasershutter1Open)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LASERSHUTTER1_CLOSE, OnButtonOutputLasershutter1Close)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LASERSHUTTER2_OPEN, OnButtonOutputLasershutter2Open)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LASERSHUTTER2_CLOSE, OnButtonOutputLasershutter2Close)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION1_ON, OnButtonOutputTablesuction1On)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION1_OFF, OnButtonOutputTablesuction1Off)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION2_ON, OnButtonOutputTablesuction2On)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION2_OFF, OnButtonOutputTablesuction2Off)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_VACUUM_MOTOR_ON, OnButtonOutputVacuumMotorOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_VACUUM_MOTOR_OFF, OnButtonOutputVacuumMotorOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_VACUUM_MOTOR2_ON, OnButtonOutputVacuumMotor2On)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_VACUUM_MOTOR2_OFF, OnButtonOutputVacuumMotor2Off)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_ALIGN, OnButtonOutputLoaderAlign)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_LOAD, OnButtonOutputLoaderLoad)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_ELV_LOAD_POS, OnButtonOutputLoaderElvLoadPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_ELV_ORI_POS, OnButtonOutputLoaderElvOriPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS, OnButtonOutputLoaderCarrCartPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADER_CARR_TABLE_POS, OnButtonOutputLoaderCarrTablePos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_UNLOAD, OnButtonOutputUnloaderUnload)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_ELV_LOAD_POS, OnButtonOutputUnloaderElvLoadPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_ELV_ORI_POS, OnButtonOutputUnloaderElvOriPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_CARR_CART_POS, OnButtonOutputUnloaderCarrCartPos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_UNLOADER_CARR_TABLE_POS, OnButtonOutputUnloaderCarrTablePos)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLE_CLAMP, OnButtonOutputTableClamp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLE_UNCLAMP, OnButtonOutputTableUnclamp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLE_CLAMP2, OnButtonOutputTableClamp2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLE_UNCLAMP2, OnButtonOutputTableUnclamp2)
	ON_BN_CLICKED(IDC_BUTTON_DOOR_BY_PASS_ON, OnButtonDoorByPassOn)
	ON_BN_CLICKED(IDC_BUTTON_DOOR_BY_PASS_OFF, OnButtonDoorByPassOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADING_SHUTTER_OPEN, OnButtonOutputLoadingShutterOpen)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_LOADING_SHUTTER_CLOSE, OnButtonOutputLoadingShutterClose)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BUZZER_ON, OnButtonOutputBuzzerOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BUZZER_OFF, OnButtonOutputBuzzerOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AIR_BLOWER_ON, OnButtonOutputAirBlowerOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AIR_BLOWER_OFF, OnButtonOutputAirBlowerOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BRUSH_MOTOR_ON, OnButtonOutputBrushMotorOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BRUSH_MOTOR_OFF, OnButtonOutputBrushMotorOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BRUSH_SOL_UP, OnButtonOutputBrushSolUp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BRUSH_SOL_DOWN, OnButtonOutputBrushSolDown)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_GREEN_LAMP_ON, OnButtonOutputGreenLampOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_GREEN_LAMP_OFF, OnButtonOutputGreenLampOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_YELLOW_LAMP_ON, OnButtonOutputYellowLampOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_YELLOW_LAMP_OFF, OnButtonOutputYellowLampOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RED_LAMP_ON, OnButtonOutputRedLampOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RED_LAMP_OFF, OnButtonOutputRedLampOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_LOADER1, OnButtonOutputResetLoader1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_LOADER2, OnButtonOutputResetLoader2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_LOADER_TABLE, OnButtonOutputResetLoaderTable)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_UNLOADER1, OnButtonOutputResetUnloader1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_UNLOADER2, OnButtonOutputResetUnloader2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_UNLOADER_TABLE, OnButtonOutputResetUnloaderTable)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_TABLE1, OnButtonOutputResetTable1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_RESET_TABLE2, OnButtonOutputResetTable2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_AOMPOWER_ON, OnButtonOutputAOMPowerOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION_DEFUALT_ON, OnButtonOutputTablesuctionDefualtOn)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION_DEFUALT_OFF, OnButtonOutputTablesuctionDefualtOff)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION_DEFUALT_ON2, OnButtonOutputTablesuctionDefualtOn2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_TABLESUCTION_DEFUALT_OFF2, OnButtonOutputTablesuctionDefualtOff2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_HOOD_SHUTTER_OPEN, OnButtonOutputHoodShutterOpen)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_HOOD_SHUTTER_CLOSE, OnButtonOutputHoodShutterClose)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_A1, OnButtonOutputInitializeA1)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_INITIALIZE_A2, OnButtonOutputInitializeA2)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BEAMPASS_MASTER_UP, OnButtonOutputBeampassMasterUp)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BEAMPASS_MASTER_DOWN, OnButtonOutputBeampassMasterDown)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BEAMPASS_SLAVE_UP, OnButtonOutputBeampassSlaveUp)
	ON_BN_CLICKED(IDC_RADIO_TABLE_VACUMM_A, OnRadioTableAVacuum)
	ON_BN_CLICKED(IDC_RADIO_TABLE_VACUMM_B, OnRadioTableBVacuum)
	ON_BN_CLICKED(IDC_RADIO_TABLE_VACUMM_C, OnRadioTableCVacuum)
	ON_BN_CLICKED(IDC_RADIO_TABLE_VACUMM_D, OnRadioTableDVacuum)
	ON_BN_CLICKED(IDC_BUTTON_OUTPUT_BEAMPASS_SLAVE_DOWN, OnButtonOutputBeampassSlaveDown)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub1Osan diagnostics

#ifdef _DEBUG
void CPaneManualControlIOMonitorOutputSub1Osan::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlIOMonitorOutputSub1Osan::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutputSub1Osan message handlers

void CPaneManualControlIOMonitorOutputSub1Osan::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class

	InitBtnControl();
}

void CPaneManualControlIOMonitorOutputSub1Osan::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(100, "Arial Bold");

	m_btnRollUseOn.SetFont( &m_fntBtn );
	m_btnRollUseOn.SetFlat( FALSE );
	m_btnRollUseOn.EnableBallonToolTip();
	m_btnRollUseOn.SetToolTipText( _T("Roll Up/Down Use On") );
	m_btnRollUseOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRollUseOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnRollUseOff.SetFont( &m_fntBtn );
	m_btnRollUseOff.SetFlat( FALSE );
	m_btnRollUseOff.EnableBallonToolTip();
	m_btnRollUseOff.SetToolTipText( _T("Roll Up/Down Use Off") );
	m_btnRollUseOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRollUseOff.SetBtnCursor(IDC_HAND_1);

	m_btnLaserHeadPurgeOn.SetFont( &m_fntBtn );
	m_btnLaserHeadPurgeOn.SetFlat( FALSE );
	m_btnLaserHeadPurgeOn.EnableBallonToolTip();
	m_btnLaserHeadPurgeOn.SetToolTipText( _T("Laser Head Purge On") );
	m_btnLaserHeadPurgeOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLaserHeadPurgeOn.SetBtnCursor(IDC_HAND_1);

	m_btnLaserHeadPurgeOff.SetFont( &m_fntBtn );
	m_btnLaserHeadPurgeOff.SetFlat( FALSE );
	m_btnLaserHeadPurgeOff.EnableBallonToolTip();
	m_btnLaserHeadPurgeOff.SetToolTipText( _T("Laser Head Purge Off") );
	m_btnLaserHeadPurgeOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLaserHeadPurgeOff.SetBtnCursor(IDC_HAND_1);
	
	m_btnLampOn.SetFont( &m_fntBtn );
	m_btnLampOn.SetFlat( FALSE );
	m_btnLampOn.EnableBallonToolTip();
	m_btnLampOn.SetToolTipText( _T("���� �ѱ�") );
	m_btnLampOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLampOn.SetBtnCursor(IDC_HAND_1);

	m_btnLampOff.SetFont( &m_fntBtn );
	m_btnLampOff.SetFlat( FALSE );
	m_btnLampOff.EnableBallonToolTip();
	m_btnLampOff.SetToolTipText( _T("���� ����") );
	m_btnLampOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLampOff.SetBtnCursor(IDC_HAND_1);

	m_btnSafeOn.SetFont( &m_fntBtn );
	m_btnSafeOn.SetFlat( FALSE );
	m_btnSafeOn.EnableBallonToolTip();
	m_btnSafeOn.SetToolTipText( _T("������� �ѱ�") );
	m_btnSafeOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSafeOn.SetBtnCursor(IDC_HAND_1);

	//2011526
	m_btnAOMPower.SetFont( &m_fntBtn );
	m_btnAOMPower.SetFlat( FALSE );
	m_btnAOMPower.EnableBallonToolTip();
	m_btnAOMPower.SetToolTipText( _T("AOM Power On") );
	m_btnAOMPower.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAOMPower.SetBtnCursor(IDC_HAND_1);


	m_btnSafeOff.SetFont( &m_fntBtn );
	m_btnSafeOff.SetFlat( FALSE );
	m_btnSafeOff.EnableBallonToolTip();
	m_btnSafeOff.SetToolTipText( _T("������� ����") );
	m_btnSafeOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSafeOff.SetBtnCursor(IDC_HAND_1);

	m_btnInitX.SetFont( &m_fntBtn );
	m_btnInitX.SetFlat( FALSE );
	m_btnInitX.EnableBallonToolTip();
	m_btnInitX.SetToolTipText( _T("X�� �ʱ�ȭ") );
	m_btnInitX.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitX.SetBtnCursor(IDC_HAND_1);

	m_btnInitY.SetFont( &m_fntBtn );
	m_btnInitY.SetFlat( FALSE );
	m_btnInitY.EnableBallonToolTip();
	m_btnInitY.SetToolTipText( _T("Y�� �ʱ�ȭ") );
	m_btnInitY.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitY.SetBtnCursor(IDC_HAND_1);

	m_btnInitZ1.SetFont( &m_fntBtn );
	m_btnInitZ1.SetFlat( FALSE );
	m_btnInitZ1.EnableBallonToolTip();
	m_btnInitZ1.SetToolTipText( _T("Z1�� �ʱ�ȭ") );
	m_btnInitZ1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitZ1.SetBtnCursor(IDC_HAND_1);

	m_btnInitZ2.SetFont( &m_fntBtn );
	m_btnInitZ2.SetFlat( FALSE );
	m_btnInitZ2.EnableBallonToolTip();
	m_btnInitZ2.SetToolTipText( _T("Z2�� �ʱ�ȭ") );
	m_btnInitZ2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitZ2.SetBtnCursor(IDC_HAND_1);

	m_btnInitM.SetFont( &m_fntBtn );
	m_btnInitM.SetFlat( FALSE );
	m_btnInitM.EnableBallonToolTip();
	m_btnInitM.SetToolTipText( _T("M1�� �ʱ�ȭ") );
	m_btnInitM.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitM.SetBtnCursor(IDC_HAND_1);

	m_btnInitM2.SetFont( &m_fntBtn );
	m_btnInitM2.SetFlat( FALSE );
	m_btnInitM2.EnableBallonToolTip();
	m_btnInitM2.SetToolTipText( _T("M2�� �ʱ�ȭ") );
	m_btnInitM2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitM2.SetBtnCursor(IDC_HAND_1);

	m_btnInitM3.SetFont( &m_fntBtn );
	m_btnInitM3.SetFlat( FALSE );
	m_btnInitM3.EnableBallonToolTip();
	m_btnInitM3.SetToolTipText( _T("M3�� �ʱ�ȭ") );
	m_btnInitM3.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitM3.SetBtnCursor(IDC_HAND_1);

	m_btnInitC.SetFont( &m_fntBtn );
	m_btnInitC.SetFlat( FALSE );
	m_btnInitC.EnableBallonToolTip();
	m_btnInitC.SetToolTipText( _T("B1�� �ʱ�ȭ") );
	m_btnInitC.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitC.SetBtnCursor(IDC_HAND_1);

	m_btnInitC2.SetFont( &m_fntBtn );
	m_btnInitC2.SetFlat( FALSE );
	m_btnInitC2.EnableBallonToolTip();
	m_btnInitC2.SetToolTipText( _T("B2�� �ʱ�ȭ") );
	m_btnInitC2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitC2.SetBtnCursor(IDC_HAND_1);

	m_btnInitA1.SetFont( &m_fntBtn );
	m_btnInitA1.SetFlat( FALSE );
	m_btnInitA1.EnableBallonToolTip();
	m_btnInitA1.SetToolTipText( _T("A1�� �ʱ�ȭ") );
	m_btnInitA1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitA1.SetBtnCursor(IDC_HAND_1);
	
	m_btnInitA2.SetFont( &m_fntBtn );
	m_btnInitA2.SetFlat( FALSE );
	m_btnInitA2.EnableBallonToolTip();
	m_btnInitA2.SetToolTipText( _T("A2�� �ʱ�ȭ") );
	m_btnInitA2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitA2.SetBtnCursor(IDC_HAND_1);

	m_btnInitLC.SetFont( &m_fntBtn );
	m_btnInitLC.SetFlat( FALSE );
	m_btnInitLC.EnableBallonToolTip();
	m_btnInitLC.SetToolTipText( _T("�δ�ĳ���� �ʱ�ȭ") );
	m_btnInitLC.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitLC.SetBtnCursor(IDC_HAND_1);

	m_btnInitUC.SetFont( &m_fntBtn );
	m_btnInitUC.SetFlat( FALSE );
	m_btnInitUC.EnableBallonToolTip();
	m_btnInitUC.SetToolTipText( _T("��δ�ĳ���� �ʱ�ȭ") );
	m_btnInitUC.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInitUC.SetBtnCursor(IDC_HAND_1);
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		m_btnInitM.SetWindowText("Axis-A1 Initialize");
		m_btnInitM.SetToolTipText( _T("Axis-A1 Initialize") );
		m_btnInitC.SetWindowText("Axis-A2 Initialize");
		m_btnInitC.SetToolTipText( _T("Axis-A2 Initialize") );
	}

	m_btnPowermeterOpen.SetFont( &m_fntBtn );
	m_btnPowermeterOpen.SetFlat( FALSE );
	m_btnPowermeterOpen.EnableBallonToolTip();
	m_btnPowermeterOpen.SetToolTipText( _T("�Ŀ����ͼ��� ����") );
	m_btnPowermeterOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPowermeterOpen.SetBtnCursor(IDC_HAND_1);

	m_btnPowermeterClose.SetFont( &m_fntBtn );
	m_btnPowermeterClose.SetFlat( FALSE );
	m_btnPowermeterClose.EnableBallonToolTip();
	m_btnPowermeterClose.SetToolTipText( _T("�Ŀ����ͼ��� �ݱ�") );
	m_btnPowermeterClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnPowermeterClose.SetBtnCursor(IDC_HAND_1);

	m_btnHeightSensorUp.SetFont( &m_fntBtn );
	m_btnHeightSensorUp.SetFlat( FALSE );
	m_btnHeightSensorUp.EnableBallonToolTip();
	m_btnHeightSensorUp.SetToolTipText( _T("�β���������1 ��") );
	m_btnHeightSensorUp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHeightSensorUp.SetBtnCursor(IDC_HAND_1);

	m_btnHeightSensorDown.SetFont( &m_fntBtn );
	m_btnHeightSensorDown.SetFlat( FALSE );
	m_btnHeightSensorDown.EnableBallonToolTip();
	m_btnHeightSensorDown.SetToolTipText( _T("�β���������1 �ٿ�") );
	m_btnHeightSensorDown.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHeightSensorDown.SetBtnCursor(IDC_HAND_1);

	m_btnHeightSensorUp2.SetFont( &m_fntBtn );
	m_btnHeightSensorUp2.SetFlat( FALSE );
	m_btnHeightSensorUp2.EnableBallonToolTip();
	m_btnHeightSensorUp2.SetToolTipText( _T("H�β����������� ��") );
	m_btnHeightSensorUp2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHeightSensorUp2.SetBtnCursor(IDC_HAND_1);
	
	m_btnHeightSensorDown2.SetFont( &m_fntBtn );
	m_btnHeightSensorDown2.SetFlat( FALSE );
	m_btnHeightSensorDown2.EnableBallonToolTip();
	m_btnHeightSensorDown2.SetToolTipText( _T("�β���������2 �ٿ�") );
	m_btnHeightSensorDown2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHeightSensorDown2.SetBtnCursor(IDC_HAND_1);

	m_btnShutter1Open.SetFont( &m_fntBtn );
	m_btnShutter1Open.SetFlat( FALSE );
	m_btnShutter1Open.EnableBallonToolTip();
	m_btnShutter1Open.SetToolTipText( _T("����������1 ����") );
	m_btnShutter1Open.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShutter1Open.SetBtnCursor(IDC_HAND_1);

	m_btnShutter1Close.SetFont( &m_fntBtn );
	m_btnShutter1Close.SetFlat( FALSE );
	m_btnShutter1Close.EnableBallonToolTip();
	m_btnShutter1Close.SetToolTipText( _T("����������1 �ݱ�") );
	m_btnShutter1Close.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShutter1Close.SetBtnCursor(IDC_HAND_1);

	m_btnShutter2Open.SetFont( &m_fntBtn );
	m_btnShutter2Open.SetFlat( FALSE );
	m_btnShutter2Open.EnableBallonToolTip();
	m_btnShutter2Open.SetToolTipText( _T("����������2 ����") );
	m_btnShutter2Open.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShutter2Open.SetBtnCursor(IDC_HAND_1);
	
	m_btnShutter2Close.SetFont( &m_fntBtn );
	m_btnShutter2Close.SetFlat( FALSE );
	m_btnShutter2Close.EnableBallonToolTip();
	m_btnShutter2Close.SetToolTipText( _T("����������2 �ݱ�") );
	m_btnShutter2Close.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnShutter2Close.SetBtnCursor(IDC_HAND_1);

	m_btnSuction1On.SetFont( &m_fntBtn );
	m_btnSuction1On.SetFlat( FALSE );
	m_btnSuction1On.EnableBallonToolTip();
	m_btnSuction1On.SetToolTipText( _T("���̺�1 �����ѱ�") );
	m_btnSuction1On.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuction1On.SetBtnCursor(IDC_HAND_1);
	m_btnSuction1On.SetSelection( 0 );

	m_btnSuction1Off.SetFont( &m_fntBtn );
	m_btnSuction1Off.SetFlat( FALSE );
	m_btnSuction1Off.EnableBallonToolTip();
	m_btnSuction1Off.SetToolTipText( _T("���̺�1 ���в���") );
	m_btnSuction1Off.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuction1Off.SetBtnCursor(IDC_HAND_1);
	m_btnSuction1Off.SetSelection( 1 );

	m_btnSuction2On.SetFont( &m_fntBtn );
	m_btnSuction2On.SetFlat( FALSE );
	m_btnSuction2On.EnableBallonToolTip();
	m_btnSuction2On.SetToolTipText( _T("���̺�2 �����ѱ�") );
	m_btnSuction2On.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuction2On.SetBtnCursor(IDC_HAND_1);
	m_btnSuction2On.SetSelection( 0 );
	
	m_btnSuction2Off.SetFont( &m_fntBtn );
	m_btnSuction2Off.SetFlat( FALSE );
	m_btnSuction2Off.EnableBallonToolTip();
	m_btnSuction2Off.SetToolTipText( _T("���̺�2 ���в���") );
	m_btnSuction2Off.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSuction2Off.SetBtnCursor(IDC_HAND_1);
	m_btnSuction2Off.SetSelection( 1 );

	m_btnVacuumMotorOn.SetFont( &m_fntBtn );
	m_btnVacuumMotorOn.SetFlat( FALSE );
	m_btnVacuumMotorOn.EnableBallonToolTip();
	m_btnVacuumMotorOn.SetToolTipText( _T("VacuumMotor1 On") );
	m_btnVacuumMotorOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVacuumMotorOn.SetBtnCursor(IDC_HAND_1);

	m_btnVacuumMotorOff.SetFont( &m_fntBtn );
	m_btnVacuumMotorOff.SetFlat( FALSE );
	m_btnVacuumMotorOff.EnableBallonToolTip();
	m_btnVacuumMotorOff.SetToolTipText( _T("VacuumMotor1 Off") );
	m_btnVacuumMotorOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVacuumMotorOff.SetBtnCursor(IDC_HAND_1);

	m_btnVacuumMotor2On.SetFont( &m_fntBtn );
	m_btnVacuumMotor2On.SetFlat( FALSE );
	m_btnVacuumMotor2On.EnableBallonToolTip();
	m_btnVacuumMotor2On.SetToolTipText( _T("VacuumMotor2 On") );
	m_btnVacuumMotor2On.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVacuumMotor2On.SetBtnCursor(IDC_HAND_1);
	
	m_btnVacuumMotor2Off.SetFont( &m_fntBtn );
	m_btnVacuumMotor2Off.SetFlat( FALSE );
	m_btnVacuumMotor2Off.EnableBallonToolTip();
	m_btnVacuumMotor2Off.SetToolTipText( _T("VacuumMotor2 Off") );
	m_btnVacuumMotor2Off.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVacuumMotor2Off.SetBtnCursor(IDC_HAND_1);

	m_btnLoaderAlign.SetFont( &m_fntBtn );
	m_btnLoaderAlign.SetFlat( FALSE );
	m_btnLoaderAlign.EnableBallonToolTip();
	m_btnLoaderAlign.SetToolTipText( _T("Align") );
	m_btnLoaderAlign.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderAlign.SetBtnCursor(IDC_HAND_1);	

	m_btnLoaderLoad.SetFont( &m_fntBtn );
	m_btnLoaderLoad.SetFlat( FALSE );
	m_btnLoaderLoad.EnableBallonToolTip();
	m_btnLoaderLoad.SetToolTipText( _T("Loading") );
	m_btnLoaderLoad.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoaderLoad.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadElvLoadPos.SetFont( &m_fntBtn );
	m_btnLoadElvLoadPos.SetFlat( FALSE );
	m_btnLoadElvLoadPos.EnableBallonToolTip();
	m_btnLoadElvLoadPos.SetToolTipText( _T("�δ�Elv �ε� ��ġ��") );
	m_btnLoadElvLoadPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadElvLoadPos.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadElvOriPos.SetFont( &m_fntBtn );
	m_btnLoadElvOriPos.SetFlat( FALSE );
	m_btnLoadElvOriPos.EnableBallonToolTip();
	m_btnLoadElvOriPos.SetToolTipText( _T("�ε�Elv �ʱ� ��ġ��") );
	m_btnLoadElvOriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadElvOriPos.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadCarrCartPos.SetFont( &m_fntBtn );
	m_btnLoadCarrCartPos.SetFlat( FALSE );
	m_btnLoadCarrCartPos.EnableBallonToolTip();
	m_btnLoadCarrCartPos.SetToolTipText( _T("�δ� ĳ���� Elevator ��ġ��") );
	m_btnLoadCarrCartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarrCartPos.SetBtnCursor(IDC_HAND_1);	

	m_btnLoadCarrTablePos.SetFont( &m_fntBtn );
	m_btnLoadCarrTablePos.SetFlat( FALSE );
	m_btnLoadCarrTablePos.EnableBallonToolTip();
	m_btnLoadCarrTablePos.SetToolTipText( _T("�δ��ɸ��� ���̺� ��ġ��") );
	m_btnLoadCarrTablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadCarrTablePos.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloaderUnload.SetFont( &m_fntBtn );
	m_btnUnloaderUnload.SetFlat( FALSE );
	m_btnUnloaderUnload.EnableBallonToolTip();
	m_btnUnloaderUnload.SetToolTipText( _T("Unloading") );
	m_btnUnloaderUnload.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloaderUnload.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloadElvUnloadPos.SetFont( &m_fntBtn );
	m_btnUnloadElvUnloadPos.SetFlat( FALSE );
	m_btnUnloadElvUnloadPos.EnableBallonToolTip();
	m_btnUnloadElvUnloadPos.SetToolTipText( _T("��δ�Elv ��δ� ��ġ��") );
	m_btnUnloadElvUnloadPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadElvUnloadPos.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloadElvOriPos.SetFont( &m_fntBtn );
	m_btnUnloadElvOriPos.SetFlat( FALSE );
	m_btnUnloadElvOriPos.EnableBallonToolTip();
	m_btnUnloadElvOriPos.SetToolTipText( _T("��δ�Elv �ʱ���ġ��") );
	m_btnUnloadElvOriPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadElvOriPos.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloadCarrCartPos.SetFont( &m_fntBtn );
	m_btnUnloadCarrCartPos.SetFlat( FALSE );
	m_btnUnloadCarrCartPos.EnableBallonToolTip();
	m_btnUnloadCarrCartPos.SetToolTipText( _T("��δ� ĳ���� Elevator ��ġ��") );
	m_btnUnloadCarrCartPos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarrCartPos.SetBtnCursor(IDC_HAND_1);	

	m_btnUnloadCarrTablePos.SetFont( &m_fntBtn );
	m_btnUnloadCarrTablePos.SetFlat( FALSE );
	m_btnUnloadCarrTablePos.EnableBallonToolTip();
	m_btnUnloadCarrTablePos.SetToolTipText( _T("��δ��ɸ��� ���̺� ��ġ��") );
	m_btnUnloadCarrTablePos.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUnloadCarrTablePos.SetBtnCursor(IDC_HAND_1);	
	
	m_btnTableClamp.SetFont( &m_fntBtn );
	m_btnTableClamp.SetFlat( FALSE );
	m_btnTableClamp.EnableBallonToolTip();
	m_btnTableClamp.SetToolTipText( _T("���̺� Ŭ����1") );
	m_btnTableClamp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableClamp.SetBtnCursor(IDC_HAND_1);
	
	m_btnTableUnclamp.SetFont( &m_fntBtn );
	m_btnTableUnclamp.SetFlat( FALSE );
	m_btnTableUnclamp.EnableBallonToolTip();
	m_btnTableUnclamp.SetToolTipText( _T("���̺� ��Ŭ����1") );
	m_btnTableUnclamp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableUnclamp.SetBtnCursor(IDC_HAND_1);

	m_btnTableClamp2.SetFont( &m_fntBtn );
	m_btnTableClamp2.SetFlat( FALSE );
	m_btnTableClamp2.EnableBallonToolTip();
	m_btnTableClamp2.SetToolTipText( _T("���̺� Ŭ����") );
	m_btnTableClamp2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableClamp2.SetBtnCursor(IDC_HAND_1);
	
	m_btnTableUnclamp2.SetFont( &m_fntBtn );
	m_btnTableUnclamp2.SetFlat( FALSE );
	m_btnTableUnclamp2.EnableBallonToolTip();
	m_btnTableUnclamp2.SetToolTipText( _T("���̺� ��Ŭ����") );
	m_btnTableUnclamp2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTableUnclamp2.SetBtnCursor(IDC_HAND_1);

	if (gSystemINI.m_sHardWare.nTableClamp == 0)
	{
		m_btnTableClamp.ShowWindow(SW_HIDE);
		m_btnTableUnclamp.ShowWindow(SW_HIDE);
		m_btnTableClamp2.ShowWindow(SW_HIDE);
		m_btnTableUnclamp2.ShowWindow(SW_HIDE);
	}
	else if(gSystemINI.m_sHardWare.nTableClamp == 1)
	{
		m_btnTableClamp.ShowWindow(SW_SHOW);
		m_btnTableUnclamp.ShowWindow(SW_SHOW);
		m_btnTableClamp2.ShowWindow(SW_HIDE);
		m_btnTableUnclamp2.ShowWindow(SW_HIDE);
	}
	else
	{
		m_btnTableClamp.ShowWindow(SW_SHOW);
		m_btnTableUnclamp.ShowWindow(SW_SHOW);
		m_btnTableClamp2.ShowWindow(SW_SHOW);
		m_btnTableUnclamp2.ShowWindow(SW_SHOW);
	}

	m_btnDoorByPassOn.SetFont( &m_fntBtn );
	m_btnDoorByPassOn.SetFlat( FALSE );
	m_btnDoorByPassOn.EnableBallonToolTip();
	m_btnDoorByPassOn.SetToolTipText( _T("DoorBypass On") );
	m_btnDoorByPassOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDoorByPassOn.SetBtnCursor(IDC_HAND_1);

	m_btnDoorByPassOff.SetFont( &m_fntBtn );
	m_btnDoorByPassOff.SetFlat( FALSE );
	m_btnDoorByPassOff.EnableBallonToolTip();
	m_btnDoorByPassOff.SetToolTipText( _T("DoorBypass Off") );
	m_btnDoorByPassOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDoorByPassOff.SetBtnCursor(IDC_HAND_1);

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		m_btnInitZ2.ShowWindow(SW_HIDE);
		m_btnShutter2Open.ShowWindow(SW_HIDE);
		m_btnShutter2Close.ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
	{
		m_btnInitZ1.ShowWindow(SW_HIDE);
		m_btnInitZ2.ShowWindow(SW_HIDE);
		m_btnInitM.ShowWindow(SW_HIDE);
		m_btnInitC.ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 0)
	{
		m_btnSuction2On.ShowWindow(SW_HIDE);
		m_btnSuction2Off.ShowWindow(SW_HIDE);
	}
	
	if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() == 0)
	{
		m_btnPowermeterOpen.ShowWindow(SW_HIDE);
		m_btnPowermeterClose.ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 1)
	{
		m_btnHeightSensorUp.ShowWindow(SW_HIDE);
		m_btnHeightSensorDown.ShowWindow(SW_HIDE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 2)
	{
//		m_btnHeightSensorUp2.ShowWindow(SW_HIDE);
//		m_btnHeightSensorDown2.ShowWindow(SW_HIDE);
	}

	m_btnLoadingShutterOpen.SetFont( &m_fntBtn );
	m_btnLoadingShutterOpen.SetFlat( FALSE );
	m_btnLoadingShutterOpen.EnableBallonToolTip();
	m_btnLoadingShutterOpen.SetToolTipText( _T("LoadingShutter Open") );
	m_btnLoadingShutterOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadingShutterOpen.SetBtnCursor(IDC_HAND_1);

	m_btnLoadingShutterClose.SetFont( &m_fntBtn );
	m_btnLoadingShutterClose.SetFlat( FALSE );
	m_btnLoadingShutterClose.EnableBallonToolTip();
	m_btnLoadingShutterClose.SetToolTipText( _T("LoadingShutter Close") );
	m_btnLoadingShutterClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLoadingShutterClose.SetBtnCursor(IDC_HAND_1);

	m_btnBuzzerOn.SetFont( &m_fntBtn );
	m_btnBuzzerOn.SetFlat( FALSE );
	m_btnBuzzerOn.EnableBallonToolTip();
	m_btnBuzzerOn.SetToolTipText( _T("Buzzer On") );
	m_btnBuzzerOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBuzzerOn.SetBtnCursor(IDC_HAND_1);

	m_btnBuzzerOff.SetFont( &m_fntBtn );
	m_btnBuzzerOff.SetFlat( FALSE );
	m_btnBuzzerOff.EnableBallonToolTip();
	m_btnBuzzerOff.SetToolTipText( _T("Buzzer Off") );
	m_btnBuzzerOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBuzzerOff.SetBtnCursor(IDC_HAND_1);

	m_btnAirBlowerOn.SetFont( &m_fntBtn );
	m_btnAirBlowerOn.SetFlat( FALSE );
	m_btnAirBlowerOn.EnableBallonToolTip();
	m_btnAirBlowerOn.SetToolTipText( _T("AirBlower On") );
	m_btnAirBlowerOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAirBlowerOn.SetBtnCursor(IDC_HAND_1);

	m_btnAirBlowerOff.SetFont( &m_fntBtn );
	m_btnAirBlowerOff.SetFlat( FALSE );
	m_btnAirBlowerOff.EnableBallonToolTip();
	m_btnAirBlowerOff.SetToolTipText( _T("AirBlower Off") );
	m_btnAirBlowerOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAirBlowerOff.SetBtnCursor(IDC_HAND_1);
	
	m_btnBrushMotorOn.SetFont( &m_fntBtn );
	m_btnBrushMotorOn.SetFlat( FALSE );
	m_btnBrushMotorOn.EnableBallonToolTip();
	m_btnBrushMotorOn.SetToolTipText( _T("������ �н� ��") );
	m_btnBrushMotorOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBrushMotorOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnBrushMotorOff.SetFont( &m_fntBtn );
	m_btnBrushMotorOff.SetFlat( FALSE );
	m_btnBrushMotorOff.EnableBallonToolTip();
	m_btnBrushMotorOff.SetToolTipText( _T("������ �н� �ٿ�") );
	m_btnBrushMotorOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBrushMotorOff.SetBtnCursor(IDC_HAND_1);
	
	m_btnBrushSolUp.SetFont( &m_fntBtn );
	m_btnBrushSolUp.SetFlat( FALSE );
	m_btnBrushSolUp.EnableBallonToolTip();
//	m_btnBrushSolUp.SetToolTipText( _T("BrushSol Up") );
	m_btnBrushSolUp.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBrushSolUp.SetBtnCursor(IDC_HAND_1);
	
	m_btnBrushSolDown.SetFont( &m_fntBtn );
	m_btnBrushSolDown.SetFlat( FALSE );
	m_btnBrushSolDown.EnableBallonToolTip();
//	m_btnBrushSolDown.SetToolTipText( _T("BrushSol Down") );
	m_btnBrushSolDown.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBrushSolDown.SetBtnCursor(IDC_HAND_1);

	m_btnGreenLampOn.SetFont( &m_fntBtn );
	m_btnGreenLampOn.SetFlat( FALSE );
	m_btnGreenLampOn.EnableBallonToolTip();
	m_btnGreenLampOn.SetToolTipText( _T("GreenLamp On") );
	m_btnGreenLampOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGreenLampOn.SetBtnCursor(IDC_HAND_1);

	m_btnGreenLampOff.SetFont( &m_fntBtn );
	m_btnGreenLampOff.SetFlat( FALSE );
	m_btnGreenLampOff.EnableBallonToolTip();
	m_btnGreenLampOff.SetToolTipText( _T("GreenLamp Off") );
	m_btnGreenLampOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnGreenLampOff.SetBtnCursor(IDC_HAND_1);

	m_btnYellowLampOn.SetFont( &m_fntBtn );
	m_btnYellowLampOn.SetFlat( FALSE );
	m_btnYellowLampOn.EnableBallonToolTip();
	m_btnYellowLampOn.SetToolTipText( _T("YellowLamp On") );
	m_btnYellowLampOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnYellowLampOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnYellowLampOff.SetFont( &m_fntBtn );
	m_btnYellowLampOff.SetFlat( FALSE );
	m_btnYellowLampOff.EnableBallonToolTip();
	m_btnYellowLampOff.SetToolTipText( _T("YellowLamp Off") );
	m_btnYellowLampOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnYellowLampOff.SetBtnCursor(IDC_HAND_1);
	
	m_btnRedLampOn.SetFont( &m_fntBtn );
	m_btnRedLampOn.SetFlat( FALSE );
	m_btnRedLampOn.EnableBallonToolTip();
	m_btnRedLampOn.SetToolTipText( _T("RedLamp On") );
	m_btnRedLampOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRedLampOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnRedLampOff.SetFont( &m_fntBtn );
	m_btnRedLampOff.SetFlat( FALSE );
	m_btnRedLampOff.EnableBallonToolTip();
	m_btnRedLampOff.SetToolTipText( _T("RedLamp Off") );
	m_btnRedLampOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnRedLampOff.SetBtnCursor(IDC_HAND_1);

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_COMIZOA)
	{
		m_btnLoadingShutterOpen.ShowWindow(SW_HIDE);
		m_btnLoadingShutterClose.ShowWindow(SW_HIDE);
		m_btnBuzzerOn.ShowWindow(SW_HIDE);
		m_btnBuzzerOff.ShowWindow(SW_HIDE);
		m_btnAirBlowerOn.ShowWindow(SW_HIDE);
		m_btnAirBlowerOff.ShowWindow(SW_HIDE);
//		m_btnBrushMotorOn.ShowWindow(SW_HIDE);
//		m_btnBrushMotorOff.ShowWindow(SW_HIDE);
//		m_btnBrushSolUp.ShowWindow(SW_HIDE);
//		m_btnBrushSolDown.ShowWindow(SW_HIDE);
		m_btnGreenLampOn.ShowWindow(SW_HIDE);
		m_btnGreenLampOff.ShowWindow(SW_HIDE);
		m_btnYellowLampOn.ShowWindow(SW_HIDE);
		m_btnYellowLampOff.ShowWindow(SW_HIDE);
		m_btnRedLampOn.ShowWindow(SW_HIDE);
		m_btnRedLampOff.ShowWindow(SW_HIDE);
	}
	else
	{
		m_btnShutter1Open.ShowWindow(SW_HIDE);
		m_btnShutter1Close.ShowWindow(SW_HIDE);
		m_btnSafeOn.ShowWindow(SW_HIDE);
		m_btnSafeOff.ShowWindow(SW_HIDE);
		m_btnLoaderLoad.ShowWindow(SW_HIDE);
		m_btnUnloaderUnload.ShowWindow(SW_HIDE);

		m_btnTableClamp2.ShowWindow(SW_SHOW);
		m_btnTableClamp2.EnableWindow(TRUE);
		m_btnTableClamp2.SetWindowText("Chuck Clamp");
		m_btnTableClamp2.SetToolTipText(_T("Chuck Clamp"));
		m_btnTableUnclamp2.ShowWindow(SW_SHOW);
		m_btnTableUnclamp2.EnableWindow(TRUE);
		m_btnTableUnclamp2.SetWindowText("Chuck Unclamp");
		m_btnTableUnclamp2.SetToolTipText(_T("Chuck Unclamp"));

		m_btnSuction1On.SetWindowText("TableSuction On");
		m_btnSuction1On.SetToolTipText( _T("TableSuction On") );
		m_btnSuction1Off.SetWindowText("TableSuction Off");
		m_btnSuction1Off.SetToolTipText( _T("TableSuction Off") );
	}

	m_btnResetLoader1.SetFont( &m_fntBtn );
	m_btnResetLoader1.SetFlat( FALSE );
	m_btnResetLoader1.EnableBallonToolTip();
	m_btnResetLoader1.SetToolTipText( _T("�δ��� ���縮��") );
	m_btnResetLoader1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetLoader1.SetBtnCursor(IDC_HAND_1);

	m_btnResetLoader2.SetFont( &m_fntBtn );
	m_btnResetLoader2.SetFlat( FALSE );
	m_btnResetLoader2.EnableBallonToolTip();
	m_btnResetLoader2.SetToolTipText( _T("�δ��� ���縮��") );
	m_btnResetLoader2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetLoader2.SetBtnCursor(IDC_HAND_1);

	m_btnResetLoaderTable.SetFont( &m_fntBtn );
	m_btnResetLoaderTable.SetFlat( FALSE );
	m_btnResetLoaderTable.EnableBallonToolTip();
	m_btnResetLoaderTable.SetToolTipText( _T("�δ����̺� ���縮��") );
	m_btnResetLoaderTable.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetLoaderTable.SetBtnCursor(IDC_HAND_1);

	m_btnResetUnLoader1.SetFont( &m_fntBtn );
	m_btnResetUnLoader1.SetFlat( FALSE );
	m_btnResetUnLoader1.EnableBallonToolTip();
	m_btnResetUnLoader1.SetToolTipText( _T("��δ��� ���縮��") );
	m_btnResetUnLoader1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetUnLoader1.SetBtnCursor(IDC_HAND_1);
	
	m_btnResetUnLoader2.SetFont( &m_fntBtn );
	m_btnResetUnLoader2.SetFlat( FALSE );
	m_btnResetUnLoader2.EnableBallonToolTip();
	m_btnResetUnLoader2.SetToolTipText( _T("��δ��� ���縮��") );
	m_btnResetUnLoader2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetUnLoader2.SetBtnCursor(IDC_HAND_1);
	
	m_btnResetUnLoaderTable.SetFont( &m_fntBtn );
	m_btnResetUnLoaderTable.SetFlat( FALSE );
	m_btnResetUnLoaderTable.EnableBallonToolTip();
	m_btnResetUnLoaderTable.SetToolTipText( _T("��δ� ���̺� ���縮��") );
	m_btnResetUnLoaderTable.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetUnLoaderTable.SetBtnCursor(IDC_HAND_1);

	m_btnResetTable1.SetFont( &m_fntBtn );
	m_btnResetTable1.SetFlat( FALSE );
	m_btnResetTable1.EnableBallonToolTip();
	m_btnResetTable1.SetToolTipText( _T("���̺�1 ���縮��") );
	m_btnResetTable1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetTable1.SetBtnCursor(IDC_HAND_1);

	m_btnResetTable2.SetFont( &m_fntBtn );
	m_btnResetTable2.SetFlat( FALSE );
	m_btnResetTable2.EnableBallonToolTip();
	m_btnResetTable2.SetToolTipText( _T("���̺�2 ���縮��") );
	m_btnResetTable2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnResetTable2.SetBtnCursor(IDC_HAND_1);

	m_btnTable1DefaultOn.SetFont( &m_fntBtn );
	m_btnTable1DefaultOn.SetFlat( FALSE );
	m_btnTable1DefaultOn.EnableBallonToolTip();
	m_btnTable1DefaultOn.SetToolTipText( _T("���̺�1 �⺻���� �ѱ�") );
	m_btnTable1DefaultOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTable1DefaultOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnTable1DefaultOff.SetFont( &m_fntBtn );
	m_btnTable1DefaultOff.SetFlat( FALSE );
	m_btnTable1DefaultOff.EnableBallonToolTip();
	m_btnTable1DefaultOff.SetToolTipText( _T("���̺�1 �⺻���� ����") );
	m_btnTable1DefaultOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTable1DefaultOff.SetBtnCursor(IDC_HAND_1);

	m_btnTable2DefaultOn.SetFont( &m_fntBtn );
	m_btnTable2DefaultOn.SetFlat( FALSE );
	m_btnTable2DefaultOn.EnableBallonToolTip();
	m_btnTable2DefaultOn.SetToolTipText( _T("���̺�2 �⺻���� �ѱ�") );
	m_btnTable2DefaultOn.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTable2DefaultOn.SetBtnCursor(IDC_HAND_1);
	
	m_btnTable2DefaultOff.SetFont( &m_fntBtn );
	m_btnTable2DefaultOff.SetFlat( FALSE );
	m_btnTable2DefaultOff.EnableBallonToolTip();
	m_btnTable2DefaultOff.SetToolTipText( _T("���̺�2 �⺻���� ����") );
	m_btnTable2DefaultOff.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnTable2DefaultOff.SetBtnCursor(IDC_HAND_1);


	m_btnHoodShutterOpen.SetFont( &m_fntBtn );
	m_btnHoodShutterOpen.SetFlat( FALSE );
	m_btnHoodShutterOpen.EnableBallonToolTip();
	m_btnHoodShutterOpen.SetToolTipText( _T("Hood Shutter Open. Dust suction On.") );
	m_btnHoodShutterOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHoodShutterOpen.SetBtnCursor(IDC_HAND_1);

	m_btnHoodShutterClose.SetFont( &m_fntBtn );
	m_btnHoodShutterClose.SetFlat( FALSE );
	m_btnHoodShutterClose.EnableBallonToolTip();
	m_btnHoodShutterClose.SetToolTipText( _T("Hood Shutter Close. Dust suction Off.") );
	m_btnHoodShutterClose.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnHoodShutterClose.SetBtnCursor(IDC_HAND_1);

	m_btnBeamPassUp1.SetFont( &m_fntBtn );
	m_btnBeamPassUp1.SetFlat( FALSE );
	m_btnBeamPassUp1.EnableBallonToolTip();
	m_btnBeamPassUp1.SetToolTipText( _T("Laser Beam Path Master Up") );
	m_btnBeamPassUp1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBeamPassUp1.SetBtnCursor(IDC_HAND_1);

	m_btnBeamPassDown1.SetFont( &m_fntBtn );
	m_btnBeamPassDown1.SetFlat( FALSE );
	m_btnBeamPassDown1.EnableBallonToolTip();
	m_btnBeamPassDown1.SetToolTipText( _T("Laser Beam Path Master Down") );
	m_btnBeamPassDown1.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBeamPassDown1.SetBtnCursor(IDC_HAND_1);

	m_btnBeamPassUp2.SetFont( &m_fntBtn );
	m_btnBeamPassUp2.SetFlat( FALSE );
	m_btnBeamPassUp2.EnableBallonToolTip();
	m_btnBeamPassUp2.SetToolTipText( _T("Laser Beam Path Slave Up") );
	m_btnBeamPassUp2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBeamPassUp2.SetBtnCursor(IDC_HAND_1);

	m_btnBeamPassDown2.SetFont( &m_fntBtn );
	m_btnBeamPassDown2.SetFlat( FALSE );
	m_btnBeamPassDown2.EnableBallonToolTip();
	m_btnBeamPassDown2.SetToolTipText( _T("Laser Beam Path Slave Down") );
	m_btnBeamPassDown2.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnBeamPassDown2.SetBtnCursor(IDC_HAND_1);
}

void CPaneManualControlIOMonitorOutputSub1Osan::UpdateStatus()
{
	if(m_lStatus1 != m_lStatus1Old)
	{
		m_lStatus1Old = m_lStatus1;

		if(m_lStatus1 & 0x0002)
		{
			m_btnHeightSensorUp2.SetSelection( 0);
			m_btnHeightSensorDown2.SetSelection( 1 );
		}
		else
		{
			m_btnHeightSensorUp2.SetSelection( 1 );
			m_btnHeightSensorDown2.SetSelection( 0 );
		}
		if(m_lStatus1 & 0x0008)
		{
			m_btnSafeOn.SetSelection( 1 );
			m_btnSafeOff.SetSelection( 0 );
		}
		else
		{
			m_btnSafeOn.SetSelection( 0 );
			m_btnSafeOff.SetSelection( 1 );
		}

		if(m_lStatus1 & 0x0010)
		{
			m_btnDoorByPassOn.SetSelection( 1 );
			m_btnDoorByPassOff.SetSelection( 0 );
		}
		else
		{
			m_btnDoorByPassOn.SetSelection( 0 );
			m_btnDoorByPassOff.SetSelection( 1 );
		}
/*
		if(m_lStatus1 & 0x0020)
		{
			m_btnSuction1On.SetSelection( 1 );
			m_btnSuction1Off.SetSelection( 0 );
		}
		else
		{
			m_btnSuction1On.SetSelection( 0 );
			m_btnSuction1Off.SetSelection( 1 );
		}

		if(m_lStatus1 & 0x0040)
		{
			m_btnSuction2On.SetSelection( 1 );
			m_btnSuction2Off.SetSelection( 0 );
		}
		else
		{
			m_btnSuction2On.SetSelection( 0 );
			m_btnSuction2Off.SetSelection( 1 );
		}
*/
		if(m_lStatus1 & 0x0400)
			m_btnInitX.SetSelection( 1 );
		else
			m_btnInitX.SetSelection( 0 );

		if(m_lStatus1 & 0x4000)
			m_btnInitY.SetSelection( 1 );
		else
			m_btnInitY.SetSelection( 0 );
		
		//2011526
		if(m_lStatus1 & 0x10000)
			m_btnInitA1.SetSelection( 1 );
		else
			m_btnInitA1.SetSelection( 0 );

		if(m_lStatus1 & 0x40000)
			m_btnInitA2.SetSelection( 1 );
		else
			m_btnInitA2.SetSelection( 0 );
	}

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_COMIZOA)
	{
		if(m_lStatus2 != m_lStatus2Old)
		{
			m_lStatus2Old = m_lStatus2;

			if(m_lStatus2 & 0x0004)
				m_btnInitZ1.SetSelection( 1 );
			else
				m_btnInitZ1.SetSelection( 0 );

			if(m_lStatus2 & 0x0040)
				m_btnInitZ2.SetSelection( 1 );
			else
				m_btnInitZ2.SetSelection( 0 );

			if(m_lStatus2 & 0x0400)
				m_btnInitM.SetSelection( 1 );
			else
				m_btnInitM.SetSelection( 0 );

			if(m_lStatus2 & 0x4000)
				m_btnInitC.SetSelection( 1 );
			else
				m_btnInitC.SetSelection( 0 );
			

		}
			
		if(m_lStatus3 != m_lStatus3old)
		{
			m_lStatus3old = m_lStatus3;

			if(m_lStatus3 & 0x10000)
				m_btnShutter1Close.SetSelection( 1 );
			else
				m_btnShutter1Close.SetSelection( 0 );

			if(m_lStatus3 & 0x20000)
				m_btnShutter1Open.SetSelection( 1 );
			else
				m_btnShutter1Open.SetSelection( 0 );

			if(m_lStatus3 & 0x0010)
				m_btnShutter2Close.SetSelection( 1 );
			else
				m_btnShutter2Close.SetSelection( 0 );

			if(m_lStatus3 & 0x0020)
				m_btnShutter2Open.SetSelection( 1 );
			else
				m_btnShutter2Open.SetSelection( 0 );
			

			if(m_lStatus3 & 0x0040)
				m_btnHeightSensorUp.SetSelection( 1 );
			else
				m_btnHeightSensorUp.SetSelection( 0 );

			if(m_lStatus3 & 0x0080)
				m_btnHeightSensorDown.SetSelection( 1 );
			else
				m_btnHeightSensorDown.SetSelection( 0 );

			if(m_lStatus3 & 0x0100)
				m_btnPowermeterOpen.SetSelection( 1 );
			else
				m_btnPowermeterOpen.SetSelection( 0 );

			if(m_lStatus3 & 0x0200)
				m_btnPowermeterClose.SetSelection( 1 );
			else
				m_btnPowermeterClose.SetSelection( 0 );

			if(m_lStatus2 & 0x0400)
				m_btnInitC2.SetSelection( 1 );
			else
				m_btnInitC2.SetSelection( 0 );



//			if(m_lStatus3 & 0x0400)
//			{
//				m_btnVacuumMotorOn.SetSelection( 1 );
//				m_btnVacuumMotorOff.SetSelection( 0 );
//			}
//			else
//			{
//				m_btnVacuumMotorOn.SetSelection( 0 );
//				m_btnVacuumMotorOff.SetSelection( 1 );
//			}

//			if(m_lStatus3 & 0x0800)
//			{
//				m_btnVacuumMotor2On.SetSelection( 1 );
//				m_btnVacuumMotor2Off.SetSelection( 0 );
//			}
//			else
//			{
//				m_btnVacuumMotor2On.SetSelection( 0 );
//				m_btnVacuumMotor2Off.SetSelection( 1 );
//			}			

/*
			if(gSystemINI.m_sHardWare.nTableClamp > 0)
			{
				if(m_lStatus3 & 0x0800)
					m_btnTableClamp.SetSelection( 1 );
				else
					m_btnTableClamp.SetSelection( 0 );

				if(m_lStatus3 & 0x1000)
					m_btnTableUnclamp.SetSelection( 1 );
				else
					m_btnTableUnclamp.SetSelection( 0 );
			}

			if(gSystemINI.m_sHardWare.nTableClamp > 1)
			{
				if(m_lStatus3 & 0x2000)
					m_btnTableClamp2.SetSelection( 1 );
				else
					m_btnTableClamp2.SetSelection( 0 );

				if(m_lStatus3 & 0x4000)
					m_btnTableUnclamp2.SetSelection( 1 );
				else
					m_btnTableUnclamp2.SetSelection( 0 );
			}
*/
		}
		if(m_lStatus4 != m_lStatus4old)
		{

			
			m_lStatus4old = m_lStatus4;
			if(m_lStatus4 & 0x0001)
			{
				m_btnBeamPassUp1.SetSelection( 1 );
				m_btnBeamPassDown1.SetSelection( 0 );
			}
			else
			{
				m_btnBeamPassUp1.SetSelection( 0 );
				m_btnBeamPassDown1.SetSelection( 1 );
			}
			if(m_lStatus4 & 0x0010)
			{
				m_btnBeamPassUp2.SetSelection( 1 );
				m_btnBeamPassDown2.SetSelection( 0 );
			}
			else
			{
				m_btnBeamPassUp2.SetSelection( 1 );
				m_btnBeamPassDown2.SetSelection( 0 );
			}
//			if(m_lStatus4 & 0x0004)
//				m_btnBrushMotorOff.SetSelection( 1 );
//			else
//				m_btnBrushMotorOff.SetSelection( 0 );

//			if(m_lStatus4 & 0x0004)
//				m_btnBrushMotorOn.SetSelection( 1 );
//			else
//				m_btnBrushMotorOn.SetSelection( 0 );
//			if(m_lStatus4 & 0x0008)
//				m_btnBrushMotorOff.SetSelection( 1 );
//			else
//				m_btnBrushMotorOff.SetSelection( 0 );

// 			if(m_lStatus4 & 0x0010)
// 				m_btnBrushSolUp.SetSelection( 1 );
// 			else
// 				m_btnBrushSolUp.SetSelection( 0 );
// 			if(m_lStatus4 & 0x0020)
// 				m_btnBrushSolDown.SetSelection( 1 );
// 			else
// 				m_btnBrushSolDown.SetSelection( 0 );


#ifdef __SERVO_MOTOR__
			BOOL bTemp = Servo_IsOrigin(0);
			if(bTemp)
				m_btnInitM2.SetSelection( 1 );
			else
				m_btnInitM2.SetSelection( 0 );

			bTemp = Servo_IsOrigin(1);
			if(bTemp)
				m_btnInitM3.SetSelection( 1 );
			else
				m_btnInitM3.SetSelection( 0 );

#endif
			if(gSystemINI.m_sHardWare.nTableClamp > 0)
			{
				if(m_lStatus4 & 0x0040)
					m_btnTableClamp.SetSelection( 0 );
				else
					m_btnTableClamp.SetSelection( 1 );
				
				if(m_lStatus4 & 0x0080)
					m_btnTableUnclamp.SetSelection( 0 );
				else
					m_btnTableUnclamp.SetSelection( 1 );
			}
			
			if(gSystemINI.m_sHardWare.nTableClamp > 1)
			{
				if(m_lStatus4 & 0x0100)
					m_btnTableClamp2.SetSelection( 0 );
				else
					m_btnTableClamp2.SetSelection( 1 );
				
				if(m_lStatus4 & 0x0200)
					m_btnTableUnclamp2.SetSelection( 0 );
				else
					m_btnTableUnclamp2.SetSelection( 1 );
			}

			if(m_lStatus4 & 0x0400)
				m_btnInitLC.SetSelection( 1 );
			else
				m_btnInitLC.SetSelection( 0 );

			if(m_lStatus4 & 0x0800)
				m_btnInitUC.SetSelection( 1 );
			else
				m_btnInitUC.SetSelection( 0 );

			if(m_lStatus4 & 0x1000)
			{	
				m_btnBrushMotorOn.SetSelection( 1 );
				m_btnBrushMotorOff.SetSelection( 0 );
			}
			else
			{
				m_btnBrushMotorOn.SetSelection( 0 );
				m_btnBrushMotorOff.SetSelection( 1 );
			}
// 				if(m_lStatus4 & 0x1000)
// 				m_btnLoadElvOriPos.SetSelection( 1 );
// 			else
// 				m_btnLoadElvOriPos.SetSelection( 0 );
// 
// 			if(m_lStatus4 & 0x2000)
// 				m_btnUnloadElvOriPos.SetSelection( 1 );
// 			else
// 				m_btnUnloadElvOriPos.SetSelection( 0 );
		}

		if(m_lStatus5 != m_lStatus5old)
		{
			m_lStatus5old = m_lStatus5;

			if((m_lStatus5 & 0x200000) && (m_lStatus5 & 0x800000))
				m_btnHoodShutterOpen.SetSelection( 1 );
			else
				m_btnHoodShutterOpen.SetSelection( 0 );
			
			if((m_lStatus5 & 0x100000) && (m_lStatus5 & 0x400000))
				m_btnHoodShutterClose.SetSelection( 1 );
			else
				m_btnHoodShutterClose.SetSelection( 0 );

		}

	}

	BOOL b1st = TRUE, b2nd = TRUE;
	
	m_nSuction1 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x01;
	m_nSuction2 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x02;
	if(m_nSuction1 != m_nSuction1Old)
	{
		m_nSuction1Old = m_nSuction1;
		if(m_nSuction1)
		{
			m_btnSuction1On.SetSelection(1);
			m_btnSuction1Off.SetSelection(0);
		}
		else
		{
			m_btnSuction1On.SetSelection(0);
			m_btnSuction1Off.SetSelection(1);
		}
	}
	if(m_nSuction2 != m_nSuction2Old)
	{
		m_nSuction2Old = m_nSuction2;
		if(m_nSuction2)
		{
			m_btnSuction2On.SetSelection(1);
			m_btnSuction2Off.SetSelection(0);
		}
		else
		{
			m_btnSuction2On.SetSelection(0);
			m_btnSuction2Off.SetSelection(1);
		}
	}

	BOOL bMotor = gDeviceFactory.GetMotor()->GetCurrentSuctionMotor();
	if(bMotor)
	{
		m_btnVacuumMotorOn.SetSelection( 1 );
		m_btnVacuumMotorOff.SetSelection( 0 );
	}
	else
	{
		m_btnVacuumMotorOn.SetSelection( 0 );
		m_btnVacuumMotorOff.SetSelection( 1 );
	}

	if(m_bLamp != m_bLampOld)
	{
		m_bLampOld = m_bLamp;

		if(m_bLamp)
		{
			m_btnLampOn.SetSelection( 1 );
			m_btnLampOff.SetSelection( 0 );
		}
		else
		{
			m_btnLampOn.SetSelection( 0 );
			m_btnLampOff.SetSelection( 1 );
		}
	}

	
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		if(m_bChuck != m_bChuckOld)
		{
			m_bChuckOld = m_bChuck;

			if(m_bChuck)
			{
				m_btnTableClamp2.SetSelection( 1 );
				m_btnTableUnclamp2.SetSelection( 0 );
			}
			else
			{
				m_btnTableClamp2.SetSelection( 0 );
				m_btnTableUnclamp2.SetSelection( 1 );
			}
		}

		if(m_bLoadingShutter != m_bLoadingShutterOld)
		{
			m_bLoadingShutterOld = m_bLoadingShutter;

			if(m_bLoadingShutter)
			{
				m_btnLoadingShutterOpen.SetSelection( 1 );
				m_btnLoadingShutterClose.SetSelection( 0 );
			}
			else
			{
				m_btnLoadingShutterOpen.SetSelection( 0 );
				m_btnLoadingShutterClose.SetSelection( 1 );
			}
		}

		if(m_bBrushSol != m_bBrushSolOld)
		{
			m_bBrushSolOld = m_bBrushSol;

			if(m_bBrushSol)
			{
				m_btnBrushSolUp.SetSelection( 1 );
				m_btnBrushSolDown.SetSelection( 0 );
			}
			else
			{
				m_btnBrushSolUp.SetSelection( 0 );
				m_btnBrushSolDown.SetSelection( 1 );
			}
		}
	}

	// Loader1 Status
	if(m_pMotor->IsLoaderPicker1PCBExist())
		m_bStatusLoader1 = TRUE;
	else
		m_bStatusLoader1 = FALSE;
	
	m_btnResetLoader1.SetSelection(m_bStatusLoader1);
	
	// Loader2 Status
	if(m_pMotor->IsLoaderPicker2PCBExist())
		m_bStatusLoader2 = TRUE;
	else
		m_bStatusLoader2 = FALSE;
	
	m_btnResetLoader2.SetSelection(m_bStatusLoader2);
	
	// Unloader1 Status
	if(m_pMotor->IsUnloaderPicker1PCBExist())
		m_bStatusUnloader1 = TRUE;
	else
		m_bStatusUnloader1 = FALSE;
	
	m_btnResetUnLoader1.SetSelection(m_bStatusUnloader1);
	
	// Unloader2 Status
	if(m_pMotor->IsUnloaderPicker2PCBExist())
		m_bStatusUnloader2 = TRUE;
	else
		m_bStatusUnloader2 = FALSE;
	
	m_btnResetUnLoader2.SetSelection(m_bStatusUnloader2);
	
	// Table1 Status
	if(m_pMotor->IsTable1PCBExist())
		m_bStatusTable1 = TRUE;
	else
		m_bStatusTable1 = FALSE;
	
	m_btnResetTable1.SetSelection(m_bStatusTable1);
	
	// Table2 Status
	if(m_pMotor->IsTable2PCBExist())
		m_bStatusTable2 = TRUE;
	else
		m_bStatusTable2 = FALSE;
	
	m_btnResetTable2.SetSelection(m_bStatusTable2);
	
	// Loader Aligner Status
#ifndef __ADD_MELSEC_MOTOR__
	if(m_pMotor->IsAlignerPCBExist())
		m_bStatusAligner = TRUE;
	else
		m_bStatusAligner = FALSE;
	
	m_btnResetLoaderTable.SetSelection(m_bStatusAligner);
	
	// Unloader Aligner Status
	if(m_pMotor->IsULAlignerPCBExist())
		m_bStatusAligner2 = TRUE;
	else
		m_bStatusAligner2 = FALSE;

	m_btnResetUnLoaderTable.SetSelection(m_bStatusAligner2);

	if(m_pMotor->IsLCinCartPos())
		m_btnLoadCarrCartPos.SetSelection( 1 );
	else
		m_btnLoadCarrCartPos.SetSelection( 0 );

	if(m_pMotor->IsLCinLoadPos())
		m_btnLoadCarrTablePos.SetSelection( 1 );
	else
		m_btnLoadCarrTablePos.SetSelection( 0 );

	if(m_pMotor->IsUCinCartPos())
		m_btnUnloadCarrCartPos.SetSelection( 1 );
	else
		m_btnUnloadCarrCartPos.SetSelection( 0 );
	
	if(m_pMotor->IsUCinUnloadPos())
		m_btnUnloadCarrTablePos.SetSelection( 1 );
	else
		m_btnUnloadCarrTablePos.SetSelection( 0 );
#endif
	
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	m_lStatus1 = m_pMotor->GetCurrentError(STATUS_IO1);
//	m_nSuction = m_pMotor->GetCurrentSuction();
//	m_nVacuumType = m_pMotor->GetTableVacuumType();
	m_nSuction1 = m_pMotor->GetCurrentSuction() & 0x01;
	m_nSuction2 = m_pMotor->GetCurrentSuction() & 0x02;
	m_bMotor = FALSE; //m_pMotor->GetCurrentVacuumMotor(TRUE);
	m_bMotor2 = FALSE; //m_pMotor->GetCurrentVacuumMotor(FALSE);
	
	m_bAcrMotorOn = m_pMotor->GetCurrentAcrylSuction(TRUE);
	m_btnVacuumMotor2On.SetSelection(m_bAcrMotorOn);
	m_btnVacuumMotor2Off.SetSelection(!m_bAcrMotorOn);
	
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_bChuck = m_pMotor->GetChuckStatus(TRUE);
		m_bLoadingShutter = m_pMotor->GetLoadingShutterStatus(TRUE);
		m_bBrushSol = m_pMotor->GetBrushStatus(TRUE);
	}
	else
	{
		m_lStatus2 = m_pMotor->GetCurrentError(STATUS_IO2);
		m_lStatus3 = m_pMotor->GetCurrentError(STATUS_IO3);
		m_lStatus4 = m_pMotor->GetCurrentError(STATUS_IO4);
		m_lStatus5 = m_pMotor->GetCurrentError(STATUS_IO5);//2011518
		m_bLamp = m_pMotor->IsFluorescentLampOn();
	}
	
	UpdateStatus();

	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlIOMonitorOutputSub1Osan::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_pMotor = gDeviceFactory.GetMotor();
//		m_RadioVacuumTable = m_pMotor->GetTableVacuumType(); // ó�� �ѹ� �� ����
		UpdateData(FALSE);
		m_nTimerID = SetTimer(9981, 1000, NULL);
	}
//	SetTimer(9981, 1000, NULL);
}

void CPaneManualControlIOMonitorOutputSub1Osan::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
		
		m_lStatus1 = m_lStatus1Old = 0;
		m_lStatus2 = m_lStatus2Old = 0;
		m_lStatus3 = m_lStatus3old = 0;
		m_lStatus4 = m_lStatus4old = 0;
		m_lStatus5 = m_lStatus5old = 0;		//2011518

		m_nSuction = m_nSuctionOld = 0;
		m_bMotor = m_bMotorOld = FALSE;
		m_bMotor2 = m_bMotor2Old = FALSE;
		m_bLamp = m_bLampOld = FALSE;
		m_bChuck = m_bChuckOld = FALSE;
		m_bLoadingShutter = m_bLoadingShutterOld = FALSE;
		m_bBrushSol = m_bBrushSolOld = FALSE;
	}
//	KillTimer(9981);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLampOn() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->WriteOutputIOBIt(1, 6, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLampOff() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->WriteOutputIOBIt(1, 6, FALSE);
}

//2011526	// aom power on �ñ׳� �ֱ� 
void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputAOMPowerOn()
{
	if(m_pMotor->WriteOutputIOBIt(9,12,TRUE) )
	{
		m_pMotor->SetAOMPowerON(TRUE);	
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputSafetyModeOn() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_MODE_SELECT, 4);
	
	// NORMAL_MODE, SAFETY_MODE, IDLE_MODE
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_MODE_CHANGE, SAFETY_MODE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputSafetyModeOff() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_MODE_SELECT, 1);

	// NORMAL_MODE, SAFETY_MODE, IDLE_MODE
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_MODE_CHANGE, NORMAL_MODE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputInitializeX() 
{
	// TODO: Add your control notification handler code here
	
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);
 	
	m_pMotor->SetOrigin(AXIS_X);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputInitializeY() 
{
	// TODO: Add your control notification handler code here

	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);

	m_pMotor->SetOrigin(AXIS_Y);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputInitializeZ1() 
{
	// TODO: Add your control notification handler code here

	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);

	m_pMotor->SetOrigin(AXIS_Z1);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputInitializeZ2() 
{
	// TODO: Add your control notification handler code here

	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

// 	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);

	m_pMotor->SetOrigin(AXIS_Z2);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputInitializeM() 
{
	// TODO: Add your control notification handler code here

	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return ;
	}
// 	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);

	m_pMotor->SetOrigin(AXIS_M);
}
void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputInitializeM2() 
{
	// TODO: Add your control notification handler code here

	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

// 	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);
	
	m_pMotor->SetOrigin(AXIS_M2);
}


void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputInitializeC() 
{
	// TODO: Add your control notification handler code here

	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}

	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return ;
	}
// 	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);
	
	m_pMotor->SetOrigin(AXIS_C);
}
void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputInitializeC2()
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		ErrMsgDlg(STDGNALM781);
		return ;
	}
// 	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);
	
	m_pMotor->SetOrigin(AXIS_C2);
}
void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputInitializeLC() 
{
	// TODO: Add your control notification handler code here

	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);
	
	m_pMotor->SetOrigin(AXIS_L_CARRIER);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputInitializeUC() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}

	// 110620 Scal�� Power�� ���� �ð� ����
// 	gProcessINI.m_sProcessCal.nStartScalTime = 0;
// 	gProcessINI.m_sProcessCal.nStartPowerTime = 0;
// 	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);
	
	m_pMotor->SetOrigin(AXIS_UL_CARRIER);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputPowermeterOpen() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_POWER_METER, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputPowermeterClose() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_POWER_METER, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputHeightSensorUp() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_HEIGHT_SENSOR, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputHeightSensorDown() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_HEIGHT_SENSOR, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputHeightSensorUp2() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputHeightSensorDown2() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_HEIGHT_SENSOR_2, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLasershutter1Open() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_SHUTTER_MASTER, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLasershutter1Close() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_SHUTTER_MASTER, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLasershutter2Open() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_SHUTTER_SLAVE, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLasershutter2Close() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_SHUTTER_SLAVE, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputTablesuction1On() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
// 	m_pMotor->WriteOutputIOBIt(2, 1, FALSE);
// 	m_pMotor->WriteOutputIOBIt(2, 0, TRUE);

	//2011519
//	m_pMotor->SetOutportTableVacuum(m_RadioVacuumTable, TRUE);
//	m_pMotor->WriteOutputIOBIt(2, 0, TRUE);
//	m_pMotor->WriteOutputIOBIt(2, 1, FALSE);
	m_pMotor->SetOutPort(PORT_TABLE_SUCTION1, TRUE);

}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputTablesuction1Off() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

//	m_pMotor->SetOutportTableVacuum(TABLE_ALL, FALSE);
//	m_pMotor->WriteOutputIOBIt(2, 0, FALSE);
//	m_pMotor->WriteOutputIOBIt(2, 1, TRUE);
	m_pMotor->SetOutPort(PORT_TABLE_SUCTION1, FALSE);	
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputTablesuction2On() 
{	
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
//	m_pMotor->SetOutportTableVacuum(m_RadioVacuumTable, TRUE);
//	m_pMotor->WriteOutputIOBIt(2, 2, TRUE);
//	m_pMotor->WriteOutputIOBIt(2, 3, FALSE);
	m_pMotor->SetOutPort(PORT_TABLE_SUCTION2, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputTablesuction2Off() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
//	m_pMotor->SetOutportTableVacuum(TABLE_ALL, FALSE);
//	m_pMotor->WriteOutputIOBIt(2, 2, FALSE);
//	m_pMotor->WriteOutputIOBIt(2, 3, TRUE);
	m_pMotor->SetOutPort(PORT_TABLE_SUCTION2, FALSE);		
//	ClearRadioTableVacuum();

}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputVacuumMotorOn() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->Table1VacuumMotor(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputVacuumMotorOff() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->Table1VacuumMotor(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputVacuumMotor2On() 
{
	m_pMotor->SetOutPort(PORT_ACRYL_TABLE_SUCTION, TRUE);
//	m_bAcrMotorOn = TRUE;
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pMotor->SetCurrentAcrSuction(m_bAcrMotorOn);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputVacuumMotor2Off() 
{
	m_pMotor->SetOutPort(PORT_ACRYL_TABLE_SUCTION, FALSE);
//	m_bAcrMotorOn = FALSE;
//	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pMotor->SetCurrentAcrSuction(m_bAcrMotorOn);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLoaderAlign() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	if(m_pMotor->IsHandlerOperation( HANDLER_LOADER_ALIGN, FALSE, FALSE ))
	{
		ErrMessage(_T("���� Align �������Դϴ�.\r\nAlign Command Reject."));
		return;
	}

	if(m_pMotor->IsLoadCartNoPCB())
	{
		ErrMessage(_T("���� �δ��ο� ���簡 �����ϴ�.\r\nAlign Command Reject."));
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->HandlerOperation(HANDLER_LOADER_ALIGN);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLoaderLoad() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	if(!m_pMotor->IsHandlerOperation( HANDLER_LOADER_ALIGN, TRUE, FALSE ))
	{
		ErrMessage(_T("Align �Ϸ� ���°� �ƴմϴ�.\r\nLoad Command Reject."));
		return;
	}
	
	if(m_pMotor->IsHandlerOperation( HANDLER_LOADER_LOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("���� Load �������Դϴ�.\r\nLoad Command Reject."));
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->HandlerOperation(HANDLER_LOADER_LOAD);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLoaderElvLoadPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->LoaderElvLoadPos();
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLoaderElvOriPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->LoaderElvOriginPos();
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLoaderCarrCartPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->LoaderCarrierAlignPos();	
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLoaderCarrTablePos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->LoaderCarrierLoadPos();
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputUnloaderUnload() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	if(m_pMotor->IsHandlerOperation( HANDLER_LOADER_LOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("It is loading \r\nUnload Command Reject."));
		return;
	}
	
	if(m_pMotor->IsHandlerOperation( HANDLER_UNLOADER_UNLOAD, FALSE, FALSE ))
	{
		ErrMessage(_T("It is Unloading \r\nUnload Command Reject."));
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputUnloaderElvLoadPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderElvUnloadPos();
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputUnloaderElvOriPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderElvOriginPos();
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputUnloaderCarrCartPos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderCarrierUnloadPos();
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputUnloaderCarrTablePos() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->UnloaderCarrierTablePos();
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputTableClamp() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->TableClamp(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputTableUnclamp() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->TableClamp(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputTableClamp2() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}

	// TODO: Add your control notification handler code here
	m_pMotor->TableClamp(TRUE, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputTableUnclamp2() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	// TODO: Add your control notification handler code here
	m_pMotor->TableClamp(FALSE, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonDoorByPassOn() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_SYSTEM_DOOR_BYPASS, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonDoorByPassOff() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_SYSTEM_DOOR_BYPASS, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::EnableButton(BOOL bUse)
{
	GetDlgItem(IDC_BUTTON_OUTPUT_ROLL_USE_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_ROLL_USE_OFF)->EnableWindow(bUse);	
	GetDlgItem(IDC_BUTTON_OUTPUT_LASER_HEAD_PURGE_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LASER_HEAD_PURGE_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LAMP_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LAMP_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_SAFETY_MODE_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_SAFETY_MODE_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_X)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_Y)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_Z1)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_Z2)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_M)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_M2)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_C)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_C2)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_LC)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_INITIALIZE_UC)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_POWERMETER_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_POWERMETER_CLOSE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_UP)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_HEIGHT_SENSOR_DOWN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LASERSHUTTER1_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LASERSHUTTER1_CLOSE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LASERSHUTTER2_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LASERSHUTTER2_CLOSE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_TABLESUCTION1_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_TABLESUCTION1_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_TABLESUCTION2_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_TABLESUCTION2_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_VACUUM_MOTOR_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_VACUUM_MOTOR_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_VACUUM_MOTOR2_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_VACUUM_MOTOR2_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_ALIGN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_LOAD)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_ELV_LOAD_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_ELV_ORI_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_CARR_CART_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADER_CARR_TABLE_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_UNLOAD)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_ELV_LOAD_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_ELV_ORI_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_CARR_CART_POS)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_UNLOADER_CARR_TABLE_POS)->EnableWindow(bUse);
//	GetDlgItem(IDC_BUTTON_DOOR_BY_PASS_ON)->EnableWindow(bUse);
//	GetDlgItem(IDC_BUTTON_DOOR_BY_PASS_OFF)->EnableWindow(bUse);

	GetDlgItem(IDC_BUTTON_OUTPUT_LOADING_SHUTTER_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_LOADING_SHUTTER_CLOSE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BUZZER_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BUZZER_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_AIR_BLOWER_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_AIR_BLOWER_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BRUSH_MOTOR_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BRUSH_MOTOR_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BRUSH_SOL_UP)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_BRUSH_SOL_DOWN)->EnableWindow(bUse);

	GetDlgItem(IDC_BUTTON_OUTPUT_GREEN_LAMP_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_GREEN_LAMP_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_YELLOW_LAMP_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_YELLOW_LAMP_OFF)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RED_LAMP_ON)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RED_LAMP_OFF)->EnableWindow(bUse);

	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_LOADER1)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_LOADER2)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_LOADER_TABLE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_UNLOADER1)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_UNLOADER2)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_UNLOADER_TABLE)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_TABLE1)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_RESET_TABLE2)->EnableWindow(bUse);
	
	GetDlgItem(IDC_BUTTON_OUTPUT_HOOD_SHUTTER_OPEN)->EnableWindow(bUse);
	GetDlgItem(IDC_BUTTON_OUTPUT_HOOD_SHUTTER_CLOSE)->EnableWindow(bUse);

	//2011526
	GetDlgItem(IDC_BUTTON_OUTPUT_AOMPOWER_ON)->EnableWindow(bUse);

	if(gSystemINI.m_sHardWare.nTableClamp > 0)
	{
		GetDlgItem(IDC_BUTTON_OUTPUT_TABLE_CLAMP)->EnableWindow(bUse);
		GetDlgItem(IDC_BUTTON_OUTPUT_TABLE_UNCLAMP)->EnableWindow(bUse);
	}
	if(gSystemINI.m_sHardWare.nTableClamp > 1 ||
		gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		GetDlgItem(IDC_BUTTON_OUTPUT_TABLE_CLAMP2)->EnableWindow(bUse);
		GetDlgItem(IDC_BUTTON_OUTPUT_TABLE_UNCLAMP2)->EnableWindow(bUse);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::SetAuthorityByLevel(int nLevel)
{
	// 100209 operator�� ��� ����Ҽ� �ְ�
//	EnableButton(TRUE);
	return;

	switch(nLevel)
	{
	case 0: // Operator
//		EnableButton(FALSE);
		break;
	case 1: // Engineer
	case 2: // EO Engineer
	case 3: //Super Engineer
//		EnableButton(TRUE);
		break;
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLoadingShutterOpen()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(SHUTTER_OPEN_CLOSE_SOL, TRUE);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLoadingShutterClose()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(SHUTTER_OPEN_CLOSE_SOL, FALSE);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputBuzzerOn()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(BUZZER, TRUE);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputBuzzerOff()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(BUZZER, FALSE);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputAirBlowerOn()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(AIR_BLOWER, TRUE);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputAirBlowerOff()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(AIR_BLOWER, FALSE);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputBrushMotorOn()
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
//	m_pMotor->WriteOutputIOBIt(9, 0, TRUE);
//	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
//	{
		m_pMotor->SetOutPort(PORT_LASER_PASS_TOP, TRUE);
		//m_pMotor->WriteOutPort(PORT_LASER_PASS, TRUE);
//	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputBrushMotorOff()
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
//	m_pMotor->WriteOutputIOBIt(9, 1, TRUE);
//	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
//	{
		m_pMotor->SetOutPort(PORT_LASER_PASS_TOP, FALSE);
//		m_pMotor->WriteOutPort(PORT_LASER_PASS, FALSE);
//	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputBrushSolUp()
{
	m_pMotor->WriteOutputIOBIt(9, 2, TRUE);
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(BRUSH_SOL, TRUE);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputBrushSolDown()
{
	m_pMotor->WriteOutputIOBIt(9, 3, TRUE);
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(BRUSH_SOL, FALSE);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputGreenLampOn()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(TOWER_LAMP_GREEN, TRUE);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputGreenLampOff()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(TOWER_LAMP_GREEN, FALSE);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputYellowLampOn()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(TOWER_LAMP_YELLOW, TRUE);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputYellowLampOff()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(TOWER_LAMP_YELLOW, FALSE);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputRedLampOn()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(TOWER_LAMP_RED, TRUE);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputRedLampOff()
{
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA)
	{
		m_pMotor->WriteOutPort(TOWER_LAMP_RED, FALSE);
	}
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputResetLoader1()
{
	m_bStatusLoader1 = !m_bStatusLoader1;
	
	if(m_bStatusLoader1)
		m_pMotor->Loader1PCBExist(TRUE);
	else
		m_pMotor->Loader1PCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputResetLoader2()
{
	m_bStatusLoader2 = !m_bStatusLoader2;
	
	if(m_bStatusLoader2)
		m_pMotor->Loader2PCBExist(TRUE);
	else
		m_pMotor->Loader2PCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputResetLoaderTable()
{
	m_bStatusAligner = !m_bStatusAligner;
	
	if(m_bStatusAligner)
		m_pMotor->AlignTablePCBExist(TRUE);
	else
		m_pMotor->AlignTablePCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputResetUnloader1()
{
	m_bStatusUnloader1 = !m_bStatusUnloader1;
	
	if(m_bStatusUnloader1)
		m_pMotor->Unloader1PCBExist(TRUE);
	else
		m_pMotor->Unloader1PCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputResetUnloader2()
{
	m_bStatusUnloader2 = !m_bStatusUnloader2;
	
	if(m_bStatusUnloader2)
		m_pMotor->Unloader2PCBExist(TRUE);
	else
		m_pMotor->Unloader2PCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputResetUnloaderTable()
{
	m_bStatusAligner2 = !m_bStatusAligner2;
	
	if(m_bStatusAligner2)
		m_pMotor->ULAlignTablePCBExist(TRUE);
	else
		m_pMotor->ULAlignTablePCBExist(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputResetTable1()
{
	m_bStatusTable1 = !m_bStatusTable1;
	
	m_pMotor->TablePCBReset();
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputResetTable2()
{
	m_bStatusTable2 = !m_bStatusTable2;
	
	m_pMotor->TablePCBReset();
}

//2011524
void CPaneManualControlIOMonitorOutputSub1Osan::OnRadioTableAVacuum()
{
	m_RadioVacuumTable = 0;
//	m_pMotor->SetOutportTableVacuum(m_RadioVacuumTable, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnRadioTableBVacuum()
{
	m_RadioVacuumTable = 1;
//	m_pMotor->SetOutportTableVacuum(m_RadioVacuumTable, TRUE);
}
void CPaneManualControlIOMonitorOutputSub1Osan::OnRadioTableCVacuum()
{
	m_RadioVacuumTable = 2;
//	m_pMotor->SetOutportTableVacuum(m_RadioVacuumTable, TRUE);
}
void CPaneManualControlIOMonitorOutputSub1Osan::OnRadioTableDVacuum()
{
	m_RadioVacuumTable = 3;
//	m_pMotor->SetOutportTableVacuum(m_RadioVacuumTable, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::ClearRadioTableVacuum()
{
	m_RadioVacuumTable = 0;

	CheckRadioButton(IDC_RADIO_TABLE_VACUMM_A,IDC_RADIO_TABLE_VACUMM_D,IDC_RADIO_TABLE_VACUMM_A);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputTablesuctionDefualtOn() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputTablesuctionDefualtOff() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputTablesuctionDefualtOn2() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputTablesuctionDefualtOff2() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
}

BOOL CPaneManualControlIOMonitorOutputSub1Osan::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLaserHeadPurgeOn() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_LASER_HEAD_PURGE, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputLaserHeadPurgeOff() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->SetOutPort(PORT_LASER_HEAD_PURGE, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputRollUseOn() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->UseRoll(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputRollUseOff() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->UseRoll(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputHoodShutterOpen() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->HoodOpen(TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputHoodShutterClose() 
{
	// TODO: Add your control notification handler code here
	m_pMotor->HoodOpen(FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputInitializeA1() 
{
	// TODO: Add your control notification handler code here
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	m_pMotor->SetOrigin(AXIS_A1);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputInitializeA2() 
{
	// TODO: Add your control notification handler code here
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); // 110603
		return;
	}
	
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	
	m_pMotor->SetOrigin(AXIS_A2);
}

BOOL CPaneManualControlIOMonitorOutputSub1Osan::GetCurrentAcrSuction()
{
	return m_bAcrMotorOn;
}

void CPaneManualControlIOMonitorOutputSub1Osan::SetCurrentAcrSuction(BOOL bOn)
{	
	m_bAcrMotorOn = bOn;
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputBeampassMasterUp() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_BEAM_PASS, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputBeampassMasterDown() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_BEAM_PASS, FALSE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputBeampassSlaveUp() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_BEAM_PASS, TRUE);
}

void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputBeampassSlaveDown() 
{
	// TODO: Add your control notification handler code here
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_BEAM_PASS, FALSE);
}
void CPaneManualControlIOMonitorOutputSub1Osan::OnButtonOutputInitializeM3() 
{
	if( m_pMotor->IsAnyError() )
	{
		ErrMessage(_T("Must do error reset")); 
		return;
	}
	
	if(m_pMotor->GetCurrentMode() == MODE_MPG)
	{
		ErrMsgDlg(STDGNALM209);
		return;
	}
	
	if(m_pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return;
	}
	
	m_pMotor->SetOrigin(AXIS_M3);
}


BOOL CPaneManualControlIOMonitorOutputSub1Osan::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_IO_Output1) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}

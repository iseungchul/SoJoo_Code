#if !defined(AFX_PANESYSSETUPMOTORPUSAN1_H__8BBEFF88_5291_4C70_9F9A_B68DCA94DCFC__INCLUDED_)
#define AFX_PANESYSSETUPMOTORPUSAN1_H__8BBEFF88_5291_4C70_9F9A_B68DCA94DCFC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupMotor.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupMotor form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

class CPaneSysSetupMotorPusan1 : public CFormView
{
protected:
	CPaneSysSetupMotorPusan1();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupMotorPusan1)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupMotorPusan1)
	enum { IDD = IDD_DLG_SYS_SETUP_MOTOR_PUSAN1 };
	UEasyButtonEx	m_btnPowermeterPort;
	UEasyButtonEx	m_btnVisionLampPort;
	UEasyButtonEx	m_btnVisionLampPort2;
	UEasyButtonEx	m_btnMarkingParam;
	UEasyButtonEx	m_btnPixelRevision;
	UEasyButtonEx	m_btnServoPort;
	UEasyButtonEx	m_btnMotorMove;
	UEasyButtonEx	m_btnChillerPort;
	UEasyButtonEx	m_btnHumidity;
	CColorEdit  m_edtVibrationCount;
	CColorEdit	m_edtVibrationLPCount;
	CColorEdit	m_edtScannerFieldY;
	CColorEdit	m_edtScannerFieldX;

	CColorEdit	m_edt2ndPanelID;
	CColorEdit	m_edt1stPanelID;
	CColorEdit	m_edtSoftLimitPlus;
	CColorEdit	m_edtSoftLimitMinus;
	CColorEdit	m_edtMoveSCurve;
	CColorEdit	m_edtMoveAccel;

	CColorEdit	m_edtMoveSCurvePre;
	CColorEdit	m_edtMoveAccelPre;
	CColorEdit	m_edtMoveSCurveNext;
	CColorEdit	m_edtMoveAccelNext;

	CColorEdit	m_edtMoveVelocity;
	CColorEdit	m_edtScale;
	CColorEdit	m_edtLowVisionHeight;
	CColorEdit	m_edtHighVisionHeight;
	CColorEdit	m_edtHOffset2ndLowY;
	CColorEdit	m_edtHOffset2ndLowX;
	CColorEdit	m_edtHOffset2ndHighY;
	CColorEdit	m_edtHOffset2ndHighX;
	CColorEdit	m_edtHOffset1stLowY;
	CColorEdit	m_edtHOffset1stLowX;
	CColorEdit	m_edtHOffset1stHighY;
	CColorEdit	m_edtHOffset1stHighX;

	CColorEdit m_edtWaterFlow1;
	CColorEdit m_edtWaterFlow2;
	CColorEdit m_edtMainAir;
	CColorEdit m_edtDustSuction;
	CColorEdit m_edtTableVacuum1;
	CColorEdit m_edtTableVacuum2;
	CColorEdit m_edtWaterFlowOffset1;
	CColorEdit m_edtWaterFlowOffset2;

	CListBox	m_lbAxis;
	//}}AFX_DATA

// Attributes
public:

// Attributes
protected :
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	CFont			m_fntListBox;
	CFont			m_fntBtn;

	int				m_nIndex;
	int				m_nAxisMax;

	SSYSTEMDEVICE	m_sSystemDevice;
	SAXISINFO		m_pAxisInfo[MOTOR_AXIS_MAX];
	
	int				m_nUserLevel;

// Operations
public:
	void SaveChangeCamOffset(BOOL *pChangeCam);
	CString GetChangeValueStr();
	void		InitStaticControl();
	void		InitEditControl();
	void		InitListBoxControl();
	void		InitBtnControl();

	void		DispSystemDevice();
	void		ShowAxisInfo(int nSel);
	void		SetSystemDevice(SSYSTEMDEVICE sSystemDevice);
	void		GetSystemDevice(SSYSTEMDEVICE* pSystemDevice);
	void		OnApply();
	void		UpdateAxis();

	void		OnCamChange(int nCamNo);

	BOOL		MoveTable(double dPosX, double dPosY);

	void		RefreshHeadOffset(int nCam, DPOINT dPoint);

	void		EnableControl(BOOL bUse);
	void		SetAuthorityByLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupMotorPusan1)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupMotorPusan1();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupMotorPusan1)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	afx_msg void OnButtonPowermeterPort();
	afx_msg void OnButtonServoPort();
	afx_msg void OnButtonMarkingParam();
	afx_msg void OnSelchangeListAxis();
	afx_msg void OnButtonCamSet();
	afx_msg void OnButtonMove();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedButtonChiller();
	afx_msg void OnBnClickedButtonHumidity();
	afx_msg void OnBnClickedButtonVisionLampPort();
	afx_msg void OnBnClickedButtonVisionLamp2Port();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPMOTORPUSAN1_H__8BBEFF88_5291_4C70_9F9A_B68DCA94DCFC__INCLUDED_)

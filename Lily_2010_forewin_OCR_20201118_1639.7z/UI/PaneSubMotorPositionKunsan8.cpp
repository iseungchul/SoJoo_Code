// PaneSubMotorPositionKunsan8.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneSubMotorPositionKunsan8.h"
#include "..\EasyDrillerDlg.h"
#include "..\device\hdevicefactory.h"
#include "..\device\DeviceMotor.h"
#include "..\device\HMotor.h"
#include "..\model\dsystemini.h"
#include "..\model\deasydrillerini.h"
#include "..\device\HLaserAttenuator.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneSubMotorPositionKunsan8

IMPLEMENT_DYNCREATE(CPaneSubMotorPositionKunsan8, CFormView)

CPaneSubMotorPositionKunsan8::CPaneSubMotorPositionKunsan8()
	: CFormView(CPaneSubMotorPositionKunsan8::IDD)
{
	//{{AFX_DATA_INIT(CPaneSubMotorPositionKunsan8)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nTimerID = 0;
}

CPaneSubMotorPositionKunsan8::~CPaneSubMotorPositionKunsan8()
{
}

void CPaneSubMotorPositionKunsan8::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneSubMotorPositionKunsan8)
	DDX_Control(pDX, IDC_STATIC_POS_X_VALUE, m_stcPosX);
	DDX_Control(pDX, IDC_STATIC_POS_Y_VALUE, m_stcPosY);
	DDX_Control(pDX, IDC_STATIC_POS_Z1_VALUE, m_stcPosZ1);
	DDX_Control(pDX, IDC_STATIC_POS_Z2_VALUE, m_stcPosZ2);
	DDX_Control(pDX, IDC_STATIC_POS_M_VALUE, m_stcPosM);
	DDX_Control(pDX, IDC_STATIC_POS_C_VALUE, m_stcPosC);
	DDX_Control(pDX, IDC_STATIC_POS_A_VALUE, m_stcPosA);
	DDX_Control(pDX, IDC_STATIC_POS_LC_VALUE, m_stcPosLC);
	DDX_Control(pDX, IDC_STATIC_POS_UC_VALUE, m_stcPosUC);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneSubMotorPositionKunsan8, CFormView)
	//{{AFX_MSG_MAP(CPaneSubMotorPositionKunsan8)
	ON_WM_TIMER()
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneSubMotorPositionKunsan8 diagnostics

#ifdef _DEBUG
void CPaneSubMotorPositionKunsan8::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneSubMotorPositionKunsan8::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneSubMotorPositionKunsan8 message handlers

void CPaneSubMotorPositionKunsan8::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();

	InitTimer();

	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1)
	{
		GetDlgItem(IDC_STATIC_POS_Z2)->EnableWindow(FALSE);
		m_stcPosZ2.EnableWindow(FALSE);
	}

	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0)
	{
		GetDlgItem(IDC_STATIC_POS_Z2)->ShowWindow(SW_HIDE);
		m_stcPosZ2.ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC_POS_M)->ShowWindow(SW_HIDE);
		m_stcPosM.ShowWindow(SW_HIDE);

		GetDlgItem(IDC_STATIC_POS_C)->ShowWindow(SW_HIDE);
		m_stcPosC.ShowWindow(SW_HIDE);

		if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		{
			GetDlgItem(IDC_STATIC_POS_Z1)->EnableWindow(FALSE);
			m_stcPosZ1.EnableWindow(FALSE);
		}
	}
	if(gSystemINI.m_sHardWare.nLaserType != LASER_SLV263G)
	{
		GetDlgItem(IDC_STATIC_POS_A)->ShowWindow(SW_HIDE);
		m_stcPosA.ShowWindow(SW_HIDE);
	}
	if(gSystemINI.m_sHardWare.nLaserType != LASER_CO2)
	{
		if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
		{
			GetDlgItem(IDC_STATIC_POS_Z2)->EnableWindow(TRUE);
			m_stcPosZ2.EnableWindow(TRUE);
			GetDlgItem(IDC_STATIC_POS_Z2)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_STATIC_POS_Z2)->SetWindowText("T");
			m_stcPosZ2.ShowWindow(SW_SHOW);
		}
		else
		{
			GetDlgItem(IDC_STATIC_POS_Z2)->ShowWindow(SW_HIDE);
			m_stcPosZ2.ShowWindow(SW_HIDE);
		}
			
		GetDlgItem(IDC_STATIC_POS_M)->ShowWindow(SW_HIDE);
		m_stcPosM.ShowWindow(SW_HIDE);
		
		GetDlgItem(IDC_STATIC_POS_C)->ShowWindow(SW_HIDE);
		m_stcPosC.ShowWindow(SW_HIDE);
	}
}

void CPaneSubMotorPositionKunsan8::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(120, "Arial Bold");
	
	// Position
	GetDlgItem(IDC_STATIC_GROUP_MOTOR_POSITION)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_POS_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_Z1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_Z2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_M)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_C)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_A)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_LC)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POS_UC)->SetFont( &m_fntStatic );

	m_stcPosX.SetFont( &m_fntStatic );
	m_stcPosX.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosX.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosY.SetFont( &m_fntStatic );
	m_stcPosY.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosY.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosZ1.SetFont( &m_fntStatic );
	m_stcPosZ1.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosZ1.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosZ2.SetFont( &m_fntStatic );
	m_stcPosZ2.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosZ2.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosM.SetFont( &m_fntStatic );
	m_stcPosM.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosM.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosC.SetFont( &m_fntStatic );
	m_stcPosC.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosC.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosA.SetFont( &m_fntStatic );
	m_stcPosA.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosA.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosLC.SetFont( &m_fntStatic );
	m_stcPosLC.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosLC.SetBackColor( VALUE_BACK_COLOR );

	m_stcPosUC.SetFont( &m_fntStatic );
	m_stcPosUC.SetForeColor( VALUE_FORE_COLOR );
	m_stcPosUC.SetBackColor( VALUE_BACK_COLOR );

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		GetDlgItem(IDC_STATIC_POS_M)->SetWindowText("A1");
		GetDlgItem(IDC_STATIC_POS_C)->SetWindowText("A2");
	}
}

HBRUSH CPaneSubMotorPositionKunsan8::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_GROUP_MOTOR_POSITION)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneSubMotorPositionKunsan8::DispStatus()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	double dPos = 0;
	int nPos = 0;
	CString strData;
	strData.GetBuffer(256);
	// X
	pMotor->GetRawPosition( AXIS_X, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosX.SetWindowText( (LPCTSTR)strData );
	
	// Y
	pMotor->GetRawPosition( AXIS_Y, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosY.SetWindowText( (LPCTSTR)strData );
	
	// Z1
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() == 1)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_Z1, dPos );

	strData.Format(_T("%.3f"), dPos);
	m_stcPosZ1.SetWindowText( (LPCTSTR)strData );
	
	// Z2
	if(gEasyDrillerINI.m_clsHwOption.GetScannerHeadNum() == 1 ||
		gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3 )
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_Z2, dPos );
	
	strData.Format(_T("%.3f"), dPos);
	m_stcPosZ2.SetWindowText( (LPCTSTR)strData );
	
	// M
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_M, dPos );

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		strData.Format(_T("%.3f"), dPos);
	else
		strData.Format(_T("%.1f"), dPos);
	m_stcPosM.SetWindowText( (LPCTSTR)strData );
	
	// C
	if(gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() != 0 && gEasyDrillerINI.m_clsHwOption.GetUseOnlyXY() < 3)
		dPos = 0.0;
	else
		pMotor->GetRawPosition( AXIS_C, dPos );
	
	strData.Format(_T("%.3f"), dPos);
	m_stcPosC.SetWindowText( (LPCTSTR)strData );

	nPos = gDeviceFactory.GetAttenuator()->GetCurrentPos();
	strData.Format(_T("%d"), nPos);
	m_stcPosA.SetWindowText( (LPCTSTR)strData );

	// L.C
	pMotor->GetRawPosition( AXIS_L_CARRIER, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosLC.SetWindowText( (LPCTSTR)strData );

	// L.C
	pMotor->GetRawPosition( AXIS_UL_CARRIER, dPos );
	strData.Format(_T("%.3f"), dPos);
	m_stcPosUC.SetWindowText( (LPCTSTR)strData );

	m_bTimer = FALSE;
	strData.ReleaseBuffer();
}

void CPaneSubMotorPositionKunsan8::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default

	if(!m_bTimer)
		DispStatus();
	
	CFormView::OnTimer(nIDEvent);
}

void CPaneSubMotorPositionKunsan8::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_bTimer = FALSE;
		m_nTimerID = SetTimer(999, 500, NULL);
	}
}

void CPaneSubMotorPositionKunsan8::DestroyTimer()
{
	if(m_nTimerID)
	{
		m_bTimer = TRUE;
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}
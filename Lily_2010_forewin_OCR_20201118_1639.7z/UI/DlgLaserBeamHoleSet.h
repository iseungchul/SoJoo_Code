#if !defined(AFX_DLGLASERBEAMHOLESET_H__13158C73_EF5A_42BA_A749_842A79F4C613__INCLUDED_)
#define AFX_DLGLASERBEAMHOLESET_H__13158C73_EF5A_42BA_A749_842A79F4C613__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgLaserBeamHoleSet.h : header file
//

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

#define MAX_BEAM_HOLE		15

/////////////////////////////////////////////////////////////////////////////
// CDlgLaserBeamHoleSet dialog

class CDlgLaserBeamHoleSet : public CDialog
{
// Construction
public:
	CDlgLaserBeamHoleSet(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgLaserBeamHoleSet)
#ifdef __USE_DUALBAND_EOCARD__
	enum { IDD = IDD_DLG_LASER_BEAM_HOLE_SET_DUALBAND };
#else
	enum { IDD = IDD_DLG_LASER_BEAM_HOLE_SET };
#endif
	UEasyButtonEx	m_btnApply;
	UEasyButtonEx	m_btnCancel;
	UEasyButtonEx	m_chkApplyAll;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgLaserBeamHoleSet)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Operation
public :
	void			SetUserLevel(int nLevel);
	void			OpenAOMProfileFile();
	BOOL			InitControl();
	void			InitBtnControl();
	int GetFireHole(double dHoleSet[], double dHoleAOMDelay[], double dHoleAOMDuty[], double dHoleMinFreq[], double dHoleMaxFreq[] , TCHAR (*n)[255], double dDutyOffsetM[], double dDutyOffsetS[], double dVoltageM[], double dVoltageS[]);
	void SetFireHole(int nCount, double dHoleSet[], double dHoleAOMDelay[], double dHoleAOMDuty[], double dHoleMinFreq[], double dHoleMaxFreq[], TCHAR (*n)[255], double dDutyOffsetM[], double dDutyOffsetS[], double dVoltageM[], double dVoltageS[], BOOL bGlobalTool);

	int				m_nUserLevel;
// Attribute
protected :
	CStatic			m_stcHole[MAX_BEAM_HOLE];
	CColorEdit		m_edtHole[MAX_BEAM_HOLE];
	CStatic			m_stcUnit[MAX_BEAM_HOLE];
	UEasyButtonEx	m_chkParam[MAX_BEAM_HOLE];

	CColorEdit		m_edtAOMDelay[MAX_BEAM_HOLE];
	CStatic			m_stcAOMDelayUnit[MAX_BEAM_HOLE];
	CColorEdit		m_edtAOMDuty[MAX_BEAM_HOLE];
	CStatic			m_stcAOMDutyUnit[MAX_BEAM_HOLE];
	CColorEdit		m_edtAOMFilePath[MAX_BEAM_HOLE];
	UEasyButtonEx	m_btnFileOpen[MAX_BEAM_HOLE];
	CStatic			m_stcMinFreqUnit[MAX_BEAM_HOLE];
	CColorEdit		m_edtMinFreq[MAX_BEAM_HOLE];
	CStatic			m_stcMaxFreqUnit[MAX_BEAM_HOLE];
	CColorEdit		m_edtMaxFreq[MAX_BEAM_HOLE];

	CStatic			m_stcDutyOffset[MAX_BEAM_HOLE];
	CColorEdit		m_edtDutyOffsetM[MAX_BEAM_HOLE];
	CColorEdit		m_edtDutyOffsetS[MAX_BEAM_HOLE];
	CStatic			m_stcVoltage[MAX_BEAM_HOLE];
	CColorEdit		m_edtVoltageM[MAX_BEAM_HOLE];
	CColorEdit		m_edtVoltageS[MAX_BEAM_HOLE];
//	CButton			m_chkApplyAll;
	BOOL			m_bIsApplyAll;

	int				m_nCount;
	double			m_dHoleSet[MAX_BEAM_HOLE];
	double			m_dAOMDelay[MAX_BEAM_HOLE];
	double			m_dAOMDuty[MAX_BEAM_HOLE];
	double			m_dMinFreq[MAX_BEAM_HOLE];
	double			m_dMaxFreq[MAX_BEAM_HOLE];

	double			m_dDutyOffsetM[MAX_BEAM_HOLE];
	double			m_dDutyOffsetS[MAX_BEAM_HOLE];
	double			m_dVoltageM[MAX_BEAM_HOLE];
	double			m_dVoltageS[MAX_BEAM_HOLE];

	TCHAR			m_cAOMFilePath[MAX_BEAM_HOLE][255];

	CFont			m_fntBtn;
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	int				m_nAOMFileNo;
	BOOL			m_bGlobal;

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgLaserBeamHoleSet)
	virtual BOOL OnInitDialog();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnSetDuty();
	afx_msg void OnAOMOpen1();
	afx_msg void OnAOMOpen2();
	afx_msg void OnAOMOpen3();
	afx_msg void OnAOMOpen4();
	afx_msg void OnAOMOpen5();
	afx_msg void OnAOMOpen6();
	afx_msg void OnAOMOpen7();
	afx_msg void OnAOMOpen8();
	afx_msg void OnAOMOpen9();
	afx_msg void OnAOMOpen10();
	afx_msg void OnAOMOpen11();
	afx_msg void OnAOMOpen12();
	afx_msg void OnAOMOpen13();
	afx_msg void OnAOMOpen14();
	afx_msg void OnAOMOpen15();
	afx_msg void OnCheckParam();
	afx_msg void OnCheckParam2();
	afx_msg void OnCheckParam3();
	afx_msg void OnCheckParam4();
	afx_msg void OnCheckParam5();
	afx_msg void OnCheckParam6();
	afx_msg void OnCheckParam7();
	afx_msg void OnCheckParam8();
	afx_msg void OnCheckParam9();
	afx_msg void OnCheckParam10();
	afx_msg void OnCheckParam11();
	afx_msg void OnCheckParam12();
	afx_msg void OnCheckParam13();
	afx_msg void OnCheckParam14();
	afx_msg void OnCheckParam15();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGLASERBEAMHOLESET_H__13158C73_EF5A_42BA_A749_842A79F4C613__INCLUDED_)

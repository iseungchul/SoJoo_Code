// DlgLaserBeamHoleSet.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgLaserBeamHoleSet.h"
#include "..\model\dsystemini.h"
#include "..\model\deasydrillerini.h"
#include "..\Device\HEocard.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgLaserBeamHoleSet dialog


CDlgLaserBeamHoleSet::CDlgLaserBeamHoleSet(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgLaserBeamHoleSet::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgLaserBeamHoleSet)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nCount		= 0;
	memset( m_dHoleSet, 0, sizeof(m_dHoleSet) );
	memset( m_dAOMDelay, 0, sizeof(m_dAOMDelay) );
	memset( m_dAOMDuty, 0, sizeof(m_dAOMDuty) );
	memset(	m_dMinFreq, 0, sizeof(m_dMinFreq) );
	memset( m_dMaxFreq, 0, sizeof(m_dMaxFreq) );

	memset( m_dDutyOffsetM, 0, sizeof(m_dDutyOffsetM) );
	memset( m_dDutyOffsetS, 0, sizeof(m_dDutyOffsetS) );
	memset( m_dVoltageM, 0, sizeof(m_dVoltageM) );
	memset( m_dVoltageS, 0, sizeof(m_dVoltageS) );

	m_bGlobal = FALSE;
	CString str;
	str.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	for(int i = 0; i < MAX_BEAM_HOLE; i++)
		memcpy(m_cAOMFilePath[i], str, str.GetLength()+1);
}


void CDlgLaserBeamHoleSet::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgLaserBeamHoleSet)
	DDX_Control(pDX, IDOK, m_btnApply);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_CHECK_APPLY_ALL, m_chkApplyAll);
	DDX_Control(pDX, IDC_AOM_OPEN1, m_btnFileOpen[0]);
	DDX_Control(pDX, IDC_AOM_OPEN2, m_btnFileOpen[1]);
	DDX_Control(pDX, IDC_AOM_OPEN3, m_btnFileOpen[2]);
	DDX_Control(pDX, IDC_AOM_OPEN4, m_btnFileOpen[3]);
	DDX_Control(pDX, IDC_AOM_OPEN5, m_btnFileOpen[4]);
	DDX_Control(pDX, IDC_AOM_OPEN6, m_btnFileOpen[5]);
	DDX_Control(pDX, IDC_AOM_OPEN7, m_btnFileOpen[6]);
	DDX_Control(pDX, IDC_AOM_OPEN8, m_btnFileOpen[7]);
	DDX_Control(pDX, IDC_AOM_OPEN9, m_btnFileOpen[8]);
	DDX_Control(pDX, IDC_AOM_OPEN10, m_btnFileOpen[9]);
	DDX_Control(pDX, IDC_AOM_OPEN11, m_btnFileOpen[10]);
	DDX_Control(pDX, IDC_AOM_OPEN12, m_btnFileOpen[11]);
	DDX_Control(pDX, IDC_AOM_OPEN13, m_btnFileOpen[12]);
	DDX_Control(pDX, IDC_AOM_OPEN14, m_btnFileOpen[13]);
	DDX_Control(pDX, IDC_AOM_OPEN15, m_btnFileOpen[14]);
	DDX_Control(pDX, IDC_CHECK_PARAM, m_chkParam[0]);
	DDX_Control(pDX, IDC_CHECK_PARAM2, m_chkParam[1]);
	DDX_Control(pDX, IDC_CHECK_PARAM3, m_chkParam[2]);
	DDX_Control(pDX, IDC_CHECK_PARAM4, m_chkParam[3]);
	DDX_Control(pDX, IDC_CHECK_PARAM5, m_chkParam[4]);
	DDX_Control(pDX, IDC_CHECK_PARAM6, m_chkParam[5]);
	DDX_Control(pDX, IDC_CHECK_PARAM7, m_chkParam[6]);
	DDX_Control(pDX, IDC_CHECK_PARAM8, m_chkParam[7]);
	DDX_Control(pDX, IDC_CHECK_PARAM9, m_chkParam[8]);
	DDX_Control(pDX, IDC_CHECK_PARAM10, m_chkParam[9]);
	DDX_Control(pDX, IDC_CHECK_PARAM11, m_chkParam[10]);
	DDX_Control(pDX, IDC_CHECK_PARAM12, m_chkParam[11]);
	DDX_Control(pDX, IDC_CHECK_PARAM13, m_chkParam[12]);
	DDX_Control(pDX, IDC_CHECK_PARAM14, m_chkParam[13]);
	DDX_Control(pDX, IDC_CHECK_PARAM15, m_chkParam[14]);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgLaserBeamHoleSet, CDialog)
	//{{AFX_MSG_MAP(CDlgLaserBeamHoleSet)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_CHECK_APPLY_ALL, OnSetDuty)
	ON_BN_CLICKED(IDC_AOM_OPEN1, OnAOMOpen1)
	ON_BN_CLICKED(IDC_AOM_OPEN2, OnAOMOpen2)
	ON_BN_CLICKED(IDC_AOM_OPEN3, OnAOMOpen3)
	ON_BN_CLICKED(IDC_AOM_OPEN4, OnAOMOpen4)
	ON_BN_CLICKED(IDC_AOM_OPEN5, OnAOMOpen5)
	ON_BN_CLICKED(IDC_AOM_OPEN6, OnAOMOpen6)
	ON_BN_CLICKED(IDC_AOM_OPEN7, OnAOMOpen7)
	ON_BN_CLICKED(IDC_AOM_OPEN8, OnAOMOpen8)
	ON_BN_CLICKED(IDC_AOM_OPEN9, OnAOMOpen9)
	ON_BN_CLICKED(IDC_AOM_OPEN10, OnAOMOpen10)
	ON_BN_CLICKED(IDC_AOM_OPEN11, OnAOMOpen11)
	ON_BN_CLICKED(IDC_AOM_OPEN12, OnAOMOpen12)
	ON_BN_CLICKED(IDC_AOM_OPEN13, OnAOMOpen13)
	ON_BN_CLICKED(IDC_AOM_OPEN14, OnAOMOpen14)
	ON_BN_CLICKED(IDC_AOM_OPEN15, OnAOMOpen15)
	ON_BN_CLICKED(IDC_CHECK_PARAM, OnCheckParam)
	ON_BN_CLICKED(IDC_CHECK_PARAM2, OnCheckParam2)
	ON_BN_CLICKED(IDC_CHECK_PARAM3, OnCheckParam3)
	ON_BN_CLICKED(IDC_CHECK_PARAM4, OnCheckParam4)
	ON_BN_CLICKED(IDC_CHECK_PARAM5, OnCheckParam5)
	ON_BN_CLICKED(IDC_CHECK_PARAM6, OnCheckParam6)
	ON_BN_CLICKED(IDC_CHECK_PARAM7, OnCheckParam7)
	ON_BN_CLICKED(IDC_CHECK_PARAM8, OnCheckParam8)
	ON_BN_CLICKED(IDC_CHECK_PARAM9, OnCheckParam9)
	ON_BN_CLICKED(IDC_CHECK_PARAM10, OnCheckParam10)
	ON_BN_CLICKED(IDC_CHECK_PARAM11, OnCheckParam11)
	ON_BN_CLICKED(IDC_CHECK_PARAM12, OnCheckParam12)
	ON_BN_CLICKED(IDC_CHECK_PARAM13, OnCheckParam13)
	ON_BN_CLICKED(IDC_CHECK_PARAM14, OnCheckParam14)
	ON_BN_CLICKED(IDC_CHECK_PARAM15, OnCheckParam15)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgLaserBeamHoleSet message handlers

BOOL CDlgLaserBeamHoleSet::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitBtnControl();
	if( FALSE == InitControl() )
		return FALSE;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgLaserBeamHoleSet::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Check Box
	m_chkApplyAll.SetFont( &m_fntBtn );
	m_chkApplyAll.SetImageOrg( 10, 3 );
	m_chkApplyAll.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkApplyAll.EnableBallonToolTip();
	m_chkApplyAll.SetToolTipText( _T("Apply All") );
	m_chkApplyAll.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_chkApplyAll.SetBtnCursor(IDC_HAND_1);

	// Apply
	m_btnApply.SetFont( &m_fntBtn );
	m_btnApply.SetFlat( FALSE );
	m_btnApply.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApply.EnableBallonToolTip();
	m_btnApply.SetToolTipText( _T("Apply") );
	m_btnApply.SetBtnCursor(IDC_HAND_1);
#if defined (__OSAN_LG_2013__) || defined (__OSAN_LG__)
	m_btnApply.EnableWindow(FALSE);
#endif

	// Cancel
	m_btnCancel.SetFont( &m_fntBtn );
	m_btnCancel.SetFlat( FALSE );
	m_btnCancel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCancel.EnableBallonToolTip();
	m_btnCancel.SetToolTipText( _T("Cancel") );
	m_btnCancel.SetBtnCursor(IDC_HAND_1);
#if defined (__OSAN_LG_2013__) || defined (__OSAN_LG__)
	m_btnCancel.EnableWindow(FALSE);
#endif

	for(int i = 0; i < MAX_BEAM_HOLE; i++)
	{
		m_btnFileOpen[i].SetFont( &m_fntBtn );
		m_btnFileOpen[i].SetFlat( FALSE );
		m_btnFileOpen[i].SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_btnFileOpen[i].EnableBallonToolTip();
		m_btnFileOpen[i].SetToolTipText( _T("AOM Profile File Open") );
		m_btnFileOpen[i].SetBtnCursor(IDC_HAND_1);
		m_btnFileOpen[i].ShowWindow(SW_HIDE);
#if defined (__OSAN_LG_2013__) || defined (__OSAN_LG__)
		m_chkParam[i].SetFont( &m_fntBtn );
		m_chkParam[i].SetImageOrg( 10, 3 );
		m_chkParam[i].SetIcon( IDI_LEDON, IDI_LEDOFF );
		m_chkParam[i].EnableBallonToolTip();
		m_chkParam[i].SetToolTipText( _T("Apply the Parameter") );
		m_chkParam[i].SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
		m_chkParam[i].SetBtnCursor(IDC_HAND_1);
#endif
		m_chkParam[i].ShowWindow(SW_HIDE);


	}
}

BOOL CDlgLaserBeamHoleSet::InitControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	DWORD dwType = 0;
	if(gSystemINI.m_sHardWare.nAOMType == 0)
		dwType = WS_DISABLED;

	CRect rt;
	
	GetDlgItem(IDC_STATIC_SETTING)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SETTING)->GetWindowRect(rt);
	ScreenToClient(rt);
	m_bIsApplyAll = FALSE;
	m_chkApplyAll.SetCheck(m_bIsApplyAll);
	
	DWORD dwStyle, dwFreqStyle;

	int nXSize = 100;

	CString strTitle;
	for (int i = 0 ; i < m_nCount ; i++)
	{
		CRect rect(rt.left + (rt.right - rt.left) * (i / 5) + 10,
					rt.top + 30 + (i % 5) * 70, 0, 0);
		rect.right = rect.left + 50; 
		rect.bottom = rect.top + 30;

		if(i == 0 && !m_bGlobal)
			dwStyle = WS_VISIBLE | WS_CHILD | SS_CENTERIMAGE | SS_CENTER | WS_DISABLED;
		else
			dwStyle = WS_VISIBLE | WS_CHILD | SS_CENTERIMAGE | SS_CENTER;

		dwFreqStyle = WS_VISIBLE | WS_CHILD | SS_CENTERIMAGE | SS_CENTER;

		if(i % 5 == 0)
		{
			rect.left += 50;
			rect.right = rect.left + 80;
			if (!m_stcUnit[i / 5].Create("Duty(us)", dwStyle, rect, this, 0xffff))
			{
				TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
				return FALSE;
			}
			m_stcUnit[i / 5].SetFont(&m_fntStatic);
			m_stcUnit[i / 5].MoveWindow(rect);
#ifndef __3RDAOD__
			rect.left += 85;
			rect.right = rect.left + 120;
			if (!m_stcAOMDelayUnit[i / 5].Create("AOM Delay(us)", dwStyle, rect, this, 0xffff))
			{
				TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
				return FALSE;
			}
			m_stcAOMDelayUnit[i / 5].SetFont(&m_fntStatic);
			m_stcAOMDelayUnit[i / 5].MoveWindow(rect);

			rect.left += 125;
			rect.right = rect.left + 120;
			if (!m_stcAOMDutyUnit[i / 5].Create("AOM Duty(us)", dwStyle, rect, this, 0xffff))
			{
				TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
				return FALSE;
			}
			m_stcAOMDutyUnit[i / 5].SetFont(&m_fntStatic);
			m_stcAOMDutyUnit[i / 5].MoveWindow(rect);

	#ifdef __USE_DUALBAND_EOCARD__
			rect.left += 125;
			rect.right = rect.left + 120;
			if (!m_stcMinFreqUnit[i / 5].Create("Min. Freq.(Hz)", dwFreqStyle, rect, this, 0xffff))
			{
				TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
				return FALSE;
			}
			m_stcMinFreqUnit[i / 5].SetFont(&m_fntStatic);
			m_stcMinFreqUnit[i / 5].MoveWindow(rect);

			rect.left += 125;
			rect.right = rect.left + 120;
			if (!m_stcMaxFreqUnit[i / 5].Create("Max. Freq.(Hz)", dwFreqStyle, rect, this, 0xffff))
			{
				TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
				return FALSE;
			}
			m_stcMaxFreqUnit[i / 5].SetFont(&m_fntStatic);
			m_stcMaxFreqUnit[i / 5].MoveWindow(rect);
	#endif
#else
	#ifdef __USE_DUALBAND_EOCARD__
			rect.left += 90;
			rect.right = rect.left + 120;
			if (!m_stcMaxFreqUnit[i / 5].Create("Max. Freq.(Hz)", dwFreqStyle, rect, this, 0xffff))
			{
				TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
				return FALSE;
			}
			m_stcMaxFreqUnit[i / 5].SetFont(&m_fntStatic);
			m_stcMaxFreqUnit[i / 5].MoveWindow(rect);
	#endif
#endif

		}

		rect.left = rt.left + (rt.right - rt.left) * (i / 5) + 10;
		rect.top = rt.top + 30 + (i % 5) * 70 + 35;
		rect.right = rect.left + 50;
		rect.bottom = rect.top + 30;
		strTitle.Format(_T("No.%d"), i + 1);

		
		if (!m_stcHole[i].Create(strTitle, dwStyle, rect, this, 0xffff))
		{
			TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
			return FALSE;
		}
		m_stcHole[i].SetFont(&m_fntStatic);
		m_stcHole[i].MoveWindow(rect);

		rect.left += 50;
		rect.right = rect.left + 80;
		if (!m_edtHole[i].Create(dwStyle | WS_BORDER, rect, this, 0xffff))
		{
			TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
			return FALSE;
		}
		m_edtHole[i].SetFont(&m_fntEdit);
		m_edtHole[i].SetForeColor( BLACK_COLOR );
		m_edtHole[i].SetBackColor( WHITE_COLOR );
		m_edtHole[i].SetReceivedFlag( 3 );
		m_edtHole[i].MoveWindow(rect);

		strTitle.Format(_T("%.2f"), m_dHoleSet[i]);
		m_edtHole[i].SetWindowText( (LPCTSTR)strTitle );

#ifndef __3RDAOD__
		rect.left += 85;
		rect.right = rect.left + 120;
		if (!m_edtAOMDelay[i].Create(dwStyle | WS_BORDER | dwType, rect, this, 0xffff))
		{
			TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
			return FALSE;
		}
		m_edtAOMDelay[i].SetFont(&m_fntEdit);
		m_edtAOMDelay[i].SetForeColor( BLACK_COLOR );
		m_edtAOMDelay[i].SetBackColor( WHITE_COLOR );
		m_edtAOMDelay[i].SetReceivedFlag( 3 );
		m_edtAOMDelay[i].MoveWindow(rect);

		strTitle.Format(_T("%.2f"), m_dAOMDelay[i]);
		m_edtAOMDelay[i].SetWindowText( (LPCTSTR)strTitle );

		rect.left += 125;
		rect.right = rect.left + 120;
		if (!m_edtAOMDuty[i].Create(dwStyle | WS_BORDER | dwType, rect, this, 0xffff))
		{
			TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
			return FALSE;
		}
		m_edtAOMDuty[i].SetFont(&m_fntEdit);
		m_edtAOMDuty[i].SetForeColor( BLACK_COLOR );
		m_edtAOMDuty[i].SetBackColor( WHITE_COLOR );
		m_edtAOMDuty[i].SetReceivedFlag( 3 );
		m_edtAOMDuty[i].MoveWindow(rect);

		strTitle.Format(_T("%.2f"), m_dAOMDuty[i]);
		m_edtAOMDuty[i].SetWindowText( (LPCTSTR)strTitle );

	#ifdef __USE_DUALBAND_EOCARD__
		rect.left += 125;
		rect.right = rect.left + 120;
		if (!m_edtMinFreq[i].Create(dwFreqStyle | WS_BORDER , rect, this, 0xffff))
		{
			TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
			return FALSE;
		}
		m_edtMinFreq[i].SetFont(&m_fntEdit);
		m_edtMinFreq[i].SetForeColor( BLACK_COLOR );
		m_edtMinFreq[i].SetBackColor( WHITE_COLOR );
		m_edtMinFreq[i].SetReceivedFlag( 3 );
		m_edtMinFreq[i].MoveWindow(rect);
		
		strTitle.Format(_T("%.2f"), m_dMinFreq[i]);
		m_edtMinFreq[i].SetWindowText( (LPCTSTR)strTitle );

		rect.left += 125;
		rect.right = rect.left + 120;
		if (!m_edtMaxFreq[i].Create(dwFreqStyle | WS_BORDER , rect, this, 0xffff))
		{
			TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
			return FALSE;
		}
		m_edtMaxFreq[i].SetFont(&m_fntEdit);
		m_edtMaxFreq[i].SetForeColor( BLACK_COLOR );
		m_edtMaxFreq[i].SetBackColor( WHITE_COLOR );
		m_edtMaxFreq[i].SetReceivedFlag( 3 );
		m_edtMaxFreq[i].MoveWindow(rect);
		
		strTitle.Format(_T("%.2f"), m_dMaxFreq[i]);
		m_edtMaxFreq[i].SetWindowText( (LPCTSTR)strTitle );
	#endif

		//
		rect.left = rt.left + (rt.right - rt.left) * (i / 5) + 10 +50;
		rect.top = rt.top + 30 + (i % 5) * 70 + 35 + 35;
		rect.right = rect.left + 255;
		rect.bottom = rect.top + 30;

		if (!m_edtAOMFilePath[i].Create(dwStyle | WS_BORDER | dwType, rect, this, 0xffff))
		{
			TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
			return FALSE;
		}
//		m_edtAOMFilePath[i].SetFont(&m_fntEdit);
		m_edtAOMFilePath[i].SetForeColor( BLACK_COLOR );
		m_edtAOMFilePath[i].SetBackColor( WHITE_COLOR );
		m_edtAOMFilePath[i].MoveWindow(rect);
		m_edtAOMFilePath[i].EnableWindow(FALSE);
		m_edtAOMFilePath[i].SetWindowText(m_cAOMFilePath[i]);

		rect.left += 260;
		rect.right = rect.left + 70;
		m_btnFileOpen[i].SetFont(&m_fntEdit);
		m_btnFileOpen[i].MoveWindow(rect);
		m_btnFileOpen[i].ShowWindow(SW_SHOW);
	#ifdef __USEAOD__
		if(m_nUserLevel < 3) // Operator
		{
			m_btnFileOpen[i].ShowWindow(SW_HIDE);
		}
		else
		{
			m_edtAOMFilePath[i].ShowWindow(SW_HIDE);
			m_btnFileOpen[i].ShowWindow(SW_HIDE);
		}
	#else
		if(m_nUserLevel < 3) // Operator
		{
//			m_btnFileOpen[i].ShowWindow(SW_HIDE);
		}
		else
		{
			m_edtAOMFilePath[i].ShowWindow(SW_HIDE);
			m_btnFileOpen[i].ShowWindow(SW_HIDE);
		}
	#endif
#else
	#ifdef __USE_DUALBAND_EOCARD__
		rect.left += 90;
		rect.right = rect.left + 120;
		if (!m_edtMaxFreq[i].Create(dwFreqStyle | WS_BORDER, rect, this, 0xffff))
		{
			TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
			return FALSE;
		}
		m_edtMaxFreq[i].SetFont(&m_fntEdit);
		m_edtMaxFreq[i].SetForeColor( BLACK_COLOR );
		m_edtMaxFreq[i].SetBackColor( WHITE_COLOR );
		m_edtMaxFreq[i].SetReceivedFlag( 3 );
		m_edtMaxFreq[i].MoveWindow(rect);
		
		strTitle.Format(_T("%.2f"), m_dMaxFreq[i]);
		m_edtMaxFreq[i].SetWindowText( (LPCTSTR)strTitle );
#if defined (__OSAN_LG_2013__) || defined (__OSAN_LG__)
		rect.left += 130;
		rect.right = rect.left + 30;

		m_chkParam[i].SetCheck(FALSE);
		m_chkParam[i].MoveWindow(rect);
		m_chkParam[i].ShowWindow(SW_SHOW);
#endif
	#endif
#endif

		//
		//----------------- offset 
		rect.left = rt.left + (rt.right - rt.left) * (i / 5) + 5 ;
		rect.top = rt.top + 30 + (i % 5) * 70 + 35 + 35;
		rect.right = rect.left + 95;
		rect.bottom = rect.top + 20;
		
		if (!m_stcDutyOffset[i].Create(_T("DutyOffset"), dwStyle, rect, this, 0xffff))
		{
			TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
			return FALSE;
		}
//		m_stcDutyOffset[i].SetFont(&m_fntStatic);
		m_stcDutyOffset[i].MoveWindow(rect);

		rect.left += 100;
		rect.right = rect.left + 45;
		if (!m_edtDutyOffsetM[i].Create(dwStyle | WS_BORDER, rect, this, 0xffff))
		{
			TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
			return FALSE;
		}
//		m_edtDutyOffsetM[i].SetFont(&m_fntEdit);
		m_edtDutyOffsetM[i].SetForeColor( BLACK_COLOR );
		m_edtDutyOffsetM[i].SetBackColor( WHITE_COLOR );
		m_edtDutyOffsetM[i].SetReceivedFlag( 3 );
		m_edtDutyOffsetM[i].MoveWindow(rect);
		strTitle.Format(_T("%.2f"), m_dDutyOffsetM[i]);
		m_edtDutyOffsetM[i].SetWindowText( (LPCTSTR)strTitle );
		
#ifndef __3RDAOD__
		rect.left += 50;
		rect.right = rect.left + 45;
		if (!m_edtDutyOffsetS[i].Create(dwStyle | WS_BORDER, rect, this, 0xffff))
		{
			TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
			return FALSE;
		}
//		m_edtDutyOffsetS[i].SetFont(&m_fntEdit);
		m_edtDutyOffsetS[i].SetForeColor( BLACK_COLOR );
		m_edtDutyOffsetS[i].SetBackColor( WHITE_COLOR );
		m_edtDutyOffsetS[i].SetReceivedFlag( 3 );
		m_edtDutyOffsetS[i].MoveWindow(rect);
		strTitle.Format(_T("%.2f"), m_dDutyOffsetS[i]);
		m_edtDutyOffsetS[i].SetWindowText( (LPCTSTR)strTitle );

		rect.left += 50;
		rect.right = rect.left + 75;
		if (!m_stcVoltage[i].Create(_T("Vol.Offset(%)"), dwStyle, rect, this, 0xffff))
		{
			TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
			return FALSE;
		}
//		m_stcVoltage[i].SetFont(&m_fntStatic);
		m_stcVoltage[i].MoveWindow(rect);

		rect.left += 80;
		rect.right = rect.left + 45;
		if (!m_edtVoltageM[i].Create(dwStyle | WS_BORDER, rect, this, 0xffff))
		{
			TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
			return FALSE;
		}
//		m_edtVoltageM[i].SetFont(&m_fntEdit);
		m_edtVoltageM[i].SetForeColor( BLACK_COLOR );
		m_edtVoltageM[i].SetBackColor( WHITE_COLOR );
		m_edtVoltageM[i].SetReceivedFlag( 3 );
		m_edtVoltageM[i].MoveWindow(rect);
		strTitle.Format(_T("%.2f"), m_dVoltageM[i]);
		m_edtVoltageM[i].SetWindowText( (LPCTSTR)strTitle );

		rect.left += 50;
		rect.right = rect.left + 45;
		if (!m_edtVoltageS[i].Create(dwStyle | WS_BORDER, rect, this, 0xffff))
		{
			TRACE0( "Failed to create child window in CDlgLaserBeamHoleSet.\n" );
			return FALSE;
		}
//		m_edtVoltageS[i].SetFont(&m_fntEdit);
		m_edtVoltageS[i].SetForeColor( BLACK_COLOR );
		m_edtVoltageS[i].SetBackColor( WHITE_COLOR );
		m_edtVoltageS[i].SetReceivedFlag( 3 );
		m_edtVoltageS[i].MoveWindow(rect);
		strTitle.Format(_T("%.2f"), m_dVoltageS[i]);
		m_edtVoltageS[i].SetWindowText( (LPCTSTR)strTitle );
		//---------- offset end
	#ifndef __USEAOD__
//		m_stcDutyOffset[i].ShowWindow(SW_HIDE);
//		m_edtDutyOffsetM[i].ShowWindow(SW_HIDE);
		m_edtDutyOffsetS[i].ShowWindow(SW_HIDE);
		m_stcVoltage[i].ShowWindow(SW_HIDE);
		m_edtVoltageM[i].ShowWindow(SW_HIDE);
		m_edtVoltageS[i].ShowWindow(SW_HIDE);
	#endif
#endif
		int nBlockLevel = 0;
#ifdef __ANSAN_KCC__
		nBlockLevel = 1;
#elif defined __PUSAN_LAVIA__
		nBlockLevel = 2;
#else
		nBlockLevel = 3;
#endif
		if(m_nUserLevel < nBlockLevel) // Operator
		{
			m_stcDutyOffset[i].ShowWindow(SW_HIDE);
			m_edtDutyOffsetM[i].ShowWindow(SW_HIDE);

#ifndef __3RDAOD__
			m_edtDutyOffsetS[i].ShowWindow(SW_HIDE);
			
			m_stcVoltage[i].ShowWindow(SW_HIDE);
			m_edtVoltageM[i].ShowWindow(SW_HIDE);
			m_edtVoltageS[i].ShowWindow(SW_HIDE);
#endif
		}

	#ifdef __USE_DUALBAND_EOCARD__
		if(m_nUserLevel < 1) // Operator
		{
//			m_edtMinFreq[i].EnableWindow(FALSE);
			m_edtMaxFreq[i].EnableWindow(FALSE);
		}
	#endif

		if(i == 0)
		{
#ifdef __ANSAN_KCC__
			m_edtDutyOffsetM[i].EnableWindow(TRUE);
#endif
#ifdef __PUSAN_LAVIA__
			m_edtDutyOffsetM[i].EnableWindow(TRUE);
#endif
//			m_edtDutyOffsetM[i].EnableWindow(FALSE);
//			m_edtDutyOffsetM[i].SetWindowText( _T("0.00") );
#ifndef __3RDAOD__
			m_edtDutyOffsetS[i].EnableWindow(FALSE);
			m_edtDutyOffsetS[i].SetWindowText( _T("0.00") );

			m_edtVoltageM[i].EnableWindow(FALSE);
			m_edtVoltageM[i].SetWindowText( _T("0.00") );
			m_edtVoltageS[i].EnableWindow(FALSE);
			m_edtVoltageS[i].SetWindowText( _T("0.00") );
#endif
		}
		
		rect.left += (rect.right - rect.left);

	}

	rt.right += (rt.right - rt.left) * ((m_nCount - 1) / 5) + 10;

	CRect rect(rt.left, rt.top, rt.right - 10, rt.bottom - 10);
	GetDlgItem(IDC_STATIC_SETTING)->MoveWindow(rect);

	// Check Box
	CRect chkRt;
	((CWnd*)GetDlgItem(IDC_CHECK_APPLY_ALL))->GetWindowRect(chkRt);
	ScreenToClient(chkRt);
	((CWnd*)GetDlgItem(IDC_CHECK_APPLY_ALL))->SetWindowPos(&wndTop, 
									((rt.right + rt.left) / 2) - (chkRt.Width()/2),
									chkRt.top , chkRt.Width(), chkRt.Height(), SWP_SHOWWINDOW);

	((CWnd*)GetDlgItem(IDOK))->GetWindowRect(rect);
	ScreenToClient(rect);
	((CWnd*)GetDlgItem(IDOK))->SetWindowPos(
									&wndTop, 
									((rt.left+(rt.Width()/2))/2) - (rect.Width()/2),
									rect.top, 
									rect.Width(), 
									rect.Height(), 
									SWP_SHOWWINDOW
									);
	
	((CWnd*)GetDlgItem(IDCANCEL))->GetWindowRect(rect);
	ScreenToClient(rect);
	((CWnd*)GetDlgItem(IDCANCEL))->SetWindowPos(
									&wndTop, 
									(((rt.left+(rt.Width()/2))+rt.right)/2) - (rect.Width()/2),
									rect.top, 
									rect.Width(), 
									rect.Height(), 
									SWP_SHOWWINDOW
									);
	GetWindowRect(rt);
	rt.right += (rt.right - rt.left - 25) * ((m_nCount - 1) / 5);
	ClientToScreen(rt);
	MoveWindow(rt);
	CenterWindow(this);

	return TRUE;
}

int CDlgLaserBeamHoleSet::GetFireHole(double dHoleSet[], double dHoleAOMDelay[], double dHoleAOMDuty[], double dHoleMinFreq[], double dHoleMaxFreq[], TCHAR (*n)[255], double dDutyOffsetM[], double dDutyOffsetS[], double dVoltageM[], double dVoltageS[])
{
	memcpy( dHoleSet, m_dHoleSet, sizeof(double) * m_nCount );
	memcpy( dHoleAOMDelay, m_dAOMDelay, sizeof(double) * m_nCount );
	memcpy( dHoleAOMDuty, m_dAOMDuty, sizeof(double) * m_nCount );
	memcpy( dHoleMinFreq, m_dMinFreq, sizeof(double) * m_nCount );
	memcpy( dHoleMaxFreq, m_dMaxFreq, sizeof(double) * m_nCount );
	memcpy( n, m_cAOMFilePath, 255 * m_nCount);

	memcpy( dDutyOffsetM, m_dDutyOffsetM, sizeof(double) * m_nCount );
	memcpy( dDutyOffsetS, m_dDutyOffsetS, sizeof(double) * m_nCount );
	memcpy( dVoltageM, m_dVoltageM, sizeof(double) * m_nCount );
	memcpy( dVoltageS, m_dVoltageS, sizeof(double) * m_nCount );

	return m_nCount;
}

void CDlgLaserBeamHoleSet::SetFireHole(int nCount, double dHoleSet[], double dHoleAOMDelay[], double dHoleAOMDuty[], double dHoleMinFreq[], double dHoleMaxFreq[], TCHAR (*n)[255], double dDutyOffsetM[], double dDutyOffsetS[], double dVoltageM[], double dVoltageS[], BOOL bGlobalTool)
{
	m_nCount = nCount;
	memcpy( m_dHoleSet, dHoleSet, sizeof(double) * m_nCount );
	memcpy( m_dAOMDelay, dHoleAOMDelay, sizeof(double) * m_nCount );
	memcpy( m_dAOMDuty, dHoleAOMDuty, sizeof(double) * m_nCount );
	memcpy( m_dMinFreq, dHoleMinFreq, sizeof(double) * m_nCount );
	memcpy( m_dMaxFreq, dHoleMaxFreq, sizeof(double) * m_nCount );
	memcpy( m_cAOMFilePath, n, 255 * m_nCount);

	memcpy( m_dDutyOffsetM, dDutyOffsetM, sizeof(double) * m_nCount );
	memcpy( m_dDutyOffsetS, dDutyOffsetS, sizeof(double) * m_nCount );
	memcpy( m_dVoltageM, dVoltageM, sizeof(double) * m_nCount );
	memcpy( m_dVoltageS, dVoltageS, sizeof(double) * m_nCount );
	
	m_bGlobal = bGlobalTool;

	/*for (int i = 0; i < m_nCount; i++)
	{
		if (m_dHoleSet[i] < g_paramLaserMin.PulseWidth / 100.0
			|| m_dHoleSet[i] > g_paramLaserMax.PulseWidth / 100.0)
			m_dHoleSet[i] = 0.1;
	}*/
}

HBRUSH CDlgLaserBeamHoleSet::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
 	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
// 	
// 	// TODO: Change any attributes of the DC here
// 	if( CTLCOLOR_STATIC == nCtlColor )
// 	{
// 		if( GetDlgItem(IDC_STATIC_SETTING)->GetSafeHwnd() == pWnd->m_hWnd )
// 			pDC->SetTextColor( RGB(0, 0, 255) );
// 	}
// 
// 	// TODO: Return a different brush if the default is not desired
 	return hbr;
}

BOOL CDlgLaserBeamHoleSet::DestroyWindow() 
{
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();
	
	return CDialog::DestroyWindow();
}

void CDlgLaserBeamHoleSet::OnOK() 
{
	// TODO: Add extra validation here
	CString str;
	double dTemp;
	for (int i = 0 ; i < m_nCount ; i++)
	{
		
		m_edtHole[i].GetWindowText(str);
		dTemp = atof(str);
		m_dHoleSet[i] = dTemp;
#ifndef __3RDAOD__
		m_edtAOMDelay[i].GetWindowText(str);
		dTemp = atof(str);
		m_dAOMDelay[i] = dTemp;

		m_edtAOMDuty[i].GetWindowText(str);
		dTemp = atof(str);
		m_dAOMDuty[i] = dTemp;

		#ifdef __USE_DUALBAND_EOCARD__
			m_edtMinFreq[i].GetWindowText(str);
			dTemp = atof(str);
			m_dMinFreq[i] = dTemp;

			m_edtMaxFreq[i].GetWindowText(str);
			dTemp = atof(str);
			m_dMaxFreq[i] = dTemp;
		#else
			m_dMinFreq[i] = 1000;
			m_dMaxFreq[i] = 1000;
		#endif
#else
		#ifdef __USE_DUALBAND_EOCARD__
			m_edtMaxFreq[i].GetWindowText(str);
			dTemp = atof(str);
			m_dMaxFreq[i] = dTemp;
		#else
			m_dMaxFreq[i] = 1000;
		#endif
#endif
		m_edtDutyOffsetM[i].GetWindowText(str);
		dTemp = atof(str);
		m_dDutyOffsetM[i] = dTemp;
#ifndef __3RDAOD__
		m_edtDutyOffsetS[i].GetWindowText(str);
		dTemp = atof(str);
		m_dDutyOffsetS[i] = dTemp;

		m_edtVoltageM[i].GetWindowText(str);
		dTemp = atof(str);
		m_dVoltageM[i] = dTemp;

		m_edtVoltageS[i].GetWindowText(str);
		dTemp = atof(str);
		m_dVoltageS[i] = dTemp;

		if(m_dAOMDuty[i] + m_dAOMDelay[i] > m_dHoleSet[i] + 50)
		{
			ErrMessage(IDS_ERR_AOM);
			return;
		}

		m_edtAOMFilePath[i].GetWindowText(str);
		memcpy(m_cAOMFilePath[i], str, str.GetLength() + 1);
#endif
	}
	CDialog::OnOK();
}

void CDlgLaserBeamHoleSet::OnSetDuty()
{
	if(m_chkApplyAll.GetCheck())
	{
		CString szText;
		m_edtHole[0].GetWindowText(szText);
		for(int j = 0; j < m_nCount; j++)
		{
			m_dHoleSet[j] = ::atof(szText);
			m_edtHole[j].SetWindowText(szText);
		}

/*		m_edtAOMDelay[0].GetWindowText(szText);
		for(int j =  0; j < m_nCount; j++)
		{
			m_dAOMDelay[j] = ::atof(szText);
			m_edtAOMDelay[j].SetWindowText(szText);
		}

		m_edtAOMDuty[0].GetWindowText(szText);
		for(int j =  0; j < m_nCount; j++)
		{
			m_dAOMDuty[j] = ::atof(szText);
			m_edtAOMDuty[j].SetWindowText(szText);
		}

		#ifdef __USE_DUALBAND_EOCARD__
			m_edtMinFreq[0].GetWindowText(szText);
			for(int j = 0; j < m_nCount; j++)
			{
				m_dMinFreq[j] = ::atof(szText);
				m_edtMinFreq[j].SetWindowText(szText);
			}

			m_edtMaxFreq[0].GetWindowText(szText);
			for(int j = 0; j < m_nCount; j++)
			{
				m_dMaxFreq[j] = ::atof(szText);
				m_edtMaxFreq[j].SetWindowText(szText);
			}
		#else
			for(int j = 0; j < m_nCount; j++)
			{
				m_dMinFreq[j] = 1000;
			}
			for(int j = 0; j < m_nCount; j++)
			{
				m_dMaxFreq[j] = 1000;
			}
		#endif
*/
#ifndef __OSAN_LG_2013__
#ifndef __OSAN_LG__
		m_edtDutyOffsetM[0].GetWindowText(szText);
		for(int j =  0; j < m_nCount; j++)
		{
			m_dDutyOffsetM[j] = ::atof(szText);
			m_edtDutyOffsetM[j].SetWindowText(szText);
		}
#endif
#endif
	/*	
		m_edtDutyOffsetS[0].GetWindowText(szText);
		for(int j =  0; j < m_nCount; j++)
		{
			m_dDutyOffsetS[j] = ::atof(szText);
			m_edtDutyOffsetS[j].SetWindowText(szText);
		}
		
		m_edtdVoltageM[0].GetWindowText(szText);
		for(int j =  0; j < m_nCount; j++)
		{
			m_dVoltageM[j] = ::atof(szText);
			m_edtdVoltageM[j].SetWindowText(szText);
		}
		
		m_edtdVoltageS[0].GetWindowText(szText);
		for(int j =  0; j < m_nCount; j++)
		{
			m_dVoltageS[j] = ::atof(szText);
			m_edtdVoltageS[j].SetWindowText(szText);
		}
*/
/*		m_edtAOMFilePath[0].GetWindowText(szText);
		for(int j =  0; j < m_nCount; j++)
		{
			memcpy(m_cAOMFilePath[j], szText, szText.GetLength() + 1);
			m_edtAOMFilePath[j].SetWindowText(szText);
		}
*/
	}
	UpdateData();
}

void CDlgLaserBeamHoleSet::OnAOMOpen1()
{
	m_nAOMFileNo = 0;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OnAOMOpen2()
{
	m_nAOMFileNo = 1;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OnAOMOpen3()
{
	m_nAOMFileNo = 2;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OnAOMOpen4()
{
	m_nAOMFileNo = 3;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OnAOMOpen5()
{
	m_nAOMFileNo = 4;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OnAOMOpen6()
{
	m_nAOMFileNo = 5;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OnAOMOpen7()
{
	m_nAOMFileNo = 6;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OnAOMOpen8()
{
	m_nAOMFileNo = 7;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OnAOMOpen9()
{
	m_nAOMFileNo = 8;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OnAOMOpen10()
{
	m_nAOMFileNo = 9;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OnAOMOpen11()
{
	m_nAOMFileNo = 10;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OnAOMOpen12()
{
	m_nAOMFileNo = 11;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OnAOMOpen13()
{
	m_nAOMFileNo = 12;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OnAOMOpen14()
{
	m_nAOMFileNo = 13;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OnAOMOpen15()
{
	m_nAOMFileNo = 14;
	OpenAOMProfileFile();
}

void CDlgLaserBeamHoleSet::OpenAOMProfileFile()
{
	TCHAR BASED_CODE szFilter[] = _T("AOM File (*.aom)|*.aom|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.aom"), NULL, dwFlags, szFilter);

	CString strPath;
	m_edtAOMFilePath[m_nAOMFileNo].GetWindowText(strPath);
	int nLength = strPath.GetLength();
	int nIndex;
	if(nLength > 0)
	{
		nIndex = strPath.ReverseFind(_T('\\'));
		strPath = strPath.Left(nIndex);
	}
	else
		strPath = gEasyDrillerINI.m_clsDirPath.GetRootDir() + _T("AOM\\");

	dlg.m_ofn.lpstrInitialDir = (LPCTSTR)strPath;
	
	if(IDOK != dlg.DoModal())
	{
		return;
	}
	m_edtAOMFilePath[m_nAOMFileNo].SetWindowText(dlg.GetPathName());
}

void CDlgLaserBeamHoleSet::SetUserLevel(int nLevel)
{
	m_nUserLevel = nLevel;
}

void CDlgLaserBeamHoleSet::OnCheckParam()
{
	int nCheck = m_chkParam[0].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}

void CDlgLaserBeamHoleSet::OnCheckParam2()
{
	int nCheck = m_chkParam[1].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}

void CDlgLaserBeamHoleSet::OnCheckParam3()
{
	int nCheck = m_chkParam[2].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}

void CDlgLaserBeamHoleSet::OnCheckParam4()
{
	int nCheck = m_chkParam[3].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}

void CDlgLaserBeamHoleSet::OnCheckParam5()
{
	int nCheck = m_chkParam[4].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}

void CDlgLaserBeamHoleSet::OnCheckParam6()
{
	int nCheck = m_chkParam[5].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}

void CDlgLaserBeamHoleSet::OnCheckParam7()
{
	int nCheck = m_chkParam[6].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}

void CDlgLaserBeamHoleSet::OnCheckParam8()
{
	int nCheck = m_chkParam[7].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}

void CDlgLaserBeamHoleSet::OnCheckParam9()
{
	int nCheck = m_chkParam[8].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}

void CDlgLaserBeamHoleSet::OnCheckParam10()
{
	int nCheck = m_chkParam[9].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}

void CDlgLaserBeamHoleSet::OnCheckParam11()
{
	int nCheck = m_chkParam[10].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}

void CDlgLaserBeamHoleSet::OnCheckParam12()
{
	int nCheck = m_chkParam[11].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}

void CDlgLaserBeamHoleSet::OnCheckParam13()
{
	int nCheck = m_chkParam[12].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}

void CDlgLaserBeamHoleSet::OnCheckParam14()
{
	int nCheck = m_chkParam[13].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}

void CDlgLaserBeamHoleSet::OnCheckParam15()
{
	int nCheck = m_chkParam[14].GetCheck();
	if(nCheck)
	{
		for(int i = 0; i < m_nCount;i++)
		{
			if(!m_chkParam[i].GetCheck())
				break;
			if(i == m_nCount-1)
			{
				m_btnApply.EnableWindow(TRUE);
				m_btnCancel.EnableWindow(TRUE);
			}
		}
	}
	else
	{
		m_btnApply.EnableWindow(FALSE);
		m_btnCancel.EnableWindow(FALSE);
	}
}


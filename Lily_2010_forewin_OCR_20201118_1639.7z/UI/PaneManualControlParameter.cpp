// PaneManualControlParameter.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlParameter.h"
#include "DlgLaserBeamHoleSet.h"

#include "..\model\GlobalVariable.h"
#include "..\model\DProject.h"
#include "..\Model\DSystemINI.h"
#include "..\easydrillerdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlParameter

IMPLEMENT_DYNCREATE(CPaneManualControlParameter, CFormView)

CPaneManualControlParameter::CPaneManualControlParameter()
	: CFormView(CPaneManualControlParameter::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlParameter)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CPaneManualControlParameter::~CPaneManualControlParameter()
{
}

void CPaneManualControlParameter::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlParameter)
	DDX_Control(pDX, IDC_LIST_MAIN_TOOL_CODE, m_listMainTool);
	DDX_Control(pDX, IDC_LIST_SUB_TOOL_CODE, m_listSubTool);
	
	DDX_Control(pDX, IDC_COMBO_COLOR, m_cmbColor);
	DDX_Control(pDX, IDC_COMBO_SUB_TOOL_TYPE, m_cmbToolType);
	DDX_Control(pDX, IDC_COMBO_SUB_MASK, m_cmbMask);
	DDX_Control(pDX, IDC_COMBO_SUB_DRILL_METHOD, m_cmbDrillMethod);
	
	DDX_Control(pDX, IDC_BUTTON_SUB_SHOT_SETTING, m_btnSetting);
	DDX_Control(pDX, IDC_BUTTON_PARAM_UPDATE_MAIN, m_btnUpdateMain);
	DDX_Control(pDX, IDC_BUTTON_PARAM_UPDATE, m_btnUpdate);
	DDX_Control(pDX, IDC_BUTTON_PARAM_DELETE, m_btnDelete);
	DDX_Control(pDX, IDC_BUTTON_PARAM_ADD, m_btnAdd);
	DDX_Control(pDX, IDC_BUTTON_SUB_APERTURE_OPEN, m_btnFileOpen);
	DDX_Control(pDX, IDC_BUTTON_SUB_PROFILE_OPEN, m_btnScannerProfileOpen);
	
	DDX_Control(pDX, IDC_CHECK_USE_TOOL, m_chkUseTool);
	DDX_Control(pDX, IDC_CHECK_TOOL_ORDER, m_chkUseToolOrder);
	DDX_Control(pDX, IDC_CHECK_SUB_USE_APERTURE, m_chkUseAperture);
	
	DDX_Control(pDX, IDC_EDIT_TCODE_NO, m_edtMainTcode);
	DDX_Control(pDX, IDC_EDIT_SIZE, m_edtToolSize);
	DDX_Control(pDX, IDC_EDIT_SUB_TCODE_NO, m_edtSubNo);
	DDX_Control(pDX, IDC_EDIT_SUB_DRAW_STEP, m_edtDrawStep);
	DDX_Control(pDX, IDC_EDIT_SUB_JUMP_STEP, m_edtJumpStep);
	DDX_Control(pDX, IDC_EDIT_SUB_DRAW_STEP_PERIOD, m_edtDrawStepPeriod);
	DDX_Control(pDX, IDC_EDIT_SUB_JUMP_STEP_PERIOD, m_edtJumpStepPeriod);
	DDX_Control(pDX, IDC_EDIT_SUB_CORNER_DELAY, m_edtCornerDelay);
	DDX_Control(pDX, IDC_EDIT_SUB_JUMP_DELAY, m_edtJumpDelay);
	DDX_Control(pDX, IDC_EDIT_SUB_LINE_DELAY, m_edtLineDelay);	
	DDX_Control(pDX, IDC_EDIT_SUB_LASER_ON_DELAY, m_edtLaserOnDelay);
	DDX_Control(pDX, IDC_EDIT_SUB_LASER_OFF_DELAY, m_edtLaserOffDelay);
	DDX_Control(pDX, IDC_EDIT_SUB_FREQUENCY, m_edtFrequency);
	DDX_Control(pDX, IDC_EDIT_SUB_FPS, m_edtFPS);
	DDX_Control(pDX, IDC_EDIT_SUB_CURRENT, m_edtCurrent);	
	DDX_Control(pDX, IDC_EDIT_SUB_TOTAL_SHOT, m_edtTotalShot);
	DDX_Control(pDX, IDC_EDIT_SUB_BURST_SHOT, m_edtBurstShot);
	DDX_Control(pDX, IDC_EDIT_SUB_LEAD_IN, m_edtLeadIn);
	DDX_Control(pDX, IDC_EDIT_SUB_LEAD_OUT, m_edtLeadOut);	
	DDX_Control(pDX, IDC_EDIT_SUB_TABLE_SPEED, m_edtTableSpeed);	
	DDX_Control(pDX, IDC_EDIT_APERTURE_PATH, m_edtAperturePath);
	DDX_Control(pDX, IDC_EDIT_PROFILE_PATH, m_edtScannerProfilePath);
	DDX_Control(pDX, IDC_EDIT_SUB_APERTURE_BURST, m_edtApertureBurst);
	DDX_Control(pDX, IDC_EDIT_SUB_THERMAL_TRACK, m_edtThermalTrack);
	DDX_Control(pDX, IDC_EDIT_SUB_Z_OFFSET, m_edtZOffset);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlParameter, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlParameter)
	ON_NOTIFY(NM_CLICK, IDC_LIST_MAIN_TOOL_CODE, OnClickListMainToolCode)
	ON_NOTIFY(NM_CLICK, IDC_LIST_SUB_TOOL_CODE, OnClickListSubToolCode)
	ON_CBN_SELCHANGE(IDC_COMBO_COLOR, OnSelChangeComboColor)
	ON_CBN_SELCHANGE(IDC_COMBO_SUB_DRILL_METHOD, OnSelChangeComboDrillMethod)
	ON_CBN_SELCHANGE(IDC_COMBO_SUB_TOOL_TYPE, OnSelChangeComboToolType)
	ON_CBN_SELCHANGE(IDC_COMBO_SUB_MASK, OnSelChangeComboMask)
	ON_BN_CLICKED(IDC_BUTTON_SUB_APERTURE_OPEN, OnButtonApertureOpen)
	ON_BN_CLICKED(IDC_BUTTON_SUB_SHOT_SETTING, OnButtonSetting)
	ON_BN_CLICKED(IDC_BUTTON_PARAM_ADD, OnButtonParamAdd)
	ON_BN_CLICKED(IDC_BUTTON_PARAM_DELETE, OnButtonParamDelete)
	ON_BN_CLICKED(IDC_BUTTON_PARAM_UPDATE, OnButtonParamUpdate)
	ON_BN_CLICKED(IDC_BUTTON_PARAM_UPDATE_MAIN, OnButtonParamUpdateMain)
	ON_BN_CLICKED(IDC_CHECK_USE_TOOL, OnCheckUseTool)
	ON_BN_CLICKED(IDC_CHECK_TOOL_ORDER, OnCheckUseToolOrder)
	ON_BN_CLICKED(IDC_CHECK_SUB_USE_APERTURE, OnCheckUseAperture)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_SUB_PROFILE_OPEN, OnButtonSubProfileOpen)
	ON_EN_CHANGE(IDC_EDIT_SUB_TOTAL_SHOT, OnChangeEditSubTotalShot)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlParameter diagnostics

#ifdef _DEBUG
void CPaneManualControlParameter::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlParameter::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlParameter message handlers
void CPaneManualControlParameter::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitListControl();
	InitStaticControl();
	InitBtnControl();
	InitComboControl();
	InitEditControl();

	OnCheckUseTool();

	memset(&m_dDuty, 0, sizeof(m_dDuty));

	m_bUseTool = FALSE;
	m_bToolOrder = FALSE;
	m_bUseAperture = FALSE;
}

BOOL CPaneManualControlParameter::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneManualControlParameter::InitListControl()
{
	// Set List Font
	m_fntList.CreatePointFont(130, _T("Arial Bold"));
	
	m_listMainTool.SetFont( &m_fntList );
	
	int nMaxColumnNum = 2;
	LV_COLUMN lvcolumn;
	CString strText;
	TCHAR szText[256] = {0,};
	
	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_CENTER;
	
	for(int i = 0 ; i < nMaxColumnNum ; i++ )
	{
		switch( i )
		{
		case 0 :
			strText.Format(_T("T-Code"));
			lvcolumn.cx = 70;
			break;
		case 1 :
			strText.Format(_T("Color"));
			lvcolumn.cx = 115;
			break;
		}
		
		_stprintf_s( szText, _T("%s"), strText );
		lvcolumn.pszText = szText;
		lvcolumn.iSubItem = i;
		
		m_listMainTool.InsertColumn(i, &lvcolumn);
	}

	DWORD dwStyle = m_listMainTool.GetStyle();
	dwStyle |= LVS_EX_FULLROWSELECT;
	dwStyle |= LVS_EX_GRIDLINES;
	
	m_listMainTool.SetExtendedStyle( dwStyle );

	m_listMainTool.DeleteAllItems();
	
	LVITEM lvItem;
	lvItem.mask = LVIF_TEXT|LVIF_PARAM;
	lvItem.lParam = 1;
	lvItem.state = 0;
	lvItem.stateMask = LVIS_SELECTED;
	
	for(int i = 0; i<MAX_PARAM_TOOL; i++)
	{
		//Tool No
		lvItem.iItem = i;
		lvItem.iSubItem = 0;
		strText.Format(_T("%d"), i+1);
		lvItem.pszText = (LPSTR)(LPCSTR)strText;
		m_listMainTool.InsertItem(&lvItem);
		
		//Color
		lvItem.iItem = i;
		lvItem.iSubItem = 1;
		GetColor(0, strText);
		lvItem.pszText = (LPSTR)(LPCSTR)strText;
		m_listMainTool.InsertItem(&lvItem);
	}

	m_listSubTool.SetFont( &m_fntList );
	
	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_CENTER;
	
	strText.Format(_T("Sub No"));
	
	_stprintf_s( szText, "%s", strText );
	lvcolumn.pszText = szText;
	lvcolumn.iSubItem = 0;
	lvcolumn.cx = 170;
	
	m_listSubTool.InsertColumn(0, &lvcolumn);
	
	dwStyle = m_listSubTool.GetStyle();
	dwStyle |= LVS_EX_FULLROWSELECT;
	dwStyle |= LVS_EX_GRIDLINES;
	
	m_listSubTool.SetExtendedStyle( dwStyle );
}

void CPaneManualControlParameter::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	
	// Shot Count Setting
	m_btnSetting.SetFont( &m_fntBtn );
	m_btnSetting.SetFlat( FALSE );
	m_btnSetting.EnableBallonToolTip();
	m_btnSetting.SetToolTipText( _T("Shot Count Setting") );
	m_btnSetting.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSetting.SetBtnCursor(IDC_HAND_1);

	// Aperture File Open
	m_btnFileOpen.SetFont( &m_fntBtn );
	m_btnFileOpen.SetFlat( FALSE );
	m_btnFileOpen.EnableBallonToolTip();
	m_btnFileOpen.SetToolTipText( _T("Aperture File Open") );
	m_btnFileOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnFileOpen.SetBtnCursor(IDC_HAND_1);

	// Scanner move profile File Open
	m_btnScannerProfileOpen.SetFont( &m_fntBtn );
	m_btnScannerProfileOpen.SetFlat( FALSE );
	m_btnScannerProfileOpen.EnableBallonToolTip();
	m_btnScannerProfileOpen.SetToolTipText( _T("Scanner Move Profile File Open") );
	m_btnScannerProfileOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnScannerProfileOpen.SetBtnCursor(IDC_HAND_1);

	// Param Add
	m_btnAdd.SetFont( &m_fntBtn );
	m_btnAdd.SetFlat( FALSE );
	m_btnAdd.EnableBallonToolTip();
	m_btnAdd.SetToolTipText( _T("Add Parameter") );
	m_btnAdd.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnAdd.SetBtnCursor(IDC_HAND_1);

	// Param Delete
	m_btnDelete.SetFont( &m_fntBtn );
	m_btnDelete.SetFlat( FALSE );
	m_btnDelete.EnableBallonToolTip();
	m_btnDelete.SetToolTipText( _T("Delete Parameter") );
	m_btnDelete.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnDelete.SetBtnCursor(IDC_HAND_1);

	// Param Update
	m_btnUpdate.SetFont( &m_fntBtn );
	m_btnUpdate.SetFlat( FALSE );
	m_btnUpdate.EnableBallonToolTip();
	m_btnUpdate.SetToolTipText( _T("Update Parameter") );
	m_btnUpdate.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUpdate.SetBtnCursor(IDC_HAND_1);

	// Param Update Main
	m_btnUpdateMain.SetFont( &m_fntBtn );
	m_btnUpdateMain.SetFlat( FALSE );
	m_btnUpdateMain.EnableBallonToolTip();
	m_btnUpdateMain.SetToolTipText( _T("Update Main Paramater") );
	m_btnUpdateMain.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUpdateMain.SetBtnCursor(IDC_HAND_1);
	
	// Use Aperture
	m_chkUseAperture.SetFont( &m_fntBtn );
	m_chkUseAperture.SetImageOrg( 10, 3 );
	m_chkUseAperture.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseAperture.EnableBallonToolTip();
	m_chkUseAperture.SetToolTipText( _T("Use Aperture") );
	m_chkUseAperture.SetBtnCursor(IDC_HAND_1);
	m_chkUseAperture.EnableWindow(TRUE);

	// Use Tool
	m_chkUseTool.SetFont( &m_fntBtn );
	m_chkUseTool.SetImageOrg( 10, 3 );
	m_chkUseTool.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseTool.EnableBallonToolTip();
	m_chkUseTool.SetToolTipText( _T("Use Tool") );
	m_chkUseTool.SetBtnCursor(IDC_HAND_1);
	m_chkUseTool.EnableWindow(TRUE);

	// ToolOrder
	m_chkUseToolOrder.SetFont( &m_fntBtn );
	m_chkUseToolOrder.SetImageOrg( 10, 3 );
	m_chkUseToolOrder.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseToolOrder.EnableBallonToolTip();
	m_chkUseToolOrder.SetToolTipText( _T("Tool Order") );
	m_chkUseToolOrder.SetBtnCursor(IDC_HAND_1);
	m_chkUseToolOrder.EnableWindow(TRUE);
}

void CPaneManualControlParameter::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");
	m_fntEdit2.CreatePointFont(100, "Arial Bold");
	
	// T-Code No
	m_edtMainTcode.SetFont( &m_fntEdit );
	m_edtMainTcode.SetForeColor( BLACK_COLOR );
	m_edtMainTcode.SetBackColor( WHITE_COLOR );
	m_edtMainTcode.SetReceivedFlag( 1 ); // Integer
	m_edtMainTcode.EnableWindow( FALSE );
	
	// Tool Size
	m_edtToolSize.SetFont( &m_fntEdit );
	m_edtToolSize.SetForeColor( BLACK_COLOR );
	m_edtToolSize.SetBackColor( WHITE_COLOR );
	m_edtToolSize.SetReceivedFlag( 1 ); // Integer
	m_edtToolSize.SetWindowText( _T("0") );
	
	// Sub Tool No
	m_edtSubNo.SetFont( &m_fntEdit );
	m_edtSubNo.SetForeColor( BLACK_COLOR );
	m_edtSubNo.SetBackColor( WHITE_COLOR );
	m_edtSubNo.SetReceivedFlag( 1 ); // Integer
	m_edtSubNo.EnableWindow( FALSE );
	
	// Draw Step
	m_edtDrawStep.SetFont( &m_fntEdit );
	m_edtDrawStep.SetForeColor( BLACK_COLOR );
	m_edtDrawStep.SetBackColor( WHITE_COLOR );
	m_edtDrawStep.SetReceivedFlag( 1 ); // Integer
	m_edtDrawStep.SetWindowText( _T("25") );

	// Jump Step
	m_edtJumpStep.SetFont( &m_fntEdit );
	m_edtJumpStep.SetForeColor( BLACK_COLOR );
	m_edtJumpStep.SetBackColor( WHITE_COLOR );
	m_edtJumpStep.SetReceivedFlag( 1 ); // Integer
	m_edtJumpStep.SetWindowText( _T("50") );
	
	// Draw Step Period
	m_edtDrawStepPeriod.SetFont( &m_fntEdit );
	m_edtDrawStepPeriod.SetForeColor( BLACK_COLOR );
	m_edtDrawStepPeriod.SetBackColor( WHITE_COLOR );
	m_edtDrawStepPeriod.SetReceivedFlag( 1 ); // Integer
	m_edtDrawStepPeriod.SetWindowText( _T("20") );

	// Jump Step Period
	m_edtJumpStepPeriod.SetFont( &m_fntEdit );
	m_edtJumpStepPeriod.SetForeColor( BLACK_COLOR );
	m_edtJumpStepPeriod.SetBackColor( WHITE_COLOR );
	m_edtJumpStepPeriod.SetReceivedFlag( 1 ); // Integer
	m_edtJumpStepPeriod.SetWindowText( _T("20") );

	// Corner Delay
	m_edtCornerDelay.SetFont( &m_fntEdit );
	m_edtCornerDelay.SetForeColor( BLACK_COLOR );
	m_edtCornerDelay.SetBackColor( WHITE_COLOR );
	m_edtCornerDelay.SetReceivedFlag( 1 ); // Integer
	m_edtCornerDelay.SetWindowText( _T("20") );
	
	// Jump Delay
	m_edtJumpDelay.SetFont( &m_fntEdit );
	m_edtJumpDelay.SetForeColor( BLACK_COLOR );
	m_edtJumpDelay.SetBackColor( WHITE_COLOR );
	m_edtJumpDelay.SetReceivedFlag( 1 ); // Integer
	m_edtJumpDelay.SetWindowText( _T("350") );

	// Line Delay
	m_edtLineDelay.SetFont( &m_fntEdit );
	m_edtLineDelay.SetForeColor( BLACK_COLOR );
	m_edtLineDelay.SetBackColor( WHITE_COLOR );
	m_edtLineDelay.SetReceivedFlag( 1 ); // Integer
	m_edtLineDelay.SetWindowText( _T("200") );

	// Laser On Delay
	m_edtLaserOnDelay.SetFont( &m_fntEdit );
	m_edtLaserOnDelay.SetForeColor( BLACK_COLOR );
	m_edtLaserOnDelay.SetBackColor( WHITE_COLOR );
	m_edtLaserOnDelay.SetReceivedFlag( 1 ); // Integer
	m_edtLaserOnDelay.SetWindowText( _T("350") );
	
	// Laser Off Delay
	m_edtLaserOffDelay.SetFont( &m_fntEdit );
	m_edtLaserOffDelay.SetForeColor( BLACK_COLOR );
	m_edtLaserOffDelay.SetBackColor( WHITE_COLOR );
	m_edtLaserOffDelay.SetReceivedFlag( 1 ); // Integer
	m_edtLaserOffDelay.SetWindowText( _T("250") );

	// Frequency
	m_edtFrequency.SetFont( &m_fntEdit );
	m_edtFrequency.SetForeColor( BLACK_COLOR );
	m_edtFrequency.SetBackColor( WHITE_COLOR );
	m_edtFrequency.SetReceivedFlag( 1 ); // Integer
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		m_edtFrequency.SetWindowText( _T("90000") );
	else
		m_edtFrequency.SetWindowText( _T("1000") );

	// FPS
	m_edtFPS.SetFont( &m_fntEdit );
	m_edtFPS.SetForeColor( BLACK_COLOR );
	m_edtFPS.SetBackColor( WHITE_COLOR );
	m_edtFPS.SetReceivedFlag( 1 ); // Integer
	m_edtFPS.SetWindowText( _T("0") );

	// Current
	m_edtCurrent.SetFont( &m_fntEdit );
	m_edtCurrent.SetForeColor( BLACK_COLOR );
	m_edtCurrent.SetBackColor( WHITE_COLOR );
	m_edtCurrent.SetReceivedFlag( 3 ); // Integer
	m_edtCurrent.SetWindowText( _T("90.0") );

	// TotalShot
	m_edtTotalShot.SetFont( &m_fntEdit );
	m_edtTotalShot.SetForeColor( BLACK_COLOR );
	m_edtTotalShot.SetBackColor( WHITE_COLOR );
	m_edtTotalShot.SetReceivedFlag( 1 ); // Integer
	m_edtTotalShot.SetWindowText( _T("1") );

	// BurstShot
	m_edtBurstShot.SetFont( &m_fntEdit );
	m_edtBurstShot.SetForeColor( BLACK_COLOR );
	m_edtBurstShot.SetBackColor( WHITE_COLOR );
	m_edtBurstShot.SetReceivedFlag( 1 ); // Integer
	m_edtBurstShot.SetWindowText( _T("0") );

	// Lead In
	m_edtLeadIn.SetFont( &m_fntEdit );
	m_edtLeadIn.SetForeColor( BLACK_COLOR );
	m_edtLeadIn.SetBackColor( WHITE_COLOR );
	m_edtLeadIn.SetReceivedFlag( 1 ); // Integer
	m_edtLeadIn.SetWindowText( _T("50") );

	// Lead Out
	m_edtLeadOut.SetFont( &m_fntEdit );
	m_edtLeadOut.SetForeColor( BLACK_COLOR );
	m_edtLeadOut.SetBackColor( WHITE_COLOR );
	m_edtLeadOut.SetReceivedFlag( 1 ); // Integer
	m_edtLeadOut.SetWindowText( _T("50") );

	// TableSpeed
	m_edtTableSpeed.SetFont( &m_fntEdit );
	m_edtTableSpeed.SetForeColor( BLACK_COLOR );
	m_edtTableSpeed.SetBackColor( WHITE_COLOR );
	m_edtTableSpeed.SetReceivedFlag( 1 ); // Integer
	m_edtTableSpeed.SetWindowText( _T("2000") );
	
	// Aperture File Path
	m_edtAperturePath.SetFont( &m_fntEdit2 );
	m_edtAperturePath.SetForeColor( BLACK_COLOR );
	m_edtAperturePath.SetBackColor( ::GetSysColor(COLOR_BTNFACE) );
	m_edtAperturePath.SetWindowText( _T("") );
	m_edtAperturePath.EnableWindow( FALSE );

	// Scanner Move Profile File Path
	m_edtScannerProfilePath.SetFont( &m_fntEdit2 );
	m_edtScannerProfilePath.SetForeColor( BLACK_COLOR );
	m_edtScannerProfilePath.SetBackColor( ::GetSysColor(COLOR_BTNFACE) );
	m_edtScannerProfilePath.SetWindowText( _T("") );
	m_edtScannerProfilePath.EnableWindow( FALSE );

	// Aperture Burst Shot
	m_edtApertureBurst.SetFont( &m_fntEdit );
	m_edtApertureBurst.SetForeColor( BLACK_COLOR );
	m_edtApertureBurst.SetBackColor( WHITE_COLOR );
	m_edtApertureBurst.SetReceivedFlag( 1 ); // Integer
	m_edtApertureBurst.SetWindowText( _T("1") );

	// Thermal Track
	m_edtThermalTrack.SetFont( &m_fntEdit );
	m_edtThermalTrack.SetForeColor( BLACK_COLOR );
	m_edtThermalTrack.SetBackColor( WHITE_COLOR );
	m_edtThermalTrack.SetReceivedFlag( 1 ); // Integer
	m_edtThermalTrack.SetWindowText( _T("2525") );

	// Z Offset
	m_edtZOffset.SetFont( &m_fntEdit );
	m_edtZOffset.SetForeColor( BLACK_COLOR );
	m_edtZOffset.SetBackColor( WHITE_COLOR );
	m_edtZOffset.SetReceivedFlag( 3 ); // Integer
	m_edtZOffset.SetWindowText( _T("0.0") );
}

void CPaneManualControlParameter::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	
	GetDlgItem(IDC_STATIC_TCODE_NO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_COLOR)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_TCODE_NO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_TOOL_TYPE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_DRAW_STEP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_JUMP_STEP)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_DRAW_STEP_PERIOD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_JUMP_STEP_PERIOD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_CORNER_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_JUMP_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_LINE_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_LASER_ON_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_LASER_OFF_DELAY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_FREQUENCY)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_FPS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_CURRENT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_MASK_NO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_DRILL_METHOD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_TOTAL_SHOT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_BURST_SHOT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_LEAD_IN)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_LEAD_OUT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_TABLE_SPEED)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_APERTURE_PATH)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_PROFILE_PATH)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_APERTURE_BURST)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_THERMAL_TRACK)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SUB_Z_OFFSET)->SetFont( &m_fntStatic );
}

void CPaneManualControlParameter::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(130, "Arial Bold");
	
	m_cmbMask.SetFont( &m_fntCombo );
	m_cmbMask.SetCurSel( 0 );

	m_cmbColor.SetFont( &m_fntCombo );
	m_cmbColor.SetCurSel( 0 );
	
	m_cmbDrillMethod.SetFont( &m_fntCombo );
	m_cmbDrillMethod.SetCurSel( 0 );

	m_cmbToolType.SetFont( &m_fntCombo );
	m_cmbToolType.SetCurSel( 0 );
}

void CPaneManualControlParameter::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntCombo.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntList.DeleteObject();
	m_fntStatic.DeleteObject();
	
	CFormView::OnDestroy();
}

BOOL CPaneManualControlParameter::GetData(GlobalVariable &tempGlobal)
{
//	for(int i=0; i<MAX_PARAM_TOOL; i++)
//	{
//		tempGlobal.m_pToolCode[i] = m_pToolCode[i];
//	}
//  set data���� �̹� pointer�� ���� �߱� ������ ���� �޾ƿ� �ʿ� ����
	return TRUE;
}

BOOL CPaneManualControlParameter::SetData(GlobalVariable& mGlobal)
{ 
	m_listMainTool.DeleteAllItems();
	m_listSubTool.DeleteAllItems();
	memset(&m_pToolCode, 0, sizeof(m_pToolCode));
	for(int i = 0; i < MAX_PARAM_TOOL; i++)
	{
		m_pToolCode[i] = mGlobal.m_pToolCode[i];
		if(m_pToolCode[i]->m_bUseTool)
			AddParameter(i);
	}
	
	ChangeDisplay(0, 0);
	UpdateList(0);
	
	m_listMainTool.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);
	m_listMainTool.SetFocus();
	m_listMainTool.EnsureVisible( 0, TRUE );
	m_listMainTool.SetSelectionMark(0);

	m_listSubTool.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);
	m_listSubTool.EnsureVisible( 0, TRUE );
	m_listSubTool.SetSelectionMark(0);

	return TRUE;
}

void CPaneManualControlParameter::AddParameter(int nMainIndex)
{
	int nIndex;
	LV_ITEM lvItem;
	CString strText;
	
	lvItem.mask = LVIF_TEXT|LVIF_PARAM;
	lvItem.iItem = m_listMainTool.GetItemCount();
	lvItem.lParam = 1;
	lvItem.state = 0;
	lvItem.stateMask = LVIS_SELECTED;
	
	//Tool No
	lvItem.iSubItem = 0;
	strText.Format(_T("%d"), nMainIndex);
	lvItem.pszText = (LPSTR)(LPCSTR)strText;
	nIndex = m_listMainTool.InsertItem(&lvItem);

	strText.Format(_T("%d"), nMainIndex);
	m_listMainTool.SetItemText(nIndex, 0, (LPSTR)(LPCSTR)strText);

	GetColor(m_pToolCode[nMainIndex]->m_nToolColor, strText);
	m_listMainTool.SetItemText(nIndex, 1, (LPSTR)(LPCSTR)strText);
}

void CPaneManualControlParameter::ChangeDisplay(int nMainIndex, int nSubIndex)
{
	CString str;
	SUBTOOLDATA subData;

	CToolCodeList* pToolCode;
	int nListIndex = GetUseToolIndex(nMainIndex);

	if(nListIndex == -1)
		return;

	pToolCode = m_pToolCode[nListIndex];

	int i= -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}

	if(i==-1)
	{
		m_listSubTool.DeleteAllItems();

		str.Format(_T("%d"), nListIndex);
		m_edtMainTcode.SetWindowText(str);
		
		m_chkUseTool.SetCheck(pToolCode->m_bUseTool);
		
		m_cmbColor.SetCurSel(pToolCode->m_nToolColor);
		
		str.Format(_T("%d"), pToolCode->m_nToolSize);
		m_edtToolSize.SetWindowText(str);
		
		m_chkUseToolOrder.SetCheck(pToolCode->m_bToolOrder);

		UpdateData(FALSE);

		return;
	}
	
	subData = pToolCode->m_SubToolData.GetAt(pos);

	OnCheckUseTool();

	for(int i = 0; i < MAX_BEAM_HOLE; i++)
		m_dDuty[i] = subData.dShotDuty[i];
	
	str.Format(_T("%d"), nListIndex);
	m_edtMainTcode.SetWindowText(str);

	m_chkUseTool.SetCheck(pToolCode->m_bUseTool);

	m_bUseTool = pToolCode->m_bUseTool;

	m_cmbColor.SetCurSel(pToolCode->m_nToolColor);
	
	str.Format(_T("%d"), pToolCode->m_nToolSize);
	m_edtToolSize.SetWindowText(str);

	m_chkUseToolOrder.SetCheck(pToolCode->m_bToolOrder);

	m_bToolOrder = pToolCode->m_bToolOrder;

	str.Format(_T("%d"), subData.nSubToolNo);
	m_edtSubNo.SetWindowText(str);

	m_cmbToolType.SetCurSel(subData.nToolType);

	m_cmbMask.SetCurSel(subData.nMask);
	
	m_cmbDrillMethod.SetCurSel(subData.nShotMode);

	m_chkUseAperture.SetCheck(subData.bUseAperture);

	m_bUseAperture = subData.bUseAperture;

	str.Format(_T("%d"), subData.dDrawStep);
	m_edtDrawStep.SetWindowText(str);

	str.Format(_T("%d"), subData.nJumpStep);
	m_edtJumpStep.SetWindowText(str);

	str.Format(_T("%d"), subData.nDrawStepPeriod);
	m_edtDrawStepPeriod.SetWindowText(str);

	str.Format(_T("%d"), subData.nJumpStepPeriod);
	m_edtJumpStepPeriod.SetWindowText(str);

	str.Format(_T("%d"), subData.nCornerDelay);
	m_edtCornerDelay.SetWindowText(str);

	str.Format(_T("%d"), subData.nJumpDelay);
	m_edtJumpDelay.SetWindowText(str);

	str.Format(_T("%d"), subData.nLineDelay);
	m_edtLineDelay.SetWindowText(str);

	str.Format(_T("%d"), subData.nLaserOnDelay);
	m_edtLaserOnDelay.SetWindowText(str);

	str.Format(_T("%d"), subData.nLaserOffDelay);
	m_edtLaserOffDelay.SetWindowText(str);

	str.Format(_T("%d"), subData.nFrequency);
	m_edtFrequency.SetWindowText(str);

	str.Format(_T("%d"), subData.nFPS);
	m_edtFPS.SetWindowText(str);

	str.Format(_T("%.3f"), subData.dCurrent);
	m_edtCurrent.SetWindowText(str);

	str.Format(_T("%d"), subData.nTotalShot);
	m_edtTotalShot.SetWindowText(str);

	str.Format(_T("%d"), subData.nBurstShot);
	m_edtBurstShot.SetWindowText(str);

	str.Format(_T("%d"), subData.nLeadIn);
	m_edtLeadIn.SetWindowText(str);

	str.Format(_T("%d"), subData.nLeadOut);
	m_edtLeadOut.SetWindowText(str);

	str.Format(_T("%d"), subData.nTableSpeed);
	m_edtTableSpeed.SetWindowText(str);

	str.Format(_T("%s"), (CString)subData.cFilePath);
	m_edtAperturePath.SetWindowText(str);

//	str.Format(_T("%s"), (CString)subData.cMoveProfileFilePath);
//	m_edtScannerProfilePath.SetWindowText(str);

	str.Format(_T("%d"), subData.nApertureBurst);
	m_edtApertureBurst.SetWindowText(str);

	str.Format(_T("%d"), subData.nThermalTrack);
	m_edtThermalTrack.SetWindowText(str);

	str.Format(_T("%.3f"), subData.dZOffset);
	m_edtZOffset.SetWindowText(str);


	UpdateData(FALSE);
}

void CPaneManualControlParameter::ChangeDataMain(int nMainIndex)
{
	int nTempVal;
	CString str;

	int nListIndex = GetUseToolIndex(nMainIndex);
	if(nListIndex == -1)
		return;

	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	m_edtMainTcode.GetWindowText(str);
	nTempVal = atoi(str);
	pToolCode->m_nToolNo = nTempVal;

	pToolCode->m_bUseTool = m_chkUseTool.GetCheck();

	pToolCode->m_nToolColor = m_cmbColor.GetCurSel();

	m_edtToolSize.GetWindowText(str);
	nTempVal = atoi(str);
	pToolCode->m_nToolSize = nTempVal;

	pToolCode->m_bToolOrder = m_chkUseToolOrder.GetCheck();

	m_pToolCode[nListIndex] =  pToolCode;	
}

void CPaneManualControlParameter::ChangeData(int nMainIndex, int nSubIndex)
{
	int nTempVal;
	double dTempVal;
	CString str;

	int nListIndex = GetUseToolIndex(nMainIndex);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	int i = -1;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		i++;
		if(i == nSubIndex) break;
		pToolCode->m_SubToolData.GetNext(pos);
	}

	if(i == -1) return;

	subData = pToolCode->m_SubToolData.GetAt(pos);

	for(int i = 0; i < MAX_BEAM_HOLE; i++)
		subData.dShotDuty[i] = m_dDuty[i];

	m_edtMainTcode.GetWindowText(str);
	nTempVal = atoi(str);
	pToolCode->m_nToolNo = nTempVal;

	pToolCode->m_bUseTool = m_chkUseTool.GetCheck();

	pToolCode->m_nToolColor = m_cmbColor.GetCurSel();

	m_edtToolSize.GetWindowText(str);
	nTempVal = atoi(str);
	pToolCode->m_nToolSize = nTempVal;

	pToolCode->m_bToolOrder = m_chkUseToolOrder.GetCheck();

	m_edtSubNo.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nSubToolNo = nTempVal;

	subData.nToolType = m_cmbToolType.GetCurSel();

	subData.nMask = m_cmbMask.GetCurSel();

	subData.nShotMode = m_cmbDrillMethod.GetCurSel();

	subData.bUseAperture = m_chkUseAperture.GetCheck();

	m_edtDrawStep.GetWindowText(str);
	nTempVal = atoi(str);
	subData.dDrawStep = nTempVal;

	m_edtJumpStep.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nJumpStep = nTempVal;

	m_edtDrawStepPeriod.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nDrawStepPeriod = nTempVal;

	m_edtJumpStepPeriod.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nJumpStepPeriod = nTempVal;

	m_edtCornerDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nCornerDelay = nTempVal;

	m_edtJumpDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nJumpDelay = nTempVal;

	m_edtLineDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLineDelay = nTempVal;

	m_edtLaserOnDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLaserOnDelay = nTempVal;

	m_edtLaserOffDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLaserOffDelay = nTempVal;

	m_edtFrequency.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nFrequency = nTempVal;

	m_edtFPS.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nFPS = nTempVal;

	m_edtCurrent.GetWindowText(str);
	dTempVal = atof(str);
	subData.dCurrent = dTempVal;

	m_edtTotalShot.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nTotalShot = nTempVal;

	m_edtBurstShot.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nBurstShot = nTempVal;

	m_edtLeadIn.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLeadIn = nTempVal;

	m_edtLeadOut.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLeadOut = nTempVal;

	m_edtTableSpeed.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nTableSpeed = nTempVal;

	m_edtAperturePath.GetWindowText(str);
	strcpy_s(subData.cFilePath, str);

//	m_edtScannerProfilePath.GetWindowText(str);
//	strcpy_s(subData.cMoveProfileFilePath, str);

	m_edtApertureBurst.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nApertureBurst = nTempVal;

	m_edtThermalTrack.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nThermalTrack = nTempVal;

	m_edtZOffset.GetWindowText(str);
	dTempVal = atof(str);
	subData.dZOffset = dTempVal;

	if(!CheckSubTool(subData))
		return;

	pToolCode->m_SubToolData.SetAt(pos, subData);
	m_pToolCode[nListIndex] = pToolCode;
}

void CPaneManualControlParameter::UpdateList(int nMainIndex)
{
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	int nListIndex = GetUseToolIndex(nMainIndex);
	if(nListIndex == -1)
		return;

	pToolCode = m_pToolCode[nListIndex];

	CString strText;
	LVITEM lvItem;
	lvItem.iSubItem = 0;
	strText.Format(_T("%d"), nListIndex);
	lvItem.pszText = (LPSTR)(LPCSTR)strText;
	m_listMainTool.InsertItem(&lvItem);

	strText.Format(_T("%d"), nListIndex);
	m_listMainTool.SetItemText(nMainIndex, 0, (LPSTR)(LPCSTR)strText);
	
	GetColor(pToolCode->m_nToolColor, strText);
	m_listMainTool.SetItemText(nMainIndex, 1, (LPSTR)(LPCSTR)strText);

	m_listSubTool.DeleteAllItems();
	
	lvItem.mask = LVIF_TEXT|LVIF_PARAM;
	lvItem.lParam = 1;
	lvItem.state = 0;
	lvItem.stateMask = LVIS_SELECTED;
	
	int nIndex;
	
	POSITION pos = m_pToolCode[nListIndex]->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		subData = m_pToolCode[nListIndex]->m_SubToolData.GetNext(pos);
		
		//Tool No
		lvItem.iItem = m_listSubTool.GetItemCount();
		lvItem.iSubItem = 0;
		strText.Format(_T("%d"), subData.nSubToolNo);
		lvItem.pszText = (LPSTR)(LPCSTR)strText;
		nIndex = m_listSubTool.InsertItem(&lvItem);		
	}	
}

void CPaneManualControlParameter::OnClickListMainToolCode(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int sel = m_listMainTool.GetSelectionMark();
	if(-1 == sel) 
	{
		ErrMessage(_T("Please Select Tool First."));
		return;
	}
	
	ChangeDisplay(sel, 0);
	UpdateList(sel);
	
	m_listMainTool.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
	m_listMainTool.SetFocus();
	m_listMainTool.EnsureVisible(sel, TRUE );
	m_listMainTool.SetSelectionMark(sel);

//	m_listSubTool.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);
//	m_listSubTool.SetFocus();
//	m_listSubTool.EnsureVisible(0, TRUE );
	
	*pResult = 0;
}

void CPaneManualControlParameter::OnClickListSubToolCode(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int sel = m_listMainTool.GetSelectionMark();
	if(-1 == sel) 
	{
		ErrMessage(_T("Please Select Tool First."));
		return;
		sel = 0;
		m_listMainTool.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
		m_listMainTool.EnsureVisible(sel, TRUE );
		m_listMainTool.SetSelectionMark(sel);
	}
	
	int selSub = m_listSubTool.GetSelectionMark();
	if(-1 == selSub) 
	{
		ErrMessage(_T("Please Select SubTool First."));
		return;
	}
	
	ChangeDisplay(sel, selSub);
	
//	m_listMainTool.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
//	m_listMainTool.SetFocus();
//	m_listMainTool.EnsureVisible(sel, TRUE );
	
	m_listSubTool.SetItemState(selSub, LVIS_SELECTED, LVIS_SELECTED);
	m_listSubTool.SetFocus();
	m_listSubTool.EnsureVisible(selSub, TRUE );
	m_listSubTool.SetSelectionMark(selSub);
	
	*pResult = 0;
}

void CPaneManualControlParameter::OnSelChangeComboColor() 
{
	// TODO: Add your control notification handler code here
}

void CPaneManualControlParameter::OnSelChangeComboDrillMethod() 
{
	int nMode = m_cmbDrillMethod.GetCurSel();
	if(nMode < 2)
	{
		GetDlgItem(IDC_STATIC_SUB_BURST_SHOT)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SUB_BURST_SHOT)->EnableWindow(FALSE);

		if(nMode == 0)
		{
			CString str;
			m_edtTotalShot.GetWindowText(str);
			m_edtBurstShot.SetWindowText(str);
		}
		else
		{
			m_edtBurstShot.SetWindowText("0");
		}
	}
	else
	{
		if(!m_bUseTool)
			return;
		
		GetDlgItem(IDC_STATIC_SUB_BURST_SHOT)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_SUB_BURST_SHOT)->EnableWindow(TRUE);
	}
}

void CPaneManualControlParameter::OnSelChangeComboToolType() 
{
	// TODO: Add your control notification handler code here
	int nType = m_cmbToolType.GetCurSel();
	GetDlgItem(IDC_EDIT_SUB_TCODE_NO)->EnableWindow(FALSE);

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		GetDlgItem( IDC_EDIT_SUB_CURRENT )->EnableWindow(TRUE);
		GetDlgItem( IDC_COMBO_SUB_MASK )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_THERMAL_TRACK )->EnableWindow(TRUE);
		
		GetDlgItem( IDC_STATIC_SUB_CURRENT )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_MASK_NO )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_THERMAL_TRACK )->EnableWindow(TRUE);
	}
	else
	{
		if(gSystemINI.m_sHardWare.nLaserType != LASER_IPGPULSE)
		{
			GetDlgItem( IDC_EDIT_SUB_CURRENT )->EnableWindow(FALSE);
			GetDlgItem( IDC_STATIC_SUB_CURRENT )->EnableWindow(FALSE);
		}

		GetDlgItem( IDC_COMBO_SUB_MASK )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_THERMAL_TRACK )->EnableWindow(FALSE);
		
		GetDlgItem( IDC_STATIC_SUB_MASK_NO )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_THERMAL_TRACK )->EnableWindow(FALSE);
	}

	if(nType == MARKING_TYPE)
	{
		GetDlgItem( IDC_EDIT_SUB_DRAW_STEP )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_STEP )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_CORNER_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_LINE_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_LASER_ON_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_LASER_OFF_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_FPS )->EnableWindow(TRUE);

		GetDlgItem( IDC_STATIC_SUB_DRAW_STEP )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_STEP )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_DRAW_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_CORNER_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LINE_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LASER_ON_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LASER_OFF_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_FREQUENCY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_FPS )->EnableWindow(TRUE);
		
		GetDlgItem( IDC_COMBO_SUB_DRILL_METHOD )->EnableWindow(FALSE);

		GetDlgItem( IDC_EDIT_SUB_TOTAL_SHOT )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_BURST_SHOT )->EnableWindow(FALSE);
		m_edtTotalShot.SetWindowText("1");
		m_edtBurstShot.SetWindowText("1");

		GetDlgItem( IDC_BUTTON_SUB_SHOT_SETTING )->EnableWindow(FALSE);
		
		GetDlgItem( IDC_EDIT_SUB_LEAD_IN )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_LEAD_OUT )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_TABLE_SPEED )->EnableWindow(FALSE);
		GetDlgItem( IDC_CHECK_SUB_USE_APERTURE )->EnableWindow(FALSE);
		m_chkUseAperture.SetCheck(FALSE);
		GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_APERTURE_PATH)->EnableWindow(FALSE);
		m_edtAperturePath.SetWindowText("");
		GetDlgItem(IDC_BUTTON_SUB_PROFILE_OPEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_PROFILE_PATH)->EnableWindow(FALSE);
		m_edtScannerProfilePath.SetWindowText("");
		GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_Z_OFFSET )->EnableWindow(TRUE);

		GetDlgItem( IDC_STATIC_SUB_DRILL_METHOD )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_TOTAL_SHOT )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_BURST_SHOT )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LEAD_IN )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LEAD_OUT )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_TABLE_SPEED )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_APERTURE_PATH )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_PROFILE_PATH )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_APERTURE_BURST )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_Z_OFFSET )->EnableWindow(TRUE);
	}
	else if(nType == SHOT_DRILL_TYPE)
	{
		GetDlgItem( IDC_EDIT_SUB_DRAW_STEP )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_STEP )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_CORNER_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_LINE_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_LASER_ON_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_LASER_OFF_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_FPS )->EnableWindow(FALSE);

		GetDlgItem( IDC_STATIC_SUB_DRAW_STEP )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_STEP )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_DRAW_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_CORNER_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LINE_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LASER_ON_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LASER_OFF_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_FREQUENCY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_FPS )->EnableWindow(FALSE);
		
		GetDlgItem( IDC_COMBO_SUB_DRILL_METHOD )->EnableWindow(TRUE);
		
		GetDlgItem( IDC_EDIT_SUB_TOTAL_SHOT )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_BURST_SHOT )->EnableWindow(TRUE);
		
		GetDlgItem( IDC_EDIT_SUB_LEAD_IN )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_LEAD_OUT )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_TABLE_SPEED )->EnableWindow(FALSE);
		GetDlgItem( IDC_CHECK_SUB_USE_APERTURE )->EnableWindow(TRUE);
		m_chkUseAperture.SetCheck(FALSE);
		GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_APERTURE_PATH)->EnableWindow(FALSE);
		m_edtAperturePath.SetWindowText("");
		GetDlgItem(IDC_BUTTON_SUB_PROFILE_OPEN)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_PROFILE_PATH)->EnableWindow(FALSE);
		m_edtScannerProfilePath.SetWindowText("");
		GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_Z_OFFSET )->EnableWindow(TRUE);

		GetDlgItem( IDC_STATIC_SUB_DRILL_METHOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_TOTAL_SHOT )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_BURST_SHOT )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LEAD_IN )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LEAD_OUT )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_TABLE_SPEED )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_APERTURE_PATH )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_PROFILE_PATH )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_APERTURE_BURST )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_Z_OFFSET )->EnableWindow(TRUE);
	}
	else if(nType == LINE_DRILL_TYPE)
	{
		GetDlgItem( IDC_EDIT_SUB_DRAW_STEP )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_STEP )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_CORNER_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_LINE_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_LASER_ON_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_LASER_OFF_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_FPS )->EnableWindow(FALSE);

		GetDlgItem( IDC_STATIC_SUB_DRAW_STEP )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_STEP )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_DRAW_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_STEP_PERIOD )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_CORNER_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LINE_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LASER_ON_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LASER_OFF_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_FREQUENCY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_FPS )->EnableWindow(FALSE);
		
		GetDlgItem( IDC_COMBO_SUB_DRILL_METHOD )->EnableWindow(FALSE);
		
		GetDlgItem( IDC_EDIT_SUB_TOTAL_SHOT )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_BURST_SHOT )->EnableWindow(FALSE);
		m_edtTotalShot.SetWindowText("1");
		m_edtBurstShot.SetWindowText("1");

		GetDlgItem( IDC_BUTTON_SUB_SHOT_SETTING )->EnableWindow(FALSE);
		
		GetDlgItem( IDC_EDIT_SUB_LEAD_IN )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_LEAD_OUT )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_TABLE_SPEED )->EnableWindow(FALSE);
		GetDlgItem( IDC_CHECK_SUB_USE_APERTURE )->EnableWindow(TRUE);
		m_chkUseAperture.SetCheck(TRUE);
		GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_APERTURE_PATH)->EnableWindow(FALSE);
		m_edtAperturePath.SetWindowText("");
		GetDlgItem(IDC_BUTTON_SUB_PROFILE_OPEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_PROFILE_PATH)->EnableWindow(FALSE);
		m_edtScannerProfilePath.SetWindowText("");
		GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_Z_OFFSET )->EnableWindow(TRUE);

		GetDlgItem( IDC_STATIC_SUB_DRILL_METHOD )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_TOTAL_SHOT )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_BURST_SHOT )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LEAD_IN )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LEAD_OUT )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_TABLE_SPEED )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_APERTURE_PATH )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_PROFILE_PATH )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_APERTURE_BURST )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_Z_OFFSET )->EnableWindow(TRUE);
	}
	else //  if(nMode = FLYING_TYPE)
	{
		GetDlgItem( IDC_EDIT_SUB_DRAW_STEP )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_STEP )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_STEP_PERIOD )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_CORNER_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_JUMP_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_LINE_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_LASER_ON_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_LASER_OFF_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_FPS )->EnableWindow(FALSE);

		GetDlgItem( IDC_STATIC_SUB_DRAW_STEP )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_STEP )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_DRAW_STEP_PERIOD )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_STEP_PERIOD )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_CORNER_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_JUMP_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LINE_DELAY )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LASER_ON_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LASER_OFF_DELAY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_FREQUENCY )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_FPS )->EnableWindow(FALSE);
		
		GetDlgItem( IDC_COMBO_SUB_DRILL_METHOD )->EnableWindow(FALSE);
		
		GetDlgItem( IDC_EDIT_SUB_TOTAL_SHOT )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_BURST_SHOT )->EnableWindow(FALSE);
		m_edtTotalShot.SetWindowText("1");
		m_edtBurstShot.SetWindowText("1");

		GetDlgItem( IDC_BUTTON_SUB_SHOT_SETTING )->EnableWindow(FALSE);
		
		GetDlgItem( IDC_EDIT_SUB_LEAD_IN )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_LEAD_OUT )->EnableWindow(TRUE);
		GetDlgItem( IDC_EDIT_SUB_TABLE_SPEED )->EnableWindow(TRUE);
		GetDlgItem( IDC_CHECK_SUB_USE_APERTURE )->EnableWindow(FALSE);
		m_chkUseAperture.SetCheck(FALSE);
		GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_APERTURE_PATH)->EnableWindow(FALSE);
		m_edtAperturePath.SetWindowText("");
		GetDlgItem(IDC_BUTTON_SUB_PROFILE_OPEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_PROFILE_PATH)->EnableWindow(FALSE);
		m_edtScannerProfilePath.SetWindowText("");
		GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_SUB_Z_OFFSET )->EnableWindow(TRUE);

		GetDlgItem( IDC_STATIC_SUB_DRILL_METHOD )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_TOTAL_SHOT )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_BURST_SHOT )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_LEAD_IN )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_LEAD_OUT )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_TABLE_SPEED )->EnableWindow(TRUE);
		GetDlgItem( IDC_STATIC_SUB_APERTURE_PATH )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_PROFILE_PATH )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_APERTURE_BURST )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_SUB_Z_OFFSET )->EnableWindow(TRUE);
	}

	OnSelChangeComboDrillMethod();
}

void CPaneManualControlParameter::OnSelChangeComboMask() 
{
	// TODO: Add your control notification handler code here
}

void CPaneManualControlParameter::OnButtonSetting() 
{
	int sel = m_listMainTool.GetSelectionMark();
	if(-1 == sel) 
	{
		ErrMessage(_T("Please Select Tool First."));
		return;
		sel = 0;
		m_listMainTool.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
		m_listMainTool.EnsureVisible(sel, TRUE );
		m_listMainTool.SetSelectionMark(sel);
	}

	int selSub = m_listSubTool.GetSelectionMark();
	if(-1 == selSub) 
	{
		ErrMessage(_T("Please Select SubTool First."));
		return;
		selSub = 0;
		m_listSubTool.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);
		m_listSubTool.EnsureVisible(0, TRUE );
		m_listSubTool.SetSelectionMark(0);
	}
	
	int nShotCount = 0;
	
	nShotCount = GetDlgItemInt( IDC_EDIT_SUB_TOTAL_SHOT );
	
	if( nShotCount <= 0 || nShotCount > 15)
	{
		ErrMessage(IDS_SHOT_COUNT_INPUT_ERR, MB_ICONERROR);
		
		m_listSubTool.SetItemState(selSub, LVIS_SELECTED, LVIS_SELECTED);
		m_listSubTool.SetFocus();
		m_listSubTool.EnsureVisible(selSub, TRUE );
		m_listSubTool.SetSelectionMark(selSub);
		return;
	}

	int nListIndex = GetUseToolIndex(sel);
	if(nListIndex == -1)
		return;

	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];
		
	int i = 0;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		if(i == selSub) break;

		pToolCode->m_SubToolData.GetNext(pos);
		i++;
	}
	
	subData = pToolCode->m_SubToolData.GetAt(pos);
	
	for(int i = 0; i<MAX_BEAM_HOLE; i++)
		m_dDuty[i] = subData.dShotDuty[i];
	
	CDlgLaserBeamHoleSet dlg;
	
//	dlg.SetFireHole( nShotCount, m_dDuty );
	
	if(IDOK != dlg.DoModal())
	{
		m_listSubTool.SetItemState(selSub, LVIS_SELECTED, LVIS_SELECTED);
		m_listSubTool.SetFocus();
		m_listSubTool.EnsureVisible(selSub, TRUE );
		m_listSubTool.SetSelectionMark(selSub);
		return;
	}
	
//	dlg.GetFireHole(m_dDuty);
	
	m_listSubTool.SetItemState(selSub, LVIS_SELECTED, LVIS_SELECTED);
	m_listSubTool.SetFocus();
	m_listSubTool.EnsureVisible(selSub, TRUE );
	m_listSubTool.SetSelectionMark(selSub);
}

void CPaneManualControlParameter::OnButtonApertureOpen()
{
	int sel = m_listMainTool.GetSelectionMark();
	if(-1 == sel)
	{
		ErrMessage(_T("Please Select Tool First."));
		return;
		sel = 0;
		m_listMainTool.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
		m_listMainTool.EnsureVisible(sel, TRUE );
	}

	int selSub = m_listSubTool.GetSelectionMark();
/*	if(-1 == selSub)
	{
		ErrMessage(_T("SubTool�� �����ϼ���."));
		return;
		selSub = 0;
		m_listSubTool.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);
		m_listSubTool.EnsureVisible(0, TRUE );
	}
*/
	TCHAR BASED_CODE szFilter[] = _T("APL File (*.apl)|*.apl|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.apl"), NULL, dwFlags, szFilter);
	
	if(IDOK != dlg.DoModal())
	{
		m_listSubTool.SetItemState(selSub, LVIS_SELECTED, LVIS_SELECTED);
		m_listSubTool.SetFocus();
		m_listSubTool.EnsureVisible(selSub, TRUE );
		m_listSubTool.SetSelectionMark(selSub);
		return;
	}
	
	CString strPath;
	strPath.Format(_T("%s"), dlg.GetPathName());
	m_edtAperturePath.SetWindowText( (LPCTSTR)strPath );
}

void CPaneManualControlParameter::OnButtonSubProfileOpen() 
{
	// TODO: Add your control notification handler code here
	int sel = m_listMainTool.GetSelectionMark();
	if(-1 == sel)
	{
		ErrMessage(_T("Please Select Tool First."));
		return;
		sel = 0;
		m_listMainTool.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
		m_listMainTool.EnsureVisible(sel, TRUE );
	}
	
	int selSub = m_listSubTool.GetSelectionMark();
/*	if(-1 == selSub)
	{
		ErrMessage(_T("SubTool�� �����ϼ���."));
		return;
		selSub = 0;
		m_listSubTool.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);
		m_listSubTool.EnsureVisible(0, TRUE );
	}
*/	
	TCHAR BASED_CODE szFilter[] = _T("PRO File (*.pro)|*.pro|All Files (*.*)|*.*||");
	
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	
	CFileDialog dlg(TRUE, _T("*.pro"), NULL, dwFlags, szFilter);
	
	if(IDOK != dlg.DoModal())
	{
		m_listSubTool.SetItemState(selSub, LVIS_SELECTED, LVIS_SELECTED);
		m_listSubTool.SetFocus();
		m_listSubTool.EnsureVisible(selSub, TRUE );
		m_listSubTool.SetSelectionMark(selSub);
		return;
	}
	
	CString strPath;
	strPath.Format(_T("%s"), dlg.GetPathName());
	m_edtScannerProfilePath.SetWindowText( (LPCTSTR)strPath );
}

void CPaneManualControlParameter::OnButtonParamAdd() 
{
	int sel = m_listMainTool.GetSelectionMark();
	if(-1 == sel)
	{
		ErrMessage(_T("Please Select Tool First."));
		return;
		sel = 0;
		m_listMainTool.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
		m_listMainTool.EnsureVisible(sel, TRUE );
	}

	int nTempVal;
	double dTempVal;
	CString str;

	int nListIndex = GetUseToolIndex(sel);
	if(nListIndex == -1)
		return;
	
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	int nCount = 0;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		pToolCode->m_SubToolData.GetNext(pos);
		nCount++;
	}

	memset(&subData, 0, sizeof(subData));

	for(int i = 0; i < MAX_BEAM_HOLE; i++)
		subData.dShotDuty[i] = m_dDuty[i];

//	m_edtMainTcode.GetWindowText(str);
//	nTempVal = atoi(str);
//	pToolCode->m_nToolNo = nTempVal;
	
//	pToolCode->m_bUseTool = m_chkUseTool.GetCheck();
	
//	pToolCode->m_nToolColor = m_cmbColor.GetCurSel();
	
//	m_edtToolSize.GetWindowText(str);
//	nTempVal = atoi(str);
//	pToolCode->m_nToolSize = nTempVal;
	
//	pToolCode->m_bToolOrder = m_chkUseToolOrder.GetCheck();

	subData.nSubToolNo = nCount+1;

	subData.nToolType = m_cmbToolType.GetCurSel();

	subData.nMask = m_cmbMask.GetCurSel();
	
	subData.nShotMode = m_cmbDrillMethod.GetCurSel();
	
	subData.bUseAperture = m_chkUseAperture.GetCheck();

	m_edtDrawStep.GetWindowText(str);
	nTempVal = atoi(str);
	subData.dDrawStep = nTempVal;

	m_edtJumpStep.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nJumpStep = nTempVal;

	m_edtDrawStepPeriod.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nDrawStepPeriod = nTempVal;

	m_edtJumpStepPeriod.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nJumpStepPeriod = nTempVal;

	m_edtCornerDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nCornerDelay = nTempVal;

	m_edtJumpDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nJumpDelay = nTempVal;

	m_edtLineDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLineDelay = nTempVal;

	m_edtLaserOnDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLaserOnDelay = nTempVal;

	m_edtLaserOffDelay.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLaserOffDelay = nTempVal;

	m_edtFrequency.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nFrequency = nTempVal;

	m_edtFPS.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nFPS = nTempVal;

	m_edtCurrent.GetWindowText(str);
	dTempVal = atof(str);
	subData.dCurrent = dTempVal;

	m_edtTotalShot.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nTotalShot = nTempVal;

	m_edtBurstShot.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nBurstShot = nTempVal;

	m_edtLeadIn.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLeadIn = nTempVal;

	m_edtLeadOut.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nLeadOut = nTempVal;

	m_edtTableSpeed.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nTableSpeed = nTempVal;

	m_edtAperturePath.GetWindowText(str);
	strcpy_s(subData.cFilePath, str);

//	m_edtScannerProfilePath.GetWindowText(str);
//	strcpy_s(subData.cMoveProfileFilePath, str);

	m_edtApertureBurst.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nApertureBurst = nTempVal;

	m_edtThermalTrack.GetWindowText(str);
	nTempVal = atoi(str);
	subData.nThermalTrack = nTempVal;

	m_edtZOffset.GetWindowText(str);
	dTempVal = atof(str);
	subData.dZOffset = dTempVal;

	if(!CheckSubTool(subData))
		return;

	pToolCode->m_SubToolData.AddTail(subData);

	UpdateList(sel);

	m_listSubTool.SetItemState(nCount, LVIS_SELECTED, LVIS_SELECTED);
	m_listSubTool.SetFocus();
	m_listSubTool.EnsureVisible(nCount, TRUE );
	m_listSubTool.SetSelectionMark(nCount);
}

void CPaneManualControlParameter::OnButtonParamDelete() 
{
	int sel = m_listMainTool.GetSelectionMark();
	if(-1 == sel)
	{
		ErrMessage(_T("Please Select Tool First."));
		return;
		sel = 0;
		m_listMainTool.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
		m_listMainTool.EnsureVisible(sel, TRUE );
	}

	int nListIndex = GetUseToolIndex(sel);
	if(nListIndex == -1)
		return;
	
	CToolCodeList* pToolCode;
	pToolCode = m_pToolCode[nListIndex];

	int i = 0;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		pToolCode->m_SubToolData.GetNext(pos);
		i++;
	}

	int selSub = m_listSubTool.GetSelectionMark();
	if(-1 == selSub)
	{
		ErrMessage(_T("Please Select Subtool First."));
		return;
		selSub = i-1;
		m_listSubTool.SetItemState(selSub, LVIS_SELECTED, LVIS_SELECTED);
		m_listSubTool.EnsureVisible(selSub, TRUE );

		if(selSub < 0)
		{
			ErrMessage(_T("There is no Subtool."));
			return;
		}
	}

	i = 0;
	pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		if(i == selSub) break;
		
		pToolCode->m_SubToolData.GetNext(pos);
		i++;
	}
	
	pToolCode->m_SubToolData.RemoveAt(pos);

	SUBTOOLDATA subData;

	pos = pToolCode->m_SubToolData.GetHeadPosition();
	while(pos)
	{
		subData = pToolCode->m_SubToolData.GetAt(pos);
		if(subData.nSubToolNo > selSub + 1)
		{
			subData.nSubToolNo--;
			pToolCode->m_SubToolData.SetAt(pos, subData);
		}
		pToolCode->m_SubToolData.GetNext(pos);
	}

	UpdateList(sel);
}

void CPaneManualControlParameter::OnButtonParamUpdate() 
{
	// TODO: Add your control notification handler code here
	int sel = m_listMainTool.GetSelectionMark();
	if(-1 == sel) 
	{
		ErrMessage(_T("Please Select Tool First."));
		return;
		sel = 0;
		m_listMainTool.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
		m_listMainTool.EnsureVisible(sel, TRUE );
	}

	int selSub = m_listSubTool.GetSelectionMark();
	if(-1 == selSub)
	{
		ErrMessage(_T("Please Select SubTool First."));
		return;
		selSub = 0;
		m_listSubTool.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);
		m_listSubTool.EnsureVisible(0, TRUE );
	}
	
	ChangeData(sel, selSub);
	UpdateList(sel);
	
//	m_listMainTool.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
//	m_listMainTool.SetFocus();
//	m_listMainTool.EnsureVisible(sel, TRUE );

	m_listSubTool.SetItemState(selSub, LVIS_SELECTED, LVIS_SELECTED);
	m_listSubTool.SetFocus();
	m_listSubTool.EnsureVisible(selSub, TRUE );
	m_listSubTool.SetSelectionMark(selSub);
}

void CPaneManualControlParameter::OnButtonParamUpdateMain()
{
	int sel = m_listMainTool.GetSelectionMark ();
	if(-1 == sel)
	{
		ErrMessage(_T("Please Select Tool First."));
		return;
		sel = 0;
		m_listMainTool.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
		m_listMainTool.EnsureVisible(sel, TRUE );		
	}

	ChangeDataMain(sel);
	UpdateList(sel);

	m_listMainTool.SetItemState(sel, LVIS_SELECTED, LVIS_SELECTED);
	m_listMainTool.SetFocus();
	m_listMainTool.EnsureVisible(sel, TRUE);
	m_listMainTool.SetSelectionMark(sel);
}

void CPaneManualControlParameter::OnCheckUseTool() 
{
	UpdateData(TRUE);
	m_bUseTool = m_chkUseTool.GetCheck();

	EnableControl(m_bUseTool);

	OnCheckUseAperture();
	OnSelChangeComboDrillMethod();
	OnSelChangeComboToolType();
}

void CPaneManualControlParameter::OnCheckUseToolOrder() 
{
	UpdateData(TRUE);
	m_bToolOrder = m_chkUseToolOrder.GetCheck();
}

void CPaneManualControlParameter::OnCheckUseAperture() 
{
	UpdateData(TRUE);
	m_bUseAperture = m_chkUseAperture.GetCheck();

//	if(m_bUseAperture && !m_bUseTool)
//		return;

	GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->EnableWindow(m_bUseAperture);
//	GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->EnableWindow(m_bUseAperture);
//	GetDlgItem(IDC_EDIT_SUB_THERMAL_TRACK)->EnableWindow(m_bUseAperture);
//	GetDlgItem(IDC_EDIT_SUB_Z_OFFSET)->EnableWindow(m_bUseAperture);

	GetDlgItem(IDC_STATIC_SUB_APERTURE_PATH)->EnableWindow(m_bUseAperture);
//	GetDlgItem(IDC_STATIC_SUB_APERTURE_BURST)->EnableWindow(m_bUseAperture);
//	GetDlgItem(IDC_STATIC_SUB_THERMAL_TRACK)->EnableWindow(m_bUseAperture);
//	GetDlgItem(IDC_STATIC_SUB_Z_OFFSET)->EnableWindow(m_bUseAperture);

/*	
	BOOL bShow = m_chkUseAperture.GetCheck();

	GetDlgItem(IDC_STATIC_SUB_APERTURE_PATH)->ShowWindow(bShow);
	GetDlgItem(IDC_BUTTON_SUB_APERTURE_OPEN)->ShowWindow(bShow);
	GetDlgItem(IDC_EDIT_APERTURE_PATH)->ShowWindow(bShow);
	GetDlgItem(IDC_STATIC_SUB_APERTURE_BURST)->ShowWindow(bShow);
	GetDlgItem(IDC_EDIT_SUB_APERTURE_BURST)->ShowWindow(bShow);
	GetDlgItem(IDC_STATIC_SUB_THERMAL_TRACK)->ShowWindow(bShow);
	GetDlgItem(IDC_EDIT_SUB_THERMAL_TRACK)->ShowWindow(bShow);
	GetDlgItem(IDC_STATIC_SUB_Z_OFFSET)->ShowWindow(bShow);
	GetDlgItem(IDC_EDIT_SUB_Z_OFFSET)->ShowWindow(bShow);
	GetDlgItem(IDC_STATIC_Z_OFFSET)->ShowWindow(bShow);
*/
}

void CPaneManualControlParameter::GetColor(int nIndex, CString& strText)
{
	switch( nIndex )
	{
	case 0 :
		strText.Format(_T("Maroon"));
		break;
	case 1 :
		strText.Format(_T("Gray"));
		break;
	case 2 :
		strText.Format(_T("Black"));
		break;
	case 3 :
		strText.Format(_T("Brown"));
		break;
	case 4 :
		strText.Format(_T("Red"));
		break;
	case 5 :
		strText.Format(_T("Magenta"));
		break;
	case 6 :
		strText.Format(_T("Orange"));
		break;
	case 7 :
		strText.Format(_T("Pink"));
		break;
	case 8 :
		strText.Format(_T("Yellow"));
		break;
	case 9 :
		strText.Format(_T("Cyan"));
		break;
	case 10 :
		strText.Format(_T("Blue"));
		break;
	case 11 :
		strText.Format(_T("Green"));
		break;
	case 12 :
		strText.Format(_T("Lime"));
		break;
	case 13 :
		strText.Format(_T("IndianRed"));
		break;
	case 14 :
		strText.Format(_T("Salmon"));
		break;
	case 15 :
		strText.Format(_T("Gold"));
		break;
	case 16 :
		strText.Format(_T("Tan"));
		break;
	case 17 :
		strText.Format(_T("Khaki"));
		break;
	case 18 :
		strText.Format(_T("Teal"));
		break;
	case 19 :
		strText.Format(_T("Purple"));
		break;
	case 20 :
		strText.Format(_T("CadeBlue"));
		break;
	case 21 :
		strText.Format(_T("Crimson"));
		break;
	case 22 :
		strText.Format(_T("Silver"));
		break;
	case 23 :
		strText.Format(_T("Navy"));
		break;
	case 24 :
		strText.Format(_T("Plum"));
		break;
	case 25 :
		strText.Format(_T("Violet"));
		break;
	case 26 :
		strText.Format(_T("SeaGreen"));
		break;
	case 27 :
		strText.Format(_T("DarkGray"));
		break;
	case 28 :
		strText.Format(_T("Indigo"));
		break;
	case 29 :
		strText.Format(_T("GoldenRod"));
		break;
	}
}

void CPaneManualControlParameter::EnableControl(BOOL bUse)
{
	GetDlgItem(IDC_STATIC_TCODE_NO)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_COLOR)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SIZE)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_TCODE_NO)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_TOOL_TYPE)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_DRAW_STEP)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_JUMP_STEP)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_DRAW_STEP_PERIOD)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_JUMP_STEP_PERIOD)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_CORNER_DELAY)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_JUMP_DELAY)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_LINE_DELAY)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_LASER_ON_DELAY)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_LASER_OFF_DELAY)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_FREQUENCY)->EnableWindow(FALSE); // bUse);
	GetDlgItem(IDC_STATIC_SUB_FPS)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_CURRENT)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_MASK_NO)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_DRILL_METHOD)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_TOTAL_SHOT)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_BURST_SHOT)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_LEAD_IN)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_LEAD_OUT)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_TABLE_SPEED)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_APERTURE_PATH)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_PROFILE_PATH)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_APERTURE_BURST)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_THERMAL_TRACK)->EnableWindow(bUse);
	GetDlgItem(IDC_STATIC_SUB_Z_OFFSET)->EnableWindow(bUse);
}

int CPaneManualControlParameter::GetUseToolIndex(int nIndex)
{
	int nCount = 0;
	for(int i = 0; i < MAX_PARAM_TOOL; i++)
	{
		if(m_pToolCode[i]->m_bUseTool)
		{
			if(nCount == nIndex)
				return i;

			nCount++;
		}
	}
	return -1;
}



void CPaneManualControlParameter::OnChangeEditSubTotalShot() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFormView::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	int nMode = m_cmbDrillMethod.GetCurSel();
	if(nMode == 0) // burst
	{
		CString str;
		m_edtTotalShot.GetWindowText(str);
		m_edtBurstShot.SetWindowText(str);
	}
	else if(nMode == 1) // cycle
	{
		m_edtBurstShot.SetWindowText("0");
	}
	else
	{
		
	}
}

BOOL CPaneManualControlParameter::CheckSubTool(SUBTOOLDATA subData)
{
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		if(subData.dCurrent > 100 || subData.dCurrent <= 0)
		{
			ErrMessage(_T("Current range : 0 % < Current <= 100%"));
			GetDlgItem( IDC_EDIT_SUB_CURRENT )->SetFocus();
			return FALSE;
		}
		if(subData.nFrequency < 10000 || subData.nFrequency > 200000)
		{
			ErrMessage(_T("Frequency range : 10 KHz < Current <= 200 KHz"));
			GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->SetFocus();
			return FALSE;
		}
	}
	else
	{
		if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			if(subData.dCurrent > 100 || subData.dCurrent < 0)
			{
				ErrMessage(_T("Current range : 0 < Current <= 100"));
				GetDlgItem( IDC_EDIT_SUB_CURRENT )->SetFocus();
				return FALSE;
			}
		}

		if(subData.nMask < 0)
		{
			ErrMessage(_T("Select Mask No."));
			GetDlgItem( IDC_COMBO_SUB_MASK )->SetFocus();
			return FALSE;
		}
		if(subData.nFrequency < 1000 || subData.nFrequency > 10000)
		{
			ErrMessage(_T("Frequency range : 1 KHz < Current <= 10 KHz"));
			GetDlgItem( IDC_EDIT_SUB_FREQUENCY )->SetFocus();
			return FALSE;
		}
	}
	
	if(subData.nToolType != FLYING_TYPE)
	{
		if(subData.nToolType == MARKING_TYPE)
		{
			if(subData.dDrawStep < 1 || subData.dDrawStep > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Draw Step : Insert 1 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_DRAW_STEP )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nToolType == MARKING_TYPE || subData.nToolType == LINE_DRILL_TYPE)
		{
			if(subData.nJumpStep < 1 || subData.nJumpStep > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Jump Step : Insert 1 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_JUMP_STEP )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nToolType == MARKING_TYPE)
		{
			if(subData.nDrawStepPeriod < 20 || subData.nDrawStepPeriod > 51)
			{
				ErrMessage(_T("Draw Step Period : Insert 20 ~ 50"));
				GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->SetFocus();
				return FALSE;
			}
		}
		else
		{
			if(subData.nDrawStepPeriod < 15 || subData.nDrawStepPeriod > 51)
			{
				ErrMessage(_T("Draw Step Period : Insert 15 ~ 50"));
				GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nJumpStepPeriod % subData.nDrawStepPeriod != 0)
		{
			ErrMessage(_T("Jump Step Period : Insert a multiple of Draw Step period."));
			GetDlgItem( IDC_EDIT_SUB_JUMP_STEP_PERIOD )->SetFocus();
			return FALSE;
		}
		if(subData.nToolType == MARKING_TYPE)
		{
			if(subData.nCornerDelay < 0 || subData.nCornerDelay > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Corner Delay : Insert 0 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_CORNER_DELAY )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nToolType == MARKING_TYPE || subData.nToolType == LINE_DRILL_TYPE)
		{
			if(subData.nJumpDelay < 0 || subData.nJumpDelay > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Jump Delay : Insert 0 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_JUMP_DELAY )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nToolType == MARKING_TYPE || subData.nToolType == LINE_DRILL_TYPE)
		{
			if(subData.nLineDelay < 0 || subData.nLineDelay > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Line Delay : Insert 0 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_LINE_DELAY )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nLaserOnDelay < 0 || subData.nLaserOnDelay > MAX_SCANNER_PARAM)
		{
			ErrMessage(_T("Laser On Delay : Insert 0 ~ 65534."));
			GetDlgItem( IDC_EDIT_SUB_LASER_ON_DELAY )->SetFocus();
			return FALSE;
		}
		if(subData.nToolType == MARKING_TYPE || subData.nToolType == LINE_DRILL_TYPE)
		{
			if(subData.nLaserOffDelay < 0 || subData.nLaserOffDelay > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Laser Off Delay : Insert 0 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_LASER_OFF_DELAY )->SetFocus();
				return FALSE;
			}
		}
		if(subData.nToolType == MARKING_TYPE)
		{
			if(subData.nFPS < 0 || subData.nFPS > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("FPS : Insert 0 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_FPS )->SetFocus();
				return FALSE;
			}
		}

		int nTotalCount = 1;
		if(subData.nToolType == SHOT_DRILL_TYPE)
		{
			if(subData.nShotMode < 0)
			{
				ErrMessage(_T("Select Drill Shot Mode"));
				GetDlgItem( IDC_COMBO_SUB_DRILL_METHOD )->SetFocus();
				return FALSE;
			}
			if(subData.nTotalShot < 1 || subData.nTotalShot > 15)
			{
				ErrMessage(_T("Total Shot : Insert 1 ~ 15."));
				GetDlgItem( IDC_EDIT_SUB_TOTAL_SHOT )->SetFocus();
				return FALSE;
			}
			if(subData.nBurstShot < 0 || subData.nTotalShot > subData.nBurstShot)
			{
				ErrMessage(_T("Burst Shot : Insert 0 ~ Total Shot No."));
				GetDlgItem( IDC_EDIT_SUB_BURST_SHOT )->SetFocus();
				return FALSE;
			}
			nTotalCount = subData.nTotalShot;
		}
		
		for(int i = 0; i < nTotalCount; i++)
		{
			if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
			{
				if(subData.dShotDuty[i] < 0 || subData.dShotDuty[i] > 50) // %
				{
					ErrMessage(_T("Duty range : 0 < Duty < 50 %"));
					return FALSE;
				}
			}
		}
		
		if(subData.nToolType == SHOT_DRILL_TYPE)
		{
			if(subData.bUseAperture && subData.cFilePath[0] == _T('\0'))
			{
				ErrMessage(_T("Select an aperture file."));
				return FALSE;
			}
//			if(subData.cMoveProfileFilePath[0] == _T('\0'))
//			{
//				ErrMessage(_T("Select a Scanner Move Profile file."));
//				return FALSE;
//			}
		}
		if(subData.nToolType == LINE_DRILL_TYPE)
		{
			if(!subData.bUseAperture || subData.cFilePath[0] == _T('\0'))
			{
				ErrMessage(_T("Select an aperture file."));
				return FALSE;
			}
		}
		if(subData.nToolType == SHOT_DRILL_TYPE)
		{
			if(subData.nApertureBurst < 1 || subData.nApertureBurst > MAX_SCANNER_PARAM)
			{
				ErrMessage(_T("Aperture Burst : Insert 1 ~ 65534."));
				GetDlgItem( IDC_EDIT_SUB_APERTURE_BURST )->SetFocus();
				return FALSE;
			}
		}
	}
	else // flying type
	{
		if(subData.dDrawStep < 1 || subData.dDrawStep > MAX_SCANNER_PARAM)
		{
			ErrMessage(_T("Draw Step : Insert 1 ~ 65534."));
			GetDlgItem( IDC_EDIT_SUB_DRAW_STEP )->SetFocus();
			return FALSE;
		}
		if(subData.nJumpStep < 1 || subData.nJumpStep > MAX_SCANNER_PARAM)
		{
			ErrMessage(_T("Jump Step : Insert 1 ~ 65534."));
			GetDlgItem( IDC_EDIT_SUB_JUMP_STEP )->SetFocus();
			return FALSE;
		}
		if(subData.nDrawStepPeriod < 20 || subData.nDrawStepPeriod > 51)
		{
			ErrMessage(_T("Draw Step Period : Insert 20 ~ 50"));
			GetDlgItem( IDC_EDIT_SUB_DRAW_STEP_PERIOD )->SetFocus();
			return FALSE;
		}
		if(subData.nJumpStepPeriod % subData.nDrawStepPeriod != 0)
		{
			ErrMessage(_T("Jump Step Period : Insert a multiple of Draw Step period."));
			GetDlgItem( IDC_EDIT_SUB_JUMP_STEP_PERIOD )->SetFocus();
			return FALSE;
		}
		if(subData.nLaserOnDelay < 0 || subData.nLaserOnDelay > MAX_SCANNER_PARAM)
		{
			ErrMessage(_T("Laser On Delay : Insert 0 ~ 65534."));
			GetDlgItem( IDC_EDIT_SUB_LASER_ON_DELAY )->SetFocus();
			return FALSE;
		}
		if(subData.nLaserOffDelay < 0 || subData.nLaserOffDelay > MAX_SCANNER_PARAM)
		{
			ErrMessage(_T("Laser Off Delay : Insert 0 ~ 65534."));
			GetDlgItem( IDC_EDIT_SUB_LASER_OFF_DELAY )->SetFocus();
			return FALSE;
		}

		if(subData.nTableSpeed < 0)
		{
			ErrMessage(_T("Table Speed : Insert 1 ~ Max Table Speed."));
			GetDlgItem( IDC_EDIT_SUB_TABLE_SPEED )->SetFocus();
			return FALSE;
		}
//		GetDlgItem( IDC_EDIT_SUB_LEAD_IN )->EnableWindow(FALSE);
//		GetDlgItem( IDC_EDIT_SUB_LEAD_OUT )->EnableWindow(FALSE);
	}
	if(subData.dZOffset < -5 || subData.dZOffset > 5)
	{
		ErrMessage(_T("Z-axis Offset : Insert -5mm ~ 5mm."));
		GetDlgItem( IDC_EDIT_SUB_Z_OFFSET )->SetFocus();
		return FALSE;
	}
	return TRUE;
}


BOOL CPaneManualControlParameter::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Manual_Parameter) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}

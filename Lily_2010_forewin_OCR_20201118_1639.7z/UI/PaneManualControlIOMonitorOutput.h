#if !defined(AFX_PANEMANUALCONTROLIOMONITOROUTPUT_H__5B4445EF_E46B_4F68_B59C_BEBBCC456F83__INCLUDED_)
#define AFX_PANEMANUALCONTROLIOMONITOROUTPUT_H__5B4445EF_E46B_4F68_B59C_BEBBCC456F83__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlIOMonitorOutput.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorOutput form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "USimpleTab.h"
#ifdef __PUSAN_LDD__
	class CPaneManualControlIOMonitorOutputSub1LDD;
#else
	class CPaneManualControlIOMonitorOutputSub1;
	class CPaneManualControlIOMonitorOutputSub2;
#endif


class CPaneManualControlIOMonitorOutput : public CFormView
{
protected:
	CPaneManualControlIOMonitorOutput();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlIOMonitorOutput)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlIOMonitorOutput)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_IO_MONITOR_OUTPUT };
	USimpleTab	m_tabManualControl;
	//}}AFX_DATA

// Attributes
public:
#ifdef __PUSAN_LDD__
	CPaneManualControlIOMonitorOutputSub1LDD* m_pSub1;
	CPaneManualControlIOMonitorOutputSub1LDD* m_pSub2; //�Ϻη� �̷��� �� ���� �ƴ� 
#else
	CPaneManualControlIOMonitorOutputSub1* m_pSub1;
	CPaneManualControlIOMonitorOutputSub2* m_pSub2;
#endif
	

// Operations
public:
	void		InitTabControl();
	void		ShowTabPane(int nPaneNo);
	int			GetTabCurSel();
	
	void		ChangeSubPane();
	void		KillSubTimer();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlIOMonitorOutput)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlIOMonitorOutput();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntTab;
	
	int			m_nPaneNo;

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlIOMonitorOutput)
	afx_msg void OnClickTabManualControl(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLIOMONITOROUTPUT_H__5B4445EF_E46B_4F68_B59C_BEBBCC456F83__INCLUDED_)

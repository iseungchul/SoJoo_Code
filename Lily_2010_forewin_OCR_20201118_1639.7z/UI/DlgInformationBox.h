#if !defined(AFX_DLGINFORMATIONBOX_H__521C6FCD_17C8_4A4F_98C1_4C824E54738E__INCLUDED_)
#define AFX_DLGINFORMATIONBOX_H__521C6FCD_17C8_4A4F_98C1_4C824E54738E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgInformationBox.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgInformationBox dialog

class CDlgInformationBox : public CDialog
{
// Construction
public:
	void SetTitleContent(LPCTSTR strTitle, LPCTSTR strContent);
	void SetTitleContent(LPCTSTR strTitle, int nIdContent);
	void SetTitleContent(int nIdTitle, int nIdContent);
	void SetTitleContent(int nIdTitle, LPCTSTR strContent);
	CDlgInformationBox(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgInformationBox)
	enum { IDD = IDD_INFORMATION_BOX };
	CString	m_strContent;
	CString	m_strTitle;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgInformationBox)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CFont	m_dlgFont;
	CFont	m_btnFont;

	void SetDlgFont();

	// Generated message map functions
	//{{AFX_MSG(CDlgInformationBox)
		// NOTE: the ClassWizard will add member functions here
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGINFORMATIONBOX_H__521C6FCD_17C8_4A4F_98C1_4C824E54738E__INCLUDED_)

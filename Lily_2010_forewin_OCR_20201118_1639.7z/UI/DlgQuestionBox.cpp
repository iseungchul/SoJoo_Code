// DlgQuestionBox.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgQuestionBox.h"

#include "NAnswer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgQuestionBox dialog


CDlgQuestionBox::CDlgQuestionBox(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgQuestionBox::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgQuestionBox)
	m_strContent = _T("");
	//}}AFX_DATA_INIT

	m_bHideCancelBtn = false;
	m_strBtn1 = _T("");
	m_strBtn2 = _T("");
	m_strBtn3 = _T("");
}


void CDlgQuestionBox::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgQuestionBox)
	DDX_Text(pDX, IDC_STC_CONTENT, m_strContent);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgQuestionBox, CDialog)
	//{{AFX_MSG_MAP(CDlgQuestionBox)
	ON_BN_CLICKED(IDC_BTN_YES, OnBtnYes)
	ON_BN_CLICKED(IDC_BTN_NO, OnBtnNo)
	ON_BN_CLICKED(IDC_BTN_CANCEL, OnBtnCancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgQuestionBox message handlers

void CDlgQuestionBox::SetContent(LPCTSTR strContent)
{
	m_strContent = strContent;
}

void CDlgQuestionBox::OnBtnYes() 
{
	// TODO: Add your control notification handler code here
	EndDialog(NAnswer::answerYes);
	
}

void CDlgQuestionBox::OnBtnNo() 
{
	// TODO: Add your control notification handler code here
	EndDialog(NAnswer::answerNo);
	
}

void CDlgQuestionBox::OnBtnCancel() 
{
	// TODO: Add your control notification handler code here
	EndDialog(NAnswer::answerCancel);
	
}

void CDlgQuestionBox::HideCancelBtn()
{
	m_bHideCancelBtn = true;
}

void CDlgQuestionBox::SetDlgFont()
{
	SetButtonFont();

	m_dlgFont.CreateFont(16, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0, DEFAULT_CHARSET, 0, 0, 0, 0, DEF_FONT_FACE_NAME);
	GetDlgItem(IDC_STC_CONTENT)->SetFont(&m_dlgFont);
}
BOOL CDlgQuestionBox::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	if(m_bHideCancelBtn == true)
	{
		CWnd *pWnd = GetDlgItem(IDC_BTN_CANCEL);
		pWnd->ShowWindow(SW_HIDE);
	}
	
	if(m_strBtn1 != _T(""))
	{
		CWnd *pWnd = GetDlgItem(IDC_BTN_YES);
		pWnd->SetWindowText(m_strBtn1);
	}

	if(m_strBtn2 != _T(""))
	{
		CWnd *pWnd = GetDlgItem(IDC_BTN_NO);
		pWnd->SetWindowText(m_strBtn2);
	}

	if(m_strBtn3 != _T(""))
	{
		CWnd *pWnd = GetDlgItem(IDC_BTN_CANCEL);
		pWnd->SetWindowText(m_strBtn3);
	}

	SetDlgFont();

	return TRUE;
}

void CDlgQuestionBox::SetBtnText(const CString &strBtn1, const CString &strBtn2, const CString &strBtn3)
{
	m_strBtn1 = strBtn1;
	m_strBtn2 = strBtn2;
	m_strBtn3 = strBtn3;
}

void CDlgQuestionBox::SetButtonFont()
{
	LOGFONT lf;
	::ZeroMemory((void *) &lf, sizeof(lf));
	lf.lfHeight = 16;
	lf.lfWidth = 0;
	lf.lfEscapement = 0;
	lf.lfOrientation = 0;
	lf.lfWeight = 700;
	lf.lfItalic = 0;
	lf.lfUnderline = 0;
	lf.lfStrikeOut = 0;
	lf.lfCharSet = 0;
	lf.lfOutPrecision = 3;
	lf.lfClipPrecision = 2;
	lf.lfQuality = 1;
	lf.lfPitchAndFamily = 34;
	::lstrcpy(lf.lfFaceName, DEF_FONT_FACE_NAME);

	m_fontBtn.CreateFontIndirect(&lf);

	GetDlgItem(IDC_BTN_YES)->SetFont(&m_fontBtn);
	GetDlgItem(IDC_BTN_NO)->SetFont(&m_fontBtn);
	GetDlgItem(IDC_BTN_CANCEL)->SetFont(&m_fontBtn);
}

#if !defined(AFX_PANESYSSETUPBEAMPATHKUNSAN8_H__2CDF5088_DC6F_4988_8CE9_85E4A77A7E11__INCLUDED_)
#define AFX_PANESYSSETUPBEAMPATHKUNSAN8_H__2CDF5088_DC6F_4988_8CE9_85E4A77A7E11__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "resource.h"
#include "easydriller.h"
#include "..\model\BeamPathINIFile.h"
#include "..\model\DBeampathINI.h"
#include "GridCtrl.h"



#define		TABLE0  0
#define		TABLE1  1
#define		TABLE2  2
#define		TABLE3  3
#define		TABLE4  4
#define		TABLE5  5 

#define		TABLE0_COLUMN_COUNT 3
#define		TABLE1_COLUMN_COUNT 5
#define		TABLE2_COLUMN_COUNT 1
#define		TABLE3_COLUMN_COUNT 5
#define		TABLE4_COLUMN_COUNT 9
#define		TABLE5_COLUMN_COUNT 7

#define		COLUMNWIDTH  13	// �÷��� �ѱ��ڴ� �Ҵ�Ǵ� ������ ���� 


#define		TABLETEXT_COLOR		RGB(0,0,0)
#define		TABLE1_COLOR		RGB(255,255,255)
#define		TABLE2_COLOR		RGB(230,230,230)
#define		TABLE3_COLOR		RGB(220,220,220)
#define		TABLE4_COLOR		RGB(210,210,210)
#define		TABLE5_COLOR		RGB(200,200,200) 
#define		TABLE6_COLOR		RGB(180,180,180)


class CPaneSysSetupBeamPathKunsan8 : public CFormView
{
protected:
	CPaneSysSetupBeamPathKunsan8();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupBeamPathKunsan8)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupBeamPathKunsan8)
	enum { IDD = IDD_DLG_SYS_SETUP_BEAMPATH_KUNSAN8 };
	virtual BOOL PreTranslateMessage(MSG* pMsg);

	//}}AFX_DATA

// Attributes
public:
	UEasyButtonEx	m_chkInfo;
	UEasyButtonEx	m_chkBeamPath;
	UEasyButtonEx	m_chkPowerOffset;
	UEasyButtonEx	m_chkPowerCompensation;
	UEasyButtonEx	m_chkScannerFact;
	UEasyButtonEx   m_ChkSubBox[6];
	UEasyButtonEx	m_btnRefresh;
	UEasyButtonEx   m_btnAdd;
	UEasyButtonEx	m_btnDel;
	UEasyButtonEx   m_btnUp;
	UEasyButtonEx	m_btnDown;

	BOOL			m_bInfoCheck;
	BOOL			m_bBeamPathCheck;
	BOOL			m_bPowerOffsetCheck;
	BOOL			m_bpowerCompensationCheck;
	BOOL			m_bScannerFactCheck;

	BOOL			m_bCheckBox[6];
	CListCtrl		m_list;

	CEdit			m_editwnd;
	CPoint			m_posClicked;		// ����Ʈ �� Ŭ���� �� ��� 
	CColorEdit		m_edtFixMask;


	int				m_nRepeatCount;
	BOOL			m_bClickList;
	BOOL			m_ClickID;


	SBEAMPATH		m_sBeamPath;
	SBEAMPATH		m_sTempBeamPath;

	int				 m_IdNoToAddDel;

	int m_nPolarityMode;
	BOOL m_bUseTopHatMode;
	CGridCtrl m_Grid;
	int				m_nColumnCount;
	
	CString strTable0[TABLE0_COLUMN_COUNT];// = {"No", "Name", "MSize"};
	CString strTable1[TABLE1_COLUMN_COUNT];//= {"C1","C2","M1","M2","Z1","Z2","UseTopHat","LaserPath","Voltage1(%)","Voltage2(%)","Asc File"};
	CString strTable2[TABLE2_COLUMN_COUNT];// = {"Duty","Aom Delay","Aom Duty", "DualAom1","DualAom2", "VolOffset(%)","VolOffset(%)" };
	CString strTable3[TABLE3_COLUMN_COUNT];// = {"Frequency","Duty","Aom Delay","Aom Duty","Target Min","Target Max","Duty Offset"};
	CString strTable4[TABLE4_COLUMN_COUNT];// ={"Duty","Aom Delay","Aom Duty","Shot","Vision","Size","Tol.","Ratio","Polarity","Contrast","Brightness"};
	CString strTable5[TABLE5_COLUMN_COUNT]; // = {vision, size, tol, ratio, polarity, contrast, brightness}

// Attributes
protected :
	CFont		m_fntStatic;
	CFont		m_fntEdit;
	CFont		m_fntBtn;
// Operations
public:
	void FillTable5Data(int x, int y, CString str);
	void GetCurrentASC();
	BOOL CheckApply();

	int m_nVisionMode;
	int GetVisionMode();
	void SetVisionMode(int nMode);
	void CheckAnyDoPrework();

	void SetPolarityMode(int nMode);
	int GetPolarityMode();
	BOOL GetUseTopHatMode();
	void SetUseTopHatMode(BOOL bMode);
	int GetShowBoxMode(int nXPos);
	void SetCurrentScrollPos(int xPos, int yPos);
	void OnCheckDown();
	void OnCheckUp();
	void CopyFromTempToOriginal();
	void CopyFromOriginaltoTemp(int nSelectNo, int RepeatNo);
	void InitDataStruct();

	int GetIdNoToAddDel();
	void SetIdNoToAddDel(int nIdYPos);

	int GetListRowIndexCount();
	BOOL MoveFocus(int nXpos, int nYpos,int nMoveType);
	int GetColumnSize(int nStrlen);
	void OnCheckDel();
	void OnCheckAdd();
	
	void GetBeamPath(SBEAMPATH* pBeamPath);
	CString GetChangeValueStr();
	void FillTable4Data(int x, int y, CString str);
	void FillTable0Data(int x, int y, CString str);
	void FillTable3Data(int x, int y, CString str);
	void FillTable2Data(int x, int y, CString str);
	void FillTable1Data(int x, int y, CString str);
	void ListUpdate(CPoint ClickedPos, CString str);
	void OnKillfocusEditGrid();
	void InsertListValue(LV_ITEM lvitem,int startNo, int TableNo, int ColCount);
	void InsertGridValue(GV_ITEM Gvitem,int startNo, int TableNo, int ColCount);
	void SetBeamPath(SBEAMPATH sBeamPath);
	void InsertListComumn(int startNo, int TableNo);
	void DeleteList();
	void SetDrawMember(int listcount);
	int  GetListIndex();
	void InitListControl();
	void OnCheckRefresh();
	void OnCheckScannerFact();
	void OnCheckPowerCompensation();
	void OnCheckPowerOffset();
	void OnCheckBeamPath();
	void OnCheckInfo();
	void InitBtnControl();
	void InitStaticControl();
	void InitEditControl();
	void InitGrid();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupBeamPathPusan1)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupBeamPathKunsan8();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupBeamPath)

	afx_msg void OnClickList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	afx_msg void OnCheckHoleFact();
	//afx_msg void OnCustomdrawList(NMHDR* pNMHDR, LRESULT * pResult);
	afx_msg void OnNMCustomdrawListTest(NMHDR *pNMHDR, LRESULT *pResult);
		//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
#endif // !defined(AFX_PANESYSSETUPBEAMPATHKUNSAN8_H__2CDF5088_DC6F_4988_8CE9_85E4A77A7E11__INCLUDED_)

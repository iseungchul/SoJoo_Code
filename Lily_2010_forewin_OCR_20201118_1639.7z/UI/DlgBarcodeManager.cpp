// DlgBarcodeManager.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "CDlgBarcodeManager.h"
#include "..\model\BarcodeODBC.h"
#include "..\model\DEasyDrillerINI.h"
#include "..\model\FileDialogEX.h"
#include "..\easydrillerdlg.h"
#include "..\model\DProject.h"
#include <math.h>
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgBarcodeManager dialog


CDlgBarcodeManager::CDlgBarcodeManager(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgBarcodeManager::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgBarcodeManager)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_bOpenPrj = FALSE;
}


void CDlgBarcodeManager::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgBarcodeManager)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX,IDC_BUTTON_INPUT, m_btnInput );
	DDX_Control(pDX, IDC_BUTTON_OPEN_PROJECT, m_btnOpen);
	DDX_Control(pDX, IDC_BUTTON_APPLY, m_btnApply);
	DDX_Control(pDX, IDC_EDIT_LOT, m_edtLotNo);
	DDX_Control(pDX, IDC_EDIT_MANAGE, m_edtManageNo);
	DDX_Control(pDX, IDC_EDIT_PROJECT, m_edtProjectPath);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgBarcodeManager, CDialog)
	//{{AFX_MSG_MAP(CDlgBarcodeManager)
	ON_BN_CLICKED(IDC_BUTTON_INPUT, OnButtonInput)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_PROJECT, OnButtonOpenProject)
	ON_BN_CLICKED(IDC_BUTTON_APPLY, OnButtonApply)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgBarcodeManager message handlers

BOOL CDlgBarcodeManager::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	InitBtnControl();
	InitStaticControl();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
void CDlgBarcodeManager::InitEditControl()
{
	m_fntEdit.CreatePointFont(150, "Arial Bold");
	
	// Lot No
	m_edtLotNo.SetFont( &m_fntEdit );
	m_edtLotNo.SetForeColor( BLACK_COLOR );
	m_edtLotNo.SetBackColor( WHITE_COLOR );

	// Manage No
	m_edtManageNo.SetFont( &m_fntEdit );
	m_edtManageNo.SetForeColor( BLACK_COLOR );
	m_edtManageNo.SetBackColor( WHITE_COLOR );

	// Project Path
	m_edtProjectPath.SetFont( &m_fntEdit );
	m_edtProjectPath.SetForeColor( BLACK_COLOR );
	m_edtProjectPath.SetBackColor( WHITE_COLOR );
}


void CDlgBarcodeManager::InitBtnControl()
{
	m_fntBtn.CreatePointFont(100, "Arial Bold");
	
	// Aperture file path
	m_btnApply.SetFont( &m_fntBtn );
	m_btnApply.SetFlat( FALSE );
	m_btnApply.EnableBallonToolTip();
	m_btnApply.SetToolTipText( _T("Apply") );
	m_btnApply.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnApply.SetBtnCursor(IDC_HAND_1);

	m_btnInput.SetFont( &m_fntBtn );
	m_btnInput.SetFlat( FALSE );
	m_btnInput.EnableBallonToolTip();
	m_btnInput.SetToolTipText( _T("Input") );
	m_btnInput.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnInput.SetBtnCursor(IDC_HAND_1);

	m_btnOpen.SetFont( &m_fntBtn );
	m_btnOpen.SetFlat( FALSE );
	m_btnOpen.EnableBallonToolTip();
	m_btnOpen.SetToolTipText( _T("Open Project") );
	m_btnOpen.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOpen.SetBtnCursor(IDC_HAND_1);

}

void CDlgBarcodeManager::InitStaticControl()
{
	m_fntStatic.CreatePointFont(100, "Arial Bold");
	
	GetDlgItem(IDC_STATIC_LOT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MANAGE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PROJECT)->SetFont( &m_fntStatic );

}

void CDlgBarcodeManager::OnButtonInput() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CString strLot, strManage;
	m_edtLotNo.GetWindowText( strLot );
	m_strLotNo = strLot;
	if(strlen(strLot) < 1)
	{
		ErrMessage(_T("Please input LotNumber."));
		return;
	}

//	gDProject.m_strBarcodeLotName = m_strLotNo;// �α� �����Ͽ� ���ڵ� lot �̸� ����ϱ����� �߰� 20111212

	TCHAR pManager[256]={0,};
	TCHAR pCurrnet[256]={0,};
	CBarcodeOdbc Odbc;
	if(!Odbc.GetManageNo((LPSTR)(LPCTSTR)strLot,pManager, pCurrnet))
	{
		ErrMessage(_T("Can not open DB."));
		return;
	}
	strManage.Format(_T("%s"), pManager);
	
	if(strlen(strManage) <1)
	{
#ifdef __TEST__
		double dMax;
		int nValue;
		dMax = 2.0 * rand() / static_cast<double>(RAND_MAX);
		nValue = (int)((fabs(dMax * (rand() - RAND_MAX / 2.0) / static_cast<double>(RAND_MAX))) * 10000.0);
		if(nValue % 3 == 2)
			strManage = _T("215-746-20");
		else if(nValue % 3 == 1)
			strManage = _T("212-746-20");
		else
			strManage = _T("209-746-20");
#else
		ErrMessage(_T("There is no admin number in DB."));
		return;
#endif
	}

	m_edtManageNo.SetWindowText(strManage);
	m_strManageNo = strManage;
	m_strCurrent.Format(_T("%s"), pCurrnet);
	int nLength = m_strLotNo.GetLength();
	if(nLength == 9)
		m_strCurrent = m_strCurrent.Left(3);
	else
		m_strCurrent = m_strCurrent.Right(2);
//	memcpy(&gDProject.m_szBarcodeLotName, m_strLotNo, strlen(m_strLotNo));
//	memcpy(&gDProject.m_szManageNo, m_strManageNo, strlen(m_strManageNo));

	DecodeManageNum();
}

void CDlgBarcodeManager::DecodeManageNum()
{
	CString strManage,strLot;
	m_edtManageNo.GetWindowText(strManage);
	m_edtLotNo.GetWindowText(strLot);
	int nIndex = strManage.Find(_T('-'));
	
	if(nIndex == -1)
	{
		ErrMessage(_T("DB Admin numbers are not correct..\r\n( correct is : XXX-XX... )"));
		
		m_edtLotNo.SetWindowText("");
		m_edtManageNo.SetWindowText("");
		UpdateData(FALSE);
		
		return;
	}
	
	// m_strLot2�� 133-877-9T�̶�� �Ѵٸ�,
	// m_strManage = 1X8779T�� �ȴ�
	// "133"���� �ڿ� 2�ڸ� "33"�� "X"�� ��ȯ�ϸ� ��
	
	CString strTemp = strManage.Left(nIndex).Mid(1);
	int nNum = atoi(strTemp);
	
	if(nNum < 10)
		strTemp.Format(_T("%d"), nNum);
	else
		strTemp.Format(_T("%c"), nNum+55);
	
	m_strManage = strManage.Left(1) + strTemp;
	
	CString strTemp2= strManage.Mid(nIndex+1);
	
	while(TRUE)
	{
		nIndex = strTemp2.Find(_T('-'));
		if(nIndex < 1)
		{
			m_strManage += strTemp2;
			break;
		}
		m_strManage += strTemp2.Left(nIndex);
		strTemp2 = strTemp2.Mid(nIndex+1);
	}
	
	::AfxGetApp()->WriteProfileString("DualPanel", "Lot1", strLot);
	::AfxGetApp()->WriteProfileString("DualPanel", "Lot2", strManage);
	::AfxGetApp()->WriteProfileString("DualPanel", "ManageCode", m_strManage);

}

void CDlgBarcodeManager::OnButtonOpenProject() 
{
	CString strFilter, strFilter2;
	int nLength = m_strLotNo.GetLength();
	int nLength2 = m_strManageNo.GetLength();
/*	
	if(nLength == 9 && nLength2 > 0) // ����1�ڸ�+����8�ڸ� ����
		strFilter.Format(_T("���� ProjectFile(.prj)|%s*.prj;%s*.prj||"), m_strManage+"A", m_strManage+"1"));
	else if(nLength == 11 && nLength2 > 0) // ����1�ڸ�+����10�ڸ� ����
		strFilter.Format(_T("���� ProjectFile(.prj)|%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;||"), 
		m_strManage+"C", m_strManage+"E", m_strManage+"G", m_strManage+"I", 
		m_strManage+"3", m_strManage+"5", m_strManage+"7", m_strManage+"9");
//��⿡ ���ڵ� �߰��߰� co2 123
	else
		strFilter.Format(_T("���������� �����ϴ�.|NoFile.NoNo||"));
*/
#ifdef __PUSAN_LAVIA__
	if(nLength == 9 && nLength2 > 0) // ����1�ڸ�+����8�ڸ� ����
	{
		if (strcmp(m_strCurrent, "B2S") == 0)
		{
			strFilter.Format(_T("���� DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), m_strManageNo + "-comp", m_strManageNo + "-sold", m_strManageNo + "-comp", m_strManageNo + "-sold");
			strFilter2.Format(_T("���� ProjectFile(.prj;)|%s*.prj;%s*.prj;||"), m_strManageNo + "-comp", m_strManageNo + "-sold");
		}
		else
		{
			strFilter.Format(_T("���� DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), m_strManage + "_A", m_strManage + "_1", m_strManage + "_A", m_strManage + "_1");
			strFilter2.Format(_T("���� ProjectFile(.prj;)|%s*.prj;%s*.prj;||"), m_strManage + "_A", m_strManage + "_1");
		}

	}
	else if(nLength == 11 && nLength2 > 0) // ����1�ڸ�+����10�ڸ� ����
	{
		if(strcmp(m_strCurrent, "L1") == 0)
		{
			strFilter.Format(_T("���� DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), 
				m_strManage+"_C", m_strManage+"_3", m_strManage+"_C", m_strManage+"_3");
			strFilter2.Format(_T("���� ProjectFile(.prj;)|%s*.prj;%s*.prj;||"), 
				m_strManage+"_C", m_strManage+"_3");
		}
		else if(strcmp(m_strCurrent, "L2") == 0)
		{
			strFilter.Format(_T("���� DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), 
				m_strManage+"_5",  
				m_strManage+"_E", 
				m_strManage+"_5", 
				m_strManage+"_E");
			strFilter2.Format(_T("���� ProjectFile(.prj;)|%s*.prj;%s*.prj;||"), 
				m_strManage+"_5",  
				m_strManage+"_E");
		}
		else if(strcmp(m_strCurrent, "L3") == 0)
		{
			strFilter.Format(_T("���� DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), 
				m_strManage+"_7",  
				m_strManage+"_G", 
				m_strManage+"_7", 
				m_strManage+"_G");
			strFilter2.Format(_T("���� ProjectFile(.prj;)|%s*.prj;%s*.prj;||"), 
				m_strManage+"_7",  
				m_strManage+"_G");
		}
		else if(strcmp(m_strCurrent, "L4") == 0)
		{
			strFilter.Format(_T("���� DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), 
				m_strManage+"_9",  
				m_strManage+"_I", 
				m_strManage+"_9", 
				m_strManage+"_I");
			strFilter2.Format(_T("���� ProjectFile(.prj;)|%s*.prj;%s*.prj;||"), 
				m_strManage+"_9",  
				m_strManage+"_I");
		}
		else
		{
			strFilter.Format(_T("���� DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;||"), 
				m_strManage+"_C", m_strManage+"_E", m_strManage+"_G", m_strManage+"_I", 
				m_strManage+"_3", m_strManage+"_5", m_strManage+"_7", m_strManage+"_9", 
				m_strManage+"_11", m_strManage+"_F", m_strManage+"_KK",
				m_strManage+"_C", m_strManage+"_E", m_strManage+"_G", m_strManage+"_I", 
				m_strManage+"_3", m_strManage+"_5", m_strManage+"_7", m_strManage+"_9",
				m_strManage+"_11", m_strManage+"_F", m_strManage+"_KK");
			strFilter2.Format(_T("���� DataFile(.prj;)|%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;||"), 
				m_strManage+"_C", m_strManage+"_E", m_strManage+"_G", m_strManage+"_I", 
				m_strManage+"_3", m_strManage+"_5", m_strManage+"_7", m_strManage+"_9",
				m_strManage+"_11", m_strManage+"_F", m_strManage+"_KK");
		}
		
	}
	else
		strFilter.Format(_T("���������� �����ϴ�.|NoFile.NoNo||"));
#else
	if(nLength == 9 && nLength2 > 0) // ����1�ڸ�+����8�ڸ� ����
	{
		strFilter.Format(_T("���� DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), m_strManage+"A", m_strManage+"1", m_strManage+"A", m_strManage+"1");
		strFilter2.Format(_T("���� ProjectFile(.prj;)|%s*.prj;%s*.prj;||"), m_strManage+"A", m_strManage+"1");
	}
	else if(nLength == 11 && nLength2 > 0) // ����1�ڸ�+����10�ڸ� ����
	{
		if(strcmp(m_strCurrent, "L1") == 0)
		{
			strFilter.Format(_T("���� DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), 
				m_strManage+"C", m_strManage+"3", m_strManage+"C", m_strManage+"3");
			strFilter2.Format(_T("���� ProjectFile(.prj;)|%s*.prj;%s*.prj;||"), 
				m_strManage+"C", m_strManage+"3");
		}
		else if(strcmp(m_strCurrent, "L2") == 0)
		{
			strFilter.Format(_T("���� DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), 
				m_strManage+"5",  
				m_strManage+"E", 
				m_strManage+"5", 
				m_strManage+"E");
			strFilter2.Format(_T("���� ProjectFile(.prj;)|%s*.prj;%s*.prj;||"), 
				m_strManage+"5",  
				m_strManage+"E");
		}
		else if(strcmp(m_strCurrent, "L3") == 0)
		{
			strFilter.Format(_T("���� DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), 
				m_strManage+"7",  
				m_strManage+"G", 
				m_strManage+"7", 
				m_strManage+"G");
			strFilter2.Format(_T("���� ProjectFile(.prj;)|%s*.prj;%s*.prj;||"), 
				m_strManage+"7",  
				m_strManage+"G");
		}
		else if(strcmp(m_strCurrent, "L4") == 0)
		{
			strFilter.Format(_T("���� DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.txt;%s*.txt;||"), 
				m_strManage+"9",  
				m_strManage+"I", 
				m_strManage+"9", 
				m_strManage+"I");
			strFilter2.Format(_T("���� ProjectFile(.prj;)|%s*.prj;%s*.prj;||"), 
				m_strManage+"9",  
				m_strManage+"I");
		}
		else
		{
			strFilter.Format(_T("���� DataFile(.dat;.txt;)|%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.dat;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;%s*.txt;||"), 
				m_strManage+"C", m_strManage+"E", m_strManage+"G", m_strManage+"I", 
				m_strManage+"3", m_strManage+"5", m_strManage+"7", m_strManage+"9", 
				m_strManage+"C", m_strManage+"E", m_strManage+"G", m_strManage+"I", 
				m_strManage+"3", m_strManage+"5", m_strManage+"7", m_strManage+"9");
			strFilter2.Format(_T("���� DataFile(.prj;)|%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;%s*.prj;||"), 
				m_strManage+"C", m_strManage+"E", m_strManage+"G", m_strManage+"I", 
				m_strManage+"3", m_strManage+"5", m_strManage+"7", m_strManage+"9");
		}
		
	}
	else
		strFilter.Format(_T("���������� �����ϴ�.|NoFile.NoNo||"));
#endif
	CString strSavedDir;
	CString strDirectory;
	CString strOpenDir;

	if(m_bOpenPrj)
	{
		CFileDialogEX filedlg(TRUE, "prj", NULL, OFN_HIDEREADONLY, strFilter2);
		strSavedDir = gEasyDrillerINI.m_clsDirPath.GetProjectDir();
		strDirectory = _T("");
		strOpenDir = strSavedDir.Left(strSavedDir.ReverseFind(_T('\\')));
		strDirectory.Format(strOpenDir + _T('\\'));

		filedlg.m_ofn.lpstrInitialDir = (LPCTSTR)strDirectory;
		
		if (IDOK == filedlg.DoModal())
		{
			m_OpenProjectFile = filedlg.GetPathName();
			m_OpenProjectFileName = filedlg.GetFileName();
			m_edtProjectPath.SetWindowText(m_OpenProjectFileName);
		}
		else
			return;

	}
	else
	{
		CFileDialogEX filedlg(TRUE, "txt", NULL, OFN_HIDEREADONLY, strFilter);
		strSavedDir = gEasyDrillerINI.m_clsDirPath.GetDataDir();
		strDirectory = _T("");
		strOpenDir = strSavedDir.Left(strSavedDir.ReverseFind(_T('\\')));
		strDirectory.Format(strOpenDir + _T('\\'));

		filedlg.m_ofn.lpstrInitialDir = (LPCTSTR)strDirectory;
		
		if (IDOK == filedlg.DoModal())
		{
			m_OpenProjectFile = filedlg.GetPathName();
			m_OpenProjectFileName = filedlg.GetFileName();
			m_edtProjectPath.SetWindowText(m_OpenProjectFileName);
		}
		else
			return;
	}
}
void CDlgBarcodeManager::OnButtonApply() 
{
	int nLen = m_OpenProjectFile.GetLength();
	if(nLen < 1)
	{
		if(!m_bOpenPrj)
			ErrMessage(_T("Excellon File is not open."));
		else
			ErrMessage(_T("Project File is not open."));
		return;
	}
	
	if(m_bOpenPrj)
	{
		((CEasyDrillerDlg*)GetParent())->SetFileOpen(FALSE);
		
		((CEasyDrillerDlg*)GetParent())->SetPrjName( m_OpenProjectFileName );
		if(FALSE == ((CEasyDrillerDlg*)GetParent())->OpenProject(m_OpenProjectFile))
			return;
		
		::AfxGetMainWnd()->SendMessage(UM_CHANGE_DATAFILE, FALSE, reinterpret_cast<WPARAM>(&m_OpenProjectFile));
		
		strcpy_s(gDProject.m_szProjectName, m_OpenProjectFile);
		strcpy_s(gDProject.m_szLotId, m_strLotNo);
		
		CString strMessage;
		strMessage.Format(_T("Project ( %s )�� ���� �Ǿ����ϴ�."), m_OpenProjectFile);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), NULL);
		
		((CEasyDrillerDlg*)GetParent())->SetFileOpen(TRUE);
	}
	OnOK();
}

// 2011 02 24
BOOL CDlgBarcodeManager::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	if(pMsg->wParam == VK_RETURN)
	{
		return TRUE;
	} 

	return CDialog::PreTranslateMessage(pMsg);
}

CString CDlgBarcodeManager::GetFilePath()
{
	return m_OpenProjectFile;
}
CString CDlgBarcodeManager::GetFileName()
{
	return m_OpenProjectFileName;
}
void CDlgBarcodeManager::SetOpenType(BOOL bPrj)
{
	m_bOpenPrj = bPrj;
}

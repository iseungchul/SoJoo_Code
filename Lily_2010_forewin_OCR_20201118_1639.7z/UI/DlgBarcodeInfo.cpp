// DlgBarcodeInfo.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgBarcodeInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgBarcodeInfo dialog


CDlgBarcodeInfo::CDlgBarcodeInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgBarcodeInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgBarcodeInfo)
	m_strLotInfo = _T("IDDTEST-ABCDEFGHIJKLMNOPQR-01");
	m_nNo = 0;
	m_nBarType = 2;
	//}}AFX_DATA_INIT
}


void CDlgBarcodeInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgBarcodeInfo)
	DDX_Control(pDX, IDC_COMBO1, m_cmbBarType);
	DDX_Text(pDX, IDC_EDT_LOTINFO, m_strLotInfo);
	DDV_MaxChars(pDX, m_strLotInfo, 42);
	DDX_Text(pDX, IDC_EDT_NO, m_nNo);
	DDV_MinMaxUInt(pDX, m_nNo, 0, 9999);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgBarcodeInfo, CDialog)
	//{{AFX_MSG_MAP(CDlgBarcodeInfo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgBarcodeInfo message handlers

void CDlgBarcodeInfo::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData(TRUE);
	::AfxGetApp()->WriteProfileString("BARCODE_TEXT", "CONTENT", m_strLotInfo);
	m_nBarType = m_cmbBarType.GetCurSel();
	CDialog::OnOK();
}

BOOL CDlgBarcodeInfo::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_strLotInfo = ::AfxGetApp()->GetProfileString("BARCODE_TEXT", "CONTENT", _T("IDDTEST-ABCDEFGHIJKLMNOPQR-01"));
	m_cmbBarType.SetCurSel(0);
	UpdateData(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

#if !defined(AFX_PANESYSSETUPTABLECAL_H__EF622903_2B1E_4054_AB86_11602B13DBE0__INCLUDED_)
#define AFX_PANESYSSETUPTABLECAL_H__EF622903_2B1E_4054_AB86_11602B13DBE0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneSysSetupTableCal.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneSysSetupTableCal form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButton.h"
#include "UEasyButtonEx.h"
#include "ColorEdit.h"
#include "ColorStatic.h"
#include "..\model\dpoint.h"
#include "..\Device\Calibration.h"

class CDlgVisionOnly;

typedef CArray<DPOINT, DPOINT&> DPArray;

class CPaneSysSetupTableCal : public CFormView
{
protected:
	CPaneSysSetupTableCal();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneSysSetupTableCal)

// Form Data
public:
	//{{AFX_DATA(CPaneSysSetupTableCal)
	enum { IDD = IDD_DLG_SYS_SETUP_TABLE_CAL };
	CComboBox	m_cmbUseVision;
	CColorStatic	m_stcAvgXVal;
	CColorStatic	m_stcAvgYVal;
	CColorStatic	m_stcRangeYMin;
	CColorStatic	m_stcRangeYMax;
	CColorStatic	m_stcRangeXMin;
	CColorStatic	m_stcRangeXMax;
	CColorStatic	m_stcDispRet;
	CColorEdit	m_edtStartY;
	CColorEdit	m_edtStartX;
	CColorEdit	m_edtRangeYMin;
	CColorEdit	m_edtRangeYMax;
	CColorEdit	m_edtRangeXMin;
	CColorEdit	m_edtRangeXMax;
	CColorEdit	m_edtGridY;
	CColorEdit	m_edtGridX;
	CColorEdit	m_edtCalGap;
	UEasyButtonEx	m_btnVerify;
	UEasyButtonEx	m_btnShowVision;
	UEasyButtonEx	m_btnSetCurPos;
	UEasyButtonEx	m_btnLoadCalData;
	UEasyButton	m_btnCalStart;
	UEasyButtonEx	m_btnApply;
	UEasyButtonEx	m_btnMakeCalFile;
	int		m_nXPixelNum;
	int		m_nYPixelNum;
	//}}AFX_DATA

// Attributes
public:

// Attrivutes
protected :
	CFont			m_fntBtn;
	CFont			m_fntStatic;
	CFont			m_fntEdit;
	CFont			m_fntCombo;

	BOOL			m_bStopDraw;
	BOOL			m_bSuccess;
	BOOL m_bStartCal;
	BOOL m_bStartProof;

	DPArray			m_dpArray;
	DPArray			m_dpDraw;

	BOOL	m_bRotateCalDone;
	int		m_nFoundIndex;
	double m_dMaxOffset; 
	double m_dMaxOffsetX;
	double m_dMaxOffsetY;
	double m_dMinOffsetX;
	double m_dMinOffsetY;
	double m_dAvgX;
	double m_dAvgY;
	double m_dCalThick;
	double m_dCalGap;
	double m_dGap;
	double m_dXStart;
	double m_dYStart;
	double m_dXEnd;
	double m_dYEnd;
	double m_dXStartPos;
	double m_dYStartPos;
	double m_dStartPosZ;

	int	   m_nUsePanel;
	int		m_nGridX;
	int		m_nGridY;

	double* m_pXCal;
	double* m_pYCal;	
	double* m_pXProofPos;
	double* m_pYProofPos;

	CALHEAD m_CalHead;
	DPOINT* m_Offset;	

	CDlgVisionOnly*	m_pVisionOnly;

// Operations
public:
	BOOL SavePLC();
	void			InitBtnControl();
	void			InitStaticControl();
	void			InitEditControl();
	void			InitComboControl();

	void			SetDCCoord(CDC *pDC);
	void			SetPictureBackground();
	void			DrawCalibration();

	void			ConnectView();
	void			OnCamChange(int nCamNo);
	void			OnMoveVisionView();

	void LoadData(int nUsePanel);
	void UpdateCalibration(const CALHEAD& calHead);
	void GetCalibrationOffset(double dX, double dY, double& dOffset);
	void GetPartialCalibrationOffset(double dX, double dY, double& dOffset);
	void SetMatrixToZero();
	void SaveCalibration(int nUsePanel);
	BOOL IsPartialInside(double dX, double dY);
	BOOL IsInside(double dX, double dY);
	BOOL LoadCalibration(int nUsePanel);
	BOOL DoCalibration();
	void MessageLoop();
	void CalOffset();
	void moveOffset();
	void rotateOffset();
	void ClearMem();
	BOOL SaveFile(const CString& strFileName);
	void EnableAllButton(BOOL bEnable);

	void EnableControl(BOOL bUse);
	void SetAuthorityByLevel(int nLevel);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneSysSetupTableCal)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneSysSetupTableCal();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneSysSetupTableCal)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnPaint();
	afx_msg void OnButtonSetCurPos();
	afx_msg void OnButtonLoadCalData();
	afx_msg void OnButtonStart();
	afx_msg void OnButtonApply();
	afx_msg void OnButtonShowVision();
	afx_msg void OnProof();
	afx_msg void OnDestroy();
	afx_msg void OnSelchangeComboUseVision();
	afx_msg void OnButtonMakeXycal();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANESYSSETUPTABLECAL_H__EF622903_2B1E_4054_AB86_11602B13DBE0__INCLUDED_)

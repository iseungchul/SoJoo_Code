#if !defined(AFX_PANEAUTORUNVIEWPROCESS_H__BC0E8917_B229_45F1_8880_13FC62D07E59__INCLUDED_)
#define AFX_PANEAUTORUNVIEWPROCESS_H__BC0E8917_B229_45F1_8880_13FC62D07E59__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneAutoRunViewProcess.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunViewProcess form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif
#include "LedButton.h"
#include "..\model\DProcessINI.h"
class CPaneAutoRunViewProcess : public CFormView
{
protected:
	CPaneAutoRunViewProcess();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneAutoRunViewProcess)

// Form Data
public:
	//{{AFX_DATA(CPaneAutoRunViewProcess)
	enum { IDD = IDD_DLG_AUTORUN_VIEW_PROCESS };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	CFont m_fntStatic;
	CFont m_fntBtn;
	CLedButton m_ledMainDoorLock;
	CLedButton m_ledNoUseLU;
	CLedButton m_ledDryRun;
	CLedButton m_ledNoUseSuction;
	CLedButton m_ledNoUseVision;
	CLedButton m_ledNoAOMAlarm;
	CLedButton m_ledNoUsePowerAfterLotEnd;
	CLedButton m_ledNoUsePaper;
	CLedButton m_ledNoApplySCResult;
	CLedButton m_ledNoUsePrework;
	SPROCESSSYSTEM m_sProcessSystem;

// Operations
public:
	void SetProcessData(SPROCESSSYSTEM sProcessSystem);
	void ChangeDisplay();
	void InitBtnControl();
	void InitStatic();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneAutoRunViewProcess)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneAutoRunViewProcess();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneAutoRunViewProcess)
		// NOTE - the ClassWizard will add and remove member functions here.
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG


	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEAUTORUNVIEWPROCESS_H__BC0E8917_B229_45F1_8880_13FC62D07E59__INCLUDED_)

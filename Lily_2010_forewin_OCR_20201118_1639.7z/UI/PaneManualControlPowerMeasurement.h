#if !defined(AFX_PANEMANUALCONTROLPOWERMEASUREMENT_H__5A2D1DBE_9147_44A2_A478_099668A6A365__INCLUDED_)
#define AFX_PANEMANUALCONTROLPOWERMEASUREMENT_H__5A2D1DBE_9147_44A2_A478_099668A6A365__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlPowerMeasurement.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlPowerMeasurement form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "UEasyButton.h"
#include "ColorEdit.h"
#include "..\Device\DevLaserPower.h"
#include "..\Device\HEoCard.h"
#include "..\Device\FParameter.h"

#define INCREASE 1
#define DECREASE 2

struct PowerMeasure
{
	double			xTablePos;
	double			yTablePos;
	unsigned short	xGalvoPos;
	unsigned short	yGalvoPos;
	double			dVal;
};

class CPaneManualControlPowerMeasurement;
struct MEASURETHREADPARAM
{
	CPaneManualControlPowerMeasurement*	pParent;
	HANDLE		pHandle[3];
};

class CPaneManualControlPowerMeasurement : public CFormView
{
friend UINT ThreadProc(LPVOID lParam);

protected:
	CPaneManualControlPowerMeasurement();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlPowerMeasurement)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlPowerMeasurement)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_PWR_MEASUREMENT };
	CProgressCtrl	m_progTime;
	CColorEdit	m_edt2ndHead;
	CColorEdit	m_edt1stHead;
	CColorEdit	m_edtCompensationTargetMin;
	CColorEdit	m_edtCompensationTargetMax;
	CColorEdit	m_edtLongTermCheckTime;
	CColorEdit	m_edtLongTermCheckPeriod;
	CColorEdit	m_edtLongTermCheckDummyOnTime;
	CListBox	m_lboxResult;
	UEasyButton	m_btnStop;
	UEasyButton	m_btnMeasureStart;
	UEasyButton	m_btnApply;
	UEasyButtonEx m_chkUseCompensation;
	UEasyButtonEx m_chkUseLongTermCheck;
	CComboBox	m_cmbMeasurementMode;
	CComboBox	m_cmbHead;
	CComboBox	m_cmbTool;
	CColorEdit	 m_edtFreq;
	CColorEdit	 m_edtDuty;
	CColorEdit	 m_edtAOMDelay;
	CColorEdit	 m_edtAOMDuty;
	CColorEdit	 m_edtDutyOffset;
	CColorEdit	 m_edtAOMDelayOffset;
	CColorEdit	 m_edtAOMDutyOffset;
	CColorEdit	 m_edtWaitTime;
	//}}AFX_DATA

// Attributes
public:
	int m_nTimer1;
	BOOL m_bUserDummyOn;
// Attributes
protected:
	int				m_nUserLevel;
	SPROCESSPOWERMEASURE m_sProcessPowerMeasure;
	CFont			m_fntBtn;
	CFont			m_fntEdit;
	CFont			m_fntStatic;
	CFont			m_fntCombo;
	CFont			m_fntListBox;

	double			m_d1stPosition;
	double			m_d2ndPosition;

	int				m_nMeasureMode;

	DPOINT			m_d1stPos;
	DPOINT			m_d2ndPos;

	BOOL			m_b1stPower[25];
	BOOL			m_b2ndPower[25];

	double			m_dMasterAvrPower;
	double			m_dSlaveAvrPower;

	SCOMPORT		m_sComPort;

	int				m_nStart;
	int				m_nEnd;
	bool			m_bMeasureComplete;
	double			m_dMeasureTime;
	
	volatile MEASURETHREADPARAM	m_ThreadParam;
	CWinThread*		m_pThread;
	CDevLaserPower	m_Serial;

	PowerMeasure	m_pPowerMeasure[50];

	double			m_dEachPowerMaster[10];
	double			m_dEachPowerSlave[10];

	HEocard*		m_pEOCard;
	FParameter		m_OldParameter;
	FParameter		m_NewParameter;

	BOOL			m_bTimer;
	BOOL			m_bCompensationMode;
	BOOL			m_bLongTermCheck;
	double			m_dNewDutyOffset;
	int					m_nNewAttenOffsetPos;
	int				m_nUseTool;
	double			m_dDeltaDuty;
	int					m_nDeltaAttenPos;
	double			m_dDeltaPower; //��� ������ 
	double			m_dOldPower;
	BOOL			m_bMasterOK;
	BOOL			m_bSlaveOK;
	int				m_nPattern;
// Operations
public:
	BOOL			CheckCompensationRepeat( int nPoint);
	void			UpdateResult(double dResult, int nPoint);
	BOOL			WaitLongTerm(int& nSleepCount, HANDLE* pHandle);
	void			AddCompensationResult();
	void			SaveAllResult(CTime cStartTime, CTime cEndTime, double dDrillTime);
	void			SavePowerTime();
	BOOL			MeasureOnePoint(int nIndex);
	void SaveJobTimeLog(int nStartYear, int nStartMonth, int nStartDay, int nStartHour, int nStartMin, int nStartSec, 
						int nEndYear, int nEndMonth, int nEndDay, int nEndHour, int nEndMin, int nEndSec,
						int ndiff, int nJobType);
	double			GetCompensationOffset(int nRepeatCnt, double dCurrentPower);
	int					GetCompensationAttenPosOffset(int nRepeatCnt, double dCurrentPower, int nPoint);
	void			SetAuthorityByLevel(int nLevel);
	BOOL			ChangeBeamPath(int nIndex);
	void			GetMeasureData();
	void			ChangeLaserParam(int nIndex);
	double			MeasuerPower();
	void			SetCompensation();
	void			SetControlToData();
	void			SetProcessPowerMeasure(SPROCESSPOWERMEASURE sProcessPowerMeasure, DPOINT dMeaserPos[2]);
	void			GetProcessPowerMeasure(SPROCESSPOWERMEASURE* pProcessPowerMeasure);
	void			DispProcessPowerMeasure();
	void			InitBtnControl();
	void			InitStaticControl();
	void			InitEditControl();
	void			InitComboControl();
	void			InitListBoxControl();
	void			DutyOffetCheck();
	void			InitPosition();

	void			DisplayAndCheck(UINT nID, BOOL bIsMeasure);
	void			ToggleMeasure(UINT nID, BOOL bIs1stPanel=TRUE);

	void			SetComPortData(SCOMPORT* psComPort);

	void			EnablePowerLocationButton(BOOL bEnable = TRUE);
	bool			ParameterIntegrity();
	BOOL			UpdateNewParam(double dOffsetDuty);
	void			SetEditBoxActive(int i);
	void			ButtonInit();
	void			MakeThreadClear();
	void			CalculateAveragePower(); //master or Slave�� ��ü ��� 
	double			CalculateAverageOnePower(double dPower[], int nPoint); // ������ ���� ��� 
	void			SavePowerTrend();
	void			ProcessMeasureStop();
	void			SetMeasureTime(BOOL bIsInit, double dTime);
	BOOL			MoveZ(BYTE nAxis, double dMove);
	BOOL			MoveMotor(int i);
	void			GalvoStepMove(int i);
	double			RepeatMeasure(int nPoint);
	bool			PreHeatWait(BOOL bIsOff, double dTime);
	bool			Wait(double dTime);
	void			MeasureLaserOff();
	void			MeasureLaserOn();
	bool			MeasureWait(double dTime);
	double			MeasureDuringWait(double dTime, int nDivide);
	double			Measure( void );
	double			ConvertDouble(TCHAR* chData);
	int				CharToInt(TCHAR chNumber);
	CString			GetTextString(int i);
	void			ResultViewText(double dAverage, int i);
	void			MessageLoop();

	void			ConnectPort();
	void			DisconnectPort();
	
	void			EnableControl(BOOL bEnable);
	
	int				GetUseTool();
	BOOL			InPositionCheck();
	void			SetToolComboBox();
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlPowerMeasurement)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlPowerMeasurement();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlPowerMeasurement)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnCheck1stP0();
	afx_msg void OnCheck1stP1();
	afx_msg void OnCheck1stP2();
	afx_msg void OnCheck1stP3();
	afx_msg void OnCheck1stP4();
	afx_msg void OnCheck1stP5();
	afx_msg void OnCheck1stP6();
	afx_msg void OnCheck1stP7();
	afx_msg void OnCheck1stP8();
	afx_msg void OnCheck1stP9();
	afx_msg void OnCheck1stP10();
	afx_msg void OnCheck1stP11();
	afx_msg void OnCheck1stP12();
	afx_msg void OnCheck1stP13();
	afx_msg void OnCheck1stP14();
	afx_msg void OnCheck1stP15();
	afx_msg void OnCheck1stP16();
	afx_msg void OnCheck1stP17();
	afx_msg void OnCheck1stP18();
	afx_msg void OnCheck1stP19();
	afx_msg void OnCheck1stP20();
	afx_msg void OnCheck1stP21();
	afx_msg void OnCheck1stP22();
	afx_msg void OnCheck1stP23();
	afx_msg void OnCheck1stP24();
	afx_msg void OnCheck2ndP0();
	afx_msg void OnCheck2ndP1();
	afx_msg void OnCheck2ndP2();
	afx_msg void OnCheck2ndP3();
	afx_msg void OnCheck2ndP4();
	afx_msg void OnCheck2ndP5();
	afx_msg void OnCheck2ndP6();
	afx_msg void OnCheck2ndP7();
	afx_msg void OnCheck2ndP8();
	afx_msg void OnCheck2ndP9();
	afx_msg void OnCheck2ndP10();
	afx_msg void OnCheck2ndP11();
	afx_msg void OnCheck2ndP12();
	afx_msg void OnCheck2ndP13();
	afx_msg void OnCheck2ndP14();
	afx_msg void OnCheck2ndP15();
	afx_msg void OnCheck2ndP16();
	afx_msg void OnCheck2ndP17();
	afx_msg void OnCheck2ndP18();
	afx_msg void OnCheck2ndP19();
	afx_msg void OnCheck2ndP20();
	afx_msg void OnCheck2ndP21();
	afx_msg void OnCheck2ndP22();
	afx_msg void OnCheck2ndP23();
	afx_msg void OnCheck2ndP24();
	afx_msg void OnDestroy();
	afx_msg void OnButtonStop();
	afx_msg void OnButtonMeasureStart();
	afx_msg void OnSelectHeadCombo();
	afx_msg void OnSelectModeCombo();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg LRESULT OnStartCompensation(WPARAM wParam, LPARAM lParam);
	afx_msg void OnCheckSubUseCompensation();
	afx_msg void OnCheckSubUseLongTermCheck();
	afx_msg LRESULT OnResourceControl(WPARAM wParam, LPARAM lParam);
	afx_msg void OnSelchangeComboTool();
	afx_msg void OnButtonApply();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLPOWERMEASUREMENT_H__5A2D1DBE_9147_44A2_A478_099668A6A365__INCLUDED_)

﻿// PaneAutoRun.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneAutoRun.h"
#include "ColorStatic.h"
#include "DlgInputLot.h"
#include "..\EasyDrillerDlg.h"
#include "DlgVisionView.h"
#include "DlgVisionProView.h"
#include "DlgMatroxVisionView.h"
#include "..\device\hdevicefactory.h"
#include "..\device\hvision.h"
#include "..\device\hvisionomi.h"
#include "..\model\DProject.h"
#include "..\device\devicemotor.h"
#include "..\device\HMotor.h"
#include "..\model\dprocessini.h"
#include "math.h"
#include "..\Model\DSystemINI.h"
#include "..\Model\DEasyDrillerInI.h"
#include "..\Model\ToolCodeList.h"
#include "..\Model\2DBarcode.h"
#include "..\device\HEocard.h"
#include "..\Device\HLaser.h"
#include "..\device\HLaserAttenuator.h"
#include "..\alarmmsg.h"
#include "DlgMeasuringPCBThickness.h"
#include "..\model\globalvariable.h"
#include "DlgBarcodeInfo.h"
#include "panerecipegen.h"
#include "..\model\DBeampathINI.h"
#include "..\model\DTempINI.h"
#include "PaneAutoRunViewData.h"
#include "..\model\dprocessini.h"
#include"..\MODEL\DTemperCompensation.h"
#include "PaneAutoRunViewFiducial.h"
#include "PaneAutoRunViewPrework.h"
#include "PaneAutoRunViewProcess.h"
#include "PaneAutoRunViewSystem.h"
#include "PaneAutoRunViewStatus.h"
#include "PaneAutoRunViewPreworkScanner.h"
#include "PaneAutoRunViewPreworkPower.h"
#include "PaneAutoRunViewOPC.h"
#include "PaneManualControl.h"
#include "PaneManualControlLaser.h"
#include "PaneManualControlPowerMeasurement.h"
#include "DlgSideVision.h"
#include "..\model\DTextData.h"
#include "DlgSchedualeInfo.h"
#include "..\vicwin32\VICDEFS.H"
#include "ProgressWnd.h"
#include "..\DEVICE\OPCSvr.h"
#include <direct.h>
#include "DlgNGInfo.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define AREA_TOOL_NO_ERROR			1001
#define XYZ_MOVE_POS_ERROR			1002
#define MC_MOVE_POS_ERROR			1003
#define MOVE_IO_CMD_ERROR			1004
#define EOCARD_DOWNLOAD_FAIL		1005
#define USER_STOP_ERROR				1006
#define INPOSITION_ERROR			1007
#define LASER_CURRENT_SET_ERROR		1008
#define LASER_MISS_SHOT				1009

#define	FIND_ALL_MODE			-1
#define FIND_ONLY_CENTER_MODE	1
#define FIND_4_EDGE_MODE		4

const UINT FIRESTART_TIME		= 1;
const UINT FIREPAUSES_TIME		= 2;
const UINT FIREPAUSEE_TIME		= 3;
const UINT FIRENEXT_TIME		= 4;
const UINT FIREEND_TIME			= 5;
const UINT FIRESTEP_TIME		= 6;
const UINT FIRECYCLES_TIME		= 7;
const UINT FIRECYCLEE_TIME		= 8;
const UINT FIRESTARTDRILL_TIME	= 9;
const UINT FIREENDDRILL_TIME	= 10;
const UINT FIREPRESENTDRILL_TIME = 11;
const UINT FIREMARKINGSTART_TIME = 12;
const UINT FIREMARKINGEND_TIME = 13;

const UINT TIMER_DISPLAY = 1000;
const UINT TIMER_STATUS  = 1001;
const UINT TIMER_RESET	 = 1002;
CONST UINT TIMER_COMPONENT = 1004;


const UINT UM_CHANGE_VISION_PARAM2	= WM_APP + 51;
const UINT UM_VISION_FIND			= WM_APP + 52;
const UINT UM_VISION_ROI_SET		= WM_APP + 53;
const UINT UM_CHANGE_VISION_PARAM3	= WM_APP + 54;
const UINT UM_SAVE_PROJECT			= WM_APP + 55;
const UINT UM_VISION_FIND_NOGRAP	= WM_APP + 56;
const UINT UM_VISION_ROI_SET_UM		= WM_APP + 57;
const UINT UM_VISION_SAVE			= WM_APP + 58;
const UINT UM_VISION_LAMP			= WM_APP + 59;
const UINT UM_VISION_LAMP2			= WM_APP + 60;
const UINT UM_VISION_SAVE_FAIL		= WM_APP + 61;
#define MAX_AUTOCAL_COUNT	300
#define CALIBRATION_SLEEP	100
#define MAX_CHECK_HEADOFFSET_COUNT	4050 // 4번째 필드 상단만 사용 8100/2
const int SEL_HEAD_BOTH		= 0;
const int SEL_HEAD_MASTER	= 1;
const int SEL_HEAD_SLAVE	= 2;
/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRun

volatile HANDLE g_hDrill = ::CreateEvent(NULL, TRUE, TRUE, NULL);

//volatile HANDLE g_hCheckScal = ::CreateEvent(NULL, TRUE, TRUE, NULL);
//volatile HANDLE g_hCheckPower = ::CreateEvent(NULL, TRUE, TRUE, NULL);
//volatile HANDLE g_hCheckPreheat = ::CreateEvent(NULL, TRUE, TRUE, NULL);
//volatile HANDLE g_hDoScal = ::CreateEvent(NULL, TRUE, TRUE, NULL);
//volatile HANDLE g_hDoPower = ::CreateEvent(NULL, TRUE, TRUE, NULL);
//volatile HANDLE g_hDoPreheat = ::CreateEvent(NULL, TRUE, TRUE, NULL);

volatile HANDLE g_hDoScalManual = ::CreateEvent(NULL, TRUE, TRUE, NULL);
volatile HANDLE g_hDoPowerManual = ::CreateEvent(NULL, TRUE, TRUE, NULL);

IMPLEMENT_DYNCREATE(CPaneAutoRun, CFormView)

UINT CheckPreworkTimeThread(LPVOID pParam)
{
	CPaneAutoRun* pRun = (CPaneAutoRun*)pParam;
	CTime CurTime;
	time_t timeNow, timeRef, timeRef2;
	int nSecond;
	double dNowTime, dNowTime2;
	double dDiffDrill;
	int nPNLCount = 1;
	CString strFile, strLog;
	strFile.Format(_T("PreWork"));
	int nCurrentLotCount, nLotCountOld;

	nCurrentLotCount = nLotCountOld = -1;

	while(TRUE)
	{		
		nCurrentLotCount = pRun->m_nCycleCount;
		
		if(pRun->m_bRunThreadEnd)
		{
			TRACE(_T("Prework Time Check Start\r\n"));
			return TRUE;

		}
		
		if(!pRun->m_bDoAutoPreheat)
		{
			nSecond = gProcessINI.m_sProcessCal.nPreheatRelTime * 60;
			timeRef = gTempINI.m_sTempTime.nAutoPreheatEndTime;
			time(&timeNow);
			dDiffDrill = difftime(timeNow, timeRef); 
			
			if(((int)dDiffDrill > nSecond))
			{
				pRun->m_bDoAutoPreheat = TRUE;
				strLog.Format(_T("PreHeat Time Over : limit %d, last %d, curr %d : "), nSecond, gTempINI.m_sTempTime.nAutoPreheatEndTime, (int)dDiffDrill);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			}
		}
		
		if(!pRun->m_bDoAutoPower)
		{
			if(gProcessINI.m_sProcessCal.bUsePNLCountUnit)
			{
				if(gProcessINI.m_sProcessCal.nPowerCountTime != 0)
					nPNLCount = gProcessINI.m_sProcessCal.nPowerCountTime;
				else
					nPNLCount = 1;
			
					if(nCurrentLotCount % nPNLCount == 0 &&  nCurrentLotCount != nLotCountOld)
					{
						pRun->m_bDoAutoPower = TRUE;
					}
					else if(nCurrentLotCount % nPNLCount == 1 &&  nCurrentLotCount == nLotCountOld + 2) // 두장으로 넘어간 경우
					{
						pRun->m_bDoAutoPower = TRUE;
					}
			
			
			}
			else
			{
				int nCount = gBeamPathINI.m_sBeampath.nLastIndex;
				for(int k =0; k<= nCount; k++)
				{
					if(!pRun->m_bPowerTool[k])
						continue;

					timeRef = gTempINI.m_sTempTime.nAutoPowerEndTime[k][0]; //master
					timeRef2 = gTempINI.m_sTempTime.nAutoPowerEndTime[k][1]; //slave

					nSecond = gProcessINI.m_sProcessCal.nPowerRelTime * 60;
					
					time(&timeNow);
					dNowTime = difftime(timeNow, timeRef);
					dNowTime2 = difftime(timeNow, timeRef2);
					if(gDProject.m_nSeparation == USE_DUAL)
					{
						if((int)dNowTime > nSecond || (int)dNowTime2 > nSecond)
						{
							pRun->m_bDoAutoPower = TRUE;
							strLog.Format(_T("Power Time Over dual : limit %d, last %d[%d], curr %d, last :  %d[%d], curr %d"), nSecond, 
								gTempINI.m_sTempTime.nAutoPowerEndTime[k][0], k, (int)dNowTime,
								gTempINI.m_sTempTime.nAutoPowerEndTime[k][1], k, (int)dNowTime2);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
						}
					}
					else if(gDProject.m_nSeparation == USE_1ST)
					{
						if((int)dNowTime > nSecond)
						{
							pRun->m_bDoAutoPower = TRUE;
							strLog.Format(_T("Power Time Over 1st : limit %d, last %d[%d], curr %d"), nSecond, 
								gTempINI.m_sTempTime.nAutoPowerEndTime[k][0], k, (int)dNowTime);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
						}
					}
					else if(gDProject.m_nSeparation == USE_2ND)
					{
						if((int)dNowTime2 > nSecond)
						{
							pRun->m_bDoAutoPower = TRUE;
							strLog.Format(_T("Power Time Over dual : limit %d, last %d[%d], curr %d"), nSecond, 
								gTempINI.m_sTempTime.nAutoPowerEndTime[k][1], k, (int)dNowTime2);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
						}
					}

					if(pRun->m_bDoAutoPower)
						break;
				}
			}
		}
		
		if(!pRun->m_bDoAutoSCal)
		{
			if(gProcessINI.m_sProcessCal.bUsePNLCountUnit)
			{
				if(gProcessINI.m_sProcessCal.nScalCountTime != 0)
					nPNLCount = gProcessINI.m_sProcessCal.nScalCountTime;
				else
					nPNLCount = 1;
			
					if(nCurrentLotCount % nPNLCount == 0  && nCurrentLotCount != nLotCountOld)
					{
						pRun->m_bDoAutoSCal = TRUE;
					}
					else if(nCurrentLotCount % nPNLCount == 1 &&  nCurrentLotCount == nLotCountOld + 2)
					{
						pRun->m_bDoAutoSCal = TRUE;
					}
			}
			else
			{
				int nCount = gBeamPathINI.m_sBeampath.nLastIndex;
				for(int i =0; i<= nCount; i++)
				{
					if(!pRun->m_bASCTool[i])
						continue;

					timeRef = gTempINI.m_sTempTime.nAutoScalEndTime[i][0]; //master
					timeRef2 = gTempINI.m_sTempTime.nAutoScalEndTime[i][1]; //slave

					nSecond = gProcessINI.m_sProcessCal.nScalRelTime * 60;
					
					time(&timeNow);
					dNowTime = difftime(timeNow, timeRef);
					dNowTime2 = difftime(timeNow, timeRef2);
					if(gDProject.m_nSeparation == USE_DUAL)
					{
						if((int)dNowTime > nSecond || (int)dNowTime2 > nSecond)
						{
							pRun->m_bDoAutoSCal = TRUE;
							strLog.Format(_T("Scanner Time Over dual : limit %d, last %d[%d], curr %d, last :  %d[%d], curr %d"), nSecond, 
								gTempINI.m_sTempTime.nAutoScalEndTime[i][0], i, (int)dNowTime,
								gTempINI.m_sTempTime.nAutoScalEndTime[i][1], i, (int)dNowTime2);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
						}
					}
					else if(gDProject.m_nSeparation == USE_1ST)
					{
						if((int)dNowTime > nSecond )
						{
							pRun->m_bDoAutoSCal = TRUE;
							strLog.Format(_T("Scanner Time Over 1st : limit %d, last %d[%d], curr %d"), nSecond, 
								gTempINI.m_sTempTime.nAutoScalEndTime[i][0], i, (int)dNowTime);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
						}
					}
					else 
					{
						if((int)dNowTime2 > nSecond)
						{
							pRun->m_bDoAutoSCal = TRUE;
							strLog.Format(_T("Scanner Time Over 2nd : limit %d, last %d[%d], curr %d"), nSecond, 
								gTempINI.m_sTempTime.nAutoScalEndTime[i][1], i, (int)dNowTime2);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
						}
					}
				}	
			}
		}

		if(gProcessINI.m_sProcessCal.bUsePNLCountUnit)
		{
			nLotCountOld = nCurrentLotCount;

			pRun->MessageLoop();
			if(pRun->m_bRunThreadEnd)
			{
				TRACE(_T("Prework Time Check Start\r\n"));
				return TRUE;
				
			}
		}
		else
		{
			for(int i = 0 ; i < 6000; i++)
			{
				::Sleep(10);
				pRun->MessageLoop();
				
				if(pRun->m_bRunThreadEnd)
				{
					TRACE(_T("Prework Time Check Start\r\n"));
					return TRUE;
					
				}
			}
			//1분에 한번씩 돌아서 한번만 들어옴
			// 0 ~ 23 hour
		}

		CurTime = CTime::GetCurrentTime();
		if(CurTime.GetHour() == 0 && CurTime.GetMinute() == 0)
		{
			for(int k = 0; k<5; k++)
			{
				::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, k, TRUE);
			}
		}
	}
	
	TRACE(_T("Prework Time Check End\r\n"));
	return TRUE;

}

UINT DrillThread(LPVOID pParam)
{
	CPaneAutoRun* pRun = (CPaneAutoRun*)pParam;
	CString strSequenceLog;
	strSequenceLog.Format(_T("---Drill Start---"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
	
	::ResetEvent(g_hDrill);
	pRun->m_nErrMsgID = 0;
 	pRun->m_nAutoLotCount = 0;
	pRun->m_nTotalHoleCount = 0;
	pRun->m_nTotalLineCount = 0;
	pRun->m_bUnloadStart = FALSE; 
	pRun->m_strErrorPlus = _T("");
	

	if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
		gDeviceFactory.GetVision()->LoadProject((CString)gDProject.m_szJobFilePath);

	::AfxGetMainWnd()->SendMessage(UM_SET_CURRENT_LOTID, NULL, NULL);
	
	if(!pRun->PreLoadUnloadRun())
	{
		pRun->DrillStopProcess(NULL);
		return 1U;
	}
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, TRUE);

	pRun->m_ctStart = CTime::GetCurrentTime();

	BOOL bFirstPanel = TRUE;

	pRun->m_bPCBReject = FALSE; // 20130404 bhlee

	if(gProcessINI.m_sProcessSystem.bEveryPanelVisionHeadOffsetCheck && gProcessINI.m_sProcessOption.nTemperMeasureMode == 1) // Temperature - position offset 측정 모드
	{
		pRun->m_nErrMsgID = 0;
		if(pRun->InitStartTemperCompen())
		{
			BOOL bEndStep;
			int nMaxTemperCnt = 0;
			int nStepPower;
			int nCurrentDuty;
									
			for(int m = 0; m <= gProcessINI.m_sProcessOption.nTemperDutyStepNo; m++)
			{
				if(gProcessINI.m_sProcessOption.nTemperDutyStepNo == 0)
					nStepPower = 0;
				else
					nStepPower = ((gProcessINI.m_sProcessOption.nTemperEndPower - gProcessINI.m_sProcessOption.nTemperStartPower) / gProcessINI.m_sProcessOption.nTemperDutyStepNo );

				nCurrentDuty = gProcessINI.m_sProcessOption.nTemperStartDuty + m * gProcessINI.m_sProcessOption.nTemperStepDuty;
				if( gDProject.m_nSeparation == USE_1ST ) 
					gDeviceFactory.Get1stTemperCompen()->SetCurrentPower(m, gProcessINI.m_sProcessOption.nTemperStartPower + nStepPower * m, nStepPower);
				if( gDProject.m_nSeparation == USE_2ND ) 
					gDeviceFactory.Get2ndTemperCompen()->SetCurrentPower(m, gProcessINI.m_sProcessOption.nTemperStartPower + nStepPower * m,  nStepPower);

				int nEndNo = (int)((gProcessINI.m_sProcessOption.dTemperEndT + 0.01) / (gProcessINI.m_sProcessOption.dTemperTransT));

				double d1stTemper, d2ndTemper;
				gDeviceFactory.GetMotor()->GetTCTemperature(d1stTemper, d2ndTemper);
				if(gDProject.m_nSeparation == USE_1ST)
					pRun->m_dMeasureStartTemper = d1stTemper;
				else
					pRun->m_dMeasureStartTemper = d2ndTemper;

				int i = 0, nTempStepNo = 0;
				for(i = 0; i <= nEndNo; i++)
				{
					bEndStep = FALSE;
					pRun->MessageLoop();
					pRun->m_dTargetTemper = pRun->m_dMeasureStartTemper + gProcessINI.m_sProcessOption.dTemperTransT * i;
					if(i != 0)
					{
						if(!pRun->HeatingScannerBlockUsingIdleInfo(i, bEndStep, nCurrentDuty))
							break;
					}
					if(bEndStep) // 예열 time out으로 인한 강제 종료
					{
						break; // 이전까지 가공한 테이블까지만 만든다.
/*						gDeviceFactory.GetMotor()->GetTCTemperature(dCurr1stTemper, dCurr2ndTemper);
						if( gDProject.m_nSeparation == USE_1ST ) 
							pRun->m_dTargetTemper = dCurr1stTemper;
						if( gDProject.m_nSeparation == USE_2ND ) 
							pRun->m_dTargetTemper = dCurr2ndTemper;
						i = nEndNo;
*/					}
					nTempStepNo++;
					if(!pRun->CheckOffsetForTemperCompensation(gProcessINI.m_sProcessOption.nTemperCompenRepeatNo, T_OFFSET_FIRE, -1))
						break;
				}

				if(!pRun->CheckOffsetForTemperCompensation(gProcessINI.m_sProcessOption.nTemperCompenRepeatNo, T_OFFSET_FIND, nTempStepNo))
					break;

				pRun->m_dTargetTemper = pRun->m_dMeasureStartTemper; 
				if(gProcessINI.m_sProcessOption.nTemperDutyStepNo != m)
				{
					if(!pRun->WaitTargetTToDown())
							break;
				}
			}
			if(pRun->m_nErrMsgID == 0)
				pRun->MakeTemperCompenFile();
		}
	}
	else
	{
		if(!pRun->SetAutoTemperature(TRUE))
		{
			pRun->DrillStopProcess(NULL);
			return 1U;
		}
		do
		{
			pRun->MessageLoop();
			pRun->SetLastBoardBit();

			pRun->SendMessage(AUTO_MSG, FIRECYCLES_TIME);
			pRun->SendMessage(AUTO_MSG, FIRESTEP_TIME);

			if(bFirstPanel)
			{
				if(!pRun->PreDoPrework())
					break;
				bFirstPanel = FALSE;
			}

			if(!pRun->DoLoadingProcess())
				break;

			if(!pRun->DummyfreeOnFor2ndOrderOption())
				break;
			if(!pRun->DoCheckPCBThickProcess())
				break;

			pRun->SendMessage(AUTO_MSG, FIRESTARTDRILL_TIME);
			if(!pRun->CheckDummyfreeOn())
				break;
			pRun->SendMessage(AUTO_MSG, FIREMARKINGSTART_TIME);
			// Drill
			if(!pRun->DrillOneBoardProcess())
			{
				if(pRun->m_bPCBReject)// 20130404 bhlee
				{
					pRun->PCBReject();
				}
				break;
			}

			if(gProcessINI.m_sProcessSystem.bFailFidCountinue)
			{
				gDProject.m_nSeparation = pRun->m_nBackupSeparation;
			}
			
			if(gProcessINI.m_sProcessOption.nTemperCompenGridNo == 2 && gProcessINI.m_sProcessOption.bTemperVerifyMode)
			{
				if(!pRun->VerifyTemperComp())
					break;
			}

			if(pRun->m_bOneCycleStopNoUnloadPause)
			{
				pRun->DoOneCyclyStopNoUnloadPause();
			}
		
			if(!pRun->DoUnloadingProcess())
				break;

			if(!pRun->CheckLoaderPCBStatus())
				break;

			if(!pRun->PostDoPrework())
				break;
		} while(pRun->m_nCurrentLotCount < pRun->m_nInputLot - pRun->m_nNGLotCount && pRun->m_bAutoRun && !pRun->m_bOneCycleStop && !pRun->m_bUserStop
			&& (pRun->m_nAutoStartLotIndex == pRun->m_nCurrentLotIndex));

		if(!gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader && pRun->m_bAutoRun && pRun->m_bUnloadStart)
		{
			pRun->WaitHandler(HANDLER_UNLOADSTOP);
		}
	}

	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, FALSE);

	if(pRun->m_bAutoRun)
	{
		pRun->SendMessage(AUTO_MSG, FIREEND_TIME);
		if(!gProcessINI.m_sProcessSystem.bDryRun)
		{
			time_t timeNow;
			time(&timeNow);
			gTempINI.m_sTempTime.nAutoPreheatEndTime = (int)timeNow;	
			if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, TEMP_INI))
				ErrMsgDlg(STDGNALM119);

		}
	}
	pRun->SendMessage(AUTO_MSG, FIRECYCLEE_TIME);
	
	if(pRun->m_nErrMsgID != 0)
		pRun->m_pMotor->SetError(TRUE);

	pRun->DrillStopProcess(NULL);

	if(pRun->m_bStartCheckComponentTime)	
	{
		::AfxGetMainWnd()->SendMessage(UM_COMPONENT_PREACQTIME, NULL, NULL);
		pRun->m_bStartCheckComponentTime = FALSE;
	}
	return 1U;
}

CPaneAutoRun::CPaneAutoRun()
	: CFormView(CPaneAutoRun::IDD)
{
	//{{AFX_DATA_INIT(CPaneAutoRun)
	//}}AFX_DATA_INIT
	m_bMotor			= FALSE;
	m_bScanner			= FALSE;
	m_bVision			= FALSE;
	m_bLaser			= FALSE;
	m_bMainPower		= FALSE;
	m_bEStop			= FALSE;
	m_bInit				= FALSE;
	m_bTableSuction		= FALSE;
	m_bTableSuction2	= FALSE;
	m_nInputLot			= 30;
	m_bAutoRun			= FALSE;
	m_bSelectFire		= FALSE;
	m_bFluorescentLamp	= FALSE;
	m_bUserStop			= FALSE;
	m_bDrillPause		= FALSE;
	m_bOneCycleStop		= FALSE;
	m_bOneCycleStopNoUnloadPause = FALSE;
	m_nErrMsgID			= 0;
	m_strErrorPlus		= _T("");
	m_bAutoTimeStart	= FALSE;
	m_nCurrentLotCount	= 0;
	m_nTotalCurrentLotCount = 0;
	m_nCurrentLotIndex = 0;
	m_nNGLotCount		= 0;
	m_nAutoLotCount		= 0;
	m_dAvrTime			= 0.0;
	m_dPriTime			= 0.0;
	m_dAvgMarkingTime	= 0.0;
	m_bTimer1			= FALSE;
	m_bTimer2			= FALSE;
	m_bTimer3			= FALSE;
	m_bTimer4			= FALSE;
	m_bOdd				= FALSE;
	m_bUserDummyOn		= FALSE;
	m_nTotalHoleCount	= 0;
	m_nTotalLineCount	= 0;
	m_nLotHoleCount		= 0;
	m_nLotLineCount		= 0;
	m_nAOMAlarmCnt		= 0;
	m_nUserLevel		= 0;
	m_lErrorIo1New = m_lErrorIo1Old = 0;
	m_lErrorLoad1New = m_lErrorLoad1Old = 0;
	m_lErrorLoad2New = m_lErrorLoad2Old = 0;
	m_lErrorLoad3New = m_lErrorLoad3Old = 0;
	m_lErrorUnload1New = m_lErrorUnload1Old = 0;
	m_lErrorUnload2New = m_lErrorUnload2Old = 0;
	m_lErrorUnload3New = m_lErrorUnload3Old = 0;
	m_lErrorTableLimit1New = m_lErrorTableLimit1Old = 0;
	m_lErrorOtherLimit1New = m_lErrorOtherLimit1Old = 0;
	m_lErrorLaser1New = m_lErrorLaser1Old = 0;
	m_lErrorOthers1New = m_lErrorOthers1Old = 0;
	m_lErrorOthers2New = m_lErrorOthers2Old = 0;
	m_lErrorOthers3New = m_lErrorOthers3Old = 0;
	m_lErrorOthers4New = m_lErrorOthers4Old = 0;
	m_lErrorOthers5New = m_lErrorOthers5Old = 0;
	m_lErrorOthers6New = m_lErrorOthers6Old = 0;
	m_lErrorTable1New = m_lErrorTable1Old = 0;

	m_lErrorMelsecMainNew = m_lErrorMelsecMainOld = 0;
	m_lErrorMelsecLoaderNew = m_lErrorMelsecLoaderOld = 0;
	m_lErrorMelsecUnloaderNew = m_lErrorMelsecUnloaderOld = 0;
	m_lErrorMelsecEtc1New = m_lErrorMelsecEtc1Old = 0;
	m_lErrorMelsecEtc2New = m_lErrorMelsecEtc2Old = 0;

	m_bModeNew = m_bModeOld = 0;

	m_nTimerID1 = m_nTimerID2 = m_nTimerID3 = m_nTimerID4 = 0;	//201164

	memset(m_c2DContents, NULL, 255);
	memset(m_cPrjName, 0, sizeof(m_cPrjName));

	m_bStopField = FALSE;
	m_nStopField = -1;
	
	m_nUVTriggerMode = 1; // (external) 20090629 Front Mode error

	m_bCheckZMC = FALSE;
	m_bCheckMC = FALSE;
	m_nDummyDP = 0;
	m_bOldResetSwitch = FALSE;

	m_dRefLeght = 0.0;
	m_dTransLeght = 0.0;

	m_bStartCheckComponentTime = FALSE;
	
	m_bDoAutoPower = FALSE;
	m_bWorkingAutoSCal = FALSE;

	m_bRunThreadEnd = FALSE;
	m_pCheckPreTimeThread = NULL;
	m_pCheckDrillThread = NULL;

	m_bNeedUnload = FALSE;
	m_bEndBoard = FALSE;

	m_bPreScanner = FALSE;

	m_bWorkingAutoSCal = FALSE; 
	m_bWorkingAutoPreheat = FALSE;
	
	m_bDoAutoSCal = FALSE;
	m_bDoAutoPreheat = FALSE;
	m_nASCCount = 0;
	m_bAnyDoAutoPower = FALSE;
	m_bAnyDoAutoPreheat = FALSE;
	m_bAnyDoAutoSCal = FALSE;
	m_dMaxOffsetSlaveX = 0;
	m_dMaxOffsetMasterX = 0;
	m_dMaxOffsetSlaveY = 0;
	m_dMaxOffsetMasterY = 0;
	for(int i = 0; i < BEAMPATH_COUNT; i++)
	{
		m_bASCTool[i] = FALSE;
		m_bPowerTool[i] = FALSE;
	}
	m_nDrillEndTime = 0;
	m_nDrillOneBoardEndTime = 0; // 프로그램 시작하면 언제 가공이 끝났는지 모르므로 온도옵셋을 위해 처음부터 기다리게 만든다. (int)gProcessINI.m_sProcessOption.dTemperTWaitScal;
	
	time_t	timeNow;
	time(&timeNow);
	if(gProcessINI.m_sProcessOption.bTemperCompensationMode)
		m_nLilyStartTime =(int)(timeNow - gDeviceFactory.Get1stTemperCompen()->GetFireEndTime()); // 
	else
		m_nLilyStartTime = 0;

	m_nLotMarkStartNo = 1;
	m_nLotMarkCurrent = 0;
	m_dMeasuredPower[0] = 0.0;
	m_dMeasuredPower[1] = 0.0;

	m_bShowTimeDP = FALSE;
	m_nCurrentPrjIndex	= -1;

	m_bMissFire	= FALSE;
	m_bScannerOld = TRUE;
	m_bLaserPowerOld = TRUE;
	m_bEocardEstopAtOnceForDrillstop = FALSE;
	m_bCheckTablePCB = FALSE;
	m_bPostPreWorkDoing = FALSE;
	m_bUiAlivePulse = FALSE;
	m_nNGBoxCondition = 0 ; //20130502 bskim

	m_dAvgScaleX = 100;
	m_dAvgScaleY = 100;
	m_dCurrentScaleX[0] = m_dCurrentScaleX[1] = m_dCurrentScaleY[0] = m_dCurrentScaleY[1] = 100;
	m_nCycleCount =0;
	m_bUseManualDrillDummy = FALSE;
	m_nFidIndexForFidShowAll = -1;
	m_nFidBlockForFidShowAll = 0;
	m_bChangePanelInfo = FALSE;
	m_nMotorInitialCount = 0;
	m_d1stTemper = 0;
	m_d2ndTemper = 0;
	m_dScal1stTemper = 0;
	m_dScal2ndTemper = 0;
	m_dTargetTemper = 0;
	m_pLPCAreaInfo = NULL;
	m_bBasketLDIn = FALSE;
	m_bBasketUDIn = FALSE;
	m_bOldBasketLDIn = FALSE;
	m_bOldBasketUDIn = FALSE;	
	m_bBasketLDOut = FALSE;
	m_bBasketUDOut = FALSE;
	m_bOldBasketLDOut = FALSE;
	m_bOldBasketUDOut = FALSE;
//	m_bFirstFire = FALSE;
	m_bReadAddress = TRUE;
	m_nLaserWaringCnt = 0;
	m_nLaserOverTempCnt = 0;
	m_bLaserWaringOld = FALSE;
	m_bLaserOverTempOld = FALSE;
//	m_pcField = new BYTE[32000 * 32000];
}

CPaneAutoRun::~CPaneAutoRun()
{
	if(g_hDrill != NULL)
	{
		CloseHandle(g_hDrill);
		g_hDrill = NULL;
	}
//	if(m_pcField)
//	{
//		delete [] m_pcField;
//		m_pcField = NULL;
//	}

	KillRunThread();
}

void CPaneAutoRun::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneAutoRun)
	DDX_Control(pDX, IDC_CHECK_FLUORESCENT_LAMP, m_ledFluorescentLamp);
	DDX_Control(pDX, IDC_CHECK_TABLE_SUCTION, m_ledTableSuction);
	DDX_Control(pDX, IDC_CHECK_TABLE_SUCTION2, m_ledTableSuction2);
	DDX_Control(pDX, IDC_CHECK_INITIALIZATION, m_ledInit);
	DDX_Control(pDX, IDC_STATIC_DRILL_STATUS, m_stcDrillStatus);
	DDX_Control(pDX, IDC_STATIC_PCB_COUNT, m_stcPCBCounter);
	DDX_Control(pDX, IDC_STATIC_TOTAL_HOLE, m_stcTotalHole);
	DDX_Control(pDX, IDC_STATIC_LOT_HOLE, m_stcLotHole);
	DDX_Control(pDX, IDC_LIST_BOARD_PARAM, m_listBoardParam);
	DDX_Control(pDX, IDC_CHECK_SCANNER, m_ledScanner);
	DDX_Control(pDX, IDC_CHECK_VISION, m_ledVision);
	DDX_Control(pDX, IDC_CHECK_MOTOR, m_ledMotor);
	DDX_Control(pDX, IDC_CHECK_MAIN_POWER, m_ledMainPower);
	DDX_Control(pDX, IDC_CHECK_LASER, m_ledLaser);
	DDX_Control(pDX, IDC_CHECK_E_STOP, m_ledEStop);
	DDX_Control(pDX, IDC_CHECK_AUTO_RUN, m_ledAutoRun);
	DDX_Control(pDX, IDC_CHECK_IDLE_MODE, m_ledIdleMode);
	DDX_Control(pDX, IDC_CHECK_SELECT_RUN, m_ledSelectFire);
	DDX_Control(pDX, IDC_BUTTON_PRODUCT_COUNTER_CLEAR, m_btnProductCounterClear);
	DDX_Control(pDX, IDC_BUTTON_LOT_INPUT, m_btnLotInput);
	DDX_Control(pDX, IDC_BUTTON_CLEAR, m_btnClear);
	DDX_Control(pDX, IDC_BUTTON_VIEW_VACUUM, m_btnVacuumViewer);
	DDX_Control(pDX, IDC_PROGRESS_RUNNING_TIME, m_ctlOneTime);
	DDX_Control(pDX, IDC_PROGRESS_RUNNING_TIME2, m_ctlTotalTime);
	DDX_Control(pDX, IDC_BUTTON_L_PICK_CART, m_btnLPCart);
	DDX_Control(pDX, IDC_BUTTON_L_PICK_TABLE, m_btnLPTable);
	DDX_Control(pDX, IDC_BUTTON_U_PICK_CART, m_btnUPCart);
	DDX_Control(pDX, IDC_BUTTON_U_PICK_TABLE, m_btnUPTable);
	DDX_Control(pDX, IDC_TAB_VIEWER, m_tabAutoRunView);
	DDX_Control(pDX, IDC_BUTTON_CHANGE_DP, m_btnChangeDP);
	DDX_Control(pDX, IDC_LIST_BOARD_LOTID, m_listLotID);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneAutoRun, CFormView)
	//{{AFX_MSG_MAP(CPaneAutoRun)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_VIEW_VACUUM, OnButtonVacuumViewer)
	ON_BN_CLICKED(IDC_BUTTON_CLEAR, OnButtonClear)
	ON_BN_CLICKED(IDC_BUTTON_PRODUCT_COUNTER_CLEAR, OnButtonProductCounterClear)
	ON_BN_CLICKED(IDC_BUTTON_LOT_INPUT, OnButtonLotInput)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHECK_TABLE_SUCTION, OnChkSuction1)
	ON_BN_CLICKED(IDC_CHECK_TABLE_SUCTION2, OnChkSuction2)
	ON_WM_TIMER()
	ON_MESSAGE(AUTO_MSG, OnAutoStartSetting)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_CHECK_SELECT_RUN, OnCheckSelectRun)
	ON_BN_CLICKED(IDC_CHECK_FLUORESCENT_LAMP, OnChkFluorescentLamp)
	ON_MESSAGE(UM_CHANGE_VISION_PARAM2, ChangeVisionParam)
	ON_MESSAGE(UM_CHANGE_VISION_PARAM3, ChangeVisionParameter)
	ON_MESSAGE(UM_VISION_FIND, GetVisionResult)
	ON_MESSAGE(UM_VISION_ROI_SET, SetROI)
	ON_MESSAGE(UM_VISION_LAMP, SetVisionLamp)
	ON_MESSAGE(UM_VISION_ROI_SET_UM, SetROIUM)
	ON_MESSAGE(UM_SAVE_PROJECT, AutoSaveProject)
	ON_MESSAGE(UM_VISION_SAVE, SaveVisionImg)
	ON_MESSAGE(UM_VISION_SAVE_FAIL, SaveVisionFailImg)
	ON_MESSAGE(UM_VISION_FIND_NOGRAP, GetVisionResultNoGrab)
	ON_BN_CLICKED(IDC_BUTTON_L_PICK_TABLE, OnButtonLPickTable)
	ON_BN_CLICKED(IDC_BUTTON_U_PICK_TABLE, OnButtonUPickTable)
	ON_BN_CLICKED(IDC_BUTTON_U_PICK_CART, OnButtonUPickCart)
	ON_BN_CLICKED(IDC_BUTTON_L_PICK_CART, OnButtonLPickCart)
	ON_MESSAGE(UM_POWER_CHECK, OnChangePower)
	ON_NOTIFY(NM_CLICK, IDC_LIST_BOARD_PARAM, OnClickListBoardParam)
	ON_NOTIFY(NM_CLICK, IDC_TAB_VIEWER, OnClickTabViewer)
	ON_BN_CLICKED(IDC_BUTTON_CHANGE_DP, OnButtonChangeDp)
	ON_WM_MOUSEWHEEL()
	//}}AFX_MSG_MAP
	ON_STN_CLICKED(IDC_STATIC_PCB_COUNT, &CPaneAutoRun::OnClickedStaticPcbCount)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRun diagnostics

#ifdef _DEBUG
void CPaneAutoRun::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneAutoRun::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRun message handlers

void CPaneAutoRun::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitStaticControl();
	InitListControl();

	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 0 &&
		gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_PMAC)
		m_ledTableSuction2.ShowWindow(SW_HIDE);

	m_dlgMeasurement.Create(IDD_DLG_LASER_MEASUREMENT);
	m_dlgMeasurement.ShowWindow(SW_HIDE);

	m_dlgOPCWait.Create(IDD_DLG_LASER_MEASUREMENT);
	m_dlgOPCWait.SetUseOnlyOPCWait(TRUE);
	m_dlgOPCWait.ShowWindow(SW_HIDE);

	StartRunThread();

	m_pMotor = gDeviceFactory.GetMotor();

	if(m_pMotor->IsSafetyMode())
		::AfxGetMainWnd()->SendMessage(UM_MODE_CHANGE, SAFETY_MODE);

	m_dlgVacuumViewer.Create(IDD_DLG_VACUUM_VIEWER);
	m_dlgVacuumViewer.ShowWindow(SW_HIDE);

	m_strPLCAlarmLogFile.Format(_T("PlcAlarm"));


	InitAutoRunViewer();

	ChangeDP();
}

void CPaneAutoRun::InitAutoRunViewer()
{
	// Set Button Font
	m_fntTab.CreatePointFont(110, "Arial Bold");
	
	BOOL bRet = 0;
	int nIndex = 0;
	m_tabAutoRunView.SetFont( &m_fntTab );
	
	// Data
	bRet = m_tabAutoRunView.AddPane( _T(" Data "), RUNTIME_CLASS(CPaneAutoRunViewData) );
	if( FALSE != bRet )
	{
		m_pData = static_cast<CPaneAutoRunViewData*>(m_tabAutoRunView.GetPane(nIndex++));
		m_pData->OnInitialUpdate();
	}
	
	//Fiducial
	bRet = m_tabAutoRunView.AddPane( _T(" Fiducial "), RUNTIME_CLASS(CPaneAutoRunViewFiducial) );
	if( FALSE != bRet )
	{
		m_pFiducial = static_cast<CPaneAutoRunViewFiducial*>(m_tabAutoRunView.GetPane(nIndex++));
		m_pFiducial->OnInitialUpdate();
	}

	m_pPrework = NULL;
	if(!gProcessINI.m_sProcessSystem.bNoUsePrework)
	{
			//Pre work
		bRet = m_tabAutoRunView.AddPane( _T(" Pre-Work "), RUNTIME_CLASS(CPaneAutoRunViewPrework) );
		if( FALSE != bRet )
		{
			m_pPrework = static_cast<CPaneAutoRunViewPrework*>(m_tabAutoRunView.GetPane(nIndex++));
			m_pPrework->OnInitialUpdate();
		}
	}
	bRet = m_tabAutoRunView.AddPane( _T(" Status "), RUNTIME_CLASS(CPaneAutoRunViewStatus) );
	if( FALSE != bRet )
	{
		m_pStatus = static_cast<CPaneAutoRunViewStatus*>(m_tabAutoRunView.GetPane(nIndex++));
		m_pStatus->OnInitialUpdate();
	}
#ifdef __KUNSAN_SAMSUNG_LARGE__
	bRet = m_tabAutoRunView.AddPane( _T(" OPC "), RUNTIME_CLASS(CPaneAutoRunViewOPC) );
	if( FALSE != bRet )
	{
		m_pOPC = static_cast<CPaneAutoRunViewOPC*>(m_tabAutoRunView.GetPane(nIndex));
		m_pOPC->OnInitialUpdate();
	}


#endif

//#endif
/*
	//Process
	bRet = m_tabAutoRunView.AddPane( _T(" Process "), RUNTIME_CLASS(CPaneAutoRunViewProcess) );
	if( FALSE != bRet )
	{
		m_pProcess = static_cast<CPaneAutoRunViewProcess*>(m_tabAutoRunView.GetPane(3));
		m_pProcess->OnInitialUpdate();
	}
	

	//System
	bRet = m_tabAutoRunView.AddPane( _T(" System "), RUNTIME_CLASS(CPaneAutoRunViewSystem) );
	if( FALSE != bRet )
	{
		m_pSystem = static_cast<CPaneAutoRunViewSystem*>(m_tabAutoRunView.GetPane(4));
		m_pSystem->OnInitialUpdate();
	}
	*/
#ifdef __KUNSAN_SAMSUNG_LARGE__
	m_tabAutoRunView.ShowPane( nIndex );
#else
	m_tabAutoRunView.ShowPane( 0 );
#endif
}

void CPaneAutoRun::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");

	// Vacuum Viewer
	m_btnVacuumViewer.SetFont( &m_fntBtn );
	m_btnVacuumViewer.SetFlat( FALSE );
	m_btnVacuumViewer.EnableBallonToolTip();
	m_btnVacuumViewer.SetToolTipText( _T("Table Vacuum Viewer") );
	m_btnVacuumViewer.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnVacuumViewer.SetBtnCursor(IDC_HAND_1);

	// Clear
	m_btnClear.SetFont( &m_fntBtn );
	m_btnClear.SetFlat( FALSE );
	m_btnClear.EnableBallonToolTip();
	m_btnClear.SetToolTipText( _T("Working Time Clear") );
	m_btnClear.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnClear.SetBtnCursor(IDC_HAND_1);

	// Product Counter Clear
	m_btnProductCounterClear.SetFont( &m_fntBtn );
	m_btnProductCounterClear.SetFlat( FALSE );
	m_btnProductCounterClear.EnableBallonToolTip();
	m_btnProductCounterClear.SetToolTipText( _T("Product Counter Clear") );
	m_btnProductCounterClear.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnProductCounterClear.SetBtnCursor(IDC_HAND_1);

	// Input Lot
	m_btnLotInput.SetFont( &m_fntBtn );
	m_btnLotInput.SetFlat( FALSE );
	m_btnLotInput.EnableBallonToolTip();
	m_btnLotInput.SetToolTipText( _T("Lot Input") );
	m_btnLotInput.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLotInput.SetBtnCursor(IDC_HAND_1);
	CString strData;
	strData.Format(_T("%d (%d) PCS"), m_nInputLot, m_nLotMarkStartNo);
	m_btnLotInput.SetWindowText( (LPCTSTR)strData );

	// LP Cart
	m_btnLPCart.SetFont( &m_fntBtn );
	m_btnLPCart.SetFlat( FALSE );
	m_btnLPCart.EnableBallonToolTip();
	m_btnLPCart.SetToolTipText( _T("LC Move to Cart") );
	m_btnLPCart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLPCart.SetBtnCursor(IDC_HAND_1);

	// LP Table
	m_btnLPTable.SetFont( &m_fntBtn );
	m_btnLPTable.SetFlat( FALSE );
	m_btnLPTable.EnableBallonToolTip();
	m_btnLPTable.SetToolTipText( _T("LC Move to Table") );
	m_btnLPTable.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnLPTable.SetBtnCursor(IDC_HAND_1);

	// UP Cart
	m_btnUPCart.SetFont( &m_fntBtn );
	m_btnUPCart.SetFlat( FALSE );
	m_btnUPCart.EnableBallonToolTip();
	m_btnUPCart.SetToolTipText( _T("UC Move to Cart") );
	m_btnUPCart.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUPCart.SetBtnCursor(IDC_HAND_1);
	
	// UP Table
	m_btnUPTable.SetFont( &m_fntBtn );
	m_btnUPTable.SetFlat( FALSE );
	m_btnUPTable.EnableBallonToolTip();
	m_btnUPTable.SetToolTipText( _T("UC Move to Table") );
	m_btnUPTable.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnUPTable.SetBtnCursor(IDC_HAND_1);

	// Motor
	m_ledMotor.SetFont( &m_fntBtn );
	m_ledMotor.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMotor.Depress( !m_bMotor );

	// Scanner
	m_ledScanner.SetFont( &m_fntBtn );
	m_ledScanner.SetImage( IDB_LEDCOLOR, 15 );
	m_ledScanner.Depress( !m_bScanner );

	// Vision
	m_ledVision.SetFont( &m_fntBtn );
	m_ledVision.SetImage( IDB_LEDCOLOR, 15 );
	m_ledVision.Depress( !m_bVision );

	// Laser
	m_ledLaser.SetFont( &m_fntBtn );
	m_ledLaser.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLaser.Depress( !m_bLaser );
	
	// Main Power
	m_ledMainPower.SetFont( &m_fntBtn );
	m_ledMainPower.SetImage( IDB_LEDCOLOR, 15 );
	m_ledMainPower.Depress( !m_bMainPower );

	// E-Stop
	m_ledEStop.SetFont( &m_fntBtn );
	m_ledEStop.SetImage( IDB_LEDCOLOR, 15 );
	m_ledEStop.Depress( !m_bEStop );

	// Table Suction1
	m_ledTableSuction.SetFont( &m_fntBtn );
	m_ledTableSuction.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTableSuction.Depress( !m_bTableSuction );

	// Table Suction2
	m_ledTableSuction2.SetFont( &m_fntBtn );
	m_ledTableSuction2.SetImage( IDB_LEDCOLOR, 15 );
	m_ledTableSuction2.Depress( !m_bTableSuction2 );

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
	{
		m_ledTableSuction.SetWindowText("Suction On");
		m_ledTableSuction2.SetWindowText("Suction Off");
	}

	// Initialization
	m_ledInit.SetFont( &m_fntBtn );
	m_ledInit.SetImage( IDB_LEDCOLOR, 15 );
	m_ledInit.Depress( !m_bInit );

	// AutoRun
	m_ledAutoRun.SetFont( &m_fntBtn );
	m_ledAutoRun.SetImage( IDB_LEDCOLOR, 15 );
	m_ledAutoRun.Depress( !m_bAutoRun );

	// select fire
	m_ledSelectFire.SetFont( &m_fntBtn );
	m_ledSelectFire.SetImage( IDB_LEDCOLOR, 15 );
	m_ledSelectFire.Depress( !m_bSelectFire );

	// Fluorescent Lamp
	m_ledFluorescentLamp.SetFont( &m_fntBtn );
	m_ledFluorescentLamp.SetImage( IDB_LEDCOLOR, 15 );
	m_ledFluorescentLamp.Depress( !m_bFluorescentLamp );

	// change DP
	m_btnChangeDP.SetFont( &m_fntBtn );
	m_btnChangeDP.SetFlat( FALSE );
	m_btnChangeDP.EnableBallonToolTip();
	m_btnChangeDP.SetToolTipText( _T("View Change ( Working Time <-> Lot ID Info. )") );
	m_btnChangeDP.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnChangeDP.SetBtnCursor(IDC_HAND_1);


#ifdef __KUNSAN_SAMSUNG_LARGE__
	m_btnChangeDP.ShowWindow(SW_HIDE);
#else
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
		m_btnChangeDP.ShowWindow(SW_HIDE);
#endif
}

void CPaneAutoRun::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	m_fntStaticBig.CreatePointFont(170, "Arial Bold");
	GetDlgItem(IDC_STATIC_DUMMY)->SetFont( &m_fntStaticBig );
	
	// Working Time
	GetDlgItem(IDC_STATIC_WORKING_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_CURRENT_ONE_CYCLE_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ONE_CYCLE_RUNNING_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TOTAL_REMAIN_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_REMAIN_TIME)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AVERAGE_ONE_CYCLE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AVERAGE_ONE_CYCLE_TIME)->SetFont( &m_fntStatic );

	// Progress
	GetDlgItem(IDC_STATIC_PROGRESS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FIRE_SHOT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PCB_COUNT_TITLE)->SetFont( &m_fntStatic );

	m_stcLotHole.SetFont( &m_fntStatic );
	m_stcLotHole.SetForeColor( VALUE_FORE_COLOR );
	m_stcLotHole.SetBackColor( VALUE_BACK_COLOR );

	m_stcTotalHole.SetFont( &m_fntStatic );
	m_stcTotalHole.SetForeColor( VALUE_FORE_COLOR );
	m_stcTotalHole.SetBackColor( VALUE_BACK_COLOR );

	m_stcPCBCounter.SetFont( &m_fntStatic );
	m_stcPCBCounter.SetForeColor( VALUE_FORE_COLOR );
	m_stcPCBCounter.SetBackColor( VALUE_BACK_COLOR );

	// PCB Information
	GetDlgItem(IDC_STATIC_PCB_INFO)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DRILL_DIVISION)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DRILL_DIVISION_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DRILL_METHOD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DRILL_METHOD_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ROTATION)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ROTATION_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LINE_COUNT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LINE_COUNT_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TOTAL_HOLE_COUNT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_TOTAL_HOLE_COUNT_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER_VAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MAIN_AIR_VALUE)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_L_PICK)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_U_PICK)->SetFont( &m_fntStatic );

	// Device Status
	GetDlgItem(IDC_STATIC_DEVICE_STATUS)->SetFont( &m_fntStatic );

	// Drill Status
	m_stcDrillStatus.SetFont( &m_fntStatic );
	m_stcDrillStatus.SetForeColor( BLACK_COLOR );
	m_stcDrillStatus.SetBackColor( WHITE_COLOR );
	m_stcDrillStatus.SetWindowText( _T("Drill Data Preview") );
}

void CPaneAutoRun::InitListControl()
{
	// Set List Font
	m_fntList.CreatePointFont(130, "Arial Bold");

	m_listBoardParam.SetFont( &m_fntList );

	int nMaxColumnNum = 5;
	LV_COLUMN lvcolumn;
	CString strText;
	TCHAR szText[256] = {0,};

	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_CENTER;

	for(int i = 0 ; i < nMaxColumnNum ; i++ )
	{
		switch( i )
		{
		case 0 :
			strText.Format(_T("T"));
			lvcolumn.cx = 45;
			break;
		case 1 :
			strText.Format(_T("Beam Path"));
			lvcolumn.cx = 170;
			break;
		case 2 :
			strText.Format(_T("Type"));
			lvcolumn.cx = 80;
			break;
		case 3 :
			strText.Format(_T("Duty"));
			lvcolumn.cx = 80;
			break;
		case 4 :
			strText.Format(_T("Holes"));
			lvcolumn.cx = 100;
			break;
		}
		_stprintf_s( szText, _T("%s"), strText );
		lvcolumn.pszText = szText;
		lvcolumn.iSubItem = i;

		m_listBoardParam.InsertColumn(i, &lvcolumn);
	}

	DWORD dwStyle = m_listBoardParam.GetStyle();
	dwStyle |= LVS_EX_FULLROWSELECT;
	dwStyle |= LVS_EX_GRIDLINES;

	m_listBoardParam.SetExtendedStyle( dwStyle );

	// lot ID
	m_listLotID.SetFont( &m_fntList );
	
	nMaxColumnNum = 3;
	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_CENTER;
	
	for(int i = 0 ; i < nMaxColumnNum ; i++ )
	{
		switch( i )
		{
		case 0 :
			strText.Format(_T("Lot ID"));
			lvcolumn.cx = 250;
			break;
		case 1 :
			strText.Format(_T("PNL No."));
			lvcolumn.cx = 85;
			break;
		case 2 :
			strText.Format(_T("Status"));
			lvcolumn.cx = 85;
			break;
		}
		_stprintf_s( szText, "%s", strText );
		lvcolumn.pszText = szText;
		lvcolumn.iSubItem = i;
		
		m_listLotID.InsertColumn(i, &lvcolumn);
	}
	
	dwStyle = m_listLotID.GetStyle();
	dwStyle |= LVS_EX_FULLROWSELECT;
	dwStyle |= LVS_EX_GRIDLINES;
	
	m_listLotID.SetExtendedStyle( dwStyle );
}

HBRUSH CPaneAutoRun::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( CTLCOLOR_STATIC == nCtlColor )
	{
		if( GetDlgItem(IDC_STATIC_WORKING_TIME)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_PROGRESS)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_PCB_INFO)->GetSafeHwnd() == pWnd->m_hWnd ||
			GetDlgItem(IDC_STATIC_DEVICE_STATUS)->GetSafeHwnd() == pWnd->m_hWnd )
			pDC->SetTextColor( RGB(0, 0, 255 ) );

	}
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneAutoRun::OnButtonLotInput() 
{
	if(IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}

	GetLotCntAndMarkIndex();
}

void CPaneAutoRun::ResetLotCountAndData()
{
	m_nCycleCount = 0;
	m_nCurrentLotCount = 0;
	m_nCurrentLotIndex = 0;
	m_nTotalCurrentLotCount = 0;
	m_nNGLotCount	   = 0;
	m_nTotalHoleCount = 0;
	m_nTotalLineCount = 0;
	m_nLotHoleCount = 0;
	m_nLotLineCount = 0;
	m_nLotMarkCurrent = 0;
	m_dCurrentScaleX[0] = m_dCurrentScaleX[1] = m_dCurrentScaleY[0] = m_dCurrentScaleY[1] = 100;
	m_dAvgScaleX = m_dAvgScaleY = 100;
//	m_nPrevMarkingCount = 0;
	m_pFiducial->RemoveList();
	m_nCurrentPrjIndex	= -1;

	if(m_pPrework)
		m_pPrework->m_pPower->RemoveList();
	memset( &gLotInfo, 0, sizeof(gLotInfo));

	ChangeLotIDInfo();
	OnButtonClear();

	CString strFile, strLog;
	strFile.Format(_T("Button"));
	strLog.Format(_T("Excellon file re-open : reset count"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
}

void CPaneAutoRun::OnButtonProductCounterClear()
{
	
	if(IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}
	m_nCycleCount = 0;
	m_nCurrentLotCount = 0;
	m_nCurrentLotIndex = 0;
	m_nTotalCurrentLotCount = 0;
	m_nNGLotCount	   = 0;
	m_nTotalHoleCount = 0;
	m_nTotalLineCount = 0;
	m_nLotHoleCount = 0;
	m_nLotLineCount = 0;
	m_nLotMarkCurrent = 0;
	m_dCurrentScaleX[0] = m_dCurrentScaleX[1] = m_dCurrentScaleY[0] = m_dCurrentScaleY[1] = 100;
	m_dAvgScaleX = m_dAvgScaleY = 100;
//	m_nPrevMarkingCount = 0;
	m_pFiducial->RemoveList();
	m_nCurrentPrjIndex	= -1;

	if(m_pPrework)
		m_pPrework->m_pPower->RemoveList();
	memset( &gLotInfo, 0, sizeof(gLotInfo));
	if(gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		for(int k = 0; k<10; k++)
		{
			if(k%2 == 1)
				gLotInfo.nComSol[k] = 3;
			else
				gLotInfo.nComSol[k] = 2;
		}
	}
	else
	{
		memset(gLotInfo.szLotID, 0 , sizeof(gLotInfo.szLotID));
		strcpy_s(gLotInfo.szLotID[0], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szPrj[0], gDProject.m_szProjectName); 
		gLotInfo.nLastIndex = 1;
	}

	UpdateOPCDisplay(TRUE);
	ChangeLotIDInfo();
	OnButtonClear();

	CString strFile, strLog;
	strFile.Format(_T("Button"));
	strLog.Format(_T("Lot Clear"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
}

void CPaneAutoRun::OnButtonVacuumViewer()
{
	CRect rtPos;
	GetDlgItem(IDC_BUTTON_PRODUCT_COUNTER_CLEAR)->GetWindowRect( rtPos );

	CRect rcPane;
	rcPane.top		= rtPos.top;
	rcPane.left		= rtPos.left;
	rcPane.right	= rtPos.left + 360;
	rcPane.bottom	= rtPos.top + 300;

#ifndef __MP920_MOTOR__
	m_dlgVacuumViewer.MoveWindow(rcPane);
	
	m_dlgVacuumViewer.ShowWindow(SW_SHOW);
	m_dlgVacuumViewer.SetMotor(gDeviceFactory.GetMotor());
	m_dlgVacuumViewer.InitTimer();

#endif
}

void CPaneAutoRun::OnButtonClear()
{
	if(IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}

	m_dAvrProcessTime = 0.0;
	
	m_dAvrTime = 0.0;
	m_dPriTime = 0.0;
	m_dAvgMarkingTime = 0.0;

}

BOOL CPaneAutoRun::DestroyWindow() 
{
	return CFormView::DestroyWindow();
}

void CPaneAutoRun::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntList.DeleteObject();
	m_fntStatic.DeleteObject();
	m_fntStaticBig.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneAutoRun::OnCamChange(int nCamNo)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->OnCamChange( nCamNo );
}

void CPaneAutoRun::OnMoveVisionView()
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		int nSel = m_tabAutoRunView.GetCurSel();
		if(nSel == 1)
		{
			m_pFiducial->OnMoveVisionView();	
		}
		else
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->ShowWindow( SW_HIDE );
		}
	}
	else if(gSystemINI.m_sHardWare.nVisionType == MATROX_VISION)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->SetPanelNo(MAIN_VISION_VIEW);

		CRect rtPos;
		GetDlgItem(IDC_STATIC_VISION_VIEW)->GetWindowRect( rtPos );
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pMatroxVisionView->MoveWindow( &rtPos );
	}
	else if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
  		int nSel = m_tabAutoRunView.GetCurSel();
		if(nSel == 1)
		{
			m_pFiducial->OnMoveVisionView();	
		}
		else
		{
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionProView->ShowWindow( SW_HIDE );
		}
	}
}

BOOL CPaneAutoRun::ThickMeasurement()
{
	MoveShutterToDrillPanel(FALSE);

	CString strSequenceLog;
	strSequenceLog.Format(_T("---Thick Measurement Start---"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 1)
		return TRUE;
	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() < 2 &&
		gDProject.m_nSeparation == USE_2ND)
	{
		return TRUE;
	}
	
	CDlgMeasuringPCBThickness dlg;
	
	dlg.SetBaseZ( gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dBaseZ,
		gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dBaseZ);

	if(gDProject.m_nSeparation != USE_2ND || gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() <= 1)
	{
		dlg.SetPosition( gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dAutoX,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dAutoY,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dHeadZ,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dHeadZ);
		if(gDProject.m_nSeparation == USE_DUAL && m_bOdd)
		{
			dlg.AutoSelectHead(1);
			dlg.SelectHead(1);
		}
		else if(gDProject.m_nSeparation == USE_DUAL)
		{
			dlg.AutoSelectHead(0);
			dlg.SelectHead(0);
		}
		else
		{
			dlg.AutoSelectHead(1);
			dlg.SelectHead(1);
		}
	}
	else
	{
		dlg.SetPosition( gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dAutoX,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dAutoY,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[0].dHeadZ,
			gProcessINI.m_sProcessAutoSetting.sHeightSensor[1].dHeadZ );
		dlg.AutoSelectHead(2);
		dlg.SelectHead(2);
	}
	dlg.ChangeHeadSelectStatus(FALSE);
	
	dlg.AutoStart();
	double dThickness;
	CString strData;

	if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() > 1 && 
		gDProject.m_nSeparation == USE_2ND)
	{
		dThickness = dlg.GetHeight(FALSE);
		strSequenceLog.Format(_T("2nd Panel Thickness = %.3f"), dThickness);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
		//GetVacuum;
	
		gOPCParam.dHeight[1] = dThickness;
			
		if(m_nUserLevel < 3)
		{
			if( dThickness <=0 || 
				dThickness > gDProject.m_dPcbThick2 * 1.5 || dThickness < gDProject.m_dPcbThick2 * 0.5 )
			{
				m_nErrMsgID = STDGNALM702;
				return FALSE;
			}
		}
		gDProject.m_dPcbThick = gDProject.m_dPcbThick2 = dThickness;
	}
	else if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() > 1 && 
		gDProject.m_nSeparation == USE_DUAL && m_bOdd)
	{
		dThickness = dlg.GetHeight();
		strSequenceLog.Format(_T("1st Panel Thickness = %.3f"), dThickness);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
		gOPCParam.dHeight[0] = dThickness;
		if(m_nUserLevel < 3)
		{
			if( dThickness <=0. ||
				dThickness > gDProject.m_dPcbThick * 1.5 || dThickness < gDProject.m_dPcbThick * 0.5 )
			{
				m_nErrMsgID = STDGNALM702;
				return FALSE;
			}
		}
		gDProject.m_dPcbThick = dThickness;
	}
	else if(gEasyDrillerINI.m_clsHwOption.GetHeightSensorNum() > 1 && 
		gDProject.m_nSeparation == USE_DUAL)
	{
		dThickness = dlg.GetHeight();
		strSequenceLog.Format(_T("1st Panel Thickness = %.3f"), dThickness);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
		gOPCParam.dHeight[0] = dThickness;
		if(m_nUserLevel < 3)
		{
			if( dThickness <=0. ||
				dThickness > gDProject.m_dPcbThick * 1.5 || dThickness < gDProject.m_dPcbThick * 0.5 )
			{
				m_nErrMsgID = STDGNALM702;
				return FALSE;
			}
		}
		gDProject.m_dPcbThick = dThickness;
		
		dThickness = dlg.GetHeight(FALSE);
		strSequenceLog.Format(_T("2nd Panel Thickness = %.3f"), dThickness);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
		gOPCParam.dHeight[1] = dThickness;
		if(m_nUserLevel < 3)
		{
			if( dThickness <=0.||
				dThickness > gDProject.m_dPcbThick2 * 1.5 || dThickness < gDProject.m_dPcbThick2 * 0.5 )
			{
				m_nErrMsgID = STDGNALM702;
				return FALSE;
			}
		}
		gDProject.m_dPcbThick2 = dThickness;
	}
	else
	{
		dThickness = dlg.GetHeight();
		strSequenceLog.Format(_T("1st Panel Thickness = %.3f"), dThickness);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
		gOPCParam.dHeight[0] = dThickness;
		if(m_nUserLevel < 3)
		{
			if( dThickness <=0. ||
				dThickness > gDProject.m_dPcbThick * 1.5 || dThickness < gDProject.m_dPcbThick * 0.5 )
			{
				m_nErrMsgID = STDGNALM702;
				return FALSE;
			}
		}
		gDProject.m_dPcbThick = gDProject.m_dPcbThick2 = dThickness;
	}

	OPCUpdateParameter(N_HEIGHT);
	return TRUE;
}

BOOL CPaneAutoRun::OpticShutterOpen(BOOL bOpen)
{
	if(!bOpen)
	{
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE)) // 090805 shutter close
		{
			m_nErrMsgID = STDGNALM417; // shutter sensor error
			return FALSE;
		}
		return TRUE;
	}

	if(gDProject.m_nSeparation == USE_DUAL)
	{
		if(m_bOdd)
		{
			if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, FALSE, FALSE))
			{
				m_nErrMsgID = STDGNALM417; // shutter sensor error
				return FALSE;
			}
		}
		else
		{
			if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, TRUE, FALSE))
			{
				m_nErrMsgID = STDGNALM417; // shutter sensor error
				return FALSE;
			}
		}
	}
	else if(gDProject.m_nSeparation == USE_1ST)
	{
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, FALSE, FALSE))
		{
			m_nErrMsgID = STDGNALM417; // shutter sensor error
			return FALSE;
		}
	}
	else
	{
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, TRUE, FALSE))
		{
			m_nErrMsgID = STDGNALM417; // shutter sensor error
			return FALSE;
		}
	}
	return TRUE;
}

BOOL CPaneAutoRun::MoveShutterToDrillPanel(BOOL bOpen)
{
	if(bOpen)
	{
		if(!gProcessINI.m_sProcessSystem.bCheckPreworkData && !gProcessINI.m_sProcessSystem.bDryRun)
		{	// 090805 shutter open
			if(gDProject.m_nSeparation == USE_DUAL)
			{
				if(m_bOdd)
				{
					if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, FALSE, FALSE))
					{
						m_nErrMsgID = STDGNALM417; // shutter sensor error
						return FALSE;
					}
				}
				else
				{
					if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, TRUE, FALSE))
					{
						m_nErrMsgID = STDGNALM417; // shutter sensor error
						return FALSE;
					}
				}
			}
			else if(gDProject.m_nSeparation == USE_1ST)
			{
				if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, FALSE, FALSE))
				{
					m_nErrMsgID = STDGNALM417; // shutter sensor error
					return FALSE;
				}
			}
			else
			{
				if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, TRUE, FALSE))
				{
					m_nErrMsgID = STDGNALM417; // shutter sensor error
					return FALSE;
				}
			}
		}
		else
		{
			if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
			{
				m_nErrMsgID = STDGNALM417; // shutter sensor error
				return FALSE;
			}
		}
	}
	else
	{
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
		{
			m_nErrMsgID = STDGNALM417; // shutter sensor error
			return FALSE;
		}
	}
	return TRUE;
}

BOOL CPaneAutoRun::FindFiducialForDrill(int nFidKind, int nFindMethod, int nFidBlock, LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd)
{
	CString strSequenceLog;
	if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, TRUE);

	if(gProcessINI.m_sProcessSystem.bShowAllFidImage)
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_FIDUCIALVIEW, TRUE);

	CString strFidTimeFile, strFidTime;
	strFidTimeFile.Format(_T("FindFidTime"));
	CCorrectTime pTimer;
	pTimer.StartTime();

	m_bRetryFidFind = FALSE;
	for(int i = 0; i < 2; i++)
	{
		if(!FindFiducialAndApply(nFidKind, nFindMethod, nFidBlock, pPanel1st, pPanel2nd)) // 20130404 bhlee
		{
			strSequenceLog.Format(_T("---Find Fiducial Fail--- ( %d try)"), i + 1);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));

			if(i == 0 && m_bRetryFidFind) // 처음이고 scale 문제라면....
			{
				ResetFidResult(pPanel1st, pPanel2nd, nFidBlock, nFidKind);
				continue;
			}
			if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
				::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);

			m_bRetryFidFind = FALSE;
			::AfxGetMainWnd()->SendMessage(UM_CHANGE_VIEW, VIEW_FIDUCIAL);
			m_pFiducial->m_bDrawMode = TRUE;
			m_pFiducial->DrawFiducial(m_nListCount);
			return FALSE; // Message add
		}
		else
			break;
	}

	m_bRetryFidFind = FALSE;
	strFidTime.Format(_T("[%d] %s : %d = %.1f"), m_nCurrentLotIndex, gLotInfo.szLotID[m_nCurrentLotIndex], m_nCurrentLotCount, pTimer.PresentTime());
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFidTimeFile), reinterpret_cast<LPARAM>(&strFidTime));

	strSequenceLog.Format(_T("---Find Fiducial End---"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
		
	if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);

	return TRUE;
}

BOOL CPaneAutoRun::PCBReject()// 20130404 bhlee : no use
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if( pMotor->IsAnyError() )
	{
		ErrMessage(_T("Please Reset Error"));
		return FALSE;
	}
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		::ErrMsgDlg(STDGNALM209);
		return FALSE;
	}
	
	if(pMotor->IsSafetyMode())
	{
		::ErrMsgDlg(STDGNALM207);
		return FALSE;
	}
	
	if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX, gProcessINI.m_sProcessAutoSetting.dLoadPosY, TRUE))
	{
		::ErrMsgDlg(STDGNALM438);
		return FALSE;
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis, TRUE);
		return FALSE;
	}
	if(gProcessINI.m_sProcessOption.bRejectSuctionOff)
	{
#ifndef __MP920_MOTOR__
	pMotor->WriteOutputIOBIt(2, 0, FALSE);
	pMotor->WriteOutputIOBIt(2, 1, TRUE);

	pMotor->WriteOutputIOBIt(2, 2, FALSE);
	pMotor->WriteOutputIOBIt(2, 3, TRUE);
#else
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT +  PORT_TABLE_SUCTION, 0 );
#endif
	}

	pMotor->TableClamp(FALSE, TRUE);
	pMotor->TableClamp(FALSE, FALSE);

//	gDeviceFactory.GetMotor()->TablePCBReset();
//	::Sleep(3000);

	CString strSequenceLog;
	strSequenceLog.Format(_T("Reject Complete"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));

	return TRUE;
}
void CPaneAutoRun::CreateFidResult(LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd)
{
	int nCnt;
	LPFIDDATA pFidData;
	
	int nAddProperty, nDelProperty;
	for(int nFidKind = DEFAULT_FID_INDEX; nFidKind <= ADDED_FID_INDEX; nFidKind++)
	{
		if(nFidKind == DEFAULT_FID_INDEX)
		{
			nAddProperty = FID_FIND; nDelProperty = FID_VERIFY;
		}
		else
		{
			nAddProperty = FID_DRILL, nDelProperty = NULL;
		}
		for(int i = 0; i <= gDProject.m_nMaxFidBlock; i++)
		{
			nCnt = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, nAddProperty, nDelProperty, i);
			for(int k = 0; k < nCnt; k++) 
			{
				pFidData = gDProject.m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, k, nAddProperty, nDelProperty, i);
		
				if(pPanel1st != NULL)
				{
					LPFIDRESULT pFidResult = new FID_RESULT;
				
					pFidResult->nFindIndex = pFidData->nFindIndex;
					pFidResult->npRefPosition.x = pFidData->npPosition.x;
					pFidResult->npRefPosition.y = pFidData->npPosition.y;
					pFidResult->nFidBlock = i;	
					pFidResult->dScale = 999;
					pFidResult->npOffset.x = 0;
					pFidResult->npOffset.y = 0;
					pFidResult->bFound = FALSE;
					pFidResult->nFidKind = nFidKind;
				
					pPanel1st->FidResult.AddTail(pFidResult);
				}
				if(pPanel2nd != NULL)
				{
					LPFIDRESULT pFidResult2 = new FID_RESULT;
			
					pFidResult2->nFindIndex = pFidData->nFindIndex;
					pFidResult2->npRefPosition.x = pFidData->npPosition.x;
					pFidResult2->npRefPosition.y = pFidData->npPosition.y;
					pFidResult2->nFidBlock = i;
					pFidResult2->dScale = 999;
					pFidResult2->npOffset.x = 0;
					pFidResult2->npOffset.y = 0;
					pFidResult2->bFound = FALSE;
					pFidResult2->nFidKind = nFidKind;

					pPanel2nd->FidResult.AddTail(pFidResult2);
				}
			}
		}
	}
}
void CPaneAutoRun::ResetFidResult(LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd, int nFidBlock, int nFidKind)
{
	int nAddProperty, nDelProperty;
	if(nFidKind == DEFAULT_FID_INDEX)
	{
		nAddProperty = FID_FIND; nDelProperty = FID_VERIFY;
	}
	else
	{
		nAddProperty = FID_DRILL, nDelProperty = NULL;
	}

	LPFIDRESULT pFidResult, pFidResult2;
	int nCnt;
	LPFIDDATA pFidData;
	if(nFidBlock == -1)
	{
		for(int q = 0; q <= gDProject.m_nMaxFidBlock; q++)
		{
			nCnt= gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, nAddProperty, nDelProperty, q);
			for(int i = 0; i < nCnt; i++) 
			{
				pFidData = gDProject.m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, i, nAddProperty, nDelProperty, q);
				if(pPanel1st != NULL)
				{
					pFidResult = gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].GetFidResult(pPanel1st, pFidData->npPosition , q);
					if(pFidResult)
					{
						pFidResult->dScale = 999;
						pFidResult->npOffset.x = 0;
						pFidResult->npOffset.y = 0;
						pFidResult->bFound = FALSE;

					}
				}
				if(pPanel2nd != NULL)
				{			
					pFidResult2 = gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].GetFidResult(pPanel2nd,  pFidData->npPosition , q);
					if(pFidResult2)
					{
						pFidResult2->dScale = 999;
						pFidResult2->npOffset.x = 0;
						pFidResult2->npOffset.y = 0;
						pFidResult2->bFound = FALSE;
					}
				}
			}
		}
	}
	else
	{
		nCnt= gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, nAddProperty, nDelProperty, nFidBlock);
		for(int i = 0; i < nCnt; i++) 
		{
			pFidData = gDProject.m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, i, nAddProperty, nDelProperty, nFidBlock);
			if(pPanel1st != NULL)
			{
				pFidResult = gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].GetFidResult(pPanel1st, pFidData->npPosition , nFidBlock);
				if(pFidResult)
				{
					pFidResult->dScale = 999;
					pFidResult->npOffset.x = 0;
					pFidResult->npOffset.y = 0;
					pFidResult->bFound = FALSE;
				}
			}
			if(pPanel2nd != NULL)
			{			
				pFidResult2 = gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].GetFidResult(pPanel2nd, pFidData->npPosition , nFidBlock);
				if(pFidResult2)
				{
					pFidResult2->dScale = 999;
					pFidResult2->npOffset.x = 0;
					pFidResult2->npOffset.y = 0;
					pFidResult2->bFound = FALSE;
				}
			}
		}
	}
}
void CPaneAutoRun::InsertFidResult(BOOL b1stPanel, CPoint npFile, int nFidBlock, LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd, double dVal1, double dVal2 )
{
	LPFIDRESULT pResult = NULL;
	if(b1stPanel)
	{
		if(pPanel1st != NULL)
			pResult = gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].GetFidResult(pPanel1st,npFile, nFidBlock);
		else
			return;
	}
	else
	{
		if(pPanel2nd != NULL)
			pResult = gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].GetFidResult(pPanel2nd,npFile, nFidBlock);
		else
			return;
	}
	
	if(pResult == NULL)
		return;

	pResult->npOffset.x = (int)(dVal1);
	pResult->npOffset.y = (int)(dVal2);
	pResult->bFound = TRUE;
}
BOOL CPaneAutoRun::DrillOneBoard()
{
	gDeviceFactory.GetMotor()->SetOutPort((BYTE)(ADD0B_WRITE_OUTPORT + PORT_DRILL_START), 1, TRUE);

//	memset(m_pcField, NULL, sizeof(BYTE) * 32000 * 32000);

	m_bFireDataDoing = FALSE;
	TRACE("One Board In\n");
	m_nLotHoleCount = 0;
	m_nLotLineCount = 0;
	
	gDProject.ResetFireStatus();
	int nFindMethod;
	CString strSequenceLog;
	if(m_bAutoRun)
		nFindMethod = FIND_ALL_FID;
	else
	{
		if(m_bSelectFire)
			nFindMethod = FIND_SELECT_ONLY;
		else
			nFindMethod = FIND_VISIBLE_ONLY;
	}
	LPPNLFIDINFO pPanel1st, pPanel2nd;
	pPanel1st = pPanel2nd = NULL;

	if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST)
	{
		pPanel1st = new PNLFID_INFO; 
		pPanel1st->nPanelNo = m_nCurrentLotCount;
		pPanel1st->b1st = TRUE;
		pPanel1st->nNGType = FID_NG_NO;
		::AfxGetMainWnd()->SendMessage(UM_FID_FIND_RESULT, pPanel1st->nPanelNo);
		gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].AddPanel(pPanel1st);
	}
	if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_2ND)
	{
		pPanel2nd = new PNLFID_INFO;
		pPanel2nd->nPanelNo = m_nCurrentLotCount;
		if(gDProject.m_nSeparation == USE_DUAL) 
			pPanel2nd->nPanelNo = m_nCurrentLotCount + 1;
		pPanel2nd->b1st = FALSE;
		pPanel2nd->nNGType = FID_NG_NO;
		::AfxGetMainWnd()->SendMessage(UM_FID_FIND_RESULT, pPanel2nd->nPanelNo);
		gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].AddPanel(pPanel2nd);
	}

	CreateFidResult(pPanel1st, pPanel2nd);
		
	if(gDProject.m_bSkivingMode) //gDProject.m_Glyphs.GetUseFidCount(ADDED_FID_INDEX) != 0) // use skiving
		nFindMethod = FIND_ALL_FID;


	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE)) // 090805 shutter close
	{
		m_nErrMsgID = STDGNALM417; // shutter sensor error
		return FALSE;
	}

///* 110825 AutoRun중에 MPG 동작을 못해서 이 기능 사용 할 수 없다
	if(!(gDProject.m_nDataLoadStep & SET_FID_ORIGIN ) && m_nCurrentLotCount == 0)
	{
		double dX, dY;
		CalRefFidPos(dX, dY);
		if(!ManualFidFind(dX, dY, DEFAULT_FID_INDEX))
		{
			gDProject.ResetFireStatus();
			return FALSE;
		}
		this->SendMessage(UM_SAVE_PROJECT, NULL, NULL);
	}
	
	::AfxGetMainWnd()->SendMessage(UM_CHANGE_VIEW, VIEW_FIDUCIAL);

	int nStartFidBlock, nEndFidBlock;
	if(gDProject.m_bMultiFidAscentOrder)
	{
		nStartFidBlock = 0; nEndFidBlock = gDProject.m_nMaxFidBlock;
	}
	else
	{
		nStartFidBlock = nEndFidBlock = -1; // 한번에 모든 fid block을 가공한다.
	}
	m_bCalFidPosWithFirst2Point = TRUE;

	
	for(int i = nStartFidBlock; i <= nEndFidBlock; i++)
	{
		if(!MoveShutterToDrillPanel(FALSE))
					return FALSE;

		if(!FindFiducialForDrill(DEFAULT_FID_INDEX , nFindMethod, i, pPanel1st, pPanel2nd))
		{
			if(!gProcessINI.m_sProcessSystem.bNoUseNGBox) //20130502 bskim
			{
				NGBoxCheck(m_nNGBoxCondition);
				if(m_nBackupSeparation == USE_DUAL && m_nNGBoxCondition == 3)
					return TRUE;
				else if(m_nBackupSeparation == USE_1ST && m_nNGBoxCondition == 1)
					return TRUE;
				else if(m_nBackupSeparation == USE_2ND && m_nNGBoxCondition == 2)
					return TRUE;
			}
			else
			{
				gDProject.ResetFireStatus();
				return FALSE;
			}
		}

		
		if(!gProcessINI.m_sProcessSystem.bNoUseNGBox)
			NGBoxCheck(m_nNGBoxCondition);
		
		if(!CheckStatus())
			return FALSE;

		if(i == nStartFidBlock)
		{
			if(gDProject.m_bSkivingMode)// && !gProcessINI.m_sProcessSystem.bPowerCheckMode) //gDProject.m_Glyphs.GetUseFidCount(ADDED_FID_INDEX) != 0) // use skiving
			{
				if(!MoveShutterToDrillPanel(TRUE))
					return FALSE;
				
				if(!SkivingFire(!m_bAutoRun))// fire skiving : manual 인경우에는 스카이빙 가공 하기 전에 가공이 이미 되어 있는지 확인해야 함.
				{
					gDProject.ResetFireStatus();
					return FALSE;
				}
				// find skiving fid
				if(!MoveShutterToDrillPanel(FALSE))
					return FALSE;

				if(!FindFiducialForDrill(ADDED_FID_INDEX , FIND_ALL_FID, i , pPanel1st, pPanel2nd))
				{
					if(!gProcessINI.m_sProcessSystem.bNoUseNGBox) //20130502 bskim
					{
						NGBoxCheck(m_nNGBoxCondition);
						
						if(m_nBackupSeparation == USE_DUAL && m_nNGBoxCondition == 3)
							return TRUE;
						else if(m_nBackupSeparation == USE_1ST && m_nNGBoxCondition == 1)
							return TRUE;
						else if(m_nBackupSeparation == USE_2ND && m_nNGBoxCondition == 2)
							return TRUE;
						
					}
					else
					{
						gDProject.ResetFireStatus();
						return FALSE;
					}
				}
				if(!gProcessINI.m_sProcessSystem.bNoUseNGBox)
					NGBoxCheck(m_nNGBoxCondition);
			}

			// find rotated info hole
			if(!VerifyFiducialOrRecheckFidAfterFire(FALSE)) // Verify
			{
				m_nErrMsgID = STDGNALM782;
				gDProject.ResetFireStatus();
				return FALSE; // Message add
			}
		}
		if(!CheckStatus())
			return FALSE;

		if(!MoveShutterToDrillPanel(TRUE))
			return FALSE;

		::AfxGetMainWnd()->SendMessage(UM_CHANGE_VIEW, VIEW_DATA); //20120105 bskim fiducial 찾은 후 data 가공 화면 전환
		if(i == nStartFidBlock)
		{

			if(gDProject.m_nHoleFind == PRE_FIND)
			{
				if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
					::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, TRUE);

				if(!HoleFind())
				{
					CString strSequenceLog;
					strSequenceLog.Format(_T("---Pre Hole Find Fail---"));
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
					if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
						::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);
					m_nErrMsgID = STDGNALM786;
					gDProject.ResetFireStatus();
					return FALSE; // Message add
				}
				CString strSequenceLog;
				strSequenceLog.Format(_T("---Pre Hole Find End---"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
				if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
					::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);
			}
		}
		m_bFireDataDoing = TRUE;

		if(m_bUseManualDrillDummy)
		{
			double dStartTime;
			double dDummyTime;
			if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
				dDummyTime= gSystemINI.m_sSystemDump.nStandbyTime;
			else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
				dDummyTime = gSystemINI.m_sSystemDump.nStandbyTime2;

			dStartTime = gDeviceFactory.GetEocard()->GetDummyFreeStart();
			if(dDummyTime > dStartTime)
			{
				if(!DoStandby(dDummyTime - dStartTime))
				{
					m_bUseManualDrillDummy = FALSE;
					return FALSE;
				}
			}
			m_bUseManualDrillDummy = FALSE;
		}

		if(!SetAutoTemperature(TRUE))
			return FALSE;
		
		if(!gProcessINI.m_sProcessSystem.bDryRun)
		{
				m_nDrillOneBoardEndTime = 0;
		}

		if(!FireBoard(FALSE, i))// fire data
		{
			strSequenceLog.Format(_T("---Fire Board Fail---"));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
			gDProject.ResetFireStatus();
			if(!gProcessINI.m_sProcessSystem.bDryRun)
			{
				m_nDrillOneBoardEndTime = 0;
				if(!SetAutoTemperature(FALSE))
					return FALSE;	
			}
			return FALSE;
		}
		if(!gProcessINI.m_sProcessSystem.bDryRun)
		{
			m_nDrillOneBoardEndTime = 0;
			if(!SetAutoTemperature(FALSE))
				return FALSE;	
		}
		strSequenceLog.Format(_T("---Fire Board End---"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
	}

	if(!IsGoodFireCount())
	{
		strSequenceLog.Format(_T("LotHoleCount : %d , TotalHole : %d, SelectFireHole : %d, VisibleHole : %d"), m_nLotHoleCount, gDProject.m_nTotalHole, gDProject.m_nSelectFireHole, gDProject.m_nVisibleHole);
		m_nErrMsgID = STDGNALM603;
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
		gDProject.ResetFireStatus();
		return FALSE; // Message add  
	}

	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
	{
		m_nErrMsgID = STDGNALM417; // shutter sensor error
		gDProject.ResetFireStatus();
		return FALSE;
	}

	if(gProcessINI.m_sProcessFidFind.bAutoFidRecheck)
	{
		if(!VerifyFiducialOrRecheckFidAfterFire(TRUE))
		{
			m_nErrMsgID = STDGNALM783;
			gDProject.ResetFireStatus();
			return FALSE; // Message add
		}
	}

	if(gDProject.m_nHoleFind == POST_FIND)
	{
		if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
			::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, TRUE);

		if(!HoleFind())
		{
			CString strSequenceLog;
			strSequenceLog.Format(_T("---Post Hole Find Fail---"));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
			if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
				::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);
			m_nErrMsgID = STDGNALM786;
			gDProject.ResetFireStatus();
			return FALSE; // Message add
		}
		CString strSequenceLog;
		strSequenceLog.Format(_T("---Post Hole Find End---"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
		if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
			::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);
	}
	if( m_bAutoRun && !gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
		m_bNeedUnload = TRUE;
	gDProject.ResetFireStatus();
	return TRUE;
}

BOOL CPaneAutoRun::FindFiducialAndApply(int nFidKind, int nFindMethod, int nFidBlock, LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd)
{
	CString strSequenceLog, strEvent;
	strSequenceLog.Format(_T("---Find Fiducial Start---"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
	gDProject.m_Glyphs.ResetFidAcquireRet(DEFAULT_FID_INDEX);

	HVision* pVision = gDeviceFactory.GetVision();
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	CPoint nFidFilePos;
	CDPoint dIndexP, dOffsetP, dOffsetP2;
	double  dZOffset = 0;
	BOOL	bCoaseFid = FALSE;
	int nFindCount = 0;
 	m_nNGBoxCondition = 0;

	C2DTransform myTrans, myTrans2, myTrans3, myTrans4; //myTrans3, myTrans4 --> Coarse Fiducial 보정용 변수

	int nPanelNo = m_nCurrentLotCount;

	BOOL b1stContinue = TRUE, b2ndContinue = TRUE;

	CString strFile, strFidOffset;
	CDPoint dOffsetDataP;
	strFile.Format(_T("FidOffsetData"));
	CString strFile2, strLog;
	strFile2.Format(_T("CheckTrans"));

	this->SendMessage(UM_VISION_ROI_SET, 0, HIGH_1ST_CAM);
	this->SendMessage(UM_VISION_ROI_SET, 0, LOW_1ST_CAM);
	this->SendMessage(UM_VISION_ROI_SET, 0, HIGH_2ND_CAM);
	this->SendMessage(UM_VISION_ROI_SET, 0, LOW_2ND_CAM);

	double dManualX = 0.0, dManualY = 0.0;
 	LPFIDDATA pFidData, pFidFirstData;

	if(!gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
	{
		if(!gSystemINI.m_sSystemDevice.nNoUseVision)
		{
			int nAddProperty = 0, nDelProperty = 0;
			if(nFidKind == DEFAULT_FID_INDEX)
			{
				nAddProperty = FID_FIND;
				nDelProperty = FID_VERIFY;
			}
			else
			{
				nAddProperty = FID_DRILL;
			}
			int nCnt = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, nAddProperty, nDelProperty, nFidBlock);
			int nCntPrimary = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, FID_PRIMARY, nDelProperty, nFidBlock);
			int nCntSecondary = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, FID_SECONDARY, nDelProperty, nFidBlock);

			double dx, dy;
			CPoint tempOffset;

			myTrans.SetNumPoint(2);
			myTrans2.SetNumPoint(2);

			if(nCntPrimary <= 4)
			{
				myTrans3.SetNumPoint(nCntPrimary);
				myTrans4.SetNumPoint(nCntPrimary);
			}
			else
			{
				myTrans3.SetNumPoint(4);
				myTrans4.SetNumPoint(4);
			}

			int nFidCenterX[MAX_FID_BLOCK] = {0, }, nFidCenterY[MAX_FID_BLOCK] = {0, };
			int nFidCntPerBlock[MAX_FID_BLOCK] = {0, };
			for(int i = 0; i < nCnt; i++) // 4 fid center 구하기
			{
				pFidData = gDProject.m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, i, nAddProperty, nDelProperty, nFidBlock);
				nFidCenterX[pFidData->nFidBlock] += pFidData->npPosition.x; nFidCenterY[pFidData->nFidBlock] += pFidData->npPosition.y;
				nFidCntPerBlock[pFidData->nFidBlock]++;
			}
			if(nCnt > 0)
			{
				if(nFidBlock == -1)
				{
					for(int i = 0; i <= gDProject.m_nMaxFidBlock; i++)
					{
						nFidCenterX[i] /= nFidCntPerBlock[i]; nFidCenterY[i] /= nFidCntPerBlock[i];
					}
				}
				else
				{
					nFidCenterX[nFidBlock] /= nFidCntPerBlock[nFidBlock]; nFidCenterY[nFidBlock] /= nFidCntPerBlock[nFidBlock];
				}
			}
			int nStartBlock = nFidBlock, nEndBlock = nFidBlock;
			if(nFidBlock == -1) // 전체를 한번에 찾는 경우에는
			{
				nStartBlock = 0; nEndBlock = 1;
			}
			for(int nBlockOrder = nStartBlock; nBlockOrder <= nEndBlock; nBlockOrder++)
			{
				for(int i = 0; i < nCnt; i++) // fid 개수만큼 찾기
				{
					pFidData = gDProject.m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, i, nAddProperty, nDelProperty, nFidBlock);

					if(nFidBlock == -1) // 전체를 한번에 찾는 경우에는
					{
						if(pFidData->nFidBlock != 0 && nBlockOrder == 0)
							continue;
						if(pFidData->nFidBlock == 0 && nBlockOrder == 1) // 나머지 블럭들 피듀셜은 한번에 찾는다.
							continue;
					}
					else
					{
						if(pFidData->nFidBlock != nBlockOrder)
							continue;
					}

					if(!m_bAutoRun && m_bSelectFire)
					{
						BOOL bSelectedFid = FALSE;
						for(int nSelectedBlock = 0; nSelectedBlock < MAX_FID_BLOCK; nSelectedBlock++)
						{
#ifdef __JEUNGPYEONG_DNP_BGA__
							if(gDProject.m_nSelectedFiducial[nSelectedBlock] == pFidData->nFidBlock || pFidData->nFidBlock == 0) // 증평에선 처음 피듀셜은 선택가공과는 상관없이 무조건 찾게 함.
#else
							if(gDProject.m_nSelectedFiducial[nSelectedBlock] == pFidData->nFidBlock)
#endif
							{
									bSelectedFid = TRUE; break;
							}
						}
						if(!bSelectedFid)
							continue;
					}


					if(nFindCount == 0)
						pFidFirstData = pFidData; // 3 번째 이상 데이터 변환을 위하여
					if(nFindCount == 0 && pFidData->npTransPosition.x == 0 && pFidData->npTransPosition.y == 0 &&
						pFidData->npTransPosition2.x == 0 && pFidData->npTransPosition2.y == 0 ) // 첫장의 1번째 피듀셜 2nd PCB의 무의미한 회전을 방지하려고
					{
						if(gDProject.m_nSeparation != USE_2ND)
						{
							pFidData->npTransPosition2.x = gTempINI.m_sTempTime.n2ndFidFirstPosX;
							pFidData->npTransPosition2.y = gTempINI.m_sTempTime.n2ndFidFirstPosY;
						}
					}
					if(nFindCount == 1 && pFidData->npTransPosition.x == 0 && pFidData->npTransPosition.y == 0 &&
						pFidData->npTransPosition2.x == 0 && pFidData->npTransPosition2.y == 0 ) // 첫장의 2번째 피듀셜의 무의미한 회전을 방지하려고
					{
						if(gDProject.m_nSeparation != USE_2ND)
						{
							pFidData->npTransPosition.x = gTempINI.m_sTempTime.n1stFidSecondPosX + pFidFirstData->npTransPosition.x;
							pFidData->npTransPosition.y = gTempINI.m_sTempTime.n1stFidSecondPosY + pFidFirstData->npTransPosition.y;

							pFidData->npTransPosition2.x = gTempINI.m_sTempTime.n2ndFidSecondPosX + pFidFirstData->npTransPosition.x;
							pFidData->npTransPosition2.y = gTempINI.m_sTempTime.n2ndFidSecondPosY + pFidFirstData->npTransPosition.y;
						}
						else
						{
							pFidData->npTransPosition2.x = (gTempINI.m_sTempTime.n2ndFidSecondPosX - gTempINI.m_sTempTime.n2ndFidFirstPosX) + pFidFirstData->npTransPosition2.x;
							pFidData->npTransPosition2.y = (gTempINI.m_sTempTime.n2ndFidSecondPosY - gTempINI.m_sTempTime.n2ndFidFirstPosY) + pFidFirstData->npTransPosition2.y;
						}
					}
					if(nFindCount > 1 && pFidData->nFidType & FID_PRIMARY)
					{
						myTrans.TransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dx, dy);
						pFidData->npTransPosition.x = (int)(dx - pFidData->npPosition.x); pFidData->npTransPosition.y = (int)(dy - pFidData->npPosition.y);
						myTrans2.TransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dx, dy);
						pFidData->npTransPosition2.x = (int)(dx - pFidData->npPosition.x); pFidData->npTransPosition2.y = (int)(dy - pFidData->npPosition.y);
					}
					else if((pFidData->nFidType & FID_SECONDARY)  && !(pFidData->nFidType & FID_DRILL))
					{
						myTrans3.TransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dx, dy);
						pFidData->npTransPosition.x = (int)(dx - pFidData->npPosition.x); pFidData->npTransPosition.y = (int)(dy - pFidData->npPosition.y);
						myTrans4.TransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dx, dy);
						pFidData->npTransPosition2.x = (int)(dx - pFidData->npPosition.x); pFidData->npTransPosition2.y = (int)(dy - pFidData->npPosition.y);
					}

					if((pFidData->nFidType & FID_SECONDARY) && !(pFidData->nFidType & FID_DRILL)) // coase fid
						bCoaseFid = TRUE;

//					if(nFindMethod != FIND_ALL_FID && pFidData->bSelected) // 해당 data 가 있는 fiducial만 찾음 :: 131104 by lee 사용안하는 것으로 판단됨
//						continue;

					BOOL bFoundOK;
					if((pFidData->nFidType & FID_SECONDARY) && !(pFidData->nFidType & FID_DRILL))
						bFoundOK = FindOneVerifyFiducial(pFidData, FALSE, pPanel1st, pPanel2nd, i, pFidData->nFidBlock);
					else
					{// 20130404 bhlee
						if(!FindSameFidPosIndexAndApply(pFidData, nAddProperty, nDelProperty, -1, pPanel1st, pPanel2nd))
						{
							m_nFidIndexForFidShowAll = GetFidRectPosIndex(nFidCenterX[pFidData->nFidBlock], nFidCenterY[pFidData->nFidBlock], pFidData);
							m_nFidBlockForFidShowAll = pFidData->nFidBlock;
							bFoundOK = FindOneFiducial(pFidData, i, pFidData->nFidBlock, pPanel1st, pPanel2nd);
						}
						else
							bFoundOK = TRUE;

						m_nFidIndexForFidShowAll = -1;
						m_nFidBlockForFidShowAll = 0;
					}

					if(gProcessINI.m_sProcessSystem.bFailFidCountinue)
					{
	/*					if(!pFidData->bAcquire[0] && !pFidData->bAcquire[1])
						{
							if(gDProject.m_nSeparation == USE_DUAL)
								m_nNGBoxCondition = 3;
							else if(gDProject.m_nSeparation == USE_1ST)
								m_nNGBoxCondition = 1;
							else if(gDProject.m_nSeparation == USE_2ND)
								m_nNGBoxCondition = 2;
							return FALSE;
						}
	*/
						b1stContinue = pFidData->bAcquire[0];
						b2ndContinue = pFidData->bAcquire[1];

						if(!CheckChangePanelInfo(b1stContinue, b2ndContinue, nFidBlock, FALSE))
							return FALSE;
					}
					else
					{
						if(!bFoundOK)
						{
							if(nFindCount == 0 && (nFidBlock == -1 || nFidBlock == 0)) //첫번째 fiducial이 실패시 manual find 
							{
	//						if(ManualFidFind(0, 0, DEFAULT_FID_INDEX, TRUE))
	//						{
	//							if(IDYES == ErrMessage(_T("피듀셜 위치 설정을 이 프로젝트 파일에 저장 하시겠습니까?"), MB_YESNO))
	//							{
	//								this->SendMessage(UM_SAVE_PROJECT, NULL, NULL);
	//							}
	//						}
	//						else
								{
									m_nErrMsgID = STDGNALM709; // fid find fail
									gDProject.ResetFireStatus();
									return FALSE;
								}
							}
							m_nErrMsgID = STDGNALM709;
							return FALSE;
						}
					}
					if(nFindCount < 2)
					{
						myTrans.SetReferencePoint(pFidData->npPosition.x, pFidData->npPosition.y, nFindCount);
						myTrans.SetTransformedPoint(pFidData->npPosition.x + pFidData->npTransPosition.x, 
							pFidData->npPosition.y + pFidData->npTransPosition.y, nFindCount);
						myTrans2.SetReferencePoint(pFidData->npPosition.x, pFidData->npPosition.y, nFindCount);
						myTrans2.SetTransformedPoint(pFidData->npPosition.x + pFidData->npTransPosition2.x, 
							pFidData->npPosition.y + pFidData->npTransPosition2.y, nFindCount);
					}
					if(nFindCount == 1)
					{
						myTrans.Transform(); myTrans2.Transform();
						CalFidPosWithFirst2Point(&myTrans, &myTrans2);
					}

					if(nFindCount < nCntPrimary && nCntSecondary > 0)
					{
						myTrans3.SetReferencePoint(pFidData->npPosition.x, pFidData->npPosition.y, i);
						myTrans3.SetTransformedPoint(pFidData->npPosition.x + pFidData->npTransPosition.x, 
							pFidData->npPosition.y + pFidData->npTransPosition.y, i);
						myTrans4.SetReferencePoint(pFidData->npPosition.x, pFidData->npPosition.y, i);
						myTrans4.SetTransformedPoint(pFidData->npPosition.x + pFidData->npTransPosition2.x, 
							pFidData->npPosition.y + pFidData->npTransPosition2.y, i);
					}
					if( nFindCount == nCntPrimary - 1 && nCntSecondary > 0)
					{
						myTrans3.Transform();
						myTrans4.Transform();
					}
					nFindCount++;
				}
			}

		}
	}
	else
	{
		gDProject.ResetFidOffset();
		gDProject.m_Glyphs.ResetFidAcquireRet(DEFAULT_FID_INDEX, TRUE);
		nFindCount = 1;
	}

	strFidOffset.Format(_T("End"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));

	int nDualMode = gDProject.m_nSeparation;
	if(gDProject.m_nSeparation == USE_DUAL && m_bOdd)
		nDualMode = USE_1ST;

	BOOL bMasterOK = TRUE, bSlaveOK= TRUE;
	if(nFindCount)
	{
		BOOL bReChange = FALSE;
		if(!OnlyTransform(nFidKind, nFindMethod, bCoaseFid, nFidBlock, nDualMode, bMasterOK, bSlaveOK))
		{
			b1stContinue = bMasterOK;
			b2ndContinue = bSlaveOK;

			if(!bMasterOK && !bSlaveOK)
				return FALSE;

			if(gProcessINI.m_sProcessSystem.bFailFidCountinue)
			{
				b1stContinue = bMasterOK;
				b2ndContinue = bSlaveOK;

				if(!CheckChangePanelInfo(b1stContinue, b2ndContinue,nFidBlock, TRUE))
					return FALSE;

				if(nDualMode == USE_DUAL )
				{
					if(b1stContinue && !b2ndContinue)
						nDualMode = USE_1ST;
					else if(!b1stContinue && b2ndContinue)
						nDualMode = USE_2ND;
				}
			}
		}

		bMasterOK = TRUE, bSlaveOK= TRUE;
		if(!CheckFoundFidValid(nFidKind, nFindMethod, nFidBlock, bReChange, bMasterOK, bSlaveOK, pPanel1st, pPanel2nd))
		{
			if(m_nCurrentLotCount == 0)
			{
				m_dAvgScaleX = m_dAvgScaleY = 100;
			}
			if(!m_bRetryFidFind) // // 20130404 bhlee
			{
				m_bRetryFidFind = TRUE;
				if(bMasterOK == FALSE && bSlaveOK == FALSE)
					m_nErrMsgID = STDGNALM749;
				else if(bMasterOK == FALSE && bSlaveOK == TRUE)
					m_nErrMsgID = STDGNALM1084;
				else if(bMasterOK == TRUE && bSlaveOK == FALSE)
					m_nErrMsgID = STDGNALM1085;
				return FALSE;
			}
			else // 두번째 찾아서 실패한 경우 가공할지 아닐지를 판단
			{
				if(gProcessINI.m_sProcessSystem.bFailFidCountinue) // 한쪽 가공 시작 모드면
				{
					b1stContinue = bMasterOK;
					b2ndContinue = bSlaveOK;

					if(!CheckChangePanelInfo(b1stContinue, b2ndContinue,nFidBlock, TRUE))
						return FALSE;

					if(nDualMode == USE_DUAL )
					{
						if(b1stContinue && !b2ndContinue)
							nDualMode = USE_1ST;
						else if(!b1stContinue && b2ndContinue)
							nDualMode = USE_2ND;
					}

				}
				else
				{
					if(m_dLengthStrech[0][0] > m_dLengthStrechLimit || m_dLengthStrech[0][1] > m_dLengthStrechLimit ||
						m_dLengthStrech[1][0] > m_dLengthStrechLimit || m_dLengthStrech[1][1] > m_dLengthStrechLimit) // limit over
					{
						if(m_dLengthStrech[0][0] < gProcessINI.m_sProcessFidFind.dPCBLenTolOperatorRunLimit * 1000 &&
							m_dLengthStrech[0][1] < gProcessINI.m_sProcessFidFind.dPCBLenTolOperatorRunLimit * 1000 &&
							m_dLengthStrech[1][0] < gProcessINI.m_sProcessFidFind.dPCBLenTolOperatorRunLimit * 1000 &&
							m_dLengthStrech[1][1] < gProcessINI.m_sProcessFidFind.dPCBLenTolOperatorRunLimit * 1000) // 사용자가 임의로 시작할 수 있는 limit 이 있다
						{
							// 경광
							gDeviceFactory.GetMotor()->SetAlarmTolLed(TRUE);
							// message
							CString strString, strTemp;
							if(m_dLengthStrech[0][0] > m_dLengthStrechLimit)
								strString.Format(_T("1st Panel : Tol X is over : %.0f > Limit %.0f\r\n"), m_dLengthStrech[0][0], m_dLengthStrechLimit);
							if(m_dLengthStrech[0][1] > m_dLengthStrechLimit)
							{
								strTemp.Format(_T("1st Panel : Tol Y is over : %.0f > Limit %.0f\r\n"), m_dLengthStrech[0][1], m_dLengthStrechLimit);
								strString += strTemp;
							}
							if(m_dLengthStrech[1][0] > m_dLengthStrechLimit)
							{
								strTemp.Format(_T("2nd Panel : Tol X is over : %.0f > Limit %.0f\r\n"), m_dLengthStrech[1][0], m_dLengthStrechLimit);
								strString += strTemp;
							}
							if(m_dLengthStrech[1][1] > m_dLengthStrechLimit)
							{
								strTemp.Format(_T("2nd Panel : Tol Y is over : %.0f > Limit %.0f\r\n"), m_dLengthStrech[1][1], m_dLengthStrechLimit);
								strString += strTemp;
							}
							strString += _T("\r\n찾은 피듀셜들이 이상이 없어 가공을 진행 하시겠습니까?");

							if(!gProcessINI.m_sProcessFidFind.bOperatorCanRunForScaleOver)
							{
								m_bPCBReject = TRUE;
								if(bMasterOK == FALSE && bSlaveOK == FALSE)
									m_nErrMsgID = STDGNALM787;
								else if(bMasterOK == FALSE && bSlaveOK == TRUE)
									m_nErrMsgID = STDGNALM1084;
								else if(bMasterOK == TRUE && bSlaveOK == FALSE)
									m_nErrMsgID = STDGNALM1085;
								gDeviceFactory.GetMotor()->SetAlarmTolLed(FALSE);
								return FALSE;
							}
							if(IDNO == ErrMessage(strString, MB_YESNO)) // 정지해야 함
							{
								m_bPCBReject = TRUE;
								// 경광 end
								gDeviceFactory.GetMotor()->SetAlarmTolLed(FALSE);
								if(bMasterOK == FALSE && bSlaveOK == FALSE)
									m_nErrMsgID = STDGNALM787;
								else if(bMasterOK == FALSE && bSlaveOK == TRUE)
									m_nErrMsgID = STDGNALM1084;
								else if(bMasterOK == TRUE && bSlaveOK == FALSE)
									m_nErrMsgID = STDGNALM1085;
								return FALSE;
							}
							else // 가공 진행하기
							{
								strSequenceLog.Format(_T("User run Forcely"));
								::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
							}
							gDeviceFactory.GetMotor()->SetAlarmTolLed(FALSE);
							// 경광 end
						}
						else
						{
							m_bPCBReject = TRUE;
							if(bMasterOK == FALSE && bSlaveOK == FALSE)
								m_nErrMsgID = STDGNALM787;
							else if(bMasterOK == FALSE && bSlaveOK == TRUE)
								m_nErrMsgID = STDGNALM1084;
							else if(bMasterOK == TRUE && bSlaveOK == FALSE)
								m_nErrMsgID = STDGNALM1085;
							return FALSE;
						}
					}
					else
					{
						m_bPCBReject = TRUE;
						if(bMasterOK == FALSE && bSlaveOK == FALSE)
							m_nErrMsgID = STDGNALM787;
						else if(bMasterOK == FALSE && bSlaveOK == TRUE)
							m_nErrMsgID = STDGNALM1084;
						else if(bMasterOK == TRUE && bSlaveOK == FALSE)
							m_nErrMsgID = STDGNALM1085;
						return FALSE;
					}
				}
			}
		}

		if(bReChange)
			m_bCanCheckTransValid = FALSE; // 20130312 : 변형되어서 원본 테이블 좌표로 비교 불가

		bMasterOK = TRUE, bSlaveOK= TRUE;
		if(gProcessINI.m_sProcessFidFind.bUseProportionCompensation)
		{
			if(!ApplyFidDataToShot(nFidKind, nFindMethod, bCoaseFid, nFidBlock, nDualMode, bMasterOK, bSlaveOK, TRUE)) // gSystemINI.m_sSystemDevice.nFiducialFindType))
			{
				if(!CheckFoundFidValid(nFidKind, nFindMethod, nFidBlock, bReChange, bMasterOK, bSlaveOK, pPanel1st, pPanel2nd))
				{
					if(bMasterOK == FALSE && bSlaveOK == FALSE)
						m_nErrMsgID = STDGNALM749;
					else if(bMasterOK == FALSE && bSlaveOK == TRUE)
						m_nErrMsgID = STDGNALM1084;
					else if(bMasterOK == TRUE && bSlaveOK == FALSE)
						m_nErrMsgID = STDGNALM1085;
					return FALSE;
				}
				return FALSE;
			}
		}
		else
		{
			if(!ApplyFidDataToShot(nFidKind, nFindMethod, bCoaseFid, nFidBlock, nDualMode, bMasterOK, bSlaveOK, FALSE)) // gSystemINI.m_sSystemDevice.nFiducialFindType))
			{
				if(!CheckFoundFidValid(nFidKind, nFindMethod, nFidBlock, bReChange, bMasterOK, bSlaveOK, pPanel1st, pPanel2nd))
				{
					if(bMasterOK == FALSE && bSlaveOK == FALSE)
						m_nErrMsgID = STDGNALM749;
					else if(bMasterOK == FALSE && bSlaveOK == TRUE)
						m_nErrMsgID = STDGNALM1084;
					else if(bMasterOK == TRUE && bSlaveOK == FALSE)
						m_nErrMsgID = STDGNALM1085;
					return FALSE;
				}
				return FALSE;
			}
		}

		if(gDProject.m_bFidInfoChangeForScale)
			m_bCanCheckTransValid = FALSE; // 20130312 : 변형되어서 원본 테이블 좌표로 비교 불가

		if(nFindCount != 1 && (m_nCurrentLotCount == 5 || m_nCurrentLotCount == 6)) // 0값이 아닌경우 5,6 오토카운트(양산중) 결과로 offset을 갱신한다)
		{
			ChangeDiffFidStartPos();
		}
	}
	gDProject.m_nDataLoadStep = FIELD_DIVIED + APPLY_FID;
	return TRUE;
}
BOOL CPaneAutoRun::CheckChangePanelInfo(BOOL b1st, BOOL b2nd, int nFidBlock, BOOL bApply)
{
	CString strSequenceLog, strEvent;

	if(b1st && b2nd)
		return TRUE;
	else if(!b1st && !b2nd)
		return FALSE;

	if(!bApply)
		strEvent.Format(_T("Change Panel Use Info : Fail to Find Fiducial"));
	else
		strEvent.Format(_T("Change Panel Use Info :  Fail to Apply Fid Result"));

	if(!m_bChangePanelInfo)
	{
		if(m_nBackupSeparation == USE_DUAL && !m_bOdd)
		{
			if(b1st && !b2nd)
			{
				m_bChangePanelInfo = TRUE;
				gDProject.m_nSeparation = USE_1ST;
				strSequenceLog.Format(_T("Master OK | Salve NG | Use Panel : Master"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strSequenceLog));
				m_nNGBoxCondition = 2;
			}
			else if(!b1st && b2nd)
			{
				m_bChangePanelInfo = TRUE;
				gDProject.m_nSeparation = USE_2ND;
				strSequenceLog.Format(_T("Master NG | Salve OK | Use Panel : Slave"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strSequenceLog));
				m_nNGBoxCondition = 1;
			}
			else if(!b1st && !b2nd)
			{
				if(!gProcessINI.m_sProcessSystem.bNoUseNGBox)
				{
					m_nNGBoxCondition = 3;
					return FALSE;
				}
				else
				{
					m_nErrMsgID = STDGNALM709;
					gDProject.ResetFireStatus();
					return FALSE;				
				}
			}
		}
		else if((m_nBackupSeparation == USE_1ST && !b1st) || (m_nBackupSeparation == USE_DUAL && m_bOdd && !b1st))
		{
			if(!gProcessINI.m_sProcessSystem.bNoUseNGBox)
			{ 
				m_nNGBoxCondition = 1;
				return FALSE;
			}
			else
			{
				m_nErrMsgID = STDGNALM709;
				gDProject.ResetFireStatus();
				return FALSE;
			}
		}
		else if(m_nBackupSeparation == USE_2ND && !b2nd)
		{
			if(!gProcessINI.m_sProcessSystem.bNoUseNGBox)
			{
				m_nNGBoxCondition = 2;
				return FALSE;
			}
			else
			{
				m_nErrMsgID = STDGNALM709;
				gDProject.ResetFireStatus();
				return FALSE;
			}
		}
	}
	else
	{
		if(m_nBackupSeparation == USE_DUAL && gDProject.m_bMultiFidAscentOrder && nFidBlock != 0)
		{
			if(gDProject.m_nSeparation == USE_1ST && !b1st )
			{
				m_nErrMsgID = STDGNALM709; 
				gDProject.ResetFireStatus();
				return FALSE;
			}
			else if(gDProject.m_nSeparation == USE_2ND && !b2nd)
			{
				m_nErrMsgID = STDGNALM709; 
				gDProject.ResetFireStatus();
				return FALSE;		
			}
		}
	}
	return TRUE;
}
int	CPaneAutoRun::GetFidRectPosIndex(int nCenterX, int nCenterY, LPFIDDATA pFidData)// 20130404 bhlee
{
	//    0           1
	//
	//
	//    2           3
	if(pFidData->npPosition.x < nCenterX && pFidData->npPosition.y > nCenterY)
		return 0;
	else if(pFidData->npPosition.x >= nCenterX && pFidData->npPosition.y > nCenterY)
		return 1;
	else if(pFidData->npPosition.x < nCenterX && pFidData->npPosition.y <= nCenterY)
		return 2;
	else
		return 3;
}

BOOL CPaneAutoRun::CheckSelectedFiducial(int* nFidBlockArray)
{
	LPFIRELINE pLine;
	LPFIREHOLE pHole;
	AreaList AreaTempList;
	POSITION posArea;
	POSITION pos;
	int nCnt = 0;
	BOOL bFindBlock = FALSE;
	BOOL bDuplicate = FALSE;
	DAreaInfo *pAreaInfo;
	for(int i = 0; i < MAX_TOOL_NO; i++)
	{
		posArea = gDProject.m_Areas[i].GetHeadPosition();
		while (posArea) 
		{
			bFindBlock = FALSE;
			bDuplicate = FALSE;
			pAreaInfo = gDProject.m_Areas[i].GetNext(posArea);
			//Fiducial Block find - HOLE
			pos = pAreaInfo->m_FireHoles[i].GetHeadPosition();
			while(pos)
			{
				pHole = pAreaInfo->m_FireHoles[i].GetNext(pos);
				if(pHole->bSelect == TRUE)
				{
					for(int j = 0; j < MAX_FID_BLOCK; j++)
					{
						if(nFidBlockArray[j] == pHole->pOrigin->nFidBlock)
							bDuplicate = TRUE;
					}
					if(!bDuplicate)
					{
						bFindBlock = TRUE;
						nFidBlockArray[nCnt++] = pHole->pOrigin->nFidBlock;
						break;
					}
				}
				if(bFindBlock)
					break;
			}

			//Fiducial Block find - LINE
			pos = pAreaInfo->m_FireLines[i].GetHeadPosition();
			while(pos)
			{
				pLine = pAreaInfo->m_FireLines[i].GetNext(pos);
				if(pLine->bSelect == TRUE)
				{
					for(int j = 0; j < MAX_FID_BLOCK; j++)
					{
						if(nFidBlockArray[j] == pLine->pOrigin->nFidBlock)
							bDuplicate = TRUE;
					}
					if(!bDuplicate)
					{
						bFindBlock = TRUE;
						nFidBlockArray[nCnt++] = pLine->pOrigin->nFidBlock;
						break;
					}
				}
				if(bFindBlock)
					break;
			}
		}
	}

	return TRUE;
}

BOOL CPaneAutoRun::VerifyFiducialOrRecheckFidAfterFire(BOOL bAfterFire)
{
	CString strSequenceLog;
	if(bAfterFire)
		strSequenceLog.Format(_T("---Check Fiducial After Fire ---"));
	else
		strSequenceLog.Format(_T("---Find Verify Fiducial---"));
	CString strFile2, strLog;
	strFile2.Format(_T("CheckTrans"));

	double dTranFidX, dTranFidY;
	LPFIDDATA pFidData;

	if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, TRUE);
	if(!bAfterFire)
		gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dRotateHoleAcceptScore);

	if(!gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
	{
		if(!gSystemINI.m_sSystemDevice.nNoUseVision)
		{
			int nAddProperty = 0, nDelProperty = 0;
			if(bAfterFire) // 기판이 가공 중 움직였는지를 감지
			{
				nAddProperty = FID_FIND; nDelProperty = FID_VERIFY;
			}
			else // rotate Fid 기판의 역투입 방지 기능
			{
				nAddProperty = FID_VERIFY;
			}
			int nCnt = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, nAddProperty, nDelProperty, -1);

			if(nCnt)
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));

			for(int i = 0; i < nCnt; i++) // fid 개수만큼 찾기
			{
				pFidData = gDProject.m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, i, nAddProperty, nDelProperty, -1);
				if(!bAfterFire)
				{
					gDProject.GetTransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dTranFidX, dTranFidY, TRUE, pFidData->nFidBlock);
					pFidData->npTransPosition.x =(int)(dTranFidX - pFidData->npPosition.x); 
					pFidData->npTransPosition.y = (int)(dTranFidY - pFidData->npPosition.y);

					strLog.Format(_T("TransPosition : (%d, %d)"), pFidData->npTransPosition.x, pFidData->npTransPosition.y);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				
					gDProject.GetTransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dTranFidX, dTranFidY, FALSE, pFidData->nFidBlock);
					pFidData->npTransPosition2.x = (int)(dTranFidX - pFidData->npPosition.x); 
					pFidData->npTransPosition2.y = (int)(dTranFidY - pFidData->npPosition.y);

					strLog.Format(_T("TransPosition2 : (%d, %d)"), pFidData->npTransPosition2.x, pFidData->npTransPosition2.y);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				}
				if(!FindOneVerifyFiducial(pFidData, bAfterFire, NULL, NULL))
				{
					if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
						::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);
					if(!bAfterFire)
						gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
					strSequenceLog.Format(_T("---Verify or Check Fiducial Fail---"));
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
					return FALSE;
				}
				if(bAfterFire && i == 1) // 2개 검사했다면
					break;
				if(!bAfterFire && i == 0) // 1개 검사했다면
					break;
			}
		}
	}

	if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);
	if(!bAfterFire)
		gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
	strSequenceLog.Format(_T("---Verify or Check Fiducial End---"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
	return TRUE;
}
BOOL CPaneAutoRun::HoleFind()
{
	if(gDProject.m_nHoleFind == NO_FIND)
		return TRUE;

	if(gSystemINI.m_sSystemDevice.nNoUseVision)
		return TRUE;

	int nTool = -1;
	int nUseBeamPath = -1;
	POSITION pos;
	SUBTOOLDATA subData;

	BOOL bUseToolInfo[MAX_TOOL_NO];
	memset(bUseToolInfo, FALSE, sizeof(bUseToolInfo));
	for(int k = 0; k<MAX_TOOL_NO; k++)
	{
		if(gDProject.m_pToolCode[k]->m_bHoldFind)
		{
			bUseToolInfo[gDProject.m_ToolSumInfo[k].nRealToolNo] = TRUE;
		}
	}
	

	for(int i = 0; i<MAX_TOOL_NO ;i++)
	{
		if(bUseToolInfo[i])//if(gDProject.m_pToolCode[i]->m_bHoldFind)
		{
			nTool = i;
			pos = gDProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
			subData = gDProject.m_pToolCode[i]->m_SubToolData.GetNext(pos);	
			nUseBeamPath = subData.nMask;

			memset(m_nHoleAreaIndex, 0, sizeof(m_nHoleAreaIndex));
			memset(m_dpHoleTablePos, 0, sizeof(m_dpHoleTablePos));
			memset(m_cpHolePos, 0, sizeof(m_cpHolePos));
			memset(m_dpHoleOffset, 0 , sizeof(m_dpHoleOffset));
			memset(m_bHoleFindOK, 0 , sizeof(m_bHoleFindOK));

			if(!CheckStatus())
				return FALSE;

			int nNearAreaIndex[9];
			memset(nNearAreaIndex, -1, sizeof(nNearAreaIndex));

			FindNearAreaFiducial(nTool,nNearAreaIndex);
			
			if(!FindArea(nTool, nUseBeamPath, nNearAreaIndex))
			{
				SaveHoleFindResult(nUseBeamPath);
				return FALSE;
			}


			SaveHoleFindResult(nUseBeamPath);
		}
	}
	return TRUE;
	
}

BOOL CPaneAutoRun::CheckFoundFidValid(int nFidKind, int nFindMethod, int nFidBlock, BOOL& bReChange, BOOL& b1stOK, BOOL& b2ndOK, LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd)
{
	//  배열 저장 인덱스
	//	F3  2  F2
	//  3       1 
	//  F0  0  F1
	CalLength(TRUE, nFidKind, nFidBlock, pPanel1st, pPanel2nd);

	m_dLengthStrech[0][0] = m_dLengthStrech[0][1] = m_dLengthStrech[1][0] = m_dLengthStrech[1][1] = 0;// 20130404 bhlee
	m_dLengthStrechLimit = gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000;

	CString strFile, strLog;
	CTime cCurrent = CTime::GetCurrentTime();
	strFile.Format(_T("ResetFidResult%02d"), cCurrent.GetMonth());
	CString strMsg, strErr;
	m_dCurrentScaleX[0] = m_dCurrentScaleX[1] = 100; 
	m_dCurrentScaleY[0] = m_dCurrentScaleY[1] = 100;
	double dLenghStrech1 = 0, dLenghStrech2 = 0; 
	
	int nStartFidBlock, nEndFidBlock;
	nStartFidBlock = 0; nEndFidBlock = gDProject.m_nMaxFidBlock;// all find
	if(nFidBlock != -1) 
	{
		nStartFidBlock = nEndFidBlock = nFidBlock; 
	}

	if(gProcessINI.m_sProcessSystem.bNoUseFiducialFind || gSystemINI.m_sSystemDevice.nNoUseVision)
	{
		b1stOK = b2ndOK = TRUE;
		strMsg.Format(_T("Scale Skip Info"));
		strErr.Format(_T("No use finding fiducial option or no use camera option"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
		return TRUE;
	}

	for(int nBlockNo = nStartFidBlock; nBlockNo <= nEndFidBlock; nBlockNo++)
	{
		if(!m_bAutoRun && m_bSelectFire)
		{
			BOOL bSelectedFid = FALSE;
			for(int nSelectedBlock = 0; nSelectedBlock < MAX_FID_BLOCK; nSelectedBlock++)
			{
				if(gDProject.m_nSelectedFiducial[nSelectedBlock] == nBlockNo)
				{
					bSelectedFid = TRUE; break;
				}
			}
			if(!bSelectedFid)
				continue;
		}

		CDPoint dpMOffset1, dpMOffset2, dpSOffset1, dpSOffset2;
		CDPoint dp1, dp2;
		CDPoint dRefPos[2][4], dFindPos[2][4], dCenter[2][4];
		double dx, dy;
		double dLenRef, dLenOffset;
		double dScale[2][4] = {100,};
		double dDiagonal[2][2] = {100,100,100,100}; // 0 : 0 -> 2, 1 : 1 ->3
		CString	strScaleInfo[2][4] = {_T("OK"), };
		double dLengStrech[2][4] = {0,};
		BOOL bRet1 = TRUE, bRet2 = TRUE;
		BOOL bScaleOK[2] = {0,};
		int nUseFidCount;
		BOOL bUseScaleLimit;

		if(gDProject.m_nSeparation != USE_2ND)
		{
			nUseFidCount = gDProject.m_RefTrans[0][nBlockNo].GetNumPoint();
			bUseScaleLimit = gDProject.m_RefTrans[0][nBlockNo].m_bUseScaleLimit;
		}
		else
		{
			nUseFidCount = gDProject.m_RefTrans[1][nBlockNo].GetNumPoint();
			bUseScaleLimit = gDProject.m_RefTrans[1][nBlockNo].m_bUseScaleLimit;
		}
	  	if(!bUseScaleLimit)
		{
			strMsg.Format(_T("Scale Skip Info"));
			strErr.Format(_T("Block No : %d is disable to check scale limit"), nBlockNo);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
			continue;
		}

		if(nUseFidCount == 0)
			continue;
		//각변의 센터를 구하여 위아래좌우 판단 
		double dAvgX, dAvgY;
		double dSumX = 0, dSumY= 0;
		for(int i = 0; i< nUseFidCount; i++)
		{
			if(gDProject.m_nSeparation != USE_2ND)
				dp1	= gDProject.m_RefTrans[0][nBlockNo].GetRefsPoint(i);
			else
				dp1	= gDProject.m_RefTrans[1][nBlockNo].GetRefsPoint(i);

			dSumX += dp1.x;
			dSumY += dp1.y;
			dCenter[0][i].x = dp1.x;
			dCenter[0][i].y = dp1.y;
		}
		dAvgX = dSumX/nUseFidCount;
		dAvgY = dSumY/nUseFidCount;

		int nLB = -1, nRB = -1, nLT = -1, nRT = -1;
		int n1stCntX = 0, n1stCntY = 0;
		double dAvgScaleX[2]; //master&slave
		double dAvgScaleY[2];

		bScaleOK[0] = bScaleOK[1] = TRUE;
		b1stOK = b2ndOK = TRUE;

		if( b1stOK && (gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST))
		{
			if(nUseFidCount == 2)
			{
				if(fabs(dCenter[0][0].x - dCenter[0][1].x) > fabs(dCenter[0][0].y - dCenter[0][1].y))
				{
					if(dCenter[0][0].x > dCenter[0][1].x)
					{
						nLB = 1; nRB = 0;
					}
					else
					{
						nLB = 0; nRB = 1;
					}
				}
				else
				{
					if(dCenter[0][0].y < dCenter[0][1].y)
					{
						nRT = 1; nRB = 0;
					}
					else
					{
						nRT = 0; nRB = 1;
					}
				}
			}
			else if(nUseFidCount == 3 || nUseFidCount == 4)
			{
				for(int l = 0; l<nUseFidCount; l++)
				{
					dp1		= gDProject.m_RefTrans[0][nBlockNo].GetRefsPoint(l);
					if(dp1.x < dAvgX && dp1.y < dAvgY)
						nLB = l;
					else if(dp1.x >= dAvgX && dp1.y < dAvgY)
						nRB = l;
					else if(dp1.x < dAvgX && dp1.y >= dAvgY)
						nLT = l;
					else if(dp1.x >= dAvgX && dp1.y >= dAvgY)
						nRT = l;
				}
			}
			else
			{
				b1stOK = b2ndOK = FALSE;
				return FALSE;
			}

			//get each scale 
			dRefPos[0][0].x = dRefPos[0][1].x = dRefPos[0][2].x = dRefPos[0][3].x = DBL_MAX;
			if(nLB != -1)
			{
				dRefPos[0][0] = gDProject.m_RefTrans[0][nBlockNo].GetRefsPoint(nLB);
				dFindPos[0][0] = gDProject.m_RefTrans[0][nBlockNo].GetTransPoint(nLB);
			}
			if(nRB != -1)
			{
				dRefPos[0][1] = gDProject.m_RefTrans[0][nBlockNo].GetRefsPoint(nRB);
				dFindPos[0][1] = gDProject.m_RefTrans[0][nBlockNo].GetTransPoint(nRB);
			}
			if(nRT != -1)
			{
				dRefPos[0][2] = gDProject.m_RefTrans[0][nBlockNo].GetRefsPoint(nRT);
				dFindPos[0][2] = gDProject.m_RefTrans[0][nBlockNo].GetTransPoint(nRT);
			}
			if(nLT != -1)
			{
				dRefPos[0][3] = gDProject.m_RefTrans[0][nBlockNo].GetRefsPoint(nLT);
				dFindPos[0][3] = gDProject.m_RefTrans[0][nBlockNo].GetTransPoint(nLT);
			}

			dScale[0][0] = dScale[0][1] = dScale[0][2] = dScale[0][3] = 100;


			dAvgScaleX[0] = dAvgScaleY[0] = dAvgScaleX[1] = dAvgScaleY[1] = 0;
			if(nLB != -1 && nRB != -1)
			{
				dx = dRefPos[0][0].x - dRefPos[0][1].x;		dy = dRefPos[0][0].y - dRefPos[0][1].y;
				dLenRef = sqrt(dx*dx + dy*dy);
				dx = dFindPos[0][0].x - dFindPos[0][1].x;	dy = dFindPos[0][0].y - dFindPos[0][1].y;
				dLenOffset = sqrt(dx*dx + dy*dy);
				dScale[0][0] = dLenOffset * 100 / dLenRef;
				dAvgScaleX[0] += dScale[0][0];
				m_dCurrentScaleX[0] = dScale[0][0];
				dLengStrech[0][0] = dLenOffset - dLenRef;
				n1stCntX++;

			}

			if(nRT != -1 && nRB != -1)
			{
				dx = dRefPos[0][2].x - dRefPos[0][1].x;		dy = dRefPos[0][2].y - dRefPos[0][1].y;
				dLenRef = sqrt(dx*dx + dy*dy);
				dx = dFindPos[0][2].x - dFindPos[0][1].x;	dy = dFindPos[0][2].y - dFindPos[0][1].y;
				dLenOffset = sqrt(dx*dx + dy*dy);
				dScale[0][1] = dLenOffset * 100 / dLenRef;
				dAvgScaleY[0] += dScale[0][1];
				m_dCurrentScaleY[0] = dScale[0][1];
				dLengStrech[0][1] = dLenOffset - dLenRef;
				n1stCntY++;
			}

			if(nRT != -1 && nLT != -1)
			{
				dx = dRefPos[0][2].x - dRefPos[0][3].x;		dy = dRefPos[0][2].y - dRefPos[0][3].y;
				dLenRef = sqrt(dx*dx + dy*dy);
				dx = dFindPos[0][2].x - dFindPos[0][3].x;	dy = dFindPos[0][2].y - dFindPos[0][3].y;
				dLenOffset = sqrt(dx*dx + dy*dy);
				dScale[0][2] = dLenOffset * 100 / dLenRef;
				dAvgScaleX[0] += dScale[0][2];
				m_dCurrentScaleX[0] = dScale[0][2];
				dLengStrech[0][2] = dLenOffset - dLenRef;
				n1stCntX++;
			}

			if(nLB != -1 && nLT != -1)
			{
				dx = dRefPos[0][0].x - dRefPos[0][3].x;		dy = dRefPos[0][0].y - dRefPos[0][3].y;
				dLenRef = sqrt(dx*dx + dy*dy);
				dx = dFindPos[0][0].x - dFindPos[0][3].x;	dy = dFindPos[0][0].y - dFindPos[0][3].y;
				dLenOffset = sqrt(dx*dx + dy*dy);
				dScale[0][3] = dLenOffset * 100 / dLenRef;
				dAvgScaleY[0] += dScale[0][3];
				m_dCurrentScaleY[0] = dScale[0][3];
				dLengStrech[0][3] = dLenOffset - dLenRef;
				n1stCntY++;
			}

			if(nLB != -1 && nRT != -1)
			{
				dx = dRefPos[0][0].x - dRefPos[0][2].x;		dy = dRefPos[0][0].y - dRefPos[0][2].y;
				dLenRef = sqrt(dx*dx + dy*dy);
				dx = dFindPos[0][0].x - dFindPos[0][2].x;	dy = dFindPos[0][0].y - dFindPos[0][2].y;
				dLenOffset = sqrt(dx*dx + dy*dy);
				dDiagonal[0][0] = dLenOffset * 100 / dLenRef;
			}
			if(nRB != -1 && nLT != -1)
			{
				dx = dRefPos[0][1].x - dRefPos[0][3].x;		dy = dRefPos[0][1].y - dRefPos[0][3].y;
				dLenRef = sqrt(dx*dx + dy*dy);
				dx = dFindPos[0][1].x - dFindPos[0][3].x;	dy = dFindPos[0][1].y - dFindPos[0][3].y;
				dLenOffset = sqrt(dx*dx + dy*dy);
				dDiagonal[0][1] = dLenOffset * 100 / dLenRef;
			}

			bScaleOK[0] = bScaleOK[1] = TRUE;

			if(m_nCurrentLotCount == 0)
			{
				CalculateAvgScale();
				CheckAbsoluteScale( bScaleOK[0]);
			}

			if(n1stCntX)
			{
				dAvgScaleX[0] /= n1stCntX;
			}
			else
			{
				dAvgScaleX[0] = 100;
			}
			if(n1stCntY)
			{
				dAvgScaleY[0] /= n1stCntY;
			}
			else
			{
				dAvgScaleY[0] = 100;
			}

			m_dCurrentScaleX[0] = dAvgScaleX[0];
			m_dCurrentScaleY[0] = dAvgScaleY[0];


			if(gDProject.m_nScaleMode == 0)
			{
				for(int nScaleCheck = 0; nScaleCheck < 4; nScaleCheck++)
				{
					if(nScaleCheck == 0 || nScaleCheck == 2)
					{
						if(dScale[0][nScaleCheck] < gDProject.m_dScaleLimitX2Minus ||dScale[0][nScaleCheck] > gDProject.m_dScaleLimitX2Pluse)
						{
							strScaleInfo[0][nScaleCheck] = _T("NG");
						}
						else
							strScaleInfo[0][nScaleCheck] = _T("OK");
					}
					else if(nScaleCheck == 1 || nScaleCheck == 3)
					{
						if(dScale[0][nScaleCheck] < gDProject.m_dScaleLimitY2Minus ||dScale[0][nScaleCheck] > gDProject.m_dScaleLimitY2Pluse)
						{
							strScaleInfo[0][nScaleCheck] = _T("NG");
						}
						else
							strScaleInfo[0][nScaleCheck] = _T("OK");
					}
				}
				
				if(dScale[0][0] < gDProject.m_dScaleLimitX2Minus || dScale[0][1] < gDProject.m_dScaleLimitY2Minus ||
					dScale[0][0] > gDProject.m_dScaleLimitX2Pluse || dScale[0][1] > gDProject.m_dScaleLimitY2Pluse ||
					dScale[0][2] < gDProject.m_dScaleLimitX2Minus || dScale[0][3] < gDProject.m_dScaleLimitY2Minus ||
					dScale[0][2] > gDProject.m_dScaleLimitX2Pluse || dScale[0][3] > gDProject.m_dScaleLimitY2Pluse)
				{
					strMsg.Format(_T("1st Scale Fail Info"));
					strErr.Format(_T("1st | Avg X Scale : %.3f | Avg Y Scale : %.3f | X Limit : %.3f ~ %.3f | Y Limit : %.3f ~ %.3f |  0 - 1 Scale(X) : %.3f(%s) | 1 - 2 Scale(Y) : %.3f(%s) | 2 - 3 Scale(X) : %.3f(%s) | 3 - 0 Scale(Y) : %.3f(%s) | Fiducial Block : %d"),
						m_dAvgScaleX, m_dAvgScaleY, 
						gDProject.m_dScaleLimitX2Minus, gDProject.m_dScaleLimitX2Pluse, 
						gDProject.m_dScaleLimitY2Minus, gDProject.m_dScaleLimitY2Pluse,
						dScale[0][0], strScaleInfo[0][0], dScale[0][1], strScaleInfo[0][1], dScale[0][2], strScaleInfo[0][2], dScale[0][3], strScaleInfo[0][3], nBlockNo);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
					bScaleOK[0] = FALSE;
					if(pPanel1st != NULL)
						pPanel1st->nNGType = FID_NG_SCALE; 
				}
				else
				{
					strMsg.Format(_T("1st Scale Success Info"));
					strErr.Format(_T("1st | Avg X Scale : %.3f | Avg Y Scale : %.3f | X Limit : %.3f ~ %.3f | Y Limit : %.3f ~ %.3f |  0 - 1 Scale(X) : %.3f(%s) | 1 - 2 Scale(Y) : %.3f(%s) | 2 - 3 Scale(X) : %.3f(%s) | 3 - 0 Scale(Y) : %.3f(%s) | Fiducial Block : %d"),
						m_dAvgScaleX, m_dAvgScaleY, 
						gDProject.m_dScaleLimitX2Minus, gDProject.m_dScaleLimitX2Pluse, 
						gDProject.m_dScaleLimitY2Minus, gDProject.m_dScaleLimitY2Pluse, 
						dScale[0][0], strScaleInfo[0][0], dScale[0][1], strScaleInfo[0][1], dScale[0][2], strScaleInfo[0][2], dScale[0][3], strScaleInfo[0][3], nBlockNo);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
				}

				int nFidIndex[4];
				nFidIndex[0] = nLB; nFidIndex[1] = nRB; nFidIndex[2] = nRT; nFidIndex[3] = nLT;
				SaveFidCompensation(TRUE, nBlockNo, dAvgScaleX[0], dAvgScaleY[0],dScale[0], nFidIndex, dRefPos[0], dFindPos[0], 0);

				if(n1stCntX > 1 && n1stCntY > 1) // 거리벌 상대적 위치 편차로 양불 판정이 가능한 경우
				{
#ifndef __FID_X_Y__
					dLenghStrech1 = sqrt((dLengStrech[0][0] - dLengStrech[0][2]) * (dLengStrech[0][0] - dLengStrech[0][2]) + 
						(dLengStrech[0][1] - dLengStrech[0][3]) * (dLengStrech[0][1] - dLengStrech[0][3]));

					m_dLengthStrech[0][0] = dLenghStrech1; // // 20130404 bhlee m_dLengthStrech[0][1]

					if(gProcessINI.m_sProcessFidFind.bUseProportionCompensation)
					{
						m_dLengthStrechLimit = gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000;
						if( dLenghStrech1 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000  && 
							dLenghStrech1 <= gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000 )// um
						{
							SetProportaionCompensation(TRUE, nBlockNo, dAvgScaleX[0], dAvgScaleY[0], dScale[0], nFidIndex, FALSE);
							bReChange = TRUE;
						}
						else if(dLenghStrech1 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000)
						{
							bScaleOK[0] = FALSE;
							if(pPanel1st != NULL)
								pPanel1st->nNGType =  FID_NG_LENGH2; 
							strMsg.Format(_T("1st Length Tol. Fail Info"));
							strErr.Format(_T("Tolerance Limit : %.3f | Calculated Tolerance : %.3f | Fiducial Block : %d"), gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000, dLenghStrech1, nBlockNo );
							::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
						}
					}
					else
					{
						if( dLenghStrech1 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000 )// um
						{
							SetProportaionCompensation(TRUE, nBlockNo, dAvgScaleX[0], dAvgScaleY[0], dScale[0], nFidIndex, TRUE); //only log
							bScaleOK[0] = FALSE;
							if(pPanel1st != NULL)
								pPanel1st->nNGType =  FID_NG_LENGH; 
							strMsg.Format(_T("1st Length Tol. Fail Info"));
							strErr.Format(_T("Tolerance Limit : %.3f | Calculated Tolerance : %.3f | Fiducial Block : %d"), gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000, dLenghStrech1, nBlockNo );
							::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
						}
						else
						{
							strMsg.Format(_T("1st Length Tol. Success Info"));
							strErr.Format(_T("Tolerance Limit : %.3f | Calculated Tolerance : %.3f | Fiducial Block : %d"), gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000, dLenghStrech1, nBlockNo );
							::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
						}
					}

#else 
					dLenghStrech1 = fabs(dLengStrech[0][0] - dLengStrech[0][2]); 
					dLenghStrech2 = fabs(dLengStrech[0][1] - dLengStrech[0][3]);
					m_dLengthStrech[0][0] = dLenghStrech1; // // 20130404 bhlee 
					m_dLengthStrech[0][1] = dLenghStrech2;

					if(gProcessINI.m_sProcessFidFind.bUseProportionCompensation)
					{
						m_dLengthStrechLimit = gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000;
						if( dLenghStrech1 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000 ||
							dLenghStrech2 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000)// um
						{
							bScaleOK[0] = FALSE;
							if(pPanel1st != NULL)
								pPanel1st->nNGType =  FID_NG_LENGH2; 
							strMsg.Format(_T("1st Length Tol. Fail Info"));
							strErr.Format(_T("Tolerance Limit : %.3f | Calculated Tolerance X: %.3f | Calculated Tolerance Y: %.3f | Fiducial Block : %d"), 
								gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000, dLenghStrech1, dLenghStrech2, nBlockNo );
							::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
						}
						else if(( dLenghStrech1 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000 &&
							dLenghStrech1 <= gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000 )||
							(dLenghStrech2 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000 &&
							dLenghStrech2 <= gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000)) // um
						{
							SetProportaionCompensation(TRUE, nBlockNo, dAvgScaleX[0], dAvgScaleY[0], dScale[0], nFidIndex, FALSE);
							bReChange = TRUE;
						}

					}
					else
					{
						if( dLenghStrech1 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000 ||
							dLenghStrech2 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000)// um
						{
							SetProportaionCompensation(TRUE, nBlockNo, dAvgScaleX[0], dAvgScaleY[0], dScale[0], nFidIndex, TRUE); //only log
							bScaleOK[0] = FALSE;
							if(pPanel1st != NULL)
								pPanel1st->nNGType =  FID_NG_LENGH; 
							strMsg.Format(_T("1st Length Tol. Fail Info"));
							strErr.Format(_T("Tolerance Limit : %.3f | Calculated Tolerance X: %.3f | Calculated Tolerance Y: %.3f | Fiducial Block : %d"), 
								gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000, dLenghStrech1, dLenghStrech2, nBlockNo );
							::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
						}
						else
						{
							strMsg.Format(_T("1st Length Tol. Success Info"));
							strErr.Format(_T("Tolerance Limit : %.3f | Calculated Tolerance X: %.3f | Calculated Tolerance Y: %.3f | Fiducial Block : %d"), 
								gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000, dLenghStrech1, dLenghStrech2, nBlockNo );
							::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
						}
					}
#endif
				}
			}

		}
		//ScaleAndLength(nFidBlock, dScale[0],  dLenghStrech1,  dLenghStrech2, TRUE, pPanel1st, pPanel2nd );

		// slave
		nUseFidCount = gDProject.m_RefTrans[1][nBlockNo].GetNumPoint();

		//각변의 센터를 구하여 위아래좌우 판단 
		dSumX = 0, dSumY= 0;
		for(int i = 0; i< nUseFidCount; i++)
		{
			dp1		= gDProject.m_RefTrans[1][nBlockNo].GetRefsPoint(i);
			dSumX += dp1.x;
			dSumY += dp1.y;
			dCenter[0][i].x = dp1.x;
			dCenter[0][i].y = dp1.y;
		}
		dAvgX = dSumX/nUseFidCount;
		dAvgY = dSumY/nUseFidCount;

		nLB = -1, nRB = -1, nLT = -1, nRT = -1;

		if(b2ndOK && ( (gDProject.m_nSeparation == USE_DUAL && !m_bOdd) || gDProject.m_nSeparation == USE_2ND) )
		{
			if(nUseFidCount == 2)
			{
				if(fabs(dCenter[0][0].x - dCenter[0][1].x) > fabs(dCenter[0][0].y - dCenter[0][1].y))
				{
					if(dCenter[0][0].x > dCenter[0][1].x)
					{
						nLB = 1; nRB = 0;
					}
					else
					{
						nLB = 0; nRB = 1;
					}
				}
				else
				{
					if(dCenter[0][0].y < dCenter[0][1].y)
					{
						nRT = 1; nRB = 0;
					}
					else
					{
						nRT = 0; nRB = 1;
					}
				}
			}
			else if(nUseFidCount == 3 || nUseFidCount == 4)
			{
				for(int l = 0; l<nUseFidCount; l++)
				{
					dp1		= gDProject.m_RefTrans[1][nBlockNo].GetRefsPoint(l);
					if(dp1.x < dAvgX && dp1.y < dAvgY)
						nLB = l;
					else if(dp1.x >= dAvgX && dp1.y < dAvgY)
						nRB = l;
					else if(dp1.x < dAvgX && dp1.y >= dAvgY)
						nLT = l;
					else if(dp1.x >= dAvgX && dp1.y >= dAvgY)
						nRT = l;
				}
			}
			else
			{
				b1stOK = b2ndOK = FALSE;
				return FALSE;
			}

			//get each scale 
			dRefPos[1][0].x = dRefPos[1][1].x = dRefPos[1][2].x = dRefPos[1][3].x = DBL_MAX;
			if(nLB != -1)
			{
				dRefPos[1][0] = gDProject.m_RefTrans[1][nBlockNo].GetRefsPoint(nLB);
				dFindPos[1][0] = gDProject.m_RefTrans[1][nBlockNo].GetTransPoint(nLB);
			}
			if(nRB != -1)
			{
				dRefPos[1][1] = gDProject.m_RefTrans[1][nBlockNo].GetRefsPoint(nRB);
				dFindPos[1][1] = gDProject.m_RefTrans[1][nBlockNo].GetTransPoint(nRB);
			}
			if(nRT != -1)
			{
				dRefPos[1][2] = gDProject.m_RefTrans[1][nBlockNo].GetRefsPoint(nRT);
				dFindPos[1][2] = gDProject.m_RefTrans[1][nBlockNo].GetTransPoint(nRT);
			}
			if(nLT != -1)
			{
				dRefPos[1][3] = gDProject.m_RefTrans[1][nBlockNo].GetRefsPoint(nLT);
				dFindPos[1][3] = gDProject.m_RefTrans[1][nBlockNo].GetTransPoint(nLT);
			}
			dScale[1][0] = dScale[1][1] = dScale[1][2] = dScale[1][3] = 100;

			n1stCntX = 0, n1stCntY = 0;
			dAvgScaleX[1] = dAvgScaleY[1] = 0;
			if(nLB != -1 && nRB != -1)
			{
				dx = dRefPos[1][0].x - dRefPos[1][1].x;		dy = dRefPos[1][0].y - dRefPos[1][1].y;
				dLenRef = sqrt(dx*dx + dy*dy);
				n1stCntX++;
				dx = dFindPos[1][0].x - dFindPos[1][1].x;	dy = dFindPos[1][0].y - dFindPos[1][1].y;
				dLenOffset = sqrt(dx*dx + dy*dy);
				dScale[1][0] = dLenOffset * 100 / dLenRef;
				dAvgScaleX[1] += dScale[1][0];
				m_dCurrentScaleX[1] = dScale[1][0];
				dLengStrech[1][0] = dLenOffset - dLenRef;
			}

			if(nRT != -1 && nRB != -1)
			{
				dx = dRefPos[1][2].x - dRefPos[1][1].x;		dy = dRefPos[1][2].y - dRefPos[1][1].y;
				dLenRef = sqrt(dx*dx + dy*dy);
				n1stCntY++;
				dx = dFindPos[1][2].x - dFindPos[1][1].x;	dy = dFindPos[1][2].y - dFindPos[1][1].y;
				dLenOffset = sqrt(dx*dx + dy*dy);
				dScale[1][1] = dLenOffset * 100 / dLenRef;
				dAvgScaleY[1] += dScale[1][1];
				m_dCurrentScaleY[1] = dScale[1][1];
				dLengStrech[1][1] = dLenOffset - dLenRef;
			}

			if(nRT != -1 && nLT != -1)
			{
				dx = dRefPos[1][2].x - dRefPos[1][3].x;		dy = dRefPos[1][2].y - dRefPos[1][3].y;
				dLenRef = sqrt(dx*dx + dy*dy);
				n1stCntX++;
				dx = dFindPos[1][2].x - dFindPos[1][3].x;	dy = dFindPos[1][2].y - dFindPos[1][3].y;
				dLenOffset = sqrt(dx*dx + dy*dy);
				dScale[1][2] = dLenOffset * 100 / dLenRef;
				dAvgScaleX[1] += dScale[1][2];
				m_dCurrentScaleX[1] = dScale[1][2];
				dLengStrech[1][2] = dLenOffset - dLenRef;
			}

			if(nLB != -1 && nLT != -1)
			{
				dx = dRefPos[1][0].x - dRefPos[1][3].x;		dy = dRefPos[1][0].y - dRefPos[1][3].y;
				dLenRef = sqrt(dx*dx + dy*dy);
				n1stCntY++;
				dx = dFindPos[1][0].x - dFindPos[1][3].x;	dy = dFindPos[1][0].y - dFindPos[1][3].y;
				dLenOffset = sqrt(dx*dx + dy*dy);
				dScale[1][3] = dLenOffset * 100 / dLenRef;
				dAvgScaleY[1] += dScale[1][3];
				m_dCurrentScaleY[1] = dScale[1][3];
				dLengStrech[1][3] = dLenOffset - dLenRef;
			}
			if(nLB != -1 && nRT != -1)
			{
				dx = dRefPos[1][0].x - dRefPos[1][2].x;		dy = dRefPos[1][0].y - dRefPos[1][2].y;
				dLenRef = sqrt(dx*dx + dy*dy);
				dx = dFindPos[1][0].x - dFindPos[1][2].x;	dy = dFindPos[1][0].y - dFindPos[1][2].y;
				dLenOffset = sqrt(dx*dx + dy*dy);
				dDiagonal[0][0] = dLenOffset * 100 / dLenRef;
			}
			if(nRB != -1 && nLT != -1)
			{
				dx = dRefPos[1][1].x - dRefPos[1][3].x;		dy = dRefPos[1][1].y - dRefPos[1][3].y;
				dLenRef = sqrt(dx*dx + dy*dy);
				dx = dFindPos[1][1].x - dFindPos[1][3].x;	dy = dFindPos[1][1].y - dFindPos[1][3].y;
				dLenOffset = sqrt(dx*dx + dy*dy);
				dDiagonal[0][1] = dLenOffset * 100 / dLenRef;
			}
			bScaleOK[1] = TRUE;

			if(m_nCurrentLotCount == 0)
				{
				CalculateAvgScale();
				CheckAbsoluteScale( bScaleOK[1]);
			}
			if(n1stCntX)
			{
				dAvgScaleX[1] /= n1stCntX;
			}
			else
			{
				dAvgScaleX[1] = 100;
			}
			if(n1stCntY)
			{
				dAvgScaleY[1] /= n1stCntY;
			}
			else
			{
				dAvgScaleY[1] = 100;
			}

			m_dCurrentScaleX[1] = dAvgScaleX[1];
			m_dCurrentScaleY[1] = dAvgScaleY[1];

		

			int nFidIndex[4];
			nFidIndex[0] = nLB; nFidIndex[1] = nRB; nFidIndex[2] = nRT; nFidIndex[3] = nLT;
			SaveFidCompensation(FALSE, nBlockNo, dAvgScaleX[1], dAvgScaleY[1],dScale[1], nFidIndex, dRefPos[1], dFindPos[1], 0);

			if(gDProject.m_nScaleMode == 0)
			{
				for(int nScaleCheck = 0; nScaleCheck < 4; nScaleCheck++)
				{
					if(nScaleCheck == 0 || nScaleCheck == 2)
					{
						if(dScale[1][nScaleCheck] < gDProject.m_dScaleLimitX2Minus ||dScale[1][nScaleCheck] > gDProject.m_dScaleLimitX2Pluse)
						{
							strScaleInfo[1][nScaleCheck] = _T("NG");
						}
						else
							strScaleInfo[1][nScaleCheck] = _T("OK");
					}
					else if(nScaleCheck == 1 || nScaleCheck == 3)
					{
						if(dScale[1][nScaleCheck] < gDProject.m_dScaleLimitY2Minus ||dScale[1][nScaleCheck] > gDProject.m_dScaleLimitY2Pluse)
						{
							strScaleInfo[1][nScaleCheck] = _T("NG");
						}
						else
							strScaleInfo[1][nScaleCheck] = _T("OK");
					}
				}
				if(dScale[1][0] < gDProject.m_dScaleLimitX2Minus || dScale[1][1] < gDProject.m_dScaleLimitY2Minus ||
					dScale[1][0] > gDProject.m_dScaleLimitX2Pluse || dScale[1][1] > gDProject.m_dScaleLimitY2Pluse ||
					dScale[1][2] < gDProject.m_dScaleLimitX2Minus || dScale[1][3] < gDProject.m_dScaleLimitY2Minus ||
					dScale[1][2] > gDProject.m_dScaleLimitX2Pluse || dScale[1][3] > gDProject.m_dScaleLimitY2Pluse)
				{
					strMsg.Format(_T("2nd Scale Fail Info"));
					strErr.Format(_T("2nd | Avg X Scale : %.3f | Avg Y Scale : %.3f | X Limit : %.3f ~ %.3f | Y Limit : %.3f ~ %.3f |  0 - 1 Scale(X) : %.3f(%s) | 1 - 2 Scale(Y) : %.3f(%s) | 2 - 3 Scale(X) : %.3f(%s) | 3 - 0 Scale(Y) : %.3f(%s) | Fiducial Block : %d"),
						m_dAvgScaleX, m_dAvgScaleY, 
						gDProject.m_dScaleLimitX2Minus, gDProject.m_dScaleLimitX2Pluse, 
						gDProject.m_dScaleLimitY2Minus, gDProject.m_dScaleLimitY2Pluse,
						dScale[1][0], strScaleInfo[1][0], dScale[1][1], strScaleInfo[1][1], dScale[1][2], strScaleInfo[1][2], dScale[1][3], strScaleInfo[1][3], nBlockNo);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
					bScaleOK[1] = FALSE;
					if(pPanel2nd != NULL)
						pPanel2nd->nNGType =  FID_NG_SCALE; 
				}
				else
				{
					strMsg.Format(_T("2nd Scale Success Info"));
					strErr.Format(_T("2nd | Avg X Scale : %.3f | Avg Y Scale : %.3f | X Limit : %.3f ~ %.3f | Y Limit : %.3f ~ %.3f |  0 - 1 Scale(X) : %.3f(%s) | 1 - 2 Scale(Y) : %.3f(%s) | 2 - 3 Scale(X) : %.3f(%s) | 3 - 0 Scale(Y) : %.3f(%s) | Fiducial Block : %d"),
						m_dAvgScaleX, m_dAvgScaleY, 
						gDProject.m_dScaleLimitX2Minus, gDProject.m_dScaleLimitX2Pluse, 
						gDProject.m_dScaleLimitY2Minus, gDProject.m_dScaleLimitY2Pluse,
						dScale[1][0], strScaleInfo[1][0], dScale[1][1], strScaleInfo[1][1], dScale[1][2], strScaleInfo[1][2], dScale[1][3], strScaleInfo[1][3], nBlockNo);
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
				}


				if(n1stCntX > 1 && n1stCntY > 1) // 거리벌 상대적 위치 편차로 양불 판정이 가능한 경우
				{
#ifndef __FID_X_Y__
					dLenghStrech1 = sqrt((dLengStrech[1][0] - dLengStrech[1][2]) * (dLengStrech[1][0] - dLengStrech[1][2]) + 
						(dLengStrech[1][1] - dLengStrech[1][3]) * (dLengStrech[1][1] - dLengStrech[1][3]));

					m_dLengthStrech[1][0] = dLenghStrech1; // // 20130404 bhlee 

					if(gProcessINI.m_sProcessFidFind.bUseProportionCompensation)
					{
						m_dLengthStrechLimit = gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000;
						if( dLenghStrech1 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000  && 
							dLenghStrech1 <= gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000 )// um
						{
							SetProportaionCompensation(FALSE, nBlockNo, dAvgScaleX[1], dAvgScaleY[1], dScale[1], nFidIndex, FALSE);
							bReChange = TRUE;
						}
						else if(dLenghStrech1 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000)
						{
							bScaleOK[1] = FALSE;
							if(pPanel2nd != NULL)
								pPanel2nd->nNGType =   FID_NG_LENGH2; 
							strMsg.Format(_T("2nd Length Tol. Fail Info"));
							strErr.Format(_T("Tolerance Limit : %.3f | Calculated Tolerance : %.3f | Fiducial Block : %d"), gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000, dLenghStrech1, nBlockNo );
							::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
						}
					}
					else
					{
						if( dLenghStrech1 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000 )// um
						{
							SetProportaionCompensation(FALSE, nBlockNo, dAvgScaleX[1], dAvgScaleY[1], dScale[1], nFidIndex, TRUE); //only log
							bScaleOK[1] = FALSE;
							if(pPanel2nd != NULL)
								pPanel2nd->nNGType =   FID_NG_LENGH; 
							strMsg.Format(_T("2nd Length Tol. Fail Info"));
							strErr.Format(_T("Tolerance Limit : %.3f | Calculated Tolerance : %.3f | Fiducial Block : %d"), gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000, dLenghStrech1, nBlockNo );
							::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
						}
						else
						{
							strMsg.Format(_T("2nd Length Tol. Success Info"));
							strErr.Format(_T("Tolerance Limit : %.3f | Calculated Tolerance : %.3f | Fiducial Block : %d"), gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000, dLenghStrech1, nBlockNo );
							::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
						}
					}
#else 
					dLenghStrech1 = fabs(dLengStrech[1][0] - dLengStrech[1][2]); 
					dLenghStrech2 = fabs(dLengStrech[1][1] - dLengStrech[1][3]);

					m_dLengthStrech[1][0] = dLenghStrech1; // // 20130404 bhlee 
					m_dLengthStrech[1][1] = dLenghStrech2;

					if(gProcessINI.m_sProcessFidFind.bUseProportionCompensation)
					{
						m_dLengthStrechLimit = gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000;
						if( dLenghStrech1 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000 ||
							dLenghStrech2 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000)// um
						{
							bScaleOK[1] = FALSE;
							if(pPanel2nd != NULL)
								pPanel2nd->nNGType =   FID_NG_LENGH2; 
							strMsg.Format(_T("2nd Length Tol. Fail Info"));
							strErr.Format(_T("Tolerance Limit : %.3f | Calculated Tolerance X: %.3f | Calculated Tolerance Y: %.3f | Fiducial Block : %d"), 
								gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000, dLenghStrech1, dLenghStrech2, nFidBlock );
							::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
						}
						else if(( dLenghStrech1 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000 &&
							dLenghStrech1 <= gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000 )||
							(dLenghStrech2 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000 &&
							dLenghStrech2 <= gProcessINI.m_sProcessFidFind.dPCBLenTolerance2 * 1000)) // um
						{
							SetProportaionCompensation(FALSE, nBlockNo, dAvgScaleX[1], dAvgScaleY[1], dScale[1], nFidIndex, FALSE);
							bReChange = TRUE;
						}
					}
					else
					{
						if( dLenghStrech1 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000 ||
							dLenghStrech2 > gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000)// um
						{
							SetProportaionCompensation(FALSE, nBlockNo, dAvgScaleX[1], dAvgScaleY[1], dScale[1], nFidIndex, TRUE); //only log
							bScaleOK[1] = FALSE;
							if(pPanel2nd != NULL)
								pPanel2nd->nNGType =   FID_NG_LENGH; 
							strMsg.Format(_T("2nd Length Tol. Fail Info"));
							strErr.Format(_T("Tolerance Limit : %.3f | Calculated Tolerance X: %.3f | Calculated Tolerance Y: %.3f | Fiducial Block : %d"), 
								gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000, dLenghStrech1, dLenghStrech2, nBlockNo );
							::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
						}
						else
						{
							strMsg.Format(_T("2nd Length Tol. Success Info"));
							strErr.Format(_T("Tolerance Limit : %.3f | Calculated Tolerance X: %.3f | Calculated Tolerance Y: %.3f | Fiducial Block : %d"), 
								gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000, dLenghStrech1, dLenghStrech2, nBlockNo );
							::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );
						}
					}
#endif
				}
			}
		}
		//ScaleAndLength(nFidBlock, dScale[1],  dLenghStrech1,  dLenghStrech2, FALSE, pPanel1st, pPanel2nd );

		SaveFiducialScale(nUseFidCount, dRefPos[0], dFindPos[0], dAvgScaleX, dAvgScaleY, bScaleOK, dLenghStrech1, dLenghStrech2, dDiagonal[0], nBlockNo);
		b1stOK = bScaleOK[0];
		b2ndOK = bScaleOK[1];
		
		gOPCParam.dScale[0] = (dAvgScaleX[0] + dAvgScaleY[0])/2.;
		gOPCParam.dScale[1] = (dAvgScaleX[1] + dAvgScaleY[1])/2.;
		gOPCParam.dLengthTol[0] = gProcessINI.m_sProcessFidFind.dPCBLenTolerance;
		gOPCParam.dLengthTol[1] = gProcessINI.m_sProcessFidFind.dPCBLenTolerance2;
		OPCUpdateParameter(N_SCALE);
		
		if( !bScaleOK[0] || !bScaleOK[1]) 
		{
			return FALSE;
		}
	}
	return TRUE;
}

void CPaneAutoRun::ScaleAndLength(int nFidBlock, double* dScale, double dLenghStrech1, double dLenghStrech2, BOOL bMaster, LPPNLFIDINFO pPanel1st , LPPNLFIDINFO pPanel2nd)
{
/*
	CString strFile, str;
	strFile.Format(_T("FiducialResultPaneError"));
	LPFIDRESULT pResultM, pResultS; 
	int nTotalCnt = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);
	LPFIDDATA pFidData;

	for(int i = 0; i< nTotalCnt; i++)
	{
		pFidData = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
		if(pFidData->nFidType & FID_VERIFY)
			nTotalCnt = nTotalCnt - 1;

		if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
		{
			pResultM = gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].GetFidResult(pPanel1st, i, nFidBlock);
			pResultS = gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].GetFidResult(pPanel2nd, i, nFidBlock);
			if(pResultM == NULL || pResultS == NULL)
			{
				if(pResultM == NULL && pResultS == NULL)
					str.Format(_T("Master, Slave all"));
				else if(pResultM == NULL)
					str.Format(_T("Master, -"));
				else
					str.Format(_T("- , Slave"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
				return;
			}
		}
		else if( gDProject.m_nSeparation == USE_1ST || (gDProject.m_nSeparation == USE_DUAL && m_bOdd))
		{
			pResultM = gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].GetFidResult(pPanel1st, i, nFidBlock);
			if(pResultM == NULL)
			{
				CString strFile;
				str.Format(_T("Master"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
				return;
			}
		}
		if(gDProject.m_nSeparation == USE_2ND)
		{
			pResultS = gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].GetFidResult(pPanel2nd, i, nFidBlock);
			if(pResultS == NULL)
			{
				CString strFile;
				str.Format(_T("Slave"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&str));
				return;
			}
		}
	
		if(gDProject.m_nSeparation == USE_1ST|| (gDProject.m_nSeparation == USE_DUAL && m_bOdd))
		{
			if(bMaster)
			{
				pResultM->dScaleCheck[i] = dScale[i];
				if(i % 2 == 0 )
				{
					pResultM->dLenghStrech1 = dLenghStrech1;
					pResultM->dLenghStrech2 = 0; 
				}
				else
				{
					pResultM->dLenghStrech1 = 0;
					pResultM->dLenghStrech2 = dLenghStrech2;
				}
			}
		}
		else if(gDProject.m_nSeparation == USE_2ND)
		{
			if(!bMaster)
			{
				pResultS->dScaleCheck[i] = dScale[i];
				if(i % 2 == 0 )
				{
					pResultS->dLenghStrech1 = dLenghStrech1;
					pResultS->dLenghStrech2 = 0; 
				}
				else
				{
					pResultS->dLenghStrech1 = 0;
					pResultS->dLenghStrech2 = dLenghStrech2;
				}
			}
		}
		else if(gDProject.m_nSeparation == USE_DUAL)
		{
			if(bMaster)
			{
				pResultM->dScaleCheck[i] = dScale[i];
				if(i % 2 == 0 )
				{
					pResultM->dLenghStrech1 = dLenghStrech1;
					pResultM->dLenghStrech2 = 0; 
				}
				else
				{
					pResultM->dLenghStrech1 = 0;
					pResultM->dLenghStrech2 = dLenghStrech2;
				}
				
			}
			else
			{
				pResultS->dScaleCheck[i] = dScale[i];
				if(i % 2 == 0 )
				{
					pResultS->dLenghStrech1 = dLenghStrech1;
					pResultS->dLenghStrech2 = 0; 
				}
				else
				{
					pResultS->dLenghStrech1 = 0;
					pResultS->dLenghStrech2 = dLenghStrech2;
				}
			}
		}
	}
	*/
}

BOOL CPaneAutoRun::CalLength(BOOL bLog, int nFidKind, int nFidBlock, LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd )
{
	double dTransLen, dRefLen;
	DPOINT dTemp1, dTemp2;

	int nAddProperty = 0, nDelProperty = 0;
	if(nFidKind == DEFAULT_FID_INDEX)
	{
		nAddProperty = FID_FIND;
		nDelProperty = FID_VERIFY;
	}
	else
		nAddProperty = FID_DRILL;
		
	LPFIDDATA pFidData;
	LPFIDRESULT pResultM, pResultS; 
	LPFIDRESULT pResultListM[4], pResultListS[4]; 

	int nStartBlock = 0, nEndBlock = gDProject.m_nMaxFidBlock;
	if(nFidBlock != -1)
	{
		nStartBlock = nFidBlock, nEndBlock = nFidBlock;
	}

	for(int nBlock = nStartBlock; nBlock <= nEndBlock; nBlock++)
	{
		int nTotalCnt = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, nAddProperty, nDelProperty, nBlock);
		int nFidCenterX = 0, nFidCenterY = 0;
		int nFidCntPerBlock = 0;
		int nPosIndex;
		for(int i = 0; i< nTotalCnt; i++)
		{
			pFidData = gDProject.m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, i, nAddProperty, nDelProperty, nBlock);
			nFidCenterX += pFidData->npPosition.x; nFidCenterY += pFidData->npPosition.y;
			nFidCntPerBlock++;
		}
		if(nFidCntPerBlock > 0)
		{
			nFidCenterX /= nFidCntPerBlock; nFidCenterY /= nFidCntPerBlock;
		}

		pResultListM[0] = pResultListM[1] = pResultListM[2] =pResultListM[3] = NULL;
		pResultListS[0] = pResultListS[1] = pResultListS[2] =pResultListS[3] = NULL;
		for(int i = 0; i< nTotalCnt; i++)
		{
			pFidData = gDProject.m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, i, nAddProperty, nDelProperty, nBlock);
			nPosIndex = GetFidRectPosIndex(nFidCenterX, nFidCenterY, pFidData);

			if(pPanel1st)
			{
				pResultM = gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].GetFidResult(pPanel1st, pFidData->npPosition, nBlock);
				pResultListM[nPosIndex] = pResultM;
			}
			if(pPanel2nd)
			{
				pResultS = gDProject.m_Glyphs.m_FiducialData[DEFAULT_FID_INDEX].GetFidResult(pPanel2nd, pFidData->npPosition, nBlock);
				pResultListS[nPosIndex] = pResultS;
			}
		}

		// 4 라인 scale 넣기
		if(pResultListM[0] != NULL && pResultListM[1] != NULL)
		{
			dTemp1.x = (double) pResultListM[0]->npRefPosition.x;
			dTemp1.y = (double) pResultListM[0]->npRefPosition.y;
			dTemp2.x = (double) pResultListM[1]->npRefPosition.x;
			dTemp2.y = (double) pResultListM[1]->npRefPosition.y;
			dRefLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			dTemp1.x += (double) pResultListM[0]->npOffset.x;
			dTemp1.y += (double) pResultListM[0]->npOffset.y;
			dTemp2.x += (double) pResultListM[1]->npOffset.x;
			dTemp2.y += (double) pResultListM[1]->npOffset.y;
			dTransLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			pResultListM[0]->dScale = dTransLen / dRefLen * 100;
			pResultListM[0]->npScaleDPPos.x = (pResultListM[0]->npRefPosition.x + pResultListM[1]->npRefPosition.x) / 2;
			pResultListM[0]->npScaleDPPos.y = (pResultListM[0]->npRefPosition.y + pResultListM[1]->npRefPosition.y) / 2;
		}
		if(pResultListM[1] != NULL && pResultListM[3] != NULL)
		{
			dTemp1.x = (double) pResultListM[1]->npRefPosition.x;
			dTemp1.y = (double) pResultListM[1]->npRefPosition.y;
			dTemp2.x = (double) pResultListM[3]->npRefPosition.x;
			dTemp2.y = (double) pResultListM[3]->npRefPosition.y;
			dRefLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			dTemp1.x += (double) pResultListM[1]->npOffset.x;
			dTemp1.y += (double) pResultListM[1]->npOffset.y;
			dTemp2.x += (double) pResultListM[3]->npOffset.x;
			dTemp2.y += (double) pResultListM[3]->npOffset.y;
			dTransLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			pResultListM[1]->dScale = dTransLen / dRefLen * 100;
			pResultListM[1]->npScaleDPPos.x = (pResultListM[1]->npRefPosition.x + pResultListM[3]->npRefPosition.x) / 2;
			pResultListM[1]->npScaleDPPos.y = (pResultListM[1]->npRefPosition.y + pResultListM[3]->npRefPosition.y) / 2;
		}
		if(pResultListM[3] != NULL && pResultListM[2] != NULL)
		{
			dTemp1.x = (double) pResultListM[3]->npRefPosition.x;
			dTemp1.y = (double) pResultListM[3]->npRefPosition.y;
			dTemp2.x = (double) pResultListM[2]->npRefPosition.x;
			dTemp2.y = (double) pResultListM[2]->npRefPosition.y;
			dRefLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			dTemp1.x += (double) pResultListM[3]->npOffset.x;
			dTemp1.y += (double) pResultListM[3]->npOffset.y;
			dTemp2.x += (double) pResultListM[2]->npOffset.x;
			dTemp2.y += (double) pResultListM[2]->npOffset.y;
			dTransLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			pResultListM[3]->dScale = dTransLen / dRefLen * 100;
			pResultListM[3]->npScaleDPPos.x = (pResultListM[3]->npRefPosition.x + pResultListM[2]->npRefPosition.x) / 2;
			pResultListM[3]->npScaleDPPos.y = (pResultListM[3]->npRefPosition.y + pResultListM[2]->npRefPosition.y) / 2;
		}
		if(pResultListM[2] != NULL && pResultListM[0] != NULL)
		{
			dTemp1.x = (double) pResultListM[2]->npRefPosition.x;
			dTemp1.y = (double) pResultListM[2]->npRefPosition.y;
			dTemp2.x = (double) pResultListM[0]->npRefPosition.x;
			dTemp2.y = (double) pResultListM[0]->npRefPosition.y;
			dRefLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			dTemp1.x += (double) pResultListM[2]->npOffset.x;
			dTemp1.y += (double) pResultListM[2]->npOffset.y;
			dTemp2.x += (double) pResultListM[0]->npOffset.x;
			dTemp2.y += (double) pResultListM[0]->npOffset.y;
			dTransLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			pResultListM[2]->dScale = dTransLen / dRefLen * 100;
			pResultListM[2]->npScaleDPPos.x = (pResultListM[2]->npRefPosition.x + pResultListM[0]->npRefPosition.x) / 2;
			pResultListM[2]->npScaleDPPos.y = (pResultListM[2]->npRefPosition.y + pResultListM[0]->npRefPosition.y) / 2;
		}

		if(pResultListS[0] != NULL && pResultListS[1] != NULL)
		{
			dTemp1.x = (double) pResultListS[0]->npRefPosition.x;
			dTemp1.y = (double) pResultListS[0]->npRefPosition.y;
			dTemp2.x = (double) pResultListS[1]->npRefPosition.x;
			dTemp2.y = (double) pResultListS[1]->npRefPosition.y;
			dRefLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			dTemp1.x += (double) pResultListS[0]->npOffset.x;
			dTemp1.y += (double) pResultListS[0]->npOffset.y;
			dTemp2.x += (double) pResultListS[1]->npOffset.x;
			dTemp2.y += (double) pResultListS[1]->npOffset.y;
			dTransLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			pResultListS[0]->dScale = dTransLen / dRefLen * 100;
			pResultListS[0]->npScaleDPPos.x = (pResultListS[0]->npRefPosition.x + pResultListS[1]->npRefPosition.x) / 2;
			pResultListS[0]->npScaleDPPos.y = (pResultListS[0]->npRefPosition.y + pResultListS[1]->npRefPosition.y) / 2;
		}
		if(pResultListS[1] != NULL && pResultListS[3] != NULL)
		{
			dTemp1.x = (double) pResultListS[1]->npRefPosition.x;
			dTemp1.y = (double) pResultListS[1]->npRefPosition.y;
			dTemp2.x = (double) pResultListS[3]->npRefPosition.x;
			dTemp2.y = (double) pResultListS[3]->npRefPosition.y;
			dRefLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			dTemp1.x += (double) pResultListS[1]->npOffset.x;
			dTemp1.y += (double) pResultListS[1]->npOffset.y;
			dTemp2.x += (double) pResultListS[3]->npOffset.x;
			dTemp2.y += (double) pResultListS[3]->npOffset.y;
			dTransLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			pResultListS[1]->dScale = dTransLen / dRefLen * 100;
			pResultListS[1]->npScaleDPPos.x = (pResultListS[1]->npRefPosition.x + pResultListS[3]->npRefPosition.x) / 2;
			pResultListS[1]->npScaleDPPos.y = (pResultListS[1]->npRefPosition.y + pResultListS[3]->npRefPosition.y) / 2;
		}
		if(pResultListS[3] != NULL && pResultListS[2] != NULL)
		{
			dTemp1.x = (double) pResultListS[3]->npRefPosition.x;
			dTemp1.y = (double) pResultListS[3]->npRefPosition.y;
			dTemp2.x = (double) pResultListS[2]->npRefPosition.x;
			dTemp2.y = (double) pResultListS[2]->npRefPosition.y;
			dRefLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			dTemp1.x += (double) pResultListS[3]->npOffset.x;
			dTemp1.y += (double) pResultListS[3]->npOffset.y;
			dTemp2.x += (double) pResultListS[2]->npOffset.x;
			dTemp2.y += (double) pResultListS[2]->npOffset.y;
			dTransLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			pResultListS[3]->dScale = dTransLen / dRefLen * 100;
			pResultListS[3]->npScaleDPPos.x = (pResultListS[3]->npRefPosition.x + pResultListS[2]->npRefPosition.x) / 2;
			pResultListS[3]->npScaleDPPos.y = (pResultListS[3]->npRefPosition.y + pResultListS[2]->npRefPosition.y) / 2;
		}
		if(pResultListS[2] != NULL && pResultListS[0] != NULL)
		{
			dTemp1.x = (double) pResultListS[2]->npRefPosition.x;
			dTemp1.y = (double) pResultListS[2]->npRefPosition.y;
			dTemp2.x = (double) pResultListS[0]->npRefPosition.x;
			dTemp2.y = (double) pResultListS[0]->npRefPosition.y;
			dRefLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			dTemp1.x += (double) pResultListS[2]->npOffset.x;
			dTemp1.y += (double) pResultListS[2]->npOffset.y;
			dTemp2.x += (double) pResultListS[0]->npOffset.x;
			dTemp2.y += (double) pResultListS[0]->npOffset.y;
			dTransLen = sqrt( (dTemp1.x - dTemp2.x)*(dTemp1.x - dTemp2.x) + (dTemp1.y - dTemp2.y) * (dTemp1.y - dTemp2.y));

			pResultListS[2]->dScale = dTransLen / dRefLen * 100;
			pResultListS[2]->npScaleDPPos.x = (pResultListS[2]->npRefPosition.x + pResultListS[0]->npRefPosition.x) / 2;
			pResultListS[2]->npScaleDPPos.y = (pResultListS[2]->npRefPosition.y + pResultListS[0]->npRefPosition.y) / 2;
		}
	}
	return TRUE;
}
BOOL CPaneAutoRun::OnlyTransform(int nFidKind, int nFindMethod, int nFindFiducialType, int nFidBlock, int nDualMode, BOOL& b1stOK, BOOL& b2ndOK)
{
	int nError;
	nError = gDProject.OnlyTransform(nFidKind, nFindMethod, nFindFiducialType, nFidBlock, nDualMode, b1stOK, b2ndOK);
	if(nError == TABLE_MOVE_ERROR)
	{
		m_nErrMsgID = STDGNALM662;
	}
	else if(nError == MISSHOT_ERROR)
	{
		m_nErrMsgID = STDGNALM659;
	}
	else if(nError == FIDUCIAL_TRANS_ERROR)
	{
		m_nErrMsgID = STDGNALM659;
	}
	else if(nError == OUT_TABLE_FIRE)
	{
		m_nErrMsgID = STDGNALM663;
	}

	if(nError != 0) // MISSHOT_ERROR || nError == FIDUCIAL_TRANS_ERROR || nError == OUT_TABLE_FIRE)
		return FALSE;
	
	return TRUE;
}
BOOL CPaneAutoRun::ApplyFidDataToShot(int nFidKind, int nFindMethod, int nFindFiducialType, int nFidBlock, int nDualMode, BOOL& b1stOK, BOOL& b2ndOK, BOOL bCompensationMode)
{
	TRACE("ApplyFidDataToShot Start....\r\n");
	int nError;
	if(nFindFiducialType || nFidKind == ADDED_FID_INDEX) // corse fid or skiving
		nError = gDProject.ApplyFidDataToShot_Coarse(FID_SECONDARY, nFindMethod, nDualMode, b1stOK, b2ndOK, bCompensationMode);
	else
	{
		if(gSystemINI.m_sSystemDevice.nFiducialFindType == 0)
			nError = gDProject.ApplyFidDataToShot(nFidKind, nFindMethod, nDualMode, b1stOK, b2ndOK);
		else
			nError = gDProject.ApplyFidDataToShot_MultiFiducial(nFidKind, nFindMethod, (!m_bAutoRun & m_bSelectFire), nFidBlock, nDualMode,b1stOK, b2ndOK, bCompensationMode);
	}

	TRACE("ApplyFidDataToShot End!!!!\r\n");
	if(nError == TABLE_MOVE_ERROR)
	{
		m_nErrMsgID = STDGNALM662;
	}
	else if(nError == MISSHOT_ERROR)
	{
		m_nErrMsgID = STDGNALM659;
	}
	else if(nError == FIDUCIAL_TRANS_ERROR)
	{
		m_nErrMsgID = STDGNALM659;
	}
	else if(nError == OUT_TABLE_FIRE)
	{
		m_nErrMsgID = STDGNALM663;
	}
	
	if(nError != 0) // MISSHOT_ERROR || nError == FIDUCIAL_TRANS_ERROR || nError == OUT_TABLE_FIRE)
		return FALSE;

	return TRUE;
}
BOOL CPaneAutoRun::CheckFidTransResultForSample(DAreaInfo *pAreaInfo, int nFidBlock) // 20130312
{
#ifdef __TEST__
	return TRUE;
#endif

	BOOL bFirstHole;
	BOOL bFirstPanel, bSecondPanel;
	GetFirePanelInfo(bFirstPanel, bSecondPanel);
	LPFIREHOLE pHole;
	POSITION pos;	

	CString strFile, strLog;
	strFile.Format(_T("CheckTrans"));
	double dValX, dValY, dTransX, dTransY;

	if(gProcessINI.m_sProcessSystem.bNoUseFiducialFind || 
		gSystemINI.m_sSystemDevice.nNoUseVision)
		return TRUE;

	if(!m_bCanCheckTransValid)
	{
		strLog.Format(_T("Check Imposible : Data is changed"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		return TRUE;
	}

	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		bFirstHole = TRUE;
		pos = pAreaInfo->m_FireHoles[i].GetHeadPosition();
		while(pos)
		{
			pHole = pAreaInfo->m_FireHoles[i].GetNext(pos);

			if( i == ADDED_FID_TOOL || 
				m_bAutoRun ||
				(gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable() &&
				(!m_bSelectFire || (m_bSelectFire && pHole->bSelect))) )
			{
				if(nFidBlock != -1 && pHole->pOrigin->nFidBlock != nFidBlock)
					continue;

				if(!m_bAutoRun && m_bSelectFire)
				{
					BOOL bSelectedFid = FALSE;
					for(int nSelectedBlock = 0; nSelectedBlock < MAX_FID_BLOCK; nSelectedBlock++)
					{
						if(gDProject.m_nSelectedFiducial[nSelectedBlock] == pHole->pOrigin->nFidBlock)
						{
							bSelectedFid = TRUE; break;
						}
					}
					if(!bSelectedFid)
						continue;
				}

				if(bFirstHole)
				{
					bFirstHole = FALSE;
					double dLaserMOffsetX, dLaserMOffsetY, dLaserSOffsetX, dLaserSOffsetY, dPanelOffsetX, dPanelOffsetY;
					gDeviceFactory.GetMotor()->GetAxisMoveOffset(pAreaInfo->m_nTableX/1000., pAreaInfo->m_nTableY/1000., dPanelOffsetX, dPanelOffsetY, DELTA_PANEL_OFFSET);
					gDeviceFactory.GetEocard()->GetLaserOffset(pAreaInfo->m_nTableX/1000., pAreaInfo->m_nTableY/1000., dLaserMOffsetX, dLaserMOffsetY, FIRST_PANEL_OFFSET);
					gDeviceFactory.GetEocard()->GetLaserOffset(pAreaInfo->m_nTableX/1000., pAreaInfo->m_nTableY/1000., dLaserSOffsetX, dLaserSOffsetY, SECOND_PANEL_OFFSET);
					dLaserMOffsetX = dLaserMOffsetX * 1000;
					dLaserMOffsetY = dLaserMOffsetY * 1000;
					dLaserSOffsetX = dLaserSOffsetX * 1000;
					dLaserSOffsetY = dLaserSOffsetY * 1000;

					if(!bFirstPanel)
					{
						dPanelOffsetX = dPanelOffsetY = 0;
					}

					if(bFirstPanel)
					{
						gDProject.m_TablePosTrans[0][nFidBlock].TransformPoint(pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, dValX, dValY);

						dTransX = pAreaInfo->m_nTableX - ((pHole->npPos1.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000 / 65535) - dLaserMOffsetX;
						dTransY = pAreaInfo->m_nTableY - ((pHole->npPos1.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000 / 65535) - dLaserMOffsetY;
						if(fabs(dTransX - dValX) > gProcessINI.m_sProcessFidFind.nHolePreLimit || fabs(dTransY - dValY) > gProcessINI.m_sProcessFidFind.nHolePreLimit)
						{
							strLog.Format(_T("Fail : File(%d, %d), Table(%d, %d) : 1st LSB(%d, %d), 2nd LSB(%d, %d), TCal Off(%.3f, %.3f) Laser Off(%.0f, %.0f, %.0f, %.0f) fieldSize %.3f"), 
								pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y,
								pAreaInfo->m_nTableX, pAreaInfo->m_nTableY, pHole->npPos1.x, pHole->npPos1.y, pHole->npPos2.x, pHole->npPos2.y, dPanelOffsetX, dPanelOffsetY,
								dLaserMOffsetX, dLaserMOffsetY, dLaserSOffsetX, dLaserSOffsetY, gSystemINI.m_sSystemDevice.dFieldSize.x);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							strLog.Format(_T("Trans Off(%.3f, %.3f)"), 
								dTransX - dValX, dTransY - dValY);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							return FALSE;
						}
					}
					if(bSecondPanel)
					{
						gDProject.m_TablePosTrans[1][nFidBlock].TransformPoint(pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y, dValX, dValY);

						dTransX = pAreaInfo->m_nTableX - ((pHole->npPos2.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000 / 65535) - dLaserSOffsetX - dPanelOffsetX * 1000;
						dTransY = pAreaInfo->m_nTableY - ((pHole->npPos2.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000 / 65535) - dLaserSOffsetY - dPanelOffsetY * 1000;

						if(fabs(dTransX - dValX) > gProcessINI.m_sProcessFidFind.nHolePreLimit || fabs(dTransY - dValY) > gProcessINI.m_sProcessFidFind.nHolePreLimit)
						{
							strLog.Format(_T("Fail : File(%d, %d), Table(%d, %d) : 1st LSB(%d, %d), 2nd LSB(%d, %d), TCal Off(%.3f, %.3f) Laser Off(%.0f, %.0f, %.0f, %.0f) fieldSize %.3f"), 
								pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y,
								pAreaInfo->m_nTableX, pAreaInfo->m_nTableY, pHole->npPos1.x, pHole->npPos1.y, pHole->npPos2.x, pHole->npPos2.y, dPanelOffsetX, dPanelOffsetY,
								dLaserMOffsetX, dLaserMOffsetY, dLaserSOffsetX, dLaserSOffsetY, gSystemINI.m_sSystemDevice.dFieldSize.x);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							strLog.Format(_T("Trans Off(%.3f, %.3f)"), 
								dTransX - dValX, dTransY - dValY);
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							return FALSE;
						}
					}

					strLog.Format(_T("File(%d, %d), Table(%d, %d) : 1st LSB(%d, %d), 2nd LSB(%d, %d), TCal Off(%.3f, %.3f) Laser Off(%.0f, %.0f, %.0f, %.0f) fieldSize %.3f"), 
						pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y,
						pAreaInfo->m_nTableX, pAreaInfo->m_nTableY, pHole->npPos1.x, pHole->npPos1.y, pHole->npPos2.x, pHole->npPos2.y, dPanelOffsetX, dPanelOffsetY,
						dLaserMOffsetX, dLaserMOffsetY, dLaserSOffsetX, dLaserSOffsetY, gSystemINI.m_sSystemDevice.dFieldSize.x);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

					return TRUE;
				}
			}
		}
	}

	LPFIRELINE pLine;
	CPoint tempPos;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		for(int j = 0; j < gDProject.m_pToolCode[i]->m_SubToolData.GetCount(); j++)
		{
			bFirstHole = TRUE;
			pos = pAreaInfo->m_FireLines[i].GetHeadPosition();
				
			while(pos)
			{
				pLine = pAreaInfo->m_FireLines[i].GetNext(pos);
					
				if( m_bAutoRun ||
					(gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable() &&
					(!m_bSelectFire || (m_bSelectFire && pLine->bSelect))) )
				{
					if(nFidBlock != -1 && pLine->pOrigin->nFidBlock != nFidBlock)
						continue;

					if(!m_bAutoRun && m_bSelectFire)
					{
						BOOL bSelectedFid = FALSE;
						for(int nSelectedBlock = 0; nSelectedBlock < MAX_FID_BLOCK; nSelectedBlock++)
						{
							if(gDProject.m_nSelectedFiducial[nSelectedBlock] == pLine->pOrigin->nFidBlock)
							{
								bSelectedFid = TRUE; break;
							}
						}
						if(!bSelectedFid)
							continue;
					}

					if(bFirstHole)
					{
						bFirstHole = FALSE;
						double dLaserMOffsetX, dLaserMOffsetY, dLaserSOffsetX, dLaserSOffsetY, dPanelOffsetX, dPanelOffsetY;
						gDeviceFactory.GetMotor()->GetAxisMoveOffset(pAreaInfo->m_nTableX/1000., pAreaInfo->m_nTableY/1000., dPanelOffsetX, dPanelOffsetY, DELTA_PANEL_OFFSET);
						gDeviceFactory.GetEocard()->GetLaserOffset(pAreaInfo->m_nTableX/1000., pAreaInfo->m_nTableY/1000., dLaserMOffsetX, dLaserMOffsetY, FIRST_PANEL_OFFSET);
						gDeviceFactory.GetEocard()->GetLaserOffset(pAreaInfo->m_nTableX/1000., pAreaInfo->m_nTableY/1000., dLaserSOffsetX, dLaserSOffsetY, SECOND_PANEL_OFFSET);
						dLaserMOffsetX = dLaserMOffsetX * 1000;
						dLaserMOffsetY = dLaserMOffsetY * 1000;
						dLaserSOffsetX = dLaserSOffsetX * 1000;
						dLaserSOffsetY = dLaserSOffsetY * 1000;

						if(!bFirstPanel)
						{
							dPanelOffsetX = dPanelOffsetY = 0;
						}

						if(bFirstPanel)
						{
							gDProject.m_TablePosTrans[0][nFidBlock].TransformPoint(pLine->npStartPos.x, pLine->npStartPos.y, dValX, dValY);

							dTransX = pAreaInfo->m_nTableX - ((pLine->npFidSPos1.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000 / 65535) - dLaserMOffsetX;
							dTransY = pAreaInfo->m_nTableY - ((pLine->npFidSPos1.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000 / 65535) - dLaserMOffsetY;
							if(fabs(dTransX - dValX) > gProcessINI.m_sProcessFidFind.nHolePreLimit || fabs(dTransY - dValY) > gProcessINI.m_sProcessFidFind.nHolePreLimit)
							{
								strLog.Format(_T("Fail : File(%d, %d), Table(%d, %d) : 1st LSB(%d, %d), 2nd LSB(%d, %d), TCal Off(%.3f, %.3f) Laser Off(%.0f, %.0f, %.0f, %.0f) fieldSize %.3f"), 
									pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y,
									pAreaInfo->m_nTableX, pAreaInfo->m_nTableY, pHole->npPos1.x, pHole->npPos1.y, pHole->npPos2.x, pHole->npPos2.y, dPanelOffsetX, dPanelOffsetY,
									dLaserMOffsetX, dLaserMOffsetY, dLaserSOffsetX, dLaserSOffsetY, gSystemINI.m_sSystemDevice.dFieldSize.x);
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
								strLog.Format(_T("Trans Off(%.3f, %.3f)"), 
								dTransX - dValX, dTransY - dValY);
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
								return FALSE;
							}
						}
						if(bSecondPanel)
						{
							gDProject.m_TablePosTrans[1][nFidBlock].TransformPoint(pLine->npStartPos.x, pLine->npStartPos.y, dValX, dValY);

							dTransX = pAreaInfo->m_nTableX - ((pLine->npFidSPos2.x - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000 / 65535) - dLaserSOffsetX - dPanelOffsetX * 1000;
							dTransY = pAreaInfo->m_nTableY - ((pLine->npFidSPos2.y - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000 / 65535) - dLaserSOffsetY - dPanelOffsetY * 1000;

							if(fabs(dTransX - dValX) > gProcessINI.m_sProcessFidFind.nHolePreLimit || fabs(dTransY - dValY) > gProcessINI.m_sProcessFidFind.nHolePreLimit)
							{
								strLog.Format(_T("Fail : File(%d, %d), Table(%d, %d) : 1st LSB(%d, %d), 2nd LSB(%d, %d), TCal Off(%.3f, %.3f) Laser Off(%.0f, %.0f, %.0f, %.0f) fieldSize %.3f"), 
									pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y,
									pAreaInfo->m_nTableX, pAreaInfo->m_nTableY, pHole->npPos1.x, pHole->npPos1.y, pHole->npPos2.x, pHole->npPos2.y, dPanelOffsetX, dPanelOffsetY,
									dLaserMOffsetX, dLaserMOffsetY, dLaserSOffsetX, dLaserSOffsetY, gSystemINI.m_sSystemDevice.dFieldSize.x);
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
								strLog.Format(_T("Trans Off(%.3f, %.3f)"), 
								dTransX - dValX, dTransY - dValY);
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
								return FALSE;
							}
						}

						strLog.Format(_T("File(%d, %d), Table(%d, %d) : 1st LSB(%d, %d), 2nd LSB(%d, %d), TCal Off(%.3f, %.3f) Laser Off(%.0f, %.0f, %.0f, %.0f) fieldSize %.3f"), 
							pLine->npStartPos.x, pLine->npStartPos.y,
							pAreaInfo->m_nTableX, pAreaInfo->m_nTableY, pLine->npFidSPos1.x, pLine->npFidSPos1.y, pLine->npFidSPos2.x, pLine->npFidSPos2.y, dPanelOffsetX, dPanelOffsetY,
							dLaserMOffsetX, dLaserMOffsetY, dLaserSOffsetX, dLaserSOffsetY, gSystemINI.m_sSystemDevice.dFieldSize.x);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

						return TRUE;
					}
				}
			}
		}
	}
	return TRUE;
}

BOOL CPaneAutoRun::FireBoard(BOOL bSkive, int nFidBlock)
{
//	m_bCheckTablePCB = TRUE;
	CString strSequenceLog;
	strSequenceLog.Format(_T("---Fire Board Start---"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
	int nStartTool = 1, nEndTool = MAX_TOOL_NO; // 0번 tool 제외하고 모두 
	int nCount = 0;
	int	nSeparation = 0;

	if(!gProcessINI.m_sProcessSystem.bNoUseNGBox)	// 20130502 bskim NG Box용 separation 설정
		nSeparation = m_nBackupSeparation;	// NG box를 사용하면 separation은 항상 Backup된 separation을 따라 Unloading 해야되기 때문에
	else
		nSeparation = gDProject.m_nSeparation;

	if(bSkive) // 0번 tool 만 가공
	{
		nStartTool = ADDED_FID_TOOL;
		nEndTool = ADDED_FID_TOOL + 1;
	}

	m_dPosZ1New = m_dPosZ1Old = m_dPosZ2New = m_dPosZ2Old = -1;
	m_nMask1Old = -1;
	m_dPosC1Old = m_dPosC2Old = -1;
	
	// 가공할 것이 있는 tool 만 areaTempList에 저장
	AreaList AreaTempList;
	POSITION posArea;
	DAreaInfo *pAreaInfo, *pAreaInfoOld;
	int nHoleLogIndex[5], nRefVal[5], nLogIndex = 0;
	for(int i = 0; i < 5; i++)
	{
		nHoleLogIndex[i] = -1; nRefVal[i] = INT_MAX;
	}
	for(int i = nStartTool; i < nEndTool; i++)
	{
		posArea = gDProject.m_Areas[i].GetHeadPosition();
		while (posArea) 
		{
			pAreaInfo = gDProject.m_Areas[i].GetNext(posArea);
			if(IsAvailableArea(pAreaInfo, i, nFidBlock))
			{
				AreaTempList.AddTail(pAreaInfo);
				if(abs(pAreaInfo->m_nCenterX - gDProject.m_nMinX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMinY) < nRefVal[0])
				{
					nRefVal[0] = abs(pAreaInfo->m_nCenterX - gDProject.m_nMinX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMinY);
					nHoleLogIndex[0] = nLogIndex;
				}
				if(abs(pAreaInfo->m_nCenterX - gDProject.m_nMaxX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMinY) < nRefVal[1])
				{
					nRefVal[1] = abs(pAreaInfo->m_nCenterX - gDProject.m_nMaxX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMinY);
					nHoleLogIndex[1] = nLogIndex;
				}
				if(abs(pAreaInfo->m_nCenterX - gDProject.m_nMinX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMaxY) < nRefVal[2])
				{
					nRefVal[2] = abs(pAreaInfo->m_nCenterX - gDProject.m_nMinX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMaxY);
					nHoleLogIndex[2] = nLogIndex;
				}
				if(abs(pAreaInfo->m_nCenterX - gDProject.m_nMaxX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMaxY) < nRefVal[3])
				{
					nRefVal[3] = abs(pAreaInfo->m_nCenterX - gDProject.m_nMaxX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMaxY);
					nHoleLogIndex[3] = nLogIndex;
				}
				if(abs(pAreaInfo->m_nCenterX - (gDProject.m_nMinX + gDProject.m_nMaxX)/2) 
					+ abs(pAreaInfo->m_nCenterY - (gDProject.m_nMinY +  gDProject.m_nMaxY)/2) < nRefVal[4])
				{
					nRefVal[4] = abs(pAreaInfo->m_nCenterX - (gDProject.m_nMinX + gDProject.m_nMaxX)/2) 
							   + abs(pAreaInfo->m_nCenterY - (gDProject.m_nMinY +  gDProject.m_nMaxY)/2);
					nHoleLogIndex[4] = nLogIndex;
				}
				nLogIndex++;
			}
		}
	}

	if(!CheckStatus())
		return FALSE;
	
	m_bStopField = FALSE;
	m_nStopField = -1;

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	m_dTableTime = 0.0;
	m_dScannerTime = 0.0;

	// area 별 가공
	m_bCheckTablePos = m_bCheckAPos = FALSE;
	nCount = AreaTempList.GetCount();

	posArea = AreaTempList.GetHeadPosition(); // 20130312
	BOOL bLogHole;
	int i = 0;
	while(posArea)
	{
		pAreaInfo = AreaTempList.GetNext(posArea);

		if(nHoleLogIndex[0] == i || nHoleLogIndex[1] == i || nHoleLogIndex[2] == i || nHoleLogIndex[3] == i || nHoleLogIndex[4] == i)
		{
			if(!CheckFidTransResultForSample(pAreaInfo, nFidBlock))
			{
				m_nErrMsgID = STDGNALM749;
				return FALSE;
			}
		}
		i++;
	}

	i = 0;
	posArea = AreaTempList.GetHeadPosition();

	int nDualAlignTime, nSingleAlignTime;
	if(gProcessINI.m_sProcessSystem.bNoUsePaper)
	{
		nDualAlignTime = gProcessINI.m_sProcessOption.nAlignDualTimeOnlyPCB;
		nSingleAlignTime = gProcessINI.m_sProcessOption.nAlignSingleTimeOnlyPCB;
	}
	else
	{
		nDualAlignTime = gProcessINI.m_sProcessOption.nAlignDualTime;
		nSingleAlignTime = gProcessINI.m_sProcessOption.nAlignSingleTime;
	}
	double dVibrationTime =0;
	if(nSeparation == USE_DUAL && !m_bOdd) //20130502 bskim
		dVibrationTime = gSystemINI.m_sSystemDevice.nVibrationCount * 2 + (double)gSystemINI.m_sSystemDevice.nVibrationLPTime * 2;
	else
		dVibrationTime = gSystemINI.m_sSystemDevice.nVibrationCount + (double)gSystemINI.m_sSystemDevice.nVibrationLPTime;
	

	int nAlignStartPercent = gProcessINI.m_sProcessOption.nAlignStartPer; // % -> sec
	BOOL bMarkingTimeOK = FALSE;
	BOOL bDoAlign = m_bAlignCommandDoneAfterLoading;
	double dTime, dCompareTime;
	
	
	if(m_dAvgMarkingTime != 0)
	{
		dCompareTime = m_dAvgMarkingTime - nAlignStartPercent  - dVibrationTime - 10; 
		if(dCompareTime < 0 )
			dCompareTime = 0; 
	}
	else //요거 안하면 음수값 퓨퓨 
		dCompareTime = 0;
	int nLoop = 0;

	double dMarkingTimeWait = m_dAvgMarkingTime - dCompareTime;
	if(nSeparation == USE_DUAL && !m_bOdd) //20130502 bskim
	{
		if(nDualAlignTime + dVibrationTime > dMarkingTimeWait)
			dCompareTime = m_dAvgMarkingTime - nDualAlignTime - dVibrationTime - 10 ;
	}
	else
	{
		if(nSingleAlignTime + dVibrationTime > dMarkingTimeWait)
			dCompareTime = m_dAvgMarkingTime - nSingleAlignTime - dVibrationTime - 10 ;
	}

	if(dCompareTime < 0 )
		dCompareTime = 0;

	CString strFile, strLog;
	int nUsePanel;
	if(nSeparation == USE_DUAL) //20130502 bskim
	{
		if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount == 3)
			nUsePanel = 1;
		else
			nUsePanel = 0;
	}
	else if(nSeparation == USE_1ST)
		nUsePanel = 1;
	else
		nUsePanel = 2;

	strFile.Format(_T("AutorunTrace"));
	CString strstr;
	strstr.Format(_T("1. Current Lot Count[%d] = %d, Input Lot Count = %d NGCount = %d, nUsePanel = %d"), m_nCurrentLotIndex, m_nCurrentLotCount, m_nInputLot, m_nNGLotCount, nUsePanel);
	strLog = strstr;
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	BOOL b1st = gDeviceFactory.GetMotor()->IsTable1PCBExist();
	BOOL b2nd = gDeviceFactory.GetMotor()->IsTable2PCBExist();

	int nTotalNGCount = 0;
	if(gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		if(m_nCurrentPrjIndex != 0)
		{
			for(int q = m_nCurrentPrjIndex - 1; q >= 0; q--)
			{
				nTotalNGCount += gLotInfo.nNGLotCount[q];
			}
		}
	}

	while (i < nCount) 
	{
		if(nHoleLogIndex[0] == i || nHoleLogIndex[1] == i || nHoleLogIndex[2] == i || nHoleLogIndex[3] == i || nHoleLogIndex[4] == i)
			bLogHole = TRUE;
		else
			bLogHole = FALSE;
		dTime = m_pMarkingTime.PresentTime();	
		if(!gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader && m_bAutoRun && !bDoAlign )
		{
			LONG lStatus = m_pMotor->GetCurrentError(ERROR_LOAD);
			if(lStatus & 0x0004)
			{
				strstr.Format(_T("Error load detect"));
				strLog = strstr;
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				::Sleep(0);
			}
			else 
			{	
				strstr.Format(_T("dTime %.1f >= dCompareTime %.1f || (double)nDualAlignTime %d > m_dAvgMarkingTime %.1f, GetCurrentLoadDetect(nUsePanel) = %d, IsLoadCartNoPCB() = %d"), dTime, dCompareTime, nDualAlignTime, m_dAvgMarkingTime, pMotor->GetCurrentLoadDetect(nUsePanel), pMotor->IsLoadCartNoPCB());
				strLog = strstr;
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

				if(nSeparation == USE_DUAL && !m_bOdd)
				{
					if(pMotor->GetCurrentLoadDetect(nUsePanel) == PCB_NONE && (m_nCurrentLotCount < m_nInputLot - m_nNGLotCount - 2) )
					{	
						if(m_nCurrentLotCount < 2 || dTime >= dCompareTime || (double)nDualAlignTime > m_dAvgMarkingTime)
						{
							if(!pMotor->IsLoadCartNoPCB())
							{
								if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount == 3 )
								{
#ifdef __PUSAN_LDD__
									pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, 1);
#else
									pMotor->SetOutPort(PORT_PCB_SINGLE, 1);
#endif
									strFile.Format(_T("AutorunTrace"));
									strLog.Format(_T("Use panel info down : 1"));
									::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

								}
								else
								{
#ifdef __PUSAN_LDD__
									pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, 0);
#else
									pMotor->SetOutPort(PORT_PCB_SINGLE, 0);
#endif
									strFile.Format(_T("AutorunTrace"));
									strLog.Format(_T("Use panel info down : 0"));
									::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
								}
								pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, TRUE);
							
								strFile.Format(_T("AutorunTrace"));
								strLog.Format(_T("Align on cmd down"));
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));


							}
							bDoAlign = TRUE;
						}
					}
				}
				else if(nSeparation == USE_1ST)
				{
					if(pMotor->GetCurrentLoadDetect(nUsePanel) == PCB_NONE && (m_nCurrentLotCount < m_nInputLot - m_nNGLotCount - 1))
					{
						if(m_nCurrentLotCount < 1 || dTime >= dCompareTime || (double)nDualAlignTime > m_dAvgMarkingTime)
						{
							if(!pMotor->IsLoadCartNoPCB())
							{
#ifdef __PUSAN_LDD__
								pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, TRUE);
#else
								pMotor->SetOutPort(PORT_PCB_SINGLE, TRUE);
#endif
								strFile.Format(_T("AutorunTrace"));
								strLog.Format(_T("Use panel info down : 1"));
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
								pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, TRUE);

								strLog.Format(_T("Align on cmd down"));
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							}
							bDoAlign = TRUE;
						}
					}				
				}
				else
				{
					if(pMotor->GetCurrentLoadDetect(nUsePanel) == PCB_NONE && (m_nCurrentLotCount < m_nInputLot - m_nNGLotCount - 1))
					{
						if(m_nCurrentLotCount < 1 ||dTime >= dCompareTime || (double)nDualAlignTime > m_dAvgMarkingTime)
						{
							if(!pMotor->IsLoadCartNoPCB())
							{
#ifdef __PUSAN_LDD__
								pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, 2);
#else
								pMotor->SetOutPort(PORT_PCB_SINGLE, 2);
#endif
								strFile.Format(_T("AutorunTrace"));
								strLog.Format(_T("Use panel info down : 2"));
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
								pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, TRUE);

								strFile.Format(_T("AutorunTrace"));
								strLog.Format(_T("Align on cmd down"));
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							}
							bDoAlign = TRUE;
						}
					}						
				}
			}
		}
		MessageLoop();

		if(!gProcessINI.m_sProcessSystem.bNoUseNGBox)	//NG Box 사용하고 
		{
			if(nSeparation == USE_DUAL)	// Dual Panel 이면서
			{
				if( m_nNGBoxCondition == 3)		//Master, Slave 둘다 NG 이면
				{
					m_bStopField = FALSE;
					m_nStopField = -1;
					AreaTempList.RemoveAll(); // 임시로 저장한 area 모두 삭제
					return TRUE;
				}
			}
			else if(nSeparation == USE_1ST)	//1st Panel 만 사용하면서
			{
				if(m_nNGBoxCondition == 1)	//Master 가 NG 이면
				{
					m_bStopField = FALSE;
					m_nStopField = -1;
					AreaTempList.RemoveAll(); // 임시로 저장한 area 모두 삭제
					return TRUE;
				}
			}
			else if(nSeparation == USE_2ND)	//2nd Panel 만 사용하면서
			{
				if(m_nNGBoxCondition == 2)	//Slave 가 NG 이면
				{
					m_bStopField = FALSE;
					m_nStopField = -1;
					AreaTempList.RemoveAll(); // 임시로 저장한 area 모두 삭제
					return TRUE;
				}
			}								
		}	//20130502 bskim

		if(i == 0)
		{
			pAreaInfoOld = AreaTempList.GetNext(posArea);
			if(!DownloadFirstToolMotorPos(NULL, pAreaInfoOld, bSkive)) // x, y, z, (m, c) 축 이동
			{
				m_bStopField = TRUE;
				m_nStopField = pAreaInfoOld->m_nSortIndex;

				AreaTempList.RemoveAll(); 
				return FALSE;
			}
		}

		if(!CheckStatus())
		{
			m_bStopField = TRUE;
			m_nStopField = pAreaInfoOld->m_nSortIndex;

			return FALSE;
		}

		if(i == nCount -1)
			pAreaInfo = NULL;
		else
			pAreaInfo = AreaTempList.GetNext(posArea);
		
		// Move IO
		if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_COMIZOA ||
			gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
		{
			double dX = pAreaInfoOld->m_nTableX / 1000.0 + pAreaInfoOld->m_dTableOffsetX;
			double dY = pAreaInfoOld->m_nTableY / 1000.0 + pAreaInfoOld->m_dTableOffsetY;
#ifndef __MP920_MOTOR__
			DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
			HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
			if(!pMotor->MoveXY(dX, dY, TRUE, AUTORUN_MOVE))
			{
				m_bStopField = TRUE;
				m_nStopField = pAreaInfoOld->m_nSortIndex;
				
				m_nErrMsgID = STDGNALM438;
				AreaTempList.RemoveAll(); 
				return FALSE;
			}
		}
		else
		{
			myTableTime.StartTime();
			if(!MoveIO())
			{
				m_bStopField = TRUE;
				m_nStopField = pAreaInfoOld->m_nSortIndex;
				
				m_nErrMsgID = STDGNALM440;
				AreaTempList.RemoveAll(); 
				return FALSE;
			}
//			CString strFile, strLog;
//			strFile.Format(_T("Inpos"));
//			strLog.Format(_T("MoveIO"));
//			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		}
		m_bCheckTablePos = TRUE;
		
		// downloadFireToolData
		if(!DownloadFirstToolFireInformData(pAreaInfoOld, bSkive))
		{
			m_bStopField = TRUE;
			m_nStopField = pAreaInfoOld->m_nSortIndex;
			
			return FALSE;
		}

		//Inposition check
/*		if(!InPositionCheck())
		{
			m_bStopField = TRUE;
			m_nStopField = pAreaInfoOld->m_nSortIndex;
			
			m_nErrMsgID = STDGNALM441;
			AreaTempList.RemoveAll(); 
			return FALSE;
		}
*/
		
		if(!OneFieldFire(pAreaInfoOld, pAreaInfo, bSkive, nFidBlock, bLogHole)) // if pArreaInfo == NULL : last field
		{
			m_bStopField = TRUE;
			m_nStopField = pAreaInfoOld->m_nSortIndex;
			
			AreaTempList.RemoveAll(); 
			return FALSE;
		}

		if(gDeviceFactory.GetEocard()->GetScannerError(m_nWarningNo, m_nAlarmNo, m_nMaxValue, m_nInposMissNo))
		{
			if(m_nAlarmNo[0] || m_nAlarmNo[1] || m_nAlarmNo[2] || m_nAlarmNo[3])
			{
				CString strFile, strLog;
				strFile.Format(_T("ScannerPosError"));
				strLog.Format(_T("Alarm Cnt : 1st X = %d (Max : %d), 1st Y = %d (Max : %d), 2nd X = %d (Max : %d), 2nd Y = %d (Max : %d), InposMiss 1 = %d, InposMiss 2 = %d"),
					m_nAlarmNo[0], m_nMaxValue[0], m_nAlarmNo[1], m_nMaxValue[1],
					m_nAlarmNo[2], m_nMaxValue[2], m_nAlarmNo[3], m_nMaxValue[3],
					m_nInposMissNo[0], m_nInposMissNo[1]);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				m_nErrMsgID = STDGNALM785;
				
				m_nWarningNo[0] = m_nMaxValue[0] = m_nWarningNo[1] = m_nMaxValue[1] = m_nWarningNo[2] = m_nMaxValue[2] = m_nWarningNo[3] = m_nMaxValue[3] = 0;
				m_nInposMissNo[0] = m_nInposMissNo[1] =0;
				
				m_bStopField = TRUE;
				m_nStopField = pAreaInfoOld->m_nSortIndex;
				AreaTempList.RemoveAll(); 
				return FALSE;
			}
		}

		if(!CheckStatus())
		{
			m_bStopField = TRUE;
			m_nStopField = pAreaInfoOld->m_nSortIndex;

			return FALSE;
		}
		
		pAreaInfoOld = pAreaInfo;
		i++;

#ifdef __TEST__
		::Sleep(500);
#endif
	}
	AreaTempList.RemoveAll(); 

	m_bStopField = FALSE;
	m_nStopField = -1;
	
	// flying 가공
	
	AreaTempList.RemoveAll(); // 임시로 저장한 area 모두 삭제
	
	return TRUE;
}

BOOL CPaneAutoRun::IsAvailableArea(DAreaInfo *pAreaInfo, int nToolNo, int nFidBlock)
{
	if(nToolNo == ADDED_FID_TOOL) // skiving 처리
	{
		int nIndex;
		int nCount = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);
		LPFIDDATA pFidData;
		for(int i = 0; i < nCount; i++)
		{
			pFidData = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			if( (pFidData->nFidType & FID_SECONDARY) && (pFidData->nFidType & FID_DRILL))
			{
				nIndex = gDProject.m_Glyphs.GetUseFidRealIndex(DEFAULT_FID_INDEX, i);
				nIndex = pFidData->nFindIndex; //gDProject.m_Glyphs.GetUseFidRealIndex(ADDED_FID_INDEX, i);
				if(m_bAutoRun) // auto run에서는 select, tool visible에 관계없이 모두 가공한다.
					return TRUE;
				if(!m_bSelectFire || gDProject.m_Glyphs.GetUseFidSelect(DEFAULT_FID_INDEX, i)) //ADDED_FID_INDEX, nIndex))
				{
					if(pAreaInfo->IsThereSkivingData(nIndex, m_bSelectFire))
						return TRUE;
				}
			}
		}
		return FALSE;
	}

	if(pAreaInfo->IsThereSameBlockData(nFidBlock)) // data가 있어야 함.
	{
		if(gDProject.m_ToolSumInfo[gDProject.m_ToolSumInfo[nToolNo].nRealToolNo].nToolAtri == emFlying)
			return FALSE;

		if(pAreaInfo->IsThereSameBlockData(nFidBlock) && m_bAutoRun)
			return TRUE;// auto run에서는 select, tool visible에 관계없이 모두 가공한다.
			

		if(gDProject.m_ToolSumInfo[gDProject.m_ToolSumInfo[nToolNo].nRealToolNo].nToolAtri == emOneBoardTool)
		{
			if(!gDProject.m_pToolCode[nToolNo]->IsVisable() || (!pAreaInfo->IsThereSelectData() && m_bSelectFire))
				return FALSE;
			else
				return TRUE;
		}
		else
		{
			for(int i = nToolNo; i < MAX_TOOL_NO; i++)
			{
				if(pAreaInfo->IsThereSelectData() && m_bSelectFire) // IsThereSelectData : visible tool에 속하는 select 데이터가 있을때
					return TRUE;
				if(pAreaInfo->IsThereData() && !m_bSelectFire)
					return TRUE;
			}
			return FALSE;
		}
		return TRUE;
	}
	else
		return FALSE;
}

BOOL CPaneAutoRun::GetLotInform()
{
#ifndef __KUNSAN_SAMSUNG_LARGE__
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		strcpy_s(gLotInfo.szLotID[0], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[1], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[2], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[3], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[4], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[5], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[6], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[7], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[8], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[9], gDProject.m_szLotId);
	}
	if(gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		CDlgScheduleInfo dlg;
		dlg.SetOnlyDisplay(FALSE);

		if( IDOK != dlg.DoModal() )
			return FALSE;

		gLotInfo.nLastIndex = dlg.m_nLastIndex;

		strcpy_s(gLotInfo.szLotID[0], dlg.m_strLotInfo);
		strcpy_s(gLotInfo.szLotID[1], dlg.m_strLotInfo2);
		strcpy_s(gLotInfo.szLotID[2], dlg.m_strLotInfo3);
		strcpy_s(gLotInfo.szLotID[3], dlg.m_strLotInfo4);
		strcpy_s(gLotInfo.szLotID[4], dlg.m_strLotInfo5);
		strcpy_s(gLotInfo.szLotID[5], dlg.m_strLotInfo6); 
		strcpy_s(gLotInfo.szLotID[6], dlg.m_strLotInfo7);
		strcpy_s(gLotInfo.szLotID[7], dlg.m_strLotInfo8);
		strcpy_s(gLotInfo.szLotID[8], dlg.m_strLotInfo9);
		strcpy_s(gLotInfo.szLotID[9], dlg.m_strLotInfo10);

		gLotInfo.nLotCount[0] = dlg.m_nNo;
		gLotInfo.nLotCount[1] = dlg.m_nNo2;
		gLotInfo.nLotCount[2] = dlg.m_nNo3;
		gLotInfo.nLotCount[3] = dlg.m_nNo4;
		gLotInfo.nLotCount[4] = dlg.m_nNo5;
		gLotInfo.nLotCount[5] = dlg.m_nNo6;
		gLotInfo.nLotCount[6] = dlg.m_nNo7;
		gLotInfo.nLotCount[7] = dlg.m_nNo8;
		gLotInfo.nLotCount[8] = dlg.m_nNo9;
		gLotInfo.nLotCount[9] = dlg.m_nNo10;

		gLotInfo.bMESOK[0] = dlg.m_bMes;
		gLotInfo.bMESOK[1] = dlg.m_bMes2;
		gLotInfo.bMESOK[2] = dlg.m_bMes3;
		gLotInfo.bMESOK[3] = dlg.m_bMes4;
		gLotInfo.bMESOK[4] = dlg.m_bMes5;
		gLotInfo.bMESOK[5] = dlg.m_bMes6;
		gLotInfo.bMESOK[6] = dlg.m_bMes7;
		gLotInfo.bMESOK[7] = dlg.m_bMes8;
		gLotInfo.bMESOK[8] = dlg.m_bMes9;
		gLotInfo.bMESOK[9] = dlg.m_bMes10;

		gLotInfo.bUseMES = dlg.m_bUseMES;

		strcpy_s(gLotInfo.szFilmNo[0], dlg.m_strFilmNo);
		strcpy_s(gLotInfo.szFilmNo[1], dlg.m_strFilmNo2);
		strcpy_s(gLotInfo.szFilmNo[2], dlg.m_strFilmNo3);
		strcpy_s(gLotInfo.szFilmNo[3], dlg.m_strFilmNo4);
		strcpy_s(gLotInfo.szFilmNo[4], dlg.m_strFilmNo5);
		strcpy_s(gLotInfo.szFilmNo[5], dlg.m_strFilmNo6);
		strcpy_s(gLotInfo.szFilmNo[6], dlg.m_strFilmNo7);
		strcpy_s(gLotInfo.szFilmNo[7], dlg.m_strFilmNo8);
		strcpy_s(gLotInfo.szFilmNo[8], dlg.m_strFilmNo9);
		strcpy_s(gLotInfo.szFilmNo[9], dlg.m_strFilmNo10);

		strcpy_s(gLotInfo.szProcessCode[0], dlg.m_strProcessCode);
		strcpy_s(gLotInfo.szProcessCode[1], dlg.m_strProcessCode2);
		strcpy_s(gLotInfo.szProcessCode[2], dlg.m_strProcessCode3);
		strcpy_s(gLotInfo.szProcessCode[3], dlg.m_strProcessCode4);
		strcpy_s(gLotInfo.szProcessCode[4], dlg.m_strProcessCode5);
		strcpy_s(gLotInfo.szProcessCode[5], dlg.m_strProcessCode6);
		strcpy_s(gLotInfo.szProcessCode[6], dlg.m_strProcessCode7);
		strcpy_s(gLotInfo.szProcessCode[7], dlg.m_strProcessCode8);
		strcpy_s(gLotInfo.szProcessCode[8], dlg.m_strProcessCode9);
		strcpy_s(gLotInfo.szProcessCode[9], dlg.m_strProcessCode10);

		strcpy_s(gLotInfo.szPrj[0], dlg.m_strPrj1);
		strcpy_s(gLotInfo.szPrj[1], dlg.m_strPrj2);
		strcpy_s(gLotInfo.szPrj[2], dlg.m_strPrj3);
		strcpy_s(gLotInfo.szPrj[3], dlg.m_strPrj4);
		strcpy_s(gLotInfo.szPrj[4], dlg.m_strPrj5);
		strcpy_s(gLotInfo.szPrj[5], dlg.m_strPrj6);
		strcpy_s(gLotInfo.szPrj[6], dlg.m_strPrj7);
		strcpy_s(gLotInfo.szPrj[7], dlg.m_strPrj8);
		strcpy_s(gLotInfo.szPrj[8], dlg.m_strPrj9);
		strcpy_s(gLotInfo.szPrj[9], dlg.m_strPrj10);

		
		gLotInfo.nFireType[0] = dlg.m_nFireType;
		gLotInfo.nFireType[1] = dlg.m_nFireType2;
		gLotInfo.nFireType[2] = dlg.m_nFireType3;
		gLotInfo.nFireType[3] = dlg.m_nFireType4;
		gLotInfo.nFireType[4] = dlg.m_nFireType5;
		gLotInfo.nFireType[5] = dlg.m_nFireType6;
		gLotInfo.nFireType[6] = dlg.m_nFireType7;
		gLotInfo.nFireType[7] = dlg.m_nFireType8;
		gLotInfo.nFireType[8] = dlg.m_nFireType9;
		gLotInfo.nFireType[9] = dlg.m_nFireType10;

		CString strMsg, strErr, strTemp;
		int nLen;
		for(int k = 0; k< gLotInfo.nLastIndex; k++)
		{
			nLen = 	strlen(gLotInfo.szLotID[k]);
			if(nLen <= 0)
				continue;

			strTemp.Format(_T("#%d : %s\t %d\t %s|"), k+1, gLotInfo.szLotID[k], gLotInfo.nLotCount[k], gLotInfo.szPrj[k]);
			strErr += strTemp;
		}
		strMsg.Format(_T("Lot 정보 입력"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );	

		m_nInputLot = dlg.m_nNo + dlg.m_nNo2 + dlg.m_nNo3 + dlg.m_nNo4 + dlg.m_nNo5 + dlg.m_nNo6 + dlg.m_nNo7 + dlg.m_nNo8 + dlg.m_nNo9 + dlg.m_nNo10;
			
		CString strData;
		strData.Format(_T("%d PNL"), m_nInputLot);
		m_btnLotInput.SetWindowText( (LPCTSTR)strData );

 		if(!AutoOpenProject(FALSE))
		{
			CString str;
			int nIndex = GetCurrentLotID(str, str, str, str);
	
			if(nIndex >= gLotInfo.nLastIndex)
			{
				ErrMsgDlg(STDGNALM212);
				return FALSE;
			}
			else
			{
				ErrMsgDlg(STDGNALM103);
				return FALSE;
			}
		}
		if(gLotInfo.bUseMES && !gLotInfo.bMESOK[m_nCurrentPrjIndex])
		{
			strMsg.Format(_T("Lot ID : %s\nPlease Check MES"), gLotInfo.szLotID[m_nCurrentPrjIndex]);
			ErrMessage(strMsg);
			return FALSE;
		}
	}
	else
	{
		if(m_bAutoRun)
		{
			if(!GetLotCntAndMarkIndex())
			{
				return FALSE;
			}
		}
	}
#else
	
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		if((strcmp(gLotInfo.szPrj[0],"" ) == 0|| strcmp(gLotInfo.szPrj[0]," " ) == 0 )&&
			(strcmp(gLotInfo.szLotID[0],"" ) == 0|| strcmp(gLotInfo.szLotID[0]," " ) == 0 ))
		{
			memset(gLotInfo.szLotID, 0 , sizeof(gLotInfo.szLotID));
			strcpy_s(gLotInfo.szLotID[0], gDProject.m_szLotId);
			strcpy_s(gLotInfo.szPrj[0], gDProject.m_szProjectName); 
		}
	}
	CDlgScheduleInfo dlg;
	dlg.SetOnlyDisplay(TRUE); 

	if( IDOK != dlg.DoModal() )
		return FALSE;

	gLotInfo.nLastIndex = dlg.m_nLastIndex;

	strcpy_s(gLotInfo.szLotID[0], dlg.m_strLotInfo);
	strcpy_s(gLotInfo.szLotID[1], dlg.m_strLotInfo2);
	strcpy_s(gLotInfo.szLotID[2], dlg.m_strLotInfo3);
	strcpy_s(gLotInfo.szLotID[3], dlg.m_strLotInfo4);
	strcpy_s(gLotInfo.szLotID[4], dlg.m_strLotInfo5);
	strcpy_s(gLotInfo.szLotID[5], dlg.m_strLotInfo6); 
	strcpy_s(gLotInfo.szLotID[6], dlg.m_strLotInfo7);
	strcpy_s(gLotInfo.szLotID[7], dlg.m_strLotInfo8);
	strcpy_s(gLotInfo.szLotID[8], dlg.m_strLotInfo9);
	strcpy_s(gLotInfo.szLotID[9], dlg.m_strLotInfo10);

	gLotInfo.nLotCount[0] = dlg.m_nNo;
	gLotInfo.nLotCount[1] = dlg.m_nNo2;
	gLotInfo.nLotCount[2] = dlg.m_nNo3;
	gLotInfo.nLotCount[3] = dlg.m_nNo4;
	gLotInfo.nLotCount[4] = dlg.m_nNo5;
	gLotInfo.nLotCount[5] = dlg.m_nNo6;
	gLotInfo.nLotCount[6] = dlg.m_nNo7;
	gLotInfo.nLotCount[7] = dlg.m_nNo8;
	gLotInfo.nLotCount[8] = dlg.m_nNo9;
	gLotInfo.nLotCount[9] = dlg.m_nNo10;

	gLotInfo.bMESOK[0] = dlg.m_bMes;
	gLotInfo.bMESOK[1] = dlg.m_bMes2;
	gLotInfo.bMESOK[2] = dlg.m_bMes3;
	gLotInfo.bMESOK[3] = dlg.m_bMes4;
	gLotInfo.bMESOK[4] = dlg.m_bMes5;
	gLotInfo.bMESOK[5] = dlg.m_bMes6;
	gLotInfo.bMESOK[6] = dlg.m_bMes7;
	gLotInfo.bMESOK[7] = dlg.m_bMes8;
	gLotInfo.bMESOK[8] = dlg.m_bMes9;
	gLotInfo.bMESOK[9] = dlg.m_bMes10;

	gLotInfo.bUseMES = dlg.m_bUseMES;

	strcpy_s(gLotInfo.szFilmNo[0], dlg.m_strFilmNo);
	strcpy_s(gLotInfo.szFilmNo[1], dlg.m_strFilmNo2);
	strcpy_s(gLotInfo.szFilmNo[2], dlg.m_strFilmNo3);
	strcpy_s(gLotInfo.szFilmNo[3], dlg.m_strFilmNo4);
	strcpy_s(gLotInfo.szFilmNo[4], dlg.m_strFilmNo5);
	strcpy_s(gLotInfo.szFilmNo[5], dlg.m_strFilmNo6);
	strcpy_s(gLotInfo.szFilmNo[6], dlg.m_strFilmNo7);
	strcpy_s(gLotInfo.szFilmNo[7], dlg.m_strFilmNo8);
	strcpy_s(gLotInfo.szFilmNo[8], dlg.m_strFilmNo9);
	strcpy_s(gLotInfo.szFilmNo[9], dlg.m_strFilmNo10);

	strcpy_s(gLotInfo.szProcessCode[0], dlg.m_strProcessCode);
	strcpy_s(gLotInfo.szProcessCode[1], dlg.m_strProcessCode2);
	strcpy_s(gLotInfo.szProcessCode[2], dlg.m_strProcessCode3);
	strcpy_s(gLotInfo.szProcessCode[3], dlg.m_strProcessCode4);
	strcpy_s(gLotInfo.szProcessCode[4], dlg.m_strProcessCode5);
	strcpy_s(gLotInfo.szProcessCode[5], dlg.m_strProcessCode6);
	strcpy_s(gLotInfo.szProcessCode[6], dlg.m_strProcessCode7);
	strcpy_s(gLotInfo.szProcessCode[7], dlg.m_strProcessCode8);
	strcpy_s(gLotInfo.szProcessCode[8], dlg.m_strProcessCode9);
	strcpy_s(gLotInfo.szProcessCode[9], dlg.m_strProcessCode10);

	strcpy_s(gLotInfo.szPrj[0], dlg.m_strPrj1);
	strcpy_s(gLotInfo.szPrj[1], dlg.m_strPrj2);
	strcpy_s(gLotInfo.szPrj[2], dlg.m_strPrj3);
	strcpy_s(gLotInfo.szPrj[3], dlg.m_strPrj4);
	strcpy_s(gLotInfo.szPrj[4], dlg.m_strPrj5);
	strcpy_s(gLotInfo.szPrj[5], dlg.m_strPrj6);
	strcpy_s(gLotInfo.szPrj[6], dlg.m_strPrj7);
	strcpy_s(gLotInfo.szPrj[7], dlg.m_strPrj8);
	strcpy_s(gLotInfo.szPrj[8], dlg.m_strPrj9);
	strcpy_s(gLotInfo.szPrj[9], dlg.m_strPrj10);

	gLotInfo.nFireType[0] = dlg.m_nFireType;
	gLotInfo.nFireType[1] = dlg.m_nFireType2;
	gLotInfo.nFireType[2] = dlg.m_nFireType3;
	gLotInfo.nFireType[3] = dlg.m_nFireType4;
	gLotInfo.nFireType[4] = dlg.m_nFireType5;
	gLotInfo.nFireType[5] = dlg.m_nFireType6;
	gLotInfo.nFireType[6] = dlg.m_nFireType7;
	gLotInfo.nFireType[7] = dlg.m_nFireType8;
	gLotInfo.nFireType[8] = dlg.m_nFireType9;
	gLotInfo.nFireType[9] = dlg.m_nFireType10;


	CString strMsg, strErr, strTemp;
	int nLen;
	for(int k = 0; k< gLotInfo.nLastIndex; k++)
	{
		nLen = 	strlen(gLotInfo.szLotID[k]);
		if(nLen <= 0)
			continue;

		strTemp.Format(_T("#%d : %s\t %d\t %s|"), k+1, gLotInfo.szLotID[k], gLotInfo.nLotCount[k], gLotInfo.szPrj[k]);
		strErr += strTemp;
	}
	strMsg.Format(_T("Lot 정보 입력"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM> (&strMsg), reinterpret_cast<WPARAM>(&strErr) );	

	m_nInputLot = dlg.m_nNo + dlg.m_nNo2 + dlg.m_nNo3 + dlg.m_nNo4 + dlg.m_nNo5 + dlg.m_nNo6 + dlg.m_nNo7 + dlg.m_nNo8 + dlg.m_nNo9 + dlg.m_nNo10;

	CString strData;
	strData.Format(_T("%d PNL"), m_nInputLot);
	m_btnLotInput.SetWindowText( (LPCTSTR)strData );

	int nIndex;
	CString str;
	if(gLotInfo.bUseMES)
	{
#ifndef __NO_USE_OPC__
		nIndex = GetCurrentLotID(str, str, str, str);

		if(!gLotInfo.bMESOK[nIndex])
		{
			str.Format(_T(" Check MES (LotID : %s) before start"), gLotInfo.szLotID[nIndex]);
			ErrMessage(str);
			return FALSE;
		}
		if(nIndex % 2 == 0)
		{
			if(gLotInfo.nComSol[nIndex] == 2)
			{
				if(!gLotInfo.bMESOK[nIndex + 1])
				{
					str.Format(_T(" Check MES (LotID : %s) before start"), gLotInfo.szLotID[nIndex + 1]);
					ErrMessage(str);
					return FALSE;
				}
			}
		}
#endif
	}

	if(!AutoOpenProject(FALSE))
	{
		nIndex = GetCurrentLotID(str, str, str, str);

		if(nIndex >= gLotInfo.nLastIndex)
		{
			ErrMsgDlg(STDGNALM212);
			return FALSE;
		}
		else
		{
			ErrMsgDlg(STDGNALM103);
			return FALSE;
		}
	}
	if(gLotInfo.bUseMES && !gLotInfo.bMESOK[m_nCurrentPrjIndex])
	{
		strMsg.Format(_T("Lot ID : %s\nPlease Check MES"), gLotInfo.szLotID[m_nCurrentPrjIndex]);
		ErrMessage(strMsg);
		return FALSE;
	}
#endif
	return TRUE;
}

BOOL CPaneAutoRun::CheckSystemForDrill()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	// drillsignal check
	if(IsDrilling())
	{
		ErrMsgDlg(STDGNALM202);
		return FALSE;
	}

#ifndef __TEST__
	if(!m_bInit)
	{
		ErrMsgDlg(STDGNALM401);
		return FALSE;
	}
#endif
	if(m_pCheckDrillThread != NULL)
	{
		ErrMsgDlg(STDGNALM202);
		return FALSE;
	}

	// mode check
	if(pMotor->GetCurrentMode() == MODE_MPG || pMotor->GetCurrentMode() == MODE_OFF ||pMotor->GetCurrentMode() == MODE_HOME)
	{
		ErrMsgDlg(STDGNALM209);
		return FALSE;
	}

	if(pMotor->IsSafetyMode())
	{
		ErrMsgDlg(STDGNALM207);
		return FALSE;
	}
//	if(!gProcessINI.m_sProcessSystem.bUseScheduling) 20131001
	{
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->GetFileOpen()) 
		{
			ErrMsgDlg(STDGNALM103);
			return FALSE;
		}

// 쿤산 기능 추가
	if( ( gDProject.m_nSeparation == USE_DUAL && ( (gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_1ST) == 0 || (gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_2ND) == 0) ) ||
		( gDProject.m_nSeparation == USE_1ST && (gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_1ST) == 0 ) ||
		( gDProject.m_nSeparation == USE_2ND && (gSystemINI.m_sHardWare.nUseEocardAxis & EO_USE_2ND) == 0 ) )
	{
		ErrMessage(_T("Mis-match between Recipe->Layout->Use PNL Info. and Scanner use Info[system.ini]."));
		return FALSE;
	}


		// project step check : set fid origin
		if(!(gDProject.m_nDataLoadStep & SET_FID_ORIGIN) || (gDProject.m_nDataLoadStep & 0x0b) < FIELD_DIVIED) //20091029
		{
			ErrMsgDlg(STDGNALM703); // 20091029 message 내용 변경해야 함.
			return FALSE; 
		}

	}
	if(!gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		if(m_nUserLevel == 0)
		{
			if(pMotor->GetBasketIn() != 0x00)  // 0 이면 바스켓이 모두 있는 상태
			{
				ErrMsgDlg(STDGNALM1148);
				return FALSE;
			}
		}
#ifdef __KUNSAN_SAMSUNG_LARGE__
		CString str, strString;
		if( (GetCurrentLotID(str, str, str, str) % 2 == 1 && pMotor->GetReverseDirection()) ||
			(GetCurrentLotID(str, str, str, str) % 2 == 0 && !pMotor->GetReverseDirection()) )// 처음 순방향 , 돌아오는 lot 역방향인 정상적인 경우
		{
			if(pMotor->GetReverseDirection())
			{
				m_pOPC->SetStartDirectionInfo(TRUE);
			}
			else
				m_pOPC->SetStartDirectionInfo(FALSE);
		}
		else
		{
			if(gProcessINI.m_sProcessSystem.bUseScheduling)
			{
				ErrMsgDlg(STDGNALM1161);
				return FALSE;
			}
			if(pMotor->GetReverseDirection())
			{
				if(IDYES != ErrMessage(_T("Direction is Reverse\nAre you run this status?"), MB_YESNO))
					return FALSE;
				strString.Format(_T("User select Reverse-direction."));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strString));
				m_pOPC->SetStartDirectionInfo(TRUE);
			}
			else
			{
				m_pOPC->SetStartDirectionInfo(FALSE);
			}
		}
#endif
	}


	if(!gProcessINI.m_sProcessSystem.bDryRun) 
	{
		// laser check
		if(!gDeviceFactory.GetLaser()->IsPowerOn()	|| !gDeviceFactory.GetLaser()->IsShutterOpen() ||
		   !m_pMotor->GetAOMStatus()				|| !m_pMotor->GetScannerStatus() ) // LaserPower
		{
			
			ErrMsgDlg(STDGNALM303);
			return FALSE;
		}
		
		if(gSystemINI.m_sHardWare.bUseLPC)
		{
			if(!gDeviceFactory.GetMotor()->GetLPCStatus())
			{
				ErrMsgDlg(STDGNALM314);
				return FALSE;
			}
		}
		if(gProcessINI.m_sProcessSystem.bNoUsePrework && m_nUserLevel != 3)
		{
			// calibration time check 
			if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->CheckCalibrationTime()) // calibration time check
			{
				ErrMsgDlg(STDGNALM714);
				return FALSE;
			}

			// Power check
			if(gEasyDrillerINI.m_clsHwOption.GetUsePowerMeasure() && !((CEasyDrillerDlg*)::AfxGetMainWnd())->CheckPowerMeasureTime())
			{
				ErrMsgDlg(STDGNALM706);
				return FALSE;
			}

			// Laser Preheat check
			if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->CheckLaserPreheatTime())
			{
				ErrMsgDlg(STDGNALM705);
				return FALSE;
			}
		}
	}

	if(!m_bAutoRun && !gProcessINI.m_sProcessSystem.bNoUseSuction)
	{
		// suctiogn check
		if(!SuctionCheck())
		{
			ErrMsgDlg(STDGNALM423);
			return FALSE;
		}

#ifndef __NO_USE_OPC__
		BOOL bSuction1 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x01;
		BOOL bSuction2 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x02;
		//change status 
		CString strOPCTag;
		int nIndex;
		if(bSuction1)
			strOPCTag.Format(_T("1"));
		else
			strOPCTag.Format(_T("0"));
		nIndex = 111; // S_001_000000_01;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		if(bSuction2)
			strOPCTag.Format(_T("1"));
		else
			strOPCTag.Format(_T("0"));
		nIndex = 112; // S_002_000000_01;
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
	
#endif

	}
	return TRUE;
}

BOOL CPaneAutoRun::GetLotInformAndCheckValid()
{
	if(!GetLotInform())
		return FALSE;
	
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		if(gDProject.m_szLotId[0] == NULL)
		{
			CDlgBarcodeInfo dlgLotId;
			if(IDOK != dlgLotId.DoModal())
				return FALSE;
			strcpy_s(gDProject.m_szLotId, dlgLotId.m_strLotInfo);
		}
	}
	else
	{	
		CString strLot1, strLot2, strPrj1, strPrj2, strMessage;
		GetCurrentLotID(strLot1, strLot2, strPrj1, strPrj2);
		strcpy_s(gDProject.m_szLotId, strLot1);
	}
	ChangeLotIDInfo();
	
	if(gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		// 20131001
		if(!GetCurrentLotIndex())
		{
			ErrMsgDlg(STDGNALM1160);
			return FALSE;
		}
	}
	
	m_nAutoStartLotIndex = m_nCurrentLotIndex;
	// lot count
	if(m_nCurrentLotCount >= m_nInputLot - m_nNGLotCount)
	{
		ErrMsgDlg(STDGNALM212);
		return FALSE;

	}

	if(!gProcessINI.m_sProcessSystem.bUseScheduling)	//20130513 bskim Scheduling 사용하면서 프로젝트 열지 않고 Drillstart 하면 홀 정보가 없어 죽음
	{
		int nBeamPath = GetFirstBeamPath();
		gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNoForMotor = nBeamPath;
	}

	return TRUE;
}

BOOL CPaneAutoRun::InitSystemForDrill()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	pMotor->SendLoadCartNoPCB();	//No Cart PCB 신호 확인 받았음을 알림 20120918 bskim
	CString strString;
	// table pos check
	double dUnloadX = gProcessINI.m_sProcessAutoSetting.dUnloadPosX;
	double dUnloadY = gProcessINI.m_sProcessAutoSetting.dUnloadPosY;
	double dPosX, dPosY;
	pMotor->GetPosition(AXIS_X, dPosX);
	pMotor->GetPosition(AXIS_Y, dPosY);

#ifndef __KUNSAN_SAMSUNG_LARGE__
	if(fabs(dUnloadX - dPosX) <= 2.0 && fabs(dUnloadY - dPosY) <= 2.0)
	{
		
		strString.LoadString(IDS_PCB_CHECK);
		if(IDNO == ErrMessage(strString, MB_YESNO))
			return FALSE;
	
		strString.Format(_T("User started firing : There is the PCB board on the table."));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strString));
	}	
#endif

	if(gProcessINI.m_sProcessSystem.bDryRun)
	{
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE)) // 090805 shutter close
		{
			ErrMsgDlg(STDGNALM417); // shutter sensor error
			return FALSE;
		}
	}

	// Drill process
	pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, FALSE);
	pMotor->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, FALSE);
	pMotor->SetTowerLampBuzzer(TOWER_YELLOW, FALSE);
	pMotor->IonizerOn(TRUE);
	pMotor->DustSuctionControl(FALSE, TRUE);
	pMotor->HoodOpen(TRUE);

	pMotor->SetUsePaperBox(!gProcessINI.m_sProcessSystem.bNoUsePaper);
	pMotor->SetUseNGBox(!gProcessINI.m_sProcessSystem.bNoUseNGBox);
	
	NGBoxCheck(0);
	BOOL b1st, b2nd;
	int nVal = pMotor->GetCurrentSuction();
	b1st = nVal & 0x01;
	b2nd = nVal & 0x02;
	if(!pMotor->SetTablePCBExist(b1st, b2nd))
	{
		ErrMsgDlg(STDGNALM993);
		return FALSE;
	}
	if(!pMotor->IsHoodOK(TRUE))
	{
		ErrMsgDlg(STDGNALM769);
		return FALSE;
	}
	if(m_bAutoRun == TRUE && !gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		if(!pMotor->IsStartMode())
		{
			ErrMsgDlg(STDGNALM1152);
			return FALSE;
		}
	}

	HEocard* pEoCard = gDeviceFactory.GetEocard();

#ifdef __USE_DUALBAND_EOCARD__
	if(pEoCard->IsScannerCableError() || pEoCard->IsMotorFault() || pEoCard->IsDrillTimeOut())
	{
		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, DO_SCANNER);
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (PaneAutoRun::InitSystemForDrill) : S"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		CString strMsg;
		strMsg.Format(_T("Scanner Fault or Time out Error. Please Trun Off and Trun On Scanner Power. retry Scanner Calibration"));
		ErrMessage(strMsg);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		return FALSE;
	}
#endif

	if(!pEoCard->DownloadShotDrillScannerParam())
	{
		ErrMessage(_T("Download ShotDrill Scanner Param Error"));
		return FALSE;
	}

#ifdef __KUNSAN_8__
	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
	{
		if(!pEoCard->DummyParamSet(gDProject.m_nDummyFreeType))
		{
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("Dump Parameter Set Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			ErrMessage(_T("Error : Dummy shot parameter download Failure"));
			return FALSE;
		}
	}
#endif	
#ifndef __3RDAOD__
	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
	{
		m_pLineDummyTime.StartTime();
		if(m_bUserDummyOn)
		{
			if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
			{
				ErrMsgDlg(STDGNALM781);
				return FALSE;
			}
		}
		
		if(!gDeviceFactory.GetEocard()->StartMarkDummy())
		{
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("StartMarkDummy Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			m_pLineDummyTime.Finish();
			ErrMsgDlg(STDGNALM445);
			return FALSE;
		}
	}
	else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
	{
		if(!gSystemINI.m_sHardWare.nUseFirstOrder)
			m_bUserDummyOn = FALSE;
		else
		{
			double dDummyTime;
			if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
				dDummyTime= gSystemINI.m_sSystemDump.nStandbyTime;
			else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
				dDummyTime = gSystemINI.m_sSystemDump.nStandbyTime2;
			
			m_bUseManualDrillDummy = FALSE;

			if(gSystemINI.m_sSystemDump.n3RDDummyType != DUMMY_3RD_NO_USE)
			{
				if(m_bAutoRun || m_nUserLevel == 0)
				{
					if(!gDeviceFactory.GetEocard()->IsStannbyShotRun())
					{
						if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
						{
							ErrMsgDlg(STDGNALM781);
							return FALSE;
						}
					}
					Sleep(10);
					m_bUserDummyOn = gDeviceFactory.GetEocard()->IsStannbyShotRun();
					m_bUseManualDrillDummy = TRUE;
				}
				else
				{
					int nRes = ErrMessage(_T("Do you want to fire Dummy Free Shot?"),MB_YESNOCANCEL);
					if(IDYES == nRes)
					{
						if(!gDeviceFactory.GetEocard()->IsStannbyShotRun())
						{
							if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
							{
								ErrMsgDlg(STDGNALM781);
								return FALSE;
							}
						}
						Sleep(10);
						m_bUserDummyOn = gDeviceFactory.GetEocard()->IsStannbyShotRun();
						m_bUseManualDrillDummy = TRUE;
					}
					else if(nRes == IDNO)
					{
						m_bUseManualDrillDummy = FALSE;
					}
					else if(nRes == IDCANCEL)
					{	
						return FALSE;
					}
				}
			}
		}
	}
#endif
	if(!gProcessINI.m_sProcessSystem.bDryRun)
		gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, TRUE);

	if(!gDeviceFactory.GetEocard()->CheckLaserDutyLimit())
	{
		ErrMessage(_T("Laser Duty Limit Over. Please check."));
		return FALSE;
	}

	return TRUE;
}

void CPaneAutoRun::InitVariableForDrill()
{
	m_bChangePanelInfo = FALSE;
	m_bEocardEstopAtOnceForDrillstop = FALSE;
	m_bUserStop = FALSE;
	m_cDownASC[0] = NULL;
	m_bAlreadyLoading = FALSE;

	m_bUserDummyOn = gDeviceFactory.GetEocard()->IsStannbyShotRun();
	
	ResetScannerErrorCnt();
	m_bPostPreWorkDoing = FALSE;
	
	for(int i = 0; i<MAX_CAMERA; i++) // ROI 전체영역으로 설정
	{
		this->SendMessage(UM_VISION_ROI_SET, -1, i);
	}
	m_bLPCStartField = TRUE;
	m_bLPCDontGetYet = FALSE;
	m_pLPCAreaInfo = NULL;
	m_nNGBoxCondition = 0;
	m_dPower = GetAvgPower();

	int nLSB = 65535 / 8; // 9 by 9
	m_2DTrans1stForTempCompen.SetNumPoint(4);
	m_2DTrans1stForTempCompen.SetReferencePoint(nLSB, nLSB, 0);
	m_2DTrans1stForTempCompen.SetTransformedPoint(nLSB, nLSB, 0);
	m_2DTrans1stForTempCompen.SetReferencePoint(nLSB, 65535 - nLSB, 1);
	m_2DTrans1stForTempCompen.SetTransformedPoint(nLSB, 65535 - nLSB, 1);
	m_2DTrans1stForTempCompen.SetReferencePoint(65535 - nLSB, nLSB, 2);
	m_2DTrans1stForTempCompen.SetTransformedPoint(65535 - nLSB, nLSB, 2);
	m_2DTrans1stForTempCompen.SetReferencePoint(65535 - nLSB, 65535 - nLSB, 3);
	m_2DTrans1stForTempCompen.SetTransformedPoint(65535 - nLSB, 65535 - nLSB, 3);
	m_2DTrans1stForTempCompen.Transform();

	m_2DTrans2ndForTempCompen.SetNumPoint(4);
	m_2DTrans2ndForTempCompen.SetReferencePoint(nLSB, nLSB, 0);
	m_2DTrans2ndForTempCompen.SetTransformedPoint(nLSB, nLSB, 0);
	m_2DTrans2ndForTempCompen.SetReferencePoint(nLSB, 65535 - nLSB, 1);
	m_2DTrans2ndForTempCompen.SetTransformedPoint(nLSB, 65535 - nLSB, 1);
	m_2DTrans2ndForTempCompen.SetReferencePoint(65535 - nLSB, nLSB, 2);
	m_2DTrans2ndForTempCompen.SetTransformedPoint(65535 - nLSB, nLSB, 2);
	m_2DTrans2ndForTempCompen.SetReferencePoint(65535 - nLSB, 65535 - nLSB, 3);
	m_2DTrans2ndForTempCompen.SetTransformedPoint(65535 - nLSB, 65535 - nLSB, 3);
	m_2DTrans2ndForTempCompen.Transform();

	m_nTempCompenCurrentLotCount = 0;
	m_nBackupSeparation = gDProject.m_nSeparation;
}	

void CPaneAutoRun::DrillStart()
{
	m_nPreworkStep = DO_NOTING;
	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, FALSE, TRUE);
#ifdef __KUNSAN_SAMSUNG_LARGE__
	m_pOPC->EnableControl(FALSE);
	gDeviceFactory.GetMotor()->SetNoUseSuction(!gProcessINI.m_sProcessSystem.bNoUseSuction);
#endif
	// resume check
	if(m_bDrillPause)
	{
		SendMessage(AUTO_MSG, FIREPAUSEE_TIME);
		m_bDrillPause = FALSE;
		::SetEvent(g_hDrill);
#ifdef __KUNSAN_SAMSUNG_LARGE__
		m_pOPC->EnableControl(FALSE);
#endif
		return;
	}
	
	InitVariableForDrill();
	

	// fail to start because of Temperature Compensation : 절대 drill stop이 호출되면 안된다.
	if(gProcessINI.m_sProcessOption.bTemperCompensationMode)
	{
		double d1stEndT = gDeviceFactory.Get1stTemperCompen()->GetAutoRunLastTemperature();
		double d2ndEndT = gDeviceFactory.Get2ndTemperCompen()->GetAutoRunLastTemperature();
		double d1stTemper, d2ndTemper; // auto Start T set
		gDeviceFactory.GetMotor()->GetTCTemperature(d1stTemper, d2ndTemper);

		if(d1stTemper <= -999 || d2ndTemper <= -999)
		{
			ErrMessage(_T("Start Temperature is too high. Wait or AGC re-try."));
			gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, TRUE);
			::AfxGetMainWnd()->SendMessage(DRILL_STOP);
			gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, FALSE);
			return;
		}
	}
	// 
	
	// Input LotCount
	if(!GetLotInformAndCheckValid())
	{
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, TRUE);
		::AfxGetMainWnd()->SendMessage(DRILL_STOP);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, FALSE);
		return;
	}

	if(!CheckSystemForDrill())
	{
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, TRUE);
		::AfxGetMainWnd()->SendMessage(DRILL_STOP);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, FALSE);
		return;
	}

	if(!InitSystemForDrill())
	{
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, TRUE);
		::AfxGetMainWnd()->SendMessage(DRILL_STOP);
		gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, FALSE);
		return;
	}
	
	if(m_bAutoRun && !gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader && m_bNeedUnload)
	{
		CString strSequenceLog;
		int nResult = ErrMessage(_T("Unloading data bit is on. \nDo you want to unload first?"), MB_YESNO);
		if(nResult == IDNO)
		{

			m_bNeedUnload = FALSE;
			strSequenceLog.Format(_T("언로딩 정보 남음 - 사용자 언로딩하지 않음 선택"));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
		}
		else 
		{
			strSequenceLog.Format(_T("언로딩 정보 남음 - 사용자 언로딩 선택"));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
		}
	}

	// 가공이 들어간 경우에만 처리해야되는 변수들
	if(m_bAutoRun)
		gDProject.m_CurrentMode = AUTO_DRILL_MODE;
	else
		gDProject.m_CurrentMode = MANUAL_DRILL_MODE;
	WriteDrillParam();

	CString strFile, strLog;
	strFile.Format(_T("PreWork"));
	strLog.Format(_T("Drillstart : no use prework : %d"), gProcessINI.m_sProcessSystem.bNoUsePrework);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	
#ifndef __NO_USE_OPC__
	::AfxGetMainWnd()->SendMessage(UM_SET_CURRENT_LOTID, NULL, NULL);
	CString strLaserPower1;
	CString strLaserPower2;
//	strLaserPower1.Format("%s;%.3f", gDProject.m_strFirstLotID, ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pPowerMeasurement->m_dMasterAvrPower);
//	strLaserPower2.Format("%s;%.3f", gDProject.m_strSecondLotID, ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pPowerMeasurement->m_dSlaveAvrPower);
	
	if(gDProject.m_nSeparation == USE_DUAL)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 828, reinterpret_cast<LPARAM>(&strLaserPower1)); //828 Head 1 Laser Power
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 829, reinterpret_cast<LPARAM>(&strLaserPower2)); //829 Head 2 Laser Power
	}
	else if(gDProject.m_nSeparation == USE_1ST)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 828, reinterpret_cast<LPARAM>(&strLaserPower1)); //828 Head 1 Laser Power
	}
	else 
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, 829, reinterpret_cast<LPARAM>(&strLaserPower2)); //829 Head 2 Laser Power
	}
#endif

	m_pCheckDrillThread = ::AfxBeginThread(DrillThread, this, THREAD_PRIORITY_NORMAL);
}

void CPaneAutoRun::DrillOneCycle()
{
	m_bUserStop = FALSE;
	m_bOneCycleStop = TRUE;
}

void CPaneAutoRun::DrillPause()
{
	SendMessage(AUTO_MSG, FIREPAUSES_TIME);
	m_bDrillPause = TRUE;
	m_bUserStop = FALSE;
}

void CPaneAutoRun::WaitEocardIdleForDrillStop()
{
#ifdef __LPC_FOR_3RD_AOD__
	if(m_bLPCDontGetYet)
	{
		m_nCurrentLotCount--;
		if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
			m_nCurrentLotCount--;

		GetLPCDataAndSave(m_pLPCAreaInfo, FALSE, m_nLPCSubToolNo);

		m_nCurrentLotCount++;
		if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
			m_nCurrentLotCount++;
	}
	m_bLPCDontGetYet = FALSE;
#endif

	if(gSystemINI.m_sSystemDevice.nEStop != 1 && m_bEocardEstopAtOnceForDrillstop == FALSE)
	{
		CCorrectTime pTimer;
		pTimer.StartTime();
		double dSecond;
		BOOL bBusy = TRUE;
		while(bBusy)
		{
			bBusy = gDeviceFactory.GetEocard()->IsDSPBusy();
			dSecond = pTimer.PresentTime();
			if(dSecond > 40)
			{
				gDeviceFactory.GetEocard()->EStop();
				::Sleep(1);
				gDeviceFactory.GetEocard()->EStop();
				
#ifndef __MP920_MOTOR__
				m_pMotor->SetOutPort(PORT_ALARM, 1);	
#else
				m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);	
#endif
				
				ErrMessage(_T("Fire Time is overed 40 sec"));
				
#ifndef __MP920_MOTOR__
				m_pMotor->SetOutPort(PORT_ALARM, 0);	
#else
				m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);	
#endif
			}
			BOOL bScannerCableError = gDeviceFactory.GetEocard()->IsScannerCableError();
			BOOL bScannerMotorFault = gDeviceFactory.GetEocard()->IsMotorFault();
			BOOL bScannerDrillTimeOut = gDeviceFactory.GetEocard()->IsDrillTimeOut();
			BOOL bTimeOutType = gDeviceFactory.GetEocard()->IsDrillTimeOutType();

			if(bScannerCableError)
			{
				break;
			}
			else if(bScannerMotorFault)
			{
				break;
			}
			else if(bScannerDrillTimeOut)
			{
				break;
			}
			else if(bTimeOutType)
			{
				break;
			}
		}

//		gDeviceFactory.GetEocard()->EStop();
//		::Sleep(1);
//		gDeviceFactory.GetEocard()->EStop();
	}
	else
	{
		gDeviceFactory.GetEocard()->EStop();
		m_bEocardEstopAtOnceForDrillstop = FALSE;
	}
}

void CPaneAutoRun::InitVariableForDrillStop()
{
	m_nDrillEndTime = 0;
	m_bOdd = FALSE;
	m_bUserStop = TRUE;
	m_bOneCycleStop = FALSE;
	m_bOneCycleStopNoUnloadPause = FALSE;
	m_bDrillPause = FALSE;
	::SetEvent(g_hDrill);
	m_pStepTime.Finish();
	gDProject.m_nSeparation = m_nBackupSeparation;
	if(m_bAutoRun)
	{
		OnAutoStartSetting(FIREEND_TIME, NULL);
		ProgressInitial();
	}

	::AfxGetMainWnd()->SendMessage(UM_CONTROL_TAB_ENABLE, TRUE, TRUE);
	::AfxGetMainWnd()->SendMessage(UM_DRAW_DOING_PREWORK, FALSE); //Doing Prework draw timer kill  
	::AfxGetMainWnd()->SendMessage(UM_CHANGE_PREWORK_STATUS, DO_NOTING);
#ifdef __KUNSAN_SAMSUNG_LARGE__
	m_pOPC->EnableControl(TRUE);
#endif
}

void CPaneAutoRun::InitSystemForDrillStop()
{
	((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);// 20090629 Front Mode error
	
	gDeviceFactory.GetMotor()->SetTowerLampBuzzer(TOWER_RED, TRUE);
	gDeviceFactory.GetMotor()->IonizerOn(FALSE);
	gDeviceFactory.GetMotor()->DustSuctionControl(FALSE, FALSE);
	gDeviceFactory.GetMotor()->HandlerOperation(UI_DIRLL_STATUS_SET, FALSE);

	gDeviceFactory.GetMotor()->HandlerOperation(HANDLER_LOADER_ALIGN, FALSE);
	gDeviceFactory.GetMotor()->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
	gDeviceFactory.GetMotor()->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);


	if(gSystemINI.m_sSystemDevice.bUseHoodAutoMode)
		gDeviceFactory.GetMotor()->HoodOpen(FALSE);
	
#ifndef __MP920_MOTOR__
	if(m_bAutoRun && !gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		gDeviceFactory.GetMotor()->MainStop(TRUE);
		gDeviceFactory.GetMotor()->MainReady(FALSE);
	}
#else
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0, TRUE);
	gDeviceFactory.GetMotor()->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_DRILL_START, 0, TRUE);
#endif

	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_SIGNAL, FALSE);

	if(gSystemINI.m_sHardWare.bUseWideMonitor)
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);

	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
	{
		if(!gDeviceFactory.GetEocard()->EndMarkDummy())
		{
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("Drillstop : EndMarkDummy Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			m_pLineDummyTime.Finish();
		}
	}
	else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && !gSystemINI.m_sHardWare.nUseFirstOrder)
	{
		::Sleep(100);
		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
		{
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("Drillstop : Standby Shot stop Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		}
		m_StandbyTime.Finish();
	}

	if(gDeviceFactory.GetLaser()->IsPowerOn() && !gProcessINI.m_sProcessSystem.bDryRun)
	{
		if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn )
		{
			gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE);  
		}
	}
	
#ifdef __3RDAOD__
	if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
	{
		CString strFile, strLog;
		strFile.Format(_T("ReadHole"));
		strLog.Format(_T("Drillstop : Standby Shot stop Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
	m_StandbyTime.Finish();
#endif
	m_pCheckDrillThread = NULL;
}

void CPaneAutoRun::SaveDrillDataForDrillStop()
{
	{
		CString strLog;
		strLog.Format(_T("LotID Marking Start No : %d, Marking PCB Count : %d"), m_nLotMarkStartNo, m_nLotMarkCurrent);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));
	}
	m_nLotMarkCurrent = 0;

	MoveScaleLog();

	if(gProcessINI.m_sProcessSystem.bUseSaveFidImage)
		ChangeBMPtoJPG();
	RemoveOldFidImage();
	

#ifndef __KUNSAN_1__
	if(m_nWarningNo[0] || m_nWarningNo[1] || m_nWarningNo[2] || m_nWarningNo[3] || m_nInposMissNo[0] > 100 || m_nInposMissNo[1] > 100)
	{
		CString strFile, strLog;
		strFile.Format(_T("ScannerPosError"));
		strLog.Format(_T("Warning Cnt : 1st X = %d (Max : %d), 1st Y = %d (Max : %d), 2nd X = %d (Max : %d), 2nd Y = %d (Max : %d), InposMiss 1 = %d, InposMiss 2 = %d"),
			m_nWarningNo[0], m_nMaxValue[0], m_nWarningNo[1], m_nMaxValue[1],
			m_nWarningNo[2], m_nMaxValue[2], m_nWarningNo[3], m_nMaxValue[3],
			m_nInposMissNo[0], m_nInposMissNo[1]);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		ErrMessage(_T("Scanner Movement is not normal. Plese check Scanner."));
	}
#endif


}

void CPaneAutoRun::DrillStop()
{
	InitVariableForDrillStop();

	WaitEocardIdleForDrillStop();

	InitSystemForDrillStop();
	
	SaveDrillDataForDrillStop();
}

void CPaneAutoRun::SetUserStop(BOOL bStop)
{
	m_bUserStop = bStop;
}

BOOL CPaneAutoRun::CheckStatus()
{
	if(m_bUserStop || m_bEStop)
	{
		m_nErrMsgID = STDGNALM803;
		return FALSE;
	}

	if(m_bDrillPause)
	{
		::WaitForSingleObject(g_hDrill, INFINITE);
		::ResetEvent(g_hDrill);
	}
	return TRUE;
}

BOOL CPaneAutoRun::SuctionCheck(BOOL bWait)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	BOOL b1st = TRUE, b2nd = TRUE;
	int nCnt = 0;
	int nSuction1;
	BOOL bMotor;
	BOOL bRet = FALSE;

	do{	
		bMotor = pMotor->GetCurrentSuctionMotor();
		if(!bMotor)
			break;

		nSuction1 = pMotor->GetCurrentSuction();

		if(nSuction1 & 0x01)
			b1st = TRUE;
		else
			b1st = FALSE;

		if(nSuction1 & 0x02)
			b2nd = TRUE;
		else
			b2nd = FALSE;


		if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
		{
			if(b1st && b2nd)
				bRet = TRUE;
			else
				bRet = FALSE;
		}
		else if(gDProject.m_nSeparation == USE_1ST || gDProject.m_nSeparation == USE_DUAL && m_bOdd)
		{
			if(b1st)
				bRet = TRUE;
			else
				bRet = FALSE;
		}
		else
		{
			if(b2nd)
				bRet = TRUE;
			else
				bRet = FALSE;
		}

		if(bWait)
		{
			nCnt++;
			if(nCnt > 70)
				break;
		}
		else
			return bRet;

		if(bRet)
			return TRUE;

		::Sleep(100);

	} while(!bRet);

	return bRet;
}

BOOL CPaneAutoRun::DownloadFirstToolMotorPos(DAreaInfo* pAreaInfoOld, DAreaInfo *pAreaInfo, BOOL bSkive)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	double dX, dY, dC1, dC2; 
	int nTool;
	if(bSkive)
		nTool = ADDED_FID_TOOL;
	else
	{
		if(m_bAutoRun)
			nTool = pAreaInfo->GetFirstToolNo(FALSE, TRUE);
		else
			nTool = pAreaInfo->GetFirstToolNo(m_bSelectFire, FALSE); // select, visible, or 전체가공 등 고려하여
	}
	
	if(nTool == -1)
	{
		m_nErrMsgID = STDGNALM758;
		return FALSE;
	}

	BOOL b1stPanel = TRUE;

	if(gDProject.m_nSeparation == USE_2ND)
		b1stPanel = FALSE;

	dX = pAreaInfo->m_nTableX / 1000.0 + pAreaInfo->m_dTableOffsetX;
	dY = pAreaInfo->m_nTableY / 1000.0 + pAreaInfo->m_dTableOffsetY;
	SUBTOOLDATA subTool;
	POSITION pos = gDProject.m_pToolCode[nTool]->m_SubToolData.GetHeadPosition();
	if(pos)
		subTool = gDProject.m_pToolCode[nTool]->m_SubToolData.GetNext(pos);
	else
	{
		m_nErrMsgID = STDGNALM758;
		return FALSE;
	}
	BOOL bTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[subTool.nMask];
	if(!pMotor->MoveTophatShutter(bTophat))
	{
	//	ErrMessage(_T("Tophat shutter move error!"));
		m_nErrMsgID = STDGNALM568;
		return FALSE;
	}
	BOOL bLaserPath = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[subTool.nMask];
	if(!pMotor->MoveLaserBeamPath(bLaserPath))
	{
		m_nErrMsgID = STDGNALM974;
		return FALSE;
	}

	double dLaserHeight1, dLaserHeight2;
	double dA1, dA2;

	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		// Mask별 Z축 이동
		dLaserHeight1 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[subTool.nMask];
		dLaserHeight2 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[subTool.nMask];

		double dHeight1 = dLaserHeight1 - gDProject.m_dPcbThick;
		double dHeight2 = dLaserHeight2 - gDProject.m_dPcbThick2; 

		if(!pMotor->MotorMoveXYZDownOnly(dX, dY, dHeight1, dHeight2, b1stPanel, AUTORUN_MOVE, FALSE))
		{
			m_nErrMsgID = STDGNALM438;
			return FALSE;
		}

		dC1 =  gBeamPathINI.m_sBeampath.dBeamPathBetPos1[subTool.nMask];
		dC2 =  gBeamPathINI.m_sBeampath.dBeamPathBetPos2[subTool.nMask];
		dA1 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[subTool.nMask];
		dA2 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[subTool.nMask];

		double dmask1, dmask2, dmask3;

		dmask1 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[subTool.nMask];
		dmask2 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[subTool.nMask];
		dmask3 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[subTool.nMask];
		if(m_nMask1Old != subTool.nMask)
		{
			//if(!pMotor->MoveMCA2DownOnly(subTool.nMask, subTool.nMask, dC1, dC2, dA1, dA2, bTophat))
#ifndef __SERVO_MOTOR__
			if(!pMotor->MoveMCA2DownOnly(dmask1, dmask2,  dC1, dC2, dA1, dA2, bTophat))		//20111213
#else
			if(!pMotor->MoveMCA3DownOnly(dmask1, dmask2, dmask3, dC1, dC2, dA1, dA2))
#endif
			{
				m_nErrMsgID = STDGNALM439;
				return FALSE;
			}
			m_nMask1Old = subTool.nMask;
			m_bMoveXYMC = TRUE;
			m_bCheckZMC = TRUE;
		}
		else
		{
			m_bMoveXYMC = FALSE;
		}

		if(strcmp(m_cDownASC, gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]) != 0)
		{
			CString strMaster, strSlave;
			TCHAR sz1stFile[255], sz2ndFile[255];
			strMaster.Format(_T("%s\\%sM1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
			strSlave.Format(_T("%s\\%sS1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
			lstrcpy(sz1stFile, strMaster);
			lstrcpy(sz2ndFile, strSlave);

			BOOL bIsDspBusy = TRUE;
			while(bIsDspBusy)
			{
				if(!CheckStatus())
				{
					if(gSystemINI.m_sSystemDevice.nEStop == 1)
						gDeviceFactory.GetEocard()->EStop();
					return FALSE;
				}
				
				BOOL bScannerCableError = gDeviceFactory.GetEocard()->IsScannerCableError();
				BOOL bScannerMotorFault = gDeviceFactory.GetEocard()->IsMotorFault();
				BOOL bScannerDrillTimeOut = gDeviceFactory.GetEocard()->IsDrillTimeOut();
				BOOL bTimeOutType = gDeviceFactory.GetEocard()->IsDrillTimeOutType();
				CString strErrorMsg = _T("");
				if(bScannerCableError)
				{
					if(gSystemINI.m_sSystemDevice.nEStop == 1)
						gDeviceFactory.GetEocard()->EStop();
					m_nErrMsgID = STDGNALM1017;
					m_strErrorPlus = _T("Scanner Cable Error.");
					return FALSE;
				}
				else if(bScannerMotorFault)
				{
					if(bScannerMotorFault & 0x01)
						strErrorMsg += _T("Scanner Master X Motor Fault\r\n");
					if(bScannerMotorFault & 0x02)
						strErrorMsg += _T("Scanner Master Y Motor Fault\r\n");
					if(bScannerMotorFault & 0x04)
						strErrorMsg += _T("Scanner Slave X Motor Fault\r\n");
					if(bScannerMotorFault & 0x08)
						strErrorMsg += _T("Scanner Slave Y Motor Fault\r\n");

					if(gSystemINI.m_sSystemDevice.nEStop == 1)
						gDeviceFactory.GetEocard()->EStop();
					m_nErrMsgID = STDGNALM1017;
					m_strErrorPlus = strErrorMsg;
					return FALSE;
				}
				else if(bScannerDrillTimeOut)
				{
					if(bScannerDrillTimeOut & 0x01)
						strErrorMsg += _T("Scanner Master X Drill Time Out\r\n");
					if(bScannerDrillTimeOut & 0x02)
						strErrorMsg += _T("Scanner Master Y Drill Time Out\r\n");
					if(bScannerDrillTimeOut & 0x04)
						strErrorMsg += _T("Scanner Slave X Drill Time Out\r\n");
					if(bScannerDrillTimeOut & 0x08)
						strErrorMsg += _T("Scanner Slave Y Drill Time Out\r\n");

					if(gSystemINI.m_sSystemDevice.nEStop == 1)
						gDeviceFactory.GetEocard()->EStop();
					m_nErrMsgID = STDGNALM1017;
					m_strErrorPlus = strErrorMsg;
					return FALSE;
				}
				else if(bTimeOutType)
				{
					if(bTimeOutType & 0x01)
						strErrorMsg += _T("Unknown Time Out\r\n");
					if(bTimeOutType & 0x02)
						strErrorMsg += _T("Drill Time Out\r\n");
					if(bTimeOutType & 0x04)
						strErrorMsg += _T("LPC Time Out\r\n");

					if(gSystemINI.m_sSystemDevice.nEStop == 1)
						gDeviceFactory.GetEocard()->EStop();

					m_strErrorPlus = strErrorMsg;

					return FALSE;
				}
//				if(gDeviceFactory.GetEocard()->IsMotorFault())
//				{
//					if(gSystemINI.m_sSystemDevice.nEStop == 1)
//						gDeviceFactory.GetEocard()->EStop();
//					m_nErrMsgID = STDGNALM567;
//					return FALSE;
//				}

				if(pAreaInfoOld)
				{
					int nMaxPos = gDeviceFactory.GetMotor()->ChangeMotorPosition(pAreaInfoOld->m_nTableX / 1000.0 + pAreaInfoOld->m_dTableOffsetX, \
							pAreaInfoOld->m_nTableY / 1000.0 + pAreaInfoOld->m_dTableOffsetY, b1stPanel);
					if(nMaxPos)
					{
						CString strMsg;
						strMsg.Format(_T("Table Shoot Error : %d"), nMaxPos);
						::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
						m_nErrMsgID = STDGNALM540;
						return FALSE;
					}
				}

				bIsDspBusy = gDeviceFactory.GetEocard()->IsDSPBusy();
			}
			if(!gDeviceFactory.GetEocard()->LoadCalibrationFile(sz1stFile, sz2ndFile))
			{
#ifndef __TEST__
				CString strString, strMsg;
				strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
				CString strTemp;
				strTemp.Format(_T("%s or %s"), sz1stFile, sz2ndFile);
				strMsg.Format(strString, strTemp);
				
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				m_nErrMsgID = STDGNALM105;
				return FALSE;
#endif
			}
			strcpy_s( m_cDownASC, gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
		}

	}
	else // not use M, C
	{
		if(bTophat)
		{
			dLaserHeight1 = gSystemINI.m_sSystemDevice.d1stLaserHeightTophat[0];
			dLaserHeight2 = gSystemINI.m_sSystemDevice.d2ndLaserHeightTophat[0];
		}
		else
		{
			dLaserHeight1 = gSystemINI.m_sSystemDevice.d1stLaserHeight[0];
			dLaserHeight2 = gSystemINI.m_sSystemDevice.d2ndLaserHeight[0];
		}
		
		double dHeight1 = dLaserHeight1 - gDProject.m_dPcbThick;
		double dHeight2 = dLaserHeight2 - gDProject.m_dPcbThick2; 
		if(!pMotor->MotorMoveXYZDownOnly(dX, dY, dHeight1 + subTool.dZOffset, dHeight2 +  subTool.dZOffset, b1stPanel, AUTORUN_MOVE))
		{
			m_nErrMsgID = STDGNALM438;
			return FALSE;
		}

		if(m_dPosC1Old != subTool.dA1 || m_dPosC2Old != subTool.dA2)
		{
			if(!pMotor->MoveMC2DownOnly(subTool.dA1, subTool.dA1, subTool.dA2, subTool.dA2))
			{
				m_nErrMsgID = STDGNALM543;
				return FALSE;
			}
			m_dPosC1Old = subTool.dA1;
			m_dPosC2Old = subTool.dA2;
			m_bMoveXYMC = TRUE;
		}
		else
		{
			m_bMoveXYMC = FALSE;
		}
	}
	
	WriteTablePosition(dX, dY, dLaserHeight1, dLaserHeight2);

	return TRUE;
}

BOOL CPaneAutoRun::MoveIO()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(m_bMoveXYMC)
		return pMotor->SetMoveIO(MOVE_XYMCA);
	else
		return pMotor->SetMoveIO(MOVE_XYZ);
}

BOOL CPaneAutoRun::DownloadFirstToolFireInformData(DAreaInfo *pAreaInfo, BOOL bSkive)
{
	int nTool;
	if(bSkive)
		nTool = ADDED_FID_TOOL;
	else
	{
		if(m_bAutoRun)
			nTool = pAreaInfo->GetFirstToolNo(FALSE, TRUE);
		else
			nTool = pAreaInfo->GetFirstToolNo(m_bSelectFire, FALSE);
	}
	if(nTool == -1)
	{
		m_nErrMsgID = STDGNALM758;
		return FALSE;
	}
//	gDProject.m_pToolCode[nTool]->DownLoadToolData();
	if(gDProject.m_pToolCode[nTool]->m_SubToolData.GetCount() <= 0)
	{
		m_nErrMsgID = STDGNALM758;
		return FALSE;
	}
	
	SUBTOOLDATA subTool;
	gDProject.GetSubTool(nTool, 0, subTool);
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		if(!gDeviceFactory.GetAttenuator()->MoveIndex(subTool.nMask))
		{
			m_nErrMsgID = STDGNALM542;
			return FALSE;
		}
		m_bCheckAPos = TRUE;
	}

	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
	{
		if(!gDeviceFactory.GetEocard()->EndMarkDummy())
		{
			m_nErrMsgID = STDGNALM445; // 
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("EndMarkDummy Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			m_pLineDummyTime.Finish();
			return FALSE;
		}
	}
	
	HEocard* pEocard = gDeviceFactory.GetEocard();
	if(!DownloadOneSubTool(gDProject.m_ToolSumInfo[nTool].nRealToolNo, 0)) // 20090825 same tool line drill 버그 수정
	{
		return FALSE;
	}

	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
	{
		if(!gDeviceFactory.GetEocard()->StartMarkDummy())
		{
			m_nErrMsgID = STDGNALM445; // count No error
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("StartMarkDummy Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			m_pLineDummyTime.Finish();
			return FALSE;
		}
	}

	// Laser current Set
	if(!DownloadLaserOneSubTool(nTool, 0))
	{
		m_nErrMsgID = STDGNALM444;
		return FALSE;
	}

/*	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		if(!gDeviceFactory.GetAttenuator()->IsInposition())
		{
			m_nErrMsgID = STDGNALM441;
			return FALSE;
		}
	}
*/	return TRUE;
}

BOOL CPaneAutoRun::InPositionCheck()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		// 110427 yhchung
		if(m_bMoveXYMC)
		{
			if(gSystemINI.m_sHardWare.nBeamType == HEAD1_BEAM1_LASER1)
				return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_M1 + IND_C1 + IND_A1);
			else
				return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_M2 + IND_C2 + IND_M3 + IND_A1 + IND_A2);
		}
		else
		{
			if(gSystemINI.m_sHardWare.nBeamType == HEAD1_BEAM1_LASER1)
				return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 );
			else
				return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 );
		}
	}
	else // not use M, C
	{
		// 110427 yhchung 
		if(m_bMoveXYMC)
		{
			if(gSystemINI.m_sHardWare.nBeamType == HEAD1_BEAM1_LASER1)
				return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_M1 + IND_C1);
			else
				return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1 );
		}
		else
		{
			if(gSystemINI.m_sHardWare.nBeamType == HEAD1_BEAM1_LASER1)
				return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 );
			else
				return pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2);
		}
	}
	return TRUE;
}

void CPaneAutoRun::GetFirePanelInfo(BOOL& b1stPanelFire, BOOL& b2ndPanelFire)
{
	if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
	{
		b1stPanelFire = b2ndPanelFire = TRUE;
	}
	else if(gDProject.m_nSeparation == USE_1ST || m_bOdd)
	{
		b1stPanelFire = TRUE;
		b2ndPanelFire = FALSE;
	}
	else
	{
		b1stPanelFire = FALSE;
		b2ndPanelFire = TRUE;
	}
}

void CPaneAutoRun::WriteFidOffsetData(LPFIREHOLE pHole, int nTableX, int nTableY)
{
	double dLaserMOffsetX, dLaserMOffsetY, dLaserSOffsetX, dLaserSOffsetY, dPanelOffsetX, dPanelOffsetY;
	gDeviceFactory.GetMotor()->GetAxisMoveOffset(nTableX/1000., nTableY/1000., dPanelOffsetX, dPanelOffsetY, DELTA_PANEL_OFFSET);
	gDeviceFactory.GetEocard()->GetLaserOffset(nTableX/1000., nTableY/1000., dLaserMOffsetX, dLaserMOffsetY, FIRST_PANEL_OFFSET);
	gDeviceFactory.GetEocard()->GetLaserOffset(nTableX/1000., nTableY/1000., dLaserSOffsetX, dLaserSOffsetY, SECOND_PANEL_OFFSET);
	dLaserMOffsetX = dLaserMOffsetX * 1000;
	dLaserMOffsetY = dLaserMOffsetY * 1000;
	dLaserSOffsetX = dLaserSOffsetX * 1000;
	dLaserSOffsetY = dLaserSOffsetY * 1000;
						
	CString strFile, strFidOffset;
	strFile.Format(_T("FidOffsetData"));
	strFidOffset.Format(_T("File(%d, %d), Table(%d, %d) : 1st LSB(%d, %d), 2nd LSB(%d, %d), TCal Off(%.3f, %.3f) Laser Off(%.0f, %.0f, %.0f, %.0f) fieldSize %.3f"), 
		pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y,
		nTableX, nTableY, pHole->npPos1.x, pHole->npPos1.y, pHole->npPos2.x, pHole->npPos2.y, dPanelOffsetX, dPanelOffsetY,
		dLaserMOffsetX, dLaserMOffsetY, dLaserSOffsetX, dLaserSOffsetY, gSystemINI.m_sSystemDevice.dFieldSize.x);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
}

void CPaneAutoRun::WriteTablePosition(double dX , double dY, double dZ1, double dZ2)
{
	CString strFile, strTablePosition;
	strFile.Format(_T("TableMoving"));
	strTablePosition.Format(_T("X : (%.3f), Y : (%.3f), Z1 : (%.3f), Z2 : (%.3f)"),dX, dY, dZ1, dZ2); 
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strTablePosition));
}


int CPaneAutoRun::DownloadBarcodeData(int nTool, CPoint ptMaster, CPoint ptSlave, BOOL b1stPanelFire, BOOL b2ndPanelFire)
{
	int nBarX1, nBarY1, nBarX2, nBarY2;
	SUBTOOLDATA	subTool;
	CDlgBarcodeInfo dlg;
	memset(m_c2DContents, NULL, 255);
//	if(IDOK == dlg.DoModal())
//	{
//		int nSize = dlg.m_strLotInfo.GetLength();
//		memcpy(m_c2DContents, dlg.m_strLotInfo, 255);
//	}

	C2DBarCode temp2DBarcode;
	CString str;
	str.Format(_T("%s"), m_c2DContents);
	if(!gDProject.GetSubTool(nTool, 0, subTool))
	{
		m_nErrMsgID = STDGNALM758;
		return FALSE;
	}
					
	int nBarHoleNo = temp2DBarcode.NewObject(subTool.bFlipX, subTool.bFlipY, 
							subTool.nRotate, // + d2DTransAngle1, 
							subTool.nRotate, // + d2DTransAngle2,
							gDProject.m_pToolCode[nTool]->m_nToolSize,
							(int)(gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0),
							str, dlg.m_nBarType);
	if(nBarHoleNo == FALSE)
	{
		m_nErrMsgID = STDGNALM660; // make barcode error;
		return FALSE;
	}

	int nFieldSizeUM = (int)(gSystemINI.m_sSystemDevice.dFieldSize.x*1000);
	int nMasterLSBX, nMasterLSBY, nSlaveLSBX, nSlaveLSBY;
	for(int j = 0; j < nBarHoleNo; j++)
	{
		if(!temp2DBarcode.GetNextPoint(nBarX1, nBarY1, nBarX2, nBarY2))
		{
			m_nErrMsgID = STDGNALM661; // get barcode data error;
			return FALSE;
		}

		 nMasterLSBX = ptMaster.x + nBarX1;
		 nMasterLSBY = ptMaster.y + nBarY1;
		 nSlaveLSBX = ptSlave.x + nBarX2;
		 nSlaveLSBY = ptSlave.y + nBarY2;
		if(gProcessINI.m_sProcessOption.bTemperCompensationMode)
		{
			SUBTOOLDATA subTool;
			if(!gDProject.GetSubTool(nTool, 0, subTool))
			{
				m_nErrMsgID = STDGNALM758;
				return FALSE;
			}
			if(b1stPanelFire)
			{
				if(!gDeviceFactory.Get1stTemperCompen()->GetCompenPosition(m_d1stTemper, gTempINI.m_sTempTime.dAutoScalTemperature[subTool.nMask][0], 
					gTempINI.m_sTempTime.dAutoScalEndTemperature[subTool.nMask][0],
					nMasterLSBX, nMasterLSBY, 
					nFieldSizeUM, gProcessINI.m_sProcessOption.dTemperMinTLimit, gProcessINI.m_sProcessOption.dTemperMaxTLimit, m_dPower	))
				{
					if(gDeviceFactory.Get1stTemperCompen()->GetIsSetRefT())
						m_nErrMsgID = STDGNALM1034;
					else
						m_nErrMsgID = STDGNALM1033;
					return FALSE;
				}
			}
			if(b2ndPanelFire)
			{
				if(!gDeviceFactory.Get2ndTemperCompen()->GetCompenPosition(m_d2ndTemper, gTempINI.m_sTempTime.dAutoScalTemperature[subTool.nMask][1], 
					gTempINI.m_sTempTime.dAutoScalEndTemperature[subTool.nMask][1],
					nSlaveLSBX, nSlaveLSBY,
					nFieldSizeUM, gProcessINI.m_sProcessOption.dTemperMinTLimit, gProcessINI.m_sProcessOption.dTemperMaxTLimit, m_dPower))
				{
					if(gDeviceFactory.Get2ndTemperCompen()->GetIsSetRefT())
						m_nErrMsgID = STDGNALM1034;
					else
						m_nErrMsgID = STDGNALM1033;
					return FALSE;
				}
			}
		}

		if(!gDeviceFactory.GetEocard()->DownloadShotData2((unsigned short)nMasterLSBX, (unsigned short)nMasterLSBY, 
															(unsigned short)nSlaveLSBX, (unsigned short)nSlaveLSBY, 
															b1stPanelFire, b2ndPanelFire, nTool))
		{
			m_nErrMsgID = STDGNALM443;
			return FALSE;
		}
	}
	return nBarHoleNo;
}

int CPaneAutoRun::DownloadTextData(LPFIREHOLE pHole, int nTool, CPoint ptMaster, CPoint ptSlave, BOOL b1stPanelFire, BOOL b2ndPanelFire)
{
	int nBarX1, nBarY1, nBarX2, nBarY2;
	SUBTOOLDATA	subTool;
	CString str;
	int nLeng;
	nLeng = strlen(gDProject.m_szLotId);
	TCHAR cTemp[MAX_PATH_LEN] = {0,};
	TCHAR cFirst2[2];
				
	cFirst2[0] = gDProject.m_szLotId[0]; 
	cFirst2[1] = gDProject.m_szLotId[1];

	//앞의 알파벳 두자리 마킹하지 않음 
	if(((cFirst2[0] >= 65 && cFirst2[0] <= 90) || (cFirst2[0] >= 97 && cFirst2[0] <= 122)) &&
		((cFirst2[1] >= 65 && cFirst2[1] <= 90) || (cFirst2[1] >= 97 && cFirst2[1] <= 122)))
	{
		for(int e = 0; e < nLeng - 2 ; e++)
		{
			cTemp[e] = gDProject.m_szLotId[e+2];
		}
	}
	else
	{
		memcpy(cTemp, gDProject.m_szLotId, MAX_PATH_LEN);
	}

	str.Format(_T("%s%02d"), cTemp, m_nLotMarkStartNo + m_nLotMarkCurrent);

	if(!gDProject.GetSubTool(nTool, 0, subTool))
	{
		m_nErrMsgID = STDGNALM758;
		return FALSE;
	}
	BOOL bRet;
	if(pHole->pOrigin->bRotate)
	{
		subTool.nRotate += 90;
	}
	bRet = gTextData.GetTextData(str, gDProject.m_pToolCode[nTool]->m_nMarkingSize, 100, 
		TRUE, gSystemINI.m_sSystemDevice.nTextRefMode, (int)(gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0),
		subTool.bFlipX, subTool.bFlipY, 
		subTool.nRotate, gSystemINI.m_sSystemDevice.dTextGap, 
		gDProject.m_nRotateInfo, gSystemINI.m_sSystemDevice.bUseInnerOCRFont); 
	if(!bRet)
	{
		m_nErrMsgID = STDGNALM660; 
		return FALSE;
	}
	int nTextHoleNo = gTextData.GetDataCount(TRUE);
	if(nTextHoleNo == 0)
	{
		m_nErrMsgID = STDGNALM660; // make Text error;
		return FALSE;
	}
	
	int nFieldSizeUM = (int)(gSystemINI.m_sSystemDevice.dFieldSize.x*1000);
	int nMasterLSBX, nMasterLSBY, nSlaveLSBX, nSlaveLSBY;

	for(int j = 0; j < nTextHoleNo; j++)
	{
		if(!gTextData.GetNextPoint(TRUE, nBarX1, nBarY1, nBarX2, nBarY2))
		{
			m_nErrMsgID = STDGNALM661; // get Text data error;
			return FALSE;
		}

		nMasterLSBX = ptMaster.x + nBarX1;
		nMasterLSBY = ptMaster.y + nBarY1;
		nSlaveLSBX = ptSlave.x + nBarX2;
		nSlaveLSBY = ptSlave.y + nBarY2;
		if(gProcessINI.m_sProcessOption.bTemperCompensationMode)
		{
				SUBTOOLDATA subTool;
			if(!gDProject.GetSubTool(nTool, 0, subTool))
			{
				m_nErrMsgID = STDGNALM758;
				return FALSE;
			}

			if(b1stPanelFire)
			{
				if(!gDeviceFactory.Get1stTemperCompen()->GetCompenPosition(m_d1stTemper, gTempINI.m_sTempTime.dAutoScalTemperature[subTool.nMask][0], 
					gTempINI.m_sTempTime.dAutoScalEndTemperature[subTool.nMask][0], 
					nMasterLSBX, nMasterLSBY,
					nFieldSizeUM, gProcessINI.m_sProcessOption.dTemperMinTLimit, gProcessINI.m_sProcessOption.dTemperMaxTLimit, m_dPower))
				{
					if(gDeviceFactory.Get1stTemperCompen()->GetIsSetRefT())
						m_nErrMsgID = STDGNALM1034;
					else
						m_nErrMsgID = STDGNALM1033;
					return FALSE;
				}
			}
			if(b2ndPanelFire)
			{
				if(!gDeviceFactory.Get2ndTemperCompen()->GetCompenPosition(m_d2ndTemper, gTempINI.m_sTempTime.dAutoScalTemperature[subTool.nMask][1], 
					gTempINI.m_sTempTime.dAutoScalEndTemperature[subTool.nMask][1], 
					nSlaveLSBX, nSlaveLSBY, 
					nFieldSizeUM, gProcessINI.m_sProcessOption.dTemperMinTLimit, gProcessINI.m_sProcessOption.dTemperMaxTLimit, m_dPower))
				{
					if(gDeviceFactory.Get2ndTemperCompen()->GetIsSetRefT())
						m_nErrMsgID = STDGNALM1034;
					else
						m_nErrMsgID = STDGNALM1033;
					return FALSE;
				}
			}
		}

		if(!gDeviceFactory.GetEocard()->DownloadShotData2((unsigned short)nMasterLSBX, (unsigned short)nMasterLSBY, 
															(unsigned short)nSlaveLSBX, (unsigned short)nSlaveLSBY, 
															b1stPanelFire, b2ndPanelFire, nTool) )
		{
			m_nErrMsgID = STDGNALM443;
			return FALSE;
		}
	}
	return nTextHoleNo;
}

BOOL CPaneAutoRun::GetLPCDataAndSave(DAreaInfo *pAreaInfo, BOOL bOnlyErrorStop, int nSubToolNo)
{
	int nSortedIndex = -1;
	if(pAreaInfo)
		nSortedIndex = pAreaInfo->m_nSortIndex;

#ifndef __LPC_FOR_3RD_AOD__
	if(!gProcessINI.m_sProcessSystem.bDryRun && gSystemINI.m_sHardWare.bUseLPC)
	{
		TDrill_LPCMonitor*  pLPC_Monitor;
		pLPC_Monitor = gDeviceFactory.GetEocard()->GetLPCResult();
							
		if(pLPC_Monitor)
		{
			CString strPath, strMessage;
			strPath.Format(_T("LPC_%d_Data"), m_nCurrentLotCount);
			if(gProcessINI.m_sProcessOption.bLPCLogDetail)
			{
				for(int nShot = 0; nShot < (int)pLPC_Monitor->HoleCount.nCount; nShot++)
				{
					#ifdef __USE_DUALBAND_EOCARD__
						strMessage.Format(_T("LotCount : %d Field %d : ToolLoop %d ShotLoop %d ptnLoop %d nHoleNo %d nBurst %d nVal %d ( %.3f )"), 
							m_nCurrentLotCount, nSortedIndex, pLPC_Monitor->HoleInfo[nShot].nToolLoop, pLPC_Monitor->HoleInfo[nShot].nShotLoop, pLPC_Monitor->HoleInfo[nShot].nPtnLoop,
							pLPC_Monitor->HoleInfo[nShot].nHoleNo, pLPC_Monitor->HoleInfo[nShot].nBurstNo,
							pLPC_Monitor->HoleInfo[nShot].nBand0_Peak, 
								(double)(pLPC_Monitor->HoleInfo[nShot].nBand0_Peak) * 5. /4096);
					#else
						strMessage.Format(_T("LotCount : %d Field %d : ToolLoop %d ShotLoop %d ptnLoop %d nHoleNo %d nBurst %d nVal %d ( %.3f )"), 
							m_nCurrentLotCount, nSortedIndex, pLPC_Monitor->HoleInfo[nShot].nToolLoop, pLPC_Monitor->HoleInfo[nShot].nShotLoop, pLPC_Monitor->HoleInfo[nShot].nPtnLoop,
							pLPC_Monitor->HoleInfo[nShot].nHoleNo, pLPC_Monitor->HoleInfo[nShot].nBurstNo,
							pLPC_Monitor->HoleInfo[nShot].nValue_Peak, 
							(double)(pLPC_Monitor->HoleInfo[nShot].nValue_Peak) * 5. /4096);
					#endif
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strPath), reinterpret_cast<LPARAM>(&strMessage));
				}
			}
			else
			{
				strMessage.Format(_T("LotCount : %d Field %d : nLPC Error Count %d"), 
					m_nCurrentLotCount, nSortedIndex, pLPC_Monitor->HoleCount.nCount);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strPath), reinterpret_cast<LPARAM>(&strMessage));
									
			}
								
			if(gProcessINI.m_sProcessOption.bCheckLPCError && pLPC_Monitor->HoleCount.nCount > 0)
			{
				m_nErrMsgID = STDGNALM665;
				return FALSE;
			}
		}
		else
		{
			m_nErrMsgID = STDGNALM1024;
			return FALSE;
		}
	}
#else
	CPoint ptFilePos;
	CCorrectTime ctLogSaveTime;
	ctLogSaveTime.StartTime();
	if(!gProcessINI.m_sProcessSystem.bDryRun && gSystemINI.m_sHardWare.bUseLPC)
	{
		int nIndex;
		CString str1, strLPCFolder;
		nIndex = GetCurrentLotID(str1,str1,str1,str1);
		strLPCFolder.Format(_T("%s\\%s"), gEasyDrillerINI.m_clsDirPath.GetLPCLogDir(), gLotInfo.szLotID[nIndex]);

		// LPC Log
		if( 0 != _chdir( (LPSTR)(LPCTSTR)strLPCFolder ) )
		{
			if( 0 != _mkdir( (LPSTR)(LPCTSTR)strLPCFolder ))
			{
				m_nErrMsgID = STDGNALM1024;
				return FALSE;
			}
		}
	
		CString strPath, strMessage, strPrj;
		strPrj.Format(_T("%s"), gLotInfo.szPrj[nIndex]);
		int nDot = strPrj.ReverseFind(_T('\\'));
		strPrj = strPrj.Mid(nDot + 1);
		nDot = strPrj.ReverseFind('.');
		strPrj = strPrj.Left(nDot);

		strPath.Format(_T("%s\\%s_%d_%d.txt"), strLPCFolder, strPrj,  m_nCurrentLotIndex, m_nCurrentLotCount);
		CStdioFile file;
		if (FALSE == file.Open(strPath, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		{
				m_nErrMsgID = STDGNALM1024;
				return FALSE;
		}

		TRY
		{
			file.SeekToEnd();

			if(gProcessINI.m_sProcessOption.bLPCLogDetail && !bOnlyErrorStop)
			{
				TLpc_Buffer*  pLPC_Monitor;
				pLPC_Monitor = gDeviceFactory.GetEocard()->GetLPCResult();
							
				if(pLPC_Monitor)
				{
					int nNGType;
					for(int nShot = 0; nShot < (int)pLPC_Monitor->HoleCount.nTotal; nShot++)
					{
						nNGType = 0;
						if(pLPC_Monitor->HoleInfo[nShot].nBand0_LaserPower_S16 < pLPC_Monitor->HoleInfo[nShot].nMin)
							nNGType = 1;
						if(pLPC_Monitor->HoleInfo[nShot].nBand0_LaserPower_S16 > pLPC_Monitor->HoleInfo[nShot].nMax)
							nNGType = 2;

						ptFilePos = gDeviceFactory.GetEocard()->GetDownHoleFirePos(pLPC_Monitor->HoleInfo[nShot].nHoleNo);

						strMessage.Format(_T("Field %d SubToolNo %d Index %d NGType %d POSX %d POSY %d ToolLoop %d ShotLoop %d ptnLoop %d nHoleNo %d nBurst %d min %d max %d nVal %d ( %.3f )\n"), 
							nSortedIndex, nSubToolNo, nShot, nNGType, ptFilePos.x, ptFilePos.y,
							pLPC_Monitor->HoleInfo[nShot].nToolLoop, pLPC_Monitor->HoleInfo[nShot].nShotLoop, pLPC_Monitor->HoleInfo[nShot].nPtnLoop,
							pLPC_Monitor->HoleInfo[nShot].nHoleNo, pLPC_Monitor->HoleInfo[nShot].nBurstNo,
							pLPC_Monitor->HoleInfo[nShot].nMin,
							pLPC_Monitor->HoleInfo[nShot].nMax,
							pLPC_Monitor->HoleInfo[nShot].nBand0_LaserPower_S16, 
								(double)(pLPC_Monitor->HoleInfo[nShot].nBand0_LaserPower_S16) * 5. /4096);

						file.Write(strMessage, strMessage.GetLength());
					}
					if(gProcessINI.m_sProcessOption.bCheckLPCError && 
					(pLPC_Monitor->HoleCount.nMinLimitError > 0 || pLPC_Monitor->HoleCount.nMaxLimitError > 0))
					{
						m_nErrMsgID = STDGNALM665;
						file.Close();
						return FALSE;
					}
				}
				else
				{
					m_nErrMsgID = STDGNALM1024;
					file.Close();
					return FALSE;
				}
			}
			else
			{
				int nMinError = 0, nMaxError = 0;
				if(gDeviceFactory.GetEocard()->GetLPCErrorCount(nMinError, nMaxError))
				{
					TLpc_Buffer*  pLPC_Monitor;
					pLPC_Monitor = gDeviceFactory.GetEocard()->GetLPCResult();
					if(nMinError > 0 || nMaxError > 0)
					{
						strMessage.Format(_T("SchduleIndex %d LotCount %d Field %d SubToolNo %d nLPC Min. Error Count %d Max. Error Count %d"), 
							m_nCurrentLotIndex, m_nCurrentLotCount,nSortedIndex, nSubToolNo, pLPC_Monitor->HoleCount.nMinLimitError, pLPC_Monitor->HoleCount.nMaxLimitError);
						
						file.Write(strMessage, strMessage.GetLength());

						TLpc_Buffer*  pLPC_Monitor;
						pLPC_Monitor = gDeviceFactory.GetEocard()->GetLPCResult();
						if(pLPC_Monitor)
						{
							int nNGType;
							for(int nShot = 0; nShot < (int)pLPC_Monitor->HoleCount.nTotal; nShot++)
							{
								nNGType = 0;
								if(pLPC_Monitor->HoleInfo[nShot].nBand0_LaserPower_S16 < pLPC_Monitor->HoleInfo[nShot].nMin)
									nNGType = 1;
								if(pLPC_Monitor->HoleInfo[nShot].nBand0_LaserPower_S16 > pLPC_Monitor->HoleInfo[nShot].nMax)
									nNGType = 2;

								ptFilePos = gDeviceFactory.GetEocard()->GetDownHoleFirePos(pLPC_Monitor->HoleInfo[nShot].nHoleNo);

								strMessage.Format(_T("Field %d SubToolNo %d Index %d NGType %d POSX %d POSY %d ToolLoop %d ShotLoop %d ptnLoop %d nHoleNo %d nBurst %d min %d max %d nVal %d ( %.3f )\n"), 
									nSortedIndex, nSubToolNo, nShot, nNGType, ptFilePos.x, ptFilePos.y,
									pLPC_Monitor->HoleInfo[nShot].nToolLoop, pLPC_Monitor->HoleInfo[nShot].nShotLoop, pLPC_Monitor->HoleInfo[nShot].nPtnLoop,
									pLPC_Monitor->HoleInfo[nShot].nHoleNo, pLPC_Monitor->HoleInfo[nShot].nBurstNo,
									pLPC_Monitor->HoleInfo[nShot].nMin,
									pLPC_Monitor->HoleInfo[nShot].nMax,
									pLPC_Monitor->HoleInfo[nShot].nBand0_LaserPower_S16, 
										(double)(pLPC_Monitor->HoleInfo[nShot].nBand0_LaserPower_S16) * 5. /4096);


								file.Write(strMessage, strMessage.GetLength());
							}
						}
					}
					if(gProcessINI.m_sProcessOption.bCheckLPCError && 
						(nMinError > 0 || nMaxError > 0))
					{
						m_nErrMsgID = STDGNALM665;
						file.Close();
						return FALSE;
					}
				}
				else
				{
					m_nErrMsgID = STDGNALM1024;
					file.Close();
					return FALSE;
				}
			}
		}
		CATCH (CFileException, e)
		{
			e->Delete();
			file.Close();
			return FALSE;
		}
		END_CATCH
		file.Close();
	}
	double dLogTime = ctLogSaveTime.PresentTime();
	TRACE(_T("LPC Save Time : %.6f\n"), dLogTime);
#endif
	return TRUE;
}

BOOL CPaneAutoRun::DrillFireAndWait(BOOL& bSubToolChangSkip, BOOL& bNextAreaPosDownNeed, BOOL& bCheckInpositionCheckAll, DAreaInfo *pAreaInfo, DAreaInfo *pNextAreaInfo, int nTool, int nDumperShotNo, BOOL bSkive, int nDrillHoleCnt, BOOL b1stTCalMove)
{
	CCorrectTime myTime, ctFireTime;//1분 넘으면 알람
	BOOL bShowError = FALSE;
	CString strFile, strLog;
	strFile.Format(_T("ReadHole"));
	HEocard* pEocard = gDeviceFactory.GetEocard();
	for(int j = 0; j < gDProject.m_pToolCode[nTool]->m_SubToolData.GetCount(); j++)
	{
		if(bSubToolChangSkip)
			bSubToolChangSkip = FALSE;
		else
		{
			if(!ChangeOneSubTool(nTool, j))
			{
				return FALSE;
			}
			bNextAreaPosDownNeed = TRUE;
		}
					
		if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
		{
			if(!pEocard->EndMarkDummy())
			{
				m_nErrMsgID = STDGNALM445; // 
				strLog.Format(_T("EndMarkDummy Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				m_pLineDummyTime.Finish();
				return FALSE;
			}
		}

		if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && !gSystemINI.m_sHardWare.nUseFirstOrder)
		{
			double dStandbyTime;
			while(TRUE)
			{
				if(!CheckStatus())
				{
					if(gSystemINI.m_sSystemDevice.nEStop == 1)
						pEocard->EStop();
					return FALSE;
				}
								
				dStandbyTime = m_StandbyTime.PresentTime();
				if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
					if(dStandbyTime > gSystemINI.m_sSystemDump.nStandbyTime)
						break;
				else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
					if(dStandbyTime > gSystemINI.m_sSystemDump.nStandbyTime2)
						break;
			}
		}

		if(!pEocard->FieldPreStart(nDumperShotNo))
		{
			m_nErrMsgID = STDGNALM445; // count No error
			strLog.Format(_T("FieldPreStart Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			return FALSE;
		}

#ifdef __LPC_FOR_3RD_AOD__
		if(m_bLPCStartField)
		{
			m_bLPCStartField = FALSE;
		}
		else
		{
			if(m_bLPCDontGetYet)
			{
				if(!GetLPCDataAndSave(pAreaInfo, TRUE, m_nLPCSubToolNo))
				{
					m_bLPCDontGetYet = FALSE;
					return FALSE;
				}
			}
		}
#endif

		pEocard->SetRunMode(FALSE, 20, 2, 1, DSP_ONLY);

		if(!gSystemINI.m_sSystemDump.nDummyStartAfterTableStop)
		{
			if(nDumperShotNo > 0 && gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
			{
				m_bEocardEstopAtOnceForDrillstop = TRUE;
				if(!pEocard->DummyFieldStart(nDumperShotNo, gProcessINI.m_sProcessSystem.bDryRun))
				{
					m_nErrMsgID = STDGNALM445; // count No error
					strLog.Format(_T("DummyFieldStart Error"));
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					return FALSE;
				}
			}
		}

		if(!ChangeOneSubToolCheckInposition())
			return FALSE;

		if(bCheckInpositionCheckAll)
		{
			if(!InpositionCheckAll(pAreaInfo)) // inposition check : Move Cmd --> Download data --> inposition check
				return FALSE;
			bCheckInpositionCheckAll = FALSE;
		}

		if(gSystemINI.m_sSystemDump.nDummyStartAfterTableStop)
		{
			if(nDumperShotNo > 0 && gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
			{
				if(!pEocard->DummyFieldStart(nDumperShotNo, gProcessINI.m_sProcessSystem.bDryRun))
				{
					m_bEocardEstopAtOnceForDrillstop = TRUE;
					m_nErrMsgID = STDGNALM445; // count No error
					strLog.Format(_T("DummyFieldStart Error"));
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					return FALSE;
				}
			}
		}

		myTime.StartTime();

		if(nDumperShotNo > 0 && gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
		{
			if(!pEocard->DummyStopAndDataShotStart(gProcessINI.m_sProcessSystem.bDryRun))
			{
				m_nErrMsgID = STDGNALM445; // count No error
				strLog.Format(_T("DummyStopAndDataShotStart Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				return FALSE;
			}
			m_bEocardEstopAtOnceForDrillstop = FALSE;
		}
		else
		{
			if(!pEocard->FieldStart(gProcessINI.m_sProcessSystem.bDryRun))
			{
				m_nErrMsgID = STDGNALM445; // count No error
				strLog.Format(_T("FieldStart Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				return FALSE;
			}
		}

		::Sleep(100);							
		BOOL bIsDspBusy = TRUE;
		double dFireTime;
		ctFireTime.StartTime();
		BOOL bDrawFire = TRUE;
		BOOL bLPCDataSaveError = FALSE;
		while(bIsDspBusy)
		{
			if(bDrawFire)
			{
				m_pData->DrawData();
				bDrawFire = FALSE;
			}

			dFireTime = ctFireTime.PresentTime();
			if(dFireTime >= 60 && !bShowError)
			{
								
			#ifndef __MP920_MOTOR__
				m_pMotor->SetOutPort(PORT_ALARM, 1);	
			#else
				m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);	
			#endif

				ErrMessage(_T("Fire Time is overed 1Min"));
				bShowError = TRUE;
							
			#ifndef __MP920_MOTOR__
				m_pMotor->SetOutPort(PORT_ALARM, 0);	
			#else
				m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);	
			#endif
				m_nErrMsgID = STDGNALM566;
				return FALSE;
			}

			if(bNextAreaPosDownNeed)
			{
				if(pNextAreaInfo)
				{
					if(!DownloadFirstToolMotorPos(pAreaInfo, pNextAreaInfo, bSkive)) // x, y, z, (m, c) 축 이동
					{
						return FALSE;
					}
				}
				bNextAreaPosDownNeed = FALSE;
			}

			if(!CheckStatus())
			{
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					pEocard->EStop();
				return FALSE;
			}

			int nMaxPos = gDeviceFactory.GetMotor()->ChangeMotorPosition(pAreaInfo->m_nTableX / 1000.0 + pAreaInfo->m_dTableOffsetX, \
				pAreaInfo->m_nTableY / 1000.0 + pAreaInfo->m_dTableOffsetY, b1stTCalMove);

			if(nMaxPos)
			{
				CString strMsg;
				strMsg.Format(_T("Table Shoot Error : %d"), nMaxPos);
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				m_nErrMsgID = STDGNALM540;
				return FALSE;
			}

			BOOL bScannerCableError = gDeviceFactory.GetEocard()->IsScannerCableError();
			BOOL bScannerMotorFault = gDeviceFactory.GetEocard()->IsMotorFault();
			BOOL bScannerDrillTimeOut = gDeviceFactory.GetEocard()->IsDrillTimeOut();
			BOOL bTimeOutType = gDeviceFactory.GetEocard()->IsDrillTimeOutType();
			CString strErrorMsg = _T("");
			if(bScannerCableError)
			{
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				m_nErrMsgID = STDGNALM1017;
				m_strErrorPlus = _T("Scanner Cable Error.");
				return FALSE;
			}
			else if(bScannerMotorFault)
			{
				if(bScannerMotorFault & 0x01)
					strErrorMsg += _T("Scanner Master X Motor Fault\r\n");
				if(bScannerMotorFault & 0x02)
					strErrorMsg += _T("Scanner Master Y Motor Fault\r\n");
				if(bScannerMotorFault & 0x04)
					strErrorMsg += _T("Scanner Slave X Motor Fault\r\n");
				if(bScannerMotorFault & 0x08)
					strErrorMsg += _T("Scanner Slave Y Motor Fault\r\n");

				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				m_nErrMsgID = STDGNALM1017;
				m_strErrorPlus = strErrorMsg;
				return FALSE;
			}
			else if(bScannerDrillTimeOut)
			{
				if(bScannerDrillTimeOut & 0x01)
					strErrorMsg += _T("Scanner Master X Drill Time Out\r\n");
				if(bScannerDrillTimeOut & 0x02)
					strErrorMsg += _T("Scanner Master Y Drill Time Out\r\n");
				if(bScannerDrillTimeOut & 0x04)
					strErrorMsg += _T("Scanner Slave X Drill Time Out\r\n");
				if(bScannerDrillTimeOut & 0x08)
					strErrorMsg += _T("Scanner Slave Y Drill Time Out\r\n");

				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				m_nErrMsgID = STDGNALM1017;
				m_strErrorPlus = strErrorMsg;
				return FALSE;
			}
			else if(bTimeOutType)
 			{
				if(bTimeOutType & 0x01)
					strErrorMsg += _T("Unknown Time Out\r\n");
				if(bTimeOutType & 0x02)
					strErrorMsg += _T("Drill Time Out\r\n");
				if(bTimeOutType & 0x04)
					strErrorMsg += _T("LPC Time Out\r\n");

				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				m_nErrMsgID = STDGNALM566;
				m_strErrorPlus = strErrorMsg;
				return FALSE;
 			}
#ifdef __LPC_FOR_3RD_AOD__
			if(m_bLPCDontGetYet)
			{
				m_bLPCDontGetYet = FALSE;
				bLPCDataSaveError = !GetLPCDataAndSave(m_pLPCAreaInfo, FALSE, m_nLPCSubToolNo); // 바로 멈출 필요 없다. 단지 reading 에러이고 LPC 자체 에러는 아니다.
			}
			m_bLPCDontGetYet = FALSE;
#endif
 			
// 			if(gDeviceFactory.GetEocard()->IsMotorFault())
// 			{
// 				if(gSystemINI.m_sSystemDevice.nEStop == 1)
// 					gDeviceFactory.GetEocard()->EStop();
// 				m_nErrMsgID = STDGNALM567;
// 				return FALSE;
// 			}
			bIsDspBusy = pEocard->IsDSPBusy();
		}

		if(bLPCDataSaveError)
			return FALSE;

		if(!gDeviceFactory.GetEocard()->SetLPCDataReadReady())
		{
			m_nErrMsgID = STDGNALM1023;
			return FALSE;
		}
		::Sleep(10);
		bIsDspBusy = TRUE;
		while(bIsDspBusy)
		{
			bIsDspBusy = gDeviceFactory.GetEocard()->IsDSPBusy();
		}
		m_pLPCAreaInfo = pAreaInfo;
		m_nLPCSubToolNo = j;
		m_bLPCDontGetYet = TRUE;

		m_dScannerTime += myTime.PresentTime();
		pEocard->SetRunMode(FALSE, 20, 2, 1, DSP_CONST_ONLY);

		if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
		{
			if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
			{
				m_nErrMsgID = STDGNALM781;
				return FALSE;
			}
			m_pLineDummyTime.StartTime();
			Sleep(10);
			if(!pEocard->StartMarkDummy())
			{
				m_nErrMsgID = STDGNALM445; // count No error
				strLog.Format(_T("StartMarkDummy Error"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				m_pLineDummyTime.Finish();
				return FALSE;
			}
			Sleep(10);
		}

#ifndef __LPC_FOR_3RD_AOD__
		if(!GetLPCDataAndSave(m_pLPCAreaInfo, FALSE, m_nLPCSubToolNo))
			return FALSE;
#endif

#ifndef __TEST__
		int	nEocardHoleCount = 0, nDownShotCnt = 0, nReadShotCnt = 0;
		nEocardHoleCount = pEocard->ReadHoleCount();
		if(m_bBarcodeTool)
		{
			if(nEocardHoleCount != nDrillHoleCnt)
			{
				for(int lll = 0; lll < 3; lll++)
				{
					pEocard->IsFireCntOK(nDownShotCnt, nReadShotCnt);
					strLog.Format(_T("EOCard: first : %d - second : %d, UI:%d - FireShots : %d, downShots : %d"), 
					nEocardHoleCount, pEocard->ReadHoleCount(), nDrillHoleCnt, nReadShotCnt, nDownShotCnt);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}

				m_nErrMsgID = STDGNALM603; // count No error
				return FALSE;
			}	
		}
		else
		{
			if(nEocardHoleCount != nDrillHoleCnt)
			{
				for(int lll = 0; lll < 3; lll++)
				{
					pEocard->IsFireCntOK(nDownShotCnt, nReadShotCnt);
					if(nDownShotCnt != nReadShotCnt)
					{
						strLog.Format(_T("EOCard: first : %d - second : %d, UI:%d - FireShots : %d, downShots : %d"), 
						nEocardHoleCount, pEocard->ReadHoleCount(), nDrillHoleCnt, nReadShotCnt, nDownShotCnt);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					}
					else
						break;
				}
				m_nErrMsgID = STDGNALM603; // count No error
				return FALSE;
			}
		}
		BOOL bFireOK = FALSE;
		for(int lll = 0; lll < 3; lll++)
		{
			pEocard->IsFireCntOK(nDownShotCnt, nReadShotCnt);
			if(nDownShotCnt != nReadShotCnt)
			{
				strLog.Format(_T("UI:%d - FireShots : %d, downShots : %d"), nDrillHoleCnt, nReadShotCnt, nDownShotCnt);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			}
			else
			{
				bFireOK = TRUE;
				break;
			}
		}
		if(!bFireOK)
		{
			m_nErrMsgID = STDGNALM603; // count No error
			return FALSE;
		}
#endif
	}
	return TRUE;
}

BOOL CPaneAutoRun::WaitEocardIdle(BOOL& bNextAreaPosDownNeed, DAreaInfo *pAreaInfo, DAreaInfo *pNextAreaInfo, BOOL bSkive, BOOL b1stTCalMove)
{
	HEocard* pEocard = gDeviceFactory.GetEocard();
	CCorrectTime ctFireTime; //1분 넘으면 알람 
	ctFireTime.StartTime();
	double dFireTime;
	BOOL bIsDspBusy = TRUE;
	BOOL bShowError = TRUE;
	BOOL bDrawFire = TRUE;
	while(bIsDspBusy)
	{
		if(bDrawFire)
		{
			m_pData->DrawData();
			bDrawFire = FALSE;
		}

		dFireTime = ctFireTime.PresentTime();
		if(dFireTime >= 60 && !bShowError)
		{
		#ifndef __MP920_MOTOR__
			m_pMotor->SetOutPort(PORT_ALARM, 1);	
		#else
			m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);	
		#endif
									
			ErrMessage(_T("Fire Time is overed 1Min"));
			bShowError = TRUE;
									
		#ifndef __MP920_MOTOR__
			m_pMotor->SetOutPort(PORT_ALARM, 0);	
		#else
			m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);	
		#endif
			m_nErrMsgID = STDGNALM566;
			return FALSE;
		}
		if(bNextAreaPosDownNeed)
		{
			if(pNextAreaInfo)
			{
				if(!DownloadFirstToolMotorPos(pAreaInfo, pNextAreaInfo, bSkive)) // x, y, z, (m, c) 축 이동
					return FALSE;
			}
			bNextAreaPosDownNeed = FALSE;
		}
		
		if(!CheckStatus())
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				pEocard->EStop();
			return FALSE;
		}

		int nMaxPos = gDeviceFactory.GetMotor()->ChangeMotorPosition(pAreaInfo->m_nTableX / 1000.0 + pAreaInfo->m_dTableOffsetX, \
		pAreaInfo->m_nTableY / 1000.0 + pAreaInfo->m_dTableOffsetY, b1stTCalMove);

		if(nMaxPos)
		{
			CString strMsg;
			strMsg.Format(_T("Table Shoot Error : %d"), nMaxPos);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
			m_nErrMsgID = STDGNALM540;
			return FALSE;
		}

		BOOL bScannerCableError = gDeviceFactory.GetEocard()->IsScannerCableError();
		BOOL bScannerMotorFault = gDeviceFactory.GetEocard()->IsMotorFault();
		BOOL bScannerDrillTimeOut = gDeviceFactory.GetEocard()->IsDrillTimeOut();
		BOOL bTimeOutType =  gDeviceFactory.GetEocard()->IsDrillTimeOutType();
		CString strErrorMsg = _T("");
		if(bScannerCableError)
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			m_nErrMsgID = STDGNALM1017;
			m_strErrorPlus = _T("Scanner Cable Error.");
			return FALSE;
		}
		else if(bScannerMotorFault)
		{
			if(bScannerMotorFault & 0x01)
				strErrorMsg += _T("Scanner Master X Motor Fault\r\n");
			if(bScannerMotorFault & 0x02)
				strErrorMsg += _T("Scanner Master Y Motor Fault\r\n");
			if(bScannerMotorFault & 0x04)
				strErrorMsg += _T("Scanner Slave X Motor Fault\r\n");
			if(bScannerMotorFault & 0x08)
				strErrorMsg += _T("Scanner Slave Y Motor Fault\r\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			m_nErrMsgID = STDGNALM1017;
			m_strErrorPlus = strErrorMsg;
			return FALSE;
		}
		else if(bScannerDrillTimeOut)
		{
			if(bScannerDrillTimeOut & 0x01)
				strErrorMsg += _T("Scanner Master X Drill Time Out\r\n");
			if(bScannerDrillTimeOut & 0x02)
				strErrorMsg += _T("Scanner Master Y Drill Time Out\r\n");
			if(bScannerDrillTimeOut & 0x04)
				strErrorMsg += _T("Scanner Slave X Drill Time Out\r\n");
			if(bScannerDrillTimeOut & 0x08)
				strErrorMsg += _T("Scanner Slave Y Drill Time Out\r\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			m_nErrMsgID = STDGNALM1017;
			m_strErrorPlus = strErrorMsg;
			return FALSE;
		}
 		else if(bTimeOutType)
 		{
 			if(bTimeOutType & 0x01)
				strErrorMsg += _T("Unknown Time Out\r\n");
			if(bTimeOutType & 0x02)
				strErrorMsg += _T("Drill Time Out\r\n");
			if(bTimeOutType & 0x04)
				strErrorMsg += _T("LPC Time Out\r\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			m_nErrMsgID = STDGNALM566;
			m_strErrorPlus = strErrorMsg;
			return FALSE;
 		}
// 		if(gDeviceFactory.GetEocard()->IsMotorFault())
// 		{
// 			if(gSystemINI.m_sSystemDevice.nEStop == 1)
// 				gDeviceFactory.GetEocard()->EStop();
// 			m_nErrMsgID = STDGNALM567;
// 			return FALSE;
// 		}
		bIsDspBusy = pEocard->IsDSPBusy();
	}
	return TRUE;
}

BOOL CPaneAutoRun::DownloadLineToShotData(LPFIRELINE pLine, BOOL b1stPanelFire, BOOL b2ndPanelFire, int nDivideCount, double dFileDivideX, double dFileDivideY, double dDivideX1, double dDivideY1, double dDivideX2, double dDivideY2,  int nToolNo, int nFieldIndex, CPoint& ptLast)
{
//	CString strFile, strLog;
//	strFile.Format(_T("Cavity"));

	HEocard* pEocard = gDeviceFactory.GetEocard();
	CPoint ptMaster1, ptSlave1, ptStartP;
	CPoint ptMaster2, ptSlave2;
	int nMasterLSBX, nMasterLSBY, nSlaveLSBX, nSlaveLSBY;
	int nFileX, nFileY;
	int nIndexX, nIndexY, nSubIndexX, nSubIndexY;
	if(b1stPanelFire)
	{
		ptMaster1 = pLine->npFidSPos1;
		ptStartP = pLine->npFidSPos1;
		if(!b2ndPanelFire)
			ptSlave1 = ptMaster1;
	}
	if(b2ndPanelFire)
	{
		ptSlave1 = pLine->npFidSPos2;
		ptStartP = pLine->npFidSPos2;
		if(!b1stPanelFire)
			ptMaster1 = ptSlave1;
	}
							
	if(b1stPanelFire)
	{
		ptMaster2 = pLine->npFidEPos1;
		ptLast = pLine->npFidEPos1;
		if(!b2ndPanelFire)
			ptSlave2 = ptMaster2;
	}
	if(b2ndPanelFire)
	{
		ptSlave2 = pLine->npFidEPos2;
		ptLast = pLine->npFidEPos2;
		if(!b1stPanelFire)
			ptMaster2 = ptSlave2;
	}
							
	for(int i = 0; i <= nDivideCount; i++)
	{
		if(i == nDivideCount)
		{
			nMasterLSBX =  ptMaster2.x;
			nMasterLSBY =  ptMaster2.y;
			nSlaveLSBX =  ptSlave2.x;
			nSlaveLSBY =  ptSlave2.y;
//			nFileX = pLine->npEndPos.x;
//			nFileY = pLine->npEndPos.y;
		}
		else
		{
			nMasterLSBX =  (USHORT)(ptMaster1.x + dDivideX1*i);
			nMasterLSBY =  (USHORT)(ptMaster1.y + dDivideY1*i);
			nSlaveLSBX =  (USHORT)(ptSlave1.x + dDivideX2*i);
			nSlaveLSBY =  (USHORT)(ptSlave1.y + dDivideY2*i);
//			nFileX = pLine->npStartPos.x + dFileDivideX*i - gDProject.m_nMinX;
//			nFileY = pLine->npStartPos.y + dFileDivideY*i - gDProject.m_nMinY;
		}
//		nIndexX = nFileX >> 4;
//		nIndexY = nFileY >> 4;
//		nSubIndexX = nIndexX % 2;
//		nSubIndexY = nIndexY % 2;
//		nIndexX = nIndexX >> 1;
//		nIndexY = nIndexY >> 1;
//		if(m_pcField[nIndexX * 32000 + nIndexY] == 0)
		{
//			m_pcField[nIndexX * 32000 + nIndexY] = 15; // 1, 2, 4, 8
			if(!pEocard->DownloadShotData2((USHORT)nMasterLSBX, (USHORT)nMasterLSBY, (USHORT)nSlaveLSBX, (USHORT)nSlaveLSBY, b1stPanelFire, b2ndPanelFire, nToolNo, 0, 0))
			{
				return FALSE;
			}
//			strLog.Format(_T("%d\t%d\t%d\t%d"), nFieldIndex, nToolNo, nMasterLSBX, nMasterLSBY);
//			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		}
	}
	return TRUE;
}

void CPaneAutoRun::DownloadLineData(LPFIRELINE pLine, BOOL b1stPanelFire, BOOL b2ndPanelFire, BOOL& bShortLineOld, CPoint& ptLast)
{
	BOOL bShortLine;
	HEocard* pEocard = gDeviceFactory.GetEocard();
	CPoint ptMaster, ptSlave, ptStartP;
	if(b1stPanelFire)
	{
		ptMaster = pLine->npFidSPos1;
		ptStartP = pLine->npFidSPos1;
		if(!b2ndPanelFire)
			ptSlave = ptMaster;
	}
	if(b2ndPanelFire)
	{
		ptSlave = pLine->npFidSPos2;
		ptStartP = pLine->npFidSPos2;
		if(!b1stPanelFire)
			ptMaster = ptSlave;
	}

	double dDist = sqrt((double)(pLine->npStartPos.x - pLine->npEndPos.x) * (pLine->npStartPos.x - pLine->npEndPos.x) +
			(pLine->npStartPos.y - pLine->npEndPos.y) * (pLine->npStartPos.y - pLine->npEndPos.y));	
	if(dDist > gSystemINI.m_sHardWare.nShortLineLength) 
		bShortLine = FALSE;
	else
		bShortLine = TRUE;
							
	if(ptLast.x == INT_MAX || ptLast.x != ptStartP.x || ptLast.y != ptStartP.y )
	{
		if(b1stPanelFire)
		{
			ptMaster = pLine->npFidSPos1;
			if(!b2ndPanelFire)
				ptSlave = ptMaster; 
		}
		if(b2ndPanelFire)
		{
			ptSlave = pLine->npFidSPos2;
			if(!b1stPanelFire)
				ptMaster = ptSlave;
		}
		pEocard->jump(ptMaster.x, ptMaster.y, ptSlave.x, ptSlave.y,	HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB);
	//	TRACE("jump ptMaster.x = %d, ptMaster.x=y = %d \n", ptMaster.x, ptMaster.y);
	}
							
	if(b1stPanelFire)
	{
		ptMaster = pLine->npFidEPos1;
		ptLast = pLine->npFidEPos1;
		if(!b2ndPanelFire)
			ptSlave = ptMaster;
	}
	if(b2ndPanelFire)
	{
		ptSlave = pLine->npFidEPos2;
		ptLast = pLine->npFidEPos2;
		if(!b1stPanelFire)
			ptMaster = ptSlave;
	}
							
	if(!gProcessINI.m_sProcessSystem.bDryRun)
	{
		if((bShortLineOld && !bShortLine) ||
			(!bShortLineOld && bShortLine))
		{
			pEocard->SetParameterCavityDuty(bShortLine);
			bShortLineOld = !bShortLineOld;
		}
		pEocard->mark(	ptMaster.x, ptMaster.y,	ptSlave.x, ptSlave.y, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB);
	}
	else
		pEocard->jump(	ptMaster.x, ptMaster.y,	ptSlave.x, ptSlave.y, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB);
							
//	TRACE("ptMaster.x = %d, ptMaster.x=y = %d \n", ptMaster.x, ptMaster.y);
}

BOOL CPaneAutoRun::OneFieldFire(DAreaInfo *pAreaInfo, DAreaInfo *pNextAreaInfo, BOOL bSkive, int nFidBlock, BOOL bLogHole)
{
	CCorrectTime ctFireTime; //1분 넘으면 알람 
	ctFireTime.StartTime();
	double dFireTime = 0; 
	BOOL bShowError = FALSE;
	HEocard* pEocard = gDeviceFactory.GetEocard();
	BOOL bFirstToolDown = TRUE, bFirstHole;
	BOOL bDownOK;
	BOOL bFirstPanel, bSecondPanel;
	BOOL bDownFirstToolPos = TRUE;
	int nTotalShotCount, nSubCount, nTotalLineCount;
	int nTool = -1;
	int nTotalBarHoleNo = 0;
	CPoint ptMaster, ptSlave;
	int nMasterLSBX, nMasterLSBY, nSlaveLSBX, nSlaveLSBY;
	double d2DTransAngle1 = 0, d2DTransAngle2 = 0;
	#ifndef __TEST__
	int	nEocardHoleCount = 0, nDownShotCnt = 0, nReadShotCnt = 0;
#endif
	CString strFile, strLog;

	nTotalShotCount = 0;
	nTotalLineCount = 0;
	ptMaster.x = ptMaster.y = ptSlave.x = ptSlave.y = HALF_LSB;
	GetFirePanelInfo(bFirstPanel, bSecondPanel);
	
	int nFieldSizeUM = (int)(gSystemINI.m_sSystemDevice.dFieldSize.x*1000);
	gDeviceFactory.GetMotor()->GetTCTemperature(m_d1stTemper, m_d2ndTemper);
	gDeviceFactory.GetMotor()->GetSBTemperature(m_d1stSBTemper, m_d2ndSBTemper);
	double dScalAllTemper[10];
	gDeviceFactory.GetMotor()->GetTemperatureForAllCh(dScalAllTemper);
	if(gProcessINI.m_sProcessOption.bTemperDetailLog)
	{
		strFile.Format(_T("SCal_Time_Log"));
		strLog.Format(_T("OneFieldFire Temper \t %.3f \t %.3f"), m_d1stTemper, m_d2ndTemper);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		strLog.Format(_T("OneFieldFire Temp All \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f"),   
						dScalAllTemper[0], dScalAllTemper[1], dScalAllTemper[2], dScalAllTemper[3], dScalAllTemper[4],
						dScalAllTemper[5], dScalAllTemper[6], dScalAllTemper[7], dScalAllTemper[8], dScalAllTemper[9]);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}

	LPFIREHOLE pHole;
	POSITION pos;	
	
	pAreaInfo->m_nFireStatus = DOING_FIRE;

	// 110427 yhchung
	m_dCurrent = -1;
	m_nthermal = -1;

	BOOL bDumpShotDown = FALSE;

	BOOL bCheckInpositionCheckAll = TRUE;

	LPFIDDATA pFidData;

	
	strFile.Format(_T("ReadHole"));

	int nIndex;

	CCorrectTime myTime;

	int nDumperShotNo = gSystemINI.m_sSystemDump.nDummyShot;
	int nDumperType = DUMMY_FREE_1;
#ifdef __KUNSAN_8__
	if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
	{
		nDumperShotNo = gSystemINI.m_sSystemDump.nDummyShot2;
		nDumperType = DUMMY_FREE_2;
	}
#endif
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		nTotalShotCount = 0;
		nSubCount = 0;
		bFirstHole = TRUE;
		pos = pAreaInfo->m_FireHoles[i].GetHeadPosition();

		while(pos)
		{
			pHole = pAreaInfo->m_FireHoles[i].GetNext(pos);
			if(i == ADDED_FID_TOOL) // skiving data
			{
				nTool = ADDED_FID_TOOL;
				nIndex = (int)(pHole->pOrigin);
				if(!m_bAutoRun && m_bSelectFire && !gDProject.m_Glyphs.GetUseFidSelect(DEFAULT_FID_INDEX, nIndex)) //ADDED_FID_INDEX, nIndex))
					continue;

				pFidData = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, nIndex);
				if( !(pFidData->nFidType & FID_SECONDARY) || !(pFidData->nFidType & FID_DRILL) )
					continue;
			}
			else
				nTool = gDProject.m_ToolSumInfo[pHole->pOrigin->nToolNo].nRealToolNo;

			if( i == ADDED_FID_TOOL || 
				m_bAutoRun ||
				(gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable() &&
				(!m_bSelectFire || (m_bSelectFire && pHole->bSelect))) )
			{
				if(nFidBlock != -1 && pHole->pOrigin->nFidBlock != nFidBlock)
					continue;

				if(nSubCount == 0 || bFirstHole)
				{
					if(!pEocard->ShotDataReset())
					{
						m_nErrMsgID = STDGNALM442;
						return FALSE;
					}
					if(!bDumpShotDown)
						bDumpShotDown = TRUE;
				}
				if(bFirstHole)
				{
					bFirstHole = FALSE;
					if(bLogHole)
						WriteFidOffsetData(pHole, pAreaInfo->m_nTableX, pAreaInfo->m_nTableY);
#ifndef __TEST__
					nTotalShotCount = 0;
					ChangeShotDrillInfo(nTool);
#endif
				}

				if(bFirstPanel)
				{
					ptMaster = pHole->npPos1;
				
					if(!bSecondPanel)
						ptSlave = pHole->npPos1;
				}
				if(bSecondPanel)
				{
					ptSlave = pHole->npPos2;

					if(!bFirstPanel)
						ptMaster =  pHole->npPos2;
				}
				if(m_bBarcodeTool)
				{
					int nAddBarHoleNo = DownloadBarcodeData(nTool, ptMaster, ptSlave, bFirstPanel, bSecondPanel);
					if(nAddBarHoleNo == 0)
						return FALSE;
					nTotalBarHoleNo += nAddBarHoleNo;
					nSubCount += nAddBarHoleNo;
				}
				else if (m_bTextTool)
				{
					int nAddTextHoleNo = DownloadTextData(pHole, nTool, ptMaster, ptSlave, bFirstPanel, bSecondPanel);
					if(nAddTextHoleNo == 0)
						return FALSE;
					nSubCount += nAddTextHoleNo;
				}
				else
				{
					nSubCount++;

					nMasterLSBX = ptMaster.x; nMasterLSBY = ptMaster.y;
					nSlaveLSBX = ptSlave.x; nSlaveLSBY = ptSlave.y;
					if(gProcessINI.m_sProcessOption.bTemperCompensationMode) 
					{
						SUBTOOLDATA subTool;
						if(!gDProject.GetSubTool(nTool, 0, subTool))
						{
							m_nErrMsgID = STDGNALM758;
							return FALSE;
						}
						if(bFirstPanel)
						{
							if(!GetRepeatCompenTransResult(ptMaster.x, ptMaster.y, TRUE, nMasterLSBX, nMasterLSBY))
							{
								m_nErrMsgID = STDGNALM1033;
								return FALSE;
							}
							if(!gDeviceFactory.Get1stTemperCompen()->GetCompenPosition(m_d1stTemper, gTempINI.m_sTempTime.dAutoScalTemperature[subTool.nMask][0], 
								gTempINI.m_sTempTime.dAutoScalEndTemperature[subTool.nMask][0], 
								nMasterLSBX, nMasterLSBY, 
								nFieldSizeUM, gProcessINI.m_sProcessOption.dTemperMinTLimit, gProcessINI.m_sProcessOption.dTemperMaxTLimit, m_dPower))
							{
								if(gDeviceFactory.Get1stTemperCompen()->GetIsSetRefT())
									m_nErrMsgID = STDGNALM1034;
								else
									m_nErrMsgID = STDGNALM1033;
								return FALSE;
							}
						}
						if(bSecondPanel)
						{
							if(!GetRepeatCompenTransResult(ptSlave.x, ptSlave.y, FALSE, nSlaveLSBX, nSlaveLSBY))
							{
								m_nErrMsgID = STDGNALM1033;
								return FALSE;
							}
							if(!gDeviceFactory.Get2ndTemperCompen()->GetCompenPosition(m_d2ndTemper, gTempINI.m_sTempTime.dAutoScalTemperature[subTool.nMask][1], 
								gTempINI.m_sTempTime.dAutoScalEndTemperature[subTool.nMask][1], 
								nSlaveLSBX, nSlaveLSBY, 
								nFieldSizeUM, gProcessINI.m_sProcessOption.dTemperMinTLimit, gProcessINI.m_sProcessOption.dTemperMaxTLimit, m_dPower))
							{
								if(gDeviceFactory.Get2ndTemperCompen()->GetIsSetRefT())
									m_nErrMsgID = STDGNALM1034;
								else
									m_nErrMsgID = STDGNALM1033;
								return FALSE;
							}
						}
					}
					if(m_bShotDrill && i != ADDED_FID_TOOL)
						bDownOK = pEocard->DownloadShotData2((USHORT)nMasterLSBX, (USHORT)nMasterLSBY, (USHORT)nSlaveLSBX, (USHORT)nSlaveLSBY, bFirstPanel, bSecondPanel, pHole->pOrigin->nToolNo, pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y);
					else
						bDownOK = pEocard->DownloadShotData2((USHORT)nMasterLSBX, (USHORT)nMasterLSBY, (USHORT)nSlaveLSBX, (USHORT)nSlaveLSBY, bFirstPanel, bSecondPanel, nTool, pHole->pOrigin->npPos.x, pHole->pOrigin->npPos.y);
				}
				if(i != ADDED_FID_TOOL) // skiving hole count 제외
				{
					nTotalShotCount ++;
				}

				if(!bDownOK)
				{
					m_nErrMsgID = STDGNALM443;
					return FALSE;
				}

				if(nSubCount > DOWNLOAD_MAX_HOLE) // eocard가 처리할 수 있는 최대 수
				{
					if(!DrillFireAndWait(bFirstToolDown, bDownFirstToolPos, bCheckInpositionCheckAll, pAreaInfo, pNextAreaInfo, nTool, nDumperShotNo, bSkive, nSubCount, bFirstPanel))
						return FALSE;
					nSubCount = 0;
				}
			}
			if(!CheckStatus())
				return FALSE;
		}

		if(!CheckStatus())
			return FALSE;

		if(nSubCount > 0) // downloading 이 하나라도 되었다면 가공
		{
			if(!DrillFireAndWait(bFirstToolDown, bDownFirstToolPos, bCheckInpositionCheckAll, pAreaInfo, pNextAreaInfo, nTool, nDumperShotNo, bSkive, nSubCount, bFirstPanel))
				return FALSE;
		}
		if(nTool != ADDED_FID_TOOL)
		{
			m_nLotHoleCount += nTotalShotCount;
			m_nTotalHoleCount += nTotalShotCount;
		}
	}

	pEocard->SetRunMode(FALSE, 20, 2, 1, DSP_ONLY);

	if(bCheckInpositionCheckAll)
	{
		if(!InpositionCheckAll(pAreaInfo)) // inposition check : Move Cmd --> Download data --> inposition check
			return FALSE;
		bCheckInpositionCheckAll = FALSE;
	}

	if(!CheckStatus())
		return FALSE;
	
	LPFIRELINE pLine;
	CPoint oldEnd, tempPos;
	BOOL bShortLineOld = FALSE;
	double dLength, dDivideX1, dDivideY1, dDivideX2, dDivideY2, dFileDivideX = 0, dFileDivideY = 0;
	int nDivideCount;
		
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		nTotalLineCount = 0;

		if(gProcessINI.m_sProcessSystem.bLineToShotFireMode)// 20131028
		{
			if(!pEocard->ShotDataReset())
			{
				m_nErrMsgID = STDGNALM442;
				return FALSE;
			}

			oldEnd.x = INT_MAX;
			bFirstHole = TRUE;
			pos = pAreaInfo->m_FireLines[i].GetHeadPosition();
			
			while(pos)
			{
				pLine = pAreaInfo->m_FireLines[i].GetNext(pos);

				if(i == ADDED_FID_TOOL) // skiving data
					continue;
				else
					nTool = gDProject.m_ToolSumInfo[pLine->pOrigin->nToolNo].nRealToolNo;
					
				if( m_bAutoRun ||
					(gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable() &&
					(!m_bSelectFire || (m_bSelectFire && pLine->bSelect))) )
				{
					if(nFidBlock != -1 && pLine->pOrigin->nFidBlock != nFidBlock)
						continue;

					nTotalLineCount++;
					if(bFirstHole)
					{
//						memset(m_pcField, NULL, sizeof(BYTE) * 4097 * 4097);
						if(!bDumpShotDown)
							bDumpShotDown = TRUE;

						if(!WaitEocardIdle(bDownFirstToolPos, pAreaInfo, pNextAreaInfo, bSkive, bFirstPanel))
								return FALSE;
						bFirstHole = FALSE;

	#ifndef __TEST__
						ChangeShotDrillInfo(nTool);
	#endif
					}
					dLength = sqrt((double)(pLine->npEndPos.x - pLine->npStartPos.x) * (pLine->npEndPos.x - pLine->npStartPos.x) +
									(double)(pLine->npEndPos.y - pLine->npStartPos.y) * (pLine->npEndPos.y - pLine->npStartPos.y));
					nDivideCount = (int)(0.5 + dLength / gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->m_nToolSize) ;
					if(!gProcessINI.m_sProcessSystem.bLineToShotSameLength)
					{
						dDivideX1 =  gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->m_nToolSize * (pLine->npFidEPos1.x - pLine->npFidSPos1.x) / dLength; // 끝쪽은 크기가 다를 수 있다.
						dDivideY1 =  gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->m_nToolSize * (pLine->npFidEPos1.y - pLine->npFidSPos1.y) / dLength;
						dDivideX2 =  gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->m_nToolSize * (pLine->npFidEPos2.x - pLine->npFidSPos2.x) / dLength; // 끝쪽은 크기가 다를 수 있다.
						dDivideY2 =  gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->m_nToolSize * (pLine->npFidEPos2.y - pLine->npFidSPos2.y) / dLength;
//						dFileDivideX = gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->m_nToolSize * (pLine->npEndPos.y - pLine->npStartPos.y) / dLength;
//						dFileDivideY = gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->m_nToolSize * (pLine->npEndPos.y - pLine->npStartPos.y) / dLength;
					}
					else
					{
							dDivideX1 =  (double)(pLine->npFidEPos1.x - pLine->npFidSPos1.x) / nDivideCount; // 비례배분
							dDivideY1 =  (double)(pLine->npFidEPos1.y - pLine->npFidSPos1.y) / nDivideCount;
							dDivideX2 =  (double)(pLine->npFidEPos2.x - pLine->npFidSPos2.x) / nDivideCount; // 비례배분
							dDivideY2 =  (double)(pLine->npFidEPos2.y - pLine->npFidSPos2.y) / nDivideCount;
//							dFileDivideX = (pLine->npEndPos.x - pLine->npStartPos.x) / nDivideCount;
//							dFileDivideY = (pLine->npEndPos.y - pLine->npStartPos.y) / nDivideCount;
					}
					if(m_bShotDrill && i != ADDED_FID_TOOL)
					{
						if(!DownloadLineToShotData(pLine, bFirstPanel, bSecondPanel, nDivideCount, dFileDivideX, dFileDivideY, dDivideX1, dDivideY1, dDivideX2, dDivideY2, pLine->pOrigin->nToolNo, pAreaInfo->m_nSortIndex, oldEnd))
						{
							m_nErrMsgID = STDGNALM443;
							return FALSE;
						}
					}
					else
					{
						if(!DownloadLineToShotData(pLine, bFirstPanel, bSecondPanel, nDivideCount, dFileDivideX, dFileDivideY, dDivideX1, dDivideY1, dDivideX2, dDivideY2, nTool, pAreaInfo->m_nSortIndex, oldEnd))
						{
							m_nErrMsgID = STDGNALM443;
							return FALSE;
						}
					}
				}
			}

			if(nTotalLineCount > 0)
			{
				for(int j = 0; j < gDProject.m_pToolCode[i]->m_SubToolData.GetCount(); j++)
				{
					if(j == 0 && bFirstToolDown)
					{
						bFirstToolDown = FALSE;
					}
					else
					{
						if(!ChangeOneSubTool(i, j, TRUE))
						{
							return FALSE;
						}
						bDownFirstToolPos = TRUE;
					}

					int nSumCount = DownloadSumSubToolDataToEocard(i, j, gDProject.m_pToolCode[i]->m_SubToolData.GetCount());
					if(nSumCount == -1)
						return FALSE;

					j += nSumCount;

					if(!CheckStatus())
						return FALSE;

					// fire
					if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
					{
						if(!pEocard->EndMarkDummy())
						{
							m_nErrMsgID = STDGNALM445; // 
							strLog.Format(_T("EndMarkDummy Error"));
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							m_pLineDummyTime.Finish();
							return FALSE;
						}
					}

					if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && !gSystemINI.m_sHardWare.nUseFirstOrder)
					{
						double dStandbyTime;
						while(TRUE)
						{
							if(!CheckStatus())
							{
								if(gSystemINI.m_sSystemDevice.nEStop == 1)
									pEocard->EStop();
								return FALSE;
							}
								
							dStandbyTime = m_StandbyTime.PresentTime();
							if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
								if(dStandbyTime > gSystemINI.m_sSystemDump.nStandbyTime)
									break;
							else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
								if(dStandbyTime > gSystemINI.m_sSystemDump.nStandbyTime2)
									break;
						}
					}

					if(!pEocard->FieldPreStart(nDumperShotNo))
					{
						m_nErrMsgID = STDGNALM445; // count No error
						strLog.Format(_T("FieldPreStart Error"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
						return FALSE;
					}

					pEocard->SetRunMode(FALSE, 20, 2, 1, DSP_ONLY);

					if(!gSystemINI.m_sSystemDump.nDummyStartAfterTableStop)
					{
						if(nDumperShotNo > 0 && gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
						{
							m_bEocardEstopAtOnceForDrillstop = TRUE;
							if(!pEocard->DummyFieldStart(nDumperShotNo, gProcessINI.m_sProcessSystem.bDryRun))
							{
								m_nErrMsgID = STDGNALM445; // count No error
								strLog.Format(_T("DummyFieldStart Error"));
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
								return FALSE;
							}
						}
					}

					if(!ChangeOneSubToolCheckInposition())
						return FALSE;

					if(bCheckInpositionCheckAll)
					{
						if(!InpositionCheckAll(pAreaInfo)) // inposition check : Move Cmd --> Download data --> inposition check
							return FALSE;
						bCheckInpositionCheckAll = FALSE;
					}

					if(gSystemINI.m_sSystemDump.nDummyStartAfterTableStop)
					{
						if(nDumperShotNo > 0 && gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
						{
							if(!pEocard->DummyFieldStart(nDumperShotNo, gProcessINI.m_sProcessSystem.bDryRun))
							{
								m_bEocardEstopAtOnceForDrillstop = TRUE;
								m_nErrMsgID = STDGNALM445; // count No error
								strLog.Format(_T("DummyFieldStart Error"));
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
								return FALSE;
							}
						}
					}

					myTime.StartTime();

					if(nDumperShotNo > 0 && gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
					{
						if(!pEocard->DummyStopAndDataShotStart(gProcessINI.m_sProcessSystem.bDryRun))
						{
							m_nErrMsgID = STDGNALM445; // count No error
							strLog.Format(_T("DummyStopAndDataShotStart Error"));
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							return FALSE;
						}
						m_bEocardEstopAtOnceForDrillstop = FALSE;
					}
					else
					{
						if(!pEocard->FieldStart(gProcessINI.m_sProcessSystem.bDryRun))
						{
							m_nErrMsgID = STDGNALM445; // count No error
							strLog.Format(_T("FieldStart Error"));
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							return FALSE;
						}
					}
					::Sleep(100);

					if(!WaitEocardIdle(bDownFirstToolPos, pAreaInfo, pNextAreaInfo, bSkive, bFirstPanel))
						return FALSE;

					pEocard->SetRunMode(FALSE, 20, 2, 1, DSP_CONST_ONLY);

					if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
					{
						if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
						{
							m_nErrMsgID = STDGNALM781;
							return FALSE;
						}
						Sleep(10);
						if(!pEocard->StartMarkDummy())
						{
							m_nErrMsgID = STDGNALM445; // count No error
							strLog.Format(_T("StartMarkDummy Error"));
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							return FALSE;
						}
						Sleep(10);
					}
				}
			}
		}
		else
		{
			for(int j = 0; j < gDProject.m_pToolCode[i]->m_SubToolData.GetCount(); j++)
			{
				oldEnd.x = INT_MAX;
				bFirstHole = TRUE;
				pos = pAreaInfo->m_FireLines[i].GetHeadPosition();
				
				while(pos)
				{
					pLine = pAreaInfo->m_FireLines[i].GetNext(pos);
					
					if( m_bAutoRun ||
						(gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable() &&
						(!m_bSelectFire || (m_bSelectFire && pLine->bSelect))) )
					{
						if(nFidBlock != -1 && pLine->pOrigin->nFidBlock != nFidBlock)
							continue;

						if(bFirstHole)
						{
							if(!WaitEocardIdle(bDownFirstToolPos, pAreaInfo, pNextAreaInfo, bSkive, bFirstPanel))
								return FALSE;
			
							m_pLineDummyTime.StartTime();

							if(bFirstToolDown)
							{
								bFirstToolDown = FALSE;
								//20111107
								if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && !gSystemINI.m_sHardWare.nUseFirstOrder)
								{
									double dStandbyTime;
									while(TRUE)
									{
										if(!CheckStatus())
										{
											if(gSystemINI.m_sSystemDevice.nEStop == 1)
												pEocard->EStop();
											return FALSE;
										}
										
										dStandbyTime = m_StandbyTime.PresentTime();
										if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
											if(dStandbyTime > gSystemINI.m_sSystemDump.nStandbyTime)
												break;
										else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
											if(dStandbyTime > gSystemINI.m_sSystemDump.nStandbyTime2)
												break;
									}
								}
								if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
								{
									m_nErrMsgID = STDGNALM781;
									return FALSE;
								}
								
								if(bCheckInpositionCheckAll)
								{
									if(!InpositionCheckAll(pAreaInfo)) // inposition check : Move Cmd --> Download data --> inposition check
									{
										m_pLineDummyTime.Finish();
										return FALSE;
									}
									bCheckInpositionCheckAll = FALSE;
								}
							}
							else
							{
								if(!WaitEocardIdle(bDownFirstToolPos, pAreaInfo, pNextAreaInfo, bSkive, bFirstPanel))
									return FALSE;
									
								CCorrectTime SubToolChangeTime;
								SubToolChangeTime.StartTime();

								if(!ChangeOneSubTool(i, j))
								{
									m_pLineDummyTime.Finish();
									return FALSE;
								}
								if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
								{
									if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
									{
										m_nErrMsgID = STDGNALM781;
										return FALSE;
									}
									m_pLineDummyTime.StartTime();
									
									if(!pEocard->StartMarkDummy())
									{
										m_nErrMsgID = STDGNALM445; // count No error
										strLog.Format(_T("StartMarkDummy Error"));
										::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
										m_pLineDummyTime.Finish();
										return FALSE;
									}
								}
								if(!ChangeOneSubToolCheckInposition())
										return FALSE;
							
								if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
								{
									double dChangeTime = SubToolChangeTime.PresentTime();
									if(dChangeTime > 0.1) // 100ms 보타 큰경우만 다시 예열
									{
										double dSetDummyTime = gSystemINI.m_sSystemDump.nDummyInterval * nDumperShotNo / 1000000.;
										while (TRUE)
										{
											double dDummyTime = m_pLineDummyTime.PresentTime();
											if(dDummyTime > dSetDummyTime)
												break;
										}
									}
								}
								bDownFirstToolPos = TRUE;
							}
							
							if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
							{
								if(!pEocard->EndMarkDummy())
								{
									m_nErrMsgID = STDGNALM445; // 
									strLog.Format(_T("EndMarkDummy Error"));
									::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
									m_pLineDummyTime.Finish();
									return FALSE;
								}
								else
									m_pLineDummyTime.Finish();
								
							}
							pEocard->SubDownloadReset(0);
							bFirstHole = FALSE;
						}

						DownloadLineData(pLine, bFirstPanel, bSecondPanel, bShortLineOld, oldEnd);
					}
					nTotalLineCount++;
					if(!CheckStatus())
						return FALSE;
				}

				if(oldEnd.x != INT_MAX)
				{
					pEocard->jump(	oldEnd.x, oldEnd.y,
						oldEnd.x, oldEnd.y,
						HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB);
					pEocard->SubDownloadStop();
					if(pEocard->SubCallStart(0, FALSE) == FALSE)
					{
						#ifndef __TEST__
							m_nErrMsgID = STDGNALM445; // 
							strLog.Format(_T("Cavity Fire Fail"));
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							return FALSE;
						#endif
					}
				
					::Sleep(100);

					if(!WaitEocardIdle(bDownFirstToolPos, pAreaInfo, pNextAreaInfo, bSkive, bFirstPanel))
						return FALSE;
				}

				if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
				{
					if(!pEocard->StartMarkDummy())
					{
						m_nErrMsgID = STDGNALM445; // count No error
						strLog.Format(_T("StartMarkDummy Error"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
						m_pLineDummyTime.Finish();
						return FALSE;
					}
				}
			}
		}
		m_nLotLineCount += nTotalLineCount;
		m_nTotalLineCount += nTotalLineCount;
	}
	
	if(!CheckStatus())
		return FALSE;
	
	if(bDownFirstToolPos && pNextAreaInfo)
	{
		if(!DownloadFirstToolMotorPos(pAreaInfo, pNextAreaInfo, bSkive)) // x, y, z, (m, c) 축 이동
			return FALSE;
	}
	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
	{
		if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
		{
			if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
			{
				m_nErrMsgID = STDGNALM781;
				return FALSE;
			}
		}
	}

	pAreaInfo->m_nFireStatus = DONE_FIRE;
//	Invalidate(FALSE);
//	m_pData->DrawData();
	return TRUE;
}

BOOL CPaneAutoRun::DownloadOneSubTool(int nTool, int nSubIndex, BOOL bLineToShot)
{
	HEocard* pEocard = gDeviceFactory.GetEocard();
	SUBTOOLDATA subTool;
	m_bShotDrill = TRUE;
	m_bBarcodeTool = FALSE;
	m_bFlyingTool = FALSE;
	m_bTextTool = FALSE;
	POSITION pos;
	pos = gDProject.m_pToolCode[nTool]->m_SubToolData.GetHeadPosition();
	while (pos) 
	{
		subTool = gDProject.m_pToolCode[nTool]->m_SubToolData.GetNext(pos);
		if( subTool.nToolType != SHOT_DRILL_TYPE)
			m_bShotDrill = FALSE;
		if( subTool.nToolType == BARCODE_TYPE)
			m_bBarcodeTool = TRUE;
		if( subTool.nToolType == FLYING_TYPE)
			m_bFlyingTool = TRUE;
		if( subTool.nToolType == TEXT_TYPE)
			m_bTextTool = TRUE;
	}
	
	if(m_bShotDrill && !bLineToShot)	// download other tool info (freq. duty. aperture data)
	{					// 여러 tool을 다운로딩 해서 한번에 가공하는 경우
		int nSameTool = gDProject.m_ToolSumInfo[nTool].nRealToolNo;
		for(int i = nTool; i < MAX_TOOL_NO; i++)
		{
			if(nSameTool == gDProject.m_ToolSumInfo[i].nRealToolNo)
			{
				if(!gDProject.GetSubTool(i, nSubIndex, subTool))
				{
					m_nErrMsgID = STDGNALM758;
					return FALSE;
				}
				// beampath에서 duty 등 정보 받아오기
				GetBeamPathLaserInfo(subTool);

				if(!pEocard->DownloadOneSubTool(i, subTool))
				{
					m_nErrMsgID = STDGNALM445;
					return FALSE;
				}
			}
		}
	}
	else // 여러 tool을 다운로딩 해서 한번에 가공할 수 없는 경우
	{
		if(!gDProject.GetSubTool(nTool, nSubIndex, subTool))
		{
			m_nErrMsgID = STDGNALM758;
			return FALSE;
		}
		// beampath에서 duty 등 정보 받아오기
		GetBeamPathLaserInfo(subTool);
		
		if(!pEocard->DownloadOneSubTool(nTool, subTool))
		{
			m_nErrMsgID = STDGNALM445;
			return FALSE;
		}
	}

	GetSubToolParam(subTool, nTool, nSubIndex);

	return TRUE;
}

int CPaneAutoRun::DownloadSumSubToolDataToEocard(int nTool, int nSubIndex, int nEndIndex)
{
	SUBTOOLDATA subToolFirst;
	if(!gDProject.GetSubTool(nTool, nSubIndex, subToolFirst))
	{
		m_nErrMsgID = STDGNALM758;
		return -1;
	}
	// beampath에서 duty 등 정보 받아오기
	GetBeamPathLaserInfo(subToolFirst);

	double dMaskDutyOffset_Ori = gBeamPathINI.m_sBeampath.dPowOffsetDuty[subToolFirst.nMask];
	double dMaskAOMDelayOffset_Ori = gBeamPathINI.m_sBeampath.dPowOffsetAomDelay[subToolFirst.nMask];
	double dMaskAOMDutyOffset_Ori = gBeamPathINI.m_sBeampath.dPowOffsetAomDuty[subToolFirst.nMask];
	double dPowerDutyOffset_Ori = gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[subToolFirst.nMask];
	double dVoltage1_Ori = gBeamPathINI.m_sBeampath.dBeamPathVoltage1[subToolFirst.nMask];
	double dVoltage2_Ori = gBeamPathINI.m_sBeampath.dBeamPathVoltage2[subToolFirst.nMask];

	if( subToolFirst.nToolType != SHOT_DRILL_TYPE)
	{
		m_nErrMsgID = STDGNALM758;
		return -1;
	}

	int nSumCount = 0;
	for(int i = nSubIndex + 1; i < nEndIndex; i++)
	{
		SUBTOOLDATA subToolNext;
		if(!gDProject.GetSubTool(nTool, i, subToolNext))
		{
			m_nErrMsgID = STDGNALM758;
			return -1;
		}
		// beampath에서 duty 등 정보 받아오기
		GetBeamPathLaserInfo(subToolNext);
		//
		if(gBeamPathINI.m_sBeampath.bBeamPathUseTophat[subToolFirst.nMask] != gBeamPathINI.m_sBeampath.bBeamPathUseTophat[subToolNext.nMask])
			return nSumCount;
		if(gBeamPathINI.m_sBeampath.bBeamPathLaserPath[subToolFirst.nMask] != gBeamPathINI.m_sBeampath.bBeamPathLaserPath[subToolNext.nMask])
			return nSumCount;

		if(gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[subToolFirst.nMask] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[subToolNext.nMask])
			return nSumCount;
		if(gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[subToolFirst.nMask] != gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[subToolNext.nMask])
			return nSumCount;

		if(gBeamPathINI.m_sBeampath.dBeamPathBetPos1[subToolFirst.nMask] != gBeamPathINI.m_sBeampath.dBeamPathBetPos1[subToolNext.nMask])
			return nSumCount;
		if(gBeamPathINI.m_sBeampath.dBeamPathBetPos2[subToolFirst.nMask] != gBeamPathINI.m_sBeampath.dBeamPathBetPos2[subToolNext.nMask])
			return nSumCount;
		if(gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[subToolFirst.nMask] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[subToolNext.nMask])
			return nSumCount;
		if(gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[subToolFirst.nMask] != gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[subToolNext.nMask])
			return nSumCount;

		if(gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[subToolFirst.nMask] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[subToolNext.nMask])
			return nSumCount;
		if(gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[subToolFirst.nMask] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[subToolNext.nMask])
			return nSumCount;
		if(gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[subToolFirst.nMask] != gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[subToolNext.nMask])
			return nSumCount;

		if(strcmp(gBeamPathINI.m_sBeampath.strBeamPathAscFile[subToolFirst.nMask], gBeamPathINI.m_sBeampath.strBeamPathAscFile[subToolNext.nMask]) != 0)
			return nSumCount;

		if(gBeamPathINI.m_sBeampath.dBeamPathVoltage1[subToolFirst.nMask] != gBeamPathINI.m_sBeampath.dBeamPathVoltage1[subToolNext.nMask])
			return nSumCount;
		if(gBeamPathINI.m_sBeampath.dBeamPathVoltage2[subToolFirst.nMask] != gBeamPathINI.m_sBeampath.dBeamPathVoltage2[subToolNext.nMask])
			return nSumCount;

		if( subToolNext.nToolType != SHOT_DRILL_TYPE)
			return nSumCount;

		if( subToolFirst.bUseAperture != subToolNext.bUseAperture)
			return nSumCount;
		if(subToolFirst.bUseAperture)
		{
			if(strcmp(subToolFirst.cFilePath, subToolNext.cFilePath) != 0)
				return nSumCount;
		}
		if(subToolFirst.nTotalShot + subToolNext.nTotalShot > 15) // 15샷 이상은 합치지 못함
			return nSumCount;

		if(subToolFirst.nBurstShot != 0 || subToolNext.nBurstShot != 0) // cycle 샷만 합침
			return nSumCount;

		// sum shot info
		double dMaskDutyOffset = gBeamPathINI.m_sBeampath.dPowOffsetDuty[subToolNext.nMask];
		double dMaskAOMDelayOffset = gBeamPathINI.m_sBeampath.dPowOffsetAomDelay[subToolNext.nMask];
		double dMaskAOMDutyOffset = gBeamPathINI.m_sBeampath.dPowOffsetAomDuty[subToolNext.nMask];
		double dPowerDutyOffset = gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[subToolNext.nMask];
		double dVoltage1 = gBeamPathINI.m_sBeampath.dBeamPathVoltage1[subToolNext.nMask];
		double dVoltage2 = gBeamPathINI.m_sBeampath.dBeamPathVoltage2[subToolNext.nMask];

		for(int j = 0; j < subToolNext.nTotalShot; j++)
		{
			subToolFirst.dShotDuty[ j + subToolFirst.nTotalShot ]			= subToolNext.dShotDuty[ j ]			- (dMaskDutyOffset_Ori + dPowerDutyOffset_Ori) + (dMaskDutyOffset + dPowerDutyOffset);
			subToolFirst.dShotAOMDelay[ j + subToolFirst.nTotalShot ]	= subToolNext.dShotAOMDelay[ j ]	- (dMaskAOMDelayOffset_Ori) + (dMaskAOMDelayOffset);
			subToolFirst.dShotAOMDuty[ j + subToolFirst.nTotalShot ]		= subToolNext.dShotAOMDuty[ j ]		- (dMaskAOMDutyOffset_Ori + dPowerDutyOffset_Ori) + (dMaskAOMDutyOffset + dPowerDutyOffset);
			subToolFirst.dShotVolOffsetM[ j + subToolFirst.nTotalShot ]	= subToolNext.dShotVolOffsetM[ j ]	- (dVoltage1_Ori) + (dVoltage1);
			subToolFirst.dShotVolOffsetS[ j + subToolFirst.nTotalShot ]	= subToolNext.dShotVolOffsetS[ j ]	- (dVoltage2_Ori) + (dVoltage2);
			subToolFirst.dShotDutyOffsetM[ j + subToolFirst.nTotalShot ]	= subToolNext.dShotDutyOffsetM[ j ];
			subToolFirst.dShotDutyOffsetS[ j + subToolFirst.nTotalShot ]	= subToolNext.dShotDutyOffsetS[ j ];

			subToolFirst.dShotMaxFreq[ j + subToolFirst.nTotalShot ]		= subToolNext.dShotMaxFreq[ j ];
			subToolFirst.dShotMinFreq[ j + subToolFirst.nTotalShot ]		= subToolNext.dShotMinFreq[ j ];
		}
		subToolFirst.nTotalShot += subToolNext.nTotalShot;
		nSumCount ++;
		
		if(!gDeviceFactory.GetEocard()->DownloadOneSubTool(nTool, subToolFirst))
		{
			m_nErrMsgID = STDGNALM445;
			return -1;
		}
	}
	return nSumCount;
}

BOOL CPaneAutoRun::ChangeOneSubTool(int nTool, int nSubIndex, BOOL bLineToShot)
{
	// M, C, Z move
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	double dC1, dC2, dA1, dA2; 
	SUBTOOLDATA subTool;
	if(!gDProject.GetSubTool(nTool, nSubIndex, subTool))
	{
		m_nErrMsgID = STDGNALM758;
		return FALSE;
	}

	m_bCheckZMC = FALSE;
	m_bCheckMC = FALSE;
	BOOL bTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[subTool.nMask];

	if(!pMotor->MoveTophatShutter(bTophat))
	{
		m_nErrMsgID = STDGNALM568;
		//ErrMessage(_T("Tophat shutter move error!"));
		return FALSE;
	}
	BOOL bLaserPath = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[subTool.nMask];
	if(!pMotor->MoveLaserBeamPath(bLaserPath))
	{
		m_nErrMsgID = STDGNALM974;
		return FALSE;
	}
	double dLaserHeight1, dLaserHeight2, dM1, dM2, dM3;

	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		// Mask별 Z축 이동
		dLaserHeight1 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[subTool.nMask];
		dLaserHeight2 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[subTool.nMask];
		
		double dHeight1 = dLaserHeight1 - gDProject.m_dPcbThick;
		double dHeight2 = dLaserHeight2 - gDProject.m_dPcbThick2; 
		dC1 =  gBeamPathINI.m_sBeampath.dBeamPathBetPos1[subTool.nMask];
		dC2 =  gBeamPathINI.m_sBeampath.dBeamPathBetPos2[subTool.nMask];
		dA1 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[subTool.nMask];
		dA2 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[subTool.nMask];
		m_dPosZ1New = dHeight1;
		m_dPosZ2New = dHeight2;

		dM1 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[subTool.nMask];
		dM2 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[subTool.nMask];
		dM3 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[subTool.nMask];
		if(strcmp(m_cDownASC, gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]) != 0)
		{
			CString strMaster, strSlave;
			TCHAR sz1stFile[255], sz2ndFile[255];
			strMaster.Format(_T("%s\\%sM1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
			strSlave.Format(_T("%s\\%sS1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
			lstrcpy(sz1stFile, strMaster);
			lstrcpy(sz2ndFile, strSlave);
			if(!gDeviceFactory.GetEocard()->LoadCalibrationFile(sz1stFile, sz2ndFile))
			{
#ifndef __TEST__
				CString strString, strMsg;
				strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
				CString strTemp;
				strTemp.Format(_T("%s or %s"), sz1stFile, sz2ndFile);
				strMsg.Format(strString, strTemp);
				
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				m_nErrMsgID = STDGNALM105;
				return FALSE;
#endif
			}
			strcpy_s( m_cDownASC, gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
		}
		
		if(!gDeviceFactory.GetEocard()->SetVoltage(gBeamPathINI.m_sBeampath.dBeamPathVoltage1[subTool.nMask], gBeamPathINI.m_sBeampath.dBeamPathVoltage2[subTool.nMask]))
		{
			m_nErrMsgID = STDGNALM117;
			return FALSE;
		}
		
		m_bMoveXYMC = FALSE;


#ifndef __SERVO_MOTOR__
		if(!pMotor->MoveZMCA2(	dHeight1, dHeight2,
			dM1, dM2, dC1, dC2, dA1, dA2, TRUE, bTophat))
#else
			if(!pMotor->MoveZMCA3(dHeight1, dHeight2,
			dM1, dM2, dM3, dC1, dC2, dA1, dA2, TRUE, bTophat))
#endif
		{
			m_nErrMsgID = STDGNALM541;
			return FALSE;
		}
		m_bCheckZMC = TRUE;
		m_nMask1Old = subTool.nMask;
		m_dPosZ1Old = dHeight1;
		m_dPosZ2Old = dHeight2;
		m_bMoveXYMC = TRUE;
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		if(!gDeviceFactory.GetAttenuator()->MoveIndex(subTool.nMask))
		{
			m_nErrMsgID = STDGNALM542;
			return FALSE;
		}
	}
	else // not use M, C
	{
		if(bTophat)
		{
			dLaserHeight1 = gSystemINI.m_sSystemDevice.d1stLaserHeightTophat[0];
			dLaserHeight2 = gSystemINI.m_sSystemDevice.d2ndLaserHeightTophat[0];
		}
		else
		{
			dLaserHeight1 = gSystemINI.m_sSystemDevice.d1stLaserHeight[0];
			dLaserHeight2 = gSystemINI.m_sSystemDevice.d2ndLaserHeight[0];
		}
		
		double dHeight1 = dLaserHeight1 - gDProject.m_dPcbThick;
		double dHeight2 = dLaserHeight2 - gDProject.m_dPcbThick2; 
		m_dPosZ1New = dHeight1 + subTool.dZOffset;
		m_dPosZ2New = dHeight2 + subTool.dZOffset;
		
		m_bMoveXYMC = FALSE;
		if(m_dPosZ1New != m_dPosZ1Old || m_dPosZ2New != m_dPosZ2Old)
		{
			if(!pMotor->MoveZMC2(dHeight1 + subTool.dZOffset, dHeight2 +  subTool.dZOffset,
				subTool.dA1, subTool.dA2, TRUE, bTophat))
			{
				m_nErrMsgID = STDGNALM542;
				return FALSE;
			}
			m_bCheckZMC = TRUE;
			m_dPosZ1Old = dHeight1 + subTool.dZOffset;
			m_dPosZ2Old = dHeight2 + subTool.dZOffset;
			m_bMoveXYMC = TRUE;
		}
		else
		{
			if(m_dPosC1Old != subTool.dA1 || m_dPosC2Old != subTool.dA2)
			{
				if(!pMotor->MoveMC(subTool.dA1, subTool.dA2))
				{
					m_nErrMsgID = STDGNALM542;
					return FALSE;
				}
				m_bCheckMC = TRUE;
				m_dPosC1Old = subTool.dA1;
				m_dPosC2Old = subTool.dA2;
				m_bMoveXYMC = TRUE;
			}
		}
	}
	
	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
	{
		if(!gDeviceFactory.GetEocard()->EndMarkDummy())
		{
			m_nErrMsgID = STDGNALM445; // 
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("EndMarkDummy Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			m_pLineDummyTime.Finish();
			return FALSE;
		}
	}
	// subTool download
	if(!DownloadOneSubTool(nTool, nSubIndex, bLineToShot))
		return FALSE;
	
	// Laser Current Set
	if(!DownloadLaserOneSubTool(nTool, nSubIndex))
	{
		m_nErrMsgID = STDGNALM444;
		return FALSE;
	}
	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
	{
		if(!gDeviceFactory.GetEocard()->StartMarkDummy())
		{
			m_nErrMsgID = STDGNALM445; // count No error
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("StartMarkDummy Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			m_pLineDummyTime.Finish();
			return FALSE;
		}
	}
	
	return TRUE;
}

BOOL CPaneAutoRun::ChangeOneSubToolCheckInposition()
{
	// M, C, Z Inposition
	//Inposition check
	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
	{
		if(!gDeviceFactory.GetAttenuator()->IsInposition())
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
			return FALSE;
		}
	}
	else
	{
		if(m_bCheckZMC)
		{
			if(!m_pMotor->InPositionIO(IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_C2 + IND_M2 + IND_M3)) //110219 ejpark c2추가 
			{
				int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
				CheckInpositionError(nErrorAxis);
				return FALSE;
			}
			if(gSystemINI.m_sSystemDevice.nMaskInposWait)
				::Sleep(gSystemINI.m_sSystemDevice.nMaskInposWait);

		}
		else if(m_bCheckMC)
		{
			if(!m_pMotor->InPositionIO(IND_M1 + IND_C1 + IND_C2 + IND_M2 + IND_M3))
			{
				int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
				CheckInpositionError(nErrorAxis);
				return FALSE;
			}
			if(gSystemINI.m_sSystemDevice.nMaskInposWait)
				::Sleep(gSystemINI.m_sSystemDevice.nMaskInposWait);

		}
	}
	m_bCheckZMC = FALSE;
	m_bCheckMC = FALSE;
	return TRUE;
}

CDPoint CPaneAutoRun::GetNextStepIndex(int nStepNo)
{
	CDPoint pos(0,0);
	if(nStepNo == 0)
		return pos;
	int num = (int)sqrt((double)nStepNo) + 2;
	
	for(int j = 1; j< num; j++)
	{
		for(int i = 0; i<j; i++)
		{
			nStepNo--;
			if(j%2 == 1) pos.x++;
			else pos.x--;
			if(nStepNo == 0) return pos;
		}
		for(int i = 0; i<j; i++)
		{
			nStepNo--;
			if(j%2 == 1) pos.y++;
			else pos.y--;
			if(nStepNo == 0) return pos;
		}
	}
	return pos;
}

BOOL CPaneAutoRun::DownloadLaserOneSubTool(int nTool, int nSubIndex)
{
	if(!gProcessINI.m_sProcessSystem.bDryRun)
	{
		HLaser* pLaser = gDeviceFactory.GetLaser();
		SUBTOOLDATA subTool;

		if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
		{
			if(!gDProject.GetSubTool(nTool, nSubIndex, subTool))
			{
				m_nErrMsgID = STDGNALM758;
				return FALSE;
			}
			if(m_dCurrent != subTool.dCurrent || m_nthermal != subTool.nThermalTrack)
			{
				m_dCurrent = subTool.dCurrent;
				m_nthermal = subTool.nThermalTrack;
				return pLaser->ChangeAviaDiodeCurrent(subTool.dCurrent, subTool.nFrequency, subTool.nThermalTrack);
			}
			else
			{
				return TRUE;
			}
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
		{
			if(!gDProject.GetSubTool(nTool, nSubIndex, subTool))
			{
				m_nErrMsgID = STDGNALM758;
				return FALSE;
			}
			if(m_dCurrent != subTool.dCurrent)
			{
				m_dCurrent = subTool.dCurrent;
				return pLaser->setQuataParam(0, (int)m_dCurrent);
			}
			else
			{
				return TRUE;
			}
		}
		else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
		{
			if(!gDProject.GetSubTool(nTool, nSubIndex, subTool))
			{
				m_nErrMsgID = STDGNALM758;
				return FALSE;
			}
			if(m_dCurrent != subTool.dCurrent)
			{
				m_dCurrent = subTool.dCurrent;
				return pLaser->SetCurrent(subTool.dCurrent);
			}
			else
			{
				return TRUE;
			}
		}
	}
	return TRUE;
}

BOOL CPaneAutoRun::IsDrilling()
{
	if(WAIT_TIMEOUT == ::WaitForSingleObject(g_hDrill, 0))
		return TRUE;
	
	return FALSE;
}

void CPaneAutoRun::OnChkSuction1()
{
	if(IsDrilling() && !m_bOneCycleStopNoUnloadPause)
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
	{
		pMotor->SetOutPort( PORT_TABLE_SUCTION1, 1);
	}
	else
	{
		m_bTableSuction = !m_bTableSuction;

		if(m_bTableSuction)
			pMotor->SetOutPort( PORT_TABLE_SUCTION1, TRUE);
		else
		{
			pMotor->SetOutPort( PORT_TABLE_SUCTION1, FALSE);
		}
	}
}

void CPaneAutoRun::OnChkSuction2()
{
	if(IsDrilling() && !m_bOneCycleStopNoUnloadPause)
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_PMAC)
	{
		pMotor->SetOutPort( PORT_TABLE_SUCTION1, 0);
	}
	else
	{
		m_bTableSuction2 = !m_bTableSuction2;

		if(m_bTableSuction2)
			pMotor->SetOutPort(PORT_TABLE_SUCTION2, TRUE);
		else
			pMotor->SetOutPort(PORT_TABLE_SUCTION2, FALSE);
	}
}

void CPaneAutoRun::OnChkFluorescentLamp()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	m_bFluorescentLamp = !m_bFluorescentLamp;

	pMotor->SetOutPort(PORT_LAMP, m_bFluorescentLamp);
}

void CPaneAutoRun::SetAutoRun()
{
	if(m_bAutoRun)
	{
		m_bSelectFire = FALSE;
		m_ledSelectFire.Depress(!m_bSelectFire);
		gDProject.m_bSelectDrawMode = m_bSelectFire;
		gDProject.InitToolVisable();
//		Invalidate(FALSE);
//		m_pData->Invalidate(FALSE);
		m_pData->DrawData();
	}
	ChangeProjectInfo(TRUE);
}

BOOL CPaneAutoRun::GetLotCntAndMarkIndex()
{
	CDlgInputLot dlg;
	dlg.SetInputLot( m_nInputLot );
	dlg.SetStartNo( m_nLotMarkStartNo);

	if( IDOK != dlg.DoModal() )
		return FALSE;

	m_nLotMarkStartNo = dlg.GetStartNo();
	
	// for 스캐줄기능에서와 똑같이 작동되게 하기 위해 20131001
/*	gLotInfo.nLastIndex = 1;
	strcpy_s(gLotInfo.szLotID[0], gDProject.m_szLotId);
	gLotInfo.nLotCount[0] = dlg.GetInputLot();

	m_nInputLot = dlg.GetInputLot();
	m_nLotMarkStartNo = dlg.GetStartNo();
	CString strData;
	strData.Format(_T("%d (%d) PNL"), m_nInputLot, m_nLotMarkStartNo);
	m_btnLotInput.SetWindowText( (LPCTSTR)strData );
*/
/*	gLotInfo.nLastIndex = 1;
	strcpy_s(gLotInfo.szLotID[0], gDProject.m_szLotId);
	m_nInputLot = dlg.GetInputLot();
	m_nLotMarkStartNo = dlg.GetStartNo();

	gLotInfo.nLotCount[m_nLotMarkStartNo - 1] = dlg.GetInputLot();
	CString strData;
	strData.Format(_T("%d (%d) PNL"), m_nInputLot, m_nLotMarkStartNo);
	m_btnLotInput.SetWindowText( (LPCTSTR)strData );
	m_pOPC->InsertList();
*/
	return TRUE;
}

void CPaneAutoRun::SetErrMsg()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	if(m_nErrMsgID == 0)
		m_nErrMsgID = STDGNALM801;
#if defined (__OSAN_LG_2013__) ||  defined (__KUNSAN_SAMSUNG_LARGE__)
		if(m_nErrMsgID == STDGNALM801 || m_nErrMsgID == STDGNALM1080)
		{
	#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_LOT_END, 1);
	#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_LOT_END, 1);	
	#endif
		}
		else
		{
	#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_ALARM, 1);
	#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);	
	#endif
		}
#elif defined __KUNSAN_SAMSUNG_LARGE__
		if(m_nErrMsgID == STDGNALM801 || m_nErrMsgID == STDGNALM1080)
		{
	#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_LOT_END, 1);
	#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_LOT_END, 1);	
	#endif
		}
		else
		{
	#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_ALARM, 1);
	#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);	
	#endif
		}
#else
	#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_ALARM, 1);
	#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);	
	#endif
#endif

	if(m_bStopField)
	{
		::AfxGetMainWnd()->SendMessage(SEND_ERR_MSG, m_nErrMsgID, reinterpret_cast<LPARAM>(&m_strErrorPlus));
		m_nErrMsgID = STDGNALM804;
		m_strErrorPlus.Format("%d", m_nStopField);
		::AfxGetMainWnd()->SendMessage(SEND_ERR_MSG, m_nErrMsgID, reinterpret_cast<LPARAM>(&m_strErrorPlus));
		m_bStopField = FALSE;
	}
	else
		::AfxGetMainWnd()->SendMessage(SEND_ERR_MSG, m_nErrMsgID);

#ifndef __MP920_MOTOR__
	pMotor->SetOutPort(PORT_ALARM, 0);
	pMotor->SetOutPort(PORT_ALARM, 0);
#else
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif

	if(m_nErrMsgID != STDGNALM801)
	{
		::Sleep(500);
	}

	CString strSequenceLog;
	if(gDProject.m_CurrentMode == AUTO_DRILL_MODE || gDProject.m_CurrentMode == MANUAL_DRILL_MODE)
	{
		strSequenceLog.Format(_T("---Drill Stop---"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
	}
	
	gDProject.m_CurrentMode = NONE_DRILL_MODE;

	if(m_bMissFire)
	{
		if(ErrMessage(_T("Check PCB Drill condition manually \n Do you want add PCB Count?"), MB_YESNO) == IDYES)
		{
			m_nCycleCount++;
			m_nLotMarkCurrent++;

			m_nTotalCurrentLotCount++;
			m_nCurrentMarkingCount++;
			if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
			{
				m_nTotalCurrentLotCount++;
				m_nCurrentMarkingCount++;
			}
			if(!gProcessINI.m_sProcessSystem.bNoUseNGBox)
			{
				if(ErrMessage(_T("Are those Boards NG Panel?\n [Yes] will increase NG count. [No] will increase Good count."), MB_YESNO) == IDYES)
				{
					m_nNGLotCount++;
					gLotInfo.nNGLotCount[m_nCurrentPrjIndex]++;
					if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
					{
						m_nNGLotCount++;
						gLotInfo.nNGLotCount[m_nCurrentPrjIndex]++;
					}
				}
				else
				{
					gLotInfo.nFiredLotCount[m_nCurrentPrjIndex]++;
					m_nCurrentLotCount++;
					if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
					{
						gLotInfo.nFiredLotCount[m_nCurrentPrjIndex]++;
						m_nCurrentLotCount++;
					}
				}
			}
			else
			{
				m_nCurrentLotCount++;
				if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
					m_nCurrentLotCount++;
			}
		}
		else 
			ErrMessage(_T("Not Normal PCB must be Processed Manually."));
		
		m_bMissFire = FALSE;
		
	}
	m_pData->SetFiredNGInfo(m_nNGBoxCondition);
}

void CPaneAutoRun::OnTimer(UINT nIDEvent)
{
	switch(nIDEvent)
	{
	case TIMER_DISPLAY:
		if(m_bTimer1)
		{
			CFormView::OnTimer(nIDEvent);
			return;
		}
		m_bTimer1 = TRUE;
		if(m_bReadAddress)
			gDeviceFactory.GetMotor()->ReadAddressTemperatureComp(); // 장치에서 reading만 한다.
		else
			gDeviceFactory.GetMotor()->ReadTemperatureComp(); // 장치에서 reading만 한다.
		m_bReadAddress = !m_bReadAddress;
		CalcProductTime();	
		DrawDoingFireField();
		// M4116에다가 UI signal을 on/off함 (5초 이상 변화없으면 PLC에서 Shutter 강제로 닫음)
#ifndef __MP920_MOTOR__
		gDeviceFactory.GetMotor()->UiAlivePulse(m_bUiAlivePulse); 
		m_bUiAlivePulse = !m_bUiAlivePulse;
#endif
		m_bTimer1 = FALSE;
		m_nDrillEndTime++;
		m_nLilyStartTime++;
		m_nDrillOneBoardEndTime++;
		break;
	case TIMER_STATUS:
		if(m_bTimer2)
		{
			CFormView::OnTimer(nIDEvent);
			return;
		}
		m_bTimer2 = TRUE;
		ReadStatus();
		ReadDeviceError();
		UpdateLed();
#ifdef __PUSAN_LDD__
		CheckOmiVisionConnect();
#endif
#ifdef __KUNSAN_SAMSUNG_LARGE__
		OPCStatus();
#endif
#ifdef __OSAN_LG_2013__
		CheckVaccumMotor();
#endif
		m_bTimer2 = FALSE;
		break;
	case TIMER_RESET:
		if(m_bTimer3)
		{
			CFormView::OnTimer(nIDEvent);
			return;
		}
		m_bTimer3 = TRUE;
		CheckResetSwitchAndTableSuction();
		m_bTimer3 = FALSE;
		break;

	case TIMER_COMPONENT:
		if(m_bTimer4)
		{
			CFormView::OnTimer(nIDEvent);
			return;
		}
		m_bTimer4 = TRUE;
		CheckComponentTime();	
		m_bTimer4 = FALSE;
		break;	
	}
	CFormView::OnTimer(nIDEvent);
}

LRESULT CPaneAutoRun::OnAutoStartSetting(WPARAM wParam, LPARAM lParam)
{
	switch (wParam)
	{
	case FIRESTART_TIME	:		// 자동가공 시작
		m_pStepTime.Finish();
		SetProgress(FALSE);
		break;
	case FIREPAUSES_TIME	:	// 자동가공 일시정지
		m_pStepTime.Pause();
		m_pOneCycleTime.Pause();
		m_pDrillTime.Pause();
		break;
	case FIREPAUSEE_TIME	:	// 자동가공 재실행
		m_pStepTime.Pause(FALSE);
		m_pOneCycleTime.Pause(FALSE);
		m_pDrillTime.Pause(FALSE);
		break;
	case FIRENEXT_TIME	:
		m_nCycleCount++;
//		m_nCurrentLotCount++;
		m_nLotMarkCurrent++;
		m_nCurrentMarkingCount++;
		m_nTotalCurrentLotCount++;
		
		if(m_nBackupSeparation == USE_DUAL && !m_bOdd)
		{
//			m_nCurrentLotCount++;
			m_nCurrentMarkingCount++;
			m_nTotalCurrentLotCount++;
		}
				
//		if(!gProcessINI.m_sProcessSystem.bNoUseNGBox)
		{
			if(m_nBackupSeparation == USE_DUAL && !m_bOdd)
			{
				if(m_nNGBoxCondition == 3)
				{
					m_nNGLotCount += 2;
					gLotInfo.nNGLotCount[m_nCurrentPrjIndex] += 2;
				}
				else if(m_nNGBoxCondition == 1 || m_nNGBoxCondition == 2)
				{
					m_nNGLotCount++;
					gLotInfo.nNGLotCount[m_nCurrentPrjIndex]++;
					gLotInfo.nFiredLotCount[m_nCurrentPrjIndex]++;
					m_nCurrentLotCount++;
				}
				else
				{
					gLotInfo.nFiredLotCount[m_nCurrentPrjIndex] += 2;
					m_nCurrentLotCount +=2;
				}
			}
			else
			{
				if(m_nNGBoxCondition != 0)
				{
					m_nNGLotCount++;
					gLotInfo.nNGLotCount[m_nCurrentPrjIndex]++;
				}
				else
				{
					gLotInfo.nFiredLotCount[m_nCurrentPrjIndex]++;
					m_nCurrentLotCount++;
				}
			}
		}
		SetProgress(TRUE);
		CalculateAvgScale();
		ChangeLotIDInfo();
		UpdateOPCDisplay();

		if(gProcessINI.m_sProcessSystem.bUseScheduling)
		{
			if(!GetCurrentLotIndex())
			{
				m_nErrMsgID = STDGNALM1160;
				DrillStop();
				return 0L;
			}
		}

/*		if(gProcessINI.m_sProcessSystem.bUseScheduling && m_nCurrentLotCount < m_nInputLot - m_nNGLotCount ) // 20131001
		{
			if(!AutoOpenProject())
			{
				DrillStop();
				return 0L;
			}
		}
*/		break;
	case FIREEND_TIME	:
		m_pStepTime.Finish();
		m_pDrillTime.Finish();
		break;
	case FIRESTEP_TIME	:
		m_pStepTime.StartTime();
		break;
	case FIRECYCLES_TIME	:		// 1 Cycle시작
		m_pOneCycleTime.StartTime();
		break;
	case FIRECYCLEE_TIME	:		// 1 Cycle종료
		m_pOneCycleTime.Pause();
		SetCycleTime(m_nCurrentLotCount);
		break;
	case FIRESTARTDRILL_TIME	:		// 기판가공 시작
		m_pDrillTime.StartTime();
		break;
	case FIREENDDRILL_TIME		:       // 기판가공 종료
		m_pDrillTime.Pause();
		SetDrillTime(); 
		break;
	case FIREPRESENTDRILL_TIME  :
		SetPresentDrillTime();
		break;
	case FIREMARKINGSTART_TIME	: //마킹 시작 
		m_pMarkingAvgTime.StartTime();
		m_pMarkingTime.StartTime();
		break;
	case FIREMARKINGEND_TIME	: //마킹 끝 
		m_pMarkingTime.Finish();
		GetOnlyMarkingAvgTime();
		break;
	}
	
	return 1L;
}

void CPaneAutoRun::ProgressInitial()
{
	m_ctlOneTime.SetRange32(0, 100);
	m_ctlTotalTime.SetRange32(0, 100);
	m_ctlOneTime.SetPos(0);
	m_ctlTotalTime.SetPos(0);
}

void CPaneAutoRun::SetProgress(BOOL bFlag)
{
	m_bAutoTimeStart = bFlag;
	
	double dLotTime = m_pStepTime.PresentTime();
	int nOneCycle = static_cast<int>(dLotTime / 1.0 + 0.5);
	
	m_ctlOneTime.SetRange32(0, nOneCycle);
	m_ctlTotalTime.SetRange32(0, static_cast<int>(dLotTime * m_nInputLot + 0.5));
}

void CPaneAutoRun::SetCycleTime(int nLot)
{
	ASSERT(nLot >= 0);
	if (nLot == 1)
		m_dAvrTime = m_dPriTime = m_pOneCycleTime.PresentTime();
	else if (nLot > 1)
	{
		m_dPriTime = m_pOneCycleTime.PresentTime();
		if( gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
			m_dAvrTime = (m_dAvrTime * (nLot - 2) + m_dPriTime * 2) / nLot;
		else
			m_dAvrTime = (m_dAvrTime * (nLot - 1) + m_dPriTime) / nLot;
	}
	else
	{
		m_dPriTime = m_dAvrTime = 0.0;
	}
}

void CPaneAutoRun::SetDrillTime() 
{
	m_dAvrProcessTime = m_pDrillTime.PresentTime();
}

void CPaneAutoRun::SetPresentDrillTime()
{
	m_nAlignTime = gProcessINI.m_sProcessOption.nAlignTime;
	double dTime = m_pDrillTime.PresentTime();
	if( ((m_dAvrProcessTime > m_nAlignTime) && (dTime > (m_dAvrProcessTime - m_nAlignTime) * 0.7)) || (m_dAvrProcessTime - ((m_dAvrProcessTime - m_nAlignTime) * 0.7) < m_nAlignTime ))
		m_bNextAlign = TRUE;
	else
		m_bNextAlign = FALSE;
}

void CPaneAutoRun::CalcProductTime()
{
	LONG lHour, lMin, lSec;
	CString strTemp0, strTemp1;
	
	if(gProcessINI.m_sProcessSystem.bNoUseNGBox)
	{
		strTemp0.Format(_T("%d (%d)"), m_nTotalCurrentLotCount, m_nLotMarkCurrent);
		MakeReadableNumber(strTemp0);
		m_stcPCBCounter.SetWindowText((LPCTSTR)strTemp0);
	}
	else
	{
		strTemp0.Format(_T("%d(%d) NG(%d)"), m_nTotalCurrentLotCount, m_nLotMarkCurrent, m_nNGLotCount);
//		MakeReadableNumber(strTemp0);
		m_stcPCBCounter.SetWindowText((LPCTSTR)strTemp0);
	}
	

	strTemp0.Format(_T("%d"), m_nLotHoleCount);
	MakeReadableNumber(strTemp0);
	m_stcLotHole.SetWindowText((LPCTSTR)strTemp0);

	strTemp0.Format(_T("%d"), m_nTotalHoleCount);
	MakeReadableNumber(strTemp0);
	m_stcTotalHole.SetWindowText((LPCTSTR)strTemp0);

	if (m_bAutoRun)	// 자동모드
	{
		if(m_bAutoTimeStart == FALSE)
			SetProgress(m_bAutoTimeStart);

		double dTime = m_pStepTime.PresentTime();
		if (dTime > 0.0)
		{
			m_ctlOneTime.SetPos(static_cast<int>(dTime + 0.5));
			GetTime(dTime, lHour, lMin, lSec);
			strTemp0.Format(_T("%02ld:%02ld:%02ld"), lHour, lMin, lSec);
		}
		else
		{
			m_ctlOneTime.SetPos(0);
			strTemp0.Format(_T("00:00:00"));
		}

		// Total remaining time
		double dTotalTime = 0.0;
		if (m_bAutoTimeStart)
		{
			if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
			{
				if(m_nInputLot % 2)
					dTotalTime = m_dAvrTime * (m_nInputLot - m_nCurrentLotCount + 1) / 2;
				else
					dTotalTime = m_dAvrTime * (m_nInputLot - m_nCurrentLotCount) / 2;
			}
			else
				dTotalTime = m_dAvrTime * (m_nInputLot - m_nCurrentLotCount);
		}

		dTotalTime -= dTime;
		if (dTotalTime > 0.0)
		{
			int nLower, nUpper;
			m_ctlTotalTime.GetRange(nLower, nUpper);
			m_ctlTotalTime.SetPos(nUpper - static_cast<int>(dTotalTime + 0.5));
			GetTime(dTotalTime, lHour, lMin, lSec);
			strTemp1.Format(_T("%02ld:%02ld:%02ld"), lHour, lMin, lSec);
		}
		else
		{
			m_ctlTotalTime.SetPos(0);
			strTemp1.Format(_T("00:00:00"));
		}
	}
	else
	{
		double dTime = m_pStepTime.PresentTime();
		if (dTime > 0.0)
		{
			m_ctlOneTime.SetPos(static_cast<int>(dTime + 0.5));
			GetTime(dTime, lHour, lMin, lSec);
			strTemp0.Format(_T("%02ld:%02ld:%02ld"), lHour, lMin, lSec);
		}
		else
		{
			m_ctlOneTime.SetPos(0);
			strTemp0.Format(_T("00:00:00"));
		}

		strTemp1.Format(_T("00:00:00"));
		m_ctlTotalTime.SetPos(0);
	}

	GetDlgItem(IDC_STATIC_ONE_CYCLE_RUNNING_TIME)->SetWindowText((LPCTSTR)strTemp0);
	GetDlgItem(IDC_STATIC_REMAIN_TIME)->SetWindowText((LPCTSTR)strTemp1);

	if (m_dAvrTime > 0)
	{
		GetTime(m_dAvrTime, lHour, lMin, lSec);
		strTemp1.Format(_T("%02ld:%02ld:%02ld"), lHour, lMin, lSec);
	}
	else
		strTemp1.Format(_T("00:00:00"));

	if(m_bAutoRun || strTemp1 == _T("00:00:00"))
		GetDlgItem(IDC_STATIC_AVERAGE_ONE_CYCLE_TIME)->SetWindowText((LPCTSTR)strTemp1);
}

void CPaneAutoRun::GetTime(double dTime, LONG& lHour, LONG& lMin, LONG& lSec)
{
	lHour= static_cast<LONG>(dTime / 3600.);
	lMin = static_cast<LONG>((dTime  - (lHour * 3600)) / 60);
	lSec = static_cast<LONG>((dTime - ((lHour * 3600) + (lMin  * 60))));
}

void CPaneAutoRun::MakeReadableNumber(CString& strVal)
{
	int nLen = strVal.GetLength();

	CString strTemp,strTemp2;
	strTemp.Format("%s", strVal);
	strTemp2.Format("");

	BOOL bCheckComma = FALSE;
	int nStart = strVal.Find("(");
	if(nStart > 0)
	{
		bCheckComma = TRUE;
		strTemp = strVal.Left(nStart);
		strTemp2 = strVal.Mid(nStart);
		nLen = nStart-1;
	}

	if (nLen <= 3)
		return;
	else
	{
		for (int nComma = nLen - 3; nComma > 0; nComma -= 3)
		{
			strTemp.Insert(nComma, ',');
		}
	}

	strVal.Format("%s%s", strTemp, strTemp2);
}

void CPaneAutoRun::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	// Do not call CFormView::OnPaint() for painting messages
}

void CPaneAutoRun::DrawDoingFireField()
{
	CClientDC dc(GetDlgItem(IDC_STC_RUN_VIEW));
	CRect cRect;
	GetDlgItem(IDC_STC_RUN_VIEW)->GetClientRect(&cRect);
	
	int iRopOld = dc.SetROP2(R2_NOT);
	CBrush cBr2;
	CBrush *pBrushOld;
	cBr2.CreateSolidBrush(RGB(0, 0, 200));
	pBrushOld = dc.SelectObject(&cBr2);
	
	gDProject.DrawDoingFireField(&dc, cRect);
	
	dc.SetROP2(iRopOld);
	dc.SelectObject(pBrushOld);
}

void CPaneAutoRun::OnCheckSelectRun() 
{
	// TODO: Add your control notification handler code here
	if(m_bAutoRun)
		return;

	if(IsDrilling())
	{
		// Drilling
		ErrMsgDlg(STDGNALM202);
		return;
	}

	m_bSelectFire = !m_bSelectFire;
	m_ledSelectFire.Depress(!m_bSelectFire);
	gDProject.m_bSelectDrawMode = m_bSelectFire;

	ChangeProjectInfo(TRUE);
//	Invalidate(FALSE);
//	m_pData->Invalidate(FALSE);
	m_pData->DrawData();
}

void CPaneAutoRun::ReadStatus()
{
#ifdef __TEST__
	m_bAutoRun = TRUE;

#ifdef __KUNSAN_SAMSUNG_LARGE__
	CheckBasketInOut();
#endif
#else

#ifdef __MP920_MOTOR__
	HMotor* pMotor = gDeviceFactory.GetMotor();
#else
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	// Scanner Fault
	CString strError;
#ifndef __MP920_MOTOR__
	int nRet = pMotor->IsScannerFault();
#else
	int nRet = pMotor->IsStatus(IS_SCANNER_FAULT);
#endif
	if(nRet != 0)
	{
		strError = _T("");
		switch(nRet)
		{
		case 1:
			strError = "1st Panel X ";
			break;
		case 2:
			strError = "1st Panel Y ";
			break;
		case 3:
			strError = "1st Panel X and Y ";
			break;
		case 4:
			strError = "2nd Panel X ";
			break;
		case 5:
			strError = "1st Panel and 2nd Panel X ";
			break;
		case 6:
			strError = "1st Panel Y and 2nd Panel X ";
			break;
		case 7:
			strError = "1st Panel X-Y and 2nd Panel X ";
			break;
		case 8:
			strError = "2nd Panel Y ";
			break;
		case 9:
			strError = "1st Panel X and 2nd Panel Y ";
			break;
		case 10:
			strError = "1st Panel Y and 2nd Panel Y ";
			break;
		case 11:
			strError = "1st Panel X-Y and 2nd Panel Y ";
			break;
		case 12:
			strError = "2nd Panel X and Y ";
			break;
		case 13:
			strError = "1st Panel X and 2nd Panel X-Y ";
			break;
		case 14:
			strError = "1st Panel Y and 2nd Panel X-Y ";
			break;
		case 15:
			strError = "1st Panel X-Y and 2nd Panel X-Y ";
			break;
		}

		if(m_bAutoRun)
		{
			if((nRet & 0x03) && !(nRet & 0x0c))
			{
				if(gDProject.m_nSeparation == USE_1ST || m_bOdd)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);
				else 
					((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, TRUE);
			}
			else if(nRet == 4 || nRet == 8 || nRet == 12)
			{
				if(gDProject.m_nSelectFireHole == USE_2ND)
					((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);
				else
					((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, FALSE);
			}
			else
				((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE);

			DrillOneCycle();			
		}
		::ErrMsgDlg(STDGNALM434, strError);
	}
	// M2 M3 homing
	if(0x100 & pMotor->GetCurrentError(STATUS_IO1))
	{
		m_nMotorInitialCount++;
		if(!IsDrilling() && m_nMotorInitialCount == 5) // 2.5초
		{
#ifdef __SERVO_MOTOR__
			pMotor->SetOrigin(AXIS_M2);
			pMotor->SetOrigin(AXIS_M3);
#endif
		}
	}
	else
		m_nMotorInitialCount = 0;
	
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		if(gProcessINI.m_sProcessSystem.bLaserErrorCheck)
		{
			if(gDeviceFactory.GetLaser()->IsDutyError())
			{
				if(IsDrilling())
					DrillStop();
				ErrMsgDlg(STDGNALM310);
			}
// 			if(gDeviceFactory.GetLaser()->IsDigitalReflectError())
// 			{
// 				if(IsDrilling())
// 					DrillStop();
// 				ErrMsgDlg(STDGNALM312);
// 			}
			if(gDeviceFactory.GetLaser()->IsVSWRError())
			{
				if(IsDrilling())
					DrillStop();
				ErrMsgDlg(STDGNALM311);
			}
		}
	}
	// Water Flow
	int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
	BOOL bPower;
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
		gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
		gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		bPower = nPower;
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		if(nPower & 0x02)
			bPower = TRUE;
		else
			bPower = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_HYBRID)
	{
		if(nPower & 0x03)
			bPower = TRUE;
		else
			bPower = FALSE;
	}
	if(!gProcessINI.m_sProcessSystem.bNoUseChillerAlarm)
	{
#ifndef __MP920_MOTOR__
		if(bPower && pMotor->IsFlowWater() && gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
#else
		if(bPower && pMotor->IsStatus(IS_FLOW_WATER) && gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
#endif
		{
			if(IsDrilling())
				DrillStop();
			::ErrMsgDlg(STDGNALM429);
		}
	}

#ifndef __MP920_MOTOR__
	if(bPower && pMotor->IsLaserSystemWarning() && gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		m_nLaserWaringCnt ++;
		if(m_nLaserWaringCnt > 5)
		{
			if(IsDrilling())
				DrillStop();
			::ErrMsgDlg(STDGNALM594);
			m_nLaserWaringCnt = 0;
		}
	}
	else
		m_nLaserWaringCnt = 0;
#endif

#ifndef __MP920_MOTOR__
	if(bPower && pMotor->IsLaserOverTempFault() && gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		m_nLaserOverTempCnt++;
		if(m_nLaserOverTempCnt > 5)
		{
			if(IsDrilling())
				DrillStop();
			::ErrMsgDlg(STDGNALM595);
			m_nLaserOverTempCnt = 0;
		}
	}
	else
		m_nLaserOverTempCnt = 0;
#endif
	int nScannerPower = gDeviceFactory.GetMotor()->GetScannerStatus(); 
	bPower = bPower || nScannerPower;

	if(!gProcessINI.m_sProcessSystem.bNoUseChillerAlarm)
	{
		if(bPower && !pMotor->GetChillerRun() && gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
		{
			if(IsDrilling())
				DrillStop();

			TurnOffAllLaserDevice();
			::ErrMsgDlg(STDGNALM1030);
		}
	}


	m_bModeNew = pMotor->GetCurrentMode();
	if(m_bModeNew != m_bModeOld && (m_bModeNew == MODE_AUTO || m_bModeNew == MODE_MANUAL))
	{
		m_bModeOld = m_bModeNew;

		if(m_bModeNew == MODE_AUTO)
			m_bAutoRun = TRUE;
		else if(m_bModeNew == MODE_MANUAL)
			m_bAutoRun = FALSE;

		SetAutoRun();
	}
	

#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->GetRMSType() == 0)
		CheckBasketInOut();
#endif
#endif
}

void CPaneAutoRun::ReadDeviceError()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	m_lErrorIo1New = pMotor->GetCurrentError(ERROR_IO);
	if(m_lErrorIo1New != m_lErrorIo1Old)
	{
		m_lErrorIo1Old = m_lErrorIo1New;
		ReadErrorIo1();
	}

	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV ||
		gSystemINI.m_sHardWare.nLaserType == LASER_HYBRID) // 20090629 Front Mode error 
	{
		HLaser* pLaser = gDeviceFactory.GetLaser();
		int nMode = pLaser->GetAviaTriggerMode();
		m_nTimeCheckTrigger++;
		if(m_nTimeCheckTrigger >= 40)
		{
			m_nUVTriggerMode = nMode;
			if(m_nUVTriggerMode == 2) // front mode
			{
				pMotor->SetError(TRUE);
				gDeviceFactory.GetLaser()->ShutterOpen(FALSE);
				pMotor->MotorShutterAll(FALSE, FALSE);
				m_bEStop = TRUE;
				DrillStop();
				gDeviceFactory.GetEocard()->LaserOnOff(FALSE);
				ErrMsgDlg(STDGNALM308);
			}
			m_nTimeCheckTrigger = 40;
		}
	}

#ifndef __ADD_MELSEC_MOTOR__
	m_lErrorLoad1New = pMotor->GetCurrentError(ERROR_LOAD);
	if(m_lErrorLoad1New != m_lErrorLoad1Old)
	{
		m_lErrorLoad1Old = m_lErrorLoad1New;
		ReadErrorLoad1();
	}

	m_lErrorLoad2New = pMotor->GetCurrentError(ERROR_LOAD2);
	if(m_lErrorLoad2New != m_lErrorLoad2Old)
	{	
		m_lErrorLoad2Old = m_lErrorLoad2New;
		ReadErrorLoad2();
	}

	m_lErrorLoad3New = pMotor->GetCurrentError(ERROR_LOAD3);
	if(m_lErrorLoad3New != m_lErrorLoad3Old)
	{		
		m_lErrorLoad3Old = m_lErrorLoad3New;
		ReadErrorLoad3();
	}

	m_lErrorUnload1New = pMotor->GetCurrentError(ERROR_UNLOAD);
	if(m_lErrorUnload1New != m_lErrorUnload1Old)
	{		
		m_lErrorUnload1Old = m_lErrorUnload1New;
		ReadErrorUnload1();
	}

	m_lErrorUnload2New = pMotor->GetCurrentError(ERROR_UNLOAD2);
	if(m_lErrorUnload2New != m_lErrorUnload2Old)
	{		
		m_lErrorUnload2Old = m_lErrorUnload2New;
		ReadErrorUnload2();
	}

	m_lErrorUnload3New = pMotor->GetCurrentError(ERROR_UNLOAD3);
	if(m_lErrorUnload3New != m_lErrorUnload3Old)
	{		
		m_lErrorUnload3Old = m_lErrorUnload3New;
		ReadErrorUnload3();
	}
#endif
	
	m_lErrorTableLimit1New = pMotor->GetCurrentError(ERROR_TABLELIMIT);
	if(m_lErrorTableLimit1New != m_lErrorTableLimit1Old)
	{		
		m_lErrorTableLimit1Old = m_lErrorTableLimit1New;
		ReadErrorTableLimit1();
	}

	m_lErrorOtherLimit1New = pMotor->GetCurrentError(ERROR_OTHERLIMIT);
	if(m_lErrorOtherLimit1New != m_lErrorOtherLimit1Old)
	{		
		m_lErrorOtherLimit1Old = m_lErrorOtherLimit1New;
		ReadErrorOtherLimit1();
	}

	m_lErrorLaser1New = pMotor->GetCurrentError(ERROR_LASER);
	if(m_lErrorLaser1New != m_lErrorLaser1Old)
	{		
		m_lErrorLaser1Old = m_lErrorLaser1New;
		ReadErrorLaser1();
	}
	if(m_lErrorLaser1New & 0x0001)
		m_nChillerErrorCount++;
	else
		m_nChillerErrorCount = 0;

	
	if(m_nChillerErrorCount > 10) // 5sec
	{
		m_nChillerErrorCount = 0;
		if(!gProcessINI.m_sProcessSystem.bNoUseChillerAlarm)
		{
			if(IsDrilling())
				DrillStop();
			TurnOffAllLaserDevice();
		}
	}

	m_lErrorOthers1New = pMotor->GetCurrentError(ERROR_OTHERS);
	if(m_lErrorOthers1New != m_lErrorOthers1Old)
	{		
		m_lErrorOthers1Old = m_lErrorOthers1New;
		ReadErrorOthers1();
	}

	m_lErrorOthers2New = pMotor->GetCurrentError(ERROR_OTHERS2);
	if(m_lErrorOthers2New != m_lErrorOthers2Old)
	{	
		m_lErrorOthers2Old = m_lErrorOthers2New;
		ReadErrorOthers2();
	}

	m_lErrorOthers3New = pMotor->GetCurrentError(ERROR_OTHERS3);
	if(m_lErrorOthers3New != m_lErrorOthers3Old)
	{		
		m_lErrorOthers3Old = m_lErrorOthers3New;
		ReadErrorOthers3();
	}
		AOMAlarmCheck();



	m_lErrorOthers4New = pMotor->GetCurrentError(ERROR_OTHERS4);
	if(m_lErrorOthers4New != m_lErrorOthers4Old)
	{		
		m_lErrorOthers4Old = m_lErrorOthers4New;
		ReadErrorOthers4();
	}

	m_lErrorOthers5New = pMotor->GetCurrentError(ERROR_OTHERS5);
	if(m_lErrorOthers5New != m_lErrorOthers5Old)
	{		
		m_lErrorOthers5Old = m_lErrorOthers5New;
		ReadErrorOthers5();
	}
#ifdef __OSAN_LG__
	m_lErrorOthers6New = pMotor->GetCurrentError(ERROR_OTHERS6);
	if(m_lErrorOthers6New != m_lErrorOthers6Old)
	{		
		m_lErrorOthers6Old = m_lErrorOthers6New;
		ReadErrorOthers6();
	}
#endif
	m_lErrorTable1New = pMotor->GetCurrentError(ERROR_TABLE);
	if(m_lErrorTable1New != m_lErrorTable1Old)
	{		
		m_lErrorTable1Old = m_lErrorTable1New;
		ReadErrorTable1();
	}

	m_lErrorMelsecMainNew = pMotor->GetCurrentError(ERROR_HANDLER_MAIN);
	if(m_lErrorMelsecMainNew != m_lErrorMelsecMainOld)
	{		
		m_lErrorMelsecMainOld = m_lErrorMelsecMainNew;
		ReadErrorMelsecMain();
	}

	m_lErrorMelsecLoaderNew = pMotor->GetCurrentError(ERROR_HANDLER_LOADER);
	if(m_lErrorMelsecLoaderNew != m_lErrorMelsecLoaderOld)
	{		
		m_lErrorMelsecLoaderOld = m_lErrorMelsecLoaderNew;
		ReadErrorMelsecLoader();
	}

	m_lErrorMelsecUnloaderNew = pMotor->GetCurrentError(ERROR_HANDLER_UNLOADER);
	if(m_lErrorMelsecUnloaderNew != m_lErrorMelsecUnloaderOld)
	{		
		m_lErrorMelsecUnloaderOld = m_lErrorMelsecUnloaderNew;
		ReadErrorMelsecUnloader();
	}

	m_lErrorMelsecEtc1New = pMotor->GetCurrentError(ERROR_HANDLER_ETC1);
	if(m_lErrorMelsecEtc1New != m_lErrorMelsecEtc1Old)
	{		
		m_lErrorMelsecEtc1Old = m_lErrorMelsecEtc1New;
		ReadErrorMelsecEtc1();
	}

	m_lErrorMelsecEtc2New = pMotor->GetCurrentError(ERROR_HANDLER_ETC2);
	if(m_lErrorMelsecEtc2New != m_lErrorMelsecEtc2Old)
	{		
		m_lErrorMelsecEtc2Old = m_lErrorMelsecEtc2New;
		ReadErrorMelsecEtc2();
	}
}

void CPaneAutoRun::ReadErrorIo1()
{
	CString strLog;

	if(m_lErrorIo1New & 0x0001) // em stop
	{
		strLog.Format(_T("[MB6100] EM Stop"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		gDeviceFactory.GetLaser()->ShutterOpen(FALSE);
		m_pMotor->MotorShutterAll(FALSE, FALSE);
		m_bEStop = TRUE;
		DrillStop();
		gDeviceFactory.GetEocard()->LaserOnOff(FALSE);
		ErrMsgDlg(STDGNALM605);
	}
	else
	{
		m_bEStop = FALSE;
	}
#ifdef __PUSAN_LDD__
	if(m_lErrorIo1New & 0x0002) // Dust Suction Error
	{
		strLog.Format(_T("[MB6101] Dust Suction Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM989);
	}
#else
	if(m_lErrorIo1New & 0x0002) // servo power off
	{
		strLog.Format(_T("[MB6101] ServoPower Off"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM446);
	}
#endif

	if(m_lErrorIo1New & 0x0004) // main station initial error
	{
		strLog.Format(_T("[MB6102] Main InitErr"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM447);
	}
	if(m_lErrorIo1New & 0x0008)
	{
	}

	if(m_lErrorIo1New & 0x0010) // front door open
	{
		strLog.Format(_T("[MB6104] FrontDoor Open"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(gProcessINI.m_sProcessSystem.bLoaderUnloaderDoorLock)
		{
			if(IsDrilling())
			{
				gDeviceFactory.GetLaser()->ShutterOpen(FALSE);
				m_pMotor->MotorShutterAll(FALSE, FALSE);
				DrillStop();
				gDeviceFactory.GetEocard()->LaserOnOff(FALSE);
				ErrMsgDlg(STDGNALM468);
			}
			else
			{
				ErrMsgDlg(STDGNALM473);
			}
		}
	}
	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
	{
		if(m_lErrorIo1New & 0x0020) // dust collector overload
		{
			if(IsDrilling())
			{
				gDeviceFactory.GetLaser()->ShutterOpen(FALSE);
				m_pMotor->MotorShutterAll(FALSE, FALSE);
				DrillStop();
			}
			ErrMsgDlg(STDGNALM547);
		}
	}
	else
	{
		if(m_lErrorIo1New & 0x0020) // rear door open
		{
			strLog.Format(_T("[MB6105] RearDoor Open"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(gProcessINI.m_sProcessSystem.bLoaderUnloaderDoorLock)
			{
				if(IsDrilling())
				{
					gDeviceFactory.GetLaser()->ShutterOpen(FALSE);
					m_pMotor->MotorShutterAll(FALSE, FALSE);
					DrillStop();
					gDeviceFactory.GetEocard()->LaserOnOff(FALSE);
					ErrMsgDlg(STDGNALM469);
				}
				else
				{
					ErrMsgDlg(STDGNALM474);
				}
			}
		}
	}

	if(m_lErrorIo1New & 0x0040) // laser power off
	{
		strLog.Format(_T("[MB6107] LaserPower Off"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(!gProcessINI.m_sProcessSystem.bDryRun)
		{
			if(IsDrilling())
				DrillStop();
			ErrMsgDlg(STDGNALM303);
		}
	}
	if(m_lErrorIo1New & 0x0080) // main air error
	{
		strLog.Format(_T("[MB6108] MainAir Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
		{
			if(IsDrilling())
				DrillStop();
			ErrMsgDlg(STDGNALM432);
		}
	}
#ifndef __PUSAN_LDD__
#ifndef __CUNGJU_JASMINE_OLD__
	if(m_lErrorIo1New & 0x0100) // heightsensor up error
	{
		strLog.Format(_T("[MB6132] HeightSensor UpErr"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM424);
	}

	if(m_lErrorIo1New & 0x0200) // heightsensor down error
	{
		strLog.Format(_T("[MB6133] HeightSensor DownErr"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM425);
	}
#endif
	if(m_lErrorIo1New & 0x0400) // loader door open
	{
		strLog.Format(_T("[MB6207] LoaderDoor Open"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(!gProcessINI.m_sProcessSystem.bLoaderUnloaderDoorLock)
		{
			if(IsDrilling())
			{
				DrillStop();
				ErrMsgDlg(STDGNALM467);
			}
			else
			{
				ErrMsgDlg(STDGNALM472);
			}
		}
	}

	if(m_lErrorIo1New & 0x0800) // unloader door open
	{
		strLog.Format(_T("[MB6307] UnloaderDoor Open"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(!gProcessINI.m_sProcessSystem.bLoaderUnloaderDoorLock)
		{
			if(IsDrilling())
			{
				DrillStop();
				ErrMsgDlg(STDGNALM470);
			}
			else
			{
				ErrMsgDlg(STDGNALM471);
			}
		}
	}

	if(m_lErrorIo1New & 0x1000) // shutter1 open error
	{
		strLog.Format(_T("[MB6128] 1stShutter OpenErr"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM413);
	}
#endif
	if(m_lErrorIo1New & 0x2000) // shutter1 close error
	{
		strLog.Format(_T("[MB6129] 1stShutter CloseErr"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM415);
	}
	if(m_lErrorIo1New & 0x4000) // shutter2 open error
	{
		strLog.Format(_T("[MB6130] 2ndShutter OpenErr"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM414);
	}
	if(m_lErrorIo1New & 0x8000) // shutter2 close error
	{
		strLog.Format(_T("[MB6131] 2ndShutter CloseErr"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM416);
	}
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if((m_lErrorIo1New & 0x10000) && gProcessINI.m_sProcessSystem.bLoaderUnloaderDoorLock) // Main Door InOut Sensor Alarm
	{
		strLog.Format(_T("[MB5412] Main Door InOut Sensor Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
		{
			DrillStop();
			ErrMsgDlg(STDGNALM1035);
		}
	}
#endif
}

void CPaneAutoRun::ReadErrorLoad1()
{
	if(m_lErrorLoad1New & 0x0001) // loader stop error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM418);
	}
	if(m_lErrorLoad1New & 0x0002) // loader stop error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM419);
	}
	if(m_lErrorLoad1New & 0x0008) // loader picker1 pcb no exist 
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM431);
	}
	
	if(m_lErrorLoad1New & 0x0010) // loader picker1 pcb exist
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM433);
	}
#ifndef __CUNGJU_LG__
	if(m_lErrorLoad1New & 0x0020) // loader picker2 pcb exist
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM449);
	}
	if(m_lErrorLoad1New & 0x0040) // loader picker2 pcb nonexist
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM449);
	}
#endif
	if(m_lErrorLoad1New & 0x0080) // loader initialize error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM450);
	}
	
	if(m_lErrorLoad1New & 0x0100) // loader align table pcb nonexist
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM451);
	}
	if(m_lErrorLoad1New & 0x0200) // loader align table pcb exist
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM451);
	}
	if(m_lErrorLoad1New & 0x0400) // loader picker1 pad1 up error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM452);
	}
	if(m_lErrorLoad1New & 0x0800) // loader picker1 pad1 down error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM452);
	}
#ifdef __PUSAN2__
		if(m_lErrorLoad1New & 0x1000) // loader picker1 pad1 down2 error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM452);
	}
#else
	if(m_lErrorLoad1New & 0x1000) // loader picker1 pad2 up error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM452);
	}
#endif
	if(m_lErrorLoad1New & 0x2000) // loader picker1 pad2 down error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM452);
	}
	if(m_lErrorLoad1New & 0x4000) // loader picker1 vacuum on error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM453);
	}
	if(m_lErrorLoad1New & 0x8000) // loader picker1 vacuum off error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM453);
	}
	if(m_lErrorLoad1New & 0x10000) // loader picker1 drop e-stop 위험 지역 자재 떨어뜨림
	{
		if(IsDrilling())
			DrillStop();
		CString strMessage;
		strMessage.Format(_T("loader picker1 drop e-stop"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage));
		ErrMsgDlg(STDGNALM433);
	}
}

void CPaneAutoRun::ReadErrorLoad2()
{
	if(m_lErrorLoad2New & 0x0001) // loader picker1 blow on error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM453);
	}
	if(m_lErrorLoad2New & 0x0002) // loader picker2 pad1 up error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM454);
	}
	if(m_lErrorLoad2New & 0x0004) // loader picker2 pad1 down error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM454);
	}
#ifdef __PUSAN2__
		if(m_lErrorLoad2New & 0x0008) // loader picker2 pad1 down2 error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM454);
	}
#else
	if(m_lErrorLoad2New & 0x0008) // loader picker2 pad2 up error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM454);
	}
#endif
	
	if(m_lErrorLoad2New & 0x0010) // loader picker2 pad2 down error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM454);
	}
	if(m_lErrorLoad2New & 0x0020) // loader picker2 vacuum on error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM455);
	}
	if(m_lErrorLoad2New & 0x0040) // loader picker2 vacuum off error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM455);
	}
	if(m_lErrorLoad2New & 0x0080) // loader picker2 blow on error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM455);
	}
	
	if(m_lErrorLoad2New & 0x0100) // loader cart clamp error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM456);
	}
	if(m_lErrorLoad2New & 0x0200) // loader cart unclamp error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM456);
	}
	if(m_lErrorLoad2New & 0x0400) // loader align sheet table forward error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM457);
	}
	if(m_lErrorLoad2New & 0x0800) // loader align sheet table backward error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM457);
	}
	
	if(m_lErrorLoad2New & 0x1000) // loader align guide forward error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM458);
	}
	if(m_lErrorLoad2New & 0x2000) // loader align guide backward error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM458);
	}
	if(m_lErrorLoad2New & 0x4000) // loader align table left move error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM459);
	}
	if(m_lErrorLoad2New & 0x8000) // loader align table right move error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM459);
	}
}

void CPaneAutoRun::ReadErrorLoad3()
{
	if(m_lErrorLoad3New & 0x0001) // loader elevator loadpos error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM460);
	}
	if(m_lErrorLoad3New & 0x0002) // loader elevator originpos error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM460);
	}
	if(m_lErrorLoad3New & 0x0004) // loader elevator sensor error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM461);
	}
	if(m_lErrorLoad3New & 0x0008) // loader carrier cartpos error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM462);
	}
	
	if(m_lErrorLoad3New & 0x0010) // loader carrier loadpos error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM462);
	}
	if(m_lErrorLoad3New & 0x0020) // loader carrier motion param error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM463);
	}
	if(m_lErrorLoad3New & 0x0040) // loader carrier fault
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM463);
	}
	if(m_lErrorLoad3New & 0x0080) // loader carrier fatalfollowing error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM463);
	}
	
	if(m_lErrorLoad3New & 0x0100) // loader carrier openloop
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM463);
	}
	if(m_lErrorLoad3New & 0x0200) // loader carrier homing timeover
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM464);
	}
	if(m_lErrorLoad3New & 0x0400) // loader picker1 pcb ready error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM465);
	}
	if(m_lErrorLoad3New & 0x0800) // loader picker2 pcb ready error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM465);
	}
#ifndef __CUNGJU_JASMINE_NEW__
		if(m_lErrorLoad3New & 0x1000) // loader cart detect sensor error
		{
			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM466);
		}
	#ifdef __KUNSAN_1__
		if(m_lErrorLoad3New & 0x2000) // Loader Picker Danger
		{
			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM978);
		}
	#else
		if(m_lErrorLoad3New & 0x2000) // loader Elv. axis limit error
		{
			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM551);
		}
	#endif
#endif
	if(m_lErrorLoad3New & 0x4000) // loader no pcb error
	{
		m_nErrMsgID = STDGNALM421;
	}
	if(m_lErrorLoad3New & 0x8000) // Loader Carrier Axis Stop Error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM463);
	}
	if(m_lErrorLoad3New & 0x10000) // 
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM554);
	}
#ifdef __PUSAN2__
	if(m_lErrorLoad3New & 0x20000) // Loader Left Picker Fall PCB Error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM553);
	}
	if(m_lErrorLoad3New & 0x40000) // Loader carrier align pos err
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM462);
	}

	if(m_lErrorLoad3New & 0x80000) // Loader Process Time Over Error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM1083);
	}

#endif
}

void CPaneAutoRun::ReadErrorUnload1()
{
	if(m_lErrorUnload1New & 0x0001) // unloader stop error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM475);
	}

	if(m_lErrorUnload1New & 0x0002) // unloader stop error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM476);
	}
	if(m_lErrorUnload1New & 0x0004) // unloader table pcb exist error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM477);
	}
	if(m_lErrorUnload1New & 0x0008) // unloader table pcb nonexist error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM477);
	}
	
	if(m_lErrorUnload1New & 0x0010) // unloader picker1 pcb nonexist error 
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM478);
	}
	if(m_lErrorUnload1New & 0x0020) // unloader picker1 pcb exist error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM478);
	}
	if(m_lErrorUnload1New & 0x0040) // unloader picker2 pcb nonexist error 
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM479);
	}
	if(m_lErrorUnload1New & 0x0080) // unloader picker2 pcb exist error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM479);
	}
	
	if(m_lErrorUnload1New & 0x0100) // unloader picker1 pad1 up error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM480);
	}
	if(m_lErrorUnload1New & 0x0200) // unloader picker1 pad1 down error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM480);
	}
#ifdef __PUSAN2__
	if(m_lErrorUnload1New & 0x0400) // unloader picker1 pad2 down2 error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM480);
	}
#else
	if(m_lErrorUnload1New & 0x0400) // unloader picker1 pad2 up error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM480);
	}
#endif
	if(m_lErrorUnload1New & 0x0800) // unloader picker1 pad2 down error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM480);
	}
	
	if(m_lErrorUnload1New & 0x1000) // unloader picker1 vacuum on error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM482);
	}
	if(m_lErrorUnload1New & 0x2000) // unloader picker1 vacuum off error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM482);
	}
	if(m_lErrorUnload1New & 0x4000) // unloader picker1 blow on error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM482);
	}
	if(m_lErrorUnload1New & 0x8000) // unloader picker2 pad1 up error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM481);
	}
}

void CPaneAutoRun::ReadErrorUnload2()
{
#ifdef __PUSAN2__
	if(m_lErrorUnload2New & 0x0001) // unloader picker2 pad1 down error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM481);
	}
#else
	if(m_lErrorUnload2New & 0x0001) // unloader picker2 pad1 down2 error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM481);
	}
#endif

	if(m_lErrorUnload2New & 0x0002) // unloader picker2 pad2 up error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM481);
	}
	if(m_lErrorUnload2New & 0x0004) // unloader picker2 pad2 down error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM481);
	}
	if(m_lErrorUnload2New & 0x0008) // unloader picker2 vacuum on error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM483);
	}
	
	if(m_lErrorUnload2New & 0x0010) // unloader picker2 vacuum off error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM483);
	}
	if(m_lErrorUnload2New & 0x0020) // unloader picker2 blow on error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM483);
	}
	if(m_lErrorUnload2New & 0x0040) // unloader cart clamp error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM484);
	}
	if(m_lErrorUnload2New & 0x0080) // unloader cart unclamp error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM484);
	}
	
	if(m_lErrorUnload2New & 0x0100) // unloader align table left move error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM485);
	}
	if(m_lErrorUnload2New & 0x0200) // unloader align table right move error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM485);
	}
	if(m_lErrorUnload2New & 0x0400) // unloader elevator loadpos error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM486);
	}
	if(m_lErrorUnload2New & 0x0800) // unloader elevator originpos error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM486);
	}
	
	if(m_lErrorUnload2New & 0x1000) // unloader elevator sensor error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM487);
	}
	if(m_lErrorUnload2New & 0x2000) // unloader carrier unloadpos error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM488);
	}
	if(m_lErrorUnload2New & 0x4000) // unloader carrier cartpos error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM488);
	}
	if(m_lErrorUnload2New & 0x8000) // unloader carrier motion param error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM489);
	}
	if(m_lErrorUnload2New & 0x10000) // unLoader carrier align pos err
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM488);
	}
}

void CPaneAutoRun::ReadErrorUnload3()
{
	if(m_lErrorUnload3New & 0x0001) // unloader carrier fault
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM489);
	}
	if(m_lErrorUnload3New & 0x0002) // unloader carrier fatalfollowing error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM489);
	}
	if(m_lErrorUnload3New & 0x0004) // unloader carrier openloop
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM489);
	}
	if(m_lErrorUnload3New & 0x0008) // unloader carrier homing timeover
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM490);
	}
	
	if(m_lErrorUnload3New & 0x0010) // unloader picker1 pcb ready error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM491);
	}
	if(m_lErrorUnload3New & 0x0020) // unloader picker2 pcb ready error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM491);
	}
	if(m_lErrorUnload3New & 0x0040) // unloader initialize error
	{
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM493);
	}
#ifndef __CUNGJU_JASMINE_NEW__
		if(m_lErrorUnload3New & 0x0080) // unloader cart detect sensor error
		{
			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM492);
		}
	#ifdef __KUNSAN_1__
		if(m_lErrorUnload3New & 0x0100) // unloader Picker Danger Error
		{
			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM558);
		}
	#else
		if(m_lErrorUnload3New & 0x0100) // unloader Elv. axis limit error
		{
			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM555);
		}

		if(m_lErrorUnload3New & 0x0200) // unloader right picker status error
		{
			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM556);
		}
		if(m_lErrorUnload3New & 0x0400) // unloader left picker status error
		{
			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM557);
		}
		if(m_lErrorUnload3New & 0x0800) // unloader picker danger error
		{
			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM558);
		}
	
		if(m_lErrorUnload3New & 0x1000) // unloader cart full
		{
	//		ErrMsgDlg(STDGNALM565);
		}
		if(m_lErrorUnload3New & 0x2000) // m_bUnloadCarrierAxisStopError
		{
			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM489);
		}
		if(m_lErrorUnload3New & 0x4000)
		{
			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM1081);
		}
		if(m_lErrorUnload3New & 0x8000)
		{
			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM1082);
		}
	#endif
#endif
}

void CPaneAutoRun::ReadErrorTableLimit1()
{
	CString strLog;

	if(m_lErrorTableLimit1New & 0x0001) // x+ limit
	{
		strLog.Format(_T("[MB6003] X (+)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM494);
	}
	if(m_lErrorTableLimit1New & 0x0002) // x- limit
	{
		strLog.Format(_T("[MB6004] X (-)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM495);
	}
	if(m_lErrorTableLimit1New & 0x0004) // y+ limit
	{
		strLog.Format(_T("[MB6011] Y (+)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM496);
	}
	if(m_lErrorTableLimit1New & 0x0008) // y- limit
	{
		strLog.Format(_T("[MB6012] Y (-)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM497);
	}
	
	if(m_lErrorTableLimit1New & 0x0040) // z1+ limit
	{
		strLog.Format(_T("[MB6019] Z1 (+)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM498);
	}
	if(m_lErrorTableLimit1New & 0x0080) // z1- limit
	{
		strLog.Format(_T("[MB6020] Z1 (-)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM499);
	}
	
	if(m_lErrorTableLimit1New & 0x0100) // z2+ limit
	{
		strLog.Format(_T("[MB6027] Z2 (+)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM500);
	}
	if(m_lErrorTableLimit1New & 0x0200) // z2- limit
	{
		strLog.Format(_T("[MB6028] Z2 (-)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM501);
	}
	if(m_lErrorTableLimit1New & 0x0400) // A1 +
	{
		strLog.Format(_T("[MB6258] A1 (+)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM580);
	}
	if(m_lErrorTableLimit1New & 0x0800) // A1 -
	{
		strLog.Format(_T("[MB6259] A1 (-)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM581);
	}
	
	if(m_lErrorTableLimit1New & 0x1000) // A2 +
	{
		strLog.Format(_T("[MB6358] A2 (+)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM585);
	}
	if(m_lErrorTableLimit1New & 0x2000) // A2 -
	{
		strLog.Format(_T("[MB6359 A2 (-)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM586);
	}
}

void CPaneAutoRun::ReadErrorOtherLimit1()
{
	CString strLog;
#ifdef __KUNSAN_1__
	if(m_lErrorOtherLimit1New & 0x0001) // Colimator1+ limit
	{
		strLog.Format(_T("[MB6043] Colimator1 (+)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM979);
	}
	if(m_lErrorOtherLimit1New & 0x0002) // Colimator1- limit
	{
		strLog.Format(_T("[MB6044] Colimator1 (-)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM980);
	}
#else
	if(m_lErrorOtherLimit1New & 0x0001) // BET1+ limit
	{
		strLog.Format(_T("[MB6051] BET1 (+)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM502);
	}
	if(m_lErrorOtherLimit1New & 0x0002) // BET1- limit
	{
		strLog.Format(_T("[MB6052] BET1 (-)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM503);
	}
#endif
	
	if(m_lErrorOtherLimit1New & 0x0004) // LC+ limit
	{
		strLog.Format(_T("[MB6251] LC (+)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
	}
	if(m_lErrorOtherLimit1New & 0x0008) // LC- limit
	{
		strLog.Format(_T("[MB6252] LC (-)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
	}
#ifdef __KUNSAN_1__
	if(m_lErrorOtherLimit1New & 0x0010) // c2+ limit
	{
		strLog.Format(_T("[MB6059] COL2 (+)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM981);
	}
	if(m_lErrorOtherLimit1New & 0x0020) // c2- limit
	{
		strLog.Format(_T("[MB6060] COL2 (-)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM982);
	}
#else
	if(m_lErrorOtherLimit1New & 0x0010) // c2+ limit
	{
		strLog.Format(_T("[MB6059] BET2 (+)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM575);
	}
	if(m_lErrorOtherLimit1New & 0x0020) // c2- limit
	{
		strLog.Format(_T("[MB6060] BET2 (-)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM576);
	}
#endif

	if(m_lErrorOtherLimit1New & 0x0040) // UC+ limit
	{
		strLog.Format(_T("[MB6351] UC (+)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

	}
	if(m_lErrorOtherLimit1New & 0x0080) // UC- limit
	{
		strLog.Format(_T("[MB6352] UC (-)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
	}
	
	if(m_lErrorOtherLimit1New & 0x0100) // m1+ limit
	{
		strLog.Format(_T("[MB6035] M (+)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();

		if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
			ErrMsgDlg(STDGNALM548);
		else
			ErrMsgDlg(STDGNALM508);
	}
	if(m_lErrorOtherLimit1New & 0x0200) // m1- limit
	{
		strLog.Format(_T("[MB6036] M (-)Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();

		if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
			ErrMsgDlg(STDGNALM549);
		else
			ErrMsgDlg(STDGNALM509);
	}
#ifndef __KUNSAN_SAMSUNG_LARGE__
	#ifndef __SERVO_MOTOR__
		if(m_lErrorOtherLimit1New & 0x0400) // m2+ limit
		{
			strLog.Format(_T("[MB6043] M2 (+)Limit"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillStop();
			ErrMsgDlg(STDGNALM570);
		}
		if(m_lErrorOtherLimit1New & 0x0800) // m2- limit
		{
			strLog.Format(_T("[MB6044] M2 (-)Limit"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillStop();
			ErrMsgDlg(STDGNALM571);
		}
	#endif
#else
	if(m_lErrorOtherLimit1New & 0x0400) // Axis A1 + Limit 
	{
		strLog.Format(_T("[MB6067] Axis A1 Positive Limit Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM580);
	}
	if(m_lErrorOtherLimit1New & 0x0800) // Axis A1 - Limit 
	{
		strLog.Format(_T("[MB6068] Axis A1 Negative Limit Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM581);
	}
	if(m_lErrorOtherLimit1New & 0x1000) // Axis A2 + Limit 
	{
		strLog.Format(_T("[MB6075] Axis A2 Positive Limit Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM585);
	}
	if(m_lErrorOtherLimit1New & 0x2000) // Axis A2 - Limit 
	{
		strLog.Format(_T("[MB6076] Axis A2 Negative Limit Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM586);
	}

#endif
}

void CPaneAutoRun::ReadErrorLaser1()
{
}

void CPaneAutoRun::ReadErrorOthers1()
{
	CString strLog;

#ifdef __PUSAN1__	
	if( (m_lErrorOthers1New & 0x0001) ) // M1 Servo Drive Alarm
	{
		strLog.Format(_T("[MB6212] M1 Servo Drive Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM973);
	}
	if( (m_lErrorOthers1New & 0x0002) ) // B1 Servo Drive Alarm
	{
		strLog.Format(_T("[MB6213] B1 Servo Drive Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM592);
	}
	if( (m_lErrorOthers1New & 0x0004) ) // B2 Servo Drive Alarm
	{
		strLog.Format(_T("[MB6214] B2 Servo Drive Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM593);
	}
#endif
	
#ifdef __PUSAN2__ 
	if( (m_lErrorOthers1New & 0x0001) ) // M1 Servo Drive Alarm
	{
		strLog.Format(_T("[MB6212] M1 Servo Drive Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM973);
	}
	if( (m_lErrorOthers1New & 0x0002) ) // B1 Servo Drive Alarm
	{
		strLog.Format(_T("[MB6213] B1 Servo Drive Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM592);
	}
	if( (m_lErrorOthers1New & 0x0004) ) // B2 Servo Drive Alarm
	{
		strLog.Format(_T("[MB6214] B2 Servo Drive Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM593);
	}
#endif
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if( (m_lErrorOthers1New & 0x0001) ) //  Chiller Unit Alarm
	{
		strLog.Format(_T("[MB5425] Chiller Unit Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM1029);
	}
#endif
	
	if(m_lErrorOthers1New & 0x0010) // table1 vacuum on error
	{
		strLog.Format(_T("[MB6124] Table1 Vacuum On Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
		{
			if(gProcessINI.m_sProcessOption.bCheckSuctionError)
			{
				if(IsDrilling())
					DrillStop();
				ErrMsgDlg(STDGNALM519);
			}
			else
			{
				if(IsDrilling())
					DrillOneCycle();
				ErrMsgDlg(STDGNALM519);
			}
		}
	}
	if(m_lErrorOthers1New & 0x0020) // table1 vacuum off error
	{
		strLog.Format(_T("[MB6125] Table1 Vacuum Off Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
		{
			if(gProcessINI.m_sProcessOption.bCheckSuctionError)
			{
				if(IsDrilling())
					DrillStop();
				ErrMsgDlg(STDGNALM519);
			}
			else
			{
				if(IsDrilling())
					DrillOneCycle();
				ErrMsgDlg(STDGNALM519);
			}
		}
	}
	if(m_lErrorOthers1New & 0x0040) // table2 vacuum on error
	{
		strLog.Format(_T("[MB6126] Table2 Vacuum On Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
		{
			if(gProcessINI.m_sProcessOption.bCheckSuctionError)
			{
				if(IsDrilling())
					DrillStop();
				ErrMsgDlg(STDGNALM520);
			}
			else
			{
				if(IsDrilling())
					DrillOneCycle();
				ErrMsgDlg(STDGNALM520);
			}
			
		}
	}
	if(m_lErrorOthers1New & 0x0080) // table2 vacuum off error
	{
		strLog.Format(_T("[MB6127] Table2 Vacuum Off Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
		{
			if(gProcessINI.m_sProcessOption.bCheckSuctionError)
			{
				if(IsDrilling())
					DrillStop();
				ErrMsgDlg(STDGNALM520);
			}
			else
			{
				if(IsDrilling())
					DrillOneCycle();
				ErrMsgDlg(STDGNALM520);
			}
		}
	}

	if(m_lErrorOthers1New & 0x0100) // powerdetector sensor forward error
	{
		strLog.Format(_T("[MB6134] PowerDetector Sensor Forward Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM521);
	}
	if(m_lErrorOthers1New & 0x0200) // powerdetector sensor backward error
	{
		strLog.Format(_T("[MB6135] PowerDetector Sensor Backward Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM521);
	}
#ifdef __PUSAN2__
	if(m_lErrorOthers1New & 0x0400) // M1 Servo Error
	{
		strLog.Format(_T("[MB6038] M1 Servo Drive Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM973);
	}
	if(m_lErrorOthers1New & 0x0800) // BET1 Servo Error
	{
		strLog.Format(_T("[MB6054] BET1 Servo Drive Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM592);
	}
	
	if(m_lErrorOthers1New & 0x1000) // BET2 Servo Error
	{
		strLog.Format(_T("[MB6062]  BET2 Servo Drive Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM593);
	}
#else
	if(m_lErrorOthers1New & 0x0400) // x position error
	{
		strLog.Format(_T("[MB6137] X Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM522);
	}
	if(m_lErrorOthers1New & 0x0800) // y position error
	{
		strLog.Format(_T("[MB6138] Y Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM523);
	}
	
	if(m_lErrorOthers1New & 0x1000) // xy load position error
	{
		strLog.Format(_T("[MB6140] XY Load Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM562);
	}
#endif
#ifndef __KUNSAN_SAMSUNG_LARGE__
	if(m_lErrorOthers1New & 0x2000) // xy position error
	{
		strLog.Format(_T("[MB6139] XY Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM524);
	}
	if(m_lErrorOthers1New & 0x4000) // xy unload position error
	{
		strLog.Format(_T("[MB6141] XY Unload Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM563);
	}
	if(m_lErrorOthers1New & 0x8000) // xy unload 2 position error
	{
		strLog.Format(_T("[MB6142] XY Unload2 Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM564);
	}

	if(m_lErrorOthers1New & 0x20000) // Suction Hood Air Open/Close Error
	{
		strLog.Format(_T("[MB6136] Suction Hood Air Open/Close Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM972);
	}
#else
	if(m_lErrorOthers1New & 0x2000) // Axis A1 Fault 
	{
		strLog.Format(_T("[MB6064] Axis A1 Fault"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM1010);
	}
	if(m_lErrorOthers1New & 0x4000) // Axis A1 Fatal Following Err 
	{
		strLog.Format(_T("[MB6065] Axis A1 Following Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM1011);
	}
	if(m_lErrorOthers1New & 0x8000) // Axis A1 Open Loop 
	{
		strLog.Format(_T("[MB6066] Axis A1 Open Loop Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM1012);
	}
	
	if(m_lErrorOthers1New & 0x40000) // Axis A1 Homing Time out  
	{
		strLog.Format(_T("[MB6069] Axis A1 Homing Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM1013);
	}
	if(m_lErrorOthers1New & 0x80000) // Axis A1 Servo
	{
		strLog.Format(_T("[MB6070] Axis A1 Servo Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM590);
	}
	if(m_lErrorOthers1New & 0x100000) // Axis A1 Param
	{
		strLog.Format(_T("[MB6164] Axis A1 Parameter Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM583);
	}
#endif
}

void CPaneAutoRun::ReadErrorOthers2()
{
	CString strLog;

	if(m_lErrorOthers2New & 0x0001) // xy motion param error
	{
		strLog.Format(_T("[MB6157] XY Motion Param Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM525);
	}
	if(m_lErrorOthers2New & 0x0002) // z1 motion param error
	{
		strLog.Format(_T("[MB6158] Z1 Motion Param Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM526);
	}
	if(m_lErrorOthers2New & 0x0004) // z2 motion param error
	{
		strLog.Format(_T("[MB6159] Z2 Motion Param Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM527);
	}
	if(m_lErrorOthers2New & 0x0008) // m1 motion param error
	{
		strLog.Format(_T("[MB6160] M1 Motion Param Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM528);
	}
	
#ifdef __KUNSAN_1__
	if(m_lErrorOthers2New & 0x0010) // C1 motion param error
	{
		strLog.Format(_T("[MB6162] COL1 Motion Param Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM983);
	}
	if(m_lErrorOthers2New & 0x0020 && gSystemINI.m_sHardWare.nTableClamp) // M2 motion param error
	{
		strLog.Format(_T("[MB6162] M2 Motion Param Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM573);
	}
	if(m_lErrorOthers2New & 0x0040) // C2 motion param error
	{
		strLog.Format(_T("[MB6163] COL2 Motion Param Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();

		ErrMsgDlg(STDGNALM984);
	}
#else
	if(m_lErrorOthers2New & 0x0010) // BET1 motion param error
	{
		strLog.Format(_T("[MB6162] BET1 Motion Param Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM529);
	}
	if(m_lErrorOthers2New & 0x0020 && gSystemINI.m_sHardWare.nTableClamp) // table 1 clamp error
	{
		strLog.Format(_T("[MB6062] TableClamp1 Sensor Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM530);
	}
	if(m_lErrorOthers2New & 0x0040) // m1 fault
	{
		strLog.Format(_T("[MB6032] M1 Fault"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		
		if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
			ErrMsgDlg(STDGNALM550);
		else
			ErrMsgDlg(STDGNALM532);
	}
#endif

	if(m_lErrorOthers2New & 0x0080) // m1 fatalfollowing error
	{
		strLog.Format(_T("[MB6033] M1 FatalFollowing Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
		DrillStop();

		if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
			ErrMsgDlg(STDGNALM550);
		else
			ErrMsgDlg(STDGNALM532);
	}
	
	if(m_lErrorOthers2New & 0x0100) // m1 openloop
	{
		strLog.Format(_T("[MB6034] M1 OpenLoop"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();

		if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
			ErrMsgDlg(STDGNALM550);
		else
			ErrMsgDlg(STDGNALM532);
	}
	if(m_lErrorOthers2New & 0x0200) // m1 homing timeover
	{
		strLog.Format(_T("[MB6037] M1 Homing TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();

		if(gEasyDrillerINI.m_clsHwOption.GetMotorType() == MOTOR_UMAC_PROGRAM)
			ErrMsgDlg(STDGNALM550);
		else
			ErrMsgDlg(STDGNALM532);
	}
#ifdef __KUNSAN_1__
	if(m_lErrorOthers2New & 0x0400) // C1 fault
	{
		strLog.Format(_T("[MB6040] COL1 Fault"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM985);
	}
	if(m_lErrorOthers2New & 0x0800) // C1 fatalfollowing error
	{
		strLog.Format(_T("[MB6041] COL1 FatalFollowing Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM985);
	}
	
	if(m_lErrorOthers2New & 0x1000) // C1 openloop
	{
		strLog.Format(_T("[MB60442] COL1 OpenLoop"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM985);
	}
	if(m_lErrorOthers2New & 0x2000) // C1 homing timeover
	{
		strLog.Format(_T("[MB6045] COL1 Homing TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM985);
	}
#else
	if(m_lErrorOthers2New & 0x0400) // BET1 fault
	{
		strLog.Format(_T("[MB6048] BET1 Fault"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM533);
	}
	if(m_lErrorOthers2New & 0x0800) // BET1 fatalfollowing error
	{
		strLog.Format(_T("[MB6049] BET1 FatalFollowing Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM533);
	}
	
	if(m_lErrorOthers2New & 0x1000) // BET1 openloop
	{
		strLog.Format(_T("[MB6050] BET1 OpenLoop"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM533);
	}
	if(m_lErrorOthers2New & 0x2000) // BET1 homing timeover
	{
		strLog.Format(_T("[MB6053] BET1 Homing TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM533);
	}
#endif

	if(m_lErrorOthers2New & 0x4000 &&  gSystemINI.m_sHardWare.nTableClamp) // table 2 clamp error
	{
		strLog.Format(_T("[MB6063] TableClamp2 Sensor Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM531);
	}
	if(m_lErrorOthers2New & 0x8000) // M2 Motion Error
	{
		strLog.Format(_T("[MB6161] M2 Motion Param Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM573);
	}
	if(m_lErrorOthers2New & 0x00100000) // BET2 MotioAn Error
	{
		strLog.Format(_T("[MB6163] BET2 Motion Param Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM578);
	}
	if(m_lErrorOthers2New & 0x00040000) // BET2 Oopen Loop
	{
		strLog.Format(_T("[MB6058] BET2 OpenLoop"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM577);
	}
	if(m_lErrorOthers2New & 0x00080000) // BET2 Homing TimeOut
	{
		strLog.Format(_T("[MB6061] BET2 Homing TimeOut"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM577);
	}
	if(m_lErrorOthers2New & 0x00010000) // BET2 Fault
	{
		strLog.Format(_T("[MB6056] BET2 Fault"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM577);
	}
	if(m_lErrorOthers2New & 0x00020000) // BET2 Fatal Following Error
	{
		strLog.Format(_T("[MB6057] BET2 FatalFollowing Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM577);
	}
}

void CPaneAutoRun::ReadErrorOthers3()
{
	CString strLog;

	if(m_lErrorOthers3New & 0x0001) // z1 position error
	{
		strLog.Format(_T("[MB6144] Z1 Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM534);
	}
	if(m_lErrorOthers3New & 0x0002) // z1 stop error
	{
		strLog.Format(_T("[MB6145] Z1 Stop Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM514);
	}
	if(m_lErrorOthers3New & 0x0004) // z2 position error
	{
		strLog.Format(_T("[MB6146] Z2 Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM535);
	}
	if(m_lErrorOthers3New & 0x0008) // z2 stop error
	{
		strLog.Format(_T("[MB6147] Z2 Stop Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM515);
	}
	
	if(m_lErrorOthers3New & 0x0010) // m1 position error
	{
		strLog.Format(_T("[MB6148] M1 Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM536);
	}
	if(m_lErrorOthers3New & 0x0020) // m1 stop error
	{
		strLog.Format(_T("[MB6149] M1 Stop Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM532);
	}
#ifdef __KUNSAN_1__
	if(m_lErrorOthers3New & 0x0040) // C1 position error
	{
		strLog.Format(_T("[MB6150] COL1 Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM987);
	}
	if(m_lErrorOthers3New & 0x0080) // C1 stop error
	{
		strLog.Format(_T("[MB6151] COL1 Stop Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM985);
	}
	
#ifndef __PUSAN_LDD__
	#ifndef __PUSAN_OLD_32__
	if(m_lErrorOthers3New & 0x0100) // m2 position error
	{
		strLog.Format(_T("[MB6152] M2 Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM574);
	}
	if(m_lErrorOthers3New & 0x0200) // m2 stop error
	{
		strLog.Format(_T("[MB6153] M2 Stop Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM572);
	}
	#endif
#endif
	if(m_lErrorOthers3New & 0x0400) // C2 positoin error
	{
		strLog.Format(_T("[MB6154] COL2 Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM988);
	}
	if(m_lErrorOthers3New & 0x0800) // C2 stop error
	{
		strLog.Format(_T("[MB6155] COL2 Stop Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM986);
	}
	if(m_lErrorOthers3New & 0x1000) // mpg on
	{
		//비워두나
	}
#else
	if(m_lErrorOthers3New & 0x0040) // BET1 position error
	{
		strLog.Format(_T("[MB6152] BET1 Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM537);
	}
	if(m_lErrorOthers3New & 0x0080) // BET1 stop error
	{
		strLog.Format(_T("[MB6153] BET1 Stop Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM533);
	}
#ifdef __PUSAN2__

#else
	#ifndef __PUSAN_OLD_32__
		#ifndef __PUSAN_OLD_17__
			#ifndef __PUSAN1__
				#ifndef __KUNSAN_SAMSUNG_LARGE__
					if(m_lErrorOthers3New & 0x0100) // m2 position error
					{
						strLog.Format(_T("[MB6150] M2 Position Err"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
			
						if(IsDrilling())
							DrillStop();
						ErrMsgDlg(STDGNALM574);
					}

					if(m_lErrorOthers3New & 0x0200) // m2 stop error
					{
						strLog.Format(_T("[MB6151] M2 Stop Err"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
					
						if(IsDrilling())
							DrillStop();
						ErrMsgDlg(STDGNALM572);
					}
				#endif
			#endif	
		#endif
	#endif
#endif

	if(m_lErrorOthers3New & 0x0400) // BET2 positoin error
	{
		strLog.Format(_T("[MB6154] BET2 Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM579);
	}
	if(m_lErrorOthers3New & 0x0800) // BET2 stop error
	{
		strLog.Format(_T("[MB6155] BET2 Stop Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM577);
	}
	if(m_lErrorOthers3New & 0x1000) // mpg on
	{
		strLog.Format(_T("[MB6106] MPG On Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		ErrMsgDlg(STDGNALM559);
	}
#endif


	if(m_lErrorOthers3New & 0x2000) // z2 openloop
	{
		strLog.Format(_T("[MB6026] Z2 OpenLoop"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM515);
	}
	if(m_lErrorOthers3New & 0x4000) // z2 homing timeover
	{
		strLog.Format(_T("[MB6029] Z2 Homing TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM515);
	}
	if(m_lErrorOthers3New & 0x8000) // M1 Fault
	{
		strLog.Format(_T("[MB6032] M1 Fault"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM532);
	}
#ifdef __KUNSAN_SAMSUNG_LARGE__
	/* A2는 예비용 
	if(m_lErrorOthers3New & 0x10000) // Axis A2 Fault 
	{
		strLog.Format(_T("[MB6072] Axis A2 Fault"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM1005);
	}
	if(m_lErrorOthers3New & 0x20000) // Axis A2 Fatal Following Err 
	{
		strLog.Format(_T("[MB6073] Axis A2 Following Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM1006);
	}
	if(m_lErrorOthers3New & 0x40000) // Axis A2 Open Loop 
	{
		strLog.Format(_T("[MB6074] Axis A2 Open Loop Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM1007);
	}

	if(m_lErrorOthers3New & 0x200000) // Axis A2 Homing Time out  
	{
		strLog.Format(_T("[MB6077] Axis A2 Homing Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM1008);
	}
	if(m_lErrorOthers3New & 0x400000) // Axis A2 Servo
	{
		strLog.Format(_T("[MB6078] Axis A2 Servo Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM591);
	}
	if(m_lErrorOthers3New & 0x800000) // Axis A2 Param
	{
		strLog.Format(_T("[MB6165] Axis A2 Parameter Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM588);
	}
	*/
#endif
}

void CPaneAutoRun::ReadErrorOthers4()
{
	CString strLog;
#ifndef __CUNGJU_JASMINE_NEW__
	if(m_lErrorOthers4New & 0x0002) // 1sttable pcb exist error
	{
		strLog.Format(_T("[MB6112] 1stTable PCB Exist Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
		{
			if(IsDrilling())
				DrillStop();
			ErrMsgDlg(STDGNALM538);
		}
	}
	if(m_lErrorOthers4New & 0x0004) // 1sttable pcb nonexist error
	{
		strLog.Format(_T("[MB6113] 1stTable PCB NotExist Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
		{
			if(IsDrilling())
				DrillStop();
			ErrMsgDlg(STDGNALM1016);
		}
	}
	if(m_lErrorOthers4New & 0x0008) // 2ndtable pcb exist error
	{
		strLog.Format(_T("[MB6114] 2ndTable PCB Exist Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
		{
			if(IsDrilling())
				DrillStop();
			ErrMsgDlg(STDGNALM539);
		}
	}
	
	if(m_lErrorOthers4New & 0x0010) // 2ndtable pcb nonexist error
	{
		strLog.Format(_T("[MB6115] 2ndTable PCB NotExist Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
		{
			if(IsDrilling())
				DrillStop();
			ErrMsgDlg(STDGNALM1015);
		}

	}
#endif
	if(m_lErrorOthers4New & 0x0020) // MPG On Alarm
	{
		strLog.Format(_T("[MB6106] MPG On Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		ErrMsgDlg(STDGNALM559);
	}

#ifdef __PUSAN1__	
	if(m_lErrorOthers4New & 0x0040) // BeamPath UpDown
	{
		strLog.Format(_T("[MB6054] Beam Pass1 Up/Down Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM974);
	}
	if(m_lErrorOthers4New & 0x0080) // BeamPath Updown2
	{
		strLog.Format(_T("[MB6055] Beam Pass2 Up/Down Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM975);
	}
	
	if(m_lErrorOthers4New & 0x0100) // Suction Hood Air Open Err
	{
		strLog.Format(_T("[MB6116] Suction Hood Air Open Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM972);
	}
	if(m_lErrorOthers4New & 0x0200) // Suction Hood Air Close Err
	{
		strLog.Format(_T("[MB6117] Suction Hood Air Close Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM972);
	}
	if(m_lErrorOthers4New & 0x8000) // Tophat Fwd Err
	{
		strLog.Format(_T("[MB6120] Tophat Fwd Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM568);
	}
	if(m_lErrorOthers4New & 0x10000) // Tophat Bwd Err
	{
		strLog.Format(_T("[MB6121] Tophat Bwd Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM568);
	}
/*	if(m_lErrorOthers4New & 0x20000) // Laser System Warning
	{
		strLog.Format(_T("[MB6311] Laser System Warning"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM594);
	}
	if(m_lErrorOthers4New & 0x40000) // Laser Over Temp Fault 
	{
		strLog.Format(_T("[MB6312] Laser Over Temp Fault Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM595);
	}*/
	if(m_lErrorOthers4New & 0x80000) // Dust Suction Error
	{
		strLog.Format(_T("[MB5431] Dust Suction Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		//		if(IsDrilling())
		//			DrillStop();
		ErrMsgDlg(STDGNALM989);
	}
#endif
	
#ifdef __PUSAN2__ 
	if(m_lErrorOthers4New & 0x0040) // BeamPath UpDown
	{
		strLog.Format(_T("[MB6054] Beam Pass1 Up/Down Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM974);
	}
	if(m_lErrorOthers4New & 0x0080) // BeamPath Updown2
	{
		strLog.Format(_T("[MB6055] Beam Pass2 Up/Down Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM975);
	}
	
	if(m_lErrorOthers4New & 0x0100) // Suction Hood Air Open Err
	{
		strLog.Format(_T("[MB6116] Suction Hood Air Open Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM972);
	}
	if(m_lErrorOthers4New & 0x0200) // Suction Hood Air Close Err
	{
		strLog.Format(_T("[MB6117] Suction Hood Air Close Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM972);
	}
	if(m_lErrorOthers4New & 0x0400) // Height Sensor2 Up Error
	{
		strLog.Format(_T("[MB6122] Height Sensor2 Up Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM569);
	}
	if(m_lErrorOthers4New & 0x0800) // Height Sensor2 Down Error
	{
		strLog.Format(_T("[MB6123] Height Sensor2 Down Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM569);
	}
	if(m_lErrorOthers4New & 0x8000) // Tophat Fwd Err
	{
		strLog.Format(_T("[MB6120] Tophat Fwd Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM568);
	}
	if(m_lErrorOthers4New & 0x10000) // Tophat Bwd Err
	{
		strLog.Format(_T("[MB6121] Tophat Bwd Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM568);
	}
/*	if( m_lErrorOthers4New & 0x20000) // Laser System Warning
	{
		strLog.Format(_T("[MB6311] Laser System Warning"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM594);
	}*/
	if(m_lErrorOthers4New & 0x40000) // BeamPass Down Error 
	{
		strLog.Format(_T("[MB6137] BeamPass Down Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM974);
	}
	if(m_lErrorOthers4New & 0x80000) // BeamPass2 Down Error 
	{
		strLog.Format(_T("[MB6139] BeamPass2 Down Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM975);
	}
/*	if(m_lErrorOthers4New & 0x100000) // Laser Over Temp Fault Error 
	{
		strLog.Format(_T("[MB6146] Laser Over Temp Fault Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM595);
	}*/
	if(m_lErrorOthers4New & 0x400000) // Dust Suction Error
	{
		strLog.Format(_T("[MB5431] Dust Suction Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		//		if(IsDrilling())
		//			DrillStop();
		ErrMsgDlg(STDGNALM989);
	}
#else
	if(m_lErrorOthers4New & 0x0800) // elv dry run err
	{
		strLog.Format(_T("[MB6119] Elv Dry Run Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM773);
	}
#endif
	
#ifdef __PUSAN_OLD_17__
	if(m_lErrorOthers4New & 0x0040) // laser 1 pass error
	{
		strLog.Format(_T("[MB6054] Laser1 Pass Sensor Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM560);
	}
	if(m_lErrorOthers4New & 0x0080) // laser 2 pass error
	{
		strLog.Format(_T("[MB6055] Laser2 Pass Sensor Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM561);
	}
	
	if(m_lErrorOthers4New & 0x0100) // NoSafetyModeErr
	{
		strLog.Format(_T("[MB6116] NoSafetyMode Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM770);
	}
	if(m_lErrorOthers4New & 0x0200) // UnUse LdUdErr
	{
		strLog.Format(_T("[MB6117] UnUse Ld Ud Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM771);
	}
	if(m_lErrorOthers4New & 0x8000) // Dust Suction Error
	{
		strLog.Format(_T("[MB5431] Dust Suction Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		ErrMsgDlg(STDGNALM989);
	}
#endif

	if(m_lErrorOthers4New & 0x1000) // loader picker not all up
	{
		strLog.Format(_T("[MB6210] L-Picker Not AllUp"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM774);
	}
	if(m_lErrorOthers4New & 0x2000) // unloader picker not all up
	{
		strLog.Format(_T("[MB6310] UL-Picker Not AllUp"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM775);
	}
	if(m_lErrorOthers4New & 0x4000) // HeightSensor2 Up/Down Err
	{
		strLog.Format(_T("[MB6123] HeightSensor2 Up/Down Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM569);
	}
#ifdef __PUSAN_OLD_32__
	if(m_lErrorOthers4New & 0x8000) // Dust Suction Error
	{
		strLog.Format(_T("[MB5431] Dust Suction Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		ErrMsgDlg(STDGNALM989);
	}
#endif
#ifdef __KUNSAN_8__
	if(m_lErrorOthers4New & 0x4000) // Dust Suction Error
	{
		strLog.Format(_T("[MB5431] Dust Suction Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		ErrMsgDlg(STDGNALM989);
	}
#endif
#ifdef __KUNSAN_6__
	if(m_lErrorOthers4New & 0x4000) // Dust Suction Error
	{
		strLog.Format(_T("[MB5431] Dust Suction Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		ErrMsgDlg(STDGNALM989);
	}
#endif
#ifdef __KUNSAN_1__
	if(m_lErrorOthers4New & 0x0020) // Dust Suction Error
	{
		strLog.Format(_T("[MB5431] Dust Suction Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		ErrMsgDlg(STDGNALM989);
	}
#endif
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(m_lErrorOthers4New & 0x200000) // Dust Suction Error
	{
		strLog.Format(_T("[MB6103] Melsec UMac Disconnect Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		ErrMsgDlg(STDGNALM1036);
	}
#endif
}

void CPaneAutoRun::ReadErrorOthers5()
{
	CString strLog;

	if(m_lErrorOthers5New & 0x0001) // A1 Fault
	{
		strLog.Format(_T("[MB6255] Att1 Fault"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM1010);
	}
	if(m_lErrorOthers5New & 0x0002) // A1 Fatal Following Err
	{
		strLog.Format(_T("[MB6256] Att1 FatalFollowing Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM1011);
	}
	if(m_lErrorOthers5New & 0x0004) // A1 Open Loop
	{
		strLog.Format(_T("[MB6257] Att1 OpenLoop"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM1012);
	}
	if(m_lErrorOthers5New & 0x0008) // A1 Homing TimeOut
	{
		strLog.Format(_T("[MB6260] Att1 Homing TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM1013);
	}

	if(m_lErrorOthers5New & 0x0010) // A1 MovePosition Err
	{
		strLog.Format(_T("[MB6038] Att1 MovePosition Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM584);
	}
	if(m_lErrorOthers5New & 0x0020) // A1 Stop Err
	{
		strLog.Format(_T("[MB6039] Att1 Stop Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM1014);
	}
	if(m_lErrorOthers5New & 0x0040) // A1 MotionParameter Err
	{
		strLog.Format(_T("[MB6030] Att1 Motion Param Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM583);
	}
#ifndef __KUNSAN_SAMSUNG_LARGE__
	if(m_lErrorOthers5New & 0x0080) // A2 Fault
	{
		strLog.Format(_T("[MB6355] Att2 Fault"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM1005);
	}

	if(m_lErrorOthers5New & 0x0100) // A2 Fatal Following ERr
	{
		strLog.Format(_T("[MB6356] Att2 FatalFollowing Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM1006);
	}
	if(m_lErrorOthers5New & 0x0200) // A2 Open Loop
	{
		strLog.Format(_T("[MB6357] Att2 OpenLoop"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM1007);
	}
	if(m_lErrorOthers5New & 0x0400) // A2 Homing TimeOut
	{
		strLog.Format(_T("[MB6360] Att2 Homing TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM1008);
	}
	if(m_lErrorOthers5New & 0x0800) // A2 MovePosition Err
	{
		strLog.Format(_T("[MB6046] Att2 Move Position Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM589);
	}

	if(m_lErrorOthers5New & 0x1000) // A2 Stop Err
	{
		strLog.Format(_T("[MB6047] Att2 Stop Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM1009);
	}
	if(m_lErrorOthers5New & 0x2000) // A2 MotionParameter Err
	{
		strLog.Format(_T("[MB6031] Att2 Motion Param Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM588);
	}
#endif
}

void CPaneAutoRun::ReadErrorOthers6()
{
#ifdef __OSAN_LG__
	CString strLog;

	if(m_lErrorOthers6New & 0x0001) // Att1 Axis Servo Drive Alarm
	{
		strLog.Format(_T("[MB6211] Att1 ServoDrive Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM590);
	}
	if(m_lErrorOthers6New & 0x0002) // Att2 Axis Servo Drive Alarm
	{
		strLog.Format(_T("[MB6212] Att2 ServoDrive Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM591);
	}
	if(m_lErrorOthers6New & 0x0004) // BET1 Axis Servo Drive Alarm
	{
		strLog.Format(_T("[MB6213] BET1 ServoDrive Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM592);
	}
	if(m_lErrorOthers6New & 0x0008) // BET2 Axis Servo Drive Alarm
	{
		strLog.Format(_T("[MB6214] BET2 ServoDrive Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM593);
	}

/*	if(m_lErrorOthers6New & 0x0010) // Laser System Warning
	{
		strLog.Format(_T("[MB6311] Laser System Warning"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM594);
	}
	if(m_lErrorOthers6New & 0x0020) // Laser Over Temp. Fault
	{
		strLog.Format(_T("[MB6312] Laser OverTemp.Fault"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM595);
	}*/
#endif
}

void CPaneAutoRun::ReadErrorTable1()
{
	CString strLog;

	if(m_lErrorTable1New & 0x0001) // xy move danger error
	{
		strLog.Format(_T("[MB6109] XY Move Danger"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM510);
	}
	if(m_lErrorTable1New & 0x0002) // xy stop error
	{
		strLog.Format(_T("[MB6143] XY Stop Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM511);
	}
	if(m_lErrorTable1New & 0x0004) // x fault
	{
		strLog.Format(_T("[MB6000] X Fault"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM512);
	}
	if(m_lErrorTable1New & 0x0008) // x fatal following error
	{
		strLog.Format(_T("[MB6001] X FatalFollowing Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM512);
	}
	
	if(m_lErrorTable1New & 0x0010) // x openloop
	{
		strLog.Format(_T("[MB6002] X OpenLoop"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM512);
	}
	if(m_lErrorTable1New & 0x0020) // x homing timeover
	{
		strLog.Format(_T("[MB6005] X Homing TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM512);
	}
	if(m_lErrorTable1New & 0x0040) // y fault
	{
		strLog.Format(_T("[MB6008] Y Fault"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM513);
	}
	if(m_lErrorTable1New & 0x0080) // y fatal following error
	{
		strLog.Format(_T("[MB6009] Y FatalFollowing Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM513);
	}
	
	if(m_lErrorTable1New & 0x0100)  // y openloop
	{
		strLog.Format(_T("[MB6010] Y OpenLoop"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM513);
	}
	if(m_lErrorTable1New & 0x0200) // y homing time over
	{
		strLog.Format(_T("[MB6013] Y Homing TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM513);
	}
	if(m_lErrorTable1New & 0x0400) // z1 fault
	{
		strLog.Format(_T("[MB6016] Z1 Fault"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM514);
	}
	if(m_lErrorTable1New & 0x0800) // z1 fatal following error
	{
		strLog.Format(_T("[MB6017] Z1 FatalFollowing Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM514);
	}
	
	if(m_lErrorTable1New & 0x1000) // z1 openloop
	{
		strLog.Format(_T("[MB6018] Z1 OpenLoop"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM514);
	}
	if(m_lErrorTable1New & 0x2000) // z1 homing timeover
	{
		strLog.Format(_T("[MB6021] Z1 Homing TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM514);
	}
	if(m_lErrorTable1New & 0x4000) // z2 fault
	{
		strLog.Format(_T("[MB6024] Z2 Fault"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM515);
	}
	if(m_lErrorTable1New & 0x8000) // z2 fatal following error
	{
		strLog.Format(_T("[MB6025] Z2 FatalFollowing Err"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
		if(IsDrilling())
			DrillStop();	
		ErrMsgDlg(STDGNALM515);
	}

	if(m_lErrorTable1New & 0x10000) // 
	{
		strLog.Format(_T("[MB6007] X Axis Servo Drive Over Temperature Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();	
		ErrMsgDlg(STDGNALM976);
	}
	if(m_lErrorTable1New & 0x20000) // 
	{
		strLog.Format(_T("[MB6015] Y Axis Servo Drive Over Temperature Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();	
		ErrMsgDlg(STDGNALM977);
	}
}

void CPaneAutoRun::ReadErrorMelsecMain()
{
	CString strLog;
#ifndef __KUNSAN_SAMSUNG_LARGE__ 
	if(m_lErrorMelsecMainNew & 0x00000002) // PLC CPU
	{
		strLog.Format(_T("[M7001] PLC CPU"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM596);
	}
	if(m_lErrorMelsecMainNew & 0x00000004) // PLC Low Battery
	{
		strLog.Format(_T("[M7002] PLC CPU LowBattery"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM597);
	}
	if(m_lErrorMelsecMainNew & 0x00000008) // PLC Fuse
	{
		strLog.Format(_T("[M7003] PLC Fuse"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM598);
	}

	if(m_lErrorMelsecMainNew & 0x00000010) // QD75Unit1
	{
		strLog.Format(_T("[M7004] QD75Unit 1"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM599);
	}
	if(m_lErrorMelsecMainNew & 0x00000020) // COM Led
	{
		strLog.Format(_T("[M7005] COM.ERR LED"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM900);
	}
	if(m_lErrorMelsecMainNew & 0x00000040) // WDT
	{
		strLog.Format(_T("[M7006] WDT Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM901);
	}
	if(m_lErrorMelsecMainNew & 0x00000080) // QD75Unit2
	{
		strLog.Format(_T("[M7007] QD75Unit 2"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM902);
	}

	if(m_lErrorMelsecMainNew & 0x00000100) // unload cart full
	{
		strLog.Format(_T("[M7008] Unloader cart Full"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM724);
	}

	if(m_lErrorMelsecMainNew & 0x00000200) // MotorPowerOff
	{
		strLog.Format(_T("[M7009] MotorPower OFF"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM903);
	}
	if(m_lErrorMelsecMainNew & 0x00000400) // MotorPowerOn
	{
		strLog.Format(_T("[M7010] MotorReady OFF"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM904);
	}
	if(m_lErrorMelsecMainNew & 0x00000800) // LdUd Air Off
	{
		strLog.Format(_T("[M7011] LdUd Air OFF"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM905);
	}

	if(m_lErrorMelsecMainNew & 0x00001000) // Emergency On 
	{
		strLog.Format(_T("[M7012] Emergency ON"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
	}
	if(m_lErrorMelsecMainNew & 0x00002000) // LdUd TimeOver
	{
		strLog.Format(_T("[M7013] LdUd TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM907);
	}
	if(m_lErrorMelsecMainNew & 0x00004000) // Ld Door Interlock
	{
		strLog.Format(_T("[M7014] Ld Door Interlock"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();	
		ErrMsgDlg(STDGNALM908);
	}
	if(m_lErrorMelsecMainNew & 0x00008000) // Ud Door Interlock
	{
		strLog.Format(_T("[M7015] Ud Door Interlock"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();	
		ErrMsgDlg(STDGNALM909);
	}
	
	if(m_lErrorMelsecMainNew & 0x00010000) // LdNoBasket
	{
		strLog.Format(_T("[M7016] Loader No Basket"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM960);
	}
	if(m_lErrorMelsecMainNew & 0x00020000) // UdNoBasket
	{
		strLog.Format(_T("[M7017] Unloader No Basket"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM961);
	}
	if(m_lErrorMelsecMainNew & 0x00040000) // LdPartInitial
	{
		strLog.Format(_T("[M7018] LoadPart Initial"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM962);
	}
	if(m_lErrorMelsecMainNew & 0x00080000) // UdPartInitial
	{
		strLog.Format(_T("[M7019] UnloadPart Initial"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();	
		ErrMsgDlg(STDGNALM963);
	}
#else
	if(!gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		if(m_lErrorMelsecMainNew & 0x0002 )
		{
			strLog.Format(_T("[R1060.0] EStop ALARM"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}
			ErrMsgDlg(STDGNALM1101);
		}

		if(m_lErrorMelsecMainNew & 0x0004)
		{
			strLog.Format(_T("[R1060.1] PLC BAT ALARM"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1102);
		}

		if(m_lErrorMelsecMainNew & 0x0008 )
		{
			strLog.Format(_T("[R1060.2] AIR Down ALARM"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1103);
		}

		if(m_lErrorMelsecMainNew & 0x0010 )
		{
			strLog.Format(_T("[R1060.3] Door Open ALARM"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1104);

		}
		if(m_lErrorMelsecMainNew & 0x0020 )
		{
			strLog.Format(_T("[R1060.4] 1 Axis Drive ALARM"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1105);
		}
		if(m_lErrorMelsecMainNew & 0x0040 )
		{
			strLog.Format(_T("[R1060.5] 2 Axis Drive ALARM"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1106);
		}
		if(m_lErrorMelsecMainNew & 0x0080 )
		{
			strLog.Format(_T("[R1060.6] 3 Axis Drive ALARM"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1107);
		}

		if(m_lErrorMelsecMainNew & 0x0100 )
		{
			strLog.Format(_T("[R1060.7] 1 Axis Control ALARM"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1108);
		}

		if(m_lErrorMelsecMainNew & 0x0200 )
		{
			strLog.Format(_T("[R1060.8] 2 Axis Control ALARM"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1109);

		}
		if(m_lErrorMelsecMainNew & 0x0400 )
		{
			strLog.Format(_T("[R1060.8] 3 Axis Control ALARM"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1110);
		}
	}
#endif
}

void CPaneAutoRun::ReadErrorMelsecLoader()
{
	CString strLog;
#ifndef __KUNSAN_SAMSUNG_LARGE__
	if(m_lErrorMelsecLoaderNew & 0x00000001) // LC Origin TimeOver
	{
		strLog.Format(_T("[M7020] LC Origin TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM464);
	}
	if(m_lErrorMelsecLoaderNew & 0x00000002) // LC Moving
	{
		strLog.Format(_T("[M7021] LC Moving"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM462);
	}
	if(m_lErrorMelsecLoaderNew & 0x00000004) // LC PosData
	{
		strLog.Format(_T("[M7022] LC PosData"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM463);
	}
	if(m_lErrorMelsecLoaderNew & 0x00000008) // LC Alarm
	{
		strLog.Format(_T("[M7023] LC Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM968);
	}

	if(m_lErrorMelsecLoaderNew & 0x00000010) // LC(+)
	{
		strLog.Format(_T("[M7024] LC(+) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM504);
	}
	if(m_lErrorMelsecLoaderNew & 0x00000020) // LC(-)
	{
		strLog.Format(_T("[M7025] LC(-) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM505);
	}
	if(m_lErrorMelsecLoaderNew & 0x00000040) // LP1 Origin TimeOver
	{
		strLog.Format(_T("[M7026] LP1 Origin TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM910);
	}
	if(m_lErrorMelsecLoaderNew & 0x00000080) // LP1 Moving
	{
		strLog.Format(_T("[M7027] LP1 Moving"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM911);
	}

	if(m_lErrorMelsecLoaderNew & 0x00000100) // LP1 PosData
	{
		strLog.Format(_T("[M7028] LP1 PosData"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM912);
	}
	if(m_lErrorMelsecLoaderNew & 0x00000200) // LP1 Alarm
	{
		strLog.Format(_T("[M7029] LP1 Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM913);
	}
	if(m_lErrorMelsecLoaderNew & 0x00000400) // LP1(+)
	{
		strLog.Format(_T("[M7030] LP1(+) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM914);
	}
	if(m_lErrorMelsecLoaderNew & 0x00000800) // LP1(-)
	{
		strLog.Format(_T("[M7031] LP1(-) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM915);
	}

	if(m_lErrorMelsecLoaderNew & 0x00001000) // LP2 Origin TimeOver
	{
		strLog.Format(_T("[M7032] LP2 Origin TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM916);
	}
	if(m_lErrorMelsecLoaderNew & 0x00002000) // LP2 Moving
	{
		strLog.Format(_T("[M7033] LP2 Moving"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM917);
	}
	if(m_lErrorMelsecLoaderNew & 0x00004000) // LP2 PosData
	{
		strLog.Format(_T("[M7034] LP2 PosData"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM918);
	}
	if(m_lErrorMelsecLoaderNew & 0x00008000) // LP2 Alarm
	{
		strLog.Format(_T("[M7035] LP2 Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM919);
	}

	if(m_lErrorMelsecLoaderNew & 0x00010000) // LP2(+)
	{
		strLog.Format(_T("[M7036] LP2(+) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM920);
	}
	if(m_lErrorMelsecLoaderNew & 0x00020000) // LP2(-)
	{
		strLog.Format(_T("[M7037] LP2(-) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM921);
	}
	if(m_lErrorMelsecLoaderNew & 0x00040000) // LP3 Origin TimeOver
	{
		strLog.Format(_T("[M7040] LP3 Origin TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM922);
	}
	if(m_lErrorMelsecLoaderNew & 0x00080000) // LP3 Moving
	{
		strLog.Format(_T("[M7041] LP3 Moving"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM923);
	}

	if(m_lErrorMelsecLoaderNew & 0x00100000) // LP3 PosData
	{
		strLog.Format(_T("[M7042] LP3 PosData"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM924);
	}
	if(m_lErrorMelsecLoaderNew & 0x00200000) // LP3 Alarm
	{
		strLog.Format(_T("[M7043] LP3 Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM925);
	}
	if(m_lErrorMelsecLoaderNew & 0x00400000) // LP3(+)
	{
		strLog.Format(_T("[M7044] LP3(+) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM926);
	}
	if(m_lErrorMelsecLoaderNew & 0x00800000) // LP3(-)
	{
		strLog.Format(_T("[M7045] LP3(-) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM927);
	}
#else
	if(!gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		if(m_lErrorMelsecLoaderNew & 0x0001 )
		{
			strLog.Format(_T("[R1060.A] LD - Left Loader 1 UpDown CYL Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1111);

		}
		if(m_lErrorMelsecLoaderNew & 0x0002 )
		{
			strLog.Format(_T("[R1060.B] LD - Left Loader 2 UpDown CYL Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1112);
		}
		if(m_lErrorMelsecLoaderNew & 0x0004 )
		{
			strLog.Format(_T("[R1060.C] LD - Left Loader Vacuum Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1113);

		}
		if(m_lErrorMelsecLoaderNew & 0x0008 )
		{
			strLog.Format(_T("[R1060.D] LD - Right Loader 1 UpDown CYL Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1114);
		}
		if(m_lErrorMelsecLoaderNew & 0x0010 )
		{
			strLog.Format(_T( "[R1060.E] LD - Right Loader 2 UpDown CYL Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1115);
		}
		if(m_lErrorMelsecLoaderNew & 0x0020 )
		{
			strLog.Format(_T( "[R1060.F] LD - Right Loader Vacuum Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1116);
		}
		if(m_lErrorMelsecLoaderNew & 0x0040 )
		{
			strLog.Format(_T( "[R1061.2] LD - Align Table For/Back Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1117);
		}
		if(m_lErrorMelsecLoaderNew & 0x0080 )
		{
			strLog.Format(_T( "[R1061.3] LD - Align1 Left Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1118);

		}
		if(m_lErrorMelsecLoaderNew & 0x0100 )
		{
			strLog.Format(_T( "[R1061.4] LD - Align1 Front Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1119);

		}

		if(m_lErrorMelsecLoaderNew & 0x0200 )
		{
			strLog.Format(_T( "[R1061.5] LD - Palte Align Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1120);

		}
		if(m_lErrorMelsecLoaderNew & 0x0400 )
		{
			strLog.Format(_T( "[R1061.6] LD - Align1 R OnOff Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1121);

		}
		if(m_lErrorMelsecLoaderNew & 0x0800 )
		{
			strLog.Format(_T( "[R1061.7] LD - Cart Lock Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1122);
		}
		if(m_lErrorMelsecLoaderNew & 0x1000 )
		{
			strLog.Format(_T( "[R1061.8] LD - Lifter Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1123);
		}
		if(m_lErrorMelsecLoaderNew & 0x2000 )
		{
			strLog.Format(_T( "[R1061.A] LD - NG Table Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1124);
		}
		if(m_lErrorMelsecLoaderNew & 0x4000 )
		{
			strLog.Format(_T("[R1061.B] LD - PAPER Table  Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1125);
		}
		if(m_lErrorMelsecLoaderNew & 0x8000 )
		{
			strLog.Format(_T( "[R1063.3] LD - Left Picker PCB Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM1171);
		}
		if(m_lErrorMelsecLoaderNew & 0x10000 )
		{
			strLog.Format(_T("[R1063.4] LD - Right Picker PCB Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM1170);

		}
		if(m_lErrorMelsecLoaderNew & 0x40000 )
		{

			strLog.Format(_T("[R1063.7] LD - Wrong Pos Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}
			ErrMsgDlg(STDGNALM1150);
		}
		if(m_lErrorMelsecLoaderNew & 0x80000 )
		{

			strLog.Format(_T("[R1061.0] Load Unload Collision Pos Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}
			ErrMsgDlg(STDGNALM1151);
		}
	}
#endif
}

void CPaneAutoRun::ReadErrorMelsecUnloader()
{
	CString strLog;
#ifndef __KUNSAN_SAMSUNG_LARGE__
	if(m_lErrorMelsecUnloaderNew & 0x00000001) // UC Origin TimeOver
	{
		strLog.Format(_T("[M7046] UC Origin TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM490);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000002) // UC Moving
	{
		strLog.Format(_T("[M7047] UC Moving"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM488);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000004) // UC PosData
	{
		strLog.Format(_T("[M7048] UC PosData"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM489);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000008) // UC Alarm
	{
		strLog.Format(_T("[M7049] UC Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM969);
	}

	if(m_lErrorMelsecUnloaderNew & 0x00000010) // UC(+)
	{
		strLog.Format(_T("[M7050] UC(+) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM506);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000020) // UC(-)
	{
		strLog.Format(_T("[M7051] UC(-) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM507);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000040) // UP1 Origin TimeOver
	{
		strLog.Format(_T("[M7052] UP1 Origin TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM928);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000080) // UP1 Moving
	{
		strLog.Format(_T("[M7053] UP1 Moving"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM929);
	}

	if(m_lErrorMelsecUnloaderNew & 0x00000100) // UP1 Pos Data
	{
		strLog.Format(_T("[M7054] UP1 PosData"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM930);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000200) // UP1 Alarm
	{
		strLog.Format(_T("[M7055] UP1 Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM931);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000400) // UP1(+)
	{
		strLog.Format(_T("[M7056] UP1(+) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM932);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00000800) // UP1(-)
	{
		strLog.Format(_T("[M7057] UP1(-) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM933);
	}

	if(m_lErrorMelsecUnloaderNew & 0x00001000) // UP2 Origin TimeOver
	{
		strLog.Format(_T("[M7060] UP2 Origin TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM934);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00002000) // UP2 Moving
	{
		strLog.Format(_T("[M7061] UP2 Moving"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM935);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00004000) // UP2 PosData
	{
		strLog.Format(_T("[M7062] UP2 PosData"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM936);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00008000) // UP2 Alarm
	{
		strLog.Format(_T("[M7063] UP2 Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM937);
	}

	if(m_lErrorMelsecUnloaderNew & 0x00010000) // UP2(+)
	{
		strLog.Format(_T("[M7064] UP2(+) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM938);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00020000) // UP2(-)
	{
		strLog.Format(_T("[M7065] UP2(-) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM939);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00040000) // UP3 Origin TimeOver
	{
		strLog.Format(_T("[M7066] UP3 Origin TimeOver"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM940);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00080000) // UP3 Moving
	{
		strLog.Format(_T("[M7067] UP3 Moving"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM941);
	}

	if(m_lErrorMelsecUnloaderNew & 0x00100000) // UP3 PosData 
	{
		strLog.Format(_T("[M7068] UP3 PosData"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM942);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00200000) // UP3 Alarm
	{
		strLog.Format(_T("[M7069] UP3 Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM943);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00400000) // UP3(+)
	{
		strLog.Format(_T("[M7070] UP3(+) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM944);
	}
	if(m_lErrorMelsecUnloaderNew & 0x00800000) // UP3(-)
	{
		strLog.Format(_T("[M7071] UP3(-) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM945);
	}
#else
	if(!gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		if(m_lErrorMelsecUnloaderNew & 0x0001 )
		{
			strLog.Format(_T("[R1061.E] UD - Left Loader 1 UpDown CYL Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1126);
		}
		if(m_lErrorMelsecUnloaderNew & 0x0002 )
		{
			strLog.Format(_T("[R1061.F] UD - Left Loader 2 UpDown CYL Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1127);
		}
		if(m_lErrorMelsecUnloaderNew & 0x0004 )
		{
			strLog.Format(_T("[R1062.0] UD - Left Loader Vacuum Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1128);
		}
		if(m_lErrorMelsecUnloaderNew & 0x0008 )
		{
			strLog.Format(_T("[R1062.1] UD - Right Loader 1 UpDown CYL Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1129);
		}
		if(m_lErrorMelsecUnloaderNew & 0x0010 )
		{
			strLog.Format(_T("[R1062.2] UD - Right Loader 2 UpDown CYL Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1130);
		}
		if(m_lErrorMelsecUnloaderNew & 0x0020 )
		{
			strLog.Format(_T("[R1062.3] UD - Right Loader Vacuum Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1131);
		}
		if(m_lErrorMelsecUnloaderNew & 0x0040 )
		{
			strLog.Format(_T("[R1062.6] UD - Align Table For/Back Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1132);
		}
		if(m_lErrorMelsecUnloaderNew & 0x0080 )
		{
			strLog.Format(_T("[R1062.7] UD - Align1 Left Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1133);
		}
		if(m_lErrorMelsecUnloaderNew & 0x0100 )
		{
			strLog.Format(_T( "[R1062.8] UD - Align1 Front Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1134);
		}

		if(m_lErrorMelsecUnloaderNew & 0x0200 )
		{
			strLog.Format(_T("[R1062.9] UD - Palte Align Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1135);
		}
		if(m_lErrorMelsecUnloaderNew & 0x0400 )
		{
			strLog.Format(_T("[R1062.A] UD - Align1 R OnOff Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1136);
		}
		if(m_lErrorMelsecUnloaderNew & 0x0800 )
		{
			strLog.Format(_T("[R1062.B] UD - Cart Lock Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1137);
		}
		if(m_lErrorMelsecUnloaderNew & 0x1000 )
		{
			strLog.Format(_T("[R1062.C] UD - Lifter Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1138);
		}
		if(m_lErrorMelsecUnloaderNew & 0x2000 )
		{
			strLog.Format(_T("[R1061.E] UD - NG Table Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1139);
		}
		if(m_lErrorMelsecUnloaderNew & 0x4000 )
		{
			strLog.Format(_T("[R1061.F] UD - PAPER Table  Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1143);
		}
		if(m_lErrorMelsecUnloaderNew & 0x8000 )
		{
			strLog.Format(_T("[R1063.5] UD - Left Picker PCB Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM1173);
		}
		if(m_lErrorMelsecUnloaderNew & 0x10000 )
		{
			strLog.Format(_T( "[R1063.6] UD - Right Picker PCB Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM1172);

		}
		if(m_lErrorMelsecUnloaderNew & 0x40000  )
		{
			strLog.Format(_T( "[R1063.8] UD - Worng Pos Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1149);
		}
	}
#endif
}

void CPaneAutoRun::ReadErrorMelsecEtc1()
{
	CString strLog;
#ifndef __KUNSAN_SAMSUNG_LARGE__
	if(m_lErrorMelsecEtc1New & 0x00000001) // LdElv Homing
	{
		strLog.Format(_T("[M7080] Ld Elv Homing"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM460);
	}
	if(m_lErrorMelsecEtc1New & 0x00000002) // LdElv Loading
	{
		strLog.Format(_T("[M7081] Ld Elv Loading"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM970);
	}
	if(m_lErrorMelsecEtc1New & 0x00000004) // LdElv Alarm
	{
		strLog.Format(_T("[M7082] Ld Elv Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM461);
	}
	if(m_lErrorMelsecEtc1New & 0x00000008) // LdElv(+)
	{
		strLog.Format(_T("[M7083] Ld Elv(+) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM946);
	}

	if(m_lErrorMelsecEtc1New & 0x00000010) // LdElv(-)
	{
		strLog.Format(_T("[M7084] Ld Elv(-) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM947);
	}
	if(m_lErrorMelsecEtc1New & 0x00000020) // UdElv homing
	{
		strLog.Format(_T("[M7085] Ud Elv Homing"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM486);
	}
	if(m_lErrorMelsecEtc1New & 0x00000040) // UdElv Loading
	{
		strLog.Format(_T("[M7086] Ud Elv Loading"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM971);
	}
	if(m_lErrorMelsecEtc1New & 0x00000080) // UdElv Alarm
	{
		strLog.Format(_T("[M7087] Ud Elv Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM487);
	}

	if(m_lErrorMelsecEtc1New & 0x00000100) // UdElv(+)
	{
		strLog.Format(_T("[M7088] Ud Elv(+) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM948);
	}
	if(m_lErrorMelsecEtc1New & 0x00000200) // UdElv(-)
	{
		strLog.Format(_T("[M7089] Ud Elv(-) Limit"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM949);
	}
	if(m_lErrorMelsecEtc1New & 0x00000400) // Ld Paper Trans FwdBwd
	{
		strLog.Format(_T("[M7090] Ld Paper Trans Fwd/Bwd"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM950);
	}
	if(m_lErrorMelsecEtc1New & 0x00000800) // Ld PCB Trans FwdBwd
	{
		strLog.Format(_T("[M7091] Ld PCB Trans Fwd/Bwd"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM951);
	}

	if(m_lErrorMelsecEtc1New & 0x00001000) // Ld Align Sheet FwdBwd
	{
		strLog.Format(_T("[M7092] Ld Align Sheet Fwd/Bwd"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM457);
	}
	if(m_lErrorMelsecEtc1New & 0x00002000) // Ld Align Guide FwdBwd
	{
		strLog.Format(_T("[M7093] Ld Align Guid Fwd/Bwd"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM458);
	}
	if(m_lErrorMelsecEtc1New & 0x00004000) // Ld Cart Clamp UpDown
	{
		strLog.Format(_T("[M7094] Ld Cart Clamp Up/Down"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM456);
	}
	if(m_lErrorMelsecEtc1New & 0x00008000) // LP1 Vacuum
	{
		strLog.Format(_T("[M7095] LP1 Vacuum"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM453);
	}

	if(m_lErrorMelsecEtc1New & 0x00010000) // LP2 Vacuum
	{
		strLog.Format(_T("[M7096] LP2 Vacuum"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM455);
	}
	if(m_lErrorMelsecEtc1New & 0x00020000) // LP3 Vacuum
	{
		strLog.Format(_T("[M7097] LP3 Vacuum"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM952);
	}
	if(m_lErrorMelsecEtc1New & 0x00040000) // Ud Paper Trans FwdBwd
	{
		strLog.Format(_T("[M7098] Ud Paper Trans Fwd/Bwd"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM953);
	}
	if(m_lErrorMelsecEtc1New & 0x00080000) // Ud PCB Trans FwdBwd
	{
		strLog.Format(_T("[M7099] Ud PCB Trans Fwd/Bwd"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM954);
	}

	if(m_lErrorMelsecEtc1New & 0x00100000) // Ud Cart Clamp UpDown
	{
		strLog.Format(_T("[M7100] Ud Cart Clamp Up/Down"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM484);
	}
	if(m_lErrorMelsecEtc1New & 0x00200000) // UP1 Vacuum
	{
		strLog.Format(_T("[M7101] UP1 Vacuum"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM482);
	}
	if(m_lErrorMelsecEtc1New & 0x00400000) // UP2 Vacuum
	{
		strLog.Format(_T("[M7102] UP2 Vacuum"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM483);
	}
	if(m_lErrorMelsecEtc1New & 0x00800000) // UP3 Vacuum
	{
		strLog.Format(_T("[M7103] UP3 Vacuum"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM955);
	}

	if(m_lErrorMelsecEtc1New & 0x01000000) // Ld Cart Detect Sensor
	{
		strLog.Format(_T("[M7104] Ld Cart Detect Sensor"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM466);
	}
	if(m_lErrorMelsecEtc1New & 0x02000000) // Ud Cart Detect Sensor
	{
		strLog.Format(_T("[M7105] Ud Cart Detect Sensor"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM492);
	}
	if(m_lErrorMelsecEtc1New & 0x04000000) // LP1 Status
	{
		strLog.Format(_T("[M7106] LP1 Status"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM913);
	}
	if(m_lErrorMelsecEtc1New & 0x08000000) // LP2 Status
	{
		strLog.Format(_T("[M7107] LP2 Status"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM919);
	}

	if(m_lErrorMelsecEtc1New & 0x10000000) // LP3 Status
	{
		strLog.Format(_T("[M7108] LP3 Status"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM925);
	}
	if(m_lErrorMelsecEtc1New & 0x20000000) // Ld PCB Table Status
	{
		strLog.Format(_T("[M7109] Ld PCB Table Status"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM956);
	}
	if(m_lErrorMelsecEtc1New & 0x40000000) // Ld Paper Table Status
	{
		strLog.Format(_T("[M7110] Ld Paper Table Status"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM957);
	}
	if(m_lErrorMelsecEtc1New & 0x80000000) // UP1 Status
	{
		strLog.Format(_T("[M7111] UP1 Status"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM931);
	}
#else
	if(!gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader)
	{
		if(m_lErrorMelsecEtc1New & 0x00000001 )
		{
			strLog.Format(_T("[R1063.0] Turn Table For/Back Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1140);

		}
		if(m_lErrorMelsecEtc1New & 0x00000002)
		{
			strLog.Format(_T("[R1063.1] Trun Table Up/Down Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1141);
		}
		if(m_lErrorMelsecEtc1New & 0x00000004)
		{
			strLog.Format(_T("[R1063.2] Turn Table Vacuum Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			else
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
				Sleep(100);
				gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
			}

			ErrMsgDlg(STDGNALM1142);
		}
		if(m_lErrorMelsecEtc1New & 0x00000008)
		{
			if(!gProcessINI.m_sProcessSystem.bNoUsePaper)
			{
				strLog.Format(_T("[R1063.D] Paper No Exist"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

				if(IsDrilling())
					DrillOneCycle();
				else
				{
					gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
					Sleep(100);
					gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
				}

				ErrMsgDlg(STDGNALM1144);
			}
		}
		if(m_lErrorMelsecEtc1New & 0x00000010)
		{
			if(!gProcessINI.m_sProcessSystem.bNoUsePaper)
			{
				strLog.Format(_T("[R1063.E] Paper Box Full Alarm"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

				if(IsDrilling())
					DrillOneCycle();
				else
				{
					gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
					Sleep(100);
					gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
				}
				ErrMsgDlg(STDGNALM1145);
			}
		}
		if(m_lErrorMelsecEtc1New & 0x00000020)
		{
			if(!gProcessINI.m_sProcessSystem.bNoUseNGBox)
			{
				strLog.Format(_T("[R1063.F] NG Box Full Alarm"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

				if(IsDrilling())
					DrillOneCycle();
				else
				{
					gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
					Sleep(100);
					gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
				}
				ErrMsgDlg(STDGNALM1146);
			}
		}
		if(m_lErrorMelsecEtc1New & 0x00000040)
		{
			if(gProcessINI.m_sProcessSystem.bNoUsePaper)
			{
				strLog.Format(_T("[R1063.B] Paper Exist Alarm"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

				if(IsDrilling())
					DrillOneCycle();
				else
				{
					gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
					Sleep(100);
					gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
				}
				ErrMsgDlg(STDGNALM1148);
			}
		}
		if(m_lErrorMelsecEtc1New & 0x00000080)
		{
			if(gProcessINI.m_sProcessSystem.bNoUsePaper)
			{
				strLog.Format(_T("[R1063.C] Paper Exist Alarm"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

				if(IsDrilling())
					DrillOneCycle();
				else
				{
					gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 1);
					Sleep(100);
					gDeviceFactory.GetMotor()->SetOutPort(PORT_ALARM, 0);
				}
				ErrMsgDlg(STDGNALM1148);
			}
		}
		if(m_lErrorMelsecEtc1New & 0x00000100)
		{
			strLog.Format(_T("[R1074] Fall PCB In Danger Pos Alarm"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

			if(IsDrilling())
				DrillOneCycle();
			ErrMsgDlg(STDGNALM776);

		}
	}
#endif
}

void CPaneAutoRun::ReadErrorMelsecEtc2()
{
	CString strLog;

	if(m_lErrorMelsecEtc2New & 0x00000001) // UP2 Status
	{
		strLog.Format(_T("[M7112] UP2 Status"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM937);
	}
	if(m_lErrorMelsecEtc2New & 0x00000002) // UP3 Status
	{
		strLog.Format(_T("[M7113] UP3 Status"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM943);
	}
	if(m_lErrorMelsecEtc2New & 0x00000004) // Ud PCB Table Status
	{
		strLog.Format(_T("[M7114] Ud PCB Table Status"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM958);
	}
	if(m_lErrorMelsecEtc2New & 0x00000008) // Ud Paper Table Status
	{
		strLog.Format(_T("[M7115] Ud Paper Table Status"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillOneCycle();
		ErrMsgDlg(STDGNALM959);
	}
	if(m_lErrorMelsecEtc2New & 0x00000010) // Ld PCB Drop in Danger Place
	{
		strLog.Format(_T("[M7116] Ld PCB Drop in Danger Place"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM964);
	}
	if(m_lErrorMelsecEtc2New & 0x00000020) // Ud PCB Drop in Danger Place
	{
		strLog.Format(_T("[M7117] Ud PCB Drop in Danger Place"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM965);
	}
	if(m_lErrorMelsecEtc2New & 0x00000040) // Ld Basket Paper Full
	{
		strLog.Format(_T("[M7038] Ld Basket Paper Full"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM966);
	}
	if(m_lErrorMelsecEtc2New & 0x00000080) // Ud Elv PCB Full
	{
		strLog.Format(_T("[M7058] Ud Elv PCB Full"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(IsDrilling())
			DrillStop();
		ErrMsgDlg(STDGNALM967);
	}
}

void CPaneAutoRun::UpdateLed()
{
	
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	// Motor
	m_bMotor = pMotor->IsReady();
	m_ledMotor.Depress( !m_bMotor );
	
	// Laser
	int nPower = gDeviceFactory.GetLaser()->IsPowerOn();
	int nShutter = gDeviceFactory.GetLaser()->IsShutterOpen();
	BOOL bAOM = m_pMotor->GetAOMStatus(); // 110607
	BOOL bScanner = m_pMotor->GetScannerStatus();

	if(!bScanner)
	{
		if(m_bScannerOld != bScanner)
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, DO_SCANNER);
			CString strFile, strLog;
			strFile.Format(_T("PreWork"));
			strLog.Format(_T("AnyDo (PaneAutoRun::UpdateLed) : S"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		}
	}
	m_bScannerOld = bScanner;

	if(!nPower)
	{
		if(m_bLaserPowerOld != nPower)
		{
			::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, DO_POWER);
			CString strFile, strLog;
			strFile.Format(_T("PreWork"));
			strLog.Format(_T("AnyDo (PaneAutoRun::UpdateLed) : P"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		}
	}
	m_bLaserPowerOld = nPower;

	BOOL bPower, bShutter;
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2 ||
		gSystemINI.m_sHardWare.nLaserType == LASER_LV100 ||
		gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		bPower = nPower;
		bShutter = nShutter;
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		if(nPower & 0x02) 
			bPower = TRUE;
		else
			bPower = FALSE;
		
		if(nShutter & 0x02)
			bShutter = TRUE;
		else
			bShutter = FALSE;
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_HYBRID)
	{
		if(nPower & 0x03) 
			bPower = TRUE;
		else
			bPower = FALSE;
		
		if(nShutter & 0x03)
			bShutter = TRUE;
		else
			bShutter = FALSE;
	}

	if(gSystemINI.m_sHardWare.nLaserType == LASER_SLV263G)
		m_bLaser = gDeviceFactory.GetLaser()->IsFireOK();
	else
		m_bLaser = bPower & bShutter & bAOM & bScanner;

	m_ledLaser.Depress( !m_bLaser );

	if(gEasyDrillerINI.m_clsHwOption.GetMotorType() != MOTOR_PMAC)
	{	
		// Main Power
		m_bMainPower = pMotor->IsReady();
		m_ledMainPower.Depress( !m_bMainPower );
	
		// E-Stop
		m_bEStop = pMotor->GetCurrentEMStop();
		m_ledEStop.Depress( !m_bEStop );
	
		// Table Suction
		BOOL bMotor, b1st = TRUE, b2nd = TRUE;
		int nSuction1;
		bMotor = pMotor->GetCurrentSuctionMotor();
		nSuction1 = pMotor->GetCurrentSuction();
		
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->GetFileOpen())
		{
			if(nSuction1 & 0x01 && bMotor)
				b1st = TRUE;
			else
				b1st = FALSE;
			
			if(nSuction1 & 0x02 && bMotor)
				b2nd = TRUE;
			else
				b2nd = FALSE;
		}
		else
		{
			if(nSuction1 & 0x01 && bMotor)
				b1st = TRUE;
			else
				b1st = FALSE;

			if(nSuction1 & 0x02 && bMotor)
				b2nd = TRUE;
			else
				b2nd = FALSE;
		}

		m_bTableSuction = b1st;
		m_ledTableSuction.Depress( !m_bTableSuction );

		m_bTableSuction2 = b2nd;
		m_ledTableSuction2.Depress( !m_bTableSuction2 );
	
		// Initialization
		m_bInit = pMotor->IsInOrigin(-1, FALSE);
		m_ledInit.Depress( !m_bInit );

		// Fluorescent Lamp
		m_bFluorescentLamp = pMotor->IsFluorescentLampOn();
		m_ledFluorescentLamp.Depress( !m_bFluorescentLamp );

		// AutoRun
		m_ledAutoRun.Depress( !m_bAutoRun );

	}
	
}

void CPaneAutoRun::ChangeProjectInfo(BOOL bOnlyCount)
{
	CString strNo1, strNo2, strTotal;
	gDProject.CalculateDataCount();

	if(gEasyDrillerINI.m_clsHwOption.GetUseDualPanel() == 0)
		gDProject.m_nSeparation = USE_1ST;
	
	if(gDProject.m_nSeparation == USE_DUAL)
		GetDlgItem(IDC_STATIC_DRILL_DIVISION_VAL)->SetWindowText("Dual PNL");
	else if(gDProject.m_nSeparation == USE_1ST)
		GetDlgItem(IDC_STATIC_DRILL_DIVISION_VAL)->SetWindowText("1st PNL");
	else
		GetDlgItem(IDC_STATIC_DRILL_DIVISION_VAL)->SetWindowText("2nd PNL");

	if(m_bAutoRun)
	{
		strNo1 = GetCountString(gDProject.m_nTotalHole);
		strTotal.Format(_T("%s ( %s )"), strNo1, strNo1);
		GetDlgItem(IDC_STATIC_TOTAL_HOLE_COUNT_VAL)->SetWindowText(strTotal);
		strNo1 = GetCountString(gDProject.m_nTotalLine);
		strTotal.Format(_T("%s ( %s )"), strNo1, strNo1);
		GetDlgItem(IDC_STATIC_LINE_COUNT_VAL)->SetWindowText(strTotal);
	}
	else
	{
		if(m_bSelectFire)
		{
			strNo1 = GetCountString(gDProject.m_nTotalHole);
			strNo2 = GetCountString(gDProject.m_nSelectFireHole);
			strTotal.Format(_T("%s ( %s )"), strNo1, strNo2);
			GetDlgItem(IDC_STATIC_TOTAL_HOLE_COUNT_VAL)->SetWindowText(strTotal);
			strNo1 = GetCountString(gDProject.m_nTotalLine);
			strNo2 = GetCountString(gDProject.m_nSelectFireLine);
			strTotal.Format(_T("%s ( %s )"), strNo1, strNo2);
			GetDlgItem(IDC_STATIC_LINE_COUNT_VAL)->SetWindowText(strTotal);
			for(int i = 0; i< MAX_FID_BLOCK; i++)
			{
				gDProject.m_nSelectedFiducial[i] = -1;
			}
			CheckSelectedFiducial(gDProject.m_nSelectedFiducial); //20111128 bskim 
		}
		else
		{
			strNo1 = GetCountString(gDProject.m_nTotalHole);
			strNo2 = GetCountString(gDProject.m_nVisibleHole);
			strTotal.Format(_T("%s ( %s )"), strNo1, strNo2);
			GetDlgItem(IDC_STATIC_TOTAL_HOLE_COUNT_VAL)->SetWindowText(strTotal);
			strNo1 = GetCountString(gDProject.m_nTotalLine);
			strNo2 = GetCountString(gDProject.m_nVisibleLine);
			strTotal.Format(_T("%s ( %s )"), strNo1, strNo2);
			GetDlgItem(IDC_STATIC_LINE_COUNT_VAL)->SetWindowText(strTotal);
		}
	}

	if(bOnlyCount)
		return;

	m_listBoardParam.DeleteAllItems();
	
	SUBTOOLDATA toolData;
	LVITEM lvItem;
	lvItem.mask = LVIF_TEXT|LVIF_PARAM;
	lvItem.lParam = 1;
	lvItem.state = 0;
//	lvItem.stateMask = LVIS_SELECTED;
	int nCount = 0;
	
	for(int i = 0; i<MAX_TOOL_NO; i++)
	{
		if(!gDProject.m_pToolCode[i]->m_bUseTool)
			continue;
		//Tool No
		lvItem.iItem = nCount;
		lvItem.iSubItem = 0;
		strTotal.Format(_T("%d"), i);
		lvItem.pszText = (LPSTR)(LPCSTR)strTotal;
		m_listBoardParam.InsertItem(&lvItem);

		//Tool type
		lvItem.iItem = nCount;
		lvItem.iSubItem = 2;
		POSITION pos = gDProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		if(pos)
		{
			toolData = gDProject.m_pToolCode[i]->m_SubToolData.GetNext(pos);

			// 110311 Mask로 변경
			lvItem.iItem = nCount;
			lvItem.iSubItem = 1;
			strTotal.Format(_T("%d-%s"), gBeamPathINI.m_sBeampath.nInfoId[toolData.nMask], gBeamPathINI.m_sBeampath.strInfoName[toolData.nMask] );
			m_listBoardParam.SetItemText(nCount, 1, (LPSTR)(LPCSTR)strTotal);
			
			if(toolData.nToolType == MARKING_TYPE)
				strTotal.Format(_T("Marking"));
			else if(toolData.nToolType == SHOT_DRILL_TYPE)
				strTotal.Format(_T("ShotDrill"));
			else if(toolData.nToolType == LINE_DRILL_TYPE)
				strTotal.Format(_T("LineDrill"));
			else if(toolData.nToolType == FLYING_TYPE)
				strTotal.Format(_T("Flying"));
			else if(toolData.nToolType == TEXT_TYPE)
				strTotal.Format(_T("Text"));
			else 
				strTotal.Format(_T("Barcode"));
			m_listBoardParam.SetItemText(nCount, 2, (LPSTR)(LPCSTR)strTotal);
			
			// 110311 Duty로 변경
			lvItem.iItem = nCount;
			lvItem.iSubItem = 3;
			strTotal.Format(_T("%.2f"), gBeamPathINI.m_sBeampath.dPowCompensationDuty[toolData.nMask]);//toolData.dShotDuty[0]);
			m_listBoardParam.SetItemText(nCount, 3, (LPSTR)(LPCSTR)strTotal);
		}
		else
		{
			strTotal.Format(_T("-"));
			m_listBoardParam.SetItemText(nCount, 1, (LPSTR)(LPCSTR)strTotal);
			
			m_listBoardParam.SetItemText(nCount, 2, (LPSTR)(LPCSTR)strTotal);
			
			m_listBoardParam.SetItemText(nCount, 3, (LPSTR)(LPCSTR)strTotal);
		}
		

		//Sub Tool Shot no
		lvItem.iItem = nCount;
		lvItem.iSubItem = 4;
		strTotal = GetCountString( gDProject.GetDataNo(i) );
		m_listBoardParam.SetItemText(nCount, 4, (LPSTR)(LPCSTR)strTotal);

		nCount++;
	}
}

CString CPaneAutoRun::GetCountString(int nNo)
{
	int nSubNo;
	CString str, subStr;
	str.Format(_T(""));

	if(nNo == 0)
	{
		str.Format(_T("0"));
		return str;
	}

	while (TRUE) 
	{
		nSubNo = nNo % 1000;

		if(str.GetLength() != 0)
			subStr.Format(_T("%d"), nSubNo);
		else
		{
			if(nSubNo >= 0 && nSubNo < 10)
			{
				subStr.Format(_T("00%d"), nSubNo);
			}
			else if(nSubNo >= 10 && nSubNo < 100)
			{
				subStr.Format(_T("0%d"), nSubNo);
			}
			else if(nSubNo >= 100 && nSubNo < 1000)
			{
				subStr.Format(_T("%d"), nSubNo);
			}
		}
		nNo = nNo / 1000;
		if(nNo == 0)
		{
			if(str.GetLength() == 0)
				str = subStr;
			else 
				str = subStr + "," + str;

			return str;
		}
		else
			if(str.GetLength() == 0)
				str = subStr;
			else 
				str = subStr + "," + str;
	}

	return str;
}

BOOL CPaneAutoRun::IsGoodFireCount()
{
#ifdef __TEST__
	return TRUE;
#endif

	if(m_bAutoRun)
	{
		if(m_nLotHoleCount == gDProject.m_nTotalHole)
			return TRUE;
		else
			return FALSE;
	}
	else
	{
		if(m_bSelectFire)
		{
			if(m_nLotHoleCount == gDProject.m_nSelectFireHole)
				return TRUE;
			else
				return FALSE;
		}
		else
		{
			if(m_nLotHoleCount == gDProject.m_nVisibleHole)
				return TRUE;
			else
				return FALSE;
		}
	}
}

void CPaneAutoRun::InitTimer()
{
	if(m_nTimerID1 == 0)
		m_nTimerID1 = SetTimer(TIMER_DISPLAY, 1000, NULL);
	
	if(m_nTimerID2 == 0)
		m_nTimerID2 = SetTimer(TIMER_STATUS, 500, NULL);

	if(m_nTimerID3 == 0)
		m_nTimerID3 = SetTimer(TIMER_RESET, 100, NULL);

	if(m_nTimerID4 == 0)
		m_nTimerID4 = SetTimer(TIMER_COMPONENT, 1080000, NULL);		//3시간 마다 
}

void CPaneAutoRun::DestroyTimer()
{
	if(m_nTimerID1)
		KillTimer(m_nTimerID1);

	if(m_nTimerID2)
		KillTimer(m_nTimerID2);

	if(m_nTimerID3)
		KillTimer(m_nTimerID3);

	if(m_nTimerID4)
		KillTimer(m_nTimerID4);
}

BOOL CPaneAutoRun::WaitHandler(int nCmd, BOOL b1st, BOOL b2nd)
{
#ifdef __TEST__
	return TRUE;
#endif
	
	int nWaitTime;
	if(nCmd == HANDLER_ALIGNERSTOP)
		nWaitTime = gProcessINI.m_sProcessOption.nAlignTime * 1000 / 200; 
	else if(nCmd == HANDLER_LOADSTOP || nCmd == HANDLER_LOAD_PICKER_DOWN)
		nWaitTime = gProcessINI.m_sProcessOption.nLoadTime * 1000 / 200; 
	else
		nWaitTime = gProcessINI.m_sProcessOption.nUnloadTime * 1000 / 200; 
	int nCnt = 0;
	BOOL bCheckPick = FALSE;
	LONG lError = 0;
	
	int nGetTargetVal = 0;
	if(b1st) nGetTargetVal += 0x01;
	if(b2nd) nGetTargetVal += 0x02;
	BOOL bNoCartPCB = FALSE;
	BOOL bReverse = gDeviceFactory.GetMotor()->GetReverseDirection();
	do {
		enum { HANDLER_READY, HANDLER_ALARM, HANDLER_LOTEND, HANDLER_1STEXIST, HANDLER_2NDEXIST, 
			HANDLER_LOADREADY, HANDLER_LOADEND, HANDLER_LOADALARM, HANDLER_UNLOADREADY, HANDLER_UNLOADEND, HANDLER_UNLOADALARM,
			HANDLER_ALIGNERSTOP, HANDLER_LOADSTOP, HANDLER_UNLOADSTOP, HANDLER_UNLOAD_TO_LOADSTART};		

		switch(nCmd)
		{
		case HANDLER_ALIGNERSTOP:
#ifdef __CUNGJU_LG__
			bNoCartPCB = m_pMotor->IsLoadCartNoPCB();
			
			// AlignEnd기다리는 데 기판부족으로 PLC에서 에러 날리면 Waiting중단
			if(m_pMotor->IsLoaderPicker1PCBExist() || m_pMotor->IsAlignerPCBExist())
				bCheckPick = TRUE;
			else
				bCheckPick = FALSE;
			
			if(!bCheckPick && bNoCartPCB)
			{
				return FALSE;
			}
#endif
			if(m_pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, TRUE, FALSE) &&
				!m_pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, FALSE, FALSE))
				return TRUE;
		
#ifdef __KUNSAN_SAMSUNG_LARGE__
			bNoCartPCB = m_pMotor->IsLoadCartNoPCB();
			
			if(bNoCartPCB == TRUE)
			{
				gDeviceFactory.GetMotor()->SetOutPort(PORT_PCB_SINGLE, TRUE);
			}

			if(!bReverse)
			{
				if(m_pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(m_pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}
#else
			if(m_pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			
#endif
			
			break;
		case HANDLER_LOADSTOP:
			if(m_pMotor->IsHandlerOperation(HANDLER_LOADER_LOAD, TRUE, FALSE) &&
				!m_pMotor->IsHandlerOperation(HANDLER_LOADER_LOAD, FALSE, FALSE))
				return TRUE;

			break;
		case HANDLER_UNLOADSTOP:
			if(m_pMotor->IsHandlerOperation(HANDLER_UNLOADER_UNLOAD, TRUE, FALSE) &&
				!m_pMotor->IsHandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE, FALSE))
				return TRUE;

			break;
		case HANDLER_UNLOADRUNSTOP: // 이전 Unloading의 상태 확인
			if(!m_pMotor->IsHandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE, FALSE))
				return TRUE;


			break;
		case HANDLER_UNLOAD_TO_LOADSTART:
			if(m_bAutoRun == FALSE)  // Unloading 도중 PLC 에러가 나면 Manual로 변경이 되는데 그 상황에서는 Load Request Ready 신호가 들어오지 않는다 그러므로 도중에 manual로 변경되면 빠져나와야됨
				return FALSE;		 // Load Request Ready 신호는 AutoRun 상황에서만 들어옴

#ifndef __PUSAN_LDD__
			if(m_pMotor->IsHandlerOperation(HANDLER_UNLOADER_TO_LOAD_START, TRUE))
#else
			if(m_pMotor->IsHandlerOperation(HANDLER_UNLOADER_TO_LOAD_START, TRUE, FALSE))
#endif
				return TRUE;

			break;
		case HANDLER_LOAD_PICKER_DOWN:
			if(nGetTargetVal == m_pMotor->IsHandlerOperation(HANDLER_LOAD_PICKER_DOWN, TRUE))
				return TRUE;
#ifdef __KUNSAN_SAMSUNG_LARGE__
			if(!bReverse)
			{
				if(m_pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(m_pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}
#else
			if(m_pMotor->IsHandlerPartError(TRUE))
				return FALSE;

#endif
			break;
		case HANDLER_UNLOAD_PICKER_DOWN:
			if(nGetTargetVal == m_pMotor->IsHandlerOperation(HANDLER_UNLOAD_PICKER_DOWN, TRUE))
				return TRUE;
#ifdef __KUNSAN_SAMSUNG_LARGE__
			if(bReverse)
			{
				if(m_pMotor->IsHandlerPartError(TRUE))
				return FALSE;
			}
			else
			{
				if(m_pMotor->IsHandlerPartError(FALSE))
				return FALSE;
			}
#else
			if(m_pMotor->IsHandlerPartError(TRUE))
				return FALSE;

#endif
			break;
		}
		nCnt++;

		if(!CheckStatus())
			return FALSE;

		if( m_pMotor->IsAnyError() )
		{
			return FALSE;
		}

		if(nCnt > nWaitTime * 2)
		{
			return FALSE;
		}

		::Sleep(200);

	} while(TRUE);
	return FALSE;
}

void CPaneAutoRun::GetTime(double dTime, int& nHour, int& nMin, int& nSec)
{
	nHour= static_cast<LONG>(dTime / 3600.);
	nMin = static_cast<LONG>((dTime  - (nHour * 3600)) / 60);
	nSec = static_cast<LONG>((dTime - ((nHour * 3600) + (nMin  * 60))) + 0.5);
}

void CPaneAutoRun::WriteLotLog()
{
	CTime ctEnd = CTime::GetCurrentTime();	

	if (m_nAutoLotCount == 0)
		return;

	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CString strCurProcessLogFileName = _T("Process");
	strCurProcessLogFileName += m_ctStart.Format(_T("%Y%m%d"));
	
	::WaitForSingleObject( g_hLotFile, INFINITE );
	::ResetEvent(g_hLotFile);

	CStdioFile file;
	if (FALSE == file.Open(strPathName + strCurProcessLogFileName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
	{
		::SetEvent(g_hLotFile);
		return;
	}

	CTimeSpan ctSpan = ctEnd - m_ctStart;
	double dTime;
	if(gDProject.m_nSeparation == USE_DUAL && (m_nAutoLotCount % 2 == 1))
		dTime = ctSpan.GetTotalSeconds() / static_cast<double>(m_nAutoLotCount + 1);
	else
		dTime = ctSpan.GetTotalSeconds() / static_cast<double>(m_nAutoLotCount);

	int nTotalHoleShot = m_nTotalHoleCount, nTotalLineShot = m_nTotalLineCount;
	if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
	{
		nTotalHoleShot = nTotalHoleShot * 2;
		nTotalLineShot = nTotalLineShot * 2;
	}
	else if(gDProject.m_nSeparation == USE_DUAL && m_bOdd)
	{
		nTotalHoleShot = (nTotalHoleShot * 2) - m_nLotHoleCount;
		nTotalLineShot = (nTotalLineShot * 2) - m_nLotLineCount;
	}
	else
	{
		nTotalHoleShot;
		nTotalLineShot;
	}

	int nHour, nMin, nSec;
	GetTime(dTime, nHour, nMin, nSec);

	int nPCBHole, nPCBLine;
	int nHoleShot = m_nTotalHoleCount, nLineShot = m_nTotalLineCount;
	if(m_bAutoRun)
	{
		nPCBHole = gDProject.m_nTotalHole;
		nPCBLine = gDProject.m_nTotalLine;

		nHoleShot = gDProject.m_nVisibleHoleShot;
		nLineShot = gDProject.m_nVisibleLineShot;
	}
	else
	{
		if(m_bSelectFire)
		{
			nPCBHole = gDProject.m_nSelectFireHole;
			nPCBLine = gDProject.m_nSelectFireLine;

			nHoleShot = gDProject.m_nSelectFireHoleShot;
			nLineShot = gDProject.m_nSelectFireLineShot;
		}
		else
		{
			nPCBHole = gDProject.m_nVisibleHole;
			nPCBLine = gDProject.m_nVisibleLine;

			nHoleShot = gDProject.m_nVisibleHoleShot;
			nLineShot = gDProject.m_nVisibleLineShot;
		}
	}

	nPCBHole *= m_nAutoLotCount;
	nPCBLine *= m_nAutoLotCount;
		
	nHoleShot *= m_nAutoLotCount;
	nLineShot *= m_nAutoLotCount;
	
//	gProcessINI.m_sProcessOption.nShotCount += (nHoleShot + nLineShot);
	gProcessINI.m_sProcessOption.nShotCount += (m_nTotalHoleCount + m_nTotalLineCount);
	//////
	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	CString strDetail, strTemp;
	int nToolType, nShotMode, nFrequency, nTotalShot, nBurstShot, nMask;

	double dDuty[MAX_BEAM_HOLE], dAOMDelay[MAX_BEAM_HOLE], dAOMDuty[MAX_BEAM_HOLE], dMinFreq[MAX_BEAM_HOLE], dMaxFreq[MAX_BEAM_HOLE], dDutyOffset[MAX_BEAM_HOLE], dDrawSpeed;
	
	for(int nTool = 1; nTool < MAX_TOOL_NO; nTool++)
	{
		if(!gDProject.m_pToolCode[nTool]->m_bUseTool)
			continue;

		int nSub = gDProject.m_pToolCode[nTool]->m_SubToolData.GetCount();
		
		pToolCode = gDProject.m_pToolCode[nTool];
	
		int i = 0;
		POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();

		strTemp.Format(_T("| Tool No : %d, Total SubTool : %d --- |"), nTool, nSub);
		strDetail += strTemp;

		while(pos)
		{
			if(i == nSub) break;
		
			subData = pToolCode->m_SubToolData.GetNext(pos);

			nToolType = subData.nToolType;
			nShotMode = subData.nShotMode; // Burst, Cycle, Step
			nFrequency = gBeamPathINI.m_sBeampath.nPowCompensationFrequency[subData.nMask];//subData.nFrequency;
			nTotalShot = subData.nTotalShot;
			nBurstShot = subData.nBurstShot;
			dDrawSpeed = subData.dDrawStep;
			nMask = subData.nMask;

			switch(nToolType)
			{
			case 0:
				strTemp.Format(_T("Sub%d) ToolType = Marking | "), i+1);
				strDetail += strTemp;
				break;
			case 1:
				strTemp.Format(_T("Sub%d) ToolType = ShotDrill | "), i+1);
				strDetail += strTemp;
				break;
			case 2:
				strTemp.Format(_T("Sub%d) ToolType = LineDrill | "), i+1);
				strDetail += strTemp;
				break;
			case 3:
				strTemp.Format(_T("Sub%d) ToolType = Flying | "), i+1);
				strDetail += strTemp;
				break;
			case 4:
				strTemp.Format(_T("Sub%d) ToolType = Barcode | "), i+1);
				strDetail += strTemp;
				break;
			}

			switch(nShotMode)
			{
			case 0:
				strTemp.Format(_T("ShotMode = Burst mode |"));
				strDetail += strTemp;
				break;
			case 1:
				strTemp.Format(_T("ShotMode = Cycle mode |"));
				strDetail += strTemp;
				break;
			case 2:
				strTemp.Format(_T("ShotMode = Step mode |"));
				strDetail += strTemp;
				break;
			}
			strTemp.Format(_T("Frequency = %d Hz | Mask = %d | "), nFrequency, nMask);
			strDetail += strTemp;

			if(nToolType == MARKING_TYPE)
			{
				strTemp.Format(_T("Draw Speed = %.2f mm/s |"), dDrawSpeed);
				strDetail += strTemp;
			}

			strTemp.Format(_T("TotalShot = %d |  BurstShot = %d |"), nTotalShot, nBurstShot);
			strDetail += strTemp;

			for(int j=0; j<MAX_BEAM_HOLE; j++)
			{
				dDuty[j] = subData.dShotDuty[j];
				dAOMDelay[j] = subData.dShotAOMDelay[j];
				dAOMDuty[j] = subData.dShotAOMDuty[j];
	#ifdef __USE_DUALBAND_EOCARD__
				dMinFreq[j] = subData.dShotMinFreq[j];
				dMaxFreq[j] = subData.dShotMaxFreq[j];
#endif
				dDutyOffset[j] = gBeamPathINI.m_sBeampath.dPowOffsetDuty[nMask];
			}
			dDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationDuty[nMask];
			dAOMDelay[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[nMask];
			dAOMDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[nMask];

			for(int j=0; j<nTotalShot; j++)
			{
				#ifdef __3RDAOD__
					if(m_nUserLevel != 3)
						strTemp.Format(_T("%d-th shot) Duty = %.2f |"), j+1, dDuty[j]);
					else
						strTemp.Format(_T("%d-th shot) Duty = %.2f, MaxFreq = %.0f |"), j+1, dDuty[j], dMaxFreq[j]);
				#else
					#ifdef __USE_DUALBAND_EOCARD__
						strTemp.Format(_T("%d-th shot) Duty = %.2f, AOMDelay = %.2f, AOMDuty = %.2f, MinFreq = %.0f, MaxFreq = %.0f | "), j+1, dDuty[j], dAOMDelay[j], dAOMDuty[j],dMinFreq[j], dMaxFreq[j]);
					#else
						strTemp.Format(_T("%d-th shot) Duty = %.2f, AOMDelay = %.2f, AOMDuty = %.2f | "), j+1, dDuty[j], dAOMDelay[j], dAOMDuty[j]);
					#endif
				#endif
				strDetail += strTemp;
			}

			i++;
		}
	}
	//////

	TRY
	{
		file.SeekToEnd();
		CString strBuf, strTemp;
		strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %04d/%02d/%02d | %02d:%02d:%02d "
			"| Shots per PCB = %d | Total shots = %d | Lot count = %d "
			"| Elapsed time = %02d:%02d:%02d | Average time per PCB = %02d:%02d:%02d "
			"| Project = %s | Cad data = %s | Total Holes = %d "
			"| Lines per PCB = %d | Total Fire lines = %d | Total Lines = %d"),
				m_ctStart.GetYear(), m_ctStart.GetMonth(), m_ctStart.GetDay(), m_ctStart.GetHour(), m_ctStart.GetMinute(), m_ctStart.GetSecond(),
				ctEnd.GetYear(), ctEnd.GetMonth(), ctEnd.GetDay(), ctEnd.GetHour(), ctEnd.GetMinute(), ctEnd.GetSecond(),
				nHoleShot / m_nAutoLotCount,  nTotalHoleShot, m_nAutoLotCount,
				(int)ctSpan.GetTotalHours(), (int)ctSpan.GetMinutes(), (int)ctSpan.GetSeconds(),nHour, nMin, nSec, 
				gDProject.m_szProjectName, gDProject.m_szFileName, nPCBHole, 
				nLineShot / m_nAutoLotCount, nTotalLineShot, nPCBLine);
				//	nLineShot / m_nAutoLotCount, nLineShot, nPCBLine);
				
		// 시작날짜 | 시작시간 | 종료날짜 | 종료시간 | 한장당 가공한 shot 수 | 전체 가공한 shot 수 | 가공한 장수 |
		// 걸린 시간 | 한장당 평균 가공시간 | 프로젝트 파일이름 | 캐드데이타 파일이름 | Total Holes | 
		// 한장당 가공한 line shot수 | 전체 가공한 line shot 수 | Total Lines
		file.Write(strBuf, strBuf.GetLength());

		
		strDetail += _T("\n");
		file.Write(strDetail, strDetail.GetLength());
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		::SetEvent(g_hLotFile);
		return;
	}
	END_CATCH
	file.Close();
	::SetEvent(g_hLotFile);
}

BOOL CPaneAutoRun::CheckPCBExist()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	BOOL b1st = pMotor->IsTable1PCBExist();
	BOOL b2nd = pMotor->IsTable2PCBExist();
	BOOL b1stSuction = pMotor->GetCurrentSuction() & 0x01;
	BOOL b2ndSuction = pMotor->GetCurrentSuction() & 0x02;

	
	if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
		return ((b1st || b1stSuction) && (b2nd ||b2ndSuction));
	else if(gDProject.m_nSeparation == USE_1ST || m_bOdd)
		return b1st || b1stSuction;
	else if(gDProject.m_nSeparation == USE_2ND)
		return b2nd || b2ndSuction;

	return TRUE;
}

BOOL CPaneAutoRun::DoLoading(BOOL bEndLot, CPaneAutoRun* pRun)
{	
	CString strFile, strLog;
	strFile.Format(_T("AutorunTrace"));
	CString strSequenceLog;
	strSequenceLog.Format(_T("---Loading Start---"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
	if(!gProcessINI.m_sProcessSystem.bNoUsePrework)
		::AfxGetMainWnd()->SendMessage(UM_CHANGE_PREWORK_STATUS, DO_NOTING);
	
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	BOOL bNoCartPCB;
	BOOL bLeftPicker, bRightPicker;
	int nUsePanel;

	if(!CheckStatus())
		return FALSE;

	if(!WaitHandler(HANDLER_ALIGNERSTOP))
	{
		if(pMotor->IsLoadCartNoPCB())
			m_nErrMsgID = STDGNALM715;
		else
			m_nErrMsgID = STDGNALM721;
		
		pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, FALSE);
		pMotor->SendLoadCartNoPCB();	//No Cart PCB 신호 확인 받았음을 알림 20120918 bskim
		strLog.Format(_T("Align Time Out"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		return FALSE;
	}
	strLog.Format(_T("Align end"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, FALSE);
	strLog.Format(_T("Align off cmd down"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	bNoCartPCB = pMotor->IsLoadCartNoPCB();

	if(bNoCartPCB)
		pMotor->SendLoadCartNoPCB();	//No Cart PCB 신호 확인 받았음을 알림 20120918 bskim

	if(gDProject.m_nSeparation == USE_DUAL)
	{
		if(bNoCartPCB && m_nCurrentLotCount < m_nInputLot - m_nNGLotCount && !pRun->m_bOdd)
		{
			bLeftPicker = pMotor->IsLoaderPicker1PCBExist();
			bRightPicker = pMotor->IsLoaderPicker2PCBExist();
			
			if(!bLeftPicker && !bRightPicker)
			{
				m_nErrMsgID = STDGNALM719;
				return FALSE;
			}
			else if(bLeftPicker && !bRightPicker)
			{
				pRun->m_bOdd = TRUE;
				nUsePanel = 1;
				m_nErrMsgID = STDGNALM715;
			}
			else if(!bLeftPicker && bRightPicker)
			{
				m_nErrMsgID = STDGNALM719;
				return FALSE;
			}
		}	

		if(pRun->m_bOdd)
		{
			nUsePanel = 1;
#ifdef __PUSAN_LDD__
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, TRUE);
#else
			pMotor->SetOutPort(PORT_PCB_SINGLE, TRUE);
#endif
			strLog.Format(_T("Use panel info down : 1"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		}
		else
		{
			nUsePanel = 0;
#ifdef __PUSAN_LDD__
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, FALSE);
#else
			pMotor->SetOutPort(PORT_PCB_SINGLE, FALSE);
#endif
			strLog.Format(_T("Use panel info down : 0"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		}
	
	}
	else if(gDProject.m_nSeparation == USE_2ND)
	{
		nUsePanel = 2;
#ifdef __PUSAN_LDD__
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, 2);
#else
		pMotor->SetOutPort(PORT_PCB_SINGLE, 2);
#endif
		strLog.Format(_T("Use panel info down : 2"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	}
	else
	{
		nUsePanel = 1;
#ifdef __PUSAN_LDD__
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, TRUE);
#else
		pMotor->SetOutPort(PORT_PCB_SINGLE, TRUE);
#endif
		strLog.Format(_T("Use panel info down : 1"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	}
	if(!CheckStatus())
		return FALSE;
	
	if(m_nPreworkStep != DO_NOTING)
	{
		if(!WaitPrework()) //prework 작업 진행중에 loading 불가 
			return FALSE;
	}
	BOOL b1st, b2nd;
	if(nUsePanel == 0)
	{
		b1st = TRUE;
		b2nd = TRUE;
	}
	else if(nUsePanel == 1)
	{
		b1st = TRUE;
		b2nd = FALSE;
	}
	else 
	{
		b1st = FALSE;
		b2nd = TRUE;
	}

	if(pMotor->GetCurrentLoadDetect(nUsePanel) != PCB_NONE)
	{
#ifdef __KUNSAN_SAMSUNG_LARGE__
		BOOL bTemp1 = pMotor->GetCurrentSuction() & 0x01;
		BOOL bTemp2 = pMotor->GetCurrentSuction() & 0x02;
		if(!pMotor->SetTablePCBExist(bTemp1, bTemp2))
		{
			m_nErrMsgID = STDGNALM719;
			return FALSE;
		}
		strLog.Format(_T("Current table info down : %d, %d"), bTemp1, bTemp2);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

#endif
		pMotor->HandlerOperation(HANDLER_LOADER_LOAD, TRUE);

		strLog.Format(_T("Load on cmd down"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		if(!SubDoLoading(b1st, b2nd))
		{
			m_nErrMsgID = STDGNALM719;
			pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
			strLog.Format(_T("Load off cmd down"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

			return FALSE;
		}
		Sleep(1000);
		ChangeBMPtoJPG();
		if(!WaitHandler(HANDLER_LOADSTOP))
		{
			
			strLog.Format(_T("Load time out"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
			strLog.Format(_T("Load off cmd down"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

			m_nErrMsgID = STDGNALM719;
			return FALSE;
		}
	}
	else
	{
		pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
		strLog.Format(_T("Load off cmd down"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		m_nErrMsgID = STDGNALM719;
		return FALSE;
	}
	pMotor->HandlerOperation(HANDLER_LOADER_LOAD, FALSE);
	strLog.Format(_T("Load off cmd down"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	return TRUE;
}

BOOL CPaneAutoRun::DoUnloading(BOOL bEndLot)
{
	if(!gProcessINI.m_sProcessSystem.bNoUsePrework)
		::AfxGetMainWnd()->SendMessage(UM_CHANGE_PREWORK_STATUS, DO_NOTING);

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif


	if(!CheckStatus())
		return FALSE;
		
	CString strFile, strLog;
	strFile.Format(_T("AutorunTrace"));
	// 이전 Unloading이 안 끝났을 수 있으므로 Run이 Off되기를 기다림
	if(!WaitHandler(HANDLER_UNLOADRUNSTOP))
	{
		strLog.Format(_T("Unload time out"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		m_nErrMsgID = STDGNALM726;
		return FALSE;
	}

	if(!CheckStatus())
		return FALSE;

#ifndef __PUSAN_LDD__
#ifndef __KUNSAN_SAMSUNG_LARGE__
	if(m_pMotor->IsHandlerOperation(HANDLER_UNLOADER_TO_LOAD_START, TRUE))
	{
		m_nErrMsgID = STDGNALM726;
		return FALSE;
	}
#endif
#endif  // Unloading 전에 LoadRequestReady 신호 확인후 Unloading 진행
	m_bUnloadStart = TRUE;
	BOOL b1st, b2nd; 
	b1st = pMotor->GetCurrentSuction() & 0x01;
	b2nd = pMotor->GetCurrentSuction() & 0x02;

	if(gProcessINI.m_sProcessSystem.bDryRunNoPCB == TRUE)
	{
		if(gDProject.m_nSeparation == USE_DUAL)
		{
			b1st = TRUE;
			b2nd = TRUE;
		}
		else if(gDProject.m_nSeparation == USE_1ST)
		{
			b1st = TRUE;
			b2nd = FALSE;
		}
		else if(gDProject.m_nSeparation == USE_2ND)
		{
			b1st = FALSE;
			b2nd = TRUE;
		}
		
	}
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(!pMotor->SetTablePCBExist(b1st, b2nd))
	{
		strLog.Format(_T("Current table info down fail : %d, %d"), b1st, b2nd);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		m_nErrMsgID = STDGNALM719;
		return FALSE;
	}
	strLog.Format(_T("Current table info down : %d, %d"), b1st, b2nd);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
#endif

	pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, TRUE);
	strLog.Format(_T("Unload on cmd down"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	if(!SubDoUnloading(b1st, b2nd))
	{
		pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
		strLog.Format(_T("Unload off cmd down"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		m_nErrMsgID = STDGNALM726;
		return FALSE;
	}
	if(bEndLot)
	{
		if(!WaitHandler(HANDLER_UNLOADSTOP))
		{
			strLog.Format(_T("Unload time out"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

			pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
			strLog.Format(_T("Unload off cmd down"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

			m_nErrMsgID = STDGNALM726;
			return FALSE;
		}
	}
	else
	{
		if(!WaitHandler(HANDLER_UNLOAD_TO_LOADSTART))
		{
			strLog.Format(_T("Unload time out"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

			pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
			strLog.Format(_T("Unload off cmd down"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

			m_nErrMsgID = STDGNALM752;
			return FALSE;
		}
	}
	pMotor->HandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE);
	strLog.Format(_T("Unload off cmd down"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));


	//unloading이 제대로 되엇는지 확인하기 위해 테이블 체크 
#ifndef __TEST__
	for(int i = 0; i < 10; i++)
	{
		if(!CheckPCBExist())
			break;
		
		if(i == 0)
			return FALSE;

		Sleep(100);
	}
#endif
	m_bNeedUnload = FALSE;
	return TRUE;
}

BOOL CPaneAutoRun::IsPCBOnTable()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
#ifdef __TEST__
	return TRUE;
#endif

	if(!m_bCheckTablePCB) // pcb 자재 있음 체크 안하는 모드에서
		return TRUE;

	if(!pMotor->GetCurrentSuctionMotor())
		return FALSE;

	int nSuction1 = pMotor->GetCurrentSuction();
	BOOL b1st, b2nd;
	if(nSuction1 & 0x01)
		b1st = TRUE;
	else
		b1st = FALSE;

	if(nSuction1 & 0x02)
		b2nd = TRUE;
	else
		b2nd = FALSE;

	if(gDProject.m_nSeparation == USE_DUAL)
	{
		if(!m_bOdd)
			return (b1st && b2nd);
		else
			return b1st;
	}
	else if(gDProject.m_nSeparation == USE_1ST)
		return b1st;
	else
		return b2nd;

}

BOOL CPaneAutoRun::DustSuction()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	int nLoopMax = gVariable.m_pRefuse->m_RefuseData.GetCount();

	double dPosX, dPosY;

	POSITIONDATA posData;

	BOOL bFirst = TRUE;

	if(gSystemINI.m_sHardWare.nTableClamp > 0)
	{
		pMotor->TableClamp(TRUE, TRUE);

		::Sleep(500);

		if(gSystemINI.m_sHardWare.nTableClamp > 1)
			pMotor->TableClamp(TRUE, FALSE);

		::Sleep(200);
	}	

	int nIndex = 0;
	POSITION pos = gVariable.m_pRefuse->m_RefuseData.GetHeadPosition();
	while(pos)
	{
		posData = gVariable.m_pRefuse->m_RefuseData.GetAt(pos);
		
		dPosX = posData.dPosX;
		dPosY = posData.dPosY;

		if(!pMotor->MotorMoveXY(dPosX, dPosY))
		{
			// suction off
			return FALSE;
		}

		if(!pMotor->InPositionIO(IND_X + IND_Y))
		{
			// suction off
			return FALSE;
		}

		if(bFirst)
		{
			if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST)
				pMotor->DustSuctionControl(TRUE, FALSE);
			if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_2ND)
				pMotor->DustSuctionControl(FALSE, FALSE);

			::Sleep(1000);

			bFirst = FALSE;
		}

		::Sleep(1500);
		
		gVariable.m_pRefuse->m_RefuseData.GetNext(pos);

		nIndex++;
	}

	if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST)
		pMotor->DustSuctionControl(TRUE, TRUE);
	if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_2ND)
		pMotor->DustSuctionControl(FALSE, TRUE);

	return TRUE;
}

void CPaneAutoRun::ChangeShotDrillInfo(int nTool)
{
	SUBTOOLDATA subTool;
	m_bShotDrill = TRUE;
	m_bBarcodeTool = FALSE;
	m_bFlyingTool = FALSE;
	m_bTextTool = FALSE;
	POSITION pos;
	pos = gDProject.m_pToolCode[nTool]->m_SubToolData.GetHeadPosition();
	while (pos) 
	{
		subTool = gDProject.m_pToolCode[nTool]->m_SubToolData.GetNext(pos);
		if( subTool.nToolType != SHOT_DRILL_TYPE)
			m_bShotDrill = FALSE;
		if( subTool.nToolType == BARCODE_TYPE)
			m_bBarcodeTool = TRUE;
		if( subTool.nToolType == FLYING_TYPE)
			m_bFlyingTool = TRUE;
		if( subTool.nToolType == TEXT_TYPE)
			m_bTextTool = TRUE;
	}
}

LRESULT CPaneAutoRun::ChangeVisionParameter(WPARAM wParam, LPARAM lParam)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		HVision* pVision = gDeviceFactory.GetVision();
		VISION_INFO* pVisInfo = reinterpret_cast<VISION_INFO*>(lParam);

		pVision->OnApplyVisionParameter(pVisInfo->nModelType, wParam, *pVisInfo );
	}
	return 1L;
}

LRESULT CPaneAutoRun::ChangeVisionParam(WPARAM wParam, LPARAM lParam)
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
		HVision* pVision = gDeviceFactory.GetVision();
		pVision->OnApplyVisionParam(gDProject.m_FidInfo[lParam].nModelType, wParam, gDProject.m_FidInfo[lParam] );
	}
	return 1L;
}

LRESULT CPaneAutoRun::GetVisionResult(WPARAM wParam, LPARAM lParam)
{
	HVision* pVision = gDeviceFactory.GetVision();
	return pVision->GetRealPos(&visionResult, wParam, lParam, TRUE);
}

LRESULT CPaneAutoRun::SetROI(WPARAM wParam, LPARAM lParam)
{
	HVision* pVision = gDeviceFactory.GetVision();
	pVision->SetInspectionArea((int)wParam, (int)lParam);
	return 1L;
}
LRESULT CPaneAutoRun::SetROIUM(WPARAM wParam, LPARAM lParam)
{
	HVision* pVision = gDeviceFactory.GetVision();
	int nCam = lParam;
	int nPercent;
	int nLowFOVX = (int)gSystemINI.m_sSystemDevice.dLowFOVX * 1000, nHighFOVX = (int)gSystemINI.m_sSystemDevice.dHighFOVX * 1000; // um
	if(nCam == HIGH_1ST_CAM || nCam == HIGH_2ND_CAM)
		nPercent = wParam * 100 / nHighFOVX;
	else
		nPercent = wParam * 100 / nLowFOVX;
	pVision->SetInspectionAreaPercent(nPercent, (int)lParam);
	return 1L;
}

void CPaneAutoRun::MessageLoop()
{
	MSG msg;
	
	if (::PeekMessage(&msg, (HWND)NULL, (UINT)NULL, (UINT)NULL, PM_REMOVE))
	{
		::TranslateMessage((LPMSG)&msg);
		::DispatchMessage((LPMSG )&msg);
	}
}

BOOL CPaneAutoRun::InpositionCheckAll(DAreaInfo *pAreaInfo)
{
	if(m_bCheckTablePos) // inposition check : Move Cmd --> Download data --> inposition check
	{
		if(!InPositionCheck())
		{
			m_bStopField = TRUE;
			m_nStopField = pAreaInfo->m_nSortIndex;
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
			return FALSE;
		}
		m_dTableTime += myTableTime.PresentTime();
		m_bCheckTablePos = FALSE;
	}
	if(m_bCheckAPos)
	{
		if(!gDeviceFactory.GetAttenuator()->IsInposition())
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
			return FALSE;
		}
		m_bCheckAPos = FALSE;
	}

	return TRUE;
}

void CPaneAutoRun::OnButtonLPickTable() 
{
	// TODO: Add your control notification handler code here
	if(m_bAutoRun)
		return;

	if(IsDrilling())
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
	m_pMotor->LoaderCarrierLoadPos();
}

void CPaneAutoRun::OnButtonUPickTable() 
{
	// TODO: Add your control notification handler code here
	if(m_bAutoRun)
		return;

	if(IsDrilling())
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
	m_pMotor->UnloaderCarrierTablePos();
}

void CPaneAutoRun::OnButtonUPickCart() 
{
	// TODO: Add your control notification handler code here
	if(m_bAutoRun)
		return;

	if(IsDrilling())
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
	m_pMotor->UnloaderCarrierUnloadPos();
}

void CPaneAutoRun::OnButtonLPickCart() 
{
	// TODO: Add your control notification handler code here
	if(m_bAutoRun)
		return;
	
	if(IsDrilling())
	{
		ErrMsgDlg(STDGNALM202);
		return;
	}
	m_pMotor->LoaderCarrierAlignPos();
}

BOOL CPaneAutoRun::SavePowerAuto(BOOL bSaveOri, double d1stMeasureResult, double d2ndMeasureResult, double dZ1, double dZ2, int nMask, int nFrequency, double dDuty, double dAOMDelay, double dAOMDuty)
{
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	
	CTime curDate = CTime::GetCurrentTime();
	
	CString strDate;
	strDate.Format(_T("%04d%02d%02d"),curDate.GetYear(), curDate.GetMonth(), curDate.GetDay());

	if(bSaveOri)
		strPathName += _T("PowerTrend");
	else
		strPathName += _T("PowerAuto") + strDate;
	CStdioFile file;
	if (FALSE == file.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return FALSE;
	
	TRY
	{
		file.SeekToEnd();
		CString strBuf;
#ifdef __3RDAOD__
	#ifdef __SERVO_MOTOR__
		strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %.2f | %.2f | %d | %.1f | %d, %d, %d | %.2f | %.2f | %.2f | %.2f\n"),
			curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
			curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
			d1stMeasureResult, d2ndMeasureResult,
			nFrequency, dDuty,
			nMask, gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[nMask], gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[nMask],dZ1, dZ2,
			gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[nMask],
			gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[nMask]);

	#else
		strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %.2f | %.2f | %d | %.1f | %d | %.2f | %.2f | %.2f | %.2f\n"),
			curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
			curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
			d1stMeasureResult, d2ndMeasureResult,
			nFrequency, dDuty,
			nMask, dZ1, dZ2,
			gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[nMask],
			gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[nMask]);
	#endif
#else
	#ifdef __SERVO_MOTOR__
		strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %.2f | %.2f | %d | %.1f, %.1f, %.1f | %d, %d, %d | %.2f | %.2f | %.2f | %.2f\n"),
			curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
			curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
			d1stMeasureResult, d2ndMeasureResult,
			nFrequency, dDuty,
			dAOMDelay, dAOMDuty, nMask, gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[nMask], gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[nMask],dZ1, dZ2,
			gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[nMask],
			gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[nMask]);

	#else
		strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %.2f | %.2f | %d | %.1f, %.1f, %.1f | %d | %.2f | %.2f | %.2f | %.2f\n"),
			curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
			curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
			d1stMeasureResult, d2ndMeasureResult,
			nFrequency, dDuty,
			dAOMDelay, dAOMDuty, nMask, dZ1, dZ2,
			gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[nMask],
			gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[nMask]);
	#endif
#endif
		file.Write(strBuf, strBuf.GetLength());
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return FALSE;
	}
	END_CATCH
		file.Close();
	return TRUE;
}

BOOL CPaneAutoRun::CheckPowerAuto() // AutoRun용 파워체크
{
	if(!CheckStatus())
	{
		return FALSE;
	}
	
	if(!m_bLaser)
	{
		m_nErrMsgID = STDGNALM303;
		return FALSE;
	}

	BOOL bResult = TRUE;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEOCard = gDeviceFactory.GetEocard();

#ifndef __MP920_MOTOR__
	pMotor->SetOutPort(PORT_POWER_METER, TRUE);
#else
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, TRUE, TRUE);
#endif
	m_dlgMeasurement.StartMeasurement(95);
	m_dlgMeasurement.ShowWindow(SW_SHOW);

//	pEOCard->MoveToCenter();

	int nUsePanel = gDProject.m_nSeparation; 

	FParameter fPara;
	SUBTOOLDATA ToolData;
	POSITION ToolPos;
	for(int nTool= 0; nTool<MAX_TOOL_NO; nTool++)
	{
		if(!gDProject.m_pToolCode[nTool]->m_bUseTool)
			continue;
		
		ToolPos = gDProject.m_pToolCode[nTool]->m_SubToolData.GetHeadPosition();
		ToolData = gDProject.m_pToolCode[nTool]->m_SubToolData.GetNext(ToolPos);
		
		if(!gDProject.m_pToolCode[nTool]->m_bPreworkPower)
			continue;

		if(!ChangeBeamPath(ToolData, DO_POWER))
		{
			m_dlgMeasurement.ShowWindow(SW_HIDE);
			m_nErrMsgID = STDGNALM600;
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
			return FALSE;
		}

		// beampath에서 duty 등 정보 받아오기
		GetBeamPathLaserInfo(ToolData);

		if(!UpdateNewParam(ToolData))
		{	
			m_nErrMsgID = STDGNALM445;
			((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
			m_dlgMeasurement.ShowWindow(SW_HIDE);
			return FALSE;
		}
	
		double dX[2], dY[2], dZ1, dZ2;
		dX[0] = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[0].x;
		dY[0] = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[0].y;
		dX[1] = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[1].x;
		dY[1] = gProcessINI.m_sProcessAutoSetting.dPowermeterPos[1].y;
		dZ1  = gProcessINI.m_sProcessPowerMeasure.d1stHeight;
		dZ2  = gProcessINI.m_sProcessPowerMeasure.d2ndHeight;
		
		int nCount = 0;
		double dMeasureResult[2] = {0, 0};
		CString strEvent, strInfo;
		
		this->SendMessage(UM_POWER_CHECK, 0, 0); //display

		int nRepeat; 
		if(gDProject.m_nSeparation == USE_DUAL)
			nRepeat = 2;
		else
			nRepeat = 1;

		for(int nHead=0; nHead<nRepeat; nHead++)
		{

			if(gDProject.m_nSeparation == USE_2ND)
				nHead = 1;

			if(!CheckStatus())
			{
				m_dlgMeasurement.ShowWindow(SW_HIDE);
				((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
				return FALSE;
			}

			if(!pMotor->MotorMoveXYZ(dX[nHead], dY[nHead], dZ1, dZ2, TRUE, SHOT_MOVE, TRUE))
			{
				m_nErrMsgID = STDGNALM438;
				m_dlgMeasurement.ShowWindow(SW_HIDE);
				((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
				return FALSE;
			}
			
			if(!gProcessINI.m_sProcessSystem.bDryRun)
			{
				if(nHead == 1)
				{
					if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, TRUE, FALSE))
					{
						m_nErrMsgID = STDGNALM417; // shutter sensor error
#ifndef __MP920_MOTOR__
						pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
						pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
						m_dlgMeasurement.ShowWindow(SW_HIDE);
						return FALSE;
					}
				}
				else
				{
					if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, FALSE, FALSE))
					{
						m_nErrMsgID = STDGNALM417; // shutter sensor error
#ifndef __MP920_MOTOR__
						pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
						pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
						m_dlgMeasurement.ShowWindow(SW_HIDE);
						return FALSE;
					}
				}
			}
			
			if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
			{
				int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
				CheckInpositionError(nErrorAxis);
				m_dlgMeasurement.ShowWindow(SW_HIDE);
				((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
				pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
				pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
				return FALSE;
			}
		
			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
			{
				if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
				{
					m_nErrMsgID = STDGNALM781;
					return FALSE;
				}
			}
			else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
			{
				if(!gDeviceFactory.GetEocard()->EndMarkDummy())
				{
					m_nErrMsgID = STDGNALM445; 
					CString strFile, strLog;
					strFile.Format(_T("ReadHole"));
					strLog.Format(_T("EndMarkDummy Error"));
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					m_pLineDummyTime.Finish();
					return FALSE;
				}
			}
			
			gDeviceFactory.GetEocard()->jump(HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB);
			
			//measure
			pEOCard->LaserOnOff(TRUE);
			nCount = 0;
			while(nCount < 20) // 2 sec
			{
				if(!CheckStatus())
				{
					pEOCard->LaserOnOff(FALSE);
					m_dlgMeasurement.ShowWindow(SW_HIDE);
					((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
					if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
					{
						if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
						{
							if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
							{
								m_nErrMsgID = STDGNALM781;
								return FALSE;
							}
						}
					}
					else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
					{
						if(!gDeviceFactory.GetEocard()->StartMarkDummy())
						{
							m_nErrMsgID = STDGNALM445; // count No error
							CString strFile, strLog;
							strFile.Format(_T("ReadHole"));
							strLog.Format(_T("StartMarkDummy Error"));
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							m_pLineDummyTime.Finish();
							return FALSE;
						}
					}
					return FALSE;
				}
				::Sleep(100);
				MessageLoop();
				nCount++;
				m_dlgMeasurement.UpdateMeasurement(nCount);
			}
			
			dMeasureResult[nHead] = 0;
			for(int i = 0; i < 5; i++)
			{
			
				nCount = 0;
				while(nCount < 15) // 1.5 sec
				{
					if(!CheckStatus())
					{
						pEOCard->LaserOnOff(FALSE);
						m_dlgMeasurement.ShowWindow(SW_HIDE);
						((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
#ifndef __MP920_MOTOR__
						pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
						pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
						if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
						{
							if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
							{
								if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
								{
									m_nErrMsgID = STDGNALM781;
									return FALSE;
								}
							}
						}
						else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
						{
							if(!gDeviceFactory.GetEocard()->StartMarkDummy())
							{
								m_nErrMsgID = STDGNALM445; // count No error
								CString strFile, strLog;
								strFile.Format(_T("ReadHole"));
								strLog.Format(_T("StartMarkDummy Error"));
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
								m_pLineDummyTime.Finish();
								return FALSE;
							}
						}
						return FALSE;
					}
					::Sleep(100);
					MessageLoop();
					nCount++;
					
					m_dlgMeasurement.UpdateMeasurement(20 + (nCount+15*i));
				}
				::AfxGetMainWnd()->SendMessage(UM_POWER_MEASURE, nHead, nTool);
				dMeasureResult[nHead] += m_dMeasuredPower[nHead];
				if(m_dMeasuredPower[nHead] <= 0.5)
				{
					pEOCard->LaserOnOff(FALSE);
					CString strMsg = _T("");
					strMsg.Format(_T("Laser power = %.3f.\nCheck laser power measuring position or port setting"), m_dMeasuredPower[nHead]);
					ErrMessage(strMsg);
					m_nErrMsgID = STDGNALM707;
					m_dlgMeasurement.ShowWindow(SW_HIDE);
#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
					return FALSE;
				}
			}
			pEOCard->LaserOnOff(FALSE);
			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
			{
				if(!gDeviceFactory.GetEocard()->IsStannbyShotRun()  && m_bUserDummyOn)
				{
					if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
					{
						m_nErrMsgID = STDGNALM781;
						return FALSE;
					}
				}
			}
			else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
			{
				if(!gDeviceFactory.GetEocard()->StartMarkDummy())
				{
					m_nErrMsgID = STDGNALM445; // count No error
					CString strFile, strLog;
					strFile.Format(_T("ReadHole"));
					strLog.Format(_T("StartMarkDummy Error"));
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					m_pLineDummyTime.Finish();
					return FALSE;
				}
			}
			dMeasureResult[nHead] = dMeasureResult[nHead]/5; // 비교

		
#ifdef __TEST__
			dMeasureResult[nHead] = 5.52;
#endif
			::AfxGetMainWnd()->SendMessage(UM_POWER_RESULT, nTool, (LPARAM)(dMeasureResult[nHead] * 1000));
			
			
			if(dMeasureResult[nHead] < ToolData.dMinPower)
			{
				if(!gProcessINI.m_sProcessSystem.bDryRun && !gProcessINI.m_sProcessSystem.bCheckPreworkData)
				{
					bResult = FALSE;
					m_nErrMsgID = STDGNALM707; // power error
					break;
				}
			}
			else if(dMeasureResult[nHead] > ToolData.dMaxPower)
			{
				if(!gProcessINI.m_sProcessSystem.bDryRun && !gProcessINI.m_sProcessSystem.bCheckPreworkData)
				{
					bResult = FALSE;
					m_nErrMsgID = STDGNALM708; // power error
					break;
				}
			}
			else
			{
				bResult = TRUE;
			}
			
		}
		//PCB information display
		this->SendMessage(UM_POWER_CHECK, (int)(dMeasureResult[0]*1000), (int)(dMeasureResult[1]*1000));
	
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE)) // 090805 shutter close
		{
			m_nErrMsgID = STDGNALM417; // shutter sensor error
			m_dlgMeasurement.ShowWindow(SW_HIDE);
#ifndef __MP920_MOTOR__
			pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
			pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif
			return FALSE;
		}

		// log
		strEvent = _T("Finished the process of measuring of laser power.");
		
		strInfo.Format(_T("Master Power Average = %f | Slave Power Average = %f | Min. criteria = %f | Max. criteria = %f | Pulse Frequency = %d Hz | Duty = %.1f um | AOM Delay = %.1f um | AOM Duty = %.1f um | Beam Path No. = %d | Master Head Height = %f mm | Slave Head Height = %f mm | Duty Offset = %.1f um | AOM Delay Offset = %.1f um | AOM Duty Offset = %.1f um | Duty Compensation = %.1f um"),
			dMeasureResult[0], dMeasureResult[1], ToolData.dMinPower, ToolData.dMaxPower, ToolData.nFrequency, ToolData.dShotDuty[0], 
			ToolData.dShotAOMDelay[0], ToolData.dShotAOMDuty[0], ToolData.nMask, dZ1, dZ2,
			gBeamPathINI.m_sBeampath.dPowOffsetDuty, gBeamPathINI.m_sBeampath.dPowOffsetAomDelay,
			gBeamPathINI.m_sBeampath.dPowOffsetAomDuty, gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[ToolData.nMask]);

		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));

		
		SavePowerAuto(TRUE, dMeasureResult[0], dMeasureResult[1], dZ1, dZ2, ToolData.nMask, ToolData.nFrequency, 
			ToolData.dShotDuty[0], 
			ToolData.dShotAOMDelay[0], ToolData.dShotAOMDuty[0]);
		
		SavePowerAuto(FALSE, dMeasureResult[0], dMeasureResult[1], dZ1, dZ2, ToolData.nMask, ToolData.nFrequency, 
			ToolData.dShotDuty[0], 
			ToolData.dShotAOMDelay[0], ToolData.dShotAOMDuty[0]);

		gOPCParam.dPowerMeasure[0] = dMeasureResult[0];
		gOPCParam.dPowerMeasure[1] = dMeasureResult[1];
		OPCUpdateParameter(N_POWER);
		if(!bResult)
			break;

	}

#ifndef __MP920_MOTOR__
	pMotor->SetOutPort(PORT_POWER_METER, FALSE);
#else
	pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_POWER_METER, FALSE, TRUE);
#endif

	m_dlgMeasurement.ShowWindow(SW_HIDE);
	
	if(bResult)
	{
		time_t timeNow;
		time(&timeNow);
		int nIndex = gBeamPathINI.m_sBeampath.nLastIndex;

		CString strFile, strLog;
		strFile.Format(_T("PreWork"));

		strLog.Format(_T("PowerSaveTime start ------"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		for(int e = 0; e <= nIndex; e++)
		{
			if(m_bPowerTool[e])
			{
				if(gDProject.m_nSeparation == USE_DUAL)
				{
					gTempINI.m_sTempTime.nAutoPowerEndTime[e][0] = (int)timeNow;
					gTempINI.m_sTempTime.nAutoPowerEndTime[e][1] = (int)timeNow;
					strLog.Format(_T("PowerSaveTime Dual [%d] = %d"), e, timeNow);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
				else if(gDProject.m_nSeparation == USE_1ST)
				{
					gTempINI.m_sTempTime.nAutoPowerEndTime[e][0] = (int)timeNow;
					strLog.Format(_T("PowerSaveTime 1st [%d] = %d"), e, timeNow);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
				else
				{
					gTempINI.m_sTempTime.nAutoPowerEndTime[e][1] = (int)timeNow;
					strLog.Format(_T("PowerSaveTime 2nd [%d] = %d"), e, timeNow);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
			}
		}
		strLog.Format(_T("PowerSaveTime end ------"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}


	return bResult;
}

LRESULT CPaneAutoRun::OnChangePower(WPARAM wParam, LPARAM lParam)
{
	int nPower1 = (int)wParam;
	int nPower2 = (int)lParam;
	CString str; 
	str.Format(_T("Last Measured Power Value : %.3f, %.3f Watt"), nPower1/1000., nPower2/1000.);
	GetDlgItem(IDC_STATIC_POWER_VAL)->SetWindowText(str);
	return 0;
}

void CPaneAutoRun::CheckResetSwitchAndTableSuction()
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();

	BOOL bSwitch = pMotor->IsResetSwitch();

	if(m_bOldResetSwitch != bSwitch)
	{
		m_bOldResetSwitch = bSwitch;

		if(bSwitch)
		{
			::AfxGetMainWnd()->SendMessage(UM_RESET_SWITCH, NULL, NULL);
		}
	}
#endif

	if(!IsPCBOnTable())
	{
		m_bCheckTablePCB = FALSE;
		CString strLog;
		strLog.Format(_T("Table PCB Info Error"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));

		if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
		{
			if(gProcessINI.m_sProcessOption.bCheckSuctionError)
			{
				if(IsDrilling())
					DrillStop();
				ErrMsgDlg(STDGNALM520);
			}
			else
			{
				if(IsDrilling())
					DrillOneCycle();
				ErrMsgDlg(STDGNALM520);
			}
		}
	}
}

BOOL CPaneAutoRun::CheckLoaderPCBStatus()
{
	if(!gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader && m_bAutoRun && m_nCurrentLotCount != m_nInputLot - m_nNGLotCount){}
	else
		return TRUE;

	LONG lStatus = m_pMotor->GetCurrentError(ERROR_LOAD);
	if(lStatus & 0x0004) 
	{
		if(!m_pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, FALSE, FALSE))
		{
			int nLoopCount = 0;
			while(TRUE)
			{
				::Sleep(50);
				MessageLoop();
				nLoopCount++;
				if(nLoopCount > 40)
					break;
			}
			
			if(!m_pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, FALSE, FALSE))
			{
				if(gDProject.m_nSeparation == USE_DUAL)
				{
					if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount >= 2 &&
						!m_pMotor->IsLoaderPicker1PCBExist() && 
						!m_pMotor->IsLoaderPicker2PCBExist() )
					{
						nLoopCount = 0;
						while(TRUE)
						{
							::Sleep(50);
							MessageLoop();
							nLoopCount++;
							if(nLoopCount > 20)
								break;
						}

						if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount >= 2 &&
							!m_pMotor->IsLoaderPicker1PCBExist() &&
							!m_pMotor->IsLoaderPicker2PCBExist() )
						{
							m_nErrMsgID = STDGNALM421;
							return FALSE;
						}
					}
					else if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount >= 1 &&
						!m_pMotor->IsLoaderPicker1PCBExist())
					{
						nLoopCount = 0;
						while(TRUE)
						{
							::Sleep(50);
							MessageLoop();
							nLoopCount++;
							if(nLoopCount > 20)
								break;
						}

						if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount >= 1 &&
							!m_pMotor->IsLoaderPicker1PCBExist())
						{
							m_nErrMsgID = STDGNALM421;
							return FALSE;
						}
					}
				}
				else if(gDProject.m_nSeparation == USE_1ST)
				{
					if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount >= 1 &&
						!m_pMotor->IsLoaderPicker1PCBExist())
					{
						nLoopCount = 0;
						while(TRUE)
						{
							::Sleep(50);
							MessageLoop();
							nLoopCount++;
							if(nLoopCount > 20)
								break;
						}

						if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount >= 1 &&
							!m_pMotor->IsLoaderPicker1PCBExist())
						{
							m_nErrMsgID = STDGNALM421;
							return FALSE;
						}
					}
				}
				else
				{
					if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount >= 1 &&
						!m_pMotor->IsLoaderPicker2PCBExist())
					{
						nLoopCount = 0;
						while(TRUE)
						{
							::Sleep(50);
							MessageLoop();
							nLoopCount++;
							if(nLoopCount > 20)
								break;
						}

						if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount >= 1&&
							!m_pMotor->IsLoaderPicker2PCBExist())
						{
							m_nErrMsgID = STDGNALM421;
							return FALSE;
						}
					}
				}
			}
		}
	}
	if(!CheckStatus())
	{
		return FALSE;
	}
	return TRUE;
}

void CPaneAutoRun::GetOnlyMarkingAvgTime()
{
	double dTime = m_pMarkingAvgTime.Finish();

	if(m_dAvgMarkingTime < 1)
		m_dAvgMarkingTime = dTime;
	else
		m_dAvgMarkingTime = (m_dAvgMarkingTime + dTime)/2.0;
}

void CPaneAutoRun::CheckComponentTime()
{
	if(FALSE == IsDrilling())
	{
		::AfxGetMainWnd()->SendMessage(UM_COMPONENT_PREACQTIME, NULL, NULL);
	}
	else
	{
		m_bStartCheckComponentTime = TRUE;
	}

}

void CPaneAutoRun::OnClickListBoardParam(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// 110311
	ShowDetailInformation();
	
	*pResult = 0;
}

void CPaneAutoRun::ShowDetailInformation()
{
	// 110311
	int nSel = m_listBoardParam.GetSelectionMark();
	if (-1 == nSel)
		return;
	
	CString strTemp(m_listBoardParam.GetItemText(nSel, 0));
	int nTool = atoi(strTemp);
	int nSub = gDProject.m_pToolCode[nTool]->m_SubToolData.GetCount();
	
	CString strDetail;

	SUBTOOLDATA subData;
	CToolCodeList* pToolCode;
	pToolCode = gDProject.m_pToolCode[nTool];
	
	int i = 0;
	POSITION pos = pToolCode->m_SubToolData.GetHeadPosition();

	double dDuty[MAX_BEAM_HOLE], dAOMDelay[MAX_BEAM_HOLE], dAOMDuty[MAX_BEAM_HOLE], dMinFreq[MAX_BEAM_HOLE], dMaxFreq[MAX_BEAM_HOLE], dDutyOffset[MAX_BEAM_HOLE];
//	int nMinShotTime[MAX_BEAM_HOLE];

	int nToolType, nShotMode, nFrequency, nTotalShot, nBurstShot, nMask;

	strTemp.Format(_T("[Tool No : %d, Total SubTool : %d]\r\n"), nTool, nSub);
	strDetail += strTemp;

	while(pos)
	{
		if(i == nSub) break;
		
		subData = pToolCode->m_SubToolData.GetNext(pos);

		nToolType = subData.nToolType;
		nShotMode = subData.nShotMode; // Burst, Cycle, Step
		nFrequency = gBeamPathINI.m_sBeampath.nPowCompensationFrequency[subData.nMask];//subData.nFrequency;
		nTotalShot = subData.nTotalShot;
		nBurstShot = subData.nBurstShot;
		nMask = subData.nMask;

		switch(nToolType)
		{
		case 0:
			strTemp.Format(_T("\r\nSub%d) ToolType = Marking, "), i+1);
			strDetail += strTemp;
			break;
		case 1:
			strTemp.Format(_T("\r\nSub%d) ToolType = ShotDrill, "), i+1);
			strDetail += strTemp;
			break;
		case 2:
			strTemp.Format(_T("\r\nSub%d) ToolType = Text, "), i+1);
			strDetail += strTemp;
			break;
		case 3:
			strTemp.Format(_T("\r\nSub%d) ToolType = Flying, "), i+1);
			strDetail += strTemp;
			break;
		case 4:
			strTemp.Format(_T("\r\nSub%d) ToolType = Barcode, "), i+1);
			strDetail += strTemp;
			break;
		}

		switch(nShotMode)
		{
		case 0:
			strTemp.Format(_T("ShotMode = Burst mode\r\n"));
			strDetail += strTemp;
			break;
		case 1:
			strTemp.Format(_T("ShotMode = Cycle mode\r\n"));
			strDetail += strTemp;
			break;
		case 2:
			strTemp.Format(_T("ShotMode = Step mode\r\n"));
			strDetail += strTemp;
			break;
		}
		strTemp.Format(_T("Frequency = %d Hz,  Mask = %d,  "), nFrequency, nMask);
		strDetail += strTemp;

		strTemp.Format(_T("TotalShot = %d,  BurstShot = %d   \r\n"), nTotalShot, nBurstShot);
		strDetail += strTemp;

		for(int j=0; j<MAX_BEAM_HOLE; j++)
		{
			dDuty[j] = subData.dShotDuty[j];
			dAOMDelay[j] = subData.dShotAOMDelay[j];
			dAOMDuty[j] = subData.dShotAOMDuty[j];
#ifdef __USE_DUALBAND_EOCARD__
			dMinFreq[j] = subData.dShotMinFreq[j];
			dMaxFreq[j] = subData.dShotMaxFreq[j];
#endif
			dDutyOffset[j] = gBeamPathINI.m_sBeampath.dPowOffsetDuty[nMask];
//			nMinShotTime[j] = subData.nMinShotTime[j];
		}
		dDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationDuty[nMask];
		dAOMDelay[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[nMask];
		dAOMDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[nMask];

		for(int j=0; j<nTotalShot; j++)
		{
//			strTemp.Format(_T("%d-th shot) Duty = %.2f\r\n"), j+1, dDuty[j]);
//			strTemp.Format(_T("%d-th shot) Duty = %.2f, AOMDelay = %.2f, AOMDuty = %.2f, MinShotTime = %d\r\n"), j+1, dDuty[j], dAOMDelay[j], dAOMDuty[j], nMinShotTime[j]);
#ifdef __3RDAOD__
	//		strTemp.Format(_T("%d-th shot) Duty = %.2f\r\n"), j+1, dDuty[j]);
			if(m_nUserLevel != 3)
				strTemp.Format(_T("%d-th shot) Duty = %.2f\r\n"), j+1, dDuty[j]);
			else
				strTemp.Format(_T("%d-th shot) Duty = %.2f, Duty Offset = %.2f, MaxFreq = %.0f\r\n"), j+1, dDuty[j], dDutyOffset[j], dMaxFreq[j]);
#else
	#ifdef __USE_DUALBAND_EOCARD__
				strTemp.Format(_T("%d-th shot) Duty = %.2f, AOMDelay = %.2f, AOMDuty = %.2f, MinFreq = %.0f, MaxFreq = %.0f\r\n"), j+1, dDuty[j], dAOMDelay[j], dAOMDuty[j],dMinFreq[j], dMaxFreq[j]);
	#else
				strTemp.Format(_T("%d-th shot) Duty = %.2f, AOMDelay = %.2f, AOMDuty = %.2f\r\n"), j+1, dDuty[j], dAOMDelay[j], dAOMDuty[j]);
	#endif
#endif
			strDetail += strTemp;
		}

		i++;
	}

	ErrMessage(_T("Drill Information\n") + strDetail, MB_ICONINFORMATION);
}

void CPaneAutoRun::StartRunThread()
{
 	m_bRunThreadEnd = FALSE;
	m_pCheckPreTimeThread = NULL;
	
	m_pCheckPreTimeThread = ::AfxBeginThread(CheckPreworkTimeThread, this, THREAD_PRIORITY_NORMAL);
}

void CPaneAutoRun::CalRefFidPos(double &PosX, double &PosY)
{
	double dOffsetX = 0, dOffsetY = 0;
	
	PosX = gProcessINI.m_sProcessFidFind.dRefPosX;
	PosY = gProcessINI.m_sProcessFidFind.dRefPosY;

	PosX += gDProject.m_dRefFidOffsetX;
	PosY += gDProject.m_dRefFidOffsetY;
}

BOOL CPaneAutoRun::ManualFidFind(double dPosX, double dPosY, int nFidKind, BOOL bNoMove)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif                       
	HVision* pVision = gDeviceFactory.GetVision();
	CString strResult;
	TCHAR myResultChar[512] = {0,};
	double dCamOffsetX = 0, dCamOffsetY = 0;
	int nCam, nIsFidFind, nFindMethod;
	double dZ1 = 0, dZ2 = 0;
	BOOL b1stPanel = TRUE;

	if(m_bAutoRun)
		nFindMethod = FIND_ALL_FID;
	else 
	{
		if(m_bSelectFire)
			nFindMethod = FIND_SELECT_ONLY;
		else
			nFindMethod = FIND_VISIBLE_ONLY;
	}

	int nCnt = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);
	LPFIDDATA pFidData;

	for(int j = 0; j < nCnt; j++) 
	{
		::Sleep(1);
		MessageLoop();
		
		if(!CheckStatus())
			return FALSE;

		pFidData = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, j);

		if(!(pFidData->nFidType & FID_PRIMARY))
			continue;
		
		if(pFidData->nFidType & FID_VERIFY)
			continue;

		nIsFidFind = gDProject.m_Glyphs.GetUseFidFindStatus(DEFAULT_FID_INDEX, j);
		if(nFindMethod != FIND_ALL_FID && (nIsFidFind & nFindMethod) == 0)
			continue;

		break;
	}
	if(!bNoMove) //OneFidFind에서 호출할경우 이미 vision param이 설정되어 있으므로 생략 
	{
		if( pFidData->nCam == LOW_CAM || pFidData->nCam == LOW_TO_HIGH_CAM )
		{
			// Parameter 설정하는 부분
			if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST)
			{
				this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
				this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
				dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - gDProject.m_dPcbThick;
				dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - gDProject.m_dPcbThick2;
				nCam = LOW_1ST_CAM;
			}
			if(gDProject.m_nSeparation == USE_2ND)
			{
				this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
				this->SendMessage(UM_VISION_LAMP, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
				dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - gDProject.m_dPcbThick;
				dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - gDProject.m_dPcbThick2;
				b1stPanel = FALSE;
				nCam = LOW_2ND_CAM;
			}
		}
		else
		{
			// Parameter 설정하는 부분
			if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST)
			{
				this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
				this->SendMessage(UM_VISION_LAMP, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
				dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - gDProject.m_dPcbThick;
				dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - gDProject.m_dPcbThick2;
				nCam = HIGH_1ST_CAM;
			}
			if(gDProject.m_nSeparation == USE_2ND)
			{
				this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
				this->SendMessage(UM_VISION_LAMP, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
				dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - gDProject.m_dPcbThick;
				dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - gDProject.m_dPcbThick2;
				b1stPanel = FALSE;
				nCam = HIGH_2ND_CAM;
			}
		}


		//cal distance cam 
		switch(nCam)
		{
		case HIGH_1ST_CAM : 
			dCamOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dCamOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y; 			
			break;
		case LOW_2ND_CAM :
			dCamOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dCamOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y; 
			break;
		case HIGH_2ND_CAM :
			dCamOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dCamOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y; 
			break;
		}
	}

	CDPoint dIndexP;
	DPOINT visionResult;
	double dFinalMoveX, dFinalMoveY;
	double dStepX, dStepY;

	int nIndexNo = 6;
	if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
		nIndexNo = 4;

	
	if(nCam == LOW_1ST_CAM || nCam == LOW_2ND_CAM)
	{
		dStepX = gProcessINI.m_sProcessFidFind.dMoveLowVision.x;
		dStepY = gProcessINI.m_sProcessFidFind.dMoveLowVision.y;
	}
	else if(nCam == HIGH_1ST_CAM || nCam == HIGH_2ND_CAM)
	{		
		dStepX = gProcessINI.m_sProcessFidFind.dMoveHighVision.x;
		dStepY = gProcessINI.m_sProcessFidFind.dMoveHighVision.y;
	}

	BOOL bFound = FALSE;
	for(int i = 0; i < gProcessINI.m_sProcessFidFind.nFidTotalRetrial ; i++)
	{
		if(!CheckStatus())
			return FALSE;
		
		dIndexP = GetNextStepIndex(i);
		
		// Table move
		dFinalMoveX = dPosX	+ dCamOffsetX - (dStepX * dIndexP.x);
		dFinalMoveY = dPosY	+ dCamOffsetY - (dStepY * dIndexP.y);
		
		if(!gDeviceFactory.GetMotor()->MotorMoveXYZ(dFinalMoveX, dFinalMoveY, dZ1, dZ2, TRUE))
		{
			m_nErrMsgID = STDGNALM438;
			return FALSE;
		}
		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
			return FALSE;
		}

		bFound = this->SendMessage(UM_VISION_FIND, nCam, nIndexNo);
		if(bFound)
		{

			if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
			{
#ifdef USE_VISION_PRO
				visionResult.x = gProcess.m_ResultData[nCam].dx;
				visionResult.y = gProcess.m_ResultData[nCam].dy;
#endif
			}
			break;
		}
		else
		{
			visionResult.x = 0;
			visionResult.y = 0;
		}
		
	}

	if(!bFound)
	{
		pMotor->SetOutPort(PORT_AUTO_MPG, TRUE);	
		::AfxGetMainWnd()->SendMessage(VISION_LIVE, nCam, TRUE);
		
		pMotor->SetOutPort(PORT_PC_BUZZER, 1);
		
		
		ErrMessage(IDS_MANUALFID_CENTER);
		
		while (TRUE)
		{
			if(gDeviceFactory.GetMotor()->GetCurrentMode() != MODE_MPG)
				break;
			ErrMessage(IDS_MANUALFID_OFF);
		}
		
		pMotor->SetOutPort(PORT_AUTO_MPG, FALSE);
		
		pMotor->SetOutPort(PORT_PC_BUZZER, 0);
		
		::AfxGetMainWnd()->SendMessage(VISION_LIVE, nCam, FALSE);

		bFound = this->SendMessage(UM_VISION_FIND, nCam, nIndexNo);
	
		if(!bFound)
			return FALSE;

	}

	double dX, dY;
	pMotor->GetPosition(AXIS_X, dX, b1stPanel);
	pMotor->GetPosition(AXIS_Y, dY, b1stPanel);
	
#ifdef __TEST__
	dX = dY = 500.0;
#endif

	if(nCam == LOW_1ST_CAM)
	{
		gDProject.m_dRefPosX = dX - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - visionResult.x;
		gDProject.m_dRefPosY = dY - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y - visionResult.y;
	}
	else if(nCam == HIGH_1ST_CAM)
	{		
		gDProject.m_dRefPosX = dX - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - visionResult.x;
		gDProject.m_dRefPosY = dY - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y - visionResult.y;
	}
	else if(nCam == LOW_2ND_CAM)
	{
		gDProject.m_dRefPosX = dX - gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - visionResult.x;
		gDProject.m_dRefPosY = dY - gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - visionResult.y;
	}
	else
	{
		gDProject.m_dRefPosX = dX - gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - visionResult.x;
		gDProject.m_dRefPosY = dY - gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y - visionResult.y;
	}

	gDProject.ResetFidOffset();
	
	gDProject.m_nDataLoadStep = FIELD_DIVIED + SET_FID_ORIGIN;

	return TRUE;
}

LRESULT CPaneAutoRun::AutoSaveProject(WPARAM wParam, LPARAM lParam)
{
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pRecipeGen->SetDataLoadStep(gDProject.m_nDataLoadStep);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SaveProject(gDProject.m_szProjectName);

	return 1L;
}

void CPaneAutoRun::OnClickTabViewer(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	BOOL bSideVision =((CEasyDrillerDlg*)::AfxGetMainWnd())->GetSideStatus();
	int nSel = m_tabAutoRunView.GetCurSel();
	
	switch(nSel)
	{
	case 0: //Data 
		if(!bSideVision)
			m_pFiducial->DisconnectView();
		break;
	case 1: //Fiducial
		if(!gSystemINI.m_sHardWare.bUseWideMonitor || !IsDrilling())
		{
			if(!bSideVision)
				m_pFiducial->ConnectView();
			m_pFiducial->ChangeDisplay();
		}
		break;
	case 2: //prework
	case 3:
	case 4:
	case 5:
		if(!bSideVision)
			m_pFiducial->DisconnectView();
		break;
	}
		
	*pResult = 0;
}

void CPaneAutoRun::CheckTab()
{
	int nSel = m_tabAutoRunView.GetCurSel();

	if(nSel == 1) //fiducial 화면 
	{
		BOOL bSideVision = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetSideStatus();
		if(bSideVision == FALSE)
			m_pFiducial->ConnectView();
	}
}

BOOL CPaneAutoRun::GetAutoRun()
{
	return m_bAutoRun;
}

void CPaneAutoRun::InsertFidList(int nLotNo)
{
	if(m_pFiducial)
		m_pFiducial->InsertFidResult(nLotNo);
}

void CPaneAutoRun::ChangeView(int nChangePane, BOOL bCapture)
{
	if(gProcessINI.m_sProcessSystem.bNoUseChangeView && !bCapture)
		return;

	m_pFiducial->DisconnectView();

	switch(nChangePane)
	{
	case VIEW_DATA :
		m_tabAutoRunView.ShowPane(0);
		break;
	case VIEW_FIDUCIAL :
		m_pFiducial->ChangeDisplay();
		if(!gSystemINI.m_sHardWare.bUseWideMonitor || !IsDrilling())
		{
			BOOL bSide = ((CEasyDrillerDlg*)::AfxGetMainWnd())->GetSideStatus();
			if(!bSide)
				m_pFiducial->ConnectView();
		}
		m_tabAutoRunView.ShowPane(1);
		break;
	case VIEW_PREHEAT :
		if(!gProcessINI.m_sProcessSystem.bNoUsePrework)
		{
			m_pPrework->ChangeView(VIEW_PREHEAT);
			m_tabAutoRunView.ShowPane(2);
		}
		break;
	case VIEW_POWER :
		if(!gProcessINI.m_sProcessSystem.bNoUsePrework)
		{
			m_pPrework->ChangeView(VIEW_POWER);
			m_tabAutoRunView.ShowPane(2);
		}
		break;
	case VIEW_SCANNER : 
		if(!gProcessINI.m_sProcessSystem.bNoUsePrework)
		{
			m_pPrework->ChangeView(VIEW_SCANNER);
			m_tabAutoRunView.ShowPane(2);
		}
		break;

	}
}

void CPaneAutoRun::SetPreworkInfo()
{
	m_nASCCount = 0;
	TCHAR Temp[256] = {0,};
	TCHAR cSumASC[BEAMPATH_COUNT][256];
	
	memset(cSumASC, 0, sizeof(cSumASC));
	for(int i = 0; i < BEAMPATH_COUNT; i++)
	{
		m_bASCTool[i] = FALSE;
		m_bPowerTool[i] = FALSE;
	}

	CString strFile, strLog;
	strFile.Format(_T("PreWork"));
	strLog.Format(_T("Power UseTool start ------"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	int nSubCount;
	BOOL bOver;
	for(int i =0 ; i<MAX_TOOL_NO ; i++)
	{
		if(!gDProject.m_pToolCode[i]->m_bUseTool)
			continue;
		
		SUBTOOLDATA subTool;
		POSITION pos;
		nSubCount = 0;
		pos = gDProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		while(pos)
		{
			bOver = FALSE;
			subTool = gDProject.m_pToolCode[i]->m_SubToolData.GetNext(pos);
		
			if(nSubCount == 0) //첫번째 subtool로 power측정 
			{
				if(gDProject.m_pToolCode[i]->m_bPreworkPower)
				{
					m_bPowerTool[subTool.nMask] = TRUE;
					strLog.Format(_T("Power UseTool [%d] = 1"), subTool.nMask);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
			}

//			m_bPreScanner = TRUE;
			strcpy_s(Temp, gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
			strcpy_s(cSumASC[m_nASCCount], Temp);

			//앞에 똑같은 asc파일사용했는지 확인
			for(int j = 0 ; j < m_nASCCount ; j++) //1번툴부터 사용 -> 1번까지만 비교 
			{
				if(strcmp(cSumASC[j], Temp) == 0)
				{
					memset(cSumASC[m_nASCCount], 0, 256);
					bOver = TRUE;
				}
			}
			
			if(!bOver)
			{
				m_bASCTool[subTool.nMask] = TRUE;
				strLog.Format(_T("Scanner UseTool [%d] = 1"), subTool.nMask);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				m_nASCCount++;
			}
			nSubCount++;
		}

	}

	strLog.Format(_T("Power UseTool end ------"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	if(m_pPrework)
		m_pPrework->SetPreworkInfo(TRUE, TRUE, TRUE);

}

BOOL CPaneAutoRun::OnDoPreheat()
{
	CString strSequenceLog;
	strSequenceLog.Format(_T("---PreHeat Start---"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
	if( !CheckStatus())
		return FALSE;
	
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	if(pMotor->GetCurrentMode() == MODE_MPG)
	{
		m_nErrMsgID = STDGNALM209;
		return FALSE;
	}
	
	if(pMotor->IsSafetyMode())
	{
		m_nErrMsgID = STDGNALM207;
		return FALSE;
	}

	if(gProcessINI.m_sProcessSystem.bDryRun)
		return TRUE;
	
	if(!m_bLaser)
	{
		m_nErrMsgID = STDGNALM303;
		return FALSE;
	}
		
	int nPreHeatTime = gProcessINI.m_sProcessCal.nAutoRunPreheatTime * 60; 
	CEasyDrillerDlg* pDlg = (CEasyDrillerDlg*)::AfxGetMainWnd();

	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE)) // 090805 shutter close
	{
		m_nErrMsgID = STDGNALM417; // shutter sensor error
		return FALSE;
	}
	
	CString strLog;
	time_t timeNow;
	time_t timeStart;

	FParameter fPara;
	gDeviceFactory.GetEocard()->GetParameter(&fPara);

	fPara.Frequency = gProcessINI.m_sProcessCal.nAutoRunPreheatFreq; 
	fPara.dDuty = gProcessINI.m_sProcessCal.dAutoRunPreheatDuty * 100.0; 
	fPara.DrawStep = (unsigned short)gSystemINI.m_sSystemDevice.dJumpSpeed;

	gDeviceFactory.GetEocard()->SetParameter(&fPara);

	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
	{
		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
		{
			m_nErrMsgID = STDGNALM781;
			return FALSE;
		}
	}
	else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
	{
		if(!gDeviceFactory.GetEocard()->EndMarkDummy())
		{
			m_nErrMsgID = STDGNALM445;  
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("EndMarkDummy Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			m_pLineDummyTime.Finish();
			return FALSE;
		}
	}

	time(&timeStart);
	gDeviceFactory.GetEocard()->LaserOnOff(TRUE);
	strLog.Format(_T("Start LaserPreheat"));
	pDlg->WriteProcessLog(strLog, _T(""));

	while(TRUE)
	{
		ScannerWamup();

		Sleep(500);
		MessageLoop();

		if(!CheckStatus())
		{
			gDeviceFactory.GetEocard()->EStop();
			::Sleep(200);
			gDeviceFactory.GetEocard()->LaserOnOff(FALSE);
			strLog.Format(_T("Stop LaserPreheat (by User)"));
			pDlg->WriteProcessLog(strLog,_T(""));

			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
			{
				if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
				{
					if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
					{
						m_nErrMsgID = STDGNALM781;
						return FALSE;
					}
				}
			}
			else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
			{
				if(!gDeviceFactory.GetEocard()->StartMarkDummy())
				{
					m_nErrMsgID = STDGNALM445; // count No error
					CString strFile, strLog;
					strFile.Format(_T("ReadHole"));
					strLog.Format(_T("StartMarkDummy Error"));
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					m_pLineDummyTime.Finish();
					return FALSE;
				}
			}
			return FALSE;
		}

		if(!BusyCheck()) //motor fault 일때만 return false 
		{
			gDeviceFactory.GetEocard()->LaserOnOff(FALSE);
			strLog.Format(_T("Stop LaserPreheat (Reason is Motor Fault) "));
			pDlg->WriteProcessLog(strLog,_T(""));

			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
			{
				if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
				{
					if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
					{
						m_nErrMsgID = STDGNALM781;
						return FALSE;
					}
				}
			}
			else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
			{
				if(!gDeviceFactory.GetEocard()->StartMarkDummy())
				{
					m_nErrMsgID = STDGNALM445; // count No error
					CString strFile, strLog;
					strFile.Format(_T("ReadHole"));
					strLog.Format(_T("StartMarkDummy Error"));
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					m_pLineDummyTime.Finish();
					return FALSE;
				}
			}
			
			return FALSE;
		}
		
		time(&timeNow);
		double dNowTimeOne = difftime(timeNow, timeStart);
		if(dNowTimeOne > (double)nPreHeatTime)
			break;
	}

	gDeviceFactory.GetEocard()->LaserOnOff(FALSE);
	strLog.Format(_T("Auto Finish LaserPreheat : Time : %d min, Freq. = %dHz, Duty = %.1f"),
			gProcessINI.m_sProcessCal.nAutoRunPreheatTime,
			gProcessINI.m_sProcessCal.nAutoRunPreheatFreq,
			gProcessINI.m_sProcessCal.dAutoRunPreheatDuty);
	pDlg->WriteProcessLog(strLog,_T(""));

	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
	{
		if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
		{
			if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
			{
				m_nErrMsgID = STDGNALM781;
				return FALSE;
			}
		}
	}
	else if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
	{
		if(!gDeviceFactory.GetEocard()->StartMarkDummy())
		{
			m_nErrMsgID = STDGNALM445; // count No error
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("StartMarkDummy Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			m_pLineDummyTime.Finish();
			return FALSE;
		}
	}
	time(&timeNow);
	gTempINI.m_sTempTime.nAutoPreheatEndTime = (int)timeNow;	
	
	CString strFile;
	strFile.Format(_T("PreWork"));
	strLog.Format(_T("AutoRun Last PreHeat Time Save : %d"), gTempINI.m_sTempTime.nAutoPreheatEndTime);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	return TRUE;
}
void CPaneAutoRun::ScannerWamup()
{
	int nX = 0, nY = 0, nStep;
	BOOL bPlus = TRUE;
	nStep = 65535/5;

	for(int i = 0; i< 1000; i++)
	{
		if(bPlus)
		{
			nX += nStep;
			nY += nStep;
		}
		else
		{
			nX -= nStep;
			nY -= nStep;
		}
		
		if(nX == 65535 || nY == 65535)
			bPlus = FALSE;
		else if(nX == 0 || nY == 0)
			bPlus = TRUE;
#ifdef __KUNSAN_8__
		::Sleep(1);
#endif	
		gDeviceFactory.GetEocard()->mark(nX, nY, nX, nY,	HALF_LSB, HALF_LSB, HALF_LSB, HALF_LSB);
	}
}
BOOL CPaneAutoRun::BusyCheck()
{
	BOOL bResult = TRUE;

	while(bResult)
	{
		BOOL bScannerCableError = gDeviceFactory.GetEocard()->IsScannerCableError();
		BOOL bScannerMotorFault = gDeviceFactory.GetEocard()->IsMotorFault();
		BOOL bScannerDrillTimeOut = gDeviceFactory.GetEocard()->IsDrillTimeOut();
		BOOL bTimeOutType =  gDeviceFactory.GetEocard()->IsDrillTimeOutType();
		CString strErrorMsg = _T("");
		if(bScannerCableError)
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			m_nErrMsgID = STDGNALM1017;
			m_strErrorPlus = _T("Scanner Cable Error.");
			return FALSE;
		}
		else if(bScannerMotorFault)
		{
			if(bScannerMotorFault & 0x01)
				strErrorMsg += _T("Scanner Master X Motor Fault\r\n");
			if(bScannerMotorFault & 0x02)
				strErrorMsg += _T("Scanner Master Y Motor Fault\r\n");
			if(bScannerMotorFault & 0x04)
				strErrorMsg += _T("Scanner Slave X Motor Fault\r\n");
			if(bScannerMotorFault & 0x08)
				strErrorMsg += _T("Scanner Slave Y Motor Fault\r\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			m_nErrMsgID = STDGNALM1017;
			m_strErrorPlus = strErrorMsg;
			return FALSE;
		}
		else if(bScannerDrillTimeOut)
		{
			if(bScannerDrillTimeOut & 0x01)
				strErrorMsg += _T("Scanner Master X Drill Time Out\r\n");
			if(bScannerDrillTimeOut & 0x02)
				strErrorMsg += _T("Scanner Master Y Drill Time Out\r\n");
			if(bScannerDrillTimeOut & 0x04)
				strErrorMsg += _T("Scanner Slave X Drill Time Out\r\n");
			if(bScannerDrillTimeOut & 0x08)
				strErrorMsg += _T("Scanner Slave Y Drill Time Out\r\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			m_nErrMsgID = STDGNALM1017;
			m_strErrorPlus = strErrorMsg;
			return FALSE;
		}
		else if(bTimeOutType)
		{
			if(bTimeOutType & 0x01)
				strErrorMsg += _T("Unknown Time Out\r\n");
			if(bTimeOutType & 0x02)
				strErrorMsg += _T("Drill Time Out\r\n");
			if(bTimeOutType & 0x04)
				strErrorMsg += _T("LPC Time Out\r\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			m_nErrMsgID = STDGNALM566;
			m_strErrorPlus = strErrorMsg;
			return FALSE;
		}
		if(!CheckStatus())
		{
			gDeviceFactory.GetEocard()->EStop();
			::Sleep(200);
			return FALSE;
		}
		bResult = gDeviceFactory.GetEocard()->IsDSPBusy();
	}

	return TRUE;
}


BOOL CPaneAutoRun::OnDoPowerMeasurement()
{
	CString strSequenceLog;
	strSequenceLog.Format(_T("---Power Measurement Start---"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
	CCorrectTime dDrillTime;
	double dDrillSec;
	dDrillTime.StartTime();
	CTime cStartTime, cEndTime;
	cStartTime = CTime::GetCurrentTime();
	
	BOOL bRet = CheckPowerAuto();
#ifdef __TEST__
	bRet = TRUE;
#endif
	cEndTime = CTime::GetCurrentTime();
	dDrillSec = dDrillTime.PresentTime();
	SaveJobTimeLog(cStartTime.GetYear(), cStartTime.GetMonth(), cStartTime.GetDay(),
					cStartTime.GetHour(), cStartTime.GetMinute(),	cStartTime.GetSecond(),
					cEndTime.GetYear(), cEndTime.GetMonth(), cEndTime.GetDay(),
					cEndTime.GetHour(), cEndTime.GetMinute(),	cEndTime.GetSecond(), (int)dDrillSec, POWER_JOB);
	
	m_dlgMeasurement.ShowWindow(SW_HIDE);
	
	if(bRet)
	{
		return TRUE;
	}	

	return FALSE;
}

void CPaneAutoRun::KillRunThread()
{
	m_bRunThreadEnd = TRUE;
	
	DWORD retCode;
	
	if(m_pCheckPreTimeThread)
	{
		retCode = ::WaitForSingleObject(m_pCheckPreTimeThread->m_hThread, 65000); //1분씩 도는 쓰레드니깐 
		m_pCheckPreTimeThread = NULL;
	}


}

BOOL CPaneAutoRun::DoFindCurrentShot(BOOL bUseLowCam, BOOL bDryRunCheck, int nFireMode)
{

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
	double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
	int nSelHead = gDProject.m_nSeparation;
	int nDivision = GetDivision();
	double dStartZ1, dStartZ2;

	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
	{
		m_nErrMsgID = STDGNALM417;
		return FALSE;
	}

	BOOL bFindFast = FALSE;
	if(gProcessINI.m_sProcessScannerCal.bDefaultLow == bUseLowCam)
		bFindFast = TRUE;
	
	if(bUseLowCam)
	{
		dStartZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - dCalThick;
		dStartZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - dCalThick2nd;
	}
	else
	{	
		dStartZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - dCalThick;
		dStartZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - dCalThick2nd;
	}
	
	if (!pMotor->MoveZ(dStartZ1, dStartZ2))
	{
		m_nErrMsgID = STDGNALM438; 
		return FALSE;
	}
	
	if (TRUE != pMotor->InPositionIO(IND_Z1 + IND_Z2))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		return FALSE;
	}

	CString szPath;
	if(bDryRunCheck)
	{
		CTime ct = CTime::GetCurrentTime();
		szPath.Format(_T("%sCalOffset%d%02d%02d%02d%02d.txt"), gEasyDrillerINI.m_clsDirPath.GetConvertedDir(),ct.GetYear(),ct.GetMonth(),ct.GetDay(),ct.GetHour(), ct.GetMinute());
	}
	else
		szPath.Format(_T("%sCalOffset.txt"), gEasyDrillerINI.m_clsDirPath.GetConvertedDir());
	CFile file;
	
	TCHAR szCode[128];
	DPOINT *pdPos = NULL, *pdOffset = NULL;
	bool* pSuccess = NULL;
	DPOINT *pdPos2 = NULL, *pdOffset2 = NULL;
	bool* pSuccess2 = NULL;
	TRY
	{
		pdPos = new DPOINT[nDivision * nDivision];
		pdOffset = new DPOINT[nDivision * nDivision];
		pSuccess = new bool[nDivision * nDivision];

		pdPos2 = new DPOINT[nDivision * nDivision];
		pdOffset2 = new DPOINT[nDivision * nDivision];
		pSuccess2 = new bool[nDivision * nDivision];
	}
	CATCH (CMemoryException, e)
	{
		if (pdPos != NULL)
			delete [] pdPos;
		if (pdOffset != NULL)
			delete [] pdOffset;
		if (pSuccess != NULL)
			delete [] pSuccess;

		if (pdPos2 != NULL)
			delete [] pdPos2;
		if (pdOffset2 != NULL)
			delete [] pdOffset2;
		if (pSuccess2 != NULL)
			delete [] pSuccess2;
		
		e->ReportError();
		e->Delete();
		return 0;
	}
	END_CATCH

	emHEAD n1stUse = emNone, n2ndUse = emNone;
	if(nSelHead != SEL_HEAD_SLAVE)
		n1stUse = emMaster;
	if (nSelHead != SEL_HEAD_MASTER)
		n2ndUse = emSlave;
	
	for (int i = 0; i < nDivision * nDivision; i++)
	{
		pSuccess[i] = true;
		pdPos[i].x = pdPos[i].y = 0.0;
		pdOffset[i].x = pdOffset[i].y = 0.0;
		
		pSuccess2[i] = true;
		pdPos2[i].x = pdPos2[i].y = 0.0;
		pdOffset2[i].x = pdOffset2[i].y = 0.0;
	}

	BOOL bPostFound = TRUE;
	if(bFindFast)
	{
		bPostFound = FindCurrentShot(dStartZ1, dStartZ2, nFireMode, n1stUse, n2ndUse, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
	}
	else
	{
		if(n1stUse == emMaster)
			bPostFound = FindCurrentShot(dStartZ1, dStartZ2, nFireMode, n1stUse, pdPos, pdOffset, pSuccess);
		if(bPostFound && n2ndUse == emSlave)
			bPostFound = FindCurrentShot(dStartZ1, dStartZ2, nFireMode, n2ndUse, pdPos2, pdOffset2, pSuccess2);
	}
	

	if(nFireMode == FIND_4_EDGE_MODE)
	{
		CString strFile, strLog;
		strFile.Format(_T("SCal_Time_Log"));
		strLog.Format(_T("Find Result"));								
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		if(gProcessINI.m_sProcessOption.nTemperMeasureMode)
		{
			double dTargetT= m_dTargetTemper;
			if(gProcessINI.m_sProcessOption.nTemperMeasureMode == 2)
			{
				if(n1stUse == emMaster)
					dTargetT = m_dScal1stSBTemper;
				if(n2ndUse == emSlave)
					dTargetT = m_dScal2ndSBTemper;
			}
			int nDivide = 8 / (gProcessINI.m_sProcessOption.nTemperCompenGridNo - 1); // (MAX_GRID_NO - 1) / (m_nGrid - 1);
			for(int i = 0; i < 9; i++)
			{
				for(int j = 0; j < 9; j++)
				{
					if(i % nDivide == 0 && j % nDivide == 0)
					{
						if(n1stUse == emMaster)
						{
							strLog.Format(_T("Mater [ %d ][[ %d ]\t %.3f \t %d \t %.0f \t %.0f \t %.3f \t %.3f"),  
											i, 8 - j, dTargetT, m_nDoASCTool, 	pdPos[i * 9 + j].x, pdPos[i * 9 + j].y, pdOffset[i * 9 + j].x, pdOffset[i * 9 + j].y);								
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));		
						}
						if(n2ndUse == emSlave)
						{
							strLog.Format(_T("Slave [ %d ][[ %d ]\t %.3f \t %d \t %.0f \t %.0f \t %.3f \t %.3f"),  
											i, 8 - j, dTargetT, m_nDoASCTool, 	pdPos2[i * 9 + j].x, pdPos2[i * 9 + j].y, pdOffset2[i * 9 + j].x, pdOffset2[i * 9 + j].y);								
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));	
						}
					}
				}
			}
			if(gProcessINI.m_sProcessOption.nTemperMeasureMode == 1)
			{
				if(n1stUse == emMaster)
					gDeviceFactory.Get1stTemperCompen()->SetOneData(m_dScal1stTemper, pdOffset);
				if(n2ndUse == emSlave)
					gDeviceFactory.Get2ndTemperCompen()->SetOneData(m_dScal2ndTemper, pdOffset2);
			}
			else
			{
				if(n1stUse == emMaster)
					gDeviceFactory.Get1stTemperCompen()->SetOneData(m_dScal1stSBTemper, pdOffset);
				if(n2ndUse == emSlave)
					gDeviceFactory.Get2ndTemperCompen()->SetOneData(m_dScal2ndSBTemper, pdOffset2);
			}
		}
		if(gProcessINI.m_sProcessOption.bTemperVerifyMode)
		{
			double dRepeatOffset[4][4], dRepeatOffset2[4][4];
			int nRepeatIndex[4], nRepeatIndex2[4];
			nRepeatIndex[0] = nRepeatIndex[1] = nRepeatIndex[2] = nRepeatIndex[3] = 0;
			nRepeatIndex2[0] = nRepeatIndex2[1] = nRepeatIndex2[2] = nRepeatIndex2[3] = 0;
			int nDivide = 8 / (gProcessINI.m_sProcessOption.nTemperCompenGridNo - 1); // (MAX_GRID_NO - 1) / (m_nGrid - 1);
			for(int i = 0; i < 9; i++)
			{
				for(int j = 0; j < 9; j++)
				{
					if(gProcessINI.m_sProcessOption.nTemperCompenGridNo == 2) // 양산 중 불량 체크를 해야하는 경우임. 보정된 홀 중 최외각 4점만 찾는다
					{
						int nRepeatCompenCnt = (int)(pow(2., m_nTempCompenCurrentLotCount));
						if( nRepeatCompenCnt &  gProcessINI.m_sProcessOption.nTempRepeatCompenLotCount ||
							(m_nTempCompenCurrentLotCount == 0 && gProcessINI.m_sProcessOption.nTempRepeatCompenLotCount > 0) ) // repeat 보정일때
						{
							if( (i == 1 && (j == 1 || j == 3 || j == 5 || j == 7)) || // 외각 12포인트
								(i == 3 && (j == 1 || j == 7)) ||
								(i == 5 && (j == 1 || j == 7)) ||
								(i == 7 && (j == 1 || j == 3 || j == 5 || j == 7)) ) {}
							else
								continue;
						}
						else // 검증 모드일때
						{
							if((i != 1 && i != 7) || (j != 1 && j != 7) ) // 최외곽 아닌 것을 찾는다. (Temper Offset 영향을 보기 위해서)
									continue;
						}
					}
					else
					{
						if(i % nDivide != 0 || j % nDivide != 0)
						{
							if((i != 1 && i != 7) || (j != 1 && j != 7) ) // 최외곽 아닌 것을 찾는다. (Temper Offset 영향을 보기 위해서)
								continue;
						}
					}
					if(n1stUse == emMaster)
					{
						strLog.Format(_T("Mater [ %d ][[ %d ]\t %.3f \t %d \t %.0f \t %.0f \t %.3f \t %.3f"),  
										i, 8 - j, m_dTargetTemper, m_nDoASCTool, 	pdPos[i * 9 + j].x, pdPos[i * 9 + j].y, pdOffset[i * 9 + j].x, pdOffset[i * 9 + j].y);								
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));	
						if( i == 1 )
						{
							dRepeatOffset[0][nRepeatIndex[0]] = - pdOffset[i * 9 + j].x * 65535 / gSystemINI.m_sSystemDevice.dFieldSize.x;
							nRepeatIndex[0]++;
						}
						if( i == 7 )
						{
							dRepeatOffset[1][nRepeatIndex[1]] = - pdOffset[i * 9 + j].x * 65535 / gSystemINI.m_sSystemDevice.dFieldSize.x;
							nRepeatIndex[1]++;
						}
						if( 8 - j == 1 )
						{
							dRepeatOffset[2][nRepeatIndex[2]] = - pdOffset[i * 9 + j].y * 65535 / gSystemINI.m_sSystemDevice.dFieldSize.x;
							nRepeatIndex[2]++;
						}
						if( 8 - j == 7 )
						{
							dRepeatOffset[3][nRepeatIndex[3]] = - pdOffset[i * 9 + j].y * 65535 / gSystemINI.m_sSystemDevice.dFieldSize.x;
							nRepeatIndex[3]++;
						}
					}
					if(n2ndUse == emSlave)
					{
						strLog.Format(_T("Slave [ %d ][[ %d ]\t %.3f \t %d \t %.0f \t %.0f \t %.3f \t %.3f"),  
										i, 8 - j, m_dTargetTemper, m_nDoASCTool, 	pdPos2[i * 9 + j].x, pdPos2[i * 9 + j].y, pdOffset2[i * 9 + j].x, pdOffset2[i * 9 + j].y);								
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));	

						if( i == 1 )
						{
							dRepeatOffset2[0][nRepeatIndex2[0]] = - pdOffset2[i * 9 + j].x * 65535 / gSystemINI.m_sSystemDevice.dFieldSize.x;
							nRepeatIndex2[0]++;
						}
						if( i == 7 )
						{
							dRepeatOffset2[1][nRepeatIndex2[1]] = - pdOffset2[i * 9 + j].x * 65535 / gSystemINI.m_sSystemDevice.dFieldSize.x;
							nRepeatIndex2[1]++;
						}
						if( 8 - j == 1 )
						{
							dRepeatOffset2[2][nRepeatIndex2[2]] = - pdOffset2[i * 9 + j].y * 65535 / gSystemINI.m_sSystemDevice.dFieldSize.x;
							nRepeatIndex2[2]++;
						}
						if( 8 - j == 7 )
						{
							dRepeatOffset2[3][nRepeatIndex2[3]] = - pdOffset2[i * 9 + j].y * 65535 / gSystemINI.m_sSystemDevice.dFieldSize.x;
							nRepeatIndex2[3]++;
						}
					}
				}
			}
			// Repeat compen 적용
			if(gProcessINI.m_sProcessOption.nTemperCompenGridNo == 2) // 양산 중 불량 체크를 해야하는 경우임. 보정된 홀 중 최외각 4점만 찾는다
			{
				int nRepeatCompenCnt = (int)(pow(2., m_nTempCompenCurrentLotCount));
				if( nRepeatCompenCnt &  gProcessINI.m_sProcessOption.nTempRepeatCompenLotCount ||
					(m_nTempCompenCurrentLotCount == 0 && gProcessINI.m_sProcessOption.nTempRepeatCompenLotCount > 0) ) // repeat 보정일때
				{
					// transform 2D
					if(n1stUse == emMaster)
					{
						// find min, max and 통계에서 제외 --> index 0에 다시 덮어씀
						for(int i = 0; i < 4; i++)
						{
							int nMinIndex = 0, nMaxIndex = 0;
							double dMinVal = dRepeatOffset[i][0], dMaxVal = dRepeatOffset[i][0];
							double dTotal = dRepeatOffset[i][0];
							for(int j = 1; j < 4; j++)
							{
								if(dMinVal > dRepeatOffset[i][j])
								{
									dMinVal = dRepeatOffset[i][j];
									nMinIndex = j;
								}
								if(dMaxVal < dRepeatOffset[i][j])
								{
									dMaxVal = dRepeatOffset[i][j];
									nMaxIndex = j;
								}
								dTotal += dRepeatOffset[i][j];
							}
							dTotal -= (dRepeatOffset[i][nMinIndex] + dRepeatOffset[i][nMaxIndex]);
							dRepeatOffset[i][0] = dTotal/2;
						}
						// 기존 trans에서 적용값 더함.
						CDPoint ptTrans;
						ptTrans = m_2DTrans1stForTempCompen.GetTransPoint(0);
						ptTrans.x += dRepeatOffset[0][0];
						ptTrans.y += dRepeatOffset[2][0];
						m_2DTrans1stForTempCompen.SetTransformedPoint(ptTrans.x, ptTrans.y, 0);

						ptTrans = m_2DTrans1stForTempCompen.GetTransPoint(1);
						ptTrans.x += dRepeatOffset[0][0];
						ptTrans.y += dRepeatOffset[3][0];
						m_2DTrans1stForTempCompen.SetTransformedPoint(ptTrans.x, ptTrans.y, 1);

						ptTrans = m_2DTrans1stForTempCompen.GetTransPoint(2);
						ptTrans.x += dRepeatOffset[1][0];
						ptTrans.y += dRepeatOffset[2][0];
						m_2DTrans1stForTempCompen.SetTransformedPoint(ptTrans.x, ptTrans.y, 2);

						ptTrans = m_2DTrans1stForTempCompen.GetTransPoint(3);
						ptTrans.x += dRepeatOffset[1][0];
						ptTrans.y += dRepeatOffset[3][0];
						m_2DTrans1stForTempCompen.SetTransformedPoint(ptTrans.x, ptTrans.y, 3);
						m_2DTrans1stForTempCompen.Transform();
					}
					if(n2ndUse == emSlave)
					{
						// find min, max and 통계에서 제외 --> index 0에 다시 덮어씀
						for(int i = 0; i < 4; i++)
						{
							int nMinIndex = 0, nMaxIndex = 0;
							double dMinVal = dRepeatOffset2[i][0], dMaxVal = dRepeatOffset2[i][0];
							double dTotal = dRepeatOffset2[i][0];
							for(int j = 1; j < 4; j++)
							{
								if(dMinVal > dRepeatOffset2[i][j])
								{
									dMinVal = dRepeatOffset2[i][j];
									nMinIndex = j;
								}
								if(dMaxVal < dRepeatOffset2[i][j])
								{
									dMaxVal = dRepeatOffset2[i][j];
									nMaxIndex = j;
								}
								dTotal += dRepeatOffset2[i][j];
							}
							dTotal -= (dRepeatOffset2[i][nMinIndex] + dRepeatOffset2[i][nMaxIndex]);
							dRepeatOffset2[i][0] = dTotal/2;
						}
						// 기존 trans에서 적용값 더함.
						CDPoint ptTrans;
						ptTrans = m_2DTrans2ndForTempCompen.GetTransPoint(0);
						ptTrans.x += dRepeatOffset2[0][0];
						ptTrans.y += dRepeatOffset2[2][0];
						m_2DTrans2ndForTempCompen.SetTransformedPoint(ptTrans.x, ptTrans.y, 0);

						ptTrans = m_2DTrans2ndForTempCompen.GetTransPoint(1);
						ptTrans.x += dRepeatOffset2[0][0];
						ptTrans.y += dRepeatOffset2[3][0];
						m_2DTrans2ndForTempCompen.SetTransformedPoint(ptTrans.x, ptTrans.y, 1);

						ptTrans = m_2DTrans2ndForTempCompen.GetTransPoint(2);
						ptTrans.x += dRepeatOffset2[1][0];
						ptTrans.y += dRepeatOffset2[2][0];
						m_2DTrans2ndForTempCompen.SetTransformedPoint(ptTrans.x, ptTrans.y, 2);

						ptTrans = m_2DTrans2ndForTempCompen.GetTransPoint(3);
						ptTrans.x += dRepeatOffset2[1][0];
						ptTrans.y += dRepeatOffset2[3][0];
						m_2DTrans2ndForTempCompen.SetTransformedPoint(ptTrans.x, ptTrans.y, 3);
						m_2DTrans2ndForTempCompen.Transform();
					}
				}
			}
		}
		delete [] pdPos;
		delete [] pdOffset;
		delete [] pSuccess;
		delete [] pdPos2;
		delete [] pdOffset2;
		delete [] pSuccess2;
		return bPostFound;
	}

	if (!bPostFound)
	{
		delete [] pdPos;
		delete [] pdOffset;
		delete [] pSuccess;
		
		delete [] pdPos2;
		delete [] pdOffset2;
		delete [] pSuccess2;
		
		return 0;
	}

	if (FALSE == file.Open(szPath, CFile::modeCreate|CFile::modeWrite))
	{
		return FALSE;
	}

	// Master 시작
	TRY
	{
		m_dMaxOffsetMasterX = 0;
		m_dMaxOffsetMasterY = 0;
		
		for (int i = 0; i < nDivision * nDivision; i++)
		{
			m_calAGCMaster.AddOffsetInfo(pdPos[i].x, pdPos[i].y, pdOffset[i].x, pdOffset[i].y);
			if (pSuccess[i])
			{
				_stprintf_s(szCode, "T-Cmd Pos:(%f, %f), Offset :(%f,%f)\r\n", pdPos[i].x, pdPos[i].y, pdOffset[i].x, pdOffset[i].y);
				if(fabs(m_dMaxOffsetMasterX) < fabs(pdOffset[i].x))
					m_dMaxOffsetMasterX = fabs(pdOffset[i].x);
				if(fabs(m_dMaxOffsetMasterY) < fabs(pdOffset[i].y))
					m_dMaxOffsetMasterY = fabs(pdOffset[i].y);
			}
			else
			{
				_stprintf_s(szCode, "F-Cmd Pos:(%f, %f), Offset :(%f,%f)\r\n", pdPos[i].x, pdPos[i].y, pdOffset[i].x, pdOffset[i].y);
				if(fabs(m_dMaxOffsetMasterX) < fabs(pdOffset[i].x))
					m_dMaxOffsetMasterX = fabs(pdOffset[i].x);
				if(fabs(m_dMaxOffsetMasterY) < fabs(pdOffset[i].y))
					m_dMaxOffsetMasterY = fabs(pdOffset[i].y);
			}
			
			file.Write(szCode, strlen(szCode));
		}
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		
		file.Close();
		delete [] pdPos;
		delete [] pdOffset;
		delete [] pSuccess;
		delete [] pdPos2;
		delete [] pdOffset2;
		delete [] pSuccess2;
		return 0;
	}
	END_CATCH
	// Master 끝
	TRY
	{
		m_dMaxOffsetSlaveX = 0;
		m_dMaxOffsetSlaveY = 0;

		for (int i = 0; i < nDivision * nDivision; i++)
		{
			m_calAGCSlave.AddOffsetInfo(pdPos2[i].x, pdPos2[i].y, pdOffset2[i].x, pdOffset2[i].y);
			if (pSuccess[i])
			{
				_stprintf_s(szCode, "T-Cmd Pos:(%f, %f), Offset :(%f,%f)\r\n", pdPos2[i].x, pdPos2[i].y, pdOffset2[i].x, pdOffset2[i].y);
				if(fabs(m_dMaxOffsetSlaveX) < fabs(pdOffset2[i].x))
					m_dMaxOffsetSlaveX = fabs(pdOffset2[i].x);
				if(fabs(m_dMaxOffsetSlaveY) < fabs(pdOffset2[i].y))
					m_dMaxOffsetSlaveY = fabs(pdOffset2[i].y);				
			}
			else
			{
				_stprintf_s(szCode, "F-Cmd Pos:(%f, %f), Offset :(%f,%f)\r\n", pdPos2[i].x, pdPos2[i].y, pdOffset2[i].x, pdOffset2[i].y);
				if(fabs(m_dMaxOffsetSlaveX) < fabs(pdOffset2[i].x))
					m_dMaxOffsetSlaveX = fabs(pdOffset2[i].x);
				if(fabs(m_dMaxOffsetSlaveY) < fabs(pdOffset2[i].y))
					m_dMaxOffsetSlaveY = fabs(pdOffset2[i].y);
			}

			file.Write(szCode, strlen(szCode));
		}
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
		
		file.Close();
		delete [] pdPos;
		delete [] pdOffset;
		delete [] pSuccess;
		delete [] pdPos2;
		delete [] pdOffset2;
		delete [] pSuccess2;
		return 0;
	}
	END_CATCH
	////////////////////////////////////////////////////
	file.Close();
//	gDeviceFactory.GetEocard()->MoveToCenter();
	WriteCalibrationStopEvent(TRUE);

	if(bDryRunCheck)
	{
		;
	}
	else
	{
		CString strEvent, strInfo;
		if(nSelHead == 0)
		{	
			if(nFireMode == FIND_ONLY_CENTER_MODE)
				strEvent = _T("Automatic Scanner Head Offset Check result.");
			else
				strEvent = _T("Automatic scanner calibration result.");
			strInfo.Format(_T("1st Panel Head Max. ( X = %.3f um, Y = %.3f um ) | 2nd Panel Head Max. ( X = %.3f um, Y = %.3f um )"),
				m_dMaxOffsetMasterX*1000, m_dMaxOffsetMasterY*1000, m_dMaxOffsetSlaveX*1000, m_dMaxOffsetSlaveY*1000);
			
			if(nFireMode != FIND_4_EDGE_MODE)
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
		}
		else if(nSelHead == SEL_HEAD_MASTER)
		{
			if(nFireMode == FIND_ONLY_CENTER_MODE)
				strEvent = _T("Automatic Scanner Head Offset Check result.");
			else
				strEvent = _T("Automatic scanner calibration result.");
			strInfo.Format(_T("1st Panel Head Max. ( X = %.3f um, Y = %.3f um )"), m_dMaxOffsetMasterX*1000, m_dMaxOffsetMasterY*1000);
			
			if(nFireMode != FIND_4_EDGE_MODE)
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
		}
		else if(nSelHead == SEL_HEAD_SLAVE)
		{
			if(nFireMode == FIND_ONLY_CENTER_MODE)
				strEvent = _T("Automatic Scanner Head Offset Check result.");
			else
				strEvent = _T("Automatic scanner calibration result.");;
			strInfo.Format(_T("2nd Panel Head Max. ( X = %.3f um, Y = %.3f um )"), m_dMaxOffsetSlaveX*1000, m_dMaxOffsetSlaveY*1000);
			
			if(nFireMode != FIND_4_EDGE_MODE)
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
		}
	}
	
	delete [] pdPos;
	delete [] pdOffset;
	delete [] pSuccess;
	delete [] pdPos2;
	delete [] pdOffset2;
	delete [] pSuccess2;
	return TRUE;
}

BOOL CPaneAutoRun::DoFireCalibrationHole(int nSelHead, BOOL bUseLowCam, BOOL bGetHeadOffset, BOOL bOnlyCenterPointFire)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	BOOL bFindFast = FALSE;
	if(gProcessINI.m_sProcessScannerCal.bDefaultLow == bUseLowCam)
		bFindFast = TRUE;
	
	// Master 찍기
	if (nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_MASTER)
	{
		if(!pMotor->MoveXY(m_dCalculateStartXAuto, m_dCalculateStartYAuto, TRUE, SHOT_MOVE))
		{
			m_nErrMsgID = STDGNALM438; 
			return FALSE;
		}		
		
		if (TRUE != pMotor->InPositionIO(IND_X + IND_Y))
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
			return FALSE;
		}
#ifdef __OSAN_LG__
		if(TRUE) // 오산에서 DryRun으로 Prework만 돌림 - prewor data 옵션으로 안된다 함 
#else
		if(!gProcessINI.m_sProcessSystem.bDryRun)
#endif
		{
			if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(TRUE, FALSE, FALSE))
			{
				m_nErrMsgID = STDGNALM417;
				return FALSE;
			}
		}
		
		::Sleep(CALIBRATION_SLEEP);

		if(!CheckStatus()) // Stop확인
			return FALSE;
		
		if (!FireCalibrationHole(TRUE, TRUE, FALSE, bOnlyCenterPointFire))
		{
			if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
			{
				m_nErrMsgID = STDGNALM417;
				return FALSE;
			}
			return FALSE;
		}

		if(bGetHeadOffset)
		{
			if(!CheckStatus())
				return FALSE;
			
			if(!pMotor->MoveXY(m_dOffsetStartXAuto, m_dOffsetStartYAuto, TRUE, SHOT_MOVE))
			{
				m_nErrMsgID = STDGNALM438; 
				return FALSE;
			}
			if (TRUE != pMotor->InPositionIO(IND_X + IND_Y)) 
			{
				int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
				CheckInpositionError(nErrorAxis);
				return FALSE;
			}
			
			if (!FireCalibrationHole(TRUE, TRUE, TRUE))
			{
				if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
				{
					m_nErrMsgID = STDGNALM417;
					return FALSE;
				}
				return FALSE;
			}
		}

		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
		{
			m_nErrMsgID = STDGNALM417;
			return FALSE;
		}
	}
	
	// Slave 찍기
	if (nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_SLAVE)
	{
		double dFirePosOffsetX, dFirePosOffsetY;
		// 카메라에 따른 위치 맞추기
		if(gProcessINI.m_sProcessScannerCal.bDefaultLow)
		{
			dFirePosOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dFirePosOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		}
		else
		{	
			dFirePosOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
			dFirePosOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y - gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		}

		if(!pMotor->MoveXY(m_dCalculateStartXAuto - dFirePosOffsetX, m_dCalculateStartYAuto - dFirePosOffsetY, FALSE, SHOT_MOVE))
		{
			m_nErrMsgID = STDGNALM438; 
			return FALSE;
		}
		
		if (TRUE != pMotor->InPositionIO(IND_X + IND_Y)) 
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
			return FALSE;
		}
#ifndef __OSAN_LG__
		if(!gProcessINI.m_sProcessSystem.bDryRun)
#else
		if(TRUE) // 오산에서 DryRun으로 Prework만 돌림 - prewor data 옵션으로 안된다 함 
#endif
		{
			if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, TRUE, FALSE))
			{
				m_nErrMsgID = STDGNALM417; 
				return FALSE;
			}
		}
		
		::Sleep(CALIBRATION_SLEEP);

		if(!CheckStatus()) // Stop확인
			return FALSE;
		
		if (!FireCalibrationHole(TRUE, FALSE, FALSE, bOnlyCenterPointFire))
		{
			if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
			{
				m_nErrMsgID = STDGNALM417;
				return FALSE;
			}

			return FALSE;
		}
		if(bGetHeadOffset)
		{
			if(!CheckStatus())
				return FALSE;
			
			if(!pMotor->MoveXY(m_dOffsetStartXAuto, m_dOffsetStartYAuto, FALSE, SHOT_MOVE))
			{
				m_nErrMsgID = STDGNALM438; 
				return FALSE;
			}
			if (TRUE != pMotor->InPositionIO(IND_X + IND_Y)) 
			{
				int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
				CheckInpositionError(nErrorAxis);
				return FALSE;
			}
			
			if (!FireCalibrationHole(TRUE, FALSE, TRUE))
			{
				if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
				{
					m_nErrMsgID = STDGNALM417;
					return FALSE;
				}
				return FALSE;
			}
		}

		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE))
		{
			m_nErrMsgID = STDGNALM417;
			return FALSE;
		}
	}

	return TRUE;
}

BOOL CPaneAutoRun::DoFindPreviousHole(BOOL bUseLowCam, BOOL bOnlyCenterPointFire)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	BOOL bFindFast = FALSE;
	if(gProcessINI.m_sProcessScannerCal.bDefaultLow == bUseLowCam)
		bFindFast = TRUE;

	double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
	double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
	int nSelHead = gDProject.m_nSeparation;
	double dStartPrefindZ1, dStartPrefindZ2 = 0.;
	int nMax = max(1, gProcessINI.m_sProcessCal.nAutoCalibrationCount);

	if(bUseLowCam)
	{
		dStartPrefindZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - dCalThick;
		dStartPrefindZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - dCalThick2nd;
	}
	else
	{
		dStartPrefindZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - dCalThick;
		dStartPrefindZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - dCalThick2nd;
	}
	
	if (!pMotor->MoveZ(dStartPrefindZ1, dStartPrefindZ2))
	{
		m_nErrMsgID = STDGNALM438; 
		return FALSE;
	}
	
	if (TRUE != pMotor->InPositionIO(IND_Z1 + IND_Z2))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		return FALSE;
	}
	

	if(!CheckStatus()) // Stop확인
		return FALSE;

	if (!CheckMotorPositionValidity(bOnlyCenterPointFire))
	{
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_ALARM, 1);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
#endif
		m_nErrMsgID = STDGNALM780;
		if(bOnlyCenterPointFire)
			gProcessINI.m_sProcessScannerCal.nCountCheckHeadOffsetAuto--;
		else
			gProcessINI.m_sProcessScannerCal.nCountAuto--;
		::Sleep(500);
#ifndef __MP920_MOTOR__
		pMotor->SetOutPort(PORT_ALARM, 0);
#else
		pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
		return FALSE;
	}

	emHEAD n1stUse = emNone, n2ndUse = emNone;
	if(nSelHead != SEL_HEAD_SLAVE)
		n1stUse = emMaster;
	if (nSelHead != SEL_HEAD_MASTER)
		n2ndUse = emSlave;
	
	BOOL bPreFound = TRUE;
	if(bFindFast)
	{
		bPreFound = FindPreviousShot(dStartPrefindZ1, dStartPrefindZ2, n1stUse, n2ndUse);
	}
	else
	{
		if(n1stUse == emMaster)
			bPreFound = FindPreviousShot(dStartPrefindZ1, dStartPrefindZ2, n1stUse);
		if(bPreFound && n2ndUse == emSlave)
			bPreFound = FindPreviousShot(dStartPrefindZ1, dStartPrefindZ2, n2ndUse);
	}
	if(!bPreFound)
	{
		if(!CheckStatus()) // Stop확인
			return FALSE;

		m_nErrMsgID = STDGNALM779;
		return FALSE;
	}
	return TRUE;
}

BOOL CPaneAutoRun::DoSCalAuto(BOOL bDryRunCheck, BOOL bGetHeadOffset, int nFireMode, int nFireAndFindMode) // AutoRun용 스캐너보정
{
	CString strEvent, strInfo, strTemp;
	CString strSequenceLog;
	strSequenceLog.Format(_T("---Auto Scanner Calibration Start---"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
	if(!ControlDeviceForScal(TRUE))
		return FALSE;

	if(!gProcessINI.m_sProcessSystem.bUseGetHighCamOffset)
		bGetHeadOffset = FALSE;

	BOOL bOnlyCenterPointFire = FALSE;
	if(nFireMode == FIND_ONLY_CENTER_MODE)
		bOnlyCenterPointFire = TRUE;

	if(bOnlyCenterPointFire) // center만 체크하고 넘어가는 옵션인 경우에는 low cam, high cam head offset을 마추지 않는다.
		bGetHeadOffset = FALSE;

	if(!m_bLaser)
	{
		m_nErrMsgID = STDGNALM303;
		return FALSE;
	}
	
	BOOL bResult = TRUE;
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEOCard = gDeviceFactory.GetEocard();
	HVision* pVision = gDeviceFactory.GetVision();

	//do table clamp checking need?

	int nSelHead = gDProject.m_nSeparation;
	for(int k =0; k<BEAMPATH_COUNT; k++)
	{
		if(!m_bASCTool[k])
			continue;

		m_nDoASCTool = k;
		
		if(!DownScalParam())
		{
			return FALSE;
		}
		double dPosX = 0.0, dPosY = 0.0, dStartX = 0.0, dStartY = 0.0;
		dPosX = gProcessINI.m_sProcessScannerCal.dAutoStart.x;
		dPosY = gProcessINI.m_sProcessScannerCal.dAutoStart.y;

		// ROI영역 조절
		if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION || gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
		{
			for(int ii = 0; ii<MAX_CAMERA; ii++)
			{
				
				if(!gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool] ||
					(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode))
				{
					this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nHighCalArea, ii);
				}
				else
				{
					this->SendMessage(UM_VISION_ROI_SET, gSystemINI.m_sSystemDevice.nLowCalArea, ii);
				}
			}
		}

		SVISIONINFO sVisionInfo;
		sVisionInfo.nModelType = 1;
		sVisionInfo.nPolarity = 0;
		sVisionInfo.dSizeA = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nDoASCTool];
		sVisionInfo.dSizeB = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nDoASCTool];
		sVisionInfo.dSizeC = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nDoASCTool];
		
		for(int i=0; i<4; i++)
		{
			sVisionInfo.nCoaxial[i] = gBeamPathINI.m_sBeampath.nScannerCoaxial[m_nDoASCTool];
			sVisionInfo.nRing[i] = gBeamPathINI.m_sBeampath.nScannerRing[m_nDoASCTool];
#ifdef __OSAN_LG_2013__
			if(gSystemINI.m_sHardWare.bTemperCompConnect && 
				(gProcessINI.m_sProcessOption.bTemperVerifyMode || gProcessINI.m_sProcessOption.bTemperCompensationMode))
			{
				sVisionInfo.dContrast[i] = gProcessINI.m_sProcessOption.dTemperVerifyContrast;
				sVisionInfo.dBrightness[i] = gProcessINI.m_sProcessOption.dTemperVerifyBrightness;
			}
			else
			{
				sVisionInfo.dContrast[i] = gBeamPathINI.m_sBeampath.dScannerContrast[m_nDoASCTool];
				sVisionInfo.dBrightness[i] = gBeamPathINI.m_sBeampath.dScannerBrightness[m_nDoASCTool];
			}
#else
			sVisionInfo.dContrast[i] = gBeamPathINI.m_sBeampath.dScannerContrast[m_nDoASCTool];
			sVisionInfo.dBrightness[i] = gBeamPathINI.m_sBeampath.dScannerBrightness[m_nDoASCTool];
#endif
		}
		
		sVisionInfo.dScoreAngle = 0;//.dAngleTolerance;
		sVisionInfo.dScoreSize = gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[m_nDoASCTool];
		sVisionInfo.dAspectRatio = gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[m_nDoASCTool];

		double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
		double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
		int nDivision = GetDivision();

		BOOL bIsSkipBoardCheck = gProcessINI.m_sProcessScannerCal.bIsSkipCheckBoard;
		BOOL bUseLowCam = gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool];//TRUE; // 저배율 기준
		if(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode)
			bUseLowCam = FALSE;


		if(!CheckStatus()) // Stop확인
			return FALSE;

		if(!bUseLowCam)
		{
			bGetHeadOffset = FALSE;
		}

		BOOL bSuccess = FALSE;
		int nDo = 0;
		if(nFireMode == FIND_4_EDGE_MODE) // 4 edge log ( T measure or T verify ) 모드에서는 한번만 가공해야한다. 온도가 정확해야 하므로 
			nDo = gProcessINI.m_sProcessCal.nAutoCalibrationCount - 1;
		// Find Previous Hole & Fire Hole & Find Hole
		for( ; nDo < gProcessINI.m_sProcessCal.nAutoCalibrationCount; nDo++)	
		{
			if(!DownloadASC())
			{
				return FALSE;
			}
			// 횟수체크
			if(bOnlyCenterPointFire)
			{
				if (gProcessINI.m_sProcessScannerCal.nCountCheckHeadOffsetAuto >= MAX_CHECK_HEADOFFSET_COUNT)		
				{
	#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_ALARM, 1);
	#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
	#endif
					m_nErrMsgID = STDGNALM778;
					::Sleep(500);
	#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_ALARM, 0);
	#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
	#endif
					return FALSE;
				}
			}
			else
			{
				int nMaxCount = MAX_AUTOCAL_COUNT;
				if(gProcessINI.m_sProcessCal.nAutoCalibrationFieldCount == 2)
					nMaxCount = MAX_AUTOCAL_COUNT - 100;

				if (gProcessINI.m_sProcessScannerCal.nCountAuto >= nMaxCount)		
				{
	#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_ALARM, 1);
	#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 1);
	#endif
					int nMaxCount = MAX_AUTOCAL_COUNT;
					if(gProcessINI.m_sProcessCal.nAutoCalibrationFieldCount == 2)
						nMaxCount = MAX_AUTOCAL_COUNT - 100;

					m_nErrMsgID = STDGNALM778;
					::Sleep(500);
	#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_ALARM, 0);
	#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
	#endif
					return FALSE;
				}
			}

			// 위치값 계산		
			CalculateAutoStartPosition(bOnlyCenterPointFire);

			strEvent = _T("Started automatic scanner calibration.");
			strInfo = _T("Automatic Calibration | ");
			strTemp.Format(_T("Grid size = %dx%d | Mask No. = %d | PCB Thickness = %f, %f mm | Start Position ( X = %f mm, Y = %f mm )"),
				nDivision, nDivision, GetMaskNo(), dCalThick, dCalThick2nd, m_dCalculateStartXAuto, m_dCalculateStartYAuto);	
			strInfo += strTemp;
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));

			if(nSelHead != SEL_HEAD_SLAVE)
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
				::Sleep(CALIBRATION_SLEEP / 2);
				if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool] == 0 ||
					(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode)) // high vision
				{
					this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
					this->SendMessage(UM_VISION_LAMP, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				}
				else
				{
					this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
					this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				}
			}
			else
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
				::Sleep(CALIBRATION_SLEEP / 2);
				if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool] == 0 ||
					(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode)) // high vision
				{
					this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
					this->SendMessage(UM_VISION_LAMP, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				}
				else
				{
					this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
					this->SendMessage(UM_VISION_LAMP, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				}
			}

			if(!CheckStatus()) // Stop확인
				return FALSE;

			if(nFireMode == FIND_4_EDGE_MODE)
				gProcessINI.m_sProcessScannerCal.nCountAuto++;
			else if(bOnlyCenterPointFire)
				gProcessINI.m_sProcessScannerCal.nCountCheckHeadOffsetAuto++;
			else
				gProcessINI.m_sProcessScannerCal.nCountAuto++;

			// 기존 Hole이 있는 지 확인
			if(!bIsSkipBoardCheck && nFireMode != FIND_4_EDGE_MODE) // 4 edge log 모드에서는 아크릭 먼저 검사 스킵
			{
				if(!DoFindPreviousHole(bUseLowCam, bOnlyCenterPointFire))
				{
					continue;
				}
			}

			// Laser발사~
			if(nFireAndFindMode & T_OFFSET_FIRE)
			{
				if(!DoFireCalibrationHole(nSelHead, bUseLowCam, bGetHeadOffset, bOnlyCenterPointFire))
				{
					continue;
				}
			}

			if(!(nFireAndFindMode & T_OFFSET_FIND)) // find mode가 아니면
				return TRUE;

			if(!CheckStatus()) // Stop확인
				return FALSE;
#ifdef __OSAN_LG__
			if(gProcessINI.m_sProcessSystem.bCheckPreworkData)
#else
			if(gProcessINI.m_sProcessSystem.bCheckPreworkData || gProcessINI.m_sProcessSystem.bDryRun)
#endif
				bDryRunCheck = TRUE;
	
			// Hole찾기
			if(!DoFindCurrentShot(bUseLowCam, bDryRunCheck, nFireMode))
			{
				if(gProcessINI.m_sProcessOption.nTemperCompenGridNo == 2 && gProcessINI.m_sProcessOption.bTemperVerifyMode) // 양산 중 불량 체크를 해야하는 경우임. 보정된 홀 중 최외각 4점만 찾는다
					return FALSE;

				continue;
			}
			if(bGetHeadOffset)
			{
				if(!GetHeadOffset(nSelHead))
					return FALSE;
				
				gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x -= m_dOffsetM.x;
				gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y -= m_dOffsetM.y;
				gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x -= m_dOffsetS.x;
				gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y -= m_dOffsetS.y;
				
				if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, SYSTEM_INI))
				{
					m_nErrMsgID = STDGNALM110;
					return FALSE;
				}
			}
#ifdef __OSAN_LG__
			if(!gProcessINI.m_sProcessSystem.bCheckPreworkData && !bOnlyCenterPointFire && nFireMode != FIND_4_EDGE_MODE)
#else
			if(!gProcessINI.m_sProcessSystem.bCheckPreworkData && !gProcessINI.m_sProcessSystem.bDryRun && !bOnlyCenterPointFire && nFireMode != FIND_4_EDGE_MODE)
#endif
			{
				// apply ASC
				if(!::AfxGetMainWnd()->SendMessage(UM_DO_APPLY_SCAL_RESULT, nSelHead))
				{
#ifdef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_ALARM, 1);
#else
					pMotor->SetOutPort((BYTE)(ADD0B_WRITE_OUTPORT + PORT_ALARM), 1);
#endif
					m_nErrMsgID = STDGNALM116;  
					::Sleep(500);
					
#ifndef __MP920_MOTOR__
					pMotor->SetOutPort(PORT_ALARM, 0);
#else
					pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_ALARM, 0);
#endif
					return FALSE;
				}
							//찾은게 실패건 성공이건 로그남김 
				SaveSCalResult();

				if(fabs(m_dMaxOffsetMasterX*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceX &&  // drilling limit
					fabs(m_dMaxOffsetMasterY*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceY &&
					fabs(m_dMaxOffsetSlaveX*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceX &&
					fabs(m_dMaxOffsetSlaveY*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceY )
				{
					bSuccess = TRUE;
					break;
				}
			}
			else
			{
				if(bOnlyCenterPointFire)
				{
					if(fabs(m_dMaxOffsetMasterX*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceX &&
						fabs(m_dMaxOffsetMasterY*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceY &&
						fabs(m_dMaxOffsetSlaveX*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceX &&
						fabs(m_dMaxOffsetSlaveY*1000) <= gProcessINI.m_sProcessCal.n2ndPreworkToleranceY )
					{
						bSuccess = TRUE;
						break;
					}
					break;
				}
				else
				{
					bSuccess = TRUE;
					break;
				}
			}
		}
		
		if(!gProcessINI.m_sProcessSystem.bCheckPreworkData || !gProcessINI.m_sProcessSystem.bDryRun)
		{
			if(nDo >= gProcessINI.m_sProcessCal.nAutoCalibrationCount)
			{
#ifndef __TEST__
				m_nErrMsgID = STDGNALM712;
				return FALSE;
#endif
			}
		}

		if(bSuccess && !bOnlyCenterPointFire && nFireMode != FIND_4_EDGE_MODE)
		{
			if(nSelHead != SEL_HEAD_SLAVE)
				SaveScalTime(TRUE);
			
			if(nSelHead != SEL_HEAD_MASTER)
				SaveScalTime(FALSE);
		

			double Temp[4];
			Temp[0] = m_dMaxOffsetMasterX;
			Temp[1] = m_dMaxOffsetMasterY;
			Temp[2] = m_dMaxOffsetSlaveX;
			Temp[3] = m_dMaxOffsetSlaveY;
			::AfxGetMainWnd()->SendMessage(UM_SCANNER_RESULT, (WPARAM)Temp, m_nDoASCTool);
		}

		if(!bSuccess)
		{
		#ifndef __TEST__
			m_nErrMsgID = STDGNALM712;
			return FALSE;
		#endif
		}
	}

	if(bResult)
	{
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("Auto Scal Time Save End"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		m_bWorkingAutoSCal = FALSE;
	}

	if(gProcessINI.m_sProcessSystem.bDryRun || gProcessINI.m_sProcessSystem.bCheckPreworkData)
		bResult = TRUE;
	
#ifdef __TEST__
	bResult = TRUE;
#endif
	return bResult;
}

bool CPaneAutoRun::FindPreviousShot(double dZ1, double dZ2, emHEAD emHead)
{
	return FindShot(dZ1, dZ2, FIND_ONLY_CENTER_MODE, emHead, false); // only center find
}

bool CPaneAutoRun::FindPreviousShot(double dZ1, double dZ2, emHEAD em1st, emHEAD em2nd)
{
	return FindShot(dZ1, dZ2, FIND_ONLY_CENTER_MODE, em1st, em2nd, false, NULL);// only center find
}

bool CPaneAutoRun::FindCurrentShot(double dZ1, double dZ2, int nFireMode, emHEAD emHead, DPOINT* pdPos, DPOINT* pdOffset, bool* pSuccess)
{
	return FindShot(dZ1, dZ2, nFireMode, emHead, true, pdPos, pdOffset, pSuccess);
}

bool CPaneAutoRun::FindCurrentShot(double dZ1, double dZ2, int nFireMode, emHEAD em1st, emHEAD em2nd, DPOINT* pdPos, DPOINT* pdOffset, bool* pSuccess, DPOINT* pdPos2, DPOINT* pdOffset2, bool* pSuccess2)
{
	return FindShot(dZ1, dZ2, nFireMode, em1st, em2nd, true, pdPos, pdOffset, pSuccess, pdPos2, pdOffset2, pSuccess2);
}

bool CPaneAutoRun::FindShot(double dZ1, double dZ2, int nFireMode, emHEAD emHead, bool bSave, DPOINT* pdPos, DPOINT* pdOffset, bool* pSuccess)
{
	if(!CheckStatus()) // Stop확인
		return FALSE;

	//탐색순서
	// 1 2 3
	// 6 5 4
	// 7 8 9

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEOCard = gDeviceFactory.GetEocard();
	HVision* pVision = gDeviceFactory.GetVision();

	double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
	double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
	int nDivision = GetDivision();
	int nSelHead = gDProject.m_nSeparation;
	BOOL bIsSkipBoardCheck = gProcessINI.m_sProcessScannerCal.bIsSkipCheckBoard;
	BOOL bUseLowCam = gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool];//TRUE; // 저배율 기준
	if(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode)
		bUseLowCam = FALSE;
	double dStartPosX = m_dCalculateStartXAuto;
	double dStartPosY = m_dCalculateStartYAuto;

	double dMoveX, dMoveY, dPosX = 0.0, dPosY = 0.0;
	
	const double dFieldSize = gSystemINI.m_sSystemDevice.dFieldSize.x;
	const double dHalfFieldSize = dFieldSize / 2.0;
	int nDivide = 8 / (gProcessINI.m_sProcessOption.nTemperCompenGridNo - 1); // (MAX_GRID_NO - 1) / (m_nGrid - 1);
	
	int nRepeatTime = 1;
	if(bSave == true)
		nRepeatTime = 10;
		
	BOOL bMaster;
	if(emHead == emMaster)	bMaster = TRUE;
	else					bMaster = FALSE;

	if (!pMotor->MoveZ(dZ1, dZ2))	
	{
		m_nErrMsgID = STDGNALM438; 
		return FALSE;
	}
	
	if (TRUE != pMotor->InPositionIO(IND_Z1 + IND_Z2))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		return FALSE;
	}

	CString strResult, strPos, strData;
	BOOL bRet;
	int nKK, nCam, nIndexNo, nIndex;
	
	SVISIONINFO sVisionInfo;
	sVisionInfo.nModelType = 1;
	sVisionInfo.nPolarity = 0;
	sVisionInfo.dSizeA = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nDoASCTool];
	sVisionInfo.dSizeB = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nDoASCTool];
	sVisionInfo.dSizeC = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nDoASCTool];
	
	for(int i=0; i<4; i++)
	{
		sVisionInfo.nCoaxial[i] = gBeamPathINI.m_sBeampath.nScannerCoaxial[m_nDoASCTool];
		sVisionInfo.nRing[i] = gBeamPathINI.m_sBeampath.nScannerRing[m_nDoASCTool];
		sVisionInfo.dContrast[i] = gBeamPathINI.m_sBeampath.dScannerContrast[m_nDoASCTool];
		sVisionInfo.dBrightness[i] = gBeamPathINI.m_sBeampath.dScannerBrightness[m_nDoASCTool];
	}
	
	sVisionInfo.dScoreAngle = 0;//.dAngleTolerance;
	sVisionInfo.dScoreSize = gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[m_nDoASCTool];
	sVisionInfo.dAspectRatio = gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[m_nDoASCTool];

	for(int nCountY = 0, nCountX; nCountY < nDivision; nCountY++)
	{
		if(emHead == emMaster && nCountY == 0 && (gSystemINI.m_sHardWare.nVisionType == OMI_VISION || gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO))
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool] == 0 ||
				(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode)) // high vision
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL);
				this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				this->SendMessage(UM_VISION_LAMP, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
			}
			else
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
				this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
			}
		}
		if(emHead == emSlave && nCountY == 0 && (gSystemINI.m_sHardWare.nVisionType == OMI_VISION || gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO))
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool] == 0 ||
				(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode)) // high vision
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL);
				this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				this->SendMessage(UM_VISION_LAMP, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
			}
			else
			{
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
				this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
				this->SendMessage(UM_VISION_LAMP, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
			}
		}

		if(emHead == emMaster)
		{
		if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool] == 0 ||
				(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode))
				dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
			else
				dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
		}
		else if(emHead == emSlave)
		{
			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool] == 0 ||
				(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode))
				dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
			else
				dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
		}
		// 카메라에 따른 위치 맞추기
		if(emHead == emSlave && gProcessINI.m_sProcessScannerCal.bDefaultLow)
		{
			dMoveY -= (gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y);
		}
		if(emHead == emSlave && !gProcessINI.m_sProcessScannerCal.bDefaultLow)
		{
			dMoveY -= (gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y - gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y);
		}

		for (nCountX = 0; nCountX < nDivision; nCountX++)
		{
			if(nFireMode == FIND_ONLY_CENTER_MODE)
			{
				if(nCountX != 4 || nCountY != 4)// center pos이 아닌 경우
					continue;
			}
			else if(nFireMode == FIND_4_EDGE_MODE)
			{
				if(gProcessINI.m_sProcessOption.nTemperMeasureMode)
				{
					if(nCountX % nDivide != 0 || nCountY % nDivide != 0)
					continue;
				}
				if(gProcessINI.m_sProcessOption.bTemperVerifyMode)
				{
					if(gProcessINI.m_sProcessOption.nTemperCompenGridNo == 2) // 양산 중 불량 체크를 해야하는 경우임. 보정된 홀 중 최외각 4점만 찾는다
					{
						int nRepeatCompenCnt = (int)(pow(2., m_nTempCompenCurrentLotCount));
						if( nRepeatCompenCnt &  gProcessINI.m_sProcessOption.nTempRepeatCompenLotCount ||
							(m_nTempCompenCurrentLotCount == 0 && gProcessINI.m_sProcessOption.nTempRepeatCompenLotCount > 0) ) // repeat 보정일때
						{
							if( (nCountX == 1 && (nCountY == 1 || nCountY == 3 || nCountY == 5 || nCountY == 7)) || // 외각 12포인트
								(nCountX == 3 && (nCountY == 1 || nCountY == 7)) ||
								(nCountX == 5 && (nCountY == 1 || nCountY == 7)) ||
								(nCountX == 7 && (nCountY == 1 || nCountY == 3 || nCountY == 5 || nCountY == 7)) ) {}
							else
								continue;
						}
						else // 검증 모드일때
						{
							if((nCountX != 1 && nCountX != 7) || (nCountY != 1 && nCountY != 7) ) // 최외곽 아닌 것을 찾는다. (Temper Offset 영향을 보기 위해서)
									continue;
						}
					}
					else
					{
						if(nCountX % nDivide != 0 || nCountY % nDivide != 0)
						{
							if((nCountX != 1 && nCountX != 7) || (nCountY != 1 && nCountY != 7) ) // 최외곽 아닌 것을 찾는다. (Temper Offset 영향을 보기 위해서)
								continue;
						}
					}
				}
			}
			else
			{
				if(!bSave && nCountX != 0) // 일반 스캐너 보정 루틴 타기 전엔 맨 첫 홀만 보기위해서임. center 찾기 모드에서는 아님.
					return TRUE;
			}
			if(emHead == emMaster)
			{
				if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool] == 0 ||
					(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode))
					dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
				else
					dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
			}
			else if(emHead == emSlave)
			{
				if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool] == 0 ||
					(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode))
					dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
				else
					dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
			}

			if ((nCountY % 2) == 1)
			{
				if(emHead == emMaster)
					dMoveX += -dFieldSize + 2 * nCountX * (dFieldSize / (nDivision - 1.0));
				else if(emHead == emSlave)
					dMoveX += -dFieldSize + 2 * nCountX * (dFieldSize / (nDivision - 1.0));
			}
			// 카메라에 따른 위치 맞추기
			if(emHead == emSlave && gProcessINI.m_sProcessScannerCal.bDefaultLow)
			{
				dMoveX -= (gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x - gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x);
			}
			if(emHead == emSlave && !gProcessINI.m_sProcessScannerCal.bDefaultLow)
			{
				dMoveX -= (gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x);
			}

			if(!CheckStatus()) // Stop확인
				return FALSE;

			if (!pMotor->MoveXYZ(dMoveX, dMoveY, dZ1, dZ2 , bMaster, FALSE))	
			{
				m_nErrMsgID = STDGNALM438; 
				return FALSE;
			}
			
			if (TRUE != pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
			{
				int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
				CheckInpositionError(nErrorAxis);
				return FALSE;
			}

#ifndef __TEST__
//			::Sleep(50);
#endif

			if (bSave)
			{
				pMotor->GetPosition(AXIS_X, dPosX);
				pMotor->GetPosition(AXIS_Y, dPosY);
			}

			nCam = 0;
			if(emHead == emMaster)
			{
				if(bUseLowCam)
					nCam = 1;
				else
				{
//					::Sleep(100);
					nCam = 0;
				}
			}
			else
			{
				if(bUseLowCam)
					nCam = 3;
				else
				{
//					::Sleep(100);
					nCam = 2;
				}
			}

			for(nKK=0; nKK< nRepeatTime; nKK++)
			{
				nIndexNo = 6;
				if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
					nIndexNo = 4;

				bRet = this->SendMessage(UM_VISION_FIND, nCam, MODEL_CIRCLE);
				
#ifndef __TEST__
//				::Sleep(50);
#endif
				
				if(bRet)
					break;
			}
			
			if (bRet) 
			{
				if(bSave)
				{
					if(nCountY%2)
						nIndex = GetPointIndex(nDivision - nCountX - 1, nCountY, nDivision);
					else
						nIndex = GetPointIndex(nCountX, nCountY, nDivision);

#ifndef __TEST__
					pdPos[nIndex].x = dPosX;
					pdPos[nIndex].y = dPosY;
#else
					pdPos[nIndex].x = dMoveX;
					pdPos[nIndex].y = dMoveY;
#endif
					pdOffset[nIndex] = visionResult;
					
					if(gProcessINI.m_sProcessOption.nTemperCompenGridNo == 2 && gProcessINI.m_sProcessOption.bTemperVerifyMode) // 양산 중 불량 체크를 해야하는 경우임. 보정된 홀 중 최외각 4점만 찾는다
					{
						if(fabs(visionResult.x * 1000) > gProcessINI.m_sProcessFidFind.nHolePostLimit ||
							fabs(visionResult.y * 1000) > gProcessINI.m_sProcessFidFind.nHolePostLimit )
						{
							pSuccess[nIndex] = false;
							m_nErrMsgID = STDGNALM1031;
							return FALSE;
						}
					}

					pSuccess[nIndex] = true;
				}
				else
				{
#ifdef __TEST__
					return TRUE;
#else
					m_nErrMsgID = STDGNALM711; // hole 이 발견되었다는 메시지 2011.9.28
					return FALSE;
#endif
				}
			}
			else
			{
				if(gProcessINI.m_sProcessOption.nTemperCompenGridNo == 2 && gProcessINI.m_sProcessOption.bTemperVerifyMode) // 양산 중 불량 체크를 해야하는 경우임. 보정된 홀 중 최외각 4점만 찾는다
				{
//					pSuccess[nIndex] = false;
					m_nErrMsgID = STDGNALM1031;
					return FALSE;
				}

				if(bSave)
				{
					m_nErrMsgID = STDGNALM711;
					return FALSE;
				}
			}
		}
	}
	return TRUE;
}

bool CPaneAutoRun::FindShot(double dZ1, double dZ2, int nFireMode, emHEAD em1st, emHEAD em2nd, bool bSave, DPOINT* pdPos, DPOINT* pdOffset, bool* pSuccess, DPOINT* pdPos2, DPOINT* pdOffset2, bool* pSuccess2)
{
	if(!CheckStatus()) // Stop확인
		return FALSE;

	//탐색순서
	// 1 2 3
	// 6 5 4
	// 7 8 9

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEOCard = gDeviceFactory.GetEocard();
	HVision* pVision = gDeviceFactory.GetVision();

	double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
	double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
	int nDivision = GetDivision();
	int nSelHead = gDProject.m_nSeparation;
	BOOL bIsSkipBoardCheck = gProcessINI.m_sProcessScannerCal.bIsSkipCheckBoard;
	BOOL bUseLowCam = gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool]; // 저배율 기준
	if(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode)
		bUseLowCam = FALSE;
	double dStartPosX = m_dCalculateStartXAuto;
	double dStartPosY = m_dCalculateStartYAuto;

	double dMoveX, dMoveY, dPosX = 0.0, dPosY = 0.0;
	
	const double dFieldSize = gSystemINI.m_sSystemDevice.dFieldSize.x;
	const double dHalfFieldSize = dFieldSize / 2.0;
	int nDivide = 8 / (gProcessINI.m_sProcessOption.nTemperCompenGridNo - 1); // (MAX_GRID_NO - 1) / (m_nGrid - 1);
	
	int nRepeatTime = 1;
	if(bSave == true)
		nRepeatTime = 10;
		
//	BOOL bMaster;
//	if(emHead == emMaster)	bMaster = TRUE;
//	else					bMaster = FALSE;

	if (!pMotor->MoveZ(dZ1, dZ2))	
	{
		m_nErrMsgID = STDGNALM438; 
		return FALSE;
	}
	
	if (TRUE != pMotor->InPositionIO(IND_Z1 + IND_Z2))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		return FALSE;
	}

	CString strResult, strPos, strData;
	BOOL bRet;
	int nKK, nCam, nIndexNo, nIndex;
	
	SVISIONINFO sVisionInfo;
	sVisionInfo.nModelType = 1;
	sVisionInfo.nPolarity = 0;
	sVisionInfo.dSizeA = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nDoASCTool];
	sVisionInfo.dSizeB = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nDoASCTool];
	sVisionInfo.dSizeC = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nDoASCTool];
	
	for(int i=0; i<4; i++)
	{
		sVisionInfo.nCoaxial[i] = gBeamPathINI.m_sBeampath.nScannerCoaxial[m_nDoASCTool];
		sVisionInfo.nRing[i] = gBeamPathINI.m_sBeampath.nScannerRing[m_nDoASCTool];
		sVisionInfo.dContrast[i] = gBeamPathINI.m_sBeampath.dScannerContrast[m_nDoASCTool];
		sVisionInfo.dBrightness[i] = gBeamPathINI.m_sBeampath.dScannerBrightness[m_nDoASCTool];
	}
	
	sVisionInfo.dScoreAngle = 0;//.dAngleTolerance;
	sVisionInfo.dScoreSize = gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[m_nDoASCTool];
	sVisionInfo.dAspectRatio = gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[m_nDoASCTool];

	double dPanelOffsetX, dPanelOffsetY;

	for(int nCountY = 0, nCountX; nCountY < nDivision; nCountY++)
	{
		if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool] == 0 ||
			(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode))
			dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));
		else
			dMoveY = dStartPosY - dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y + nCountY * (dFieldSize / (nDivision - 1.0));

		for (nCountX = 0; nCountX < nDivision; nCountX++)
		{
			if(nFireMode == FIND_ONLY_CENTER_MODE)
			{
				if(nCountX != 4 || nCountY != 4)// center pos이 아닌 경우
					continue;
			}
			else if(nFireMode == FIND_4_EDGE_MODE)
			{
				if(gProcessINI.m_sProcessOption.nTemperMeasureMode)
				{
					if(nCountX % nDivide != 0 || nCountY % nDivide != 0)
					continue;
				}
				if(gProcessINI.m_sProcessOption.bTemperVerifyMode)
				{
					if(gProcessINI.m_sProcessOption.nTemperCompenGridNo == 2) // 양산 중 불량 체크를 해야하는 경우임. 보정된 홀 중 최외각 4점만 찾는다
					{
						int nRepeatCompenCnt = (int)(pow(2., m_nTempCompenCurrentLotCount));
						if( nRepeatCompenCnt &  gProcessINI.m_sProcessOption.nTempRepeatCompenLotCount ||
							(m_nTempCompenCurrentLotCount == 0 && gProcessINI.m_sProcessOption.nTempRepeatCompenLotCount > 0) ) // repeat 보정일때
						{
							if( (nCountX == 1 && (nCountY == 1 || nCountY == 3 || nCountY == 5 || nCountY == 7)) || // 외각 12포인트
								(nCountX == 3 && (nCountY == 1 || nCountY == 7)) ||
								(nCountX == 5 && (nCountY == 1 || nCountY == 7)) ||
								(nCountX == 7 && (nCountY == 1 || nCountY == 3 || nCountY == 5 || nCountY == 7)) ) {}
							else
								continue;
						}
						else // 검증 모드일때
						{
							if((nCountX != 1 && nCountX != 7) || (nCountY != 1 && nCountY != 7) ) // 최외곽 아닌 것을 찾는다. (Temper Offset 영향을 보기 위해서)
									continue;
						}
					}
					else
					{
						if(nCountX % nDivide != 0 || nCountY % nDivide != 0)
						{
							if((nCountX != 1 && nCountX != 7) || (nCountY != 1 && nCountY != 7) ) // 최외곽 아닌 것을 찾는다. (Temper Offset 영향을 보기 위해서)
								continue;
						}
					}
				}
			}

//			if(!bSave && nCountX != 0)
//				return TRUE;

			if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool] == 0 ||
				(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode))

				dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));
			else
				dMoveX = dStartPosX + dHalfFieldSize + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x - nCountX * (dFieldSize / (nDivision - 1.0));

			if ((nCountY % 2) == 1)
			{
				dMoveX += -dFieldSize + 2 * nCountX * (dFieldSize / (nDivision - 1.0));
			}
			
			if(!CheckStatus()) // Stop확인
				return FALSE;

			if (!pMotor->MoveXYZ(dMoveX, dMoveY, dZ1, dZ2 , TRUE, FALSE))	
			{
				m_nErrMsgID = STDGNALM438; 
				return FALSE;
			}
			
			if (TRUE != pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
			{
				int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
				CheckInpositionError(nErrorAxis);
				return FALSE;
			}

#ifndef __TEST__
//			::Sleep(50);
#endif

			if (bSave)
			{
				gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dPosX, FALSE);
				gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dPosY, FALSE);
			}

			if(em1st == emMaster)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION || gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				{
					if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool] == 0 ||
						(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode)) // high vision
					{
						((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL);
						this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
						this->SendMessage(UM_VISION_LAMP, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
					}
					else
					{
						((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
						this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
						this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
					}
				}
				
				if(bUseLowCam)
					nCam = 1;
				else
					nCam = 0;

				for(nKK=0; nKK< nRepeatTime; nKK++)
				{
					nIndexNo = 6;
					if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
						nIndexNo = 4;

					bRet = this->SendMessage(UM_VISION_FIND, nCam, MODEL_CIRCLE);
					
	#ifndef __TEST__
	//				::Sleep(50);
	#endif
					
					if(bRet)
						break;
				}
				
				if (bRet) 
				{
					if(bSave)
					{
						if(nCountY%2)
							nIndex = GetPointIndex(nDivision - nCountX - 1, nCountY, nDivision);
						else
							nIndex = GetPointIndex(nCountX, nCountY, nDivision);
		
	#ifndef __TEST__
						pdPos[nIndex].x = dMoveX; 
						pdPos[nIndex].y = dMoveY;
	#else
						pdPos[nIndex].x = dMoveX;
						pdPos[nIndex].y = dMoveY;
	#endif
						pdOffset[nIndex] = visionResult;
						if(gProcessINI.m_sProcessOption.nTemperCompenGridNo == 2 && gProcessINI.m_sProcessOption.bTemperVerifyMode) // 양산 중 불량 체크를 해야하는 경우임. 보정된 홀 중 최외각 4점만 찾는다
						{
							if(fabs(visionResult.x * 1000) > gProcessINI.m_sProcessFidFind.nHolePostLimit ||
								fabs(visionResult.y * 1000) > gProcessINI.m_sProcessFidFind.nHolePostLimit )
							{
								pSuccess[nIndex] = false;
								m_nErrMsgID = STDGNALM1031;
								return FALSE;
							}
						}
						pSuccess[nIndex] = true;
					}
					else
					{
	#ifdef __TEST__
						return TRUE;
	#else
						m_nErrMsgID = STDGNALM711; // hole 이 발견되었다는 메시지 2011.9.28
						return FALSE;
	#endif
					}
				}
				else
				{
					if(gProcessINI.m_sProcessOption.nTemperCompenGridNo == 2 && gProcessINI.m_sProcessOption.bTemperVerifyMode) // 양산 중 불량 체크를 해야하는 경우임. 보정된 홀 중 최외각 4점만 찾는다
					{
//						pSuccess[nIndex] = false;
						m_nErrMsgID = STDGNALM1031;
						return FALSE;
					}

					if(bSave)
					{
						m_nErrMsgID = STDGNALM711;
						return FALSE;
					}
				}
			}

			if(em2nd == emSlave)
			{
				if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION || gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
				{
					if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool] == 0 ||
						(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode)) // high vision
					{
						((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL);
						this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
						this->SendMessage(UM_VISION_LAMP, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
					}
					else
					{
						((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
						this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
						this->SendMessage(UM_VISION_LAMP, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&sVisionInfo));
					}
				}
				
				if(bUseLowCam)
					nCam = 3;
				else
					nCam = 2;
				
				for(nKK=0; nKK< nRepeatTime; nKK++)
				{
					nIndexNo = 6;
					if(gSystemINI.m_sHardWare.nVisionType == MATROXTCP_VISION)
						nIndexNo = 4;
					
					bRet = this->SendMessage(UM_VISION_FIND, nCam, MODEL_CIRCLE);
					
#ifndef __TEST__
					//				::Sleep(50);
#endif
					
					if(bRet)
						break;
				}
				
				if (bRet) 
				{
					if(bSave)
					{
						if(nCountY%2)
							nIndex = GetPointIndex(nDivision - nCountX - 1, nCountY, nDivision);
						else
							nIndex = GetPointIndex(nCountX, nCountY, nDivision);

						dPanelOffsetX = dMoveX - dPosX;
						dPanelOffsetY = dMoveY - dPosY;
						pdPos2[nIndex].x = dMoveX;
						pdPos2[nIndex].y = dMoveY;
						pdOffset2[nIndex].x = visionResult.x + dPanelOffsetX;
						pdOffset2[nIndex].y = visionResult.y + dPanelOffsetY;
						if(gProcessINI.m_sProcessOption.nTemperCompenGridNo == 2 && gProcessINI.m_sProcessOption.bTemperVerifyMode) // 양산 중 불량 체크를 해야하는 경우임. 보정된 홀 중 최외각 4점만 찾는다
						{
							if(fabs(pdOffset2[nIndex].x * 1000) > gProcessINI.m_sProcessFidFind.nHolePostLimit ||
								fabs(pdOffset2[nIndex].y * 1000) > gProcessINI.m_sProcessFidFind.nHolePostLimit )
							{
								pSuccess[nIndex] = false;
								m_nErrMsgID = STDGNALM1031;
								return FALSE;
							}
						}
						pSuccess2[nIndex] = true;
					}
					else
					{
#ifdef __TEST__
						return TRUE;
#else
						m_nErrMsgID = STDGNALM711; // hole 이 발견되었다는 메시지 2011.9.28
						return FALSE;
#endif
					}
				}
				else
				{
					if(gProcessINI.m_sProcessOption.nTemperCompenGridNo == 2 && gProcessINI.m_sProcessOption.bTemperVerifyMode) // 양산 중 불량 체크를 해야하는 경우임. 보정된 홀 중 최외각 4점만 찾는다
					{
//						pSuccess[nIndex] = false;
						m_nErrMsgID = STDGNALM1031;
						return FALSE;
					}
					if(bSave)
					{
						m_nErrMsgID = STDGNALM711;
						return FALSE;
					}
				}
			}
		}
	}
	return TRUE;
}

bool CPaneAutoRun::FireCalibrationHole(bool bFire, bool b1stPanel, BOOL bGetHeadOffset, BOOL bOnlyCenterPointFire)
{
	if(!CheckStatus()) // Stop확인
		return FALSE;

	SUBTOOLDATA ToolData;
	if(!ChangeBeamPath(ToolData, DO_SCANNER))
	{
		m_nErrMsgID = STDGNALM600;
		return FALSE;
	}
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HEocard* pEoCard = gDeviceFactory.GetEocard();
	HVision* pVision = gDeviceFactory.GetVision();

	CCalibrationPath* pMasterPath = GetMasterPath();
	CCalibrationPath* pSlavePath = GetSlavePath();
	
	double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
	double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
	int nSelHead = gDProject.m_nSeparation;
	int nDivision = GetDivision();

	int nMaxIndex = nDivision * nDivision;
	unsigned short usLaserPosMX = 32767, usLaserPosMY = 32767, usLaserPosSX = 32767, usLaserPosSY = 32767;
	if(!bGetHeadOffset && !bOnlyCenterPointFire)
	{
		pMasterPath->SetCalibrationGridSize(nDivision);
		pSlavePath->SetCalibrationGridSize(nDivision);

		pMasterPath->SetCalibrationGridIndex(usLaserPosMX, usLaserPosMY);
		pSlavePath->SetCalibrationGridIndex(usLaserPosSX, usLaserPosSY);
		
		pMasterPath->GetFirstLSB(usLaserPosMX, usLaserPosMY);
		pSlavePath->GetFirstLSB(usLaserPosSX, usLaserPosSY);
	}
	else
	{
		nMaxIndex = 1;
	}

	unsigned short usMasterDumpPosX, usMasterDumpPosY, usSlaveDumpPosX, usSlaveDumpPosY;
	int nXYORDER;

	int nUseTool = gProcessINI.m_sProcessPowerMeasure.nUseTool;
	BOOL bFind = FALSE, bResult;

	//툴도 체크해야지?

	pEoCard->SetRunMode(FALSE, 20, 2, 1, DSP_ONLY);
	
//#ifndef __TEST__
//	::Sleep(CALIBRATION_SLEEP);
//#endif
	
	pEoCard->GetDumperPosition(usMasterDumpPosX, usMasterDumpPosY, usSlaveDumpPosX, usSlaveDumpPosY);
	
	pEoCard->ShotDataReset();

	if(!CheckStatus()) // Stop확인
		return FALSE;

	CString strFile, strLog;
	strFile.Format(_T("SCal_Time_Log"));
	if(gProcessINI.m_sProcessOption.bTemperVerifyMode) // 4 edge T Compen verify mode이면
	{
		strLog.Format(_T("SCal Start"));								
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}

	for (int nIndex = 0; nIndex < nMaxIndex; nIndex++)
	{
		nXYORDER = gProcessINI.m_sProcessCal.nXYOrder;
		if(!bGetHeadOffset && !bOnlyCenterPointFire)
		{
			pMasterPath->GetNextLSBXYORDER(usLaserPosMX, usLaserPosMY, nDivision, nIndex, nXYORDER);
			pSlavePath->GetNextLSBXYORDER(usLaserPosSX, usLaserPosSY, nDivision, nIndex, nXYORDER);
		}
		else
		{
			usLaserPosMX = usLaserPosMY = usLaserPosSX = usLaserPosSY = 32767;
		}

		if(gProcessINI.m_sProcessOption.bTemperVerifyMode) // 4 edge T Compen verify mode이면
		{
			double d1stCurTemper, d2ndCurTemper, d1stCurSBTemper, d2ndCurSBTemper;
			gDeviceFactory.GetMotor()->GetTCTemperature(d1stCurTemper, d2ndCurTemper);
			gDeviceFactory.GetMotor()->GetSBTemperature(d1stCurSBTemper, d2ndCurSBTemper);
			double dScalAllTemper[10];
			gDeviceFactory.GetMotor()->GetTemperatureForAllCh(dScalAllTemper);
			int nFieldSizeUM = (int)(gSystemINI.m_sSystemDevice.dFieldSize.x*1000);
			int nLSBX, nLSBY; 
			if(b1stPanel)
			{
				nLSBX = usLaserPosMX; nLSBY = usLaserPosMY;
				if(nLSBX != 0 && nLSBX != 65535 && nLSBY != 0 && nLSBY != 65535)
				{
					if(!GetRepeatCompenTransResult(usLaserPosMX, usLaserPosMY, TRUE, nLSBX, nLSBY))
					{
						m_nErrMsgID = STDGNALM1033;
						return FALSE;
					}
					if(!gDeviceFactory.Get1stTemperCompen()->GetCompenPosition(d1stCurTemper, gTempINI.m_sTempTime.dAutoScalTemperature[m_nDoASCTool][0], //d1stCurTemper, gTempINI.m_sTempTime.dAutoScalTemperature[m_nDoASCTool][0], 
						gTempINI.m_sTempTime.dAutoScalEndTemperature[m_nDoASCTool][0], 
						nLSBX, nLSBY, 
						nFieldSizeUM, gProcessINI.m_sProcessOption.dTemperMinTLimit, gProcessINI.m_sProcessOption.dTemperMaxTLimit, m_dPower	))
					{
						if(gDeviceFactory.Get1stTemperCompen()->GetIsSetRefT())
							m_nErrMsgID = STDGNALM1034;
						else
							m_nErrMsgID = STDGNALM1033;
						return FALSE;
					}
					strLog.Format(_T("Applied Offset : d1stCurTemper \t %.3f ASC Temper \t %.3f \t ASC EndT \t %.3f \t Tool \t %d \t Changed XY \t %d \t %d \t Original XY \t %d \t %d \t Temp All \t %.1f \t %.1f \t %.1f \t %.1f \t"), 
						d1stCurTemper, gTempINI.m_sTempTime.dAutoScalTemperature[m_nDoASCTool][0], 
						gTempINI.m_sTempTime.dAutoScalEndTemperature[m_nDoASCTool][0], m_nDoASCTool, nLSBX - usLaserPosMX, nLSBY - usLaserPosMY, usLaserPosMX, usLaserPosMY,
						dScalAllTemper[0], dScalAllTemper[1], dScalAllTemper[2], dScalAllTemper[3]);								
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
			}
			else
			{
				nLSBX = usLaserPosSX; nLSBY = usLaserPosSY;
				if(nLSBX != 0 && nLSBX != 65535 && nLSBY != 0 && nLSBY != 65535)
				{
					if(!GetRepeatCompenTransResult(usLaserPosSX, usLaserPosSY, FALSE, nLSBX, nLSBY))
					{
						m_nErrMsgID = STDGNALM1033;
						return FALSE;
					}
					if(!gDeviceFactory.Get2ndTemperCompen()->GetCompenPosition(d2ndCurTemper, gTempINI.m_sTempTime.dAutoScalTemperature[m_nDoASCTool][1], 
						gTempINI.m_sTempTime.dAutoScalEndTemperature[m_nDoASCTool][1], 
						nLSBX, nLSBY,
						nFieldSizeUM, gProcessINI.m_sProcessOption.dTemperMinTLimit, gProcessINI.m_sProcessOption.dTemperMaxTLimit, m_dPower))
					{
						if(gDeviceFactory.Get2ndTemperCompen()->GetIsSetRefT())
							m_nErrMsgID = STDGNALM1034;
						else
							m_nErrMsgID = STDGNALM1033;
						return FALSE;
					}
					strLog.Format(_T("Applied Offset : d2ndCurTemper \t %.3f ASC Temper \t %.3f \t ASC EndT \t %.3f \t Tool \t %d \t Changed XY \t %d \t %d \t Original XY \t %d \t %d\t Temp All \t %.1f \t %.1f \t %.1f \t %.1f"), 
						d2ndCurTemper, gTempINI.m_sTempTime.dAutoScalTemperature[m_nDoASCTool][1], 
						gTempINI.m_sTempTime.dAutoScalEndTemperature[m_nDoASCTool][1], m_nDoASCTool, nLSBX - usLaserPosSX, nLSBY - usLaserPosSY, usLaserPosSX, usLaserPosSY,
						dScalAllTemper[0], dScalAllTemper[1], dScalAllTemper[2], dScalAllTemper[3]);								
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
			}
			if(nLSBX > 65535) nLSBX = 65535;
			if(nLSBX < 0) nLSBX = 0;
			if(nLSBY > 65535) nLSBY = 65535;
			if(nLSBY < 0) nLSBY = 0;
			usLaserPosMX = usLaserPosSX = (unsigned short) nLSBX; 
			usLaserPosMY = usLaserPosSY = (unsigned short) nLSBY;
		}

		if(b1stPanel)
		{
			pEoCard->DownloadShotData2(
				usLaserPosMX,
				usLaserPosMY,
				usSlaveDumpPosX,
				usSlaveDumpPosY,
				TRUE,
				FALSE,
				SCANNER_CAL_TOOL
				);
		}
		else
		{
			pEoCard->DownloadShotData2(
				usMasterDumpPosX,
				usMasterDumpPosY,
				usLaserPosSX,
				usLaserPosSY,
				FALSE,
				TRUE,
				SCANNER_CAL_TOOL
				);
		}
	}

	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
	{
		if(!gDeviceFactory.GetEocard()->EndMarkDummy())
		{
			m_nErrMsgID = STDGNALM445;  
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("EndMarkDummy Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			m_pLineDummyTime.Finish();
			return FALSE;
		}
	}

	if(!pEoCard->FieldPreStart())
	{
		if(gSystemINI.m_sSystemDevice.nEStop == 1)
			pEoCard->EStop();

		m_nErrMsgID = STDGNALM445;
		return FALSE;
	}

	gDeviceFactory.GetMotor()->GetTCTemperature(m_dScal1stTemper, m_dScal2ndTemper);
	gDeviceFactory.GetMotor()->GetSBTemperature(m_dScal1stSBTemper, m_dScal2ndSBTemper);
	double dScalAllTemper[10];
	gDeviceFactory.GetMotor()->GetTemperatureForAllCh(dScalAllTemper);

	gDeviceFactory.Get1stTemperCompen()->SetScalTemperature(m_dScal1stTemper);
	gDeviceFactory.Get2ndTemperCompen()->SetScalTemperature(m_dScal2ndTemper);

	strLog.Format(_T("Auto Scal Temp All \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f"),   
					dScalAllTemper[0], dScalAllTemper[1], dScalAllTemper[2], dScalAllTemper[3], dScalAllTemper[4],
					dScalAllTemper[5], dScalAllTemper[6], dScalAllTemper[7], dScalAllTemper[8], dScalAllTemper[9]);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	if(!pEoCard->FieldStart(FALSE))
	{
		if(gSystemINI.m_sSystemDevice.nEStop == 1)
			pEoCard->EStop();

		m_nErrMsgID = STDGNALM445;	
		return FALSE;
	}

	
	::Sleep(100);
	
	bResult = TRUE;
	do
	{
		::Sleep(1);
		BOOL bScannerCableError = gDeviceFactory.GetEocard()->IsScannerCableError();
		BOOL bScannerMotorFault = gDeviceFactory.GetEocard()->IsMotorFault();
		BOOL bScannerDrillTimeOut = gDeviceFactory.GetEocard()->IsDrillTimeOut();
		BOOL bTimeOutType = gDeviceFactory.GetEocard()->IsDrillTimeOutType();
		CString strErrorMsg = _T("");
		if(bScannerCableError)
		{
			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			m_nErrMsgID = STDGNALM1017;
			m_strErrorPlus = _T("Scanner Cable Error.");
			return FALSE;
		}
		else if(bScannerMotorFault)
		{
			if(bScannerMotorFault & 0x01)
				strErrorMsg += _T("Scanner Master X Motor Fault\r\n");
			if(bScannerMotorFault & 0x02)
				strErrorMsg += _T("Scanner Master Y Motor Fault\r\n");
			if(bScannerMotorFault & 0x04)
				strErrorMsg += _T("Scanner Slave X Motor Fault\r\n");
			if(bScannerMotorFault & 0x08)
				strErrorMsg += _T("Scanner Slave Y Motor Fault\r\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			m_nErrMsgID = STDGNALM1017;
			m_strErrorPlus = strErrorMsg;
			return FALSE;
		}
		else if(bScannerDrillTimeOut)
		{
			if(bScannerDrillTimeOut & 0x01)
				strErrorMsg += _T("Scanner Master X Drill Time Out\r\n");
			if(bScannerDrillTimeOut & 0x02)
				strErrorMsg += _T("Scanner Master Y Drill Time Out\r\n");
			if(bScannerDrillTimeOut & 0x04)
				strErrorMsg += _T("Scanner Slave X Drill Time Out\r\n");
			if(bScannerDrillTimeOut & 0x08)
				strErrorMsg += _T("Scanner Slave Y Drill Time Out\r\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			m_nErrMsgID = STDGNALM1017;
			m_strErrorPlus = strErrorMsg;
			return FALSE;
		}
		else if(bTimeOutType)
		{
			if(bTimeOutType & 0x01)
				strErrorMsg += _T("Unknown Time Out\r\n");
			if(bTimeOutType & 0x02)
				strErrorMsg += _T("Drill Time Out\r\n");
			if(bTimeOutType & 0x04)
				strErrorMsg += _T("LPC Time Out\r\n");

			if(gSystemINI.m_sSystemDevice.nEStop == 1)
				gDeviceFactory.GetEocard()->EStop();
			m_nErrMsgID = STDGNALM566;
			m_strErrorPlus = strErrorMsg;
			return FALSE;
		}
		bResult = pEoCard->IsDSPBusy();
	}while(bResult);
	
	
	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMPER_SHOT)
	{
		if(!gDeviceFactory.GetEocard()->StartMarkDummy())
		{
			m_nErrMsgID = STDGNALM445; // count No error
			CString strFile, strLog;
			strFile.Format(_T("ReadHole"));
			strLog.Format(_T("StartMarkDummy Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			m_pLineDummyTime.Finish();
			return FALSE;
		}
	}
#ifndef __TEST__
	if( (pEoCard->ReadHoleCount() != nMaxIndex))
	{
		m_nErrMsgID = STDGNALM603;
		return FALSE;
	}
#endif
	return TRUE;
}

BOOL CPaneAutoRun::IsOutOfAxisValidity(int nAxis, double dVal)
{
	if (dVal < gSystemINI.m_sAxisInfo[nAxis].dLimitMinus || dVal > gSystemINI.m_sAxisInfo[nAxis].dLimitPlus)
		return TRUE;
	else
		return FALSE;
}

BOOL CPaneAutoRun::CheckMotorPositionValidity(BOOL bOnlyCenterPointFire)
{
	double dStartPosX = m_dCalculateStartXAuto;
	double dStartPosY = m_dCalculateStartYAuto;
	double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
	double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
	int nSelHead = gDProject.m_nSeparation;
	
	double dFieldSize = gSystemINI.m_sSystemDevice.dFieldSize.x;
	double dHalfFieldSize = dFieldSize / 2.0;
	BOOL bUseLowCam = gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool];
	if(!gProcessINI.m_sProcessOption.bTempVerifyLowCam && gProcessINI.m_sProcessOption.bTemperVerifyMode)
		bUseLowCam = FALSE;

	if(bOnlyCenterPointFire)
		dHalfFieldSize = 0;
	
	double dVisionZ1 = 0.0, dVisionZ2 = 0.0;
	if(bUseLowCam)
	{
		dVisionZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - dCalThick;
		dVisionZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - dCalThick2nd;
	}
	else
	{
		dVisionZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - dCalThick;
		dVisionZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - dCalThick2nd;
	}
	
	double dFireZ1, dFireZ2;
	
	dFireZ1 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[m_nDoASCTool] - dCalThick;
	dFireZ2 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[m_nDoASCTool] - dCalThick2nd;
	
	if (IsOutOfAxisValidity(AXIS_X, dStartPosX))
		return FALSE;
	if (IsOutOfAxisValidity(AXIS_Y, dStartPosY))
		return FALSE;
	
	double dHeadOffsetX, dHeadOffsetY;
	
	if (nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_MASTER)
	{
		if(bUseLowCam)
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;	
		}
		else
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		}
		
		if (IsOutOfAxisValidity(AXIS_X, dStartPosX + dHalfFieldSize + dHeadOffsetX))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_X, dStartPosX - dHalfFieldSize + dHeadOffsetX))
			return FALSE;
		
		if (IsOutOfAxisValidity(AXIS_Y, dStartPosY + dHalfFieldSize + dHeadOffsetY))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Y, dStartPosY - dHalfFieldSize + dHeadOffsetY))
			return FALSE;
		
		if (IsOutOfAxisValidity(AXIS_Z1, dVisionZ1))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Z1, dFireZ1))
			return FALSE;
	}
	
	if (nSelHead == SEL_HEAD_BOTH || nSelHead == SEL_HEAD_SLAVE)
	{
		if(bUseLowCam)
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;	
		}
		else
		{
			dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
			dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		}
		
		if (IsOutOfAxisValidity(AXIS_X, dStartPosX + dHalfFieldSize + dHeadOffsetX))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_X, dStartPosX - dHalfFieldSize + dHeadOffsetX))
			return FALSE;
		
		if (IsOutOfAxisValidity(AXIS_Y, dStartPosY + dHalfFieldSize + dHeadOffsetY))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Y, dStartPosY - dHalfFieldSize + dHeadOffsetY))
			return FALSE;
		
		if (IsOutOfAxisValidity(AXIS_Z2, dVisionZ2))
			return FALSE;
		if (IsOutOfAxisValidity(AXIS_Z2, dFireZ2))
			return FALSE;
	}
	
	return TRUE;
}

BOOL CPaneAutoRun::IsUserStop()
{
	int nCount = 0;
	while(nCount < 4) // 0.2 sec
	{
		::Sleep(50);
		MessageLoop();
		nCount++;

		if(m_bUserStop || m_bEStop)
		{
			m_nErrMsgID = STDGNALM803;
			return TRUE;
		}
	}
	if(m_bUserStop || m_bEStop)
	{
		m_nErrMsgID = STDGNALM803;
		return TRUE;
	}
	return FALSE;
}

int CPaneAutoRun::GetDivision()
{
	return 9;
}

int CPaneAutoRun::GetMaskNo()
{
	int nUseTool = gProcessINI.m_sProcessScannerCal.nUseTool;
	BOOL bFind = FALSE;
	
	SUBTOOLDATA ToolData;
	POSITION pos;
	pos = gVariable.m_pToolCode[0]->m_SubToolData.GetHeadPosition();
	while (pos) 
	{
		ToolData = gVariable.m_pToolCode[0]->m_SubToolData.GetNext(pos);
		if(ToolData.nSubToolNo == nUseTool + 1)
		{
			bFind = TRUE;
			break;
		}
	}
	
	if(bFind)
		return ToolData.nMask;
	else
		return 0;
}

void CPaneAutoRun::WriteCalibrationStopEvent(BOOL bFinish)
{
	double dCalThick = gProcessINI.m_sProcessScannerCal.dAuto1stThickness;
	double dCalThick2nd = gProcessINI.m_sProcessScannerCal.dAuto2ndThickness;
	int nDivision = GetDivision();

	CString strEvent, strInfo, strTemp;
	
	if (bFinish)
		strEvent = _T("Finished automatic scanner calibration.");
	else
		strEvent = _T("Stopped automatic scanner calibration on account of system failure or user's stop event.");
	
	strInfo = _T("Automatic Calibration | ");

	strTemp.Format(_T("Grid size = %dx%d | Beam Path No. = %d | PCB Thickness = %f, %f mm | Start Position ( X = %f mm, Y = %f mm )"),
		nDivision, nDivision, m_nDoASCTool, dCalThick, dCalThick2nd, m_dCalculateStartXAuto, m_dCalculateStartYAuto);
	strInfo += strTemp;
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strInfo));
}

void CPaneAutoRun::CalculateAutoStartPosition(BOOL bOnlyCenterPointFire)
{
	if(bOnlyCenterPointFire)
	{
		int nOpreationTime = gProcessINI.m_sProcessScannerCal.nCountCheckHeadOffsetAuto;
		int nField = gProcessINI.m_sProcessCal.nAutoCalibrationFieldCount; //3
		int nStartPosY = (nOpreationTime % 8100) / 90;
		int nStartPosX = (nOpreationTime % 8100) % 90;
		//4번째 필드 상단
		gProcessINI.m_sProcessScannerCal.dScanYTemp = m_dCalculateStartYAuto = gProcessINI.m_sProcessScannerCal.dAutoStart.y + (nStartPosY * 0.62) - gSystemINI.m_sSystemDevice.dFieldSize.x/2;
		gProcessINI.m_sProcessScannerCal.dScanXTemp = m_dCalculateStartXAuto = gProcessINI.m_sProcessScannerCal.dAutoStart.x + (nStartPosX * 0.62) - gSystemINI.m_sSystemDevice.dFieldSize.x/2 + (nField * (gSystemINI.m_sSystemDevice.dFieldSize.x + 10) );
	}
	else
	{
		int nOpreationTime = gProcessINI.m_sProcessScannerCal.nCountAuto;
		int nField = nOpreationTime / 100;
		int nStartPosY = (nOpreationTime % 100) / 10;
		int nStartPosX = (nOpreationTime % 100) % 10;
		int nOffsetPosY = nOpreationTime / 19;
		int nOffsetPosX = nOpreationTime % 19;

		gProcessINI.m_sProcessScannerCal.dScanYTemp = m_dCalculateStartYAuto = gProcessINI.m_sProcessScannerCal.dAutoStart.y + (nStartPosY * 0.62);
		gProcessINI.m_sProcessScannerCal.dScanXTemp = m_dCalculateStartXAuto = gProcessINI.m_sProcessScannerCal.dAutoStart.x + (nStartPosX * 0.62) + (nField * (gSystemINI.m_sSystemDevice.dFieldSize.x + 10) );

		// 4번째 필드 하단
		m_dOffsetStartYAuto = gProcessINI.m_sProcessScannerCal.dAutoStart.y + (nStartPosY * 0.62);
//		m_dOffsetStartXAuto = gProcessINI.m_sProcessScannerCal.dAutoStart.x + (nStartPosX * 0.62) - gSystemINI.m_sSystemDevice.dFieldSize.x/2 + (3 * (gSystemINI.m_sSystemDevice.dFieldSize.x + 10) );
		m_dOffsetStartXAuto = gProcessINI.m_sProcessScannerCal.dAutoStart.x + (nStartPosX * 0.62) - gSystemINI.m_sSystemDevice.dFieldSize.x/2 + (gProcessINI.m_sProcessCal.nAutoCalibrationFieldCount * (gSystemINI.m_sSystemDevice.dFieldSize.x + 10) );

	}
}

int CPaneAutoRun::GetPointIndex(int nCountX, int nCountY, int nDivision)
{
	if ((nCountX % 2) == 1)
		return (nCountX ) * nDivision + nCountY;
	else
		return nCountX * nDivision + nCountY;
}

BOOL CPaneAutoRun::ChangeBeamPath(SUBTOOLDATA subTool, int nToolType)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	
	double dC1, dC2, dA1, dA2, dM1, dM2, dM3, dZ1, dZ2; 
	CString strVal;
	BOOL bTophat;
	if(nToolType == DO_POWER)
	{
		dZ1 = gProcessINI.m_sProcessPowerMeasure.d1stHeight;
		dZ2 = gProcessINI.m_sProcessPowerMeasure.d2ndHeight;
	}
	else if(nToolType == DO_SCANNER)
	{
		dZ1 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[m_nDoASCTool] - gProcessINI.m_sProcessScannerCal.dAuto1stThickness; 
		dZ2 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[m_nDoASCTool] - gProcessINI.m_sProcessScannerCal.dAuto2ndThickness; 
	}
	else 
	{
		dZ1 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[subTool.nMask];
		dZ2 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[subTool.nMask];
	}
	BOOL bLaserPath; 

	if(nToolType == DO_SCANNER)
	{
		bTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[m_nDoASCTool];
		bLaserPath = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[m_nDoASCTool];
		
		dC1 = gBeamPathINI.m_sBeampath.dBeamPathBetPos1[m_nDoASCTool];
		dC2 = gBeamPathINI.m_sBeampath.dBeamPathBetPos2[m_nDoASCTool];
		dA1 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[m_nDoASCTool];
		dA2 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[m_nDoASCTool];
	
		dM1 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[m_nDoASCTool];
		dM2 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[m_nDoASCTool];
		dM3 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[m_nDoASCTool];	

	}
	else
	{
		bTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[subTool.nMask];
		bLaserPath = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[subTool.nMask];

		dC1 = gBeamPathINI.m_sBeampath.dBeamPathBetPos1[subTool.nMask];
		dC2 = gBeamPathINI.m_sBeampath.dBeamPathBetPos2[subTool.nMask];
		dA1 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[subTool.nMask];
		dA2 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[subTool.nMask];
		
		dM1 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[subTool.nMask];
		dM2 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[subTool.nMask];
		dM3 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[subTool.nMask];
	}
	
	if(!pMotor->MoveTophatShutter(bTophat))
	{
	//	ErrMessage(_T("Tophat shutter move error!"));
		return FALSE;
	}

	if(!pMotor->MoveLaserBeamPath(bLaserPath))
	{
		m_nErrMsgID = STDGNALM974;
		return FALSE;
	}
	if(gSystemINI.m_sHardWare.nLaserType == LASER_CO2)
	{
		m_bCheckZMC = TRUE;

#ifndef __SERVO_MOTOR__
	if(!pMotor->MoveZMCA2(	dZ1, dZ2, dM1, dM2, dC1, dC2, dA1, dA2, TRUE, bTophat))
#else 
	if(!pMotor->MoveZMCA3(	dZ1, dZ2, dM1, dM2, dM3, dC1, dC2, dA1, dA2, TRUE, bTophat))
#endif
	{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_MOVE_MOTOR);
			strMsg.Format(strString, "Z,M,C");
			m_bCheckZMC = FALSE;
		//	ErrMessage(strMsg);
			return FALSE;
		}
		
	}
	else // not use M, C
	{
		m_bCheckMC = TRUE;
		if(!pMotor->MoveZMC2(dZ1, dZ2, dA1, dA2, TRUE, bTophat))
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_MOVE_MOTOR);
			strMsg.Format(strString, "Z,A1,A2");
//			ErrMessage(strMsg);
			m_bCheckMC = FALSE;
			return FALSE;
		}
	}
	// M, C, Z Inposition
	//Inposition check
	if(!ChangeOneSubToolCheckInposition())
	{
		m_bCheckZMC = m_bCheckMC = FALSE;
		return FALSE;
	}
	return TRUE;
}

BOOL CPaneAutoRun::UpdateNewParam(SUBTOOLDATA subTool)
{
	ASSERT(gDeviceFactory.GetEocard() != NULL);
	
	gDeviceFactory.GetEocard()->GetParameter(&m_NewParameter);
	
	CString strData;
	m_NewParameter.Frequency = subTool.nFrequency;
	double dCurrent, dAOMDelay, dAOMDuty;
	int nThermalTrack;
	
	double dMaskDutyOffset = gBeamPathINI.m_sBeampath.dPowOffsetDuty[subTool.nMask];
	double dMaskAOMDelayOffset = gBeamPathINI.m_sBeampath.dPowOffsetAomDelay[subTool.nMask];
	double dMaskAOMDutyOffset = gBeamPathINI.m_sBeampath.dPowOffsetAomDuty[subTool.nMask];
	double dPowerDutyOffset = gBeamPathINI.m_sBeampath.dPowCompensationDutyOffset[subTool.nMask];
	double dVoltage1 = gBeamPathINI.m_sBeampath.dBeamPathVoltage1[subTool.nMask];
	double dVoltage2 = gBeamPathINI.m_sBeampath.dBeamPathVoltage2[subTool.nMask];
	BOOL bRet = gDeviceFactory.GetEocard()->SetVoltage(dVoltage1, dVoltage2);
	if(!bRet)
	{
		m_nErrMsgID = STDGNALM117;
		return bRet;
	}
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		m_NewParameter.dDuty = 5000; // 50%
		dCurrent = gProcessINI.m_sProcessPowerMeasure.dCurrent;
		nThermalTrack = gProcessINI.m_sProcessPowerMeasure.nThermalTrack;		
		gDeviceFactory.GetLaser()->ChangeAviaDiodeCurrent(dCurrent, m_NewParameter.Frequency, nThermalTrack);
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		dCurrent = gProcessINI.m_sProcessPowerMeasure.dCurrent;		
		m_NewParameter.dDuty = 5000; // 50%
	}
	else
	{
		m_NewParameter.dDuty = static_cast<unsigned short>(subTool.dShotDuty[0] * 100 + 0.5);
		m_NewParameter.dDuty += (dMaskDutyOffset) * 100 + dPowerDutyOffset * 100;
		
		dAOMDelay = subTool.dShotAOMDelay[0];
		dAOMDuty = subTool.dShotAOMDuty[0];
		m_NewParameter.dAOMDelay = dAOMDelay + dMaskAOMDelayOffset;
		m_NewParameter.dAOMDuty = dAOMDuty + dMaskAOMDutyOffset + dPowerDutyOffset;
		strData.Format(_T("%s"), subTool.cAOMFilePath);
		memcpy(m_NewParameter.cAOMFilePath, strData, strData.GetLength() + 1);
	}
	
	return bRet && gDeviceFactory.GetEocard()->SetParameter(&m_NewParameter, (dMaskAOMDutyOffset + dPowerDutyOffset), subTool.nMask);

}

BOOL CPaneAutoRun::ControlDeviceForScal(BOOL bStart)
{
	BOOL bRes = TRUE, bCalmp = FALSE;
	if(bStart)
	{
		gDeviceFactory.GetMotor()->TableClamp(TRUE, TRUE);
		gDeviceFactory.GetMotor()->TableClamp(TRUE, FALSE);
	}
	
	bRes = ((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE); // 항상 닫기
	
	gDeviceFactory.GetEocard()->MoveToCenter();
	
	gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION1, bStart);
	gDeviceFactory.GetMotor()->SetOutPort(PORT_DEFAULT_TABLE_SUCTION2, bStart);
	
	gDeviceFactory.GetMotor()->SetOutPort(PORT_LASER_HEAD_PURGE, bStart);

	int nCount = 0;
	BOOL bmaster, bslave;
	do 
	{
		if(!gSystemINI.m_sHardWare.nTableClamp)
		{
			bCalmp = TRUE;
			break;
		}

		bmaster = gDeviceFactory.GetMotor()->GetCurrentTableClamp(TRUE, TRUE);
		bslave = gDeviceFactory.GetMotor()->GetCurrentTableClamp(FALSE, TRUE);
		
		if(gDProject.m_nSeparation == USE_DUAL)
		{
			if(bmaster && bslave)
			{	bCalmp = TRUE;
				break;
			}
		}
		else if(gDProject.m_nSeparation == USE_1ST)
		{
			if(bmaster)
			{
				bCalmp = TRUE;
				break;
			}
		}
		else 
		{
			if(bslave)
				bCalmp = TRUE;
			break;
		}

		if (++nCount > 200)	//4 Sec
			break;
		
		::Sleep(20);
	} while (TRUE);

	if(!bRes)
	{
		m_nErrMsgID = STDGNALM417;
	}
	else if(!bCalmp)
	{
		if(!bmaster)
			m_nErrMsgID = STDGNALM530;
		else if(!bslave)
			m_nErrMsgID = STDGNALM531;
	}
	bRes = bRes & bCalmp;
	
	return bRes;
}

BOOL CPaneAutoRun::DownScalParam()
{
	SUBTOOLDATA subTool;
	GetLaserParam(subTool);

	// subTool download
	if(!gDeviceFactory.GetEocard()->SetVoltage(gBeamPathINI.m_sBeampath.dBeamPathVoltage1[subTool.nMask], gBeamPathINI.m_sBeampath.dBeamPathVoltage2[subTool.nMask]))
	{
		m_nErrMsgID = STDGNALM117;
		return FALSE;
	}
	if(!gDeviceFactory.GetEocard()->DownloadOneSubTool(SCANNER_CAL_TOOL, subTool))
	{
		m_nErrMsgID = STDGNALM445;
		return FALSE;
	}

	if(!gDeviceFactory.GetEocard()->DownloadShotDrillScannerParam(subTool.nJumpDelay))// / subTool.nDrawStepPeriod))
	{
		m_nErrMsgID = STDGNALM445;
		return FALSE;
	}

	// Laser Current Set
	if(gSystemINI.m_sHardWare.nLaserType == LASER_UV)
	{
		if(!gDeviceFactory.GetLaser()->ChangeAviaDiodeCurrent(subTool.dCurrent, subTool.nFrequency, subTool.nThermalTrack))
		{
			m_nErrMsgID = STDGNALM444;
			return FALSE;
		}
	}
	else if(gSystemINI.m_sHardWare.nLaserType == LASER_IPGPULSE)
	{
		if(!gDeviceFactory.GetLaser()->SetCurrent(subTool.dCurrent))
		{
			m_nErrMsgID = STDGNALM444;
			return FALSE;
		}
	}

	return TRUE;
}

void CPaneAutoRun::GetLaserParam(SUBTOOLDATA &subTool)
{
	subTool.nSubToolNo = 1;
	subTool.nToolType = SHOT_DRILL_TYPE;
	
	subTool.nJumpDelay = (int)(gBeamPathINI.m_sBeampath.dScannerJumpDelay);
	
	subTool.nLaserOnDelay = 1;
	subTool.nLaserOffDelay = 1;
	subTool.nFrequency = 1000;
	
	// Drill
	subTool.nShotMode = 1; // cycle mode
	subTool.nTotalShot = gBeamPathINI.m_sBeampath.nScannerTotalShot[m_nDoASCTool];
	subTool.nBurstShot = 1;
	subTool.nMask = m_nDoASCTool;
	subTool.bUseTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[m_nDoASCTool];
	
	CString strAOMFile;
	strAOMFile.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	for(int i = 0; i < subTool.nTotalShot; i++)
	{
		subTool.dShotDuty[i] = gBeamPathINI.m_sBeampath.dScannerDuty[m_nDoASCTool];
		subTool.dShotAOMDelay[i] = gBeamPathINI.m_sBeampath.dScannerAomdelay[m_nDoASCTool];
		subTool.dShotAOMDuty[i] = gBeamPathINI.m_sBeampath.dScannerAomDuty[m_nDoASCTool];
		strcpy_s(subTool.cAOMFilePath[i], strAOMFile);

		subTool.dShotDutyOffsetM[i] = 0;
		subTool.dShotDutyOffsetS[i] = 0;
		subTool.dShotVolOffsetM[i] = 0;
		subTool.dShotVolOffsetS[i] = 0;
	}
	subTool.bUseAperture = FALSE;
	subTool.nApertureBurst = 1;
	subTool.dZOffset = 0;
		
	// Memo
	subTool.cToolMemo[0] = NULL;

}

BOOL CPaneAutoRun::DownloadASC()
{
	CString strString, strMsg;
	strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
	strMsg.Format(strString, "ASC");
	
	CString strMaster, strSlave;
	strMaster.Format(_T("%s\\%sM1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_nDoASCTool]);
	strSlave.Format(_T("%s\\%sS1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_nDoASCTool]);
	
	TCHAR sz1stFile[255], sz2ndFile[255];
	lstrcpy(sz1stFile, strMaster);
	lstrcpy(sz2ndFile, strSlave);

	if(!InitAGCInfo(sz1stFile, sz2ndFile))
	{
#ifndef __TEST__
		CString strTemp;
		strTemp.Format(_T("Beam Path : %d %s or %s"), gProcessINI.m_sProcessScannerCal.nUseTool, strMaster, strSlave);
		strMsg.Format(strString, strTemp);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		m_nErrMsgID = STDGNALM118;
		return FALSE;
#endif
	}
	
	if(!gDeviceFactory.GetEocard()->LoadCalibrationFile(sz1stFile, sz2ndFile))
	{
#ifndef __TEST__
		CString strTemp;
		strTemp.Format(_T("Beam Path : %d %s or %s"), gProcessINI.m_sProcessScannerCal.nUseTool, strMaster, strSlave);
		strMsg.Format(strString, strTemp);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
		m_nErrMsgID = STDGNALM105;
		return FALSE;
#endif
	}
	return TRUE;
}

BOOL CPaneAutoRun::InitAGCInfo(TCHAR* strMaster, TCHAR* strSlave)
{
	if(!m_calAGCMaster.SetFieldSize(gSystemINI.m_sSystemDevice.dFieldSize.x, gSystemINI.m_sSystemDevice.dOriginFieldSize.x))
		return FALSE;
	TCHAR szBackupFolder[255];
	lstrcpy(szBackupFolder, gEasyDrillerINI.m_clsDirPath.GetBackupDir());
	m_calAGCMaster.SetBackupFolder(szBackupFolder);
	if(!m_calAGCMaster.SetAxisInfo(PX_PY, FALSE, FALSE, PX_PY, PX_PY))
		return FALSE;
	if(!m_calAGCMaster.SetAGCInfo(GetDivision(), strMaster, FALSE, TRUE))
		return FALSE;
	
	if(!m_calAGCSlave.SetFieldSize(gSystemINI.m_sSystemDevice.dFieldSize.x, gSystemINI.m_sSystemDevice.dOriginFieldSize.x))
		return FALSE;
	m_calAGCSlave.SetBackupFolder(szBackupFolder);
	if(!m_calAGCSlave.SetAxisInfo(PX_PY, FALSE, FALSE, PX_PY, PX_PY))
		return FALSE;
	if(!m_calAGCSlave.SetAGCInfo(GetDivision(), strSlave, FALSE, TRUE))
		return FALSE;
	
	return TRUE;
}

void CPaneAutoRun::SaveScalTime(BOOL b1st)
{
	int nCount = gBeamPathINI.m_sBeampath.nLastIndex;
	TCHAR cASC[256] ={0,};

	_stprintf_s(cASC, gBeamPathINI.m_sBeampath.strBeamPathAscFile[m_nDoASCTool]);
   
	time_t timeNow;
	time(&timeNow);

	CString strFile, strLog;
	strFile.Format(_T("PreWork"));

	for(int i =0; i<= nCount; i++)  
	{

		if(strcmp(cASC, gBeamPathINI.m_sBeampath.strBeamPathAscFile[i]) == 0)
		{
			if(b1st)
			{
				if((m_dScal1stTemper >= gProcessINI.m_sProcessOption.dTemperMinTLimit && m_dScal1stTemper <= gProcessINI.m_sProcessOption.dTemperMaxTLimit &&
					m_dScal1stSBTemper >= gProcessINI.m_sProcessOption.dTemperMinTLimit && m_dScal1stSBTemper <= gProcessINI.m_sProcessOption.dTemperMaxTLimit) ||
					!gProcessINI.m_sProcessOption.bTemperCompensationMode)
				{
					gTempINI.m_sTempTime.nAutoScalEndTime[i][0] = (int)timeNow;
					strLog.Format(_T("ScannerSaveTime 1st [%d] = %d"), i, timeNow);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

					gTempINI.m_sTempTime.dAutoScalTemperature[i][0] = m_dScal1stTemper;
					gTempINI.m_sTempTime.dAutoScalEndTemperature[i][0] = gDeviceFactory.Get1stTemperCompen()->GetAutoRunLastTemperature();
					if(gTempINI.m_sTempTime.dAutoScalTemperature[i][0] > gTempINI.m_sTempTime.dAutoScalEndTemperature[i][0])
						gTempINI.m_sTempTime.dAutoScalTemperature[i][0] = gTempINI.m_sTempTime.dAutoScalEndTemperature[i][0];
					strLog.Format(_T("ScannerSave Temperature 1st [%d] = %.3f, %.3f"), i, m_dScal1stTemper, m_dScal1stSBTemper);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
			}
			else
			{
				if((m_dScal2ndTemper >= gProcessINI.m_sProcessOption.dTemperMinTLimit && m_dScal2ndTemper <= gProcessINI.m_sProcessOption.dTemperMaxTLimit &&
					m_dScal2ndSBTemper >= gProcessINI.m_sProcessOption.dTemperMinTLimit && m_dScal2ndSBTemper <= gProcessINI.m_sProcessOption.dTemperMaxTLimit) ||
					!gProcessINI.m_sProcessOption.bTemperCompensationMode)
				{
					gTempINI.m_sTempTime.nAutoScalEndTime[i][1] = (int)timeNow;
					strLog.Format(_T("ScannerSaveTime 2nd [%d] = %d"), i, timeNow);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

					gTempINI.m_sTempTime.dAutoScalTemperature[i][1] = m_dScal2ndTemper;
					gTempINI.m_sTempTime.dAutoScalEndTemperature[i][1] = gDeviceFactory.Get2ndTemperCompen()->GetAutoRunLastTemperature();
					if(gTempINI.m_sTempTime.dAutoScalTemperature[i][1] > gTempINI.m_sTempTime.dAutoScalEndTemperature[i][1])
						gTempINI.m_sTempTime.dAutoScalTemperature[i][1] = gTempINI.m_sTempTime.dAutoScalEndTemperature[i][1];
					strLog.Format(_T("ScannerSave Temperature 2nd [%d] = %.3f, %.3f"), i, m_dScal2ndTemper, m_dScal2ndSBTemper);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				}
			}
		}
	}
}



BOOL CPaneAutoRun::GetFidPosHighCamInCenter(BOOL b1stPanel, LPFIDDATA pFidData)
{
	double dZ1, dZ2, dHeadOffsetX, dHeadOffsetY, dHeadOffsetX1, dHeadOffsetY1, dHeadOffsetX2, dHeadOffsetY2;
	double dModelX = 0, dModelY = 0;
	double dLowFOVX = gSystemINI.m_sSystemDevice.dLowFOVX, dLowFOVY = gSystemINI.m_sSystemDevice.dLowFOVY, 
			dHighFOVX = gSystemINI.m_sSystemDevice.dHighFOVX, dHighFOVY = gSystemINI.m_sSystemDevice.dHighFOVY;
	CDPoint dIndexP;
	double dFinalMoveX, dFinalMoveY;
	double dOffsetZero1stPX, dOffsetZero1stPY, dOffsetZero2ndPX, dOffsetZero2ndPY; // 
	double dRefX, dRefY;
	CDPoint dptResult1st, dptResult2nd;
	CDPoint dOffsetP;
	BOOL	b1stFound, b2ndFound;

	CString strFile, strFidOffset;
	strFile.Format(_T("FidOffsetData"));
	CString strFile2, strLog;
	strFile2.Format(_T("CheckTrans"));

//	pFidData->bAcquire[USE_1ST - 1] = pFidData->bAcquire[USE_2ND - 1] = FALSE; // default : not found

	gDProject.m_Glyphs.GetRefPosition(dRefX, dRefY);

	if(pFidData->sVisInfo.nModelType < 2) // annulus, circle
	{
		dModelX = dModelY = pFidData->sVisInfo.dSizeA;
	}
	else if(pFidData->sVisInfo.nModelType < MODEL_PATTERN) // other geometery
	{
		dModelX = pFidData->sVisInfo.dSizeA;
		dModelY = pFidData->sVisInfo.dSizeB;
	}
	
	this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
	this->SendMessage(UM_VISION_LAMP, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
	
	dHeadOffsetX1 = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
	dHeadOffsetY1 = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
	dHeadOffsetX2 = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
	dHeadOffsetY2 = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
	
	dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - gDProject.m_dPcbThick + pFidData->dOffsetZ;
	dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - gDProject.m_dPcbThick2 + pFidData->dOffsetZ;

	dOffsetZero1stPX = gDProject.m_dRefPosX	- (pFidData->npPosition.x / 1000.0 - dRefX) + dHeadOffsetX1;
	dOffsetZero1stPY = gDProject.m_dRefPosY	- (pFidData->npPosition.y / 1000.0 - dRefY) + dHeadOffsetY1;
	dOffsetZero2ndPX = gDProject.m_dRefPosX	- (pFidData->npPosition.x / 1000.0 - dRefX) + dHeadOffsetX2;
	dOffsetZero2ndPY = gDProject.m_dRefPosY	- (pFidData->npPosition.y / 1000.0 - dRefY) + dHeadOffsetY2;

	if(!b1stPanel)
	{
		dHeadOffsetX = dHeadOffsetX2;
		dHeadOffsetY = dHeadOffsetY2;
		dOffsetP.x = pFidData->npTransPosition2.x/1000.; dOffsetP.y = pFidData->npTransPosition2.y/1000.;
	}
	else
	{									// 1st 기중으로 테이블 이동
		dHeadOffsetX = dHeadOffsetX1;
		dHeadOffsetY = dHeadOffsetY1;
		dOffsetP.x = pFidData->npTransPosition.x/1000.; dOffsetP.y = pFidData->npTransPosition.y/1000.;
	}

	dptResult1st.x = dptResult1st.y = dptResult2nd.x = dptResult2nd.y = 0; // 

	if(!CheckStatus())
		return FALSE;
	
	// Table move
	dFinalMoveX = gDProject.m_dRefPosX					// 기준점 설정 좌표 (table motor 좌표 : scanner center 기준)
		- (pFidData->npPosition.x / 1000.0 - dRefX)	// 기준점에서의 상대적 파일 좌표 차이 : table 좌표계와 file 좌표계가 반대로 움직임로 - 함.
		- dOffsetP.x 							// 전에 찾았던 offset
		+ dHeadOffsetX;
	dFinalMoveY = gDProject.m_dRefPosY 
		- (pFidData->npPosition.y / 1000.0 - dRefY) 	
		- dOffsetP.y 						
		+ dHeadOffsetY;
	
	if(!gDeviceFactory.GetMotor()->MotorMoveXYZ(dFinalMoveX, dFinalMoveY, dZ1, dZ2, b1stPanel))
	{
		m_nErrMsgID = STDGNALM438;
		this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		return FALSE;
	}
	if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		return FALSE;
	}
	if(b1stPanel)
	{
		::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL); //ChangeVisionAllParam(HIGH_1ST_CAM, pFidData);
		for(int i = 0; i < 5; i++)
		{
			int nMess = UM_VISION_FIND;
			int nResult = this->SendMessage(nMess, HIGH_1ST_CAM, pFidData->sVisInfo.nModelType);
			if(nResult == 1)
			{
				b1stFound = TRUE;
				SaveFiducialImg(HIGH_1ST_CAM, 300);
				pFidData->npTransPosition.x = (int)((dOffsetZero1stPX - dFinalMoveX + visionResult.x) * 1000); //dIndexP.x * dStepX + dOffsetP.x + visionResult.x
				pFidData->npTransPosition.y = (int)((dOffsetZero1stPY - dFinalMoveY + visionResult.y) * 1000); //dIndexP.y * dStepY + dOffsetP.y + visionResult.y
				strFidOffset.Format(_T("1st Low-to-High ( %.3f,%.3f ) : offset %.4f, %.4f"), dFinalMoveX - dHeadOffsetX, dFinalMoveY - dHeadOffsetY, visionResult.x, visionResult.y);
				strLog.Format(_T("TransPosition : (%d, %d)"), pFidData->npTransPosition.x, pFidData->npTransPosition.y);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strFidOffset));

				pFidData->npTablePos1.x = (int)(1000 * (dFinalMoveX - dHeadOffsetX - visionResult.x));
				pFidData->npTablePos1.y = (int)(1000 * (dFinalMoveY - dHeadOffsetY - visionResult.y));		// 20130312

				pFidData->bAcquire[USE_1ST - 1] = TRUE;
				this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
				this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
				return TRUE;
			}
			else if(nResult == 0)
			{
				b1stFound = FALSE;
				break;
			}
			::Sleep(10);
		}
	}
	else
	{
		::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL); //ChangeVisionAllParam(HIGH_2ND_CAM, pFidData);
		for(int i = 0; i < 5; i++)
		{
			int nMess = UM_VISION_FIND;
			int nResult = this->SendMessage(nMess, HIGH_2ND_CAM, pFidData->sVisInfo.nModelType);
			if(nResult == 1)
			{
				b2ndFound = TRUE;
				SaveFiducialImg(HIGH_2ND_CAM, 300);
				pFidData->npTransPosition2.x = (int)((dOffsetZero2ndPX - dFinalMoveX + visionResult.x) * 1000); //dIndexP.x * dStepX + dOffsetP.x + visionResult.x
				pFidData->npTransPosition2.y = (int)((dOffsetZero2ndPY - dFinalMoveY + visionResult.y) * 1000); //dIndexP.y * dStepY + dOffsetP.y + visionResult.y
				strFidOffset.Format(_T("2nd Low-to-High ( %.3f,%.3f ) : offset %.4f, %.4f"), dFinalMoveX - dHeadOffsetX, dFinalMoveY - dHeadOffsetY, visionResult.x, visionResult.y);
				strLog.Format(_T("TransPosition2 : (%d, %d)"), pFidData->npTransPosition2.x, pFidData->npTransPosition2.y);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strFidOffset));

				pFidData->npTablePos2.x = (int)(1000 * (dFinalMoveX - dHeadOffsetX - visionResult.x));
				pFidData->npTablePos2.y = (int)(1000 * (dFinalMoveY - dHeadOffsetY - visionResult.y));		// 20130312

				pFidData->bAcquire[USE_2ND - 1] = TRUE;
				this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
				this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
				return TRUE;
			}
			else if(nResult == 0)
			{
				b2ndFound = FALSE;
				break;
			}
			::Sleep(10);
		}
	}

	this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
	this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
	return FALSE;
}

void CPaneAutoRun::SendFindTrigger(BOOL &b1stFound, BOOL &b2ndFound, BOOL bHighCam, BOOL b1stSkip, BOOL b2ndSkip, LPFIDDATA pFidData, 
								   double dFinalMoveX, double dFinalMoveY, CDPoint &dptResult1st, CDPoint &dptResult2nd, int nFidIndex,
								   double dHead1stOffsetX, double dHead1stOffsetY, double dHead2ndOffsetX, double dHead2ndOffsetY)
{
	CString strFile, strFidOffset;
	strFile.Format(_T("FidOffsetData"));
	if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST)
	{
		if(!bHighCam)
		{
			if(!b1stSkip)
			{
				b1stFound = FALSE;
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL); //ChangeVisionAllParam(LOW_1ST_CAM, pFidData);
				for(int i = 0; i < 5; i++)
				{
					int nMess = UM_VISION_FIND;
//					if(i == 0) nMess = UM_VISION_FIND_NOGRAP;
					int nResult = this->SendMessage(nMess, LOW_1ST_CAM, pFidData->sVisInfo.nModelType);
					if(nResult == 1)// || (nFidIndex < 100 && nResult == 10))
					{
						b1stFound = TRUE;
						dptResult1st = visionResult;
						strFidOffset.Format(_T("1st 1 File( %d, %d ) Table( %.3f,%.3f ) : offset %.4f, %.4f"), 
							pFidData->npPosition.x, pFidData->npPosition.y, dFinalMoveX - dHead1stOffsetX, dFinalMoveY - dHead1stOffsetY, visionResult.x, visionResult.y);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
						::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strFidOffset));

						pFidData->npTablePos1.x = (int)(1000 * (dFinalMoveX - dHead1stOffsetX - visionResult.x));		// 20130312
						pFidData->npTablePos1.y = (int)(1000 * (dFinalMoveY - dHead1stOffsetY - visionResult.y));

						m_dpFindFiducialPos.x = dFinalMoveX + visionResult.x;
						m_dpFindFiducialPos.y = dFinalMoveY + visionResult.y;
						if(nFidIndex >= 200)
							SaveFiducialImg(LOW_1ST_CAM, nFidIndex);
						break;
					}
					else if(nResult == 10 || nResult == 20)
					{
						SaveFailFiducialImg(LOW_1ST_CAM, nFidIndex);
						break;
					}
					else if(nResult == 0)
					{
					}
					::Sleep(10);
				}
			}
		}
		else
		{
			if(!b1stSkip)
			{
				b1stFound = FALSE;
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL); //ChangeVisionAllParam(HIGH_1ST_CAM, pFidData);
				for(int i = 0; i < 5; i++)
				{
					int nMess = UM_VISION_FIND;
//					if(i == 0) nMess = UM_VISION_FIND_NOGRAP;
					int nResult = this->SendMessage(nMess, HIGH_1ST_CAM, pFidData->sVisInfo.nModelType);
					if(nResult == 1)// || (nFidIndex < 100 && nResult == 10))
					{
						b1stFound = TRUE;
						dptResult1st = visionResult;
						strFidOffset.Format(_T("1st 1 File( %d, %d ) Table( %.3f,%.3f ) : offset %.4f, %.4f"), 
							pFidData->npPosition.x, pFidData->npPosition.y, dFinalMoveX - dHead1stOffsetX, dFinalMoveY - dHead1stOffsetY, visionResult.x, visionResult.y);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
						::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strFidOffset));

						pFidData->npTablePos1.x = (int)(1000 * (dFinalMoveX - dHead1stOffsetX - visionResult.x));		// 20130312
						pFidData->npTablePos1.y = (int)(1000 * (dFinalMoveY - dHead1stOffsetY - visionResult.y));

						m_dpFindFiducialPos.x = dFinalMoveX + visionResult.x;
						m_dpFindFiducialPos.y = dFinalMoveY + visionResult.y;
						if(nFidIndex >= 200)
							SaveFiducialImg(HIGH_1ST_CAM, nFidIndex);
						break;
					}
					else if(nResult == 10 || nResult == 20)
					{
						SaveFailFiducialImg(LOW_1ST_CAM, nFidIndex);
						break;
					}
					else if(nResult == 0)
					{

					}
					::Sleep(10);
				}
			}
		}
	}
	// 2nd panel
	if((gDProject.m_nSeparation == USE_DUAL && !m_bOdd) || gDProject.m_nSeparation == USE_2ND)
	{
		if(!bHighCam)
		{
			if(!b2ndSkip)
			{
				b2ndFound = FALSE;
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL); //ChangeVisionAllParam(LOW_2ND_CAM, pFidData);
				for(int i = 0; i < 5; i++)
				{
					int nMess = UM_VISION_FIND;
//					if(i == 0) nMess = UM_VISION_FIND_NOGRAP;
					int nResult = this->SendMessage(nMess, LOW_2ND_CAM, pFidData->sVisInfo.nModelType);
					if(nResult == 1) // || (nFidIndex < 100 && nResult == 10))
					{
						
						b2ndFound = TRUE;
						dptResult2nd = visionResult;
						double dTableX, dTableY;
						gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dTableX, FALSE);
						gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dTableY, FALSE);
						strFidOffset.Format(_T("2nd 1 File( %d, %d ) Table( %.3f,%.3f ) : offset %.4f, %.4f"), 
							pFidData->npPosition.x, pFidData->npPosition.y, dTableX - dHead2ndOffsetX, dTableY - dHead2ndOffsetY, visionResult.x, visionResult.y);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
						::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strFidOffset));

						pFidData->npTablePos2.x = (int)(1000 * (dTableX - dHead2ndOffsetX - visionResult.x));		// 20130312
						pFidData->npTablePos2.y = (int)(1000 * (dTableY - dHead2ndOffsetY - visionResult.y));

						m_dpFindFiducialPos2.x = dFinalMoveX + visionResult.x;
						m_dpFindFiducialPos2.y = dFinalMoveY + visionResult.y;
						if(nFidIndex >= 200)
							SaveFiducialImg(LOW_2ND_CAM, nFidIndex);
						break;
					}
					else if( nResult == 10 || nResult == 20)
					{
						SaveFailFiducialImg(LOW_1ST_CAM, nFidIndex);
						break;
					}
					else if(nResult == 0)
					{
					}
					::Sleep(10);
				}
			}
		}
		else
		{
			if(!b2ndSkip)
			{
				b2ndFound = FALSE;
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL); //ChangeVisionAllParam(HIGH_2ND_CAM, pFidData);
				for(int i = 0; i < 5; i++)
				{
					int nMess = UM_VISION_FIND;
//					if(i == 0) nMess = UM_VISION_FIND_NOGRAP;
					int nResult = this->SendMessage(nMess, HIGH_2ND_CAM, pFidData->sVisInfo.nModelType);
					if(nResult == 1)// || (nFidIndex < 100 && nResult == 10))
					{
						b2ndFound = TRUE;
						dptResult2nd = visionResult;
						double dTableX, dTableY;
						gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dTableX, FALSE);
						gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dTableY, FALSE);
						strFidOffset.Format(_T("2nd 1 File( %d, %d ) Table( %.3f,%.3f ) : offset %.4f, %.4f"), 
							pFidData->npPosition.x, pFidData->npPosition.y, dTableX - dHead2ndOffsetX, dTableY - dHead2ndOffsetY, visionResult.x, visionResult.y);
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
						::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strFidOffset));

						pFidData->npTablePos2.x = (int)(1000 * (dTableX - dHead2ndOffsetX - visionResult.x));		// 20130312
						pFidData->npTablePos2.y = (int)(1000 * (dTableY - dHead2ndOffsetY - visionResult.y));

						m_dpFindFiducialPos2.x = dFinalMoveX + visionResult.x;
						m_dpFindFiducialPos2.y = dFinalMoveY + visionResult.y;
						if(nFidIndex >= 200)
							SaveFiducialImg(HIGH_2ND_CAM, nFidIndex);
						break;
					}
					else if( nResult == 10 || nResult == 20)
					{
						SaveFailFiducialImg(LOW_1ST_CAM, nFidIndex);
						break;
					}
					else if(nResult == 0)
					{
					}
					::Sleep(10);
				}
			}
		}
	}
}

BOOL CPaneAutoRun::GetFidPosInCenter(double dX, double dY, double dZ1, double dZ2, BOOL b1stPanel, BOOL bHighCam, LPFIDDATA pFidData, double dRetryX, double dRetryY)
{
	if(!gDeviceFactory.GetMotor()->MotorMoveXYZ(dX, dY, dZ1, dZ2, TRUE))
	{
		m_nErrMsgID = STDGNALM438;
		return FALSE;
	}
	if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		return FALSE;
	}
	
	if(b1stPanel)
	{
		if(!bHighCam)
		{
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
			for(int i = 0; i < 5; i++)
			{
				int nMess = UM_VISION_FIND;
//				if(i == 0) nMess = UM_VISION_FIND_NOGRAP;
				int nResult = this->SendMessage(nMess, LOW_1ST_CAM, pFidData->sVisInfo.nModelType);
				if(nResult == 1)
				{
					if(fabs(visionResult.x) > dRetryX || fabs(visionResult.y) > dRetryY) // center re find try
						return FALSE;

					m_dpFindFiducialPos.x = dX + visionResult.x;
					m_dpFindFiducialPos.y = dY + visionResult.y;
					SaveFiducialImg(LOW_1ST_CAM, 100);
					return TRUE;
				}
				else if (nResult == 10 || nResult == 20)
				{
					SaveFailFiducialImg(LOW_1ST_CAM, 100);
					break;
				}
				else if(nResult == 0)
				{
				}
				::Sleep(10);
			}
		}
		else
		{
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL);
			for(int i = 0; i < 5; i++)
			{
				int nMess = UM_VISION_FIND;
				if(i == 0) nMess = UM_VISION_FIND_NOGRAP;
				int nResult = this->SendMessage(nMess, HIGH_1ST_CAM, pFidData->sVisInfo.nModelType);
				if(nResult == 1)
				{
					if(fabs(visionResult.x) > dRetryX || fabs(visionResult.y) > dRetryY) // center re find try
						return FALSE;

					m_dpFindFiducialPos.x = dX + visionResult.x;
					m_dpFindFiducialPos.y = dY + visionResult.y;
					SaveFiducialImg(HIGH_1ST_CAM, 100);
					return TRUE;
				}
				else if (nResult == 10 || nResult == 20)
				{
					SaveFailFiducialImg(LOW_1ST_CAM, 100);
					break;
				}
				else if(nResult == 0)
				{
				}
				::Sleep(10);
			}
		}
	}
	else
	{
		if(!bHighCam)
		{
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
			for(int i = 0; i < 5; i++)
			{
				int nMess = UM_VISION_FIND;
//				if(i == 0) nMess = UM_VISION_FIND_NOGRAP;
				int nResult = this->SendMessage(nMess, LOW_2ND_CAM, pFidData->sVisInfo.nModelType);
				if(nResult == 1)
				{
					if(fabs(visionResult.x) > dRetryX || fabs(visionResult.y) > dRetryY) // center re find try
						return FALSE;

					m_dpFindFiducialPos2.x = dX + visionResult.x;
					m_dpFindFiducialPos2.y = dY + visionResult.y;
					SaveFiducialImg(LOW_2ND_CAM, 100);
					return TRUE;
				}
				else if (nResult == 10 || nResult == 20)
				{
					SaveFailFiducialImg(LOW_1ST_CAM, 100);
					break;
				}
				else if(nResult == 0)
				{
				}
				::Sleep(10);
			}
		}
		else
		{
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL); // ChangeVisionAllParam(HIGH_2ND_CAM, pFidData);
			for(int i = 0; i < 5; i++)
			{
				int nMess = UM_VISION_FIND;
//				if(i == 0) nMess = UM_VISION_FIND_NOGRAP;
				int nResult = this->SendMessage(nMess, HIGH_2ND_CAM, pFidData->sVisInfo.nModelType);
				if(nResult == 1)
				{
					if(fabs(visionResult.x) > dRetryX || fabs(visionResult.y) > dRetryY) // center re find try
						return FALSE;

					m_dpFindFiducialPos2.x = dX + visionResult.x;
					m_dpFindFiducialPos2.y = dY + visionResult.y;
					SaveFiducialImg(HIGH_2ND_CAM, 100);
					return TRUE;
				}
				else if (nResult == 10 || nResult == 20)
				{
					SaveFailFiducialImg(LOW_1ST_CAM, 100);
					break;
				}
				else if(nResult == 0)
				{
				}
				::Sleep(10);
			}
		}
	}
	return FALSE; 
}

BOOL CPaneAutoRun::ChangeVisionAllParam(int nCamNo, LPFIDDATA pFidData)
{
	this->SendMessage(UM_CHANGE_VISION_PARAM3, nCamNo, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
	this->SendMessage(UM_VISION_LAMP, nCamNo, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));

	if(nCamNo == LOW_1ST_CAM)
		::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
	else if(nCamNo == HIGH_1ST_CAM)
		::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL);
	else if(nCamNo == LOW_2ND_CAM)
		::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
	else
		::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL);
	return TRUE;
}

BOOL CPaneAutoRun::FindOneVerifyFiducial(LPFIDDATA pFidData, BOOL bAfterFire,LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd ,int nFidNo, int nFidBlock )
{
	double dZ1, dZ2, dHeadOffsetX1, dHeadOffsetY1, dHeadOffsetX2, dHeadOffsetY2;
	double dModelX = 0, dModelY = 0;
	double dLowFOVX = gSystemINI.m_sSystemDevice.dLowFOVX, dLowFOVY = gSystemINI.m_sSystemDevice.dLowFOVY, 
			dHighFOVX = gSystemINI.m_sSystemDevice.dHighFOVX, dHighFOVY = gSystemINI.m_sSystemDevice.dHighFOVY;
	BOOL bHighCam;
	double dFinalMoveX, dFinalMoveY;
	double dRefX, dRefY;
	int nROISize, nROIAllow = 400; // um
	double dReCheckVal = gProcessINI.m_sProcessFidFind.dRecheckTolerance;
	BOOL bResult = TRUE;

	int nPanelNo1, nPanelNo2;
	if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
	{
		nPanelNo1 = m_nCurrentLotCount;
		nPanelNo2 = m_nCurrentLotCount+1;
	}
	else
	{
		nPanelNo1 = m_nCurrentLotCount;
		nPanelNo2 = m_nCurrentLotCount;
	}
	
	CString strFile, strFidOffset;
	strFile.Format(_T("FidOffsetData"));

	CString strFile2, strLog;
	strFile2.Format(_T("CheckTrans"));

	gDProject.m_Glyphs.GetRefPosition(dRefX, dRefY);

	if(pFidData->sVisInfo.nModelType < 2) // annulus, circle
	{
		dModelX = dModelY = pFidData->sVisInfo.dSizeA;
		nROISize = (int)(dModelX * 1000 + nROIAllow);
	}
	else if(pFidData->sVisInfo.nModelType < MODEL_PATTERN) // other geometery
	{
		dModelX = pFidData->sVisInfo.dSizeA;
		dModelY = pFidData->sVisInfo.dSizeB;
		nROISize = (int)(max(dModelX, dModelY) * 1000 + nROIAllow);
	}
	else
	{
		nROISize = (int)(dLowFOVX * 1000);
	}

	if( (pFidData->nCam == LOW_CAM) || (pFidData->nCam == LOW_TO_HIGH_CAM) )
	{	// Low
#ifdef __PUSAN_LDD__
		this->SendMessage(UM_VISION_ROI_SET_UM, -1, LOW_1ST_CAM);
#else
		this->SendMessage(UM_VISION_ROI_SET_UM, nROISize, LOW_1ST_CAM);
#endif
	
		this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));

		dHeadOffsetX1 = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dHeadOffsetY1 = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		dHeadOffsetX2 = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		dHeadOffsetY2 = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;

		bHighCam = FALSE;
		dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - gDProject.m_dPcbThick + pFidData->dOffsetZ;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - gDProject.m_dPcbThick2 + pFidData->dOffsetZ;
	}
	else
	{	// High
#ifdef __PUSAN_LDD__
		this->SendMessage(UM_VISION_ROI_SET_UM, -1, HIGH_1ST_CAM);
#else
		this->SendMessage(UM_VISION_ROI_SET_UM, nROISize, HIGH_1ST_CAM);
#endif
		this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));

		dHeadOffsetX1 = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
		dHeadOffsetY1 = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		dHeadOffsetX2 = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
		dHeadOffsetY2 = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		
		bHighCam = TRUE;
		dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - gDProject.m_dPcbThick + pFidData->dOffsetZ;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - gDProject.m_dPcbThick2 + pFidData->dOffsetZ;
	}

	if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST)
	{									// 1st 기중으로 테이블 이동
		dFinalMoveX = gDProject.m_dRefPosX					// 기준점 설정 좌표 (table motor 좌표 : scanner center 기준)
			- (pFidData->npPosition.x / 1000.0 - dRefX)	// 기준점에서의 상대적 파일 좌표 차이 : table 좌표계와 file 좌표계가 반대로 움직임로 - 함.
			- pFidData->npTransPosition.x/1000. 							// 전에 찾았던 offset
			+ dHeadOffsetX1;
		dFinalMoveY = gDProject.m_dRefPosY 
			- (pFidData->npPosition.y / 1000.0 - dRefY) 	
			- pFidData->npTransPosition.y/1000. 						
			+ dHeadOffsetY1;
		
		if(!gDeviceFactory.GetMotor()->MotorMoveXYZ(dFinalMoveX, dFinalMoveY, dZ1, dZ2, TRUE, AUTORUN_MOVE))
		{
			m_nErrMsgID = STDGNALM438;
			return FALSE;
		}
		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
			return FALSE;
		}

		if(!bHighCam)
		{
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL); //ChangeVisionAllParam(LOW_1ST_CAM, pFidData);
			int nReturn = FALSE;
			for(int i = 0; i < 3; i++)
			{
				nReturn = this->SendMessage(UM_VISION_FIND, LOW_1ST_CAM, pFidData->sVisInfo.nModelType);
				if(nReturn) break;
			}
			if(!nReturn)
			{
				if(bAfterFire)
				{
					strFidOffset.Format(_T("1st (After Fire : %d) Table %.3f, %.3f Not Found"), bAfterFire, dFinalMoveX, dFinalMoveY);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				}
				return FALSE;
			}
		}
		else
		{
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL); //ChangeVisionAllParam(HIGH_1ST_CAM, pFidData);
			int nReturn = FALSE;
			for(int i = 0; i < 3; i++)
			{
				nReturn = this->SendMessage(UM_VISION_FIND, HIGH_1ST_CAM, pFidData->sVisInfo.nModelType);
				if(nReturn) break;
			}
			if(!nReturn)
			{
				if(bAfterFire)
				{
					strFidOffset.Format(_T("1st (After Fire : %d) Table %.3f, %.3f Not Found"), bAfterFire, dFinalMoveX, dFinalMoveY);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				}
				
				return FALSE;
			}
		}
		if(bAfterFire) // 위치의 변화가 없어야 한다. //10um
		{
			if(fabs(visionResult.x) > dReCheckVal || fabs(visionResult.y) > dReCheckVal)
			{
				strFidOffset.Format(_T("1st (After Fire : %d) Table %.3f, %.3f Shift Error : offset %.4f, %.4f"), bAfterFire, dFinalMoveX, dFinalMoveY, visionResult.x, visionResult.y);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strFidOffset));
				if(!bHighCam)
					this->SendMessage(UM_VISION_SAVE, LOW_1ST_CAM + 10, 1);
				else
					this->SendMessage(UM_VISION_SAVE, HIGH_1ST_CAM + 10, 1);
				bResult = FALSE;
			}
			else
			{
				strFidOffset.Format(_T("1st (After Fire : %d) Table %.3f, %.3f OK : offset %.4f, %.4f"), bAfterFire, dFinalMoveX, dFinalMoveY, visionResult.x, visionResult.y);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strFidOffset));
			}
		}
		else
		{
			strFidOffset.Format(_T("1st (second/verify : %d) Table %.3f, %.3f OK : offset %.4f, %.4f"), bAfterFire, dFinalMoveX, dFinalMoveY, visionResult.x, visionResult.y);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
//			InsertFidResult(TRUE, pFidData->npPosition, nFidBlock, pPanel1st, pPanel2nd, visionResult.x, visionResult.y);
			pFidData->npTransPosition.x += (long)visionResult.x * 1000;
			pFidData->npTransPosition.y += (long)visionResult.y * 1000;
			pFidData->bAcquire[0] = TRUE;
			strLog.Format(_T("TransPosition : (%d, %d)"), pFidData->npTransPosition.x, pFidData->npTransPosition.y);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				
		}

	}
	if((gDProject.m_nSeparation == USE_DUAL  && !m_bOdd) || gDProject.m_nSeparation == USE_2ND)
	{
		dFinalMoveX = gDProject.m_dRefPosX					// 기준점 설정 좌표 (table motor 좌표 : scanner center 기준)
			- (pFidData->npPosition.x / 1000.0 - dRefX)	// 기준점에서의 상대적 파일 좌표 차이 : table 좌표계와 file 좌표계가 반대로 움직임로 - 함.
			- pFidData->npTransPosition2.x/1000. 							// 전에 찾았던 offset
			+ dHeadOffsetX2;
		dFinalMoveY = gDProject.m_dRefPosY 
			- (pFidData->npPosition.y / 1000.0 - dRefY) 	
			- pFidData->npTransPosition2.y/1000. 						
			+ dHeadOffsetY2;
		
		if(!gDeviceFactory.GetMotor()->MotorMoveXYZ(dFinalMoveX, dFinalMoveY, dZ1, dZ2, FALSE, AUTORUN_MOVE))
		{
			m_nErrMsgID = STDGNALM438;
			return FALSE;
		}
		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
		{

			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
			return FALSE;
		}
		if(!bHighCam)
		{
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL); //ChangeVisionAllParam(LOW_2ND_CAM, pFidData);
			int nReturn = FALSE;
			for(int i = 0; i < 3; i++)
			{
				nReturn = this->SendMessage(UM_VISION_FIND, LOW_2ND_CAM, pFidData->sVisInfo.nModelType);
				if(nReturn) break;
			}
			if(!nReturn)
			{
				if(bAfterFire)
				{
					strFidOffset.Format(_T("2nd (After Fire : %d) Table %.3f, %.3f Not Found"), bAfterFire, dFinalMoveX, dFinalMoveY);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				}
				
				return FALSE;
			}
		}
		else
		{
			::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL); //ChangeVisionAllParam(HIGH_2ND_CAM, pFidData);
			int nReturn = FALSE;
			for(int i = 0; i < 3; i++)
			{
				nReturn = this->SendMessage(UM_VISION_FIND, HIGH_2ND_CAM, pFidData->sVisInfo.nModelType);
				if(nReturn) break;
			}
			if(!nReturn)
			{
				if(bAfterFire)
				{
					strFidOffset.Format(_T("2nd (After Fire : %d) Table %.3f, %.3f Not Found"), bAfterFire, dFinalMoveX, dFinalMoveY);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				}
				return FALSE;
			}
		}
		if(bAfterFire) // 위치의 변화가 없어야 한다. //10um
		{
			if(fabs(visionResult.x) > dReCheckVal || fabs(visionResult.y) > dReCheckVal)
			{
				strFidOffset.Format(_T("2nd (After Fire : %d) Table %.3f, %.3f Shift Error : offset %.4f, %.4f"), bAfterFire, dFinalMoveX, dFinalMoveY, visionResult.x, visionResult.y);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strFidOffset));
				if(!bHighCam)
					this->SendMessage(UM_VISION_SAVE, LOW_2ND_CAM + 10, 2);
				else
					this->SendMessage(UM_VISION_SAVE, HIGH_2ND_CAM + 10, 2);
				bResult = FALSE;
			}
			else
			{
				strFidOffset.Format(_T("2nd (After Fire : %d) Table %.3f, %.3f OK : offset %.4f, %.4f"), bAfterFire, dFinalMoveX, dFinalMoveY, visionResult.x, visionResult.y);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strFidOffset));
			}
		}
		else
		{
			strFidOffset.Format(_T("2nd (second/verify : %d) Table %.3f, %.3f OK : offset %.4f, %.4f"), bAfterFire, dFinalMoveX, dFinalMoveY, visionResult.x, visionResult.y);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
//			InsertFidResult(FALSE, pFidData->npPosition, nFidBlock,pPanel1st, pPanel2nd, visionResult.x, visionResult.y);			
			pFidData->npTransPosition2.x += (long)visionResult.x * 1000;
			pFidData->npTransPosition2.y += (long)visionResult.y * 1000;
			pFidData->bAcquire[1] = TRUE;
			strLog.Format(_T("TransPosition2 : (%d, %d)"), pFidData->npTransPosition2.x, pFidData->npTransPosition2.y);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				
		}
	}
	return bResult;
}

BOOL CPaneAutoRun::FindOneFiducial(LPFIDDATA pFidData, int nFidNo, int nFidBlock, LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd)
{
	double dZ1, dZ2, dHeadOffsetX, dHeadOffsetY, dHeadOffsetX1, dHeadOffsetY1, dHeadOffsetX2, dHeadOffsetY2;
	double dStepX, dStepY, dReTryOffX, dReTryOffY, dModelX = 0, dModelY = 0;
	double dLowFOVX = gSystemINI.m_sSystemDevice.dLowFOVX, dLowFOVY = gSystemINI.m_sSystemDevice.dLowFOVY, 
			dHighFOVX = gSystemINI.m_sSystemDevice.dHighFOVX, dHighFOVY = gSystemINI.m_sSystemDevice.dHighFOVY;
	BOOL bHighCam, bFidUserImage = TRUE;
	CDPoint dIndexP;
	double dFinalMoveX, dFinalMoveY;
	double dCurrentMove1stPX, dCurrentMove1stPY, dCurrentMove2ndPX, dCurrentMove2ndPY, dOffsetZero1stPX, dOffsetZero1stPY, dOffsetZero2ndPX, dOffsetZero2ndPY; // 
	double dRefX, dRefY;
	CDPoint dptResult1st, dptResult2nd, dptTemp;
	CDPoint dOffsetP;
	CDPoint dCoarseOffset;
	BOOL	b1stFound, b2ndFound, bFoundTemp;
	BOOL	b1stSkip, b2ndSkip;
	int nPanelNo1, nPanelNo2;
	
	if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
	{
		nPanelNo1 = m_nCurrentLotCount;
		nPanelNo2 = m_nCurrentLotCount+1;
	}
	else
	{
		nPanelNo1 = m_nCurrentLotCount;
		nPanelNo2 = m_nCurrentLotCount;
	}

	CString strFile, strFidOffset;
	strFile.Format(_T("FidOffsetData"));

	CString strFile2, strLog;
	strFile2.Format(_T("CheckTrans"));

	pFidData->bAcquire[USE_1ST - 1] = pFidData->bAcquire[USE_2ND - 1] = FALSE; // default : not found

	gDProject.m_Glyphs.GetRefPosition(dRefX, dRefY);

	if(pFidData->sVisInfo.nModelType < 2) // annulus, circle
	{
		dModelX = dModelY = pFidData->sVisInfo.dSizeA;
		bFidUserImage = FALSE;
	}
	else if(pFidData->sVisInfo.nModelType < MODEL_PATTERN) // other geometery
	{
		dModelX = pFidData->sVisInfo.dSizeA;
		dModelY = pFidData->sVisInfo.dSizeB;
		bFidUserImage = FALSE;
	}
	

	if( (pFidData->nCam == LOW_CAM) || (pFidData->nCam == LOW_TO_HIGH_CAM) )
	{	// Low
		this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));


		dHeadOffsetX1 = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		dHeadOffsetY1 = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		dHeadOffsetX2 = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		dHeadOffsetY2 = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;

		if(!bFidUserImage)
		{
#ifdef __PUSAN_LDD__
			dReTryOffX = 0.05; // 0.1 여분
			dReTryOffY = 0.05; // 0.1 여분
#else
			dReTryOffX = max((dLowFOVX - dModelX)/2 - 0.1, 0.1); // 0.1 여분
			dReTryOffY = max((dLowFOVY - dModelY)/2 - 0.1, 0.1); // 0.1 여분
#endif

			dStepX = dLowFOVX - dModelX;
			dStepY = dLowFOVY - dModelY;
		}
		else
		{
			dReTryOffX = dLowFOVX; // retry 안함
			dReTryOffY = dLowFOVY; // retry 안함
			dStepX = gProcessINI.m_sProcessFidFind.dMoveLowVision.x;
			dStepY = gProcessINI.m_sProcessFidFind.dMoveLowVision.y;
		}
		bHighCam = FALSE;
		dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - gDProject.m_dPcbThick + pFidData->dOffsetZ;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - gDProject.m_dPcbThick2 + pFidData->dOffsetZ;
	}
	else
	{	// High
		this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));
		this->SendMessage(UM_VISION_LAMP, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&pFidData->sVisInfo));

		dHeadOffsetX1 = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
		dHeadOffsetY1 = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
		dHeadOffsetX2 = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
		dHeadOffsetY2 = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
		
		if(!bFidUserImage)
		{
#ifdef __PUSAN_LDD__
			dReTryOffX = 0.05; // 0.1 여분
			dReTryOffY = 0.05; // 0.1 여분
#else
			dReTryOffX = max((dHighFOVX - dModelX)/2 - 0.01, 0.01); // 0.01 여분
			dReTryOffY = max((dHighFOVY - dModelY)/2 - 0.01, 0.01); // 0.01 여분
#endif
			dStepX = dHighFOVX - dModelX;
			dStepY = dHighFOVY - dModelY;
		}
		else
		{
			dReTryOffX = dHighFOVX; // retry 안함
			dReTryOffY = dHighFOVY; // retry 안함
			dStepX = gProcessINI.m_sProcessFidFind.dMoveHighVision.x;
			dStepY = gProcessINI.m_sProcessFidFind.dMoveHighVision.y;
		}
		bHighCam = TRUE;
		dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - gDProject.m_dPcbThick + pFidData->dOffsetZ;
		dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - gDProject.m_dPcbThick2 + pFidData->dOffsetZ;
	}

	dCurrentMove1stPX = dOffsetZero1stPX = gDProject.m_dRefPosX	- (pFidData->npPosition.x / 1000.0 - dRefX) + dHeadOffsetX1;
	dCurrentMove1stPY = dOffsetZero1stPY = gDProject.m_dRefPosY	- (pFidData->npPosition.y / 1000.0 - dRefY) + dHeadOffsetY1;
	dCurrentMove2ndPX = dOffsetZero2ndPX = gDProject.m_dRefPosX	- (pFidData->npPosition.x / 1000.0 - dRefX) + dHeadOffsetX2;
	dCurrentMove2ndPY = dOffsetZero2ndPY = gDProject.m_dRefPosY	- (pFidData->npPosition.y / 1000.0 - dRefY) + dHeadOffsetY2;

	if(gDProject.m_nSeparation == USE_2ND)
	{
		dHeadOffsetX = dHeadOffsetX2;
		dHeadOffsetY = dHeadOffsetY2;
		dOffsetP.x = pFidData->npTransPosition2.x/1000.; dOffsetP.y = pFidData->npTransPosition2.y/1000.;
	}
	else
	{									// 1st 기중으로 테이블 이동
		dHeadOffsetX = dHeadOffsetX1;
		dHeadOffsetY = dHeadOffsetY1;
		dOffsetP.x = pFidData->npTransPosition.x/1000.; dOffsetP.y = pFidData->npTransPosition.y/1000.;
	}

	b1stFound = b2ndFound = FALSE;					// 실제 fiducial을 찾았는지 판단 --> false : return false.
	b1stSkip = b2ndSkip = FALSE;					// 아래 retry에서 찾은 것은 skip하려고

	
	dptResult1st.x = dptResult1st.y = dptResult2nd.x = dptResult2nd.y = 0; // 
	for(int k = 0; k < gProcessINI.m_sProcessFidFind.nFidTotalRetrial; k++)
	{
		if(!CheckStatus())
			return FALSE;

		if(gDProject.m_nSeparation == USE_DUAL && b1stSkip)
		{
			dOffsetP.x = pFidData->npTransPosition2.x/1000.; dOffsetP.y = pFidData->npTransPosition2.y/1000.;
			dHeadOffsetX = dHeadOffsetX2;
			dHeadOffsetY = dHeadOffsetY2;
		}
			
		dIndexP = GetNextStepIndex(k);

		// Table move

		dFinalMoveX = gDProject.m_dRefPosX					// 기준점 설정 좌표 (table motor 좌표 : scanner center 기준)
			- (pFidData->npPosition.x / 1000.0 - dRefX)	// 기준점에서의 상대적 파일 좌표 차이 : table 좌표계와 file 좌표계가 반대로 움직임로 - 함.
			- dIndexP.x * dStepX 					// retry fid x step
			- dOffsetP.x 							// 전에 찾았던 offset
			+ dHeadOffsetX;
		dFinalMoveY = gDProject.m_dRefPosY 
			- (pFidData->npPosition.y / 1000.0 - dRefY) 	
			- dIndexP.y * dStepY 					
			- dOffsetP.y 						
			+ dHeadOffsetY;
		
		if(!gDeviceFactory.GetMotor()->MotorMoveXYZ(dFinalMoveX, dFinalMoveY, dZ1, dZ2, TRUE))
		{
			m_nErrMsgID = STDGNALM438;
			return FALSE;
		}
		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
			return FALSE;
		}

		gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
		SendFindTrigger(b1stFound, b2ndFound, bHighCam, b1stSkip, b2ndSkip, pFidData, dFinalMoveX, dFinalMoveY, dptResult1st, dptResult2nd, nFidNo,
			dHeadOffsetX1, dHeadOffsetY1, dHeadOffsetX2, dHeadOffsetY2);

		if(b1stFound) // found 1st
		{
			
			gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptScore);
			if(pFidData->nCam == LOW_TO_HIGH_CAM)
			{
				pFidData->npTransPosition.x = (int)((dOffsetZero1stPX - dFinalMoveX + dptResult1st.x) * 1000); //dIndexP.x * dStepX + dOffsetP.x + visionResult.x
				pFidData->npTransPosition.y = (int)((dOffsetZero1stPY - dFinalMoveY + dptResult1st.y) * 1000); //dIndexP.y * dStepY + dOffsetP.y + visionResult.y
				strLog.Format(_T("TransPosition : (%d, %d)"), pFidData->npTransPosition.x, pFidData->npTransPosition.y);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				if(GetFidPosHighCamInCenter(TRUE, pFidData))
				{
					b1stSkip = TRUE; b1stFound = FALSE;
//					InsertFidResult(TRUE, pFidData->npPosition, nFidBlock, pPanel1st, pPanel2nd, dptResult1st.x, dptResult1st.y);
					if(gDProject.m_nSeparation == USE_DUAL && b1stSkip)
						k = -1;
				}
			}
			else if(fabs(dptResult1st.x) > dReTryOffX || fabs(dptResult1st.y) > dReTryOffY || m_bRetryFidFind) // center re find try : // 20130404 bhlee
			{
				if(GetFidPosInCenter(dFinalMoveX - dptResult1st.x, dFinalMoveY - dptResult1st.y, dZ1, dZ2, TRUE, bHighCam, pFidData, dReTryOffX, dReTryOffY))
				{
					dCurrentMove1stPX = dFinalMoveX - dptResult1st.x; dCurrentMove1stPY = dFinalMoveY - dptResult1st.y;
					dptResult1st = visionResult;
					b1stSkip = TRUE; b1stFound = FALSE;
					strFidOffset.Format(_T("1st 2 ( %.3f,%.3f ) : offset %.4f, %.4f"), dCurrentMove1stPX - dHeadOffsetX1, dCurrentMove1stPY - dHeadOffsetY1, dptResult1st.x, dptResult1st.y);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strFidOffset));

					pFidData->npTablePos1.x = (int)(1000 * (dCurrentMove1stPX - dHeadOffsetX1 - dptResult1st.x));
					pFidData->npTablePos1.y = (int)(1000 * (dCurrentMove1stPY - dHeadOffsetY1 - dptResult1st.y));		// 20130312
//					InsertFidResult(TRUE, pFidData->npPosition, nFidBlock, pPanel1st, pPanel2nd, dptResult1st.x, dptResult1st.y);
					if(gDProject.m_nSeparation == USE_DUAL && b1stSkip)
						k = -1;
				}
			}
			else
			{
				if(gProcessINI.m_sProcessSystem.bUseFindSecondFid)
				{
					gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptScore);
					SendFindTrigger(b1stFound, bFoundTemp, bHighCam, b1stSkip, TRUE, pFidData, dFinalMoveX, dFinalMoveY, dptResult1st, dptTemp, nFidNo + 200,
						dHeadOffsetX1, dHeadOffsetY1, dHeadOffsetX2, dHeadOffsetY2);
					gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				}

				if(b1stFound)
				{
					dCurrentMove1stPX = dFinalMoveX; dCurrentMove1stPY = dFinalMoveY;
					b1stSkip = TRUE; b1stFound = FALSE;
//					InsertFidResult(TRUE, pFidData->npPosition, nFidBlock, pPanel1st, pPanel2nd, dptResult1st.x, dptResult1st.y);
					if(gDProject.m_nSeparation == USE_DUAL && b1stSkip)
						k = -1;
				}
			}
			gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
		}

		if(b2ndFound) // found 2nd
		{
			gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptScore);
			if(pFidData->nCam == LOW_TO_HIGH_CAM)
			{
				gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dCurrentMove2ndPX, FALSE);
				gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dCurrentMove2ndPY, FALSE);
				pFidData->npTransPosition2.x = (int)((dOffsetZero2ndPX - dCurrentMove2ndPX + dptResult2nd.x) * 1000); //dIndexP.x * dStepX + dOffsetP.x + visionResult.x
				pFidData->npTransPosition2.y = (int)((dOffsetZero2ndPY - dCurrentMove2ndPY + dptResult2nd.y) * 1000); //dIndexP.y * dStepY + dOffsetP.y + visionResult.y
				strLog.Format(_T("TransPosition2 : (%d, %d)"), pFidData->npTransPosition2.x, pFidData->npTransPosition2.y);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				if(GetFidPosHighCamInCenter(FALSE, pFidData))
				{
					b2ndSkip = TRUE; b2ndFound = FALSE;
//					InsertFidResult(FALSE, pFidData->npPosition, nFidBlock, pPanel1st, pPanel2nd, dptResult2nd.x, dptResult2nd.y);
				}
			}
			if(fabs(dptResult2nd.x) > dReTryOffX || fabs(dptResult2nd.y) > dReTryOffY || m_bRetryFidFind) // center re find try : // 20130404 bhlee
			{
				if(GetFidPosInCenter(dFinalMoveX - dptResult2nd.x, dFinalMoveY - dptResult2nd.y, dZ1, dZ2, FALSE, bHighCam, pFidData, dReTryOffX, dReTryOffY))
				{
					gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dCurrentMove2ndPX, FALSE);
					gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dCurrentMove2ndPY, FALSE);
					dptResult2nd = visionResult;
					b2ndSkip = TRUE; b2ndFound = FALSE;
					strFidOffset.Format(_T("2nd 2 ( %.3f,%.3f ) : offset %.4f, %.4f"), dCurrentMove2ndPX - dHeadOffsetX2, dCurrentMove2ndPY - dHeadOffsetY2, dptResult2nd.x, dptResult2nd.y);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strFidOffset));
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strFidOffset));

					pFidData->npTablePos2.x = (int)(1000 * (dCurrentMove2ndPX - dHeadOffsetX2 - dptResult2nd.x));		// 20130312
					pFidData->npTablePos2.y = (int)(1000 * (dCurrentMove2ndPY - dHeadOffsetY2 - dptResult2nd.y));

//					InsertFidResult(FALSE, pFidData->npPosition, nFidBlock, pPanel1st, pPanel2nd, dptResult2nd.x, dptResult2nd.y);
				}
			}
			else
			{
				if(gProcessINI.m_sProcessSystem.bUseFindSecondFid)
				{
					gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptScore);
					SendFindTrigger(bFoundTemp, b2ndFound, bHighCam, TRUE, b2ndSkip, pFidData, dFinalMoveX, dFinalMoveY, dptTemp, dptResult2nd, nFidNo + 200,
						dHeadOffsetX1, dHeadOffsetY1, dHeadOffsetX2, dHeadOffsetY2);
					gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
				}

				if(b2ndFound)
				{
					gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dCurrentMove2ndPX, FALSE);
					gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dCurrentMove2ndPY, FALSE);
#ifdef __TEST__
					dCurrentMove2ndPX = dOffsetZero2ndPX; dCurrentMove2ndPY = dOffsetZero2ndPY;
#endif
					b2ndSkip = TRUE; b2ndFound = FALSE;
//					InsertFidResult(FALSE, pFidData->npPosition, nFidBlock, pPanel1st, pPanel2nd, dptResult2nd.x, dptResult2nd.y);
				}
			}
			gDeviceFactory.GetVision()->SetAcceptScore(gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
		}

		


		if(! ((gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST) && !b1stSkip) )// all found, so no more find
		{
			if(b1stSkip && pFidData->nCam != LOW_TO_HIGH_CAM)
			{
				pFidData->npTransPosition.x = (int)((dOffsetZero1stPX - dCurrentMove1stPX + dptResult1st.x) * 1000); //dIndexP.x * dStepX + dOffsetP.x + visionResult.x
				pFidData->npTransPosition.y = (int)((dOffsetZero1stPY - dCurrentMove1stPY + dptResult1st.y) * 1000); //dIndexP.y * dStepY + dOffsetP.y + visionResult.y
				pFidData->bAcquire[USE_1ST - 1] = TRUE;
				InsertFidResult(TRUE, pFidData->npPosition, nFidBlock, pPanel1st, pPanel2nd, pFidData->npTransPosition.x, pFidData->npTransPosition.y);
				strLog.Format(_T("TransPosition : (%d, %d)"), pFidData->npTransPosition.x, pFidData->npTransPosition.y);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				
			}
		}
		if(! (( (gDProject.m_nSeparation == USE_DUAL && !m_bOdd) || gDProject.m_nSeparation == USE_2ND) && !b2ndSkip)   )// all found, so no more find
		{
			if(b2ndSkip && pFidData->nCam != LOW_TO_HIGH_CAM)
			{
				if((gDProject.m_nSeparation == USE_DUAL && !m_bOdd) || gDProject.m_nSeparation == USE_2ND)
				{
					pFidData->npTransPosition2.x = (int)((dOffsetZero2ndPX - dCurrentMove2ndPX + dptResult2nd.x) * 1000); //dIndexP.x * dStepX + dOffsetP.x + visionResult.x
					pFidData->npTransPosition2.y = (int)((dOffsetZero2ndPY - dCurrentMove2ndPY + dptResult2nd.y) * 1000); //dIndexP.y * dStepY + dOffsetP.y + visionResult.y
					pFidData->bAcquire[USE_2ND - 1] = TRUE;
					InsertFidResult(FALSE, pFidData->npPosition, nFidBlock, pPanel1st, pPanel2nd, pFidData->npTransPosition2.x, pFidData->npTransPosition2.y);
					strLog.Format(_T("TransPosition2 : (%d, %d)"), pFidData->npTransPosition2.x, pFidData->npTransPosition2.y);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				
				}
			}
		}
		if(!( ((gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST) && !b1stSkip) ||
			(((gDProject.m_nSeparation == USE_DUAL && !m_bOdd) || gDProject.m_nSeparation == USE_2ND) && !b2ndSkip)   ) )// all found, so no more find
		{
			return TRUE;
		}

	}
	
	m_nErrMsgID = STDGNALM709;
	return FALSE;
}
LRESULT CPaneAutoRun::GetVisionResultNoGrab(WPARAM wParam, LPARAM lParam)
{
	HVision* pVision = gDeviceFactory.GetVision();
	double dTemp;
	int nResult = pVision->GetNoGrabRealPos(&visionResult, wParam, lParam, TRUE, NULL, dTemp);
	
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
		visionResult.x = gProcess.m_ResultData[wParam].dx;
		visionResult.y = gProcess.m_ResultData[wParam].dy;
#endif
	}
	return nResult;
}

void CPaneAutoRun::DrillOneCycleNoUnloadPause()
{
	m_bUserStop = FALSE;
	m_bOneCycleStopNoUnloadPause = !m_bOneCycleStopNoUnloadPause;
	
	if(m_bOneCycleStopNoUnloadPause)
	{
		GetDlgItem(IDC_CHECK_TABLE_SUCTION)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_TABLE_SUCTION2)->EnableWindow(FALSE);
	}
}

int CPaneAutoRun::DoOneCyclyStopNoUnloadPause() // 수정이 필요한 상황임. 2013.1.8 bhLee
{
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage( DRILL_ONE_CYCLE_NOUNLOAD, 0 );
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage( DRILL_ONE_CYCLE_NOUNLOAD, 3 );
	
//	gDeviceFactory.GetMotor()->SetOutPort(PORT_AUTO_MPG_ENABLE, TRUE);
	this->SendMessage(AUTO_MSG, FIREPAUSES_TIME);
	
	if(gDeviceFactory.GetMotor()->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX, gProcessINI.m_sProcessAutoSetting.dLoadPosY, TRUE))
	{
		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis, TRUE); 
		}
	}
	
	GetDlgItem(IDC_CHECK_TABLE_SUCTION)->EnableWindow(TRUE);
	GetDlgItem(IDC_CHECK_TABLE_SUCTION2)->EnableWindow(TRUE);
	
	while (m_bOneCycleStopNoUnloadPause)
	{
		::Sleep(100);
		MessageLoop();
		if(!CheckStatus())
			break;
	}
	
	SendMessage(AUTO_MSG, FIREPAUSEE_TIME);
//	gDeviceFactory.GetMotor()->SetOutPort(PORT_AUTO_MPG_ENABLE, FALSE);
	
//	EnableButton(FALSE);
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage( DRILL_ONE_CYCLE_NOUNLOAD, 4 );
	if(m_nErrMsgID == STDGNALM803) // user stop
	{
		return 0; // stop
	}
	else
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage( DRILL_ONE_CYCLE_NOUNLOAD, 1 );
		return 1; // resume;
	}
}
BOOL CPaneAutoRun::DoStandby(double dDiffTime)
{
	if(gSystemINI.m_sSystemDump.n3RDDummyType == DUMMY_3RD_NO_USE)
	{
		return TRUE;
	}

	BOOL bDummyFree = gDeviceFactory.GetEocard()->IsStannbyShotRun();
	if(!bDummyFree)
	{
		if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
		{
			ErrMsgDlg(STDGNALM781);
			return FALSE;
		}
	
	}

	double dStandbyTime;
	CCorrectTime Temp;
	Temp.StartTime();
	while(TRUE)
	{
		Sleep(100);
		if(!CheckStatus())
		{
			return FALSE;
		}
		
		MessageLoop();
		
		dStandbyTime = Temp.PresentTime();
		if(dStandbyTime > dDiffTime)
			break;
	}
	m_bUserDummyOn = gDeviceFactory.GetEocard()->IsStannbyShotRun();
	return TRUE;
}

BOOL CPaneAutoRun::SkivingFire(BOOL bCheckAlreadyFire)
{
	LPFIDDATA pFidData;

	int nAddProperty = 0, nDelProperty = 0;
	BOOL bFire;
	nAddProperty = FID_DRILL;

	if(bCheckAlreadyFire)
	{
		if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
			::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, TRUE);
	}

	int nCnt = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, nAddProperty, nDelProperty, -1);
	for(int i = 0; i < nCnt; i++) // fid 개수만큼 찾기
	{
		bFire = TRUE;
		pFidData = gDProject.m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, i, nAddProperty, nDelProperty, -1);

//		gDProject.GetTransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dTranFidX, dTranFidY, TRUE, pFidData->nFidBlock);
//		pFidData->npTransPosition.x = (int)dTranFidX; pFidData->npTransPosition.y = (int)dTranFidY;
//		gDProject.GetTransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dTranFidX, dTranFidY, FALSE, pFidData->nFidBlock);
//		pFidData->npTransPosition2.x = (int)dTranFidX; pFidData->npTransPosition2.y = (int)dTranFidY;
		
		if(bCheckAlreadyFire)
		{
			CString strSequenceLog;
			strSequenceLog.Format(_T("Start Pre-Finding Skiving Fiducial."));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));

			if(!FindOneVerifyFiducial(pFidData, FALSE, NULL, NULL)) // 자동으로 찾아보고 찾아진 경우에는 선택되어 있어도 가공을 하지않는다.
			{
				if(m_nErrMsgID == STDGNALM438 || m_nErrMsgID == STDGNALM404 || m_nErrMsgID == STDGNALM405 ||
					m_nErrMsgID == STDGNALM406 || m_nErrMsgID == STDGNALM407 || m_nErrMsgID == STDGNALM408 ||
					m_nErrMsgID == STDGNALM409 || m_nErrMsgID == STDGNALM990 ||	m_nErrMsgID == STDGNALM410 || 
					m_nErrMsgID == STDGNALM411) // motor 이상 --> 즉시 종료 : FindOneVerifyFiducial 함수에 에러 list 추가 되면 여기도 추가해야함.
				{
					strSequenceLog.Format(_T("End Pre-Finding Skiving Fiducial : Fail"));
					::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));

					if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
						::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);
					return FALSE;
				}

				strSequenceLog.Format(_T("End Pre-Finding Skiving Fiducial : Not Found"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));

				if(!m_bSelectFire || (m_bSelectFire && pFidData->bSelected)) // 20130419 선택가공이 아니거나, 선택가공 상태에서 선택된 fiducial만 가공한다.
					bFire = TRUE;
				else
					bFire = FALSE;
			}
			else
			{
				strSequenceLog.Format(_T("End Pre-Finding Skiving Fiducial : OK"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
				bFire = FALSE;
			}
		}
		
		if(bFire)
		{
			if(!FireOneSkivingFiducial(pFidData))
			{
				if(bCheckAlreadyFire)
				{
					if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
						::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);
				}
				return FALSE;
			}
		}
	}

	if(bCheckAlreadyFire)
	{
		if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
			::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);
	}
	return TRUE;
}

BOOL CPaneAutoRun::FireOneSkivingFiducial(LPFIDDATA pFidData)
{
#ifndef __TEST__
	int	nEocardHoleCount = 0, nDownShotCnt = 0, nReadShotCnt = 0, nSubCount = 0;
#endif
	HEocard* pEocard = gDeviceFactory.GetEocard();
	double dFinalMoveX, dFinalMoveY, dHeight1, dHeight2, dC1, dC2, dA1, dA2;
	double dRefX, dRefY,dPanelOffsetX, dPanelOffsetY;
	BOOL b1stPanel = TRUE;
	CPoint ptMaster, ptSlave;
	CString strFile, strLog;
	strFile.Format(_T("ReadHole"));
	gDProject.m_Glyphs.GetRefPosition(dRefX, dRefY);
	
	ptMaster.x = ptMaster.y = ptSlave.x = ptSlave.y = HALF_LSB;
	if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST)
	{									
		dFinalMoveX = gDProject.m_dRefPosX					// 기준점 설정 좌표 (table motor 좌표 : scanner center 기준)
			- (pFidData->npPosition.x / 1000.0 - dRefX)		// 기준점에서의 상대적 파일 좌표 차이 : table 좌표계와 file 좌표계가 반대로 움직임로 - 함.
			- pFidData->npTransPosition.x/1000. ;			// 전에 찾았던 offset
		dFinalMoveY = gDProject.m_dRefPosY 
			- (pFidData->npPosition.y / 1000.0 - dRefY) 	
			- pFidData->npTransPosition.y/1000.;
		if(gDProject.m_nSeparation == USE_DUAL)
		{
			gDeviceFactory.GetMotor()->GetAxisMoveOffset(dFinalMoveX, dFinalMoveY, dPanelOffsetX, dPanelOffsetY, DELTA_PANEL_OFFSET);
			ptSlave.x = 32767 + (int)((pFidData->npTransPosition2.x - pFidData->npTransPosition.x - dPanelOffsetX) * MAXLSB / (gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0));
			ptSlave.y = 32767 + (int)((pFidData->npTransPosition2.y - pFidData->npTransPosition.y - dPanelOffsetY) * MAXLSB / (gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0));
			if(ptSlave.x < 0 || ptSlave.x > MAXLSB || ptSlave.y < 0 || ptSlave.y > MAXLSB)
			{
				m_nErrMsgID = STDGNALM659; //miss shot error
				return FALSE;
			}
		}
	}
	else
	{
		dFinalMoveX = gDProject.m_dRefPosX					// 기준점 설정 좌표 (table motor 좌표 : scanner center 기준)
			- (pFidData->npPosition.x / 1000.0 - dRefX)		// 기준점에서의 상대적 파일 좌표 차이 : table 좌표계와 file 좌표계가 반대로 움직임로 - 함.
			- pFidData->npTransPosition2.x/1000. ;			// 전에 찾았던 offset
		dFinalMoveY = gDProject.m_dRefPosY 
			- (pFidData->npPosition.y / 1000.0 - dRefY) 	
			- pFidData->npTransPosition2.y/1000.;
		b1stPanel = FALSE;
	}

	SUBTOOLDATA subTool;
	POSITION pos = gDProject.m_pToolCode[ADDED_FID_TOOL]->m_SubToolData.GetHeadPosition();
	int nSubNo = 0;
	while(pos)
	{
		subTool = gDProject.m_pToolCode[ADDED_FID_TOOL]->m_SubToolData.GetNext(pos);

		BOOL bTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[subTool.nMask];
		if(!gDeviceFactory.GetMotor()->MoveTophatShutter(bTophat))
		{
			m_nErrMsgID = STDGNALM568;
			return FALSE;
		}
		BOOL bLaserPath = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[subTool.nMask];
		if(!gDeviceFactory.GetMotor()->MoveLaserBeamPath(bLaserPath))
		{
			m_nErrMsgID = STDGNALM974;
			return FALSE;
		}


		dHeight1 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[subTool.nMask] - gDProject.m_dPcbThick;
		dHeight2 = gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[subTool.nMask] - gDProject.m_dPcbThick2; 
		if(!gDeviceFactory.GetMotor()->MotorMoveXYZDownOnly(dFinalMoveX, dFinalMoveY, dHeight1, dHeight2, b1stPanel, AUTORUN_MOVE, FALSE))
		{
			m_nErrMsgID = STDGNALM438;
			return FALSE;
		}
		dC1 =  gBeamPathINI.m_sBeampath.dBeamPathBetPos1[subTool.nMask];
		dC2 =  gBeamPathINI.m_sBeampath.dBeamPathBetPos2[subTool.nMask];
		dA1 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[subTool.nMask];
		dA2 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[subTool.nMask];
		double dmask1, dmask2, dmask3;
		dmask1 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[subTool.nMask];
		dmask2 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[subTool.nMask];
		dmask3 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[subTool.nMask];

#ifndef __SERVO_MOTOR__
		if(!gDeviceFactory.GetMotor()->MoveMCA2DownOnly(dmask1, dmask2,  dC1, dC2, dA1, dA2, bTophat))		//20111213
#else
		if(!gDeviceFactory.GetMotor()->MoveMCA3DownOnly(dmask1, dmask2, dmask3, dC1, dC2, dA1, dA2))
#endif
		{
			m_nErrMsgID = STDGNALM439;
			return FALSE;
		}

		if(!MoveIO())
		{
			m_nErrMsgID = STDGNALM440;
			return FALSE;
		}

		if(!DownloadOneSubTool(ADDED_FID_TOOL, nSubNo)) 
			return FALSE;
		
		// Laser current Set
		if(!DownloadLaserOneSubTool(ADDED_FID_TOOL, nSubNo))
		{
			m_nErrMsgID = STDGNALM444;
			return FALSE;
		}

		if(!gDeviceFactory.GetEocard()->SetVoltage(gBeamPathINI.m_sBeampath.dBeamPathVoltage1[subTool.nMask], gBeamPathINI.m_sBeampath.dBeamPathVoltage2[subTool.nMask]))
		{
			m_nErrMsgID = STDGNALM117;
			return FALSE;
		}
			
		if(strcmp(m_cDownASC, gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]) != 0)
		{
			CString strMaster, strSlave;
			TCHAR sz1stFile[255], sz2ndFile[255];
			strMaster.Format(_T("%s\\%sM1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
			strSlave.Format(_T("%s\\%sS1.asc"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir(), gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
			lstrcpy(sz1stFile, strMaster);
			lstrcpy(sz2ndFile, strSlave);
			
			BOOL bIsDspBusy = TRUE;
			while(bIsDspBusy)
			{
				bIsDspBusy = gDeviceFactory.GetEocard()->IsDSPBusy();
			}
			if(!gDeviceFactory.GetEocard()->LoadCalibrationFile(sz1stFile, sz2ndFile))
			{
#ifndef __TEST__
				CString strString, strMsg;
				strString.LoadString(IDS_ERR_DOWNLOAD_FILE);
				CString strTemp;
				strTemp.Format(_T("%s or %s"), sz1stFile, sz2ndFile);
				strMsg.Format(strString, strTemp);
				
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMsg));
				m_nErrMsgID = STDGNALM105;
				return FALSE;
#endif
			}
			strcpy_s( m_cDownASC, gBeamPathINI.m_sBeampath.strBeamPathAscFile[subTool.nMask]);
		}
			
		if(!pEocard->ShotDataReset())
		{
			m_nErrMsgID = STDGNALM442;
			return FALSE;
		}
		ChangeShotDrillInfo(ADDED_FID_TOOL);
		if(!pEocard->DownloadShotData2((USHORT)ptMaster.x, (USHORT)ptMaster.y, (USHORT)ptSlave.x, (USHORT)ptSlave.y, TRUE, TRUE, ADDED_FID_TOOL))
		{
			m_nErrMsgID = STDGNALM443;
			return FALSE;
		}

		// skiving 전 dummyshot 시간 충족을 위한 코드 20130419
		if(m_bUseManualDrillDummy)
		{
			double dStartTime;
			double dDummyTime;
			if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
				dDummyTime= gSystemINI.m_sSystemDump.nStandbyTime;
			else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
				dDummyTime = gSystemINI.m_sSystemDump.nStandbyTime2;

			dStartTime = gDeviceFactory.GetEocard()->GetDummyFreeStart();
			if(dDummyTime > dStartTime)
			{
				if(!DoStandby(dDummyTime - dStartTime))
				{
					m_bUseManualDrillDummy = FALSE;
					return FALSE;
				}
			}
			m_bUseManualDrillDummy = FALSE;
		}

		if(!pEocard->FieldPreStart(gSystemINI.m_sSystemDump.nDummyShot))
		{
			m_nErrMsgID = STDGNALM445; // count No error
			strLog.Format(_T("FieldPreStart Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			return FALSE;
		}

		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_M2 + IND_M3 + IND_C2 + IND_A1 + IND_A2))
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
			return FALSE;
		}

		if(!pEocard->FieldStart(gProcessINI.m_sProcessSystem.bDryRun))
		{
			m_nErrMsgID = STDGNALM445; // count No error
			strLog.Format(_T("FieldStart Error"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			return FALSE;
		}
		
		::Sleep(100);
		BOOL bIsDspBusy = TRUE;
		while(bIsDspBusy)
		{
			::Sleep(1);
			if(!CheckStatus())
			{
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					pEocard->EStop();
				return FALSE;
			}
			BOOL bScannerCableError = gDeviceFactory.GetEocard()->IsScannerCableError();
			BOOL bScannerMotorFault = gDeviceFactory.GetEocard()->IsMotorFault();
			BOOL bScannerDrillTimeOut = gDeviceFactory.GetEocard()->IsDrillTimeOut();
			BOOL bTimeOutType = gDeviceFactory.GetEocard()->IsDrillTimeOutType();
			CString strErrorMsg = _T("");
			if(bScannerCableError)
			{
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				m_nErrMsgID = STDGNALM1017;
				m_strErrorPlus = _T("Scanner Cable Error.");
				return FALSE;
			}
			else if(bScannerMotorFault)
			{
				if(bScannerMotorFault & 0x01)
					strErrorMsg += _T("Scanner Master X Motor Fault\r\n");
				if(bScannerMotorFault & 0x02)
					strErrorMsg += _T("Scanner Master Y Motor Fault\r\n");
				if(bScannerMotorFault & 0x04)
					strErrorMsg += _T("Scanner Slave X Motor Fault\r\n");
				if(bScannerMotorFault & 0x08)
					strErrorMsg += _T("Scanner Slave Y Motor Fault\r\n");

				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				m_nErrMsgID = STDGNALM1017;
				m_strErrorPlus = strErrorMsg;
				return FALSE;
			}
			else if(bScannerDrillTimeOut)
			{
				if(bScannerDrillTimeOut & 0x01)
					strErrorMsg += _T("Scanner Master X Drill Time Out\r\n");
				if(bScannerDrillTimeOut & 0x02)
					strErrorMsg += _T("Scanner Master Y Drill Time Out\r\n");
				if(bScannerDrillTimeOut & 0x04)
					strErrorMsg += _T("Scanner Slave X Drill Time Out\r\n");
				if(bScannerDrillTimeOut & 0x08)
					strErrorMsg += _T("Scanner Slave Y Drill Time Out\r\n");

				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				m_nErrMsgID = STDGNALM1017;
				m_strErrorPlus = strErrorMsg;
				return FALSE;
			}
			else if(bTimeOutType)
			{
				if(bTimeOutType & 0x01)
					strErrorMsg += _T("Unknown Time Out\r\n");
				if(bTimeOutType & 0x02)
					strErrorMsg += _T("Drill Time Out\r\n");
				if(bTimeOutType & 0x04)
					strErrorMsg += _T("LPC Time Out\r\n");

				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				m_nErrMsgID = STDGNALM566;
				m_strErrorPlus = strErrorMsg;
				return FALSE;
			}
			bIsDspBusy = pEocard->IsDSPBusy(); 
		}

#ifndef __TEST__
		nEocardHoleCount = pEocard->ReadHoleCount();
		if(nEocardHoleCount != 1) // 1 hole download
		{
			for(int lll = 0; lll < 3; lll++)
			{
				pEocard->IsFireCntOK(nDownShotCnt, nReadShotCnt);
				strLog.Format(_T("EOCard: first : %d - second : %d, UI:%d - FireShots : %d, downShots : %d"), 
				nEocardHoleCount, pEocard->ReadHoleCount(), nSubCount, nReadShotCnt, nDownShotCnt);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				::Sleep(10);
			}
			m_nErrMsgID = STDGNALM603; // count No error
			return FALSE;
		}
#endif
		nSubNo++;
	}
	return TRUE;
}

BOOL CPaneAutoRun::CalFidPosWithFirst2Point(C2DTransform* pTrans, C2DTransform* pTrans2)
{
	LPFIDDATA pFidData;
	CString strFile2, strLog;
	strFile2.Format(_T("CheckTrans"));

	if(m_bCalFidPosWithFirst2Point)
	{
		double dx, dy;
		for(int i = 0; i < gDProject.m_Glyphs.GetFidCount(DEFAULT_FID_INDEX); i++)
		{
			pFidData = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			
			pTrans->TransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dx, dy);
			pFidData->npTransPosition.x = (int)(dx - pFidData->npPosition.x); pFidData->npTransPosition.y = (int)(dy - pFidData->npPosition.y);

			strLog.Format(_T("TransPosition : (%d, %d)"), pFidData->npTransPosition.x, pFidData->npTransPosition.y);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));

			pTrans2->TransformPoint(pFidData->npPosition.x, pFidData->npPosition.y, dx, dy);
			pFidData->npTransPosition2.x = (int)(dx - pFidData->npPosition.x); pFidData->npTransPosition2.y = (int)(dy - pFidData->npPosition.y);

			strLog.Format(_T("TransPosition2 : (%d, %d)"), pFidData->npTransPosition2.x, pFidData->npTransPosition2.y);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile2), reinterpret_cast<LPARAM>(&strLog));
				
		}
		m_bCalFidPosWithFirst2Point = FALSE;
	}
	return TRUE;
}

BOOL CPaneAutoRun::AOMAlarmCheck()
{
	CString strLog;
	if(m_lErrorOthers3New & 0x10000) 
	{
		//	if(m_pMotor->GetAOMTime())
		//	{
		m_nAOMAlarmCnt++;
		
		if(m_nAOMAlarmCnt >= 10) // 5sec
		{
			strLog.Format(_T("[MB5557] AOM Off Alarm"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&m_strPLCAlarmLogFile), reinterpret_cast<LPARAM>(&strLog));
		
			if(!gProcessINI.m_sProcessSystem.bNoUseAOMAlarm && gSystemINI.m_sHardWare.nAOMType != 0)
			{
				if(IsDrilling())
					DrillStop();
				
				((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(FALSE, FALSE, FALSE);
				gDeviceFactory.GetEocard()->LaserOnOff(FALSE);
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				ErrMsgDlg(STDGNALM309); 
				m_nAOMAlarmCnt = 0;
			}
		}
		//	}
		
	}
	else
		m_nAOMAlarmCnt = 0;

	return TRUE;
}

BOOL CPaneAutoRun::WaitPrework()
{
	int nCount = 0;
	do 
	{
		nCount++;
		if(nCount > 100 * 180)//3분
		{
			return FALSE;
		}
		if(!CheckStatus())
			return FALSE;
		Sleep(10);
	} while (m_nPreworkStep != DO_NOTING);
	return TRUE;
}

void CPaneAutoRun::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;
}

void CPaneAutoRun::TurnOffAllLaserDevice()
{
	if(gDeviceFactory.GetLaser()->IsPowerOn() || 
		gDeviceFactory.GetMotor()->GetScannerStatus() ||
		gDeviceFactory.GetMotor()->GetAOMStatus())
	{
		BOOL bIsDspBusy = TRUE;
		while(bIsDspBusy)
		{
			bIsDspBusy = gDeviceFactory.GetEocard()->IsDSPBusy();
		}
		gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE);
		gDeviceFactory.GetLaser()->PowerOn(FALSE);
		gDeviceFactory.GetMotor()->ScannerPower(FALSE);
		gDeviceFactory.GetMotor()->SetAOMPowerON(FALSE);
		::AfxGetMainWnd()->SendMessage(UM_ANY_PREWORK, (WPARAM)(DO_POWER + DO_SCANNER));
		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("AnyDo (TurnOffAllLaserDevice) : P + S"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		ErrMsgDlg(STDGNALM516);
	}
}

BOOL CPaneAutoRun::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	// TODO: Add your message handler code here and/or call default
	return CFormView::OnMouseWheel(nFlags, zDelta, pt);
}

void CPaneAutoRun::SaveFiducialScale(int nUseFidCount, CDPoint* dRefPos, CDPoint* dFindPos, double* dAvgScaleX, double* dAvgScaleY, BOOL* bScaleOK, double dLengthStrechX, double dLengthStrechY, double* dDiagonal, int nBlockNo)
{
	CString strpathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CString strSequenceLog;
	strpathName+=_T("FiducialScale");
	CTime  curDate = CTime::GetCurrentTime();
	CString strLotID;

	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		strcpy_s(gLotInfo.szLotID[0], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[1], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[2], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[3], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[4], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[5], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[6], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[7], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[8], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[9], gDProject.m_szLotId);
	}
	int nIndex = 0, nSecondIndex = 0;
	CString str1;
	nIndex = GetCurrentLotID(str1,str1,str1,str1);

//	strLotID.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), gDProject.m_szLotId);
	strLotID.Format(_T("%s\\%s.txt"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), gLotInfo.szLotID[nIndex]);

	CString strCurTime;
	strCurTime.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	
	strpathName+=strCurTime;
	
	//우선 파일 검사
	BOOL bExist, bExist2;
	CFileFind find;
	bExist = find.FindFile((LPCTSTR)strpathName);
	bExist2 = find.FindFile((LPCTSTR)strLotID);

	CStdioFile file, file2;
	if(FALSE == file.Open(strpathName,CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite))
		return ;
	if(FALSE == file2.Open(strLotID,CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite))
	{
		file.Close();
		return ;
	}
	
	TRY 
	{
		file.SeekToEnd();
		CString strBuf, strTemp;
		CString strOK, strPanel, strMeasure, strPos;
		int i;

		if(!bExist)
		{
			strTemp.Format(_T("  Date , Time , Lot ID , Panel , Status , Scale , Data\n"));
			strBuf+=strTemp;
		}

		file2.SeekToEnd();
		if(!bExist2)
		{
			strTemp.Format(_T("  Date , Time , Lot ID , Panel , Status , Scale , Data\n"));
			file2.Write(strTemp, strTemp.GetLength());
		}

		if(gDProject.m_nSeparation == USE_DUAL || gDProject.m_nSeparation == USE_1ST)
		{
			if(!gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
			{
				if(bScaleOK[0] == TRUE)
					strOK.Format(_T("OK"));
				else
					strOK.Format(_T("NG"));
			}
			else
				strOK.Format(_T("NO USE VISION"));

			strPanel.Format(_T("1st"));

//			strTemp.Format(_T("--------------------------------------------------------------------------\n"));
//			strBuf += strTemp;

			strMeasure.Format(_T("Scale X"));
			strTemp.Format(_T("%04d/%02d/%02d , %02d:%02d:%02d , %s , %s , %s , %s , %.3f\n"),
			curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
			curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
			gLotInfo.szLotID[nIndex - nSecondIndex], strPanel, strOK, strMeasure , dAvgScaleX[0]);

			strBuf+=strTemp;

			strSequenceLog.Format(_T("%s, %s, %s, %.3f"), strPanel , strOK, strMeasure , dAvgScaleX[0]);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));

			file2.Write(strTemp, strTemp.GetLength());

			strMeasure.Format(_T("Scale Y"));
			strTemp.Format(_T("%04d/%02d/%02d , %02d:%02d:%02d , %s , %s , %s , %s , %.3f\n"),
			curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
			curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
			gLotInfo.szLotID[nIndex - nSecondIndex], strPanel , strOK, strMeasure , dAvgScaleY[0]);

			strSequenceLog.Format(_T("%s, %s, %s, %.3f"), strPanel , strOK, strMeasure , dAvgScaleY[0]);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));

			file2.Write(strTemp, strTemp.GetLength());
			strBuf+=strTemp;


			strMeasure.Format(_T("Scale R1"));
			strTemp.Format(_T("%04d/%02d/%02d , %02d:%02d:%02d , %s , %s , %s , %s , %.3f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				gLotInfo.szLotID[nIndex - nSecondIndex], strPanel , strOK, strMeasure , dDiagonal[0]);

			file2.Write(strTemp, strTemp.GetLength());
			strBuf+=strTemp;


			strMeasure.Format(_T("Scale R2"));
			strTemp.Format(_T("%04d/%02d/%02d , %02d:%02d:%02d , %s , %s , %s , %s , %.3f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				gLotInfo.szLotID[nIndex - nSecondIndex], strPanel , strOK, strMeasure , dDiagonal[1]);
				
			file2.Write(strTemp, strTemp.GetLength());
			strBuf+=strTemp;

#ifdef __LG_TYPE_DATA__
			strTemp.Format(_T("%04d/%02d/%02d , %02d:%02d:%02d , %s , %s , %s"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				gLotInfo.szLotID[nIndex - nSecondIndex], strPanel , strOK);

			CString strTolerenceLimit =  _T("");
			strTolerenceLimit.Format(_T("%s, Tolerence Limit , %.3f\n"), strTemp, gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000);
			file2.Write(strTolerenceLimit, strTolerenceLimit.GetLength());
			strBuf += strTolerenceLimit;

			strTolerenceLimit.Format(_T("%s, Calculated Tolerance X , %.3f\n"), strTemp, dLengthStrechX);
			file2.Write(strTolerenceLimit, strTolerenceLimit.GetLength());
			strBuf += strTolerenceLimit;

			strTolerenceLimit.Format(_T("%s, Calculated Tolerance Y , %.3f\n"), strTemp, dLengthStrechY);
			file2.Write(strTolerenceLimit, strTolerenceLimit.GetLength());
			strBuf += strTolerenceLimit;

			strTolerenceLimit.Format(_T("%s, Fiducial Block , %d\n"), strTemp, nBlockNo);
			file2.Write(strTolerenceLimit, strTolerenceLimit.GetLength());
			strBuf += strTolerenceLimit;
#endif

			for(i =0; i< 4 * 2; i++) 
			{
				if(dRefPos[0][i/2].x == DBL_MAX)
					continue;

				if(i%2 == 0)
				{
					strMeasure.Format(_T("Measure %d X"), i/2 + 1);
					strPos.Format(_T("%.3f"), dFindPos[0][i/2].x);
				}
				else
				{
					strMeasure.Format(_T("Measure %d Y"), i/2 + 1);
					strPos.Format(_T("%.3f"), dFindPos[0][i/2].y);
				}
				strTemp.Format(_T("%04d/%02d/%02d , %02d:%02d:%02d , %s , %s , %s , %s , %s\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				gLotInfo.szLotID[nIndex - nSecondIndex], strPanel , strOK, strMeasure , strPos);

				strBuf+=strTemp;
			}

			for(int i = 0; i< 4 * 2; i++) //x,y 
			{
				if(dRefPos[0][i/2].x == DBL_MAX)
					continue;
				
				if(i%2 == 0)
				{
					strMeasure.Format(_T("Command %d X"), i/2+1);
					strPos.Format(_T("%.3f"), dRefPos[0][i/2].x);
				}
				else
				{
					strMeasure.Format(_T("Command %d Y"), i/2+1);
					strPos.Format(_T("%.3f"), dRefPos[0][i/2].y);
				}
				strTemp.Format(_T("%04d/%02d/%02d , %02d:%02d:%02d , %s , %s , %s , %s , %s\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				gLotInfo.szLotID[nIndex - nSecondIndex], strPanel , strOK, strMeasure , strPos);

				strBuf+=strTemp;
			}

		}

		if( (gDProject.m_nSeparation == USE_DUAL && !m_bOdd) || gDProject.m_nSeparation == USE_2ND)
		{
//			strTemp.Format(_T("--------------------------------------------------------------------------\n"));
//			strBuf += strTemp;
			if(!gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
			{
				if(bScaleOK[1] == TRUE)
					strOK.Format(_T("OK"));
				else
					strOK.Format(_T("NG"));
			}
			else
				strOK.Format(_T("NO USE VISION"));
			
			strPanel.Format(_T("2nd"));
			
			strMeasure.Format(_T("Scale X"));
			strTemp.Format(_T("%04d/%02d/%02d , %02d:%02d:%02d , %s , %s , %s , %s , %.3f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				gLotInfo.szLotID[nIndex], strPanel , strOK, strMeasure , dAvgScaleX[1]);
			
			strBuf+=strTemp;

			strSequenceLog.Format(_T("%s, %s, %s, %.3f"), strPanel, strOK, strMeasure , dAvgScaleX[1]);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));

			file2.Write(strTemp, strTemp.GetLength());

			strMeasure.Format(_T("Scale Y"));
			strTemp.Format(_T("%04d/%02d/%02d , %02d:%02d:%02d , %s , %s , %s , %s , %.3f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				gLotInfo.szLotID[nIndex], strPanel , strOK, strMeasure , dAvgScaleY[1]);
			
			strBuf+=strTemp;

			strSequenceLog.Format(_T("%s, %s, %s, %.3f"), strPanel , strOK, strMeasure , dAvgScaleY[1]);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
			file2.Write(strTemp, strTemp.GetLength());

			strMeasure.Format(_T("Scale R1"));
			strTemp.Format(_T("%04d/%02d/%02d , %02d:%02d:%02d , %s , %s , %s , %s , %.3f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				gLotInfo.szLotID[nIndex - nSecondIndex], strPanel , strOK, strMeasure , dDiagonal[2]);

			file2.Write(strTemp, strTemp.GetLength());
			strBuf+=strTemp;


			strMeasure.Format(_T("Scale R2"));
			strTemp.Format(_T("%04d/%02d/%02d , %02d:%02d:%02d , %s , %s , %s , %s , %.3f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				gLotInfo.szLotID[nIndex - nSecondIndex], strPanel , strOK, strMeasure , dDiagonal[3]);

			file2.Write(strTemp, strTemp.GetLength());
			strBuf+=strTemp;

#ifdef __LG_TYPE_DATA__
			strTemp.Format(_T("%04d/%02d/%02d , %02d:%02d:%02d , %s , %s , %s"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				gLotInfo.szLotID[nIndex - nSecondIndex], strPanel , strOK);

			CString strTolerenceLimit =  _T("");
			strTolerenceLimit.Format(_T("%s, Tolerence Limit , %.3f\n"), strTemp, gProcessINI.m_sProcessFidFind.dPCBLenTolerance * 1000);
			file2.Write(strTolerenceLimit, strTolerenceLimit.GetLength());
			strBuf += strTolerenceLimit;

			strTolerenceLimit.Format(_T("%s, Calculated Tolerance X , %.3f\n"), strTemp, dLengthStrechX);
			file2.Write(strTolerenceLimit, strTolerenceLimit.GetLength());
			strBuf += strTolerenceLimit;

			strTolerenceLimit.Format(_T("%s, Calculated Tolerance Y , %.3f\n"), strTemp, dLengthStrechY);
			file2.Write(strTolerenceLimit, strTolerenceLimit.GetLength());
			strBuf += strTolerenceLimit;

			strTolerenceLimit.Format(_T("%s, Fiducial Block , %d\n"), strTemp, nBlockNo);
			file2.Write(strTolerenceLimit, strTolerenceLimit.GetLength());
			strBuf += strTolerenceLimit;
#endif


			for(i =0; i< 4 * 2; i++) 
			{
				if(dRefPos[0][i/2].x == DBL_MAX)
					continue;

				if(i%2 == 0)
				{
					strMeasure.Format(_T("Measure %d X"), i/2+1);
					strPos.Format(_T("%.3f"), dFindPos[4 + i/2].x);
				}
				else
				{
					strMeasure.Format(_T("Measure %d Y"), i/2+1);
					strPos.Format(_T("%.3f"), dFindPos[4 + i/2].y);
				}
				strTemp.Format(_T("%04d/%02d/%02d , %02d:%02d:%02d , %s , %s , %s , %s , %s\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					gLotInfo.szLotID[nIndex], strPanel , strOK, strMeasure , strPos);
				
				strBuf+=strTemp;
			}
			
			for(int i = 0; i< 4 * 2; i++) //x,y 
			{
				if(dRefPos[0][i/2].x == DBL_MAX)
					continue;
				
				if(i%2 == 0)
				{
					strMeasure.Format(_T("Command %d X"), i/2+1);
					strPos.Format(_T("%.3f"), dRefPos[4 + i/2].x);
				}
				else
				{
					strMeasure.Format(_T("Command %d Y"), i/2+1);
					strPos.Format(_T("%.3f"), dRefPos[4 + i/2].y);
				}
				strTemp.Format(_T("%04d/%02d/%02d , %02d:%02d:%02d , %s , %s , %s , %s , %s\n"),
					curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
					curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
					gLotInfo.szLotID[nIndex], strPanel , strOK, strMeasure , strPos);
				
				strBuf+=strTemp;
			}

		}

		
		file.Write(strBuf, strBuf.GetLength());
	}
	CATCH (CMemoryException, e)
	{
		file.Close();
		file2.Close();
		e->Delete();
		return;
	}
	END_CATCH
		
	file.Close();
	file2.Close();
}

LRESULT CPaneAutoRun::SaveVisionImg(WPARAM wParam, LPARAM lParam)
{
	CString strFile, strFile2;
	CTime cTime = CTime::GetCurrentTime();
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		strcpy_s(gLotInfo.szLotID[0], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[1], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[2], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[3], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[4], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[5], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[6], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[7], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[8], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[9], gDProject.m_szLotId);
	}
	CString str;
	int nIndex = 0;
	nIndex = GetCurrentLotID(str, str, str, str);

	int nBlockNo = m_nFidBlockForFidShowAll, nSubFidIndex = m_nFidIndexForFidShowAll;
	if(m_nFidIndexForFidShowAll == -1)
	{
		nSubFidIndex = 999;
	}
	
	if(wParam == LOW_1ST_CAM || wParam == HIGH_1ST_CAM)
	{
		strFile.Format(_T("%s%s_1st_%s_%d_%d_%d_%d_%d.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), cTime.Format(_T("%Y%m%d%H%M%S")), gLotInfo.szLotID[nIndex],  m_nCurrentLotIndex,  m_nCurrentLotCount, lParam, nBlockNo, nSubFidIndex);
		strFile2.Format(_T("%sBackup\\%s_1st_%s_%d_%d_%d_%d_%d.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), cTime.Format(_T("%Y%m%d%H%M%S")), gLotInfo.szLotID[nIndex],  m_nCurrentLotIndex,  m_nCurrentLotCount, lParam, nBlockNo, nSubFidIndex);
	}
	else if(wParam == LOW_2ND_CAM || wParam == HIGH_2ND_CAM)
	{
		strFile.Format(_T("%s%s_2nd_%s_%d_%d_%d_%d_%d.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), cTime.Format(_T("%Y%m%d%H%M%S")), gLotInfo.szLotID[nIndex],  m_nCurrentLotIndex,  m_nCurrentLotCount, lParam, nBlockNo, nSubFidIndex);
		strFile2.Format(_T("%sBackup\\%s_2nd_%s_%d_%d_%d_%d_%d.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), cTime.Format(_T("%Y%m%d%H%M%S")), gLotInfo.szLotID[nIndex],  m_nCurrentLotIndex,  m_nCurrentLotCount, lParam,  nBlockNo, nSubFidIndex);
	}
	else if(wParam == LOW_1ST_CAM + 10 || wParam == HIGH_1ST_CAM + 10 ||
		wParam == LOW_2ND_CAM +10 || wParam == HIGH_2ND_CAM + 10) //+10 = After Fire 실패시 저장되도록 
	{
		if(lParam == 1)
		{
			strFile.Format(_T("%s%s_1st_%s_%d_%d_AfterFiducialError.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), cTime.Format(_T("%Y%m%d%H%M%S")), gLotInfo.szLotID[nIndex],  m_nCurrentLotIndex, m_nCurrentLotCount);
			strFile2.Format(_T("%sBackup\\%s_1st_%s_%d_%d_AfterFiducialError.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), cTime.Format(_T("%Y%m%d%H%M%S")), gLotInfo.szLotID[nIndex],  m_nCurrentLotIndex,  m_nCurrentLotCount);
		}
		else
		{
			strFile.Format(_T("%s%s_2nd_%s_%d_%d_AfterFiducialError.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), cTime.Format(_T("%Y%m%d%H%M%S")), gLotInfo.szLotID[nIndex],  m_nCurrentLotIndex,  m_nCurrentLotCount);
			strFile2.Format(_T("%sBackup\\%s_2nd_%s_%d_%d_AfterFiducialError.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), cTime.Format(_T("%Y%m%d%H%M%S")), gLotInfo.szLotID[nIndex],  m_nCurrentLotIndex,  m_nCurrentLotCount);
		}
		nSubFidIndex = 999;
		wParam -= 10;
	}
	else if(wParam == LOW_1ST_CAM + 20 || wParam == HIGH_1ST_CAM + 20 ||
		wParam == LOW_2ND_CAM +20 || wParam == HIGH_2ND_CAM + 20) //+20 = pre after find hole 
	{
		if(lParam == 1)
		{
			strFile.Format(_T("%s%s_1st_%s_%d_%d_HoleError.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), cTime.Format(_T("%Y%m%d%H%M%S")), gLotInfo.szLotID[nIndex],  m_nCurrentLotIndex,  m_nCurrentLotCount);
			strFile2.Format(_T("%sBackup\\%s_1st_%s_%d_%d_HoleError.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), cTime.Format(_T("%Y%m%d%H%M%S")), gLotInfo.szLotID[nIndex],  m_nCurrentLotIndex,  m_nCurrentLotCount);
		}
		else
		{
			strFile.Format(_T("%s%s_2nd_%s_%d_%d_HoleError.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), cTime.Format(_T("%Y%m%d%H%M%S")), gLotInfo.szLotID[nIndex],  m_nCurrentLotIndex,  m_nCurrentLotCount);
			strFile2.Format(_T("%sBackup\\%s_2nd_%s_%d_%d_HoleError.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), cTime.Format(_T("%Y%m%d%H%M%S")), gLotInfo.szLotID[nIndex],  m_nCurrentLotIndex,  m_nCurrentLotCount);
		}
		nSubFidIndex = 999;
		wParam -= 20;
	}
	
	CRect rtPos;
	if(!gSystemINI.m_sHardWare.bUseWideMonitor)
		rtPos = m_pFiducial->GetVisionWindowRect();
	else
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_dlgSideVision.GetDlgSize(rtPos);

	HDC h_screen_dc = ::GetDC(NULL);
	// 현재 스크린의 해상도를 얻는다.
	int width = rtPos.Width();//::GetDeviceCaps(h_screen_dc, HORZRES);
	int height = rtPos.Height();//::GetDeviceCaps(h_screen_dc, VERTRES);
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
#ifndef __TEST__
		HRESULT				hr=s_OK;
		IPictureDisp		*pPictureDisp;
		IPicture			*pPicture;
		LPSTREAM			lpStream=NULL;
		LPTSTR				pszString=NULL;
		long				pcbSize=0;
		ULONG				ulSizeRequired=0;
		int					i=0;

		if(gVPro.m_pDisplay[wParam] == NULL)
			return 0;
		gVPro.m_pDisplay[wParam]->CreateContentBitmap(cogDisplayContentBitmapImage, NULL, NULL, &pPictureDisp);
		if(pPictureDisp == NULL)
			return 0;
		pPictureDisp->QueryInterface(&pPicture);
		if(pPicture == NULL)
			return 0;

		CreateStreamOnHGlobal(NULL, TRUE, &lpStream);
		StreamStringCopy((LPSTREAM)lpStream, (LPCTSTR)"");

		hr = pPicture->SaveAsFile(lpStream, TRUE, &pcbSize);


		StreamStringRead((LPSTREAM)lpStream, (LPTSTR)NULL, (ULONG*)&ulSizeRequired);

		HBITMAP h_bitmap = 0;
		HBITMAP h_bitmapCopy = 0;
		pPicture->get_Handle((unsigned int*)&h_bitmap);

		if(nSubFidIndex != 999)
		{
			h_bitmapCopy = (HBITMAP)CopyImage(h_bitmap, IMAGE_BITMAP, 0, 0, LR_COPYRETURNORG);
			if(wParam == LOW_1ST_CAM || wParam == HIGH_1ST_CAM)
				((CEasyDrillerDlg*)GetParent())->SetBitMap(h_bitmapCopy, TRUE, nSubFidIndex, m_nFidBlockForFidShowAll);// 20130404 bhlee
			else if(wParam == LOW_2ND_CAM || wParam == HIGH_2ND_CAM)
				((CEasyDrillerDlg*)GetParent())->SetBitMap(h_bitmapCopy, FALSE, nSubFidIndex, m_nFidBlockForFidShowAll);
		}

		pszString = (LPTSTR)malloc(ulSizeRequired + sizeof(char));
		if (pszString && gProcessINI.m_sProcessSystem.bUseSaveFidImage)
		{ 
			StreamStringRead((LPSTREAM)lpStream, (LPTSTR)pszString, (ULONG*)NULL);

			CFile file;
			if (file.Open(strFile, CFile::modeCreate|CFile::modeWrite))
			{
				file.Write(pszString, ulSizeRequired);      
				file.Close();
			}
		}
		free(pszString);
		lpStream->Release();
		pszString = NULL;
		  
		::DeleteObject(h_bitmap);
#endif
#endif
	}
	else
	{
		// DIB의 형식을 정의한다.
		BITMAPINFO dib_define;
		dib_define.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		dib_define.bmiHeader.biWidth = width;
		dib_define.bmiHeader.biHeight = height;
		dib_define.bmiHeader.biPlanes = 1;
		dib_define.bmiHeader.biBitCount = 24;
		dib_define.bmiHeader.biCompression = BI_RGB;
		dib_define.bmiHeader.biSizeImage = (((width * 24 + 31) & ~31) >> 3) * height;
		dib_define.bmiHeader.biXPelsPerMeter = 0;
		dib_define.bmiHeader.biYPelsPerMeter = 0;
		dib_define.bmiHeader.biClrImportant = 0;
		dib_define.bmiHeader.biClrUsed = 0;

		// DIB의 내부 이미지 비트 패턴을 참조할 포인터 변수
		BYTE *p_image_data = NULL;

		// dib_define에 정의된 내용으로 DIB를 생성한다.
		HBITMAP h_bitmap = ::CreateDIBSection(h_screen_dc, &dib_define, DIB_RGB_COLORS, (void **)&p_image_data, 0, 0);

		// 이미지 추출하기 위해서 가상 DC 생성. 메인 DC에서는 직접적으로 비트맵에 접근하여
		// 이미지 패턴을 얻을 수 없기 때문이다.
		HDC h_memory_dc = ::CreateCompatibleDC(h_screen_dc);

		// 가상 DC에 이미지를 추출할 비트맵을 연결한다.
		HBITMAP h_old_bitmap = (HBITMAP)::SelectObject(h_memory_dc, h_bitmap);

		// 현재 스크린 화면을 캡쳐한다.
		::BitBlt(h_memory_dc, 0, 0, width, height, h_screen_dc, rtPos.left, rtPos.top, SRCCOPY);

		// 본래의 비트맵으로 복구한다.
		::SelectObject(h_memory_dc, h_old_bitmap);

		// 가상 DC를 제거한다.
		DeleteDC(h_memory_dc);

		// DIB 파일의 헤더 내용을 구성한다.
		BITMAPFILEHEADER dib_format_layout;
		ZeroMemory(&dib_format_layout, sizeof(BITMAPFILEHEADER));
		dib_format_layout.bfType = *(WORD*)"BM";
		dib_format_layout.bfSize = sizeof(BITMAPFILEHEADER) + 
			sizeof(BITMAPINFOHEADER) + dib_define.bmiHeader.biSizeImage;
		dib_format_layout.bfOffBits = sizeof(BITMAPFILEHEADER) +
			sizeof(BITMAPINFOHEADER);

		if(wParam == LOW_1ST_CAM || wParam == HIGH_1ST_CAM)
			((CEasyDrillerDlg*)GetParent())->SetBitMap(h_bitmap, TRUE, m_nFidIndexForFidShowAll, m_nFidBlockForFidShowAll);// 20130404 bhlee
		else if(wParam == LOW_2ND_CAM || wParam == HIGH_2ND_CAM)
			((CEasyDrillerDlg*)GetParent())->SetBitMap(h_bitmap, FALSE, m_nFidIndexForFidShowAll, m_nFidBlockForFidShowAll);
		//현재 디렉토리에서 한 순위를 내려간후 [data]\\save\\ 폴더에 저장
		CString directory;


		// DIB 파일을 생성한다.

		if(gProcessINI.m_sProcessSystem.bUseSaveFidImage)
		{
			FILE *p_file;
			errno_t err = fopen_s(&p_file, strFile, "wb");
			if(err == NULL){
				fwrite(&dib_format_layout, 1, sizeof(BITMAPFILEHEADER), p_file);
				fwrite(&dib_define, 1, sizeof(BITMAPINFOHEADER), p_file);
				fwrite(p_image_data, 1, dib_define.bmiHeader.biSizeImage, p_file);
				fclose(p_file);
			}
		}

		if(!(wParam == LOW_1ST_CAM || wParam == HIGH_1ST_CAM || wParam == LOW_2ND_CAM || wParam == HIGH_2ND_CAM))// 20130404 bhlee
		{
			if(NULL != h_bitmap) DeleteObject(h_bitmap);
		}

		if(NULL != h_screen_dc) ::ReleaseDC(NULL, h_screen_dc);
	}

	// back up
	if(gProcessINI.m_sProcessSystem.bUseSaveFidImage)
	{
		HVision* pVision = gDeviceFactory.GetVision();
		pVision->SaveImg( wParam, strFile2 );
	}

	return 1;
}

LRESULT CPaneAutoRun::SaveVisionFailImg(WPARAM wParam, LPARAM lParam)
{
	CString strFile;
	CTime cTime = CTime::GetCurrentTime();
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		strcpy_s(gLotInfo.szLotID[0], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[1], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[2], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[3], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[4], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[5], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[6], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[7], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[8], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[9], gDProject.m_szLotId);
	}
	CString str;
	int nIndex = 0;
	nIndex = GetCurrentLotID(str, str, str, str);

	if(wParam == LOW_1ST_CAM || wParam == HIGH_1ST_CAM)
	{
		strFile.Format(_T("%sFail\\%s_1st_%s_%d_%d_%d.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), cTime.Format(_T("%Y%m%d%H%M%S")), gLotInfo.szLotID[nIndex],  m_nCurrentLotIndex,  m_nCurrentLotCount, lParam);
	}
	else if(wParam == LOW_2ND_CAM || wParam == HIGH_2ND_CAM)
	{
		strFile.Format(_T("%sFail\\%s_2nd_%s_%d_%d_%d.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), cTime.Format(_T("%Y%m%d%H%M%S")), gLotInfo.szLotID[nIndex],  m_nCurrentLotIndex,  m_nCurrentLotCount, lParam);
	}

	CRect rtPos;
	if(!gSystemINI.m_sHardWare.bUseWideMonitor)
		rtPos = m_pFiducial->GetVisionWindowRect();
	else
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_dlgSideVision.GetDlgSize(rtPos);

	HDC h_screen_dc = ::GetDC(NULL);
	// 현재 스크린의 해상도를 얻는다.
	int width = rtPos.Width();//::GetDeviceCaps(h_screen_dc, HORZRES);
	int height = rtPos.Height();//::GetDeviceCaps(h_screen_dc, VERTRES);
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO)
	{
#ifdef USE_VISION_PRO
#ifndef __TEST__
		HRESULT				hr=s_OK;
		IPictureDisp		*pPictureDisp;
		IPicture			*pPicture;
		LPSTREAM			lpStream=NULL;
		LPTSTR				pszString=NULL;
		long				pcbSize=0;
		ULONG				ulSizeRequired=0;
		int					i=0;

		if(gVPro.m_pDisplay[wParam] == NULL)
			return 0;
		gVPro.m_pDisplay[wParam]->CreateContentBitmap(cogDisplayContentBitmapImage, NULL, NULL, &pPictureDisp);
		if(pPictureDisp == NULL)
			return 0;
		pPictureDisp->QueryInterface(&pPicture);
		if(pPicture == NULL)
			return 0;

		CreateStreamOnHGlobal(NULL, TRUE, &lpStream);
		StreamStringCopy((LPSTREAM)lpStream, (LPCTSTR)"");

		hr = pPicture->SaveAsFile(lpStream, TRUE, &pcbSize);


		StreamStringRead((LPSTREAM)lpStream, (LPTSTR)NULL, (ULONG*)&ulSizeRequired);

		HBITMAP h_bitmap = 0;
		HBITMAP h_bitmapCopy = 0;
		pPicture->get_Handle((unsigned int*)&h_bitmap);

		h_bitmapCopy = (HBITMAP)CopyImage(h_bitmap, IMAGE_BITMAP, 0, 0, LR_COPYRETURNORG);
		if(wParam == LOW_1ST_CAM || wParam == HIGH_1ST_CAM)
			((CEasyDrillerDlg*)GetParent())->SetBitMap(h_bitmapCopy, TRUE, m_nFidIndexForFidShowAll, m_nFidBlockForFidShowAll);// 20130404 bhlee
		else if(wParam == LOW_2ND_CAM || wParam == HIGH_2ND_CAM)
			((CEasyDrillerDlg*)GetParent())->SetBitMap(h_bitmapCopy, FALSE, m_nFidIndexForFidShowAll, m_nFidBlockForFidShowAll);

		pszString = (LPTSTR)malloc(ulSizeRequired + sizeof(char));
		if (pszString && gProcessINI.m_sProcessSystem.bUseSaveFidImage)
		{
			StreamStringRead((LPSTREAM)lpStream, (LPTSTR)pszString, (ULONG*)NULL);

			CFile file;
			if (file.Open(strFile, CFile::modeCreate|CFile::modeWrite))
			{
				file.Write(pszString, ulSizeRequired);      
				file.Close();
			}
		}
		free(pszString);
		lpStream->Release();
		pszString = NULL;
		
		::DeleteObject(h_bitmap);
#endif
#endif
	}
	else
	{
		// DIB의 형식을 정의한다.
		BITMAPINFO dib_define;
		dib_define.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		dib_define.bmiHeader.biWidth = width;
		dib_define.bmiHeader.biHeight = height;
		dib_define.bmiHeader.biPlanes = 1;
		dib_define.bmiHeader.biBitCount = 24;
		dib_define.bmiHeader.biCompression = BI_RGB;
		dib_define.bmiHeader.biSizeImage = (((width * 24 + 31) & ~31) >> 3) * height;
		dib_define.bmiHeader.biXPelsPerMeter = 0;
		dib_define.bmiHeader.biYPelsPerMeter = 0;
		dib_define.bmiHeader.biClrImportant = 0;
		dib_define.bmiHeader.biClrUsed = 0;

		// DIB의 내부 이미지 비트 패턴을 참조할 포인터 변수
		BYTE *p_image_data = NULL;

		// dib_define에 정의된 내용으로 DIB를 생성한다.
		HBITMAP h_bitmap = ::CreateDIBSection(h_screen_dc, &dib_define, DIB_RGB_COLORS, (void **)&p_image_data, 0, 0);

		// 이미지 추출하기 위해서 가상 DC 생성. 메인 DC에서는 직접적으로 비트맵에 접근하여
		// 이미지 패턴을 얻을 수 없기 때문이다.
		HDC h_memory_dc = ::CreateCompatibleDC(h_screen_dc);

		// 가상 DC에 이미지를 추출할 비트맵을 연결한다.
		HBITMAP h_old_bitmap = (HBITMAP)::SelectObject(h_memory_dc, h_bitmap);

		// 현재 스크린 화면을 캡쳐한다.
		::BitBlt(h_memory_dc, 0, 0, width, height, h_screen_dc, rtPos.left, rtPos.top, SRCCOPY);

		// 본래의 비트맵으로 복구한다.
		::SelectObject(h_memory_dc, h_old_bitmap);

		// 가상 DC를 제거한다.
		DeleteDC(h_memory_dc);

		// DIB 파일의 헤더 내용을 구성한다.
		BITMAPFILEHEADER dib_format_layout;
		ZeroMemory(&dib_format_layout, sizeof(BITMAPFILEHEADER));
		dib_format_layout.bfType = *(WORD*)"BM";
		dib_format_layout.bfSize = sizeof(BITMAPFILEHEADER) + 
			sizeof(BITMAPINFOHEADER) + dib_define.bmiHeader.biSizeImage;
		dib_format_layout.bfOffBits = sizeof(BITMAPFILEHEADER) +
			sizeof(BITMAPINFOHEADER);

		if(wParam == LOW_1ST_CAM || wParam == HIGH_1ST_CAM)
			((CEasyDrillerDlg*)GetParent())->SetBitMap(h_bitmap, TRUE, m_nFidIndexForFidShowAll, m_nFidBlockForFidShowAll);// 20130404 bhlee
		else if(wParam == LOW_2ND_CAM || wParam == HIGH_2ND_CAM)
			((CEasyDrillerDlg*)GetParent())->SetBitMap(h_bitmap, FALSE, m_nFidIndexForFidShowAll, m_nFidBlockForFidShowAll);
		//현재 디렉토리에서 한 순위를 내려간후 [data]\\save\\ 폴더에 저장
		CString directory;


		// DIB 파일을 생성한다.

		if(gProcessINI.m_sProcessSystem.bUseSaveFidImage)
		{
			FILE *p_file;
			errno_t err = fopen_s(&p_file, strFile, "wb");
			if(err == NULL){
				fwrite(&dib_format_layout, 1, sizeof(BITMAPFILEHEADER), p_file);
				fwrite(&dib_define, 1, sizeof(BITMAPINFOHEADER), p_file);
				fwrite(p_image_data, 1, dib_define.bmiHeader.biSizeImage, p_file);
				fclose(p_file);
			}
		}

		if(!(wParam == LOW_1ST_CAM || wParam == HIGH_1ST_CAM || wParam == LOW_2ND_CAM || wParam == HIGH_2ND_CAM))// 20130404 bhlee
		{
			if(NULL != h_bitmap) DeleteObject(h_bitmap);
		}

		if(NULL != h_screen_dc) ::ReleaseDC(NULL, h_screen_dc);
	}

	return 1;
}

void CPaneAutoRun::MoveScaleLog()
{
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		strcpy_s(gLotInfo.szLotID[0], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[1], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[2], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[3], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[4], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[5], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[6], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[7], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[8], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[9], gDProject.m_szLotId);
	}
	
	CString strLotID, strMovePath;
	for(int i = 0; i < MAX_LOTID_CNT; i++)
	{
		strLotID.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), gLotInfo.szLotID[i]);
		
		//우선 파일 검사
		BOOL bExist;
		CFileFind find;
		bExist = find.FindFile((LPCTSTR)strLotID);
		if(bExist)
		{
			strMovePath.Format(_T("%s%s.txt"), gEasyDrillerINI.m_clsDirPath.GetScaleLogDir(), gLotInfo.szLotID[i]);
			CopyFile(strLotID, strMovePath, FALSE);
		}
	}

	// delete file
	CFileFind finder;
    int Index = 180;    // 기간을 정해 줌
	
    CString strFile, strTempFilePath;
    CTime nowTime, Createtime;     
	
	nowTime = CTime::GetCurrentTime();
	// 현재 날짜에서 Index 날짜 만큼 빼줌
	nowTime = nowTime - CTimeSpan(7, 0, 0, 0);
	
	strTempFilePath.Format(_T("%s*.txt"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());
    BOOL bFind = finder.FindFile(strTempFilePath);  // 현재 찾고자 하는 파일의 폴더 이름...
	
    while(bFind)
    {
        bFind = finder.FindNextFile();
        if(finder.IsDots())
            continue;
		else
		{
			strFile = finder.GetFileName();
			// 파일 생성 시간을 가져옴
			finder.GetLastWriteTime(Createtime);
			
			// 지금 시간보다 Index 날짜 이전 파일은 모두 삭제
			if(nowTime >= Createtime)
			{
				CString strTemp;
				strTemp.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir(), strFile);
				::DeleteFile(strTemp);
			}			
		}
    }
    finder.Close();
}

void CPaneAutoRun::SaveFiducialImg(int nCamNo, int nFidNo)
{
	if(gProcessINI.m_sProcessSystem.bUseSaveFidImage)
	{
		if(!gSystemINI.m_sHardWare.bUseWideMonitor)
			::AfxGetMainWnd()->SendMessage(UM_CHANGE_VIEW, VIEW_FIDUCIAL, TRUE);

		this->SendMessage(UM_VISION_SAVE, nCamNo, nFidNo);
	}
	else if(gProcessINI.m_sProcessSystem.bShowAllFidImage)
	{
		if(!gSystemINI.m_sHardWare.bUseWideMonitor)
			::AfxGetMainWnd()->SendMessage(UM_CHANGE_VIEW, VIEW_FIDUCIAL, TRUE);
		
		this->SendMessage(UM_VISION_SAVE, nCamNo, nFidNo);
	}
	return;
}

void CPaneAutoRun::SaveFailFiducialImg(int nCamNo, int nFidNo)
{
	if(!gSystemINI.m_sHardWare.bUseWideMonitor)
		::AfxGetMainWnd()->SendMessage(UM_CHANGE_VIEW, VIEW_FIDUCIAL, TRUE);

	this->SendMessage(UM_VISION_SAVE_FAIL, nCamNo, nFidNo);
	
	return;
}

void CPaneAutoRun::RemoveOldFidImage()
{
	CFileFind finder;
    int Index = gProcessINI.m_sProcessFidFind.nFidImgSaveData;    // 기간을 정해 줌
	
    CString strFile, strTempFilePath, strFile2;
    CTime nowTime, Createtime;     
	
	nowTime = CTime::GetCurrentTime();
	// 현재 날짜에서 Index 날짜 만큼 빼줌
	nowTime = nowTime - CTimeSpan(Index, 0, 0, 0); // 90일
	CString strFolder;
	strFolder = nowTime.Format(_T("%Y%m%d"));
	int nRefTime = atoi(strFolder);
	int nTimeFolder;
	
	strTempFilePath.Format(_T("%s*"), gEasyDrillerINI.m_clsDirPath.GetImageDir());
    BOOL bFind = finder.FindFile(strTempFilePath);  // 현재 찾고자 하는 파일의 폴더 이름...
	
    while(bFind)
    {
        bFind = finder.FindNextFile();
        if(finder.IsDots() || !finder.IsDirectory())
            continue;
		else
		{
			strFile = finder.GetFileName();
			if(strFile.CompareNoCase("Backup") == 0)
				continue;

			nTimeFolder = atoi(strFile);
			// 지금 시간보다 Index 날짜 이전 파일은 모두 삭제
			if(nRefTime > nTimeFolder)
			{
				CFileFind finder2;
				strTempFilePath.Format(_T("%s\\*"), finder.GetFilePath());
				BOOL bFind2 = finder2.FindFile(strTempFilePath);  // 현재 찾고자 하는 파일의 폴더 이름...
				
				while(bFind2)
				{
					bFind2 = finder2.FindNextFile();
					if(finder2.IsDots())
						continue;
					else
					{
						::DeleteFile(finder2.GetFilePath());
					}
				}
				finder2.Close();

				CString strTemp;
				strTemp.Format(_T("%s"), finder.GetFilePath());
				_rmdir( strTemp );
			}			
		}
    }
    finder.Close();

	strTempFilePath.Format(_T("%sbackup\\*"), gEasyDrillerINI.m_clsDirPath.GetImageDir());
    bFind = finder.FindFile(strTempFilePath);  // 현재 찾고자 하는 파일의 폴더 이름...
	
    while(bFind)
    {
        bFind = finder.FindNextFile();
        if(finder.IsDots() || !finder.IsDirectory())
            continue;
		else
		{
			strFile = finder.GetFileName();
			nTimeFolder = atoi(strFile);
			
			// 지금 시간보다 Index 날짜 이전 파일은 모두 삭제
			if(nRefTime > nTimeFolder)
			{
				CFileFind finder2;
				strTempFilePath.Format(_T("%s\\*"), finder.GetFilePath());
				BOOL bFind2 = finder2.FindFile(strTempFilePath);  // 현재 찾고자 하는 파일의 폴더 이름...
				
				while(bFind2)
				{
					bFind2 = finder2.FindNextFile();
					if(finder2.IsDots())
						continue;
					else
					{
						::DeleteFile(finder2.GetFilePath());
					}
				}
				finder2.Close();
				
				CString strTemp;
				strTemp.Format(_T("%s"), finder.GetFilePath());
				_rmdir( strTemp );
			}			
		}
    }
    finder.Close();
}

void CPaneAutoRun::GetBeamPathLaserInfo(SUBTOOLDATA &subTool)
{
	subTool.nFrequency = gBeamPathINI.m_sBeampath.nPowCompensationFrequency[subTool.nMask];
	subTool.dShotDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationDuty[subTool.nMask];
	subTool.dShotAOMDelay[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[subTool.nMask];
	subTool.dShotAOMDuty[0] = gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[subTool.nMask];

	subTool.dMinPower = gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[subTool.nMask];
	subTool.dMaxPower = gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[subTool.nMask];
}

void CPaneAutoRun::SaveJobTimeLog(int nStartYear, int nStartMonth, int nStartDay, int nStartHour, int nStartMin, int nStartSec, 
								  int nEndYear, int nEndMonth, int nEndDay, int nEndHour, int nEndMin, int nEndSec,
								  int ndiff, int nJobType)
{
	CString strpathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	strpathName+=_T("JobTime");
	CTime  curDate = CTime::GetCurrentTime();
	CString strCurTime;
	strCurTime.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	
	strpathName+=strCurTime;
	
	//우선 파일 검사
	CStdioFile file;
	if(FALSE == file.Open(strpathName,CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite))
		return ;
	
	TRY 
	{
		file.SeekToEnd();
		CString strBuf, strType;
		if(nJobType == PREHEAT_JOB)
			strType.Format(_T("H"));
		else if(nJobType == SCAL_JOB)
			strType.Format(_T("S"));
		else if(nJobType == POWER_JOB)
			strType.Format(_T("P"));
		else
			strType.Format(_T("D"));

		strBuf.Format(_T("%s, %04d/%02d/%02d , %02d:%02d:%02d , %04d/%02d/%02d , %02d:%02d:%02d, %d \n"),
			strType,
			nStartYear, nStartMonth, nStartDay, nStartHour, nStartMin, nStartSec, 
			nEndYear, nEndMonth, nEndDay, nEndHour, nEndMin, nEndSec,
			ndiff);
		
		
		file.Write(strBuf, strBuf.GetLength());
	}
	CATCH (CMemoryException, e)
	{
		file.Close();
		e->Delete();
		return;
	}
	END_CATCH
		
	file.Close();

	// copy
	CString strFileName, strMovePath;
	strFileName.Format(_T("JobTime%02d%02d"),curDate.GetYear(), curDate.GetMonth());

#ifdef  __KUNSAN_6__
	strMovePath.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetScaleLogDir(), strFileName);
	CopyFile(strpathName, strMovePath, FALSE);
#elif defined   __KUNSAN_8__
	strMovePath.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetScaleLogDir(), strFileName);
	CopyFile(strpathName, strMovePath, FALSE);
#elif defined   __KUNSAN_1__
	strMovePath.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetScaleLogDir(), strFileName);
	CopyFile(strpathName, strMovePath, FALSE);
#elif defined   __KUNSAN_2012__
	strMovePath.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetScaleLogDir(), strFileName);
	CopyFile(strpathName, strMovePath, FALSE);
#elif defined   __KUNSAN_2013__
	strMovePath.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetScaleLogDir(), strFileName);
	CopyFile(strpathName, strMovePath, FALSE);
#else
	strMovePath.Format(_T("%s%d\\%s"), gEasyDrillerINI.m_clsDirPath.GetNetworkDir(), gSystemINI.m_sHardWare.nMachineNo, strFileName);
	CopyFile(strpathName, strMovePath, FALSE);
#endif
	
}

void CPaneAutoRun::ResetScannerErrorCnt()
{
	for(int i = 0; i < 4; i++)
	{
		m_nWarningNo[i] = m_nAlarmNo[i] = m_nMaxValue[i] = m_nInposMissNo[i] = 0;
	}
	gDeviceFactory.GetEocard()->ResetScannerPosErrorCount();
}

void CPaneAutoRun::WriteDrillParam()
{
	SUBTOOLDATA toolData;
	CString strTotal, strTemp;
	strTotal.Format(_T("TOOL Data Info |"));
	int nCount = 0;
	BOOL bSave = FALSE;
	
	for(int i = 0; i<MAX_TOOL_NO; i++)
	{
		if(!gDProject.m_pToolCode[i]->m_bUseTool)
			continue;

		bSave = TRUE;

		strTemp.Format(_T("Tool %d, UseToolOrder=%d, CheckPower=%d, MarkSize=%d |") , i, 
						gDProject.m_pToolCode[i]->m_bToolOrder, gDProject.m_pToolCode[i]->m_bPreworkPower, gDProject.m_pToolCode[i]->m_nMarkingSize);
		strTotal += strTemp;
		POSITION pos = gDProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		while(pos)
		{
			toolData = gDProject.m_pToolCode[i]->m_SubToolData.GetNext(pos);

			if(toolData.nToolType == MARKING_TYPE)
				strTemp.Format(_T("Marking, "));
			else if(toolData.nToolType == SHOT_DRILL_TYPE)
				strTemp.Format(_T("ShotDrill, "));
			else if(toolData.nToolType == LINE_DRILL_TYPE)
				strTemp.Format(_T("LineDrill, "));
			else if(toolData.nToolType == FLYING_TYPE)
				strTemp.Format(_T("Flying, "));
			else if(toolData.nToolType == TEXT_TYPE)
				strTemp.Format(_T("Text, "));
			else 
				strTemp.Format(_T("Barcode, "));
			strTotal += strTemp;

			strTemp.Format(_T("FRQ=%d, BurstNo=%d, Method=%d, BeamPath=%d, DS=%.1f, JS=%.1f, CD=%d, JD=%d, LD=%d, LOnD=%d, LOffD=%d |"),
				toolData.nFrequency, toolData.nBurstShot , toolData.nShotMode, toolData.nMask,
				toolData.dDrawStep, gSystemINI.m_sSystemDevice.dJumpSpeed, 
				gSystemINI.m_sSystemDevice.nCornerDelay, gSystemINI.m_sSystemDevice.nJumpDelay, gSystemINI.m_sSystemDevice.nLineDelay,
				toolData.nLaserOnDelay, toolData.nLaserOffDelay);
			strTotal += strTemp;
			strTemp.Format(_T("ZOffset=%.3f, MinPower=%.2f, MaxPower=%.2f |"), toolData.dZOffset, toolData.dMinPower, toolData.dMaxPower);
			strTotal += strTemp;

			for(int j = 0; j < toolData.nTotalShot; j++)
			{
#ifdef __3RDAOD__
				strTemp.Format(_T("\tDuty=%.1f, Freq=%.1f |"),
					toolData.dShotDuty[j], toolData.dShotMaxFreq[j]);
				strTotal += strTemp;
#else
				strTemp.Format(_T("\tDuty=%.1f, AOMDelay=%.1f, AOMDuty=%.1f |"),
					toolData.dShotDuty[j], toolData.dShotAOMDelay[j], toolData.dShotAOMDuty[j]);
				strTotal += strTemp;
#endif
			}
		}
		strTemp.Format(_T("--|"));
		strTotal += strTemp;
	}

	if(bSave)
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strTotal));
}

int CPaneAutoRun::GetCurrentLotID(CString &strLotID1, CString &strLotID2, CString &strPrj1, CString &strPrj2)
{
/*	int nIndex = 0;
	int nLotTotalCnt[MAX_LOTID_CNT];
	for(int i = 0; i < MAX_LOTID_CNT; i++)
	{
		if(i == 0)
			nLotTotalCnt[i] = gLotInfo.nLotCount[i];
		else
			nLotTotalCnt[i] = nLotTotalCnt[i-1] + gLotInfo.nLotCount[i];
	}
	
	for(int i = 0; i < MAX_LOTID_CNT; i++)
	{
		if(m_nCurrentLotCount + 1 <= nLotTotalCnt[i] - m_nNGLotCount || i == MAX_LOTID_CNT - 1)
		{
			nIndex = i;
			break;
		}
	}
*/
	int nIndex = 0;
	int nTotalLotCount = 0;
	for(int i = 0; i < MAX_LOTID_CNT; i++)
	{
		nTotalLotCount += gLotInfo.nLotCount[i];
		if(m_nTotalCurrentLotCount < nTotalLotCount)
		{
			nIndex = i;
			break;
		}
	}

	strLotID1.Format(_T("%s"), gLotInfo.szLotID[nIndex]); //current
	strLotID2.Format(_T("%s"), gLotInfo.szLotID[nIndex]);
	strPrj1.Format(_T("%s"), gLotInfo.szPrj[nIndex]);
	strPrj2.Format(_T("%s"), gLotInfo.szPrj[nIndex]);
	return nIndex;
}

BOOL CPaneAutoRun::AutoOpenProject(BOOL bCompare)
{
#ifndef __KUNSAN_SAMSUNG_LARGE__ // 쿤산삼성은 항상 스케쥴다이얼로그를 이요함 
	if(!m_bAutoRun)
	{
		if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->GetFileOpen())
			return FALSE;

		return TRUE;
	}

	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
		return TRUE;
#endif
	CString strLot1, strLot2, strPrj1, strPrj2, strMessage;
	int nIndex;
	nIndex = GetCurrentLotID(strLot1, strLot2, strPrj1, strPrj2);
	
	if(nIndex >= gLotInfo.nLastIndex)
	{
		return FALSE;
	}
	memset(&m_szCurrentLotID, 0, sizeof(m_szCurrentLotID));
	strcpy_s(m_szCurrentLotID, (LPCTSTR)strLot1);
	
	if(m_nCurrentPrjIndex == nIndex && bCompare)
		return TRUE;

	if(m_nCurrentPrjIndex != nIndex)
	{
		m_nCurrentMarkingCount = 0;
		m_dAvgMarkingTime = 0.0;
	}
	
	//열려있던것과 현재 가공중인 프로젝트 비교
	if(strcmp(gDProject.m_szProjectName, strPrj1) == 0)
	{
		m_nCurrentPrjIndex = nIndex;
		return TRUE;
	}
	//project 변경 전에 로그 저장 
	if(bCompare)
		WriteLotLog();

	((CEasyDrillerDlg*)GetParent())->SetFileOpen(FALSE);
	
	((CEasyDrillerDlg*)GetParent())->SetPrjName( strPrj1 );
	if(FALSE == ((CEasyDrillerDlg*)GetParent())->OpenProject(strPrj1))
	{	
		m_nCurrentPrjIndex = nIndex;
		m_nErrMsgID = STDGNALM113;
		return FALSE; // error 로그 기록 남기고 종료한다 -> 추후 추가
	}
	
	::AfxGetMainWnd()->SendMessage(UM_CHANGE_DATAFILE, TRUE);
	
	strcpy_s(gDProject.m_szProjectName, strPrj1);
	
	strMessage.Format(_T("Auto Project ( %s )이 오픈 되었습니다."), strPrj1);
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), NULL);
	
	((CEasyDrillerDlg*)GetParent())->SetFileOpen(TRUE);

	SetPreworkInfo();
	
	m_nCurrentPrjIndex = nIndex;
	gLotInfo.nStatus[nIndex] = STATUS_PROGRESS;
	UpdateOPCDisplay();
	ChangeProjectInfo(TRUE);
	m_nAutoLotCount = 0;
	m_nTotalHoleCount = 0;
	m_nTotalLineCount = 0;
	m_ctStart = CTime::GetCurrentTime();
	return TRUE;
}

void CPaneAutoRun::ChangeLotIDInfo()
{
/*	m_listLotID.DeleteAllItems();
	CString strCont;
	
	if(!gProcessINI.m_sProcessSystem.bUseScheduling)
	{
		//		CString strPrj = ((CEasyDrillerDlg*)GetParent())->GetPrjName();
		strcpy_s(gLotInfo.szLotID[0], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[1], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[2], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[3], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[4], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[5], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[6], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[7], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[8], gDProject.m_szLotId);
		strcpy_s(gLotInfo.szLotID[9], gDProject.m_szLotId);
	}
	
	LVITEM lvItem;
	lvItem.mask = LVIF_TEXT|LVIF_PARAM;
	lvItem.lParam = 1;
	lvItem.state = 0;
	//	lvItem.stateMask = LVIS_SELECTED;
	int nCount = 0;
	int nCurCount = m_nCurrentLotCount, nLotCnt;
	
	for(int i = 0; i< MAX_LOTID_CNT; i++)
	{
		if(gLotInfo.nLotCount[i] <= 0)
			continue;
		
		nCurCount = nCurCount - gLotInfo.nLotCount[i];
		
		//Lot ID
		lvItem.iItem = nCount;
		lvItem.iSubItem = 0;
		strCont.Format(_T("%s"), gLotInfo.szLotID[i]);
		lvItem.pszText = (LPSTR)(LPCSTR)strCont;
		m_listLotID.InsertItem(&lvItem);
		
		//Input Count
		lvItem.iItem = nCount;
		lvItem.iSubItem = 1;
		strCont.Format(_T("%d"), gLotInfo.nLotCount[i]);
		m_listLotID.SetItemText(nCount, 1, (LPSTR)(LPCSTR)strCont);
		
		if(nCurCount <= 0) // 현재 작업 lot
		{
			nLotCnt = nCurCount + gLotInfo.nLotCount[i];
			if(nLotCnt >= 0)// 현재 작업 lot
			{
				strCont.Format(_T("%d"), nLotCnt);
			}
			else
				strCont.Format(_T("-"));
		}
		else
			strCont.Format(_T("%d"), gLotInfo.nLotCount[i]);
		// current status
		lvItem.iItem = nCount;
		lvItem.iSubItem = 1;
		m_listLotID.SetItemText(nCount, 2, (LPSTR)(LPCSTR)strCont);
		nCount++;
	}
*/
}

void CPaneAutoRun::ChangeDP()
{
	if(m_bShowTimeDP)
	{
		GetDlgItem(IDC_STATIC_WORKING_TIME)->SetWindowText(_T("Lot ID"));
		GetDlgItem(IDC_LIST_BOARD_LOTID)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_CURRENT_ONE_CYCLE_TIME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_ONE_CYCLE_RUNNING_TIME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_PROGRESS_RUNNING_TIME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_TOTAL_REMAIN_TIME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_REMAIN_TIME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_PROGRESS_RUNNING_TIME2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AVERAGE_ONE_CYCLE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AVERAGE_ONE_CYCLE_TIME)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BUTTON_CLEAR)->ShowWindow(SW_HIDE);
	}
	else
	{
		GetDlgItem(IDC_STATIC_WORKING_TIME)->SetWindowText(_T("Working Time"));
		GetDlgItem(IDC_LIST_BOARD_LOTID)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_CURRENT_ONE_CYCLE_TIME)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_ONE_CYCLE_RUNNING_TIME)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_PROGRESS_RUNNING_TIME)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_TOTAL_REMAIN_TIME)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_REMAIN_TIME)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_PROGRESS_RUNNING_TIME2)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_AVERAGE_ONE_CYCLE)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_AVERAGE_ONE_CYCLE_TIME)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BUTTON_CLEAR)->ShowWindow(SW_SHOW);
	}
	m_bShowTimeDP = !m_bShowTimeDP;
}

void CPaneAutoRun::OnButtonChangeDp() 
{
	// TODO: Add your control notification handler code here
	ChangeDP();
#ifdef __KUNSAN_SAMSUNG_LARGE__
	m_pOPC->InsertList();
#endif
}

void CPaneAutoRun::ChangeBMPtoJPG()
{
	CProgressWnd wndProgress(NULL, _T("Image Save"), TRUE);
	wndProgress.GoModal();
	wndProgress.SetRange(0, 0);
	wndProgress.SetText(_T("Image Save"));
	// delete file
	CFileFind finder;
    int Index = 180;    // 기간을 정해 줌
	imgdes * pImgDes = new imgdes;
	
    CString strFile, strTempFilePath;
	CString strLoadFile, strFolder, strSaveFile;
    CTime Createtime;     
	strTempFilePath.Format(_T("%s*.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir());
    BOOL bFind = finder.FindFile(strTempFilePath);  // 현재 찾고자 하는 파일의 폴더 이름...
	
    while(bFind)
    {
        bFind = finder.FindNextFile();
        if(finder.IsDots())
            continue;
		else
		{
			strFile = finder.GetFileName();
			// 파일 생성 시간을 가져옴
			finder.GetLastWriteTime(Createtime);
			strFolder.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), Createtime.Format(_T("%Y%m%d")));
			// Folder 생성
			if( 0 != _chdir( (LPSTR)(LPCTSTR)strFolder ) )
			{
				if( 0 != _mkdir( (LPSTR)(LPCTSTR)strFolder ))
				{
					continue;
				}
			}
			
			// 지금 시간보다 Index 날짜 이전 파일은 모두 삭제
			strLoadFile.Format(_T("%s%s"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), strFile);
			strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
			// image save
			
			BITMAPINFOHEADER bdat; // Reserve space for struct
			int rcode;
			BOOL bSaveOK = FALSE;
			
			if((rcode = bmpinfo(strLoadFile, &bdat)) == NO_ERROR) 
			{
				int bitcount = bdat.biBitCount;
				if(bitcount >= 16) // Load a 16-, 24-, or 32-bit file into a 24-bit buffer
					bitcount = 24;
				rcode = allocimage(pImgDes, (int)bdat.biWidth, (int)bdat.biHeight, bitcount);
				if(rcode==NO_ERROR)
				{
					// Load the image file
					rcode = loadbmp(strLoadFile, pImgDes);
					if(rcode==NO_ERROR)
					{	
						strSaveFile.Replace("bmp", "jpg");
						rcode = savejpg(strSaveFile, pImgDes, 255);// int qual);
						if(rcode==NO_ERROR)
						{
							bSaveOK = TRUE;
							::DeleteFile(strLoadFile);
						}
						else
							strSaveFile.Replace("jpg", "bmp");
					}
				}
				freeimage(pImgDes);
			}
			if(!bSaveOK)
			{
				CopyFile(strLoadFile, strSaveFile, FALSE);
			}
			
			//
			
		}
    }
    finder.Close();

	wndProgress.SetText(_T("Image Backup"));
	// back up
	strTempFilePath.Format(_T("%sbackup\\*.bmp"), gEasyDrillerINI.m_clsDirPath.GetImageDir());
    bFind = finder.FindFile(strTempFilePath);  // 현재 찾고자 하는 파일의 폴더 이름...
	
    while(bFind)
    {
        bFind = finder.FindNextFile();
        if(finder.IsDots())
            continue;
		else
		{
			strFile = finder.GetFileName();
			// 파일 생성 시간을 가져옴
			finder.GetLastWriteTime(Createtime);
			strFolder.Format(_T("%sbackup\\%s"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), Createtime.Format(_T("%Y%m%d")));
			// Folder 생성
			if( 0 != _chdir( (LPSTR)(LPCTSTR)strFolder ) )
			{
				if( 0 != _mkdir( (LPSTR)(LPCTSTR)strFolder ))
				{
					continue;
				}
			}
			
			// 지금 시간보다 Index 날짜 이전 파일은 모두 삭제
			strLoadFile.Format(_T("%sbackup\\%s"), gEasyDrillerINI.m_clsDirPath.GetImageDir(), strFile);
			strSaveFile.Format(_T("%s\\%s"), strFolder, strFile);
			// image save
			
			BITMAPINFOHEADER bdat; // Reserve space for struct
			int rcode;
			BOOL bSaveOK = FALSE;
			
			if((rcode = bmpinfo(strLoadFile, &bdat)) == NO_ERROR) 
			{
				int bitcount = bdat.biBitCount;
				if(bitcount >= 16) // Load a 16-, 24-, or 32-bit file into a 24-bit buffer
					bitcount = 24;
				rcode = allocimage(pImgDes, (int)bdat.biWidth, (int)bdat.biHeight, bitcount);
				if(rcode==NO_ERROR)
				{
					// Load the image file
					rcode = loadbmp(strLoadFile, pImgDes);
					if(rcode==NO_ERROR)
					{	
						strSaveFile.Replace("bmp", "jpg");
						rcode = savejpg(strSaveFile, pImgDes, 255);// int qual);
						if(rcode==NO_ERROR)
						{
							bSaveOK = TRUE;
							::DeleteFile(strLoadFile);
						}
						else
							strSaveFile.Replace("jpg", "bmp");
					}
				}
				freeimage(pImgDes);
			}
			if(!bSaveOK)
			{
				CopyFile(strLoadFile, strSaveFile, FALSE);
			}
			
			//
			
		}
    }
    finder.Close();
	
	delete pImgDes;
	wndProgress.SetParentWinActive();
}

void CPaneAutoRun::SaveSCalResult()
{
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	strPathName += _T("SCalLog");
	CTime curDate = CTime::GetCurrentTime();
	
	CString strCurTime;
	strCurTime.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	strPathName += strCurTime;
	
	CStdioFile file;
	if (FALSE == file.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;
	
	int nSelHead = gDProject.m_nSeparation;
	int nDivision = GetDivision();
	
	CString strBuf;
	CString strCam, strPanel, strOP;
	if(gBeamPathINI.m_sBeampath.nScannerVisionCam[m_nDoASCTool] % 2 == 0)
		strCam.Format(_T("High"));
	else
		strCam.Format(_T("Low"));
	strOP.Format(_T("Prework"));
	
	TRY
	{
		file.SeekToEnd();
		
		if(nSelHead == USE_DUAL)
		{
			strPanel.Format(_T("Dual-1st"));
			strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f | %.3f | %d | %.2f | %.2f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				strPanel, strOP, strCam, nDivision, m_dMaxOffsetMasterX * 1000, m_dMaxOffsetMasterY * 1000,
				m_nDoASCTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
			file.Write(strBuf, strBuf.GetLength());
			
			strPanel.Format(_T("Dual-2nd"));
			strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f | %.3f | %d | %.2f | %.2f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				strPanel, strOP, strCam, nDivision, m_dMaxOffsetSlaveX * 1000, m_dMaxOffsetSlaveY * 1000,
				m_nDoASCTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
			file.Write(strBuf, strBuf.GetLength());
		}
		else if(nSelHead == SEL_HEAD_MASTER)
		{
			strPanel.Format(_T("1st"));
			strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f | %d | %.2f | %.2f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				strPanel, strOP, strCam, nDivision, m_dMaxOffsetMasterX * 1000, m_dMaxOffsetMasterY * 1000,
				m_nDoASCTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
			file.Write(strBuf, strBuf.GetLength());
		}
		else if(nSelHead == SEL_HEAD_SLAVE)
		{
			strPanel.Format(_T("2nd"));
			strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %s | %d | %.3f| %.3f | %d | %.2f | %.2f\n"),
				curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
				curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
				strPanel, strOP, strCam, nDivision, m_dMaxOffsetSlaveX * 1000, m_dMaxOffsetSlaveY * 1000,
				m_nDoASCTool, gProcessINI.m_sProcessFidFind.dAcceptScore, gProcessINI.m_sProcessFidFind.dAcceptEdgeScore);
			file.Write(strBuf, strBuf.GetLength());
		}
		CString strEvent;
		strEvent = _T("Saved prework automatic scanner calibration.");
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strEvent), reinterpret_cast<LPARAM>(&strBuf));
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH
		file.Close();
	
}


void CPaneAutoRun::FindNearAreaFiducial(int nToolNo, int nAreaIndex[])
{
	//6 7 8 
	//5 4 3 
	//0 1 2  순서로 저장 

	int nAddProperty = FID_FIND;
	int nDelProperty = FID_VERIFY;
	int nFidBlock; // 여러블럭일 경우 -1부터 시작하나?
	LPFIDDATA pFidData;
	POSITION posArea;
	DAreaInfo *pAreaInfo;
	CDPoint dFidLB, dFidMB, dFidRB, dFIdLM, dFidMM, dFidRM, dFidLT, dFidMT, dFidRT; 
	double dDistLB = 999999, dDistMB = 999999, dDistRB = 999999;
	double dDistLM = 999999, dDistMM = 999999, dDistRM = 999999;
	double dDistLT = 999999, dDistMT = 999999, dDistRT = 999999;
	double dFidMinX = 999999, dFidMaxX = -999999, dFidMinY = 999999, dFidMaxY = -999999;
	double dX, dY, dDistance;

	if(gDProject.m_bMultiFidAscentOrder)
		nFidBlock = 0;
	else
		nFidBlock = -1; 

	//cal area pos 
	int nFidCount = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, nAddProperty, nDelProperty, nFidBlock );
	
	for(int i = 0; i< nFidCount; i++) 
	{
		pFidData = gDProject.m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, i, nAddProperty, nDelProperty, nFidBlock);

		if(pFidData->npPosition.x > dFidMaxX)
			dFidMaxX = (double)pFidData->npPosition.x;

		if(pFidData->npPosition.x < dFidMinX)
			dFidMinX = (double)pFidData->npPosition.x;
		
		if(pFidData->npPosition.y > dFidMaxY)
			dFidMaxY = (double)pFidData->npPosition.y;

		if(pFidData->npPosition.y < dFidMinY)
			dFidMinY = (double)pFidData->npPosition.y;
		
	}
	dFidLB.x = dFidMinX;							dFidLB.y = dFidMinY;
	dFidMB.x = dFidMinX + (dFidMaxX - dFidMinX)/2;	dFidMB.y = dFidMinY;
	dFidRB.x = dFidMaxX;							dFidRB.y = dFidMinY;
	dFIdLM.x = dFidMinX;							dFIdLM.y = dFidMinY + (dFidMaxY - dFidMinY)/2.;
	dFidMM.x = dFidMinX + (dFidMaxX - dFidMinX)/2;	dFidMM.y = dFidMinY + (dFidMaxY - dFidMinY)/2.;
	dFidRM.x = dFidMaxX;							dFidRM.y = dFidMinY + (dFidMaxY - dFidMinY)/2.; 
	dFidLT.x = dFidMinX;							dFidLT.y = dFidMaxY;
	dFidMT.x = dFidMinX + (dFidMaxX - dFidMinX)/2;	dFidMT.y = dFidMaxY;
	dFidRT.x = dFidMaxX;							dFidRT.y = dFidMaxY;

	//check area 
	posArea = gDProject.m_Areas[nToolNo].GetHeadPosition();
	while (posArea) 
	{
		if(!CheckStatus())
			return;

		pAreaInfo = gDProject.m_Areas[nToolNo].GetNext(posArea);

		if(pAreaInfo->m_nFidBlock != nFidBlock && nFidBlock != -1)
			continue;

		if(!IsAvailableArea(pAreaInfo, nToolNo, nFidBlock))
			continue;

		//LB
		dX = pAreaInfo->m_nCenterX - dFidLB.x;
		dY = pAreaInfo->m_nCenterY - dFidLB.y;
		dDistance = sqrt((dX * dX) + (dY * dY));

		if(dDistLB > dDistance)
		{
			dDistLB = dDistance;
			if(gProcessINI.m_sProcessFidFind.bHoleFindAreaPos[0])
				nAreaIndex[0] = pAreaInfo->m_nSortIndex ;
		}

		//MB
		dX = pAreaInfo->m_nCenterX - dFidMB.x;
		dY = pAreaInfo->m_nCenterY - dFidMB.y;
		dDistance = sqrt((dX * dX) + (dY * dY));

		if(dDistMB > dDistance)
		{
			dDistMB = dDistance;
			if(gProcessINI.m_sProcessFidFind.bHoleFindAreaPos[1])
				nAreaIndex[1] = pAreaInfo->m_nSortIndex;
		}

		//MB
		dX = pAreaInfo->m_nCenterX - dFidRB.x;
		dY = pAreaInfo->m_nCenterY - dFidRB.y;
		dDistance = sqrt((dX * dX) + (dY * dY));

		if(dDistRB > dDistance)
		{
			dDistRB = dDistance;
			if(gProcessINI.m_sProcessFidFind.bHoleFindAreaPos[2])
				nAreaIndex[2] = pAreaInfo->m_nSortIndex;
		}

		//LM
		dX = pAreaInfo->m_nCenterX - dFIdLM.x;
		dY = pAreaInfo->m_nCenterY - dFIdLM.y;
		dDistance = sqrt((dX * dX) + (dY * dY));

		if(dDistLM > dDistance)
		{
			dDistLM = dDistance;
			if(gProcessINI.m_sProcessFidFind.bHoleFindAreaPos[5])
				nAreaIndex[5] =pAreaInfo->m_nSortIndex;
		}

		//MM
		dX = pAreaInfo->m_nCenterX - dFidMM.x;
		dY = pAreaInfo->m_nCenterY - dFidMM.y;
		dDistance = sqrt((dX * dX) + (dY * dY));

		if(dDistMM > dDistance)
		{
			dDistMM = dDistance;
			if(gProcessINI.m_sProcessFidFind.bHoleFindAreaPos[4])
				nAreaIndex[4] = pAreaInfo->m_nSortIndex;
		}

		//RM
		dX = pAreaInfo->m_nCenterX - dFidRM.x;
		dY = pAreaInfo->m_nCenterY - dFidRM.y;
		dDistance = sqrt((dX * dX) + (dY * dY));

		if(dDistRM > dDistance)
		{
			dDistRM = dDistance;
			if(gProcessINI.m_sProcessFidFind.bHoleFindAreaPos[3])
				nAreaIndex[3] = pAreaInfo->m_nSortIndex;
		}

		//LT
		dX = pAreaInfo->m_nCenterX - dFidLT.x;
		dY = pAreaInfo->m_nCenterY - dFidLT.y;
		dDistance = sqrt((dX * dX) + (dY * dY));

		if(dDistLT > dDistance)
		{
			dDistLT = dDistance;
			if(gProcessINI.m_sProcessFidFind.bHoleFindAreaPos[6])
				nAreaIndex[6] = pAreaInfo->m_nSortIndex;
		}

		//MT
		dX = pAreaInfo->m_nCenterX - dFidMT.x;
		dY = pAreaInfo->m_nCenterY - dFidMT.y;
		dDistance = sqrt((dX * dX) + (dY * dY));

		if(dDistMT > dDistance)
		{
			dDistMT = dDistance;
			if(gProcessINI.m_sProcessFidFind.bHoleFindAreaPos[7])
				nAreaIndex[7] = pAreaInfo->m_nSortIndex;
		}

		//RT
		dX = pAreaInfo->m_nCenterX - dFidRT.x;
		dY = pAreaInfo->m_nCenterY - dFidRT.y;
		dDistance = sqrt((dX * dX) + (dY * dY));

		if(dDistRT > dDistance)
		{
			dDistRT = dDistance;
			if(gProcessINI.m_sProcessFidFind.bHoleFindAreaPos[8])
				nAreaIndex[8] =pAreaInfo->m_nSortIndex;
		}
	}

	for(int i = 8; i > 0; i--)
	{
		for(int j = 0; j < i; j++)
		{
			if(nAreaIndex[j] == nAreaIndex[i])
			{
				nAreaIndex[i] = -1;
				break;
			}
		}
	}
}

BOOL CPaneAutoRun::FindArea(int nTool, int nUseBeamPath, int nAreaIndex[])
{
	double dModelX, dModelY;
	int nROISize, nROIAllow = 0;
	dModelX = dModelY = gBeamPathINI.m_sBeampath.dHoleVisionModelSize[nUseBeamPath];//gDProject.m_Glyphs.m_HoleFindData.sVisInfo.dSizeA;//
	nROISize = (int)(dModelX * 1000 * 2);

	BOOL bHighV = gBeamPathINI.m_sBeampath.nHoleVisionCam[nUseBeamPath];

	for(int k = 0 ; k < 4; k++)
	{	
		if(bHighV == HIGH_1ST_CAM)
		{
#ifdef __PUSAN_LDD__
			this->SendMessage(UM_VISION_ROI_SET_UM, -1, HIGH_1ST_CAM);
#else
			this->SendMessage(UM_VISION_ROI_SET_UM, nROISize, HIGH_1ST_CAM);
#endif
		}
		else
		{
#ifdef __PUSAN_LDD__
			this->SendMessage(UM_VISION_ROI_SET_UM, -1, LOW_1ST_CAM);
#else
			this->SendMessage(UM_VISION_ROI_SET_UM, nROISize, LOW_1ST_CAM);
#endif
		}
	}

	if(!CheckStatus())
		return FALSE;

	int nAreaCount =0, nAtArea = 0;
	POSITION AreaPos;
	DAreaInfo *pAreaInfo;
	BOOL bCurrentArea = FALSE;
	int i = 0;
	for(i = 0; i< 9; i++)
	{
		if(!gProcessINI.m_sProcessFidFind.bHoleFindAreaPos[i])
			continue;

		AreaPos = gDProject.m_Areas[nTool].GetHeadPosition();
		
		while(AreaPos)
		{
			pAreaInfo = gDProject.m_Areas[nTool].GetNext(AreaPos);

			if(pAreaInfo->m_nSortIndex == nAreaIndex[i])
			{
				bCurrentArea = TRUE;
				break;
				
			}
		}

		if(bCurrentArea)
		{
			m_nHoleAreaIndex[i] = pAreaInfo->m_nSortIndex;

			FindNearHole(nTool,i, pAreaInfo);
			for(int k = 0; k<9; k++)
			{
				if(!CheckStatus())
					return FALSE;

				if(gProcessINI.m_sProcessFidFind.bHoleFindHolePos[k])
				{
					if(m_cpHolePos[i][k][0].x == 0 && m_cpHolePos[i][k][0].y == 0 
					&& m_cpHolePos[i][k][1].x == 0 && m_cpHolePos[i][k][1].y == 0)
						return FALSE;

					if(!FindOneHole(nTool, nUseBeamPath, pAreaInfo, i, k,
						m_cpHolePos[i][k][0].x, m_cpHolePos[i][k][0].y, 
						m_cpHolePos[i][k][1].x, m_cpHolePos[i][k][1].y))
						return FALSE;
					
				}
			}
			bCurrentArea = FALSE;
			nAreaCount++;
		}
	}

	if(i == 9 && nAreaCount == 0)
		return FALSE;

	return TRUE;
}
void CPaneAutoRun::FindNearHole(int nTool,int nAtArea, DAreaInfo *pAreaInfo)
{
	double dDistLB = 999999, dDistMB = 999999, dDistRB = 999999;
	double dDistLM = 999999, dDistMM = 999999, dDistRM = 999999;
	double dDistLT = 999999, dDistMT = 999999, dDistRT = 999999;
	double dMinX = pAreaInfo->m_nMinX;
	double dMaxX = pAreaInfo->m_nMaxX;
	double dMinY = pAreaInfo->m_nMinY;
	double dMaxY = pAreaInfo->m_nMaxY;
	DPOINT dLB, dMB, dRB, dLM, dMM, dRM, dLT, dMT, dRT;
	double dX, dY, dDistance;

	dLB.x = dMinX;						dLB.y = dMinY;
	dMB.x = dMinX + (dMaxX - dMinX)/2;	dMB.y = dMinY;
	dRB.x = dMaxX;						dRB.y = dMinY;
	dLM.x = dMinX;						dLM.y = dMinY + (dMaxY - dMinY)/2;
	dMM.x = dMinX + (dMaxX - dMinX)/2;	dMM.y = dMinY + (dMaxY - dMinY)/2;
	dRM.x = dMaxX;						dRM.y = dMinY + (dMaxY - dMinY)/2; 
	dLT.x = dMinX;						dLT.y = dMaxY;
	dMT.x = dMinX + (dMaxX - dMinX)/2;	dMT.y = dMaxY;
	dRT.x = dMaxX;						dRT.y = dMaxY;

	POSITION HolePos;
	LPFIREHOLE pHole;
	HolePos = pAreaInfo->m_FireHoles[nTool].GetHeadPosition();
	while(HolePos)//if(HolePos != NULL)
	{
		if(!CheckStatus())
			return;

		pHole = pAreaInfo->m_FireHoles[nTool].GetNext(HolePos);	
		if((pHole->bSelect && m_bSelectFire) || (!m_bSelectFire && !m_bAutoRun) || m_bAutoRun)
		{
			//LB
			dX = pHole->pOrigin->npPos.x - dLB.x;
			dY = pHole->pOrigin->npPos.y - dLB.y;
			dDistance = sqrt((dX * dX) + (dY * dY)) / 1000.;

			if(dDistLB >= dDistance)
			{
				dDistLB = dDistance;
				m_cpHolePos[nAtArea][0][0].x = pHole->npPos1.x;
				m_cpHolePos[nAtArea][0][0].y = pHole->npPos1.y;
				m_cpHolePos[nAtArea][0][1].x = pHole->npPos2.x;
				m_cpHolePos[nAtArea][0][1].y = pHole->npPos2.y;
			}

			//MB
			dX = pHole->pOrigin->npPos.x - dMB.x;
			dY =  pHole->pOrigin->npPos.y - dMB.y;
			dDistance = sqrt((dX * dX) + (dY * dY)) / 1000.;

			if(dDistMB >= dDistance)
			{
				dDistMB = dDistance;
				m_cpHolePos[nAtArea][1][0].x = pHole->npPos1.x;
				m_cpHolePos[nAtArea][1][0].y = pHole->npPos1.y;
				m_cpHolePos[nAtArea][1][1].x = pHole->npPos2.x;
				m_cpHolePos[nAtArea][1][1].y = pHole->npPos2.y;
			}

			//RB
			dX = pHole->pOrigin->npPos.x - dRB.x;
			dY = pHole->pOrigin->npPos.y - dRB.y;
			dDistance = sqrt((dX * dX) + (dY * dY)) / 1000.;

			if(dDistRB >= dDistance)
			{
				dDistRB = dDistance;
				m_cpHolePos[nAtArea][2][0].x = pHole->npPos1.x;
				m_cpHolePos[nAtArea][2][0].y = pHole->npPos1.y;
				m_cpHolePos[nAtArea][2][1].x = pHole->npPos2.x;
				m_cpHolePos[nAtArea][2][1].y = pHole->npPos2.y;
			}
			

			//LM
			dX = pHole->pOrigin->npPos.x - dLM.x;
			dY = pHole->pOrigin->npPos.y - dLM.y;
			dDistance = sqrt((dX * dX) + (dY * dY)) / 1000.;

			if(dDistLM >= dDistance)
			{
				dDistLM = dDistance;
				m_cpHolePos[nAtArea][5][0].x = pHole->npPos1.x;
				m_cpHolePos[nAtArea][5][0].y = pHole->npPos1.y;
				m_cpHolePos[nAtArea][5][1].x = pHole->npPos2.x;
				m_cpHolePos[nAtArea][5][1].y = pHole->npPos2.y;
			}

			//MM
			dX = pHole->pOrigin->npPos.x - dMM.x;
			dY = pHole->pOrigin->npPos.y - dMM.y;
			dDistance = sqrt((dX * dX) + (dY * dY)) / 1000.;

			if(dDistMM >= dDistance)
			{
				dDistMM = dDistance;
				m_cpHolePos[nAtArea][4][0].x = pHole->npPos1.x;
				m_cpHolePos[nAtArea][4][0].y = pHole->npPos1.y;
				m_cpHolePos[nAtArea][4][1].x = pHole->npPos2.x;
				m_cpHolePos[nAtArea][4][1].y = pHole->npPos2.y;
			}

			//RM
			dX = pHole->pOrigin->npPos.x - dRM.x;
			dY = pHole->pOrigin->npPos.y - dRM.y;
			dDistance = sqrt((dX * dX) + (dY * dY)) / 1000.;

			if(dDistRM >= dDistance)
			{
				dDistRM = dDistance;
				m_cpHolePos[nAtArea][3][0].x = pHole->npPos1.x;
				m_cpHolePos[nAtArea][3][0].y = pHole->npPos1.y;
				m_cpHolePos[nAtArea][3][1].x = pHole->npPos2.x;
				m_cpHolePos[nAtArea][3][1].y = pHole->npPos2.y;
			}

			//LT
			dX = pHole->pOrigin->npPos.x - dLT.x;
			dY = pHole->pOrigin->npPos.y - dLT.y;
			dDistance = sqrt((dX * dX) + (dY * dY)) / 1000.;

			if(dDistLT >= dDistance)
			{
				dDistLT = dDistance;
				m_cpHolePos[nAtArea][6][0].x = pHole->npPos1.x;
				m_cpHolePos[nAtArea][6][0].y = pHole->npPos1.y;
				m_cpHolePos[nAtArea][6][1].x = pHole->npPos2.x;
				m_cpHolePos[nAtArea][6][1].y = pHole->npPos2.y;
			}

			//MT
			dX = pHole->pOrigin->npPos.x - dMT.x;
			dY = pHole->pOrigin->npPos.y - dMT.y;
			dDistance = sqrt((dX * dX) + (dY * dY)) / 1000.;

			if(dDistMT >= dDistance)
			{
				dDistMT = dDistance;
				m_cpHolePos[nAtArea][7][0].x = pHole->npPos1.x;
				m_cpHolePos[nAtArea][7][0].y = pHole->npPos1.y;
				m_cpHolePos[nAtArea][7][1].x = pHole->npPos2.x;
				m_cpHolePos[nAtArea][7][1].y = pHole->npPos2.y;
			}

			//RT
			dX = pHole->pOrigin->npPos.x - dRT.x;
			dY = pHole->pOrigin->npPos.y - dRT.y;
			dDistance = sqrt((dX * dX) + (dY * dY)) / 1000.;

			if(dDistRT >= dDistance)
			{
				dDistRT = dDistance;
				m_cpHolePos[nAtArea][8][0].x = pHole->npPos1.x;
				m_cpHolePos[nAtArea][8][0].y = pHole->npPos1.y;
				m_cpHolePos[nAtArea][8][1].x = pHole->npPos2.x;
				m_cpHolePos[nAtArea][8][1].y = pHole->npPos2.y;
			}
		}
	}
}
BOOL CPaneAutoRun::FindOneHole(int nTool, int nUseBeamPath, DAreaInfo* pAreaInfo, int nAreaIndex, int nHoleIndex, int nMasterX, int nMasterY, int nSlaveX, int nSlaveY)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	HVision* pVision = gDeviceFactory.GetVision();

	double dPanelOffsetX, dPanelOffsetY;
	double dMoveX, dMoveY, dMoveZ;
	double dLaserOffsetX, dLaserOffsetY;
	double dHeadOffsetX, dHeadOffsetY;
	double dSlaveOffsetX = 0, dSlaveOffsetY = 0;
	int nLimit;
	int nFidBlock;

	if(gDProject.m_bMultiFidAscentOrder)
		nFidBlock = 0;
	else
		nFidBlock = -1; 
	
	BOOL b1stPanel = TRUE;
	BOOL bLowCam = gBeamPathINI.m_sBeampath.nHoleVisionCam[nUseBeamPath] % 2; //gDProject.m_Glyphs.m_HoleFindData.nCam; //

	int nRepeat = 1, nCam;
	if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
		nRepeat = 2;

	if(gDProject.m_nHoleFind == PRE_FIND)
		nLimit = gProcessINI.m_sProcessFidFind.nHolePreLimit;
	else if(gDProject.m_nHoleFind == POST_FIND)
		nLimit = gProcessINI.m_sProcessFidFind.nHolePostLimit;

	VISION_INFO sVision;
	sVision.nModelType =MODEL_CIRCLE;
	sVision.dSizeA = sVision.dSizeB = sVision.dSizeC = gBeamPathINI.m_sBeampath.dHoleVisionModelSize[nUseBeamPath];
	sVision.dScoreSize = gBeamPathINI.m_sBeampath.dHoleAcceptScoreSize[nUseBeamPath];
	sVision.dAspectRatio = gBeamPathINI.m_sBeampath.dHoleAcceptScoreRatio[nUseBeamPath];
	sVision.nPolarity = gBeamPathINI.m_sBeampath.nHolePolarity[nUseBeamPath];
	sVision.dScoreAngle = 0;
	sVision.nThreshold = gDProject.m_Glyphs.m_HoleFindData.sVisInfo.nThreshold;

	for(int k = 0; k< MAX_CAMERA; k++)
	{
		sVision.nRing[k] = gBeamPathINI.m_sBeampath.nHoleRing[nUseBeamPath];
		sVision.nCoaxial[k] = gBeamPathINI.m_sBeampath.nHoleCoaxial[nUseBeamPath];
		sVision.dBrightness[k] = gBeamPathINI.m_sBeampath.dHoleBrightness[nUseBeamPath];
		sVision.dContrast[k] = gBeamPathINI.m_sBeampath.dHoleContrast[nUseBeamPath];
	}
	

	CString strMessage, strInfo;
	for( int g = 0; g < nRepeat; g++ )
	{

		if((gDProject.m_nSeparation == USE_DUAL && !m_bOdd &&  g == 1 )|| gDProject.m_nSeparation == USE_2ND)
			b1stPanel = FALSE;

		if(b1stPanel)
		{
			if(bLowCam)
			{
				dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
				dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
				dMoveZ = gSystemINI.m_sSystemDevice.d1stLowHeight - gDProject.m_dPcbThick;
				this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&gDProject.m_Glyphs.m_HoleFindData.sVisInfo));
				this->SendMessage(UM_VISION_LAMP, LOW_1ST_CAM, reinterpret_cast<LPARAM>(&sVision));

				nCam = LOW_1ST_CAM;
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
			}
			else
			{
				dHeadOffsetX = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x;
				dHeadOffsetY = gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y;
				dMoveZ = gSystemINI.m_sSystemDevice.d1stHighHeight - gDProject.m_dPcbThick;
				this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&gDProject.m_Glyphs.m_HoleFindData.sVisInfo));
				this->SendMessage(UM_VISION_LAMP, HIGH_1ST_CAM, reinterpret_cast<LPARAM>(&sVision));
				nCam = HIGH_1ST_CAM;
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL);
			}
		}
		else
		{
			if(bLowCam)
			{
				dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
				dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
				dMoveZ = gSystemINI.m_sSystemDevice.d2ndLowHeight - gDProject.m_dPcbThick2;
				this->SendMessage(UM_CHANGE_VISION_PARAM3, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&gDProject.m_Glyphs.m_HoleFindData.sVisInfo));
				this->SendMessage(UM_VISION_LAMP, LOW_2ND_CAM, reinterpret_cast<LPARAM>(&sVision));
				nCam = LOW_2ND_CAM;
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
			}
			else
			{
				dHeadOffsetX = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x;
				dHeadOffsetY = gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y;
				dMoveZ = gSystemINI.m_sSystemDevice.d2ndHighHeight -gDProject.m_dPcbThick2;
				this->SendMessage(UM_CHANGE_VISION_PARAM3, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&gDProject.m_Glyphs.m_HoleFindData.sVisInfo));
				this->SendMessage(UM_VISION_LAMP, HIGH_2ND_CAM, reinterpret_cast<LPARAM>(&sVision));
				nCam = HIGH_2ND_CAM;
				::AfxGetMainWnd()->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL);
			}
	
		}

		if(gDProject.m_nSeparation == USE_DUAL)
		{
			pMotor->GetAxisMoveOffset(pAreaInfo->m_nTableX/1000., pAreaInfo->m_nTableY/1000., dPanelOffsetX, dPanelOffsetY, DELTA_PANEL_OFFSET);
			dPanelOffsetX = (dPanelOffsetX + 0.0005) * 1000;
			dPanelOffsetY = (dPanelOffsetY + 0.0005) * 1000;
		}
		else
		{
			dPanelOffsetX = 0;
			dPanelOffsetY = 0;
		}


		if(b1stPanel)
			gDeviceFactory.GetEocard()->GetLaserOffset(pAreaInfo->m_nTableX/1000, pAreaInfo->m_nTableY/1000, dLaserOffsetX, dLaserOffsetY, FIRST_PANEL_OFFSET);
		else
			gDeviceFactory.GetEocard()->GetLaserOffset(pAreaInfo->m_nTableX/1000, pAreaInfo->m_nTableY/1000, dLaserOffsetX, dLaserOffsetY, SECOND_PANEL_OFFSET);

		if(b1stPanel)
		{
			dMoveX = (pAreaInfo->m_nTableX - (nMasterX - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/1000.0 + dHeadOffsetX - dLaserOffsetX;
			dMoveY = (pAreaInfo->m_nTableY - (nMasterY - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/1000.0 + dHeadOffsetY - dLaserOffsetY;
		}
		else
		{
			dMoveX = (pAreaInfo->m_nTableX - dPanelOffsetX - (nSlaveX - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/ 1000.0 + dHeadOffsetX - dLaserOffsetX;
			dMoveY = (pAreaInfo->m_nTableY - dPanelOffsetY - (nSlaveY - 32767) * gSystemINI.m_sSystemDevice.dFieldSize.x * 1000.0 / static_cast<double>(MAXLSB))/ 1000.0 + dHeadOffsetY - dLaserOffsetY;
		}
					
		if(!pMotor->MotorMoveXYZ(dMoveX, dMoveY, dMoveZ, dMoveZ, b1stPanel))
		{
			CString strString, strMsg;
			strString.LoadString(IDS_ERR_MOVE_MOTOR);
			strMsg.Format(strString, "X,Y,Z");
//			ErrMessage(strMsg);
			return FALSE;
		}

		if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
		{
//			ErrMessage(_T("Inposition Error"));
			return FALSE;
		}

		m_dpHoleTablePos[nAreaIndex][nHoleIndex][!b1stPanel].x = dMoveX; 
		m_dpHoleTablePos[nAreaIndex][nHoleIndex][!b1stPanel].y = dMoveY;
		
		
		if(!CheckStatus())
			return FALSE;
	
		BOOL bFound = FALSE; 

		for(int e = 0; e < 3; e++)
		{
			bFound = this->SendMessage(UM_VISION_FIND, nCam, MODEL_CIRCLE);
		
			if(bFound)
				break;
		}
		if(!bFound)
		{
			visionResult.x = 0;
			visionResult.y = 0;
			strMessage.Format(_T("Not Found Hole"));
			
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage),NULL);

			if(b1stPanel)
				this->SendMessage(UM_VISION_SAVE, nCam + 20, 1);
			else
				this->SendMessage(UM_VISION_SAVE, nCam + 20, 2);

			m_bHoleFindOK[nAreaIndex][nHoleIndex][!b1stPanel] = FALSE; 
			m_bHoleFindOK[nAreaIndex][nHoleIndex][!b1stPanel] = FALSE;

			return FALSE;
		}
		m_dpHoleOffset[nAreaIndex][nHoleIndex][!b1stPanel].x = visionResult.x;
		m_dpHoleOffset[nAreaIndex][nHoleIndex][!b1stPanel].y = visionResult.y;

		if(abs(visionResult.x * 1000) > nLimit || abs(visionResult.y * 1000) > nLimit)
		{
			strMessage.Format(_T("Fail Hole Find"));
			strInfo.Format(_T("Table X : %.3f Table Y : %.3f| Found X : %.3f um Found Y : %.3f um "), dMoveX,dMoveY, visionResult.x, visionResult.y);
			
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strMessage), reinterpret_cast<LPARAM>(&strInfo));

			if(b1stPanel)
				this->SendMessage(UM_VISION_SAVE, nCam + 20, 1);
			else
				this->SendMessage(UM_VISION_SAVE, nCam + 20, 2);

			m_bHoleFindOK[nAreaIndex][nHoleIndex][!b1stPanel] = FALSE; 
			m_bHoleFindOK[nAreaIndex][nHoleIndex][!b1stPanel] = FALSE;

			return FALSE;
		}


		m_bHoleFindOK[nAreaIndex][nHoleIndex][!b1stPanel] = TRUE; 
		m_bHoleFindOK[nAreaIndex][nHoleIndex][!b1stPanel] = TRUE;
	}

	return TRUE;
}

void CPaneAutoRun::SaveHoleFindResult(int nUseBeamPath)
{
	CString strPathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	strPathName += _T("HoleFindLog");
	CTime curDate = CTime::GetCurrentTime();
	
	CString strCurTime;
	strCurTime.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	strPathName += strCurTime;
	
	CStdioFile file;
	if (FALSE == file.Open(strPathName, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite))
		return;
	
	int nSelHead = gDProject.m_nSeparation;
	int nDivision = GetDivision();
	
	CString strBuf;
	CString strCam, strPanel, strOP, strOK1,strOK2;
	
	
	
	int nFidBlock;
	if(gDProject.m_bMultiFidAscentOrder)
		nFidBlock = 0;
	else
		nFidBlock = -1; 
	
	BOOL b1stPanel = TRUE;
	
	if(gBeamPathINI.m_sBeampath.nHoleVisionCam[nUseBeamPath]%2 != 0) // fiducial cam -> hole find
		strCam.Format(_T("Low"));
	else
		strCam.Format(_T("High"));

	TRY
	{
		file.SeekToEnd();

		strBuf.Format(_T("Lot ID : %s\n"), gDProject.m_szLotId);
		file.Write(strBuf, strBuf.GetLength());

		strBuf.Format(_T("Project : %s\n"), gDProject.m_szProjectName);
		file.Write(strBuf, strBuf.GetLength());

		strBuf.Format(_T("Data : %s\n"), gDProject.m_szFileName);
		file.Write(strBuf, strBuf.GetLength());

		strBuf.Format(_T("Panel No : %d\n"), m_nCurrentLotCount);
		file.Write(strBuf, strBuf.GetLength());

		for(int i = 0; i < 9; i++)
		{
			if(!gProcessINI.m_sProcessFidFind.bHoleFindAreaPos[i])
				continue;

			for(int k = 0; k < 9; k++)
			{
				if(!gProcessINI.m_sProcessFidFind.bHoleFindHolePos[k])
					continue;

				if(m_bHoleFindOK[i][k][0])
					strOK1.Format(_T("OK"));
				else
					strOK1.Format(_T("NG"));

				if(m_bHoleFindOK[i][k][1])
					strOK2.Format(_T("OK"));
				else
					strOK2.Format(_T("NG"));

				if(nSelHead == USE_DUAL && !m_bOdd)
				{
					strPanel.Format(_T("Dual-1st"));
					strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %d | %d | %d | %.3f | %.3f | %.3f | %.3f\n"),
						curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
						curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
						strPanel, strOK1, m_nHoleAreaIndex[i], 
						m_cpHolePos[i][k][0].x, m_cpHolePos[i][k][0].y, 
						m_dpHoleTablePos[i][k][0].x, m_dpHoleTablePos[i][k][0].y,
						m_dpHoleOffset[i][k][0].x, m_dpHoleOffset[i][k][0].y);
					file.Write(strBuf, strBuf.GetLength());

					strPanel.Format(_T("Dual-2nd"));
					strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %d | %d | %d | %.3f | %.3f | %.3f | %.3f\n"),
						curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
						curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
						strPanel, strOK2, m_nHoleAreaIndex[i], 
						m_cpHolePos[i][k][1].x, m_cpHolePos[i][k][1].y, 
						m_dpHoleTablePos[i][k][1].x, m_dpHoleTablePos[i][k][1].y,
						m_dpHoleOffset[i][k][1].x, m_dpHoleOffset[i][k][1].y);
					file.Write(strBuf, strBuf.GetLength());
				}
				else if(nSelHead == USE_DUAL && m_bOdd || nSelHead == USE_1ST)
				{
					strPanel.Format(_T("1st"));
					strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %d | %d | %d | %.3f | %.3f | %.3f | %.3f\n"),
						curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
						curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
						strPanel, strOK1, m_nHoleAreaIndex[i], 
						m_cpHolePos[i][k][0].x, m_cpHolePos[i][k][0].y, 
						m_dpHoleTablePos[i][k][0].x, m_dpHoleTablePos[i][k][0].y,
						m_dpHoleOffset[i][k][0].x, m_dpHoleOffset[i][k][0].y);
					file.Write(strBuf, strBuf.GetLength());
				}
				else if(nSelHead == USE_2ND)
				{
					strPanel.Format(_T("2nd"));
					strBuf.Format(_T("%04d/%02d/%02d | %02d:%02d:%02d | %s | %s | %d | %d | %d | %.3f | %.3f | %.3f | %.3f\n"),
						curDate.GetYear(), curDate.GetMonth(), curDate.GetDay(),
						curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(),
						strPanel, strOK2, m_nHoleAreaIndex[i], 
						m_cpHolePos[i][k][1].x, m_cpHolePos[i][k][1].y, 
						m_dpHoleTablePos[i][k][1].x, m_dpHoleTablePos[i][k][1].y,
						m_dpHoleOffset[i][k][1].x, m_dpHoleOffset[i][k][1].y);
					file.Write(strBuf, strBuf.GetLength());
				}
			}
		}

		strBuf.Format(_T("--------------------------------------------------------------------------------------------------\n"));
		file.Write(strBuf, strBuf.GetLength());
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		return;
	}
	END_CATCH
		file.Close();

	
}

BOOL CPaneAutoRun::GetNeedUnload()
{
	return m_bNeedUnload;
}
		
void CPaneAutoRun::SetNeedUnload(BOOL bNeed)
{
	m_bNeedUnload = bNeed;	
}
void CPaneAutoRun::SaveFidCompensation(BOOL b1st, int nFidBlock, double dAvgScaleX, double dAvgScaleY, double* dScale, int* nLRTB,  CDPoint* dRefPos, CDPoint* dFindPos, int nLogTime)
{
	int nLB = nLRTB[0];
	int nRB = nLRTB[1];
	int nRT = nLRTB[2];
	int nLT = nLRTB[3];

	CString strpathName = gEasyDrillerINI.m_clsDirPath.GetProcessLogDir();
	CString strSequenceLog;
	strpathName+=_T("FiducialAllLog");
	CTime  curDate = CTime::GetCurrentTime();
	CString strLotID;

	CString strCurTime;
	strCurTime.Format(_T("%02d%02d"),curDate.GetYear(), curDate.GetMonth());
	
	strpathName+=strCurTime;
	
	//우선 파일 검사
	BOOL bExist;
	CFileFind find;
	bExist = find.FindFile((LPCTSTR)strpathName);
	
	CStdioFile file;
	if(FALSE == file.Open(strpathName,CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite))
		return ;
	
	CString strTemp, strPanel;
	if(b1st)
		strPanel.Format(_T("1st"));
	else
		strPanel.Format(_T("2nd"));
	TRY 
	{
		file.SeekToEnd();
		
		strTemp.Format(_T("\n%02d/%02d | %02d:%02d:%02d | %s\n"),
			curDate.GetMonth(), curDate.GetDay(),
			curDate.GetHour(), curDate.GetMinute(),	curDate.GetSecond(), strPanel);
		file.Write(strTemp, strTemp.GetLength());

		if(nLogTime == 0)
		{
			strTemp.Format(_T("------------------Find Fiducial Info------------------\n"));
			file.Write(strTemp, strTemp.GetLength());
			
			for(int i = 0; i< 4; i++)
			{
				strTemp.Format(_T("Fid %d | File PosX %0.f | Find PosX %0.f | File PosY %0.f | Find PosY %0.f\n"),
					i, dRefPos[i].x, dFindPos[i].x, dRefPos[i].y,  dFindPos[i].y);
				file.Write(strTemp, strTemp.GetLength());
			}
			
			strTemp.Format(_T("Avg Scale X %.3f | Avg Scale Y %.3f \n"), dAvgScaleX, dAvgScaleY);
			file.Write(strTemp, strTemp.GetLength());
			
			if(nLB != -1 && nRB != -1)
			{
				strTemp.Format(_T("%d - %d | Find Scale %.3f \n"), nLB, nRB, dScale[0] );
				file.Write(strTemp, strTemp.GetLength());
			}
			if(nRT != -1 && nRB != -1)
			{
				strTemp.Format(_T("%d - %d | Find Scale %.3f \n"), nRB, nRT, dScale[1] );
				file.Write(strTemp, strTemp.GetLength());
			}
			if(nLT != -1 && nRT != -1)
			{
				strTemp.Format(_T("%d - %d | Find Scale %.3f \n"), nRT, nLT, dScale[2] );
				file.Write(strTemp, strTemp.GetLength());				
			}
			if(nLT != -1 && nLB != -1)
			{
				strTemp.Format(_T("%d - %d | Find Scale %.3f \n"), nLT, nLB, dScale[3] );
				file.Write(strTemp, strTemp.GetLength());
			}
		}
		else
		{	
			if(nLogTime == 1)
				strTemp.Format(_T("--------------Compensation Fiducial Info--------------\n"));
			else
				strTemp.Format(_T("------------No Compensation Fiducial Info-------------\n"));

			file.Write(strTemp, strTemp.GetLength());
			for(int i = 0; i< 4; i++)
			{
				strTemp.Format(_T("Fid %d | File PosX %0.f | Find PosX %0.f | File PosY %0.f | Find PosY %0.f\n"),
					i, dRefPos[i].x, dFindPos[i].x, dRefPos[i].y,  dFindPos[i].y);
				file.Write(strTemp, strTemp.GetLength());
			}
		
			if(nLB != -1 && nRB != -1)
			{
				strTemp.Format(_T("%d - %d | Find Scale %.3f \n"), nLB, nRB, dScale[0] );
				file.Write(strTemp, strTemp.GetLength());
			}
			if(nRT != -1 && nRB != -1)
			{
				strTemp.Format(_T("%d - %d | Find Scale %.3f \n"), nRB, nRT, dScale[1] );
				file.Write(strTemp, strTemp.GetLength());
			}
			if(nLT != -1 && nRT != -1)
			{
				strTemp.Format(_T("%d - %d | Find Scale %.3f \n"), nRT, nLT, dScale[2] );
				file.Write(strTemp, strTemp.GetLength());				
			}
			if(nLT != -1 && nLB != -1)
			{
				strTemp.Format(_T("%d - %d | Find Scale %.3f \n"), nLT, nLB, dScale[3] );
				file.Write(strTemp, strTemp.GetLength());
			}
		}
	}
	CATCH (CFileException, e)
	{
		e->Delete();
		::SetEvent(g_hLotFile);
		return;
	}
	END_CATCH
	file.Close();
}
void CPaneAutoRun::SetProportaionOffset(BOOL b1st, int nFidBlock, CDPoint* dTransPos, CDPoint* dRefPos, CDPoint* dFindPos, int* nLRTB)
{
	int nLB = nLRTB[0];
	int nRB = nLRTB[1];
	int nRT = nLRTB[2];
	int nLT = nLRTB[3];

	int nCount = gDProject.m_RefTrans[!b1st][nFidBlock].GetNumPoint();
	double dRefCenterX =0, dRefCenterY =0, dTransCenterX =0, dTransCenterY =0;
	for(int i =0 ; i< nCount; i++)
	{
		dRefCenterX += dRefPos[i].x;
		dRefCenterY += dRefPos[i].y;
		dTransCenterX += dFindPos[i].x;
		dTransCenterY += dFindPos[i].y;
	}

	dRefCenterX /= nCount;
	dRefCenterY /= nCount;
	dTransCenterX /= nCount;
	dTransCenterY /= nCount;

	double dOffsetX, dOffsetY;
	dOffsetX = dTransCenterX - dRefCenterX;
	dOffsetY = dTransCenterY - dRefCenterY;
	
	for(int k = 0; k< nCount; k++)
	{
		dTransPos[k].x = dRefPos[k].x + dOffsetX;
		dTransPos[k].y = dRefPos[k].y + dOffsetY;
	}
}
BOOL CPaneAutoRun::SetProportaionCompensation(BOOL b1st, int nFidBlock, double dAvgScaleX, double dAvgScaleY, double* dScale, int* nLRTB, BOOL bOnlyLog)
{
	//  배열 저장 인덱스
	//	F3  2  F2
	//  3       1
	//  F0  0  F1
	int nLB = nLRTB[0];
	int nRB = nLRTB[1];
	int nRT = nLRTB[2];
	int nLT = nLRTB[3];
	CDPoint dTransPos[4], dRefPos[4], dFindPos[4];
	double dGetScale[4];
	
	int nCount = gDProject.m_RefTrans[!b1st][nFidBlock].GetNumPoint();

	if(nCount != 4)
		return FALSE;

	for(int i =0 ; i< nCount; i++)
	{
		dRefPos[i] = gDProject.m_RefTrans[!b1st][nFidBlock].GetRefsPoint(i);
		dFindPos[i] = gDProject.m_RefTrans[!b1st][nFidBlock].GetTransPoint(i);
	}

	SetProportaionOffset(b1st, nFidBlock, dTransPos, dRefPos, dFindPos, nLRTB);
	if(!SetProportaionScale(b1st, nFidBlock, dTransPos, dRefPos, dFindPos, nLRTB, dAvgScaleX,  dAvgScaleY, dScale))
		return FALSE;

	if(!bOnlyLog)
	{
		if(!SetProportaionAngle(b1st, nFidBlock, dTransPos, dRefPos, dFindPos, nLRTB, dGetScale, FALSE))
			return FALSE;
		SaveFidCompensation(b1st, nFidBlock, dAvgScaleX, dAvgScaleY, dGetScale, nLRTB, dRefPos, dTransPos, 1);
	}
	else
	{
		if(!SetProportaionAngle(b1st, nFidBlock, dTransPos, dRefPos, dFindPos, nLRTB, dGetScale, TRUE))
			return FALSE;
		SaveFidCompensation(b1st, nFidBlock, dAvgScaleX, dAvgScaleY, dGetScale, nLRTB, dRefPos, dTransPos, 2);
	}
	return TRUE;
}


BOOL CPaneAutoRun::SetProportaionScale(BOOL b1st, int nFidBlock, CDPoint* dTransPos, CDPoint* dRefPos, CDPoint* dFindPos, int* nLRTB, double dAvgScaleX, double dAvgScaleY, double* dScale)
{
	//  배열 저장 인덱스
	//	F3  2  F2
	//  3       1 F1
	//  F0  0  
	int nLB = nLRTB[0];
	int nRB = nLRTB[1];
	int nRT = nLRTB[2];
	int nLT = nLRTB[3];

	double dDiff;
	double dScaleOffset;

	if(nLB == -1 || nRB == -1 || nLT == -1 || nRT == -1)
		return FALSE;
	
	if(nLB != -1 && nRB != -1)
	{
		dDiff = dAvgScaleX - 100; //trans가 100 
		dScaleOffset = fabs((dRefPos[nRB].x - dRefPos[nLB].x)/ 100 * dDiff);
		if(dDiff > 0) // 평균보다 작을 경우 
		{
			dTransPos[nRB].x += dScaleOffset/2.;
			dTransPos[nLB].x -= dScaleOffset/2.;
		}
		else
		{
			dTransPos[nRB].x -= dScaleOffset/2.;
			dTransPos[nLB].x += dScaleOffset/2.;
		}
	}
	if(nLT != -1 && nRT != -1)
	{
		dDiff = dAvgScaleX - 100; 
		dScaleOffset = fabs((dRefPos[nRT].x - dRefPos[nLT].x)/ 100 * dDiff);
		if(dDiff > 0)
		{
			dTransPos[nRT].x += dScaleOffset/2.;
			dTransPos[nLT].x -= dScaleOffset/2.;
		}
		else
		{
			dTransPos[nRT].x -= dScaleOffset/2.;
			dTransPos[nLT].x += dScaleOffset/2.;
		}
		
	}
	if(nLT != -1 && nLB != -1)
	{
		dDiff = dAvgScaleY - 100; 
		dScaleOffset = fabs((dRefPos[nLT].y - dRefPos[nLB].y)/ 100 * dDiff);
		if(dDiff > 0)
		{
			dTransPos[nLT].y += dScaleOffset/2.;
			dTransPos[nLB].y -= dScaleOffset/2.;
		}
		else
		{
			dTransPos[nLT].y -= dScaleOffset/2.;
			dTransPos[nLB].y += dScaleOffset/2.;
		}
	}
	if(nRT != -1 && nRB != -1)
	{
		dDiff = dAvgScaleY - 100; 
		dScaleOffset = fabs((dRefPos[nRT].y - dRefPos[nRB].y)/ 100 * dDiff);
		if(dDiff > 0)
		{
			dTransPos[nRT].y += dScaleOffset/2.;
			dTransPos[nRB].y -= dScaleOffset/2.;
		}
		else
		{
			dTransPos[nRT].y -= dScaleOffset/2.;
			dTransPos[nRB].y += dScaleOffset/2.;
		}
	}
	return TRUE;
}
BOOL CPaneAutoRun::SetProportaionAngle(BOOL b1st, int nFidBlock, CDPoint* dTransPos, CDPoint* dRefPos, CDPoint* dFindPos, int* nLRTB, double* dScale, BOOL bNoTrans)
{
	int nLB = nLRTB[0];
	int nRB = nLRTB[1];
	int nRT = nLRTB[2];
	int nLT = nLRTB[3];
	C2DTransform pTrans;
	CDPoint dOffsetXY[4];

	if(nLB != -1)
	{
		dOffsetXY[nLB].x = dFindPos[nLB].x - dRefPos[nLB].x;
		dOffsetXY[nLB].y = dFindPos[nLB].y - dRefPos[nLB].y;
	}
	if(nRB != -1)
	{
		dOffsetXY[nRB].x = dFindPos[nRB].x - dRefPos[nRB].x;
		dOffsetXY[nRB].y = dFindPos[nRB].y - dRefPos[nRB].y;
	}
	if(nRT != -1)
	{
		dOffsetXY[nRT].x = dFindPos[nRT].x - dRefPos[nRT].x;
		dOffsetXY[nRT].y = dFindPos[nRT].y - dRefPos[nRT].y;
	}
	if(nLT != -1)
	{
		dOffsetXY[nLT].x = dFindPos[nLT].x - dRefPos[nLT].x;
		dOffsetXY[nLT].y = dFindPos[nLT].y - dRefPos[nLT].y;
	}

	//get avg angle
	double dAngle = 0;
	double dAvgAngle = 0;
	CDPoint cpTemp1, cpTemp2, cpTemp3;
	int nCount =0; 
	// 대각선 angle 로만 계산
	if(nLB != -1 && nRT != -1)
	{
		cpTemp1 = dRefPos[nRT]; 
		cpTemp2 = dRefPos[nLB];
		cpTemp3.x = dFindPos[nRT].x - dOffsetXY[nLB].x ; 	
		cpTemp3.y = dFindPos[nRT].y - dOffsetXY[nLB].y ; 	
		
		dAngle = pTrans.CalAngleMaxPi(cpTemp3, cpTemp2, cpTemp1);

		if(dAngle > M_PI/4 || dAngle < -M_PI/4)
			return FALSE;
	
		dAvgAngle += dAngle; 
		nCount++;
	}
	if(nRB != -1 && nLT != -1)
	{
		cpTemp1 = dRefPos[nRB]; 
		cpTemp2 = dRefPos[nLT];
		cpTemp3.x = dFindPos[nRB].x - dOffsetXY[nLT].x ; 	
		cpTemp3.y = dFindPos[nRB].y - dOffsetXY[nLT].y ; 	
		
		dAngle = pTrans.CalAngleMaxPi(cpTemp3, cpTemp2, cpTemp1);

		if(dAngle > M_PI/4 || dAngle < -M_PI/4)
			return FALSE;
		
		dAvgAngle += dAngle; 
		nCount++;
	}

	if(nCount == 0)
		return FALSE;

	dAvgAngle /= nCount;

	//get trans center  
	int nNum;
	nNum = gDProject.m_RefTrans[!b1st][nFidBlock].GetNumPoint();

	CDPoint dpCenter; //회전중심 
	for(int i = 0; i<nNum; i++)
	{
		dpCenter.x += dTransPos[i].x;
		dpCenter.y += dTransPos[i].y;
	}

	dpCenter.x /= nNum;
	dpCenter.y /= nNum;

	
	

//	if(nNum != nCount)
//		return FALSE;

	if(!bNoTrans)
		gDProject.m_RefTrans[!b1st][nFidBlock].SetNumPoint(nNum);

	for(int i = 0; i< nNum; i++)
	{
		dTransPos[i].rotateRadian(dpCenter, dAvgAngle);
		if(!bNoTrans)
		{
			gDProject.m_RefTrans[!b1st][nFidBlock].SetReferencePoint(dRefPos[i].x, dRefPos[i].y, i);
			gDProject.m_RefTrans[!b1st][nFidBlock].SetTransformedPoint(dTransPos[i].x, dTransPos[i].y, i);
		}
	}  
	if(!bNoTrans)
		gDProject.m_RefTrans[!b1st][nFidBlock].Transform();

	CDPoint temp1, temp2, temp3, temp4;
	double dX, dY, dX2, dY2;
	double dDist1, dDist2;
	//	//get scale 
	if(nLB != -1 && nRB != -1)
	{
		temp1 = dRefPos[nLB];
		temp2 = dRefPos[nRB];
		
		temp3 = dTransPos[nLB];
		temp4 = dTransPos[nRB];

		dX = temp2.x - temp1.x; dY = temp2.y - temp1.y;
		dDist1 = sqrt(dX * dX + dY * dY);

		dX2 = temp4.x - temp3.x; dY2 = temp4.y - temp3.y;
		dDist2 = sqrt(dX2 * dX2 + dY2 * dY2);

		dScale[0] = dDist2/dDist1 * 100;
		
	}
	if(nLT != -1 && nRT != -1)
	{
		temp1 = dRefPos[nRT];
		temp2 = dRefPos[nLT];
		
		temp3 = dTransPos[nRT];
		temp4 = dTransPos[nLT];

		dX = temp2.x - temp1.x; dY = temp2.y - temp1.y;
		dDist1 = sqrt(dX * dX + dY * dY);
		
		dX2 = temp4.x - temp3.x; dY2 = temp4.y - temp3.y;
		dDist2 = sqrt(dX2 * dX2 + dY2 * dY2);
		
		dScale[2] = dDist2/dDist1 * 100;
		
	}
	if(nLT != -1 && nLB != -1)
	{
		temp1 = dRefPos[nLB];
		temp2 = dRefPos[nLT];
		
		temp3 = dTransPos[nLB];
		temp4 = dTransPos[nLT];
		
		dX = temp2.x - temp1.x; dY = temp2.y - temp1.y;
		dDist1 = sqrt(dX * dX + dY * dY);
		
		dX2 = temp4.x - temp3.x; dY2 = temp4.y - temp3.y;
		dDist2 = sqrt(dX2 * dX2 + dY2 * dY2);
		
		dScale[3] = dDist2/dDist1 * 100;
	}
	if(nRT != -1 && nRB != -1)
	{
		temp1 = dRefPos[nRB];
		temp2 = dRefPos[nRT];
		
		temp3 = dTransPos[nRB];
		temp4 = dTransPos[nRT];
		
		dX = temp2.x - temp1.x; dY = temp2.y - temp1.y;
		dDist1 = sqrt(dX * dX + dY * dY);
		
		dX2 = temp4.x - temp3.x; dY2 = temp4.y - temp3.y;
		dDist2 = sqrt(dX2 * dX2 + dY2 * dY2);
		
		dScale[1] = dDist2/dDist1 * 100;
	}
	return TRUE;
}


BOOL CPaneAutoRun::GetHeadOffset(int nSelHead)
{
	HVision* pVision = gDeviceFactory.GetVision();
	
	emHEAD n1stUse = emNone, n2ndUse = emNone;
	if(nSelHead != SEL_HEAD_SLAVE)
		n1stUse = emMaster;
	if (nSelHead != SEL_HEAD_MASTER)
		n2ndUse = emSlave;

	int nRepeatTime = 1;
	BOOL bRet;
	double dMoveY, dMoveX;
	
	SVISIONINFO sVisionInfo;
	sVisionInfo.nModelType = 1;
	sVisionInfo.nPolarity = 0;
	sVisionInfo.dSizeA = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nDoASCTool];
	sVisionInfo.dSizeB = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nDoASCTool];
	sVisionInfo.dSizeC = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nDoASCTool];
	
	for(int i=0; i<4; i++)
	{
		sVisionInfo.nCoaxial[i] = gBeamPathINI.m_sBeampath.nScannerCoaxial[i];
		sVisionInfo.nRing[i] = gBeamPathINI.m_sBeampath.nScannerRing[i];
		sVisionInfo.dContrast[i] = gBeamPathINI.m_sBeampath.dScannerContrast[m_nDoASCTool];
		sVisionInfo.dBrightness[i] = gBeamPathINI.m_sBeampath.dScannerBrightness[m_nDoASCTool];
	}
	
	sVisionInfo.dScoreAngle = 0;//.dAngleTolerance;
	sVisionInfo.dScoreSize = gBeamPathINI.m_sBeampath.dScannerAcceptScoreSize[m_nDoASCTool];
	sVisionInfo.dAspectRatio = gBeamPathINI.m_sBeampath.dScannerAcceptScoreRatio[m_nDoASCTool];

	BOOL bFindM = FALSE, bFindS = FALSE;
	CDPoint dIndexP, dFindOffsetM, dFindOffsetS;
	double dFindPosMX, dFindPosMY, dFindPosSX, dFindPosSY;
	double dReTryOffX, dReTryOffY, dStepX, dStepY, dModelX, dModelY;
	double dHighFOVX = gSystemINI.m_sSystemDevice.dHighFOVX, dHighFOVY = gSystemINI.m_sSystemDevice.dHighFOVY;
	dModelX = dModelY = gBeamPathINI.m_sBeampath.dScannerVisionModelSize[m_nDoASCTool];
	
	dReTryOffX = max((dHighFOVX - dModelX)/2 - 0.03, 0.1); // 0.1 여분
	dReTryOffY = max((dHighFOVY - dModelY)/2 - 0.03, 0.1); // 0.1 여분
	
	dStepX = dHighFOVX - dModelX - 0.03;
	dStepY = dHighFOVY - dModelY - 0.03;

	int nMove = max(1, (int)ceil((3 - dHighFOVX)/(2 * dStepX)));
	dStepX = min(dStepX, (3 - dHighFOVX) / (2 * nMove));
	dStepY = min(dStepY, (3 - dHighFOVY) / (2 * nMove));
	nRepeatTime = (nMove * 2 + 1) * (nMove * 2 + 1);
	
	//low -> high  
	double dCalThick = gDProject.m_dPcbThick;
	double dCalThick2nd = gDProject.m_dPcbThick2;
	
	double dZ1 = gSystemINI.m_sSystemDevice.d1stLowHeight - dCalThick;
	double dZ2 = gSystemINI.m_sSystemDevice.d2ndLowHeight - dCalThick2nd;
	int nCam;

	if(n1stUse == emMaster && (gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO))
	{
		dMoveY = m_dOffsetStartYAuto + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.y;
		dMoveX = m_dOffsetStartXAuto + gSystemINI.m_sSystemDevice.d1stLowHeadOffset.x;
		if(!gDeviceFactory.GetMotor()->MoveXYZ(dMoveX, dMoveY, dZ1, dZ2, TRUE))	
		{
			m_nErrMsgID = STDGNALM438; 
			return FALSE;
		}
		
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
			return FALSE;
		}
		
		if(!CheckStatus())
			return FALSE;

		nCam = LOW_1ST_CAM; 
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STLOW, NULL);
		this->SendMessage(UM_CHANGE_VISION_PARAM3, nCam, reinterpret_cast<LPARAM>(&sVisionInfo));
		this->SendMessage(UM_VISION_LAMP, nCam, reinterpret_cast<LPARAM>(&sVisionInfo));
		Sleep(10);

		bRet = this->SendMessage(UM_VISION_FIND, nCam, MODEL_CIRCLE);

		if(bRet)
		{
			gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dFindPosMX, TRUE); // low vision pos 
			gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dFindPosMY, TRUE);
			dFindOffsetM.x = visionResult.x; 
			dFindOffsetM.y = visionResult.y;
			bFindM = TRUE;
			
		}
	}
	
	if(n2ndUse == emSlave && (gSystemINI.m_sHardWare.nVisionType == OMI_VISION ||
		gSystemINI.m_sHardWare.nVisionType == OMI_VISION_PRO))
	{
		dMoveY = m_dOffsetStartYAuto + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.y;
		dMoveX = m_dOffsetStartXAuto + gSystemINI.m_sSystemDevice.d2ndLowHeadOffset.x;
		if(!gDeviceFactory.GetMotor()->MoveXYZ(dMoveX, dMoveY, dZ1, dZ2, FALSE))	
		{
			m_nErrMsgID = STDGNALM438; 
			return FALSE;
		}
		
		if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
			return FALSE;
		}
		
		if(!CheckStatus())
			return FALSE;

		nCam = LOW_2ND_CAM; 
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDLOW, NULL);
		this->SendMessage(UM_CHANGE_VISION_PARAM3, nCam, reinterpret_cast<LPARAM>(&sVisionInfo));
		this->SendMessage(UM_VISION_LAMP, nCam, reinterpret_cast<LPARAM>(&sVisionInfo));
		Sleep(10);
		bRet = this->SendMessage(UM_VISION_FIND, nCam, MODEL_CIRCLE);
		
		if(bRet)
		{
			gDeviceFactory.GetMotor()->GetPosition(AXIS_X, dFindPosSX, FALSE);
			gDeviceFactory.GetMotor()->GetPosition(AXIS_Y, dFindPosSY, FALSE);
			dFindOffsetS.x = visionResult.x; 
			dFindOffsetS.y = visionResult.y;
			bFindS = TRUE;
		}
	}
		
	if(n1stUse == emMaster && !bFindM)
	{
		return FALSE;
	}
	if(n2ndUse == emSlave && !bFindS)
	{
		return FALSE;
	}
	int nKK;
	dZ1 = gSystemINI.m_sSystemDevice.d1stHighHeight - dCalThick;
	dZ2 = gSystemINI.m_sSystemDevice.d2ndHighHeight - dCalThick2nd;
	//set roi 
	this->SendMessage(UM_VISION_ROI_SET, -1, HIGH_2ND_CAM);
	this->SendMessage(UM_VISION_ROI_SET, -1, HIGH_1ST_CAM);

	if(n1stUse == emMaster)
	{
		if(bFindM)
		{
			nCam = HIGH_1ST_CAM; 
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA1STHIGH, NULL);
			this->SendMessage(UM_CHANGE_VISION_PARAM3, nCam, reinterpret_cast<LPARAM>(&sVisionInfo));
			this->SendMessage(UM_VISION_LAMP, nCam, reinterpret_cast<LPARAM>(&sVisionInfo));

			for(nKK=0; nKK< nRepeatTime; nKK++)
			{
				if(!CheckStatus())
					return FALSE;

				dIndexP = GetNextStepIndex(nKK);

				dMoveY = m_dOffsetStartYAuto + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.y - (dIndexP.y * dStepY) ;
				dMoveX = m_dOffsetStartXAuto + gSystemINI.m_sSystemDevice.d1stHighHeadOffset.x - (dIndexP.x * dStepX) ;
				
				if(!gDeviceFactory.GetMotor()->MoveXYZ(dMoveX, dMoveY, dZ1, dZ2, TRUE))	
				{
					m_nErrMsgID = STDGNALM438; 
					return FALSE;
				}
				
				if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
				{
					int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
					CheckInpositionError(nErrorAxis);
					return FALSE;
				}
				
				bRet = this->SendMessage(UM_VISION_FIND, nCam, MODEL_CIRCLE);
				
				if(bRet)
				{
					if(dReTryOffX > fabs(visionResult.x ) && dReTryOffY > fabs(visionResult.y ))
					{
						m_dOffsetM.x = visionResult.x - dFindOffsetM.x;
						m_dOffsetM.y = visionResult.y - dFindOffsetM.y;
						break;
					}
				}
			}

			if(!bRet)
				return FALSE;
		}
		else
			return FALSE;
	}
	
	if(n2ndUse == emSlave)
	{
		if(bFindS)
		{
			nCam = HIGH_2ND_CAM; 
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(WM_COMMAND, IDC_CHANGE_CAMERA2NDHIGH, NULL);
			this->SendMessage(UM_CHANGE_VISION_PARAM3, nCam, reinterpret_cast<LPARAM>(&sVisionInfo));
			this->SendMessage(UM_VISION_LAMP, nCam, reinterpret_cast<LPARAM>(&sVisionInfo));
			for(nKK=0; nKK< nRepeatTime; nKK++)
			{
				if(!CheckStatus())
					return FALSE;

				dIndexP = GetNextStepIndex(nKK);
				dMoveY = m_dOffsetStartYAuto + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.y - (dIndexP.y * dStepY) ;
				dMoveX = m_dOffsetStartXAuto + gSystemINI.m_sSystemDevice.d2ndHighHeadOffset.x - (dIndexP.x * dStepX) ;
				
				if(!gDeviceFactory.GetMotor()->MoveXYZ(dMoveX, dMoveY, dZ1, dZ2, FALSE))	
				{
					m_nErrMsgID = STDGNALM438; 
					return FALSE;
				}
				
				if (TRUE != gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2))
				{
					int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
					CheckInpositionError(nErrorAxis);
					return FALSE;
				}
				
				bRet = this->SendMessage(UM_VISION_FIND, nCam, MODEL_CIRCLE);
				
				if(bRet)
				{
					if(dReTryOffX > fabs(visionResult.x ) && dReTryOffY > fabs(visionResult.y ))
					{
						m_dOffsetS.x = visionResult.x - dFindOffsetS.x;
						m_dOffsetS.y = visionResult.y - dFindOffsetS.y;
						break;
					}
				}
			}
			if(!bRet)
				return FALSE;
		}
		else
			return FALSE;
	}
	return TRUE;
}

void CPaneAutoRun::CheckOmiVisionConnect()
{
	if(gSystemINI.m_sHardWare.nVisionType == OMI_VISION)
	{
		if(CWnd::FindWindowA(NULL, _T("OmiVisionCom_TCP_IP")) == NULL && !gDeviceFactory.GetVision()->CheckOmiHandle())
		{
			gDeviceFactory.GetVision()->Initialize();
			gDeviceFactory.GetVision()->OnConnectView();
			((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView = gDeviceFactory.GetVision()->m_pVisionHandle;
			//((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pVisionView->SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE );
			WPARAM wParam = DRILL;
			::AfxGetMainWnd()->PostMessage( CHANGE_PANE, wParam, 0);
		}
	}
}

void CPaneAutoRun::ChangeDiffFidStartPos()
{
	LPFIDDATA pFidData1, pFidData2;
	int nCnt = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, FID_FIND, FID_VERIFY, 0);
	if(nCnt < 2)
		return;
	pFidData1 = gDProject.m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, 0, FID_FIND, FID_VERIFY, 0);
	pFidData2 = gDProject.m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, 1, FID_FIND, FID_VERIFY, 0);

	gTempINI.m_sTempTime.n1stFidSecondPosX = pFidData2->npTransPosition.x - pFidData1->npTransPosition.x;
	gTempINI.m_sTempTime.n1stFidSecondPosY = pFidData2->npTransPosition.y - pFidData1->npTransPosition.y;
	gTempINI.m_sTempTime.n2ndFidFirstPosX = pFidData1->npTransPosition2.x - pFidData1->npTransPosition.x;
	gTempINI.m_sTempTime.n2ndFidFirstPosY = pFidData1->npTransPosition2.y - pFidData1->npTransPosition.y;
	gTempINI.m_sTempTime.n2ndFidSecondPosX = pFidData2->npTransPosition2.x - pFidData1->npTransPosition.x;
	gTempINI.m_sTempTime.n2ndFidSecondPosY = pFidData2->npTransPosition2.y - pFidData1->npTransPosition.y;

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, TEMP_INI))
		return;
}

void CPaneAutoRun::DrillStopProcess(int nErrorID)
{
	CString strFile, strLog;
	strFile.Format(_T("AutorunTrace"));
	strLog.Format(_T("Drill Stop Process : ID (%d)"), nErrorID);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	if(nErrorID)
		m_nErrMsgID = nErrorID;

	if(!m_bPostPreWorkDoing) // post prework 동안에는 그 함수에서 아래를 호출하지 않도록 함. 2중 호출의 문제가 있어서 추가함.
	{
		
		strLog.Format(_T("SendMessage : DRILL_STOP"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		WriteLotLog();
		::AfxGetMainWnd()->SendMessage(DRILL_STOP);
		SetErrMsg();
	}
	if(m_bChangePanelInfo) //unloading하기 전에 끝났을 경우  
	{
		gDeviceFactory.GetMotor()->MoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX, gProcessINI.m_sProcessAutoSetting.dLoadPosY);

		Sleep(100);

		if(!gDeviceFactory.GetMotor()->InPositionIO(IND_X + IND_Y))
		{
			int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
			CheckInpositionError(nErrorAxis);
		}
		m_bChangePanelInfo = FALSE;
		m_nErrMsgID = STDGNALM666; // fiducial find fail

	}
	gDProject.m_nSeparation = m_nBackupSeparation;
}

BOOL CPaneAutoRun::PreLoadUnloadRun(BOOL bUnloadAlign)
{
	LONG lStatus;
	CString strSequenceLog, strFile, strLog;

	if(m_bAutoRun && !gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader && !bUnloadAlign)
	{
		// 이전 AutoRun에서 가공만 하고 Unloading전에 멈춘 상태에서
		// 다시 Run하고 테이블위에 자재가 있으면 Unloading부터 시작한다
		if(m_bNeedUnload && CheckPCBExist())
		{
			lStatus = m_pMotor->GetCurrentError(ERROR_UNLOAD3);
			if(lStatus & 0x1000)
			{
				m_nErrMsgID = STDGNALM565;				
				return FALSE;
			}
			if(!CheckStatus())
			{
				return FALSE;
			}
				
			strSequenceLog.Format(_T("---Pre Unloading Start---"));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
			if(!DoUnloading(m_bEndBoard))
			{
				strSequenceLog.Format(_T("---UnLoading Fail---"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
				return FALSE;
			}
			strFile.Format(_T("AutorunTrace"));
			strLog.Format(_T("Unloading End"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			strSequenceLog.Format(_T("---UnLoading End---"));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
		}
		m_bNeedUnload = FALSE;
	}
	
	// 오토론 시작할때 테이블에 기판이 없다면 align 명령을 여기서 내려준다.
	int nUsePanel;
	if(gDProject.m_nSeparation == USE_DUAL)
	{
		if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount == 1)
			nUsePanel = 1;
		else
			nUsePanel = 0;
	}
	else if(gDProject.m_nSeparation == USE_1ST)
		nUsePanel = 1;
	else
		nUsePanel = 2;

	BOOL bAlignEnd =  m_pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, TRUE, FALSE);

	if(m_bAutoRun && !gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader && !CheckPCBExist())
	{
		if( (gDProject.m_nSeparation == USE_DUAL && (!m_pMotor->IsLoaderPicker1PCBExist() || !m_pMotor->IsLoaderPicker2PCBExist())) ||
			(gDProject.m_nSeparation == USE_1ST && !m_pMotor->IsLoaderPicker1PCBExist()) ||
			(gDProject.m_nSeparation == USE_2ND && !m_pMotor->IsLoaderPicker2PCBExist()) || !bAlignEnd)
		{
#ifdef __PUSAN_LDD__
			m_pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, nUsePanel);
#else
			m_pMotor->SetOutPort(PORT_PCB_SINGLE, nUsePanel);
#endif
			strLog.Format(_T("Use panel info down : %d"), nUsePanel);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

			::Sleep(10);
			lStatus = m_pMotor->GetCurrentError(ERROR_LOAD);
			if(lStatus & 0x0004)
			{
				m_nErrMsgID = STDGNALM421;
				return FALSE;
			}
					
			BOOL bAlignCmdDone = FALSE;
			if(!m_pMotor->IsLoadCartNoPCB())
			{
				if(gDProject.m_nSeparation == USE_DUAL)
				{
					if(m_pMotor->GetCurrentLoadDetect(nUsePanel) == PCB_NONE && (m_nCurrentLotCount <= m_nInputLot - m_nNGLotCount - 2))
					{
						bAlignCmdDone = TRUE;
						m_pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, TRUE);
						strLog.Format(_T("Align on cmd down"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

					}
					else if(m_pMotor->GetCurrentLoadDetect(nUsePanel) == PCB_NONE && (m_nCurrentLotCount <= m_nInputLot - m_nNGLotCount - 1))
					{
						bAlignCmdDone = TRUE;
						m_pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, TRUE);
						strLog.Format(_T("Align on cmd down"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

					}
					else if((!m_pMotor->IsLoaderPicker1PCBExist() || !m_pMotor->IsLoaderPicker2PCBExist()) && (m_nCurrentLotCount <= m_nInputLot - m_nNGLotCount - 1)) //한쪽만 들고 있어도 마저 들어서 해야함
					{
						bAlignCmdDone = TRUE;
						m_pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, TRUE);
						strLog.Format(_T("Align on cmd down"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

					}
					
	
				}
				else if( gDProject.m_nSeparation == USE_1ST)
				{
					if(m_pMotor->GetCurrentLoadDetect(nUsePanel) == PCB_NONE && (m_nCurrentLotCount <= m_nInputLot -  1))
					{
						bAlignCmdDone = TRUE;
						m_pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, TRUE);
						strLog.Format(_T("Align on cmd down"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

					}

				}
				else
				{
					if(m_pMotor->GetCurrentLoadDetect(nUsePanel) == PCB_NONE && (m_nCurrentLotCount <= m_nInputLot - 1))
					{
						bAlignCmdDone = TRUE;
						m_pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, TRUE);
						strLog.Format(_T("Align on cmd down"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					}
				}
#ifdef __KUNSAN_SAMSUNG_LARGE__
				int nWaitTime = gProcessINI.m_sProcessOption.nAlignTime * 1000; //sec
				int nCount = 0;
				while(!m_pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, FALSE, FALSE))
				{
					if(nCount >= nWaitTime)
					{
						strLog.Format(_T("Align start signal time out"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		
						m_pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, FALSE);
						strLog.Format(_T("Align off cmd down"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

						if(m_pMotor->IsLoadCartNoPCB())
							m_nErrMsgID = STDGNALM715;
						else
							m_nErrMsgID = STDGNALM721;
						return FALSE;
					}
					if(!CheckStatus())
					{
						m_pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, FALSE);
						strLog.Format(_T("Align off cmd down"));
						::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

						return FALSE;
					}
					Sleep(100);
					nCount += 100;
				}
#endif
			}

			if(bAlignCmdDone)
			{
				CString strFile, strLog;
				strFile.Format(_T("AutorunTrace"));
				strLog.Format(_T("Align command done : %d m_nInputLot (%d), m_nNGCount (%d), m_nCurrentLotCount (%d), m_nCurrentPrjIndex (%d), m_nCurrentMarkingCount, gDProject.m_nSeparation (%d)"), 
					nUsePanel, m_nInputLot, m_nNGLotCount, m_nCurrentLotCount, m_nCurrentPrjIndex, m_nCurrentMarkingCount, gDProject.m_nSeparation);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			}
		}
		else
		{
			//m_nErrMsgID = STDGNALM1025;
			//return FALSE;
		}
		if(!bUnloadAlign)
			SendMessage(AUTO_MSG, FIRESTART_TIME);
	}

	if(!m_bAutoRun && !bUnloadAlign)
		m_pMotor->SetOutPort(PORT_CYCLE_MODE, 1);
	return TRUE;
}

BOOL CPaneAutoRun::DoPreHeatProcess()
{
	CString strFile, strLog;
	::AfxGetMainWnd()->SendMessage(UM_CHANGE_VIEW, VIEW_PREHEAT);
	::AfxGetMainWnd()->SendMessage(UM_CHANGE_PREWORK_STATUS, DO_PREHEAT);
	strLog.LoadString(IDS_PRE_START);
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));
	m_nPreworkStep = DO_PREHEAT;
			
	CCorrectTime dDrillTime;
	double dDrillSec;
	dDrillTime.StartTime();
	CTime cStartTime, cEndTime;
	cStartTime = CTime::GetCurrentTime();
	if(!OnDoPreheat())
	{
		strLog.LoadString(IDS_PRE_FAIL);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));
		m_nPreworkStep = DO_NOTING;
		return FALSE;
	}
	strLog.Format(_T("Auto Pre-Heat End"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));

	cEndTime = CTime::GetCurrentTime();
	dDrillSec = dDrillTime.PresentTime();
	SaveJobTimeLog(cStartTime.GetYear(), cStartTime.GetMonth(), cStartTime.GetDay(),
						cStartTime.GetHour(), cStartTime.GetMinute(),	cStartTime.GetSecond(),
						cEndTime.GetYear(), cEndTime.GetMonth(), cEndTime.GetDay(),
						cEndTime.GetHour(), cEndTime.GetMinute(),	cEndTime.GetSecond(), (int)dDrillSec, PREHEAT_JOB);
			
	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, TEMP_INI))
	{
		m_nErrMsgID = STDGNALM119;
		m_nPreworkStep = DO_NOTING;
		return FALSE;
	}
	m_nPreworkStep = DO_NOTING;
	return TRUE;
}

BOOL CPaneAutoRun::DoPreworkPowerProcess()
{
	CString strFile, strLog;
	::AfxGetMainWnd()->SendMessage(UM_CHANGE_VIEW, VIEW_POWER);
	::AfxGetMainWnd()->SendMessage(UM_CHANGE_PREWORK_STATUS, DO_POWER);
	strLog.LoadString(IDS_POWER_START);
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));
		
	m_nPreworkStep = DO_POWER;
	BOOL bTempRunOK = OnDoPowerMeasurement();
	if(!bTempRunOK)
	{
		if(m_nErrMsgID == STDGNALM707 || m_nErrMsgID == STDGNALM708 ) 
		{
			m_nErrMsgID = 0;
			if(!DoPreHeatProcess())
			{
				m_nPreworkStep = DO_NOTING;
				return FALSE;
			}
				
			if(!CheckStatus())
			{
				m_nPreworkStep = DO_NOTING;
				return FALSE;
			}

			::AfxGetMainWnd()->SendMessage(UM_CHANGE_VIEW, VIEW_POWER);
			::AfxGetMainWnd()->SendMessage(UM_CHANGE_PREWORK_STATUS, DO_POWER);
			strLog.LoadString(IDS_POWER_START);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));
	
			m_nPreworkStep = DO_POWER;
			if(!OnDoPowerMeasurement())
			{
				strLog.LoadString(IDS_POWER_FAIL);
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));
				m_nPreworkStep = DO_NOTING;
				return FALSE;
			}
			else
			{
				m_bDoAutoPower = FALSE;
				m_bAnyDoAutoPower = FALSE;
				strLog.Format(_T("Auto Power Measure End"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));
				strFile.Format(_T("PreWork"));
				strLog.Format(_T("Auto Power End 1: m_bDoAutoPower , m_bAnyDoAutoPower = False"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			}
		}
		else
		{
			strLog.LoadString(IDS_POWER_FAIL);
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));
			m_nPreworkStep = DO_NOTING;
			return FALSE;
		}
	}

	m_bDoAutoPower = FALSE;
	m_bAnyDoAutoPower = FALSE;

	strLog.Format(_T("Auto Power Measure End"));
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));

	strFile.Format(_T("PreWork"));
	strLog.Format(_T("Auto Power End 2: m_bDoAutoPower , m_bAnyDoAutoPower = False"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, TEMP_INI))
	{
		m_nErrMsgID = STDGNALM119;
		m_nPreworkStep = DO_NOTING;
		return FALSE;
	}

	m_nPreworkStep = DO_NOTING;
	return TRUE;
}

BOOL CPaneAutoRun::DoPreworkSCalProcess(BOOL bOnlyCenterPointFire, int nFireAndFindMode)
{
	CString strFile, strLog;
	m_bWorkingAutoSCal = TRUE;
	::AfxGetMainWnd()->SendMessage(UM_CHANGE_VIEW, VIEW_FIDUCIAL);
	::AfxGetMainWnd()->SendMessage(UM_CHANGE_PREWORK_STATUS, DO_SCANNER);
	strLog.LoadString(IDS_SCAL_START);
	::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));

	m_nPreworkStep = DO_SCANNER;

	CCorrectTime dDrillTime;
	double dDrillSec;
	dDrillTime.StartTime();
	CTime cStartTime, cEndTime;
	cStartTime = CTime::GetCurrentTime();

	if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, TRUE);

	int nFireMode = FIND_ALL_MODE;

	if(bOnlyCenterPointFire)
	{
		if(gProcessINI.m_sProcessOption.nTemperMeasureMode || gProcessINI.m_sProcessOption.bTemperVerifyMode)
			nFireMode = FIND_4_EDGE_MODE;
		else
			nFireMode = FIND_ONLY_CENTER_MODE;
	}

	if(DoSCalAuto(FALSE, TRUE, nFireMode, nFireAndFindMode))
	{
		m_bWorkingAutoSCal = FALSE;
		m_bAnyDoAutoSCal = FALSE;
		m_bDoAutoSCal = FALSE;
		m_bPreScanner = FALSE;

		CString strFile, strLog;
		strFile.Format(_T("PreWork"));
		strLog.Format(_T("Auto Scanner End 1: m_bWorkingAutoSCal , m_bAnyDoAutoSCal , m_bDoAutoSCal , m_bPreScanner = False"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		if(!gDeviceFactory.GetEocard()->DownloadShotDrillScannerParam())
		{
			if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
				::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);
			m_nErrMsgID = STDGNALM445;
			m_nPreworkStep = DO_NOTING;
			return FALSE;
		}
	}
	else
	{
		strLog.LoadString(IDS_SCAL_FAIL);
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strLog));

		if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
			::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);
		
		if(gProcessINI.m_sProcessOption.bTemperCompensationMode)
		{
			if(bOnlyCenterPointFire && 
				!(gProcessINI.m_sProcessOption.nTemperCompenGridNo == 2 && gProcessINI.m_sProcessOption.bTemperVerifyMode))
					
				m_nErrMsgID = STDGNALM759;
		}
		m_nPreworkStep = DO_NOTING;
		return FALSE;
	}
	if(gSystemINI.m_sHardWare.bUseWideMonitor && !gProcessINI.m_sProcessSystem.bNoUseFiducialFind)
		::AfxGetMainWnd()->SendMessage(UM_SIDE_WINDOW, WIDE_VISION, FALSE);

	cEndTime = CTime::GetCurrentTime();
	dDrillSec = dDrillTime.PresentTime();
	SaveJobTimeLog(cStartTime.GetYear(), cStartTime.GetMonth(), cStartTime.GetDay(),
					cStartTime.GetHour(), cStartTime.GetMinute(),	cStartTime.GetSecond(),
					cEndTime.GetYear(), cEndTime.GetMonth(), cEndTime.GetDay(),
					cEndTime.GetHour(), cEndTime.GetMinute(),	cEndTime.GetSecond(), (int)dDrillSec, SCAL_JOB);

	m_nPreworkStep = DO_NOTING;
	return TRUE;
}

BOOL CPaneAutoRun::PreDoPrework()
{
	BOOL bScalDo = FALSE;
	CString strFile, strLog;
	m_nPreworkStep = DO_NOTING;
#ifdef __OSAN_LG__
	if((!gProcessINI.m_sProcessSystem.bNoUsePrework) )
#else
	if((!gProcessINI.m_sProcessSystem.bNoUsePrework && !gProcessINI.m_sProcessSystem.bDryRun) )
#endif
	{
		::AfxGetMainWnd()->SendMessage(UM_DRAW_DOING_PREWORK, TRUE); //Doing Prework draw timer init  


		if(m_bPreScanner || m_bAnyDoAutoSCal || m_bDoAutoSCal)
		{
			bScalDo = TRUE;
			if(!DoPreworkSCalProcess(FALSE))
			{
				if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
				{
					return FALSE;
				}
				return FALSE;
			}
		}
		if(!CheckStatus())
		{
			return FALSE;
		}

#ifdef __OSAN_LG__ //osan only use s.cal
		m_bDoAutoPreheat = FALSE;
#endif
		if(m_bDoAutoPreheat) //drill end time도 스레드에서 검사 
		{
			if(!DoPreHeatProcess())
				return FALSE;
			m_bDoAutoPreheat = FALSE;

			strFile.Format(_T("PreWork"));
			strLog.Format(_T("PreHeat End : m_bDoAutoPreheat = False"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		}
		if(!CheckStatus())
		{
			return FALSE;
		}
#ifdef __OSAN_LG__ //osan only use s.cal
		m_bDoAutoPower = FALSE;
		m_bAnyDoAutoPower = FALSE;
#endif
		if(m_bDoAutoPower || m_bAnyDoAutoPower)
		{
			if(!DoPreworkPowerProcess())
				return FALSE;
		}
		if(!CheckStatus())
		{
			return FALSE;
		}

		
		
		m_nPreworkStep = DO_NOTING;	
		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, TEMP_INI))
		{
			m_nErrMsgID = STDGNALM119;
			return FALSE;
		}
		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
		{
			m_nErrMsgID = STDGNALM108;
			return FALSE;
		}
	}

	if(!bScalDo && gProcessINI.m_sProcessSystem.bEveryPanelVisionHeadOffsetCheck && !gProcessINI.m_sProcessSystem.bDryRun)
	{
		int nRepeatCompenCnt = (int)(pow(2., m_nTempCompenCurrentLotCount));
		if( (m_nTempCompenCurrentLotCount % gProcessINI.m_sProcessOption.nTempCompenVerifyLotCount == 0) ||
			(nRepeatCompenCnt &  gProcessINI.m_sProcessOption.nTempRepeatCompenLotCount)) // repeat 보정이나 검증 count 일때만 수행
		{
			BOOL bResult =  DoPreworkSCalProcess(TRUE);
			if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
			{
				m_nErrMsgID = STDGNALM108;
				return FALSE;
			}
			return bResult;
		}
	}

	if(!CheckStatus())
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CPaneAutoRun::DummyfreeOnFor2ndOrderOption()
{
	if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && !gSystemINI.m_sHardWare.nUseFirstOrder)
	{
		if(!gDeviceFactory.GetEocard()->IsStannbyShotRun())
		{
			if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(TRUE))
			{
				m_nErrMsgID = STDGNALM781;
				return FALSE;
			}
			::Sleep(100);
			if(!gDeviceFactory.GetEocard()->IsStannbyShotRun())
			{
				m_nErrMsgID = STDGNALM781;
				return FALSE;
			}
			m_StandbyTime.StartTime();
		}
	}
	if(!CheckStatus())
	{
		return FALSE;
	}
	return TRUE;
}

void CPaneAutoRun::SetLastBoardBit()
{
	if(gDProject.m_nSeparation == USE_DUAL)
	{
		if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount == 1)
		{
			m_bOdd = TRUE;
			m_bEndBoard = TRUE;
		}
		else
		{
			m_bOdd = FALSE;
			if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount == 2)
				m_bEndBoard = TRUE;
			else
				m_bEndBoard = FALSE;
		}
	}
	else
	{
		if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount == 1)
			m_bEndBoard = TRUE;
		else
			m_bEndBoard = FALSE;
	}

	if(!gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader && m_bAutoRun)
	{
		CString strFile, strLog;
		strFile.Format(_T("AutorunTrace"));
		strLog.Format(_T("Loading/Drill Info : m_nInputLot (%d), m_nCurrentLotCount (%d), m_nCurrentPrjIndex (%d), m_nNGLotCount(%d), m_nCurrentMarkingCount, gDProject.m_nSeparation (%d)"), 
			m_nInputLot, m_nCurrentLotCount, m_nCurrentPrjIndex, m_nNGLotCount, m_nCurrentMarkingCount, gDProject.m_nSeparation);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
}

BOOL CPaneAutoRun::DoLoadingProcess()
{
	m_bAlignCommandDoneAfterLoading = FALSE;
	CString strSequenceLog;
	if(!gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader && m_bAutoRun)
	{	
		m_bAlreadyLoading = TRUE;
		if(!CheckPCBExist())
		{
			if(!CheckStatus())
				return FALSE;

			if(!DoLoading(m_bEndBoard, this))
			{
				strSequenceLog.Format(_T("---Loading Fail---"));
				::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
				return FALSE;
			}
			strSequenceLog.Format(_T("---Loading End---"));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));

			if(m_nCurrentLotCount == 0)
				OPCEvent(TRUE, TRUE);
			else
				OPCEvent(TRUE, FALSE);

		}
	}

	OPCUpdateParameter(N_VACUUM);
	
	//Loading End ->  Unloading Start : Marking Time 
	if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
	{
		if(!SuctionCheck(TRUE))
		{
			m_nErrMsgID = STDGNALM423;
			return FALSE;
		}
	}
	MessageLoop();

	// align command
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	int nDualAlignTime, nSingleAlignTime;
	if(gProcessINI.m_sProcessSystem.bNoUsePaper)
	{
		nDualAlignTime = gProcessINI.m_sProcessOption.nAlignDualTimeOnlyPCB;
		nSingleAlignTime = gProcessINI.m_sProcessOption.nAlignSingleTimeOnlyPCB;
	}
	else
	{
		nDualAlignTime = gProcessINI.m_sProcessOption.nAlignDualTime;
		nSingleAlignTime = gProcessINI.m_sProcessOption.nAlignSingleTime;
	}
	double dVibrationTime =0;
	if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd) //20130502 bskim
		dVibrationTime = gSystemINI.m_sSystemDevice.nVibrationCount * 2 + (double)gSystemINI.m_sSystemDevice.nVibrationLPTime * 2;
	else
		dVibrationTime = gSystemINI.m_sSystemDevice.nVibrationCount + (double)gSystemINI.m_sSystemDevice.nVibrationLPTime;
	

	int nAlignStartPercent = gProcessINI.m_sProcessOption.nAlignStartPer; // % -> sec
	BOOL bMarkingTimeOK = FALSE;
	double dCompareTime;
	
	
	if(m_dAvgMarkingTime != 0)
	{
		dCompareTime = m_dAvgMarkingTime - nAlignStartPercent  - dVibrationTime - 10; 
		if(dCompareTime < 0 )
			dCompareTime = 0; 
	}
	else //요거 안하면 음수값 퓨퓨 
		dCompareTime = 0;
	int nLoop = 0;

	double dMarkingTimeWait = m_dAvgMarkingTime - dCompareTime;
	if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd) //20130502 bskim
	{
		if(nDualAlignTime + dVibrationTime > dMarkingTimeWait)
			dCompareTime = m_dAvgMarkingTime - nDualAlignTime - dVibrationTime - 10 ;
	}
	else
	{
		if(nSingleAlignTime + dVibrationTime > dMarkingTimeWait)
			dCompareTime = m_dAvgMarkingTime - nSingleAlignTime - dVibrationTime - 10 ;
	}

	if(dCompareTime < 0 )
		dCompareTime = 0;

	CString strFile, strLog;
	int nUsePanel;
	if(gDProject.m_nSeparation == USE_DUAL) //20130502 bskim
	{
		if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount == 3)
			nUsePanel = 1;
		else
			nUsePanel = 0;
	}
	else if(gDProject.m_nSeparation == USE_1ST)
		nUsePanel = 1;
	else
		nUsePanel = 2;

	strFile.Format(_T("AutorunTrace"));
	CString strstr;
	strstr.Format(_T("0.1. Current Lot Count[%d] = %d, Input Lot Count = %d, NGCount = %d, dCompareTime = %.2f, nUsePanel = %d, GetCurrentLoadDetect(nUsePanel) = %d, IsLoadCartNoPCB() = %d "), m_nCurrentLotIndex, m_nCurrentLotCount, m_nInputLot, m_nNGLotCount, dCompareTime, nUsePanel, pMotor->GetCurrentLoadDetect(nUsePanel), pMotor->IsLoadCartNoPCB());
	strLog = strstr;
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	BOOL b1st = m_pMotor->IsTable1PCBExist();
	BOOL b2nd = m_pMotor->IsTable2PCBExist();

	if(!gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader && m_bAutoRun)
	{
		LONG lStatus = m_pMotor->GetCurrentError(ERROR_LOAD);
		if(lStatus & 0x0004)
		{
			strstr.Format(_T("Error load detect"));
			strLog = strstr;
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			::Sleep(0);
		}
		else 
		{	
			if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
			{
				if(pMotor->GetCurrentLoadDetect(nUsePanel) == PCB_NONE && (m_nCurrentLotCount < m_nInputLot - m_nNGLotCount - 2) )
				{	
					if( m_nCurrentLotCount < 2 || dCompareTime  <= 0.1)
					{
						if(!pMotor->IsLoadCartNoPCB())
						{
							if(m_nInputLot - m_nNGLotCount - m_nCurrentLotCount == 3)
							{
#ifdef __PUSAN_LDD__
								pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, 1);
#else
								pMotor->SetOutPort(PORT_PCB_SINGLE, 1);
#endif
								strFile.Format(_T("AutorunTrace"));
								strLog.Format(_T("Use panel info down : 1"));
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							}
							else
							{
#ifdef __PUSAN_LDD__
								pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, 0);
#else
								pMotor->SetOutPort(PORT_PCB_SINGLE, 0);
#endif
								strFile.Format(_T("AutorunTrace"));
								strLog.Format(_T("Use panel info down : 0"));
								::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
							}
							pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, TRUE);
							
							strFile.Format(_T("AutorunTrace"));
							strLog.Format(_T("Align on cmd down"));
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

						}
						m_bAlignCommandDoneAfterLoading = TRUE;
					}
				}
			}
			else if(gDProject.m_nSeparation == USE_1ST)
			{
				if(pMotor->GetCurrentLoadDetect(nUsePanel) == PCB_NONE && (m_nCurrentLotCount < m_nInputLot - m_nNGLotCount - 1))
				{
					if( m_nCurrentLotCount < 1 || dCompareTime  <= 0.1)
					{
						if(!pMotor->IsLoadCartNoPCB())
						{
#ifdef __PUSAN_LDD__
							pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, TRUE);
#else
							pMotor->SetOutPort(PORT_PCB_SINGLE, TRUE);
#endif
							strFile.Format(_T("AutorunTrace"));
							strLog.Format(_T("Use panel info down : 1"));
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

							pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, TRUE );
							
							strLog.Format(_T("Align on cmd down"));
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

						}
						m_bAlignCommandDoneAfterLoading = TRUE;
					}
				}				
			}
			else
			{
				if(pMotor->GetCurrentLoadDetect(nUsePanel) == PCB_NONE && (m_nCurrentLotCount < m_nInputLot - m_nNGLotCount - 1))
				{
					if(m_nCurrentLotCount < 1 || dCompareTime  <= 0.1)
					{
						if(!pMotor->IsLoadCartNoPCB())
						{
#ifdef __PUSAN_LDD__
							pMotor->SetOutPort(ADD0B_WRITE_OUTPORT + PORT_PCB_SINGLE, 2);
#else
							pMotor->SetOutPort(PORT_PCB_SINGLE, 2);
#endif
							strFile.Format(_T("AutorunTrace"));
							strLog.Format(_T("Use panel info down : 2"));
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

							pMotor->HandlerOperation(HANDLER_LOADER_ALIGN, TRUE);
							
							
							strLog.Format(_T("Align on cmd down"));
							::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

						}
						m_bAlignCommandDoneAfterLoading = TRUE;
					}
				}						
			}
		}
	}
	return TRUE;
}

BOOL CPaneAutoRun::DoCheckPCBThickProcess()
{
	CString strSequenceLog;
#ifdef  __KUNSAN_6__
	if((m_bAutoRun && m_nCurrentLotCount == 0) || gProcessINI.m_sProcessSystem.bEveryPanelThicknessMeasurement)
#elif defined   __KUNSAN_8__
	if((m_bAutoRun && m_nCurrentLotCount == 0) || gProcessINI.m_sProcessSystem.bEveryPanelThicknessMeasurement)
#elif defined   __KUNSAN_1__
	if((m_bAutoRun && m_nCurrentLotCount == 0) || gProcessINI.m_sProcessSystem.bEveryPanelThicknessMeasurement)
#elif defined   __KUNSAN_2012__
	if((m_bAutoRun && m_nCurrentLotCount == 0) || gProcessINI.m_sProcessSystem.bEveryPanelThicknessMeasurement)
#elif defined   __KUNSAN_2013__
	if((m_bAutoRun && m_nCurrentLotCount == 0) || gProcessINI.m_sProcessSystem.bEveryPanelThicknessMeasurement)
#else
	if(m_bAutoRun && !gProcessINI.m_sProcessSystem.bDryRunNoPCB && (m_nCurrentLotCount == 0 || gProcessINI.m_sProcessSystem.bEveryPanelThicknessMeasurement))
#endif
	{			
		if(!ThickMeasurement())
		{
			strSequenceLog.Format(_T("---Thick Measurement Fail---"));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
			return FALSE;
		}
		strSequenceLog.Format(_T("---Thick Measurement End---"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
	}
	if(!CheckStatus())
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CPaneAutoRun::CheckDummyfreeOn()
{
	if(!gProcessINI.m_sProcessSystem.bDryRun && gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE)
	{
		if(!gDeviceFactory.GetEocard()->IsStannbyShotRun() && m_bUserDummyOn)
		{
#ifndef __TEST__
			m_nErrMsgID = STDGNALM781;
			return FALSE;
#endif
		}
	}
	return TRUE;
}

BOOL CPaneAutoRun::DrillOneBoardProcess()
{
	m_nTempCompenCurrentLotCount++;
//	if(gProcessINI.m_sProcessSystem.bFailFidCountinue)
		m_nBackupSeparation = gDProject.m_nSeparation;
	m_bChangePanelInfo = FALSE;

	CString strFile, strLog;
	::AfxGetMainWnd()->SendMessage(UM_CHANGE_PREWORK_STATUS, DO_DRILL);

	m_bCanCheckTransValid = TRUE; // 20130312

	CCorrectTime dDrillTime;
	double dDrillSec;
	dDrillTime.StartTime();
	CTime cStartTime, cEndTime;
	cStartTime = CTime::GetCurrentTime();
	m_bCheckTablePCB = TRUE;
	m_pMotor->HandlerOperation(UI_DIRLL_STATUS_SET, TRUE);
	if(DrillOneBoard())
	{
		m_pMotor->HandlerOperation(UI_DIRLL_STATUS_SET, FALSE);
		m_bCheckTablePCB = FALSE;
		if(m_bAutoRun && !gProcessINI.m_sProcessSystem.bDryRun)
		{
			time_t timeDrillEnd;
			time(&timeDrillEnd);
			gProcessINI.m_sProcessCal.nDrillEndTime = (int)timeDrillEnd;
			if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
			{
				m_nErrMsgID = STDGNALM108;
				return FALSE;
			}
			::AfxGetMainWnd()->SendMessage(UM_INI_UI_UPDATE, PROCESS_PREWORK);
		}
	}
	else
	{
		m_pMotor->HandlerOperation(UI_DIRLL_STATUS_SET, FALSE);
		m_bCheckTablePCB = FALSE;
		cEndTime = CTime::GetCurrentTime();
		dDrillSec = dDrillTime.PresentTime();
		SaveJobTimeLog(cStartTime.GetYear(), cStartTime.GetMonth(), cStartTime.GetDay(),
						cStartTime.GetHour(), cStartTime.GetMinute(),	cStartTime.GetSecond(),
						cEndTime.GetYear(), cEndTime.GetMonth(), cEndTime.GetDay(),
						cEndTime.GetHour(), cEndTime.GetMinute(),	cEndTime.GetSecond(), (int)dDrillSec, DRILL_JOB);

		if(m_bFireDataDoing)
		{
			m_nAutoLotCount++;
			if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
				m_nAutoLotCount++;

			m_bMissFire = TRUE;
		}
		return FALSE;
	}

	cEndTime = CTime::GetCurrentTime();
	dDrillSec = dDrillTime.PresentTime();
	SaveJobTimeLog(cStartTime.GetYear(), cStartTime.GetMonth(), cStartTime.GetDay(),
					cStartTime.GetHour(), cStartTime.GetMinute(),	cStartTime.GetSecond(),
					cEndTime.GetYear(), cEndTime.GetMonth(), cEndTime.GetDay(),
					cEndTime.GetHour(), cEndTime.GetMinute(),	cEndTime.GetSecond(), (int)dDrillSec, DRILL_JOB);

	strFile.Format(_T("RunTime"));
	strLog.Format(_T("Table Time : %.3f"), m_dTableTime);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	strLog.Format(_T("Scanner Time : %.3f"), m_dScannerTime);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	this->SendMessage(AUTO_MSG, FIREENDDRILL_TIME);

	MessageLoop();
		



	//MC mode에서만 오터런 테스트를 위해 임의로 ng 설정할 수 있게 함
	if(gSystemINI.m_sHardWare.bCheckMCMode)
	{
		CDlgNGInfo dlg;
 		if(IDOK == dlg.DoModal())
		{
			m_nNGBoxCondition = dlg.GetUseSetNGInfo();
				NGBoxCheck(m_nNGBoxCondition);
		}
	}



	m_nAutoLotCount++;
		
	if(gDProject.m_nSeparation == USE_DUAL && !m_bOdd)
		m_nAutoLotCount++;

	int nPrjIndex = m_nCurrentPrjIndex;
#ifdef __KUNSAN_SAMSUNG_LARGE__
	if(m_bAutoRun )//&&
		this->SendMessage(AUTO_MSG, FIRENEXT_TIME); //다음 프로젝트 오픈
	else
		m_bMissFire = TRUE;
#else
	this->SendMessage(AUTO_MSG, FIRENEXT_TIME); //다음 프로젝트 오픈
#endif
	this->SendMessage(AUTO_MSG, FIRECYCLEE_TIME);

	if((m_nBackupSeparation == USE_DUAL && m_nNGBoxCondition == 3) || 
		(m_nBackupSeparation == USE_1ST && m_nNGBoxCondition == 1 ) ||
		(m_nBackupSeparation == USE_2ND && m_nNGBoxCondition == 2))
	{
		if(!PreLoadUnloadRun(TRUE))
			return FALSE;
	}

	if(gProcessINI.m_sProcessSystem.bNoUseNGBox)
	{
		if(gProcessINI.m_sProcessSystem.bFailFidCountinue && m_bChangePanelInfo)
		{
			m_nErrMsgID = STDGNALM666;
			return FALSE;
		}
	}
	else
	{
		if(nPrjIndex == m_nCurrentPrjIndex) 
			gDProject.m_nSeparation = m_nBackupSeparation;
	}
	return TRUE;
}

BOOL CPaneAutoRun::DoUnloadingProcess()
{
	if(!gProcessINI.m_sProcessSystem.bNoUseLoaderUnloader && m_bAutoRun)
	{
		CString strFile, strLog, strSequenceLog;
		LONG lStatus = m_pMotor->GetCurrentError(ERROR_UNLOAD3);
		if(lStatus & 0x1000)
		{
			m_nErrMsgID = STDGNALM565;
			return FALSE;
		}

		if(!CheckStatus())
			return FALSE;

		//Loading End ->  Unloading Start : Marking Tiime 
		this->SendMessage(AUTO_MSG, FIREMARKINGEND_TIME);

		strSequenceLog.Format(_T("---Unloading Start---"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
		if(!DoUnloading(m_bEndBoard))
		{
			strSequenceLog.Format(_T("---UnLoading Fail---"));
			::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));
			return FALSE;
		}

		strFile.Format(_T("AutorunTrace"));
		strLog.Format(_T("Unloading End"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		strSequenceLog.Format(_T("---UnLoading End---"));
		::AfxGetMainWnd()->SendMessage(UM_LOG_MESSAGE, reinterpret_cast<WPARAM>(&strSequenceLog));

		if(m_bEndBoard) 	
			OPCEvent(FALSE, TRUE);
		else
			OPCEvent(FALSE, FALSE);
	}
	else
	{
		if(m_bAlreadyLoading)
		{
			int nVal[16];
			m_pMotor->ReadAllError(nVal);
			m_bAlreadyLoading = FALSE;
			CString strFile, strLog;
			m_nErrMsgID = STDGNALM1080;
			strFile.Format(_T("AutorunTrace"));
			strLog.Format(_T("Error No : %d, %d, %d, %d,     %d, %d, %d, %d,     %d, %d, %d, %d,     %d, %d, %d, %d"), 
				nVal[0], nVal[1], nVal[2], nVal[3],
				nVal[4], nVal[5], nVal[6], nVal[7],
				nVal[8], nVal[9], nVal[10], nVal[11],
				nVal[12], nVal[13], nVal[14], nVal[15]);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			return FALSE;
		}
	}

/*	if(gProcessINI.m_sProcessSystem.bNoUseNGBox)
	{
		if(gProcessINI.m_sProcessSystem.bFailFidCountinue && m_bChangePanelInfo)
		{
			m_nErrMsgID = STDGNALM666;
			return FALSE;
		}
	}
	*/ // 다시 체크필요 ejpark 
	if(m_bEndBoard)
	{
		if(gDeviceFactory.GetMotor()->IsLoadCartNoPCB()) // 20131008 언로딩 중에 자재체크 신호를 주어서 이 루틴이 정상 동작하도록 수정해야함.
		{
			m_nErrMsgID = STDGNALM805; // 자재가 남았다는 경고는 띄우지만 가공은 정상 완료임.
		}
	}
	if(gProcessINI.m_sProcessSystem.bUseScheduling)
	{		
		if(m_bEndBoard)
		{
			if( gLotInfo.nComSol[m_nCurrentPrjIndex] == 2 || gLotInfo.nComSol[m_nCurrentPrjIndex] == 3)
			{
				CString strFile, strLog;
				strFile.Format(_T("AutorunTrace"));
				strLog.Format(_T("Reverse Info : m_bEndBoard %d, m_nCurrentLotCount %d, m_nInputLot %d, m_nNGLotCount %d "), m_bEndBoard, m_nCurrentLotCount, m_nInputLot,m_nNGLotCount );
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	//			if(m_nCurrentLotCount != m_nInputLot - m_nNGLotCount)
				{
					Sleep(1000); //need turn time 
					int nCount = 0;
					while(!gDeviceFactory.GetMotor()->GetReverseReady())
					{
						if(nCount >= 2000)
						{
							m_nErrMsgID = STDGNALM1147;
							return FALSE;
						}
						if(!CheckStatus())
							return FALSE;
						Sleep(5);
						nCount += 20;
					}

					BOOL bDirect = gDeviceFactory.GetMotor()->GetReverseDirection();
#ifndef __MP920_MOTOR__
					gDeviceFactory.GetMotor()->TablePCBReset();
					::Sleep(1000);
#endif
					gDeviceFactory.GetMotor()->SetReverseDirection(!bDirect);

			
					strFile.Format(_T("AutorunTrace"));
					strLog.Format(_T("Reverse cmd down : %d"), !bDirect);
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	//				PreLoadUnloadRun(TRUE); // 20131001 프로젝트 하나씩 끊어서 가공함.
				}
			}
		}
	}

	if(!CheckStatus())
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CPaneAutoRun::VerifyTemperComp()
{
	m_bPostPreWorkDoing = TRUE;
	m_nPreworkStep = DO_NOTING;

	if(gProcessINI.m_sProcessSystem.bEveryPanelVisionHeadOffsetCheck && !gProcessINI.m_sProcessSystem.bDryRun)
	{
		int nRepeatCompenCnt = (int)(pow(2., m_nTempCompenCurrentLotCount));
		if( (m_nTempCompenCurrentLotCount % gProcessINI.m_sProcessOption.nTempCompenVerifyLotCount == 0) ||
			(nRepeatCompenCnt &  gProcessINI.m_sProcessOption.nTempRepeatCompenLotCount)) // repeat 보정이나 검증 count 일때만 수행
		{
			BOOL bResult =  DoPreworkSCalProcess(TRUE);
			if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
			{
				m_nErrMsgID = STDGNALM108;
				m_bPostPreWorkDoing = FALSE;
				return FALSE;
			}
			m_bPostPreWorkDoing = FALSE;
			return bResult;
		}
	}
	m_bPostPreWorkDoing = FALSE;

	if(!CheckStatus())
		return FALSE;

	return TRUE;
}

BOOL CPaneAutoRun::PostDoPrework()
{
	BOOL bScalDo = FALSE;
	m_bPostPreWorkDoing = TRUE;
	CString strFile, strLog;
	m_nPreworkStep = DO_NOTING;
	BOOL bEndLot;
	if(gProcessINI.m_sProcessCal.bPowerEndLot)
	{
		if(m_nCurrentLotCount == m_nInputLot - m_nNGLotCount)
			bEndLot= TRUE;
		else
			bEndLot = FALSE;
	}
	else
		bEndLot = FALSE;
#ifdef __OSAN_LG__
 	if(!gProcessINI.m_sProcessSystem.bNoUsePrework && m_nCurrentLotCount != m_nInputLot)
#else
	if((!gProcessINI.m_sProcessSystem.bNoUsePrework && !gProcessINI.m_sProcessSystem.bDryRun) || bEndLot)
#endif
	{
		if(m_bDoAutoSCal)
		{
			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && !gSystemINI.m_sHardWare.nUseFirstOrder)
			{
				::Sleep(100);
				if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
				{
					strFile.Format(_T("ReadHole"));
					strLog.Format(_T("Standby Shot stop Error"));
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					m_nErrMsgID = STDGNALM781;
					m_bPostPreWorkDoing = FALSE;
					return FALSE;
				}
				m_StandbyTime.Finish();
			}
			bScalDo = TRUE;
			if(!DoPreworkSCalProcess(FALSE))
			{
				m_bPostPreWorkDoing = FALSE;
				if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
				{
					m_nErrMsgID = STDGNALM108;
					return FALSE;
				}
				return FALSE;
			}

			strFile.Format(_T("PreWork"));
			strLog.Format(_T("Auto Scanner End 2: m_bWorkingAutoSCal , m_bDoAutoSCal = False"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		}
		#ifdef __OSAN_LG__
		m_bDoAutoPower = FALSE;
		m_bAnyDoAutoPower = FALSE;
#endif
		if(m_bDoAutoPower || m_bAnyDoAutoPower || bEndLot)
		{
			if(gSystemINI.m_sSystemDump.nUseDummyType == DUMMY_FREE && !gSystemINI.m_sHardWare.nUseFirstOrder)
			{
				::Sleep(100);
				if(!gDeviceFactory.GetEocard()->DrillStandbyShotStart(FALSE))
				{
					strFile.Format(_T("ReadHole"));
					strLog.Format(_T("Standby Shot stop Error"));
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
					m_nErrMsgID = STDGNALM781;
					m_bPostPreWorkDoing = FALSE;
					return FALSE;
				}
				m_StandbyTime.Finish();
			}
			if(!DoPreworkPowerProcess())
			{
				m_bPostPreWorkDoing = FALSE;
				return FALSE;
			}
						
			strFile.Format(_T("PreWork - PostDoPrework"));
			strLog.Format(_T("Auto Power End: m_bDoAutoPower , m_bAnyDoAutoPower = False"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		}
			
		if(!CheckStatus())
		{
			m_bPostPreWorkDoing = FALSE;
			return FALSE;
		}

		m_nPreworkStep = DO_NOTING;
		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, TEMP_INI))
		{
			m_nErrMsgID = STDGNALM119;
			m_bPostPreWorkDoing = FALSE;
			return FALSE;
		}
		if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
		{
			m_nErrMsgID = STDGNALM108;
			m_bPostPreWorkDoing = FALSE;
			return FALSE;
		}
	}
	else
		m_nPreworkStep = DO_NOTING;

	if(gProcessINI.m_sProcessOption.nTemperCompenGridNo != 2 || !gProcessINI.m_sProcessOption.bTemperVerifyMode)
	{
		if(!bScalDo && gProcessINI.m_sProcessSystem.bEveryPanelVisionHeadOffsetCheck && !gProcessINI.m_sProcessSystem.bDryRun)
		{
			int nRepeatCompenCnt = (int)(pow(2., m_nTempCompenCurrentLotCount));
			if( (m_nTempCompenCurrentLotCount % gProcessINI.m_sProcessOption.nTempCompenVerifyLotCount == 0) ||
				(nRepeatCompenCnt &  gProcessINI.m_sProcessOption.nTempRepeatCompenLotCount)) // repeat 보정이나 검증 count 일때만 수행
			{
				BOOL bResult =  DoPreworkSCalProcess(TRUE);
				if(!::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI))
				{
					m_nErrMsgID = STDGNALM108;
					m_bPostPreWorkDoing = FALSE;
					return FALSE;
				}
				m_bPostPreWorkDoing = FALSE;
				return bResult;
			}
		}
	}
	m_bPostPreWorkDoing = FALSE;

	if(!CheckStatus())
	{
		return FALSE;
	}
	return TRUE;
}

void CPaneAutoRun::CheckInpositionError(int nAxis, BOOL bShow)
{
	switch(nAxis)
	{
	case IND_X : m_nErrMsgID = STDGNALM404; break;
	case IND_Y : m_nErrMsgID = STDGNALM405; break;
	case IND_Z1 : m_nErrMsgID = STDGNALM406; break;
	case IND_Z2 : m_nErrMsgID = STDGNALM407; break;
	case IND_M1 : m_nErrMsgID = STDGNALM408; break;
	case IND_M2 : m_nErrMsgID = STDGNALM409; break;
	case IND_M3 : m_nErrMsgID = STDGNALM990; break;
	case IND_C1 : m_nErrMsgID = STDGNALM410; break;
	case IND_C2 : m_nErrMsgID = STDGNALM411; break;
	}

	if(bShow)
		ErrMsgDlg(m_nErrMsgID);
}
void CPaneAutoRun::CalculateAvgScale()
{
	if(gDProject.m_nSeparation != USE_2ND)
	{
		CString strFile, strLog;
		strFile.Format(_T("AverageScale"));
		if(gDProject.m_nSeparation == USE_1ST || (gDProject.m_nSeparation == USE_DUAL && m_bOdd == TRUE))
		{
			strLog.Format(_T("1st panel : AvgScale X\t%.5f\tY\t%.5f \tM.Current X\t%.5f\tY\t%.5f\tCurrent Count\t%d"), m_dAvgScaleX, m_dAvgScaleY, m_dCurrentScaleX[0], m_dCurrentScaleY[0], m_nCurrentLotCount);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		}
		else
		{
			strLog.Format(_T("1st panel : AvgScale X\t%.5f\tY\t%.5f \tM.Current X\t%.5f\tY\t%.5f\tS.Current X\t%.5f\tY\t%.5f\tCurrent Count\t%d"), m_dAvgScaleX, m_dAvgScaleY, m_dCurrentScaleX[0], m_dCurrentScaleY[0], m_dCurrentScaleX[1], m_dCurrentScaleY[1], m_nCurrentLotCount);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		}
		if(m_dAvgScaleX != 100) // 처음이 아니면
		{
			if(gDProject.CheckScalVal(m_dCurrentScaleX[0], m_dCurrentScaleY[0]))
			{
				strLog.Format(_T("1st panel : Modified"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				m_dAvgScaleX = (m_dCurrentScaleX[0] + (m_dAvgScaleX * m_nCurrentLotCount)) / (m_nCurrentLotCount + 1);
				m_dAvgScaleY = (m_dCurrentScaleY[0] + (m_dAvgScaleY * m_nCurrentLotCount)) / (m_nCurrentLotCount + 1);
			}
		}
		else
		{
			m_dAvgScaleX = (m_dCurrentScaleX[0] + (m_dAvgScaleX * m_nCurrentLotCount)) / (m_nCurrentLotCount + 1);
			m_dAvgScaleY = (m_dCurrentScaleY[0] + (m_dAvgScaleY * m_nCurrentLotCount)) / (m_nCurrentLotCount + 1);
		}
	}
	else 
	{
		CString strFile, strLog;
		strFile.Format(_T("AverageScale"));
		strLog.Format(_T("2nd panel : AvgScale X\t%.5f\tY\t%.5f \tS.Current X\t%.5f\tY\t%.5f\tCurrent Count\t%d"), m_dAvgScaleX, m_dAvgScaleY, m_dCurrentScaleX[1], m_dCurrentScaleY[1], m_nCurrentLotCount);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		if(m_dAvgScaleX != 100) // 처음이 아니면
		{
			if(gDProject.CheckScalVal(m_dCurrentScaleX[1], m_dCurrentScaleY[1]))
			{
				strLog.Format(_T("2nd panel : Modified"));
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				m_dAvgScaleX = (m_dCurrentScaleX[1] + (m_dAvgScaleX * m_nCurrentLotCount)) / (m_nCurrentLotCount + 1);
				m_dAvgScaleY = (m_dCurrentScaleY[1] + (m_dAvgScaleY * m_nCurrentLotCount)) / (m_nCurrentLotCount + 1);
			}
		}
		else
		{
			m_dAvgScaleX = (m_dCurrentScaleX[1] + (m_dAvgScaleX * m_nCurrentLotCount)) / (m_nCurrentLotCount + 1);
			m_dAvgScaleY = (m_dCurrentScaleY[1] + (m_dAvgScaleY * m_nCurrentLotCount)) / (m_nCurrentLotCount + 1);
		}
	}

	gDProject.CalScaleLimit(m_dAvgScaleX, m_dAvgScaleY);
}

BOOL CPaneAutoRun::CheckVisionHeadOffset()
{
	return TRUE;
}

BOOL CPaneAutoRun::PreTranslateMessage(MSG* pMsg)
{
	// TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.
	if(pMsg->message == WM_LBUTTONDOWN)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog나 Form 의 ID일 경우 리턴 (안하면 프로그램 죽음)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // 현재 다이얼로그의 핸들인지 검사
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Drill_Main) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}

void CPaneAutoRun::ResetScale()
{
	m_dCurrentScaleX[0] = m_dCurrentScaleX[1] = m_dCurrentScaleY[0] = m_dCurrentScaleY[1] = 100;
}
int CPaneAutoRun::GetFirstBeamPath()
{
	BOOL bAuto = m_bAutoRun;
	BOOL bSelectOnly = m_bSelectFire;

	POSITION pos;
	LPFIREHOLE pHole;

	// 가공할 것이 있는 tool 만 areaTempList에 저장
	AreaList AreaTempList;
	POSITION posArea;
	DAreaInfo *pAreaInfo;
	BOOL bFirstArea = FALSE;
	int nTool = -1;
	int nStartFidBlock, nEndFidBlock;
	if(gDProject.m_bMultiFidAscentOrder)
	{
		nStartFidBlock = 0; nEndFidBlock = gDProject.m_nMaxFidBlock;
	}
	else
	{
		nStartFidBlock = nEndFidBlock = -1;
	}

	for(int nFidBlock = nStartFidBlock; nFidBlock <= nEndFidBlock; nFidBlock++) // 다시 생각해 보기 
	{

		for(int i = 1; i < MAX_TOOL_NO; i++)
		{
			if(!gDProject.m_pToolCode[i]->m_bUseTool)
				continue;

			posArea = gDProject.m_Areas[i].GetHeadPosition();
			while (posArea) 
			{
				pAreaInfo = gDProject.m_Areas[i].GetNext(posArea);
				if(IsAvailableArea(pAreaInfo, i, nFidBlock))
				{
					bFirstArea = TRUE;
					break;
				}
			}
			if(bFirstArea != NULL)
				break;
		}
	}
	if(!bFirstArea)
		return -1;

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = pAreaInfo->m_FireHoles[i].GetHeadPosition();
		while (pos) 
		{
			pHole = pAreaInfo->m_FireHoles[i].GetNext(pos);
			if(!bAuto)
			{
				if(bSelectOnly)
				{
					if(pHole->bSelect && gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable())
					{
						nTool  = pHole->pOrigin->nToolNo;
						break;
					}
				}
				else
				{
					if(gDProject.m_pToolCode[pHole->pOrigin->nToolNo]->IsVisable())
					{
						nTool = pHole->pOrigin->nToolNo;
						break;
					}
				}

			}
			else
			{
				nTool = pHole->pOrigin->nToolNo;
				break;
			}
		}
		if(nTool != -1)
			break;
	}

	LPFIRELINE pLine;

	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		pos = pAreaInfo->m_FireLines[i].GetHeadPosition();
		while (pos) 
		{
			pLine = pAreaInfo->m_FireLines[i].GetNext(pos);
			if(!bAuto)
			{
				if(bSelectOnly)
				{
					if(pLine->bSelect && gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable())
					{
						nTool = pLine->pOrigin->nToolNo;
						break;
					}
				}
				else
				{
					if(gDProject.m_pToolCode[pLine->pOrigin->nToolNo]->IsVisable())
					{
						nTool = pLine->pOrigin->nToolNo;
						break;
					}
				}
			}
			else
			{
				nTool = pLine->pOrigin->nToolNo;
				break;
			}
		}
		if(nTool != -1)
			break;
	}

	SUBTOOLDATA subdata;

	if(nTool != -1)
	{
		pos = gDProject.m_pToolCode[nTool]->m_SubToolData.GetHeadPosition();
		subdata = gDProject.m_pToolCode[nTool]->m_SubToolData.GetNext(pos);
		return subdata.nMask;
	}
	else
		return -1;
}
BOOL CPaneAutoRun::NGBoxCheck(int nNGCondition)	//20130502 bskim
{
	if(gProcessINI.m_sProcessSystem.bNoUseNGBox)
	{
		CString strFile, strLog;
		strFile.Format(_T("AutorunTrace"));
		strLog.Format(_T("NG info down : %d -> 0 (bNoUseNGBox) "), nNGCondition);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		nNGCondition = 0;
	}

	CString strFile, strLog;
	strFile.Format(_T("AutorunTrace"));
	strLog.Format(_T("NG info down : %d"), nNGCondition);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	
	BOOL bRes = TRUE;
#ifdef __KUNSAN_SAMSUNG_LARGE__
	bRes &= gDeviceFactory.GetMotor()->SetNGPanel(nNGCondition);
#endif
	return (bRes && gDeviceFactory.GetMotor()->SetOutPort(PORT_NG_PCB, nNGCondition));

}

BOOL CPaneAutoRun::FindSameFidPosIndexAndApply(LPFIDDATA& pCurrentFidData, int nAddProperty, int nDelProperty, int nFidBlock, LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd)
{
	LPFIDDATA pFidData;
	BOOL bSameFidExist = FALSE;
	int nCnt = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX, nAddProperty, nDelProperty, nFidBlock);
	for(int i = 0; i < nCnt; i++)
	{
//		if(pCurrentFidData->nFindIndex == i)
//			continue;

		pFidData = gDProject.m_Glyphs.GetUsedFiducialData(DEFAULT_FID_INDEX, i, nAddProperty, nDelProperty, nFidBlock);

		if(pCurrentFidData->npPosition.x == pFidData->npPosition.x &&
			pCurrentFidData->npPosition.y == pFidData->npPosition.y )
		{
			if(pFidData->bAcquire[0] || pFidData->bAcquire[1])
			{
				bSameFidExist = TRUE;
				break;
			}
		}
	}

	if(bSameFidExist)
	{
		pCurrentFidData->npTransPosition = pFidData->npTransPosition;
		pCurrentFidData->npTransPosition2 = pFidData->npTransPosition2;
		pCurrentFidData->npTablePos1 = pFidData->npTablePos1;
		pCurrentFidData->npTablePos2 = pFidData->npTablePos2;
		pCurrentFidData->bAcquire[0] = pFidData->bAcquire[0];
		pCurrentFidData->bAcquire[1] = pFidData->bAcquire[1];
		ChangeAllSameFidResult(pFidData, pPanel1st, pPanel2nd);
	}
	return bSameFidExist;
}

void CPaneAutoRun::ChangeAllSameFidResult(LPFIDDATA pFidData, LPPNLFIDINFO pPanel1st, LPPNLFIDINFO pPanel2nd)
{
	LPFIDRESULT pFidResult;
	if(pPanel1st && pFidData->bAcquire[0])
	{
		POSITION pos = pPanel1st->FidResult.GetHeadPosition();
		while(pos)
		{
			pFidResult = pPanel1st->FidResult.GetNext(pos);
			if(pFidResult->npRefPosition == pFidData->npPosition)
			{
				pFidResult->npOffset = pFidData->npTransPosition;
				pFidResult->bFound = TRUE;
			}
		}
	}

	if(pPanel2nd && pFidData->bAcquire[1])
	{
		POSITION pos = pPanel2nd->FidResult.GetHeadPosition();
		while(pos)
		{
			pFidResult = pPanel2nd->FidResult.GetNext(pos);
			if(pFidResult->npRefPosition == pFidData->npPosition)
			{
				pFidResult->npOffset = pFidData->npTransPosition2;
				pFidResult->bFound = TRUE;
			}
		}
	}
}


void CPaneAutoRun::OnClickedStaticPcbCount()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	if(!gProcessINI.m_sProcessSystem.bNoUseNGBox)
	{
		CString strMsg = _T("");
		strMsg.Format("Panel Total Count = %d\nPanel OK Count = %d\nPanel NG Count = %d",m_nInputLot, m_nCurrentLotCount, m_nNGLotCount);
		ErrMessage(strMsg);
	}
}
LRESULT CPaneAutoRun::SetVisionLamp(WPARAM wParam, LPARAM lParam)
{
	if(!gSystemINI.m_sHardWare.nUseLampRS232)
		return TRUE;

	HVision* pVision = gDeviceFactory.GetVision();
	int nCam = (int)wParam;
	VISION_INFO* pVisInfo = reinterpret_cast<VISION_INFO*>(lParam);

	pVision->OnLightAll(nCam, pVisInfo->nCoaxial[nCam], pVisInfo->nRing[nCam]);
	return TRUE;
}

BOOL CPaneAutoRun::HeatingScannerBlockUsingIdleInfo(int nRepeat, BOOL& bEndStep, int nDuty)
{
#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif

	CString strFile, strLog;
	strFile.Format(_T("SCal_Time_Log"));
	strLog.Format(_T("HeatingScannerBlockUsingIdleInfo Repeat[%d] : Started"), nRepeat);								
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	double dCurr1stTemper, dCurr2ndTemper;
	gDeviceFactory.GetMotor()->GetTCTemperature(dCurr1stTemper, dCurr2ndTemper);
	double dScalAllTemper[10];
	gDeviceFactory.GetMotor()->GetTemperatureForAllCh(dScalAllTemper);
	if( (gDProject.m_nSeparation == USE_1ST && dCurr1stTemper >= m_dTargetTemper - 0.01)) //m_dTargetTemper + gProcessINI.m_sProcessOption.dTemperDeltaT)) // 약간 높은 상태에서 식히고 offset 가공 들어가도록
	{
		strLog.Format(_T("HeatingScannerBlockUsingIdleInfo Repeat[%d] : m_dTargetTemper \t %.3f \t Current T \t %.3f"), nRepeat, m_dTargetTemper, dCurr1stTemper);								
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		strLog.Format(_T("HeatingScannerBlockUsingIdleInfo Temp All \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f"),   
					dScalAllTemper[0], dScalAllTemper[1], dScalAllTemper[2], dScalAllTemper[3], dScalAllTemper[4],
					dScalAllTemper[5], dScalAllTemper[6], dScalAllTemper[7], dScalAllTemper[8], dScalAllTemper[9]);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			return TRUE;
	}
	if( (gDProject.m_nSeparation == USE_2ND && dCurr2ndTemper >= m_dTargetTemper - 0.01)) //m_dTargetTemper + gProcessINI.m_sProcessOption.dTemperDeltaT)) // 약간 높은 상태에서 식히고 offset 가공 들어가도록
	{
		strLog.Format(_T("HeatingScannerBlockUsingIdleInfo Repeat[%d] : m_dTargetTemper \t %.3f \t Current T \t %.3f"), nRepeat, m_dTargetTemper, dCurr2ndTemper);								
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			strLog.Format(_T("HeatingScannerBlockUsingIdleInfo Temp All \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f"),   
					dScalAllTemper[0], dScalAllTemper[1], dScalAllTemper[2], dScalAllTemper[3], dScalAllTemper[4],
					dScalAllTemper[5], dScalAllTemper[6], dScalAllTemper[7], dScalAllTemper[8], dScalAllTemper[9]);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			return TRUE;
	}

	double dC1, dC2, dA1, dA2, dM1, dM2, dM3, dZ1, dZ2; 
	CString strVal;
	BOOL bTophat, bLaserPath;
	dZ1 = gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosZ1;//gBeamPathINI.m_sBeampath.dBeamPathZAxisPos1[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo];
	dZ2 = gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosZ2;//gBeamPathINI.m_sBeampath.dBeamPathZAxisPos2[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo];

	bTophat = gBeamPathINI.m_sBeampath.bBeamPathUseTophat[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo];
	bLaserPath = gBeamPathINI.m_sBeampath.bBeamPathLaserPath[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo];

	dC1 = gBeamPathINI.m_sBeampath.dBeamPathBetPos1[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo];
	dC2 = gBeamPathINI.m_sBeampath.dBeamPathBetPos2[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo];
	dA1 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos1[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo];
	dA2 = gBeamPathINI.m_sBeampath.nBeamPathAttenuatePos2[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo];
		
	dM1 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos1[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo];
	dM2 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos2[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo];
	dM3 = gBeamPathINI.m_sBeampath.nBeamPathMaskPos3[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo];

	
	if(!pMotor->MoveTophatShutter(bTophat))
	{
		m_nErrMsgID = STDGNALM568;
		return FALSE;
	}

	if(!pMotor->MoveLaserBeamPath(bLaserPath))
	{
		m_nErrMsgID = STDGNALM974;
		return FALSE;
	}


#ifndef __SERVO_MOTOR__
	if(!pMotor->MoveXYZMC2A(gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosX, gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosY, dZ1, dZ2, dM1, dM2, dC1, dC2, dA1, dA2, TRUE, SHOT_MOVE, FALSE, bTophat))
#else 
	if(!pMotor->MotorMoveXYZMCA3(gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosX, gProcessINI.m_sProcessAutoSetting.dIdleShotTablePosY, dZ1, dZ2, dM1, dM2, dM3, dC1, dC2, dA1, dA2, TRUE, SHOT_MOVE, FALSE, bTophat))
#endif
	{
		m_nErrMsgID = STDGNALM438;
		return FALSE;
	}

	SUBTOOLDATA subTool;
	subTool.nSubToolNo = 1;
	subTool.nToolType = SHOT_DRILL_TYPE;
	// Mark
	subTool.nJumpDelay = gSystemINI.m_sSystemDevice.nJumpDelayShot;
	subTool.nLaserOnDelay = 1;
	subTool.nLaserOffDelay = 1;
	subTool.nFrequency = 1000;
	// Drill
	subTool.nShotMode = 1; // cycle mode
	subTool.nTotalShot = 1;
	subTool.nBurstShot = 1;
	subTool.nMask = gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo;
	subTool.bUseTophat = bTophat;

	CString strAOMFile;
	strAOMFile.Format(_T("%sAOM\\Default.AOM"), gEasyDrillerINI.m_clsDirPath.GetRootDir());
	for(int i = 0; i < subTool.nTotalShot; i++)
	{
		subTool.dShotDuty[i] = nDuty;// gBeamPathINI.m_sBeampath.dPowCompensationDuty[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo];
		subTool.dShotAOMDelay[i] = gBeamPathINI.m_sBeampath.dPowCompensationAomDelay[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo];
		subTool.dShotAOMDuty[i] = gBeamPathINI.m_sBeampath.dPowCompensationAomDuty[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo];

		subTool.dShotDutyOffsetM[i] = 0;
		subTool.dShotDutyOffsetS[i] = 0;
		subTool.dShotVolOffsetM[i] = 0;
		subTool.dShotVolOffsetS[i] = 0;

		if(gDProject.m_nDummyFreeType == DUMMY_FREE_1)
		{
			subTool.dShotMaxFreq[i] = subTool.dShotMinFreq[i] = gSystemINI.m_sSystemDump.nStandbyMaxFreq;		// shot간 최소 주기.	// 2011-09-28
		}
		else if(gDProject.m_nDummyFreeType == DUMMY_FREE_2)
		{
			subTool.dShotMaxFreq[i] = subTool.dShotMinFreq[i] = gSystemINI.m_sSystemDump.nStandbyMaxFreq2;
		}

		strcpy_s(subTool.cAOMFilePath[i], strAOMFile);
	}
	subTool.bUseAperture = FALSE;
	subTool.nApertureBurst = 1;
	subTool.dZOffset = 0;
	subTool.nFPS = 0;
	// Memo
	subTool.cToolMemo[0] = NULL;

	BOOL bIsDspBusy = TRUE;
	double dFireTime;
	CCorrectTime ctFireTime; //1분 넘으면 알람
	ctFireTime.StartTime();
	while(bIsDspBusy)
	{
		dFireTime = ctFireTime.PresentTime();
		if(dFireTime >= 60)
		{
			gDeviceFactory.GetEocard()->EStop();
			m_nErrMsgID = STDGNALM566;
			return FALSE;
		}
		bIsDspBusy = gDeviceFactory.GetEocard()->IsDSPBusy();
	}

	// subTool download
	if(!gDeviceFactory.GetEocard()->DownloadOneSubTool(1, subTool))
	{
		m_nErrMsgID = STDGNALM445;
		return FALSE;
	}
	if(!gDeviceFactory.GetEocard()->DownloadShotDrillScannerParam(subTool.nJumpDelay))// / subTool.nDrawStepPeriod))
	{
		m_nErrMsgID = STDGNALM445;
		return FALSE;
	}
	// Laser Current Set - no use

#ifndef __SERVO_MOTOR__
	if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_C2))
#else 
	if(!pMotor->InPositionIO(IND_X + IND_Y + IND_Z1 + IND_Z2 + IND_M1 + IND_C1 + IND_C2 + IND_M2 + IND_M3)) //110219 ejpark c2추가 
#endif
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis, TRUE);
		return FALSE;
	}

	if(!((CEasyDrillerDlg*)::AfxGetMainWnd())->ShutterMove(gDProject.m_nSeparation == USE_1ST, gDProject.m_nSeparation == USE_2ND, FALSE))
	{
		m_nErrMsgID = STDGNALM417; // shutter sensor error
		return FALSE;
	}

	if(!gDeviceFactory.GetEocard()->ShotDataReset())
	{
		m_nErrMsgID = STDGNALM445;
		return FALSE;
	}

	gDProject.ResetFidOffset();

	gDProject.m_Glyphs.ResetFidAcquireRet(DEFAULT_FID_INDEX, TRUE);
	BOOL bFirst = TRUE, bSecond = TRUE;
	gDProject.ApplyFidDataToShot_MultiFiducial(0, FIND_ALL_FID, FALSE, -1, USE_DUAL,bFirst, bSecond, FALSE);
	POSITION posArea;
	DAreaInfo* pAreaInfo;
	for(int i = 1; i < 29; i++)
	{
		posArea = gDProject.m_Areas[i].GetHeadPosition();
		while (posArea) 
		{
			pAreaInfo = gDProject.m_Areas[i].GetNext(posArea);
			break;
		}
	}

	LPFIREHOLE pHole;
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		POSITION pos = pAreaInfo->m_FireHoles[i].GetHeadPosition();
		while(pos)
		{
			pHole = pAreaInfo->m_FireHoles[i].GetNext(pos);
			if(!gDeviceFactory.GetEocard()->DownloadShotData2((USHORT)pHole->npPos1.x, (USHORT)pHole->npPos1.y, 
																(USHORT)pHole->npPos2.x, (USHORT)pHole->npPos2.y, 
																TRUE, TRUE, 1))
				{
					gDeviceFactory.GetEocard()->ShotDataReset();
					m_nErrMsgID = STDGNALM445;
					return FALSE;
				}
			TRACE(_T("%d\t%d\n"), pHole->npPos2.x, pHole->npPos2.y);
		}
	}
	CCorrectTime	m_HeatingTime;
	m_HeatingTime.StartTime();
	BOOL bTemperReady = FALSE;
	while(TRUE)
	{
		if(!gDeviceFactory.GetEocard()->FieldPreStart(0))
		{
			m_nErrMsgID = STDGNALM445; 
			return FALSE;
		}
		if(!gDeviceFactory.GetEocard()->FieldStart(FALSE))
		{
			m_nErrMsgID = STDGNALM445; 
			return FALSE;
		}
		::Sleep(10);

		BOOL bResult = TRUE;
		while(bResult)
		{
			BOOL bScannerCableError = gDeviceFactory.GetEocard()->IsScannerCableError();
			BOOL bScannerMotorFault = gDeviceFactory.GetEocard()->IsMotorFault();
			BOOL bScannerDrillTimeOut = gDeviceFactory.GetEocard()->IsDrillTimeOut();
			CString strErrorMsg = _T("");
			if(bScannerCableError)
			{
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				m_nErrMsgID = STDGNALM1017;
				return FALSE;
			}
			else if(bScannerMotorFault)
			{
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				m_nErrMsgID = STDGNALM1017;
				return FALSE;
			}
			else if(bScannerDrillTimeOut)
			{
				if(gSystemINI.m_sSystemDevice.nEStop == 1)
					gDeviceFactory.GetEocard()->EStop();
				m_nErrMsgID = STDGNALM1017;
				return FALSE;
			}
			if(!CheckStatus())
			{
				gDeviceFactory.GetEocard()->EStop();
				::Sleep(200);
				return FALSE;
			}
			bResult = gDeviceFactory.GetEocard()->IsDSPBusy();
			::Sleep(100);

			gDeviceFactory.GetMotor()->GetTCTemperature(dCurr1stTemper, dCurr2ndTemper);
			if( (gDProject.m_nSeparation == USE_1ST && dCurr1stTemper >= m_dTargetTemper - 0.01)) // gProcessINI.m_sProcessOption.dTemperDeltaT)) // 약간 높은 상태에서 식히고 offset 가공 들어가도록
				bTemperReady = TRUE;
			if( (gDProject.m_nSeparation == USE_2ND && dCurr2ndTemper >= m_dTargetTemper - 0.01)) //+ gProcessINI.m_sProcessOption.dTemperDeltaT)) // 약간 높은 상태에서 식히고 offset 가공 들어가도록
				bTemperReady = TRUE;
		}

		if(bTemperReady)
		{
			CString strFile, strLog;
			strFile.Format(_T("SCal_Time_Log"));
			if( gDProject.m_nSeparation == USE_1ST )
				strLog.Format(_T("HeatingScannerBlockUsingIdleInfo Repeat[%d] : m_dTargetTemper \t %.3f \t Current T \t %.3f"), nRepeat, m_dTargetTemper, dCurr1stTemper);	
			else
				strLog.Format(_T("HeatingScannerBlockUsingIdleInfo Repeat[%d] : m_dTargetTemper \t %.3f \t Current T \t %.3f"), nRepeat, m_dTargetTemper, dCurr2ndTemper);	
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			gDeviceFactory.GetMotor()->GetTemperatureForAllCh(dScalAllTemper);
			strLog.Format(_T("HeatingScannerBlockUsingIdleInfo Temp All \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f"),   
					dScalAllTemper[0], dScalAllTemper[1], dScalAllTemper[2], dScalAllTemper[3], dScalAllTemper[4],
					dScalAllTemper[5], dScalAllTemper[6], dScalAllTemper[7], dScalAllTemper[8], dScalAllTemper[9]);
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			return TRUE;
		}

		if(m_HeatingTime.PresentTime() > gProcessINI.m_sProcessOption.nTemperCompenTimeoutMin * 60) // time 아웃 OK
		{
/*			bTemperReady = FALSE;
			if( (gDProject.m_nSeparation == USE_1ST && dCurr1stTemper >= m_dTargetTemper - gProcessINI.m_sProcessOption.dTemperTransT + 0.2 )) // 마지막 측정 온도보다 0.2도만 높아도..
				bTemperReady = TRUE;
			if( (gDProject.m_nSeparation == USE_2ND && dCurr2ndTemper >= m_dTargetTemper - gProcessINI.m_sProcessOption.dTemperTransT + 0.2 )) // 마지막 측정 온도보다 0.2도만 높아도..
				bTemperReady = TRUE;
*/
			bTemperReady = TRUE;
			if(bTemperReady) 
			{
				bEndStep = TRUE;
				CString strFile, strLog;
				strFile.Format(_T("SCal_Time_Log"));
				if( gDProject.m_nSeparation == USE_1ST )
					strLog.Format(_T("HeatingScannerBlockUsingIdleInfo Repeat[%d] Last : m_dTargetTemper \t %.3f \t Current T \t %.3f"), nRepeat, m_dTargetTemper, dCurr1stTemper);	
				else
					strLog.Format(_T("HeatingScannerBlockUsingIdleInfo Repeat[%d] Last : m_dTargetTemper \t %.3f \t Current T \t %.3f"), nRepeat, m_dTargetTemper, dCurr2ndTemper);	
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				gDeviceFactory.GetMotor()->GetTemperatureForAllCh(dScalAllTemper);
				strLog.Format(_T("HeatingScannerBlockUsingIdleInfo Temp All \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f \t %.1f"),   
						dScalAllTemper[0], dScalAllTemper[1], dScalAllTemper[2], dScalAllTemper[3], dScalAllTemper[4],
						dScalAllTemper[5], dScalAllTemper[6], dScalAllTemper[7], dScalAllTemper[8], dScalAllTemper[9]);
				::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
				return TRUE;
			}
			else
				m_nErrMsgID =STDGNALM1019; // 실패

			return FALSE;
		}
		::Sleep(gProcessINI.m_sProcessOption.nTableMoveWaitTimeMS);
	}
	return FALSE;
}

BOOL CPaneAutoRun::CheckOffsetForTemperCompensation(int nRepeatNo, int nFireAndFindMode, int nTempStep)
{
	CString strFile, strLog;
	strFile.Format(_T("SCal_Time_Log"));
	strLog.Format(_T("CheckOffsetForTemperCompensation Started : m_dTargetTemper \t %.3f"), m_dTargetTemper);								
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));	

	BOOL bASCToolBackup[BEAMPATH_COUNT];
	memcpy(bASCToolBackup, m_bASCTool, sizeof(m_bASCTool));
	memset(m_bASCTool, 0, sizeof(m_bASCTool));
	m_bASCTool[gProcessINI.m_sProcessAutoSetting.nIdleShotBeamPathNo] = TRUE;

	BOOL bResult = TRUE;
	if(nFireAndFindMode & T_OFFSET_FIRE)
	{
		for(int i = 0; i < nRepeatNo; i++)
		{
			bResult =  DoPreworkSCalProcess(TRUE, T_OFFSET_FIRE);
			if(!bResult)
				break;
		}
	}

	if(bResult && (nFireAndFindMode & T_OFFSET_FIND))
	{
		int nBackupAutoCalCount = gProcessINI.m_sProcessScannerCal.nCountAuto;
		gProcessINI.m_sProcessScannerCal.nCountAuto -= nRepeatNo * nTempStep;
		for(int i = 0; i < nRepeatNo * nTempStep; i++)
		{
			bResult =  DoPreworkSCalProcess(TRUE, T_OFFSET_FIND);
			if(!bResult)
			{
				gProcessINI.m_sProcessScannerCal.nCountAuto = nBackupAutoCalCount;
				break;
			}
		}
		gProcessINI.m_sProcessScannerCal.nCountAuto = nBackupAutoCalCount;
	}

	::AfxGetMainWnd()->SendMessage(UM_SAVE_INIFILE, PROCESS_INI);
	
	strLog.Format(_T("CheckOffsetForTemperCompensation end"));								
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));	

	memcpy(m_bASCTool, bASCToolBackup, sizeof(m_bASCTool));
	return bResult;
}

BOOL CPaneAutoRun::MakeTemperCompenFile()
{
	BOOL bResult = TRUE;
	if(gDProject.m_nSeparation == USE_1ST)
	{
		CString strFile, strLog;
		strFile.Format(_T("SCal_Time_Log"));
		strLog.Format(_T("Mater Compen End"));								
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));	

		if(bResult)
		{
			CString strFile;
			strFile.Format(_T("%s\\Temper.Table"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());
			return gDeviceFactory.Get1stTemperCompen()->SaveTemperCompenFile(strFile);
		}
	}
	else
	{
		CString strFile, strLog;
		strFile.Format(_T("SCal_Time_Log"));
		strLog.Format(_T("Slave Compen End"));								
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		if(bResult)
		{
			CString strFile;
			strFile.Format(_T("%s\\TemperS.Table"), gEasyDrillerINI.m_clsDirPath.GetCorrectDir());
			return gDeviceFactory.Get2ndTemperCompen()->SaveTemperCompenFile(strFile);
		}
	}
	m_nErrMsgID =STDGNALM1020;
	return FALSE;
}

BOOL CPaneAutoRun::InitStartTemperCompen()
{
	double d1stTemper, d2ndTemper;
	gDeviceFactory.GetMotor()->GetTCTemperature(d1stTemper, d2ndTemper);
	if(gDProject.m_nSeparation == USE_1ST)
		m_dMeasureStartTemper = d1stTemper;
	else
		m_dMeasureStartTemper = d2ndTemper;

	if(gDProject.m_nSeparation == USE_DUAL)
	{
		ErrMessage(_T("Can't measure Offsets at once in Dual Mode. Please select 1st_Panel or 2nd_Panel."));
		return FALSE;
	}

	if(gDProject.m_nSeparation == USE_1ST  && 
		(d1stTemper < gProcessINI.m_sProcessOption.dTemperMinTLimit || d1stTemper + gProcessINI.m_sProcessOption.dTemperDeltaT > gProcessINI.m_sProcessOption.dTemperMaxTLimit))
	{
		m_nErrMsgID = STDGNALM1018; // start Temper 이상
		return FALSE;
	}
	if(gDProject.m_nSeparation == USE_2ND  && 
		(d2ndTemper < gProcessINI.m_sProcessOption.dTemperMinTLimit || d2ndTemper + gProcessINI.m_sProcessOption.dTemperDeltaT > gProcessINI.m_sProcessOption.dTemperMaxTLimit))
	{
		m_nErrMsgID = STDGNALM1018;
		return FALSE;
	}

	if(gDProject.m_nSeparation == USE_1ST)
	{
		CString strFile, strLog;
		strFile.Format(_T("SCal_Time_Log"));
		strLog.Format(_T("Mater Compen start\t %.3f \t %d \t %.3f \t %d "),  
							m_dTargetTemper, gProcessINI.m_sProcessOption.nTemperCompenGridNo, gProcessINI.m_sProcessOption.dTemperDeltaT, gProcessINI.m_sProcessOption.nTemperCompenRepeatNo);								
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));	
		if(!gDeviceFactory.Get1stTemperCompen()->SetDataInfo(gProcessINI.m_sProcessOption.nTemperCompenGridNo, gProcessINI.m_sProcessOption.dTemperDeltaT, 
																					  gProcessINI.m_sProcessOption.nTemperCompenRepeatNo, gProcessINI.m_sProcessOption.dTemperTransT))
		{
			m_nErrMsgID = STDGNALM1021;
			return FALSE;
		}
	}
	else
	{
		CString strFile, strLog;
		strFile.Format(_T("SCal_Time_Log"));
		strLog.Format(_T("Slave Compen start\t %.3f \t %d \t %.3f \t %d "),  
							m_dTargetTemper, gProcessINI.m_sProcessOption.nTemperCompenGridNo, gProcessINI.m_sProcessOption.dTemperDeltaT, gProcessINI.m_sProcessOption.nTemperCompenRepeatNo);								
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		if(!gDeviceFactory.Get2ndTemperCompen()->SetDataInfo(gProcessINI.m_sProcessOption.nTemperCompenGridNo, gProcessINI.m_sProcessOption.dTemperDeltaT,
																					   gProcessINI.m_sProcessOption.nTemperCompenRepeatNo, gProcessINI.m_sProcessOption.dTemperTransT))
		{
			m_nErrMsgID = STDGNALM1021;
			return FALSE;
		}
	}
	return TRUE;
}

BOOL CPaneAutoRun::WaitRearchTargetT()
{
	double d1stTemper, d2ndTemper;
	while(TRUE)
	{
		gDeviceFactory.GetMotor()->GetTCTemperature(d1stTemper, d2ndTemper);
		if(gDProject.m_nSeparation == USE_1ST)
		{
			if(m_dTargetTemper >= d1stTemper)
				break;
		}
		else
		{
			if(m_dTargetTemper >= d2ndTemper )
				break;
		}
		if(!CheckStatus()) // Stop확인
			return FALSE;
		::Sleep(100);
	}
	return TRUE;
}

BOOL CPaneAutoRun::WaitDownTemp(int nTimeSec)
{
	int nCount = 0; 
	while(TRUE)
	{
		if(!CheckStatus()) // Stop확인
			return FALSE;
		::Sleep(100);

		nCount++;
		if(nTimeSec * 10 < nCount)
			return TRUE;
	}
	return TRUE;
}

void CPaneAutoRun::OPCEvent(BOOL bLoad, BOOL bFirstEnd)
{ 
#ifndef __NO_USE_OPC__
	int nIndex;
	int nUsePanel = gDProject.m_nSeparation;
	CString strOPCTag;
	CString strLotID;
	if(gProcessINI.m_sProcessSystem.bUseScheduling)
		strLotID.Format(_T("%s"), gLotInfo.szLotID[m_nCurrentPrjIndex]);
	else
		strLotID.Format(_T("%s"), gDProject.m_szLotId);
	
	if(nUsePanel == 0 && !m_bOdd)
		strOPCTag.Format("%s;%d;;;",strLotID, 2);
	else
		strOPCTag.Format("%s;%d;;;",strLotID, 1);

	if(nUsePanel == 1 || nUsePanel == 2)
		strOPCTag.Format("%s;%d;;;",strLotID, 1);
	

	if(bLoad)
	{
		if(bFirstEnd) //첫번째 기판 로딩
		{
			nIndex = 1;  //0 LOT START EVENT : E_000_000001_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
		}
		
		nIndex = 3; //3 Main 투입 : E_000_000010_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
		if(nUsePanel != USE_2ND)
		{
			nIndex = 5; //5 Working Table내 좌측PNL 투입 : E_001_000010_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
		}
		if(nUsePanel != USE_1ST && !m_bOdd)
		{
			nIndex = 7; //7 Working Table내 우측PNL 투입 : E_002_000010_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
		}
	}
	else
	{
		nIndex = 4; //3 Main 배출 : E_000_000020_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
		if(nUsePanel != USE_2ND)
		{
			nIndex = 6;//6 Working Table내 좌측PNL 배출 : E_001_000020_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
		}
		if(nUsePanel != USE_1ST && !m_bOdd)
		{
			nIndex = 8;//8 Working Table내 우측PNL 배출 : E_002_000020_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));
		}

		if(bFirstEnd)
		{
			nIndex = 2; //2 Lot End Event : E_000_000002_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
		}
	}


	BOOL bSuction1 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x01;
	BOOL bSuction2 = gDeviceFactory.GetMotor()->GetCurrentSuction() & 0x02;

	//change status 
	if(bSuction1)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 111; // S_001_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	if(bSuction2)
		strOPCTag.Format(_T("1"));
	else
		strOPCTag.Format(_T("0"));
	nIndex = 112; // S_002_000000_01;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
	
	
#endif
}
BOOL CPaneAutoRun::OPCBasket(BOOL bIn, BOOL bLoad, char* szBasketID)
{
#ifndef __NO_USE_OPC__
	CString strOPCTag;
	int nIndex;

	strOPCTag.Format("%s;;",szBasketID);

	/*if(bPanelCheck) //판넬 
	{
		if(bLoad)
		{	
			if(bIn)
				nIndex = 139; //817 Lot End Event : I_000_001211_00
			else
				nIndex = 140; //817 Lot End Event : I_000_001212_00
		}
		else
		{
			if(bIn)
				nIndex = 142; //817 Lot End Event : I_000_002211_00
			else
				nIndex = 143; //817 Lot End Event : I_000_002212_00
		}
	}
	else //바스켓
*/	{
		if(bLoad) //투입기
		{
			if(bIn)
				nIndex = 131; //130 Lot End Event : I_000_001111_00
			else
				nIndex = 132; //131 Lot End Event : I_000_001112_00
		}
		else //수취기 
		{
			if(bIn)
				nIndex = 134; //817 Lot End Event : I_000_002111_00
			else
				nIndex = 135; //817 Lot End Event : I_000_002112_00
		}
	}
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;;;;;;"),szBasketID); 

	if(bIn)
	{  
		//if(!bPanelCheck)
		{
			if(bLoad)
				nIndex =  133; //132 Lot End Event : I_000_001121_01
			else
				nIndex =  136; //817 Lot End Event : I_000_002121_01
		}
		/*else
		{
			if(bLoad)
				nIndex =  141; //817 Lot End Event : I_000_001221_01
			else
				nIndex =  144; //817 Lot End Event : I_000_002221_01
		}
		*/
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
	}
	
#endif
	return TRUE;

}

void CPaneAutoRun::UpdateOPCDisplay(BOOL bClear)
{
#ifdef __KUNSAN_SAMSUNG_LARGE__
	int nBeforeNG = 0;
	if(m_nCurrentPrjIndex % 2 == 1)
		nBeforeNG = gLotInfo.nNGLotCount[m_nCurrentPrjIndex -1]; 
	if(gLotInfo.nLotCount[m_nCurrentPrjIndex] == gLotInfo.nFiredLotCount[m_nCurrentPrjIndex] + gLotInfo.nNGLotCount[m_nCurrentPrjIndex] + nBeforeNG)
		gLotInfo.nStatus[m_nCurrentPrjIndex] = STATUS_END;

	if(m_pOPC != NULL)
		m_pOPC->InsertList(bClear);
#endif
}

void CPaneAutoRun::OPCStatus()
{
#ifndef __NO_USE_OPC__
	BOOL bSuction1 = FALSE, bSuction2 = FALSE;
	BYTE cVal;
	cVal = gDeviceFactory.GetMotor()->GetCurrentSuction();

	if(cVal & 0x01)
		bSuction1 = TRUE;
	if(cVal & 0x02)
		bSuction2 = TRUE;

	CString strOPCTag;
	int nIndex;

	CString strLotID;
	for(int i = 0; i < gLotInfo.nLastIndex; i++)
	{
		if(gLotInfo.nStatus[i] == STATUS_PROGRESS)
		{
			strLotID.Format(_T("%s"), gLotInfo.szLotID[i]);
			break;
		}
	}

	strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dChillerTemp[0]);
	nIndex = 52; //M_000_000001_00
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dChillerTemp[1]);
	nIndex = 53; //M_000_000002_00
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		
	strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dSetChillerTemp[0]);
	nIndex = 54; //M_000_000003_00
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;%.1f;;;;;;;;;"),strLotID, gOPCParam.dSetChillerTemp[1]);
	nIndex = 91; //M_000_000040_10
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
	
	strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dScannerTemp[0]);
	nIndex = 55; //M_001_000004_00
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dScannerTemp[1]);
	nIndex = 56; //M_002_000005_00
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dMainAir);
	nIndex = 94; //M_000_000043_00
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;%.1f;;;;;;;;;"),strLotID, gOPCParam.dSetMainAir);
	nIndex = 95; //M_000_000044_10
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
		
	strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dDustSuction);
	nIndex = 96; //M_000_000045_00
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;%.1f;;;;;;;;;"),strLotID, gOPCParam.dSetDustSuction);
	nIndex = 97; //M_000_000046_10
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;%.1f"),strLotID, gOPCParam.dWaterFlow[0]);
	nIndex = 98; //M_000_000047_00
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;%.1f;;;;;;;;;"),strLotID, gOPCParam.dSetWaterFlow[0]);
	nIndex = 99; //M_000_000048_10
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dWaterFlow[1]);
	nIndex = 100; //M_000_000049_00
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;%.1f;;;;;;;;;"),strLotID, gOPCParam.dSetWaterFlow[1]);
	nIndex = 101; //M_000_000050_10
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dTemp);
	nIndex = 102; //M_000_000051_00
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dHumidity);
	nIndex = 103; //M_000_000052_00
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dPower);
	nIndex = 104; //M_000_000053_00
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
	
	strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dCurrent);
	nIndex = 105; //M_000_000054_00
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

	strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dVoltage);
	nIndex = 106; //M_000_000055_00
	((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

#endif
}
void CPaneAutoRun::OPCUpdateParameter(int nType)
{
#ifndef __NO_USE_OPC__
	CString strLotID, strOPCTag;
	strLotID.Format(_T("%s"), gLotInfo.szLotID[m_nCurrentPrjIndex]);
	int nIndex;

	if(nType == N_POWER)
	{
		if(gDProject.m_nSeparation != USE_2ND)
		{
			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dPowerMeasure[0]);
			nIndex = 57; // N_001_000006_00;
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
		}
		if((gDProject.m_nSeparation == USE_DUAL && !m_bOdd) || gDProject.m_nSeparation == USE_2ND)
		{
			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dPowerMeasure[1]);
			nIndex = 58; // N_002_000007_00;
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
		}
	}
	else if(nType == N_VACUUM)
	{
		if(gDProject.m_nSeparation != USE_2ND)
		{
			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dVacuum[0]);
			nIndex = 59; //N_001_000008_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

			strOPCTag.Format(_T("%s;%.1f;;;;;;;;;;"),strLotID, gOPCParam.dSetVacuum[0]);
			nIndex = 92; //N_001_000041_10
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		}
		if((gDProject.m_nSeparation == USE_DUAL && !m_bOdd) || gDProject.m_nSeparation == USE_2ND)
		{
			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dVacuum[1]);
			nIndex = 60; // N_002_000009_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

			strOPCTag.Format(_T("%s;%.1f;;;;;;;;;;"),strLotID, gOPCParam.dSetVacuum[1]);
			nIndex = 93; //N_002_000042_10
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		}
	}
	else if(nType == N_HEIGHT)
	{
		if(gDProject.m_nSeparation != USE_2ND)
		{
			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dHeight[0]);
			nIndex = 61; //N_001_000010_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
		}
		if((gDProject.m_nSeparation == USE_DUAL && !m_bOdd) || gDProject.m_nSeparation == USE_2ND)
		{
			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dHeight[1]);
			nIndex = 62; // N_002_000011_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
		}
	}
	else if(nType == N_SCALE)
	{
		if(gDProject.m_nSeparation != USE_2ND)
		{
			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dScale[0]);
			nIndex = 63; //N_001_000012_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
		}

		if((gDProject.m_nSeparation == USE_DUAL && !m_bOdd) || gDProject.m_nSeparation == USE_2ND)
		{
			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dScale[1]);
			nIndex = 64; // N_002_000013_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
		}
		
		strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dLengthTol[0]);
		nIndex = 79; //N_000_000028_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
		strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dLengthTol[1]);
		nIndex = 80; //N_000_000029_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
	}
	else if(nType == N_TOOL)
	{
		strOPCTag.Format(_T("%s;%d;"),strLotID, gOPCParam.nMainTool);
		nIndex = 65; //N_000_000014_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		strOPCTag.Format(_T("%s;%d;"),strLotID, gOPCParam.nSubTool);
		nIndex = 66; //N_000_000015_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		strOPCTag.Format(_T("%s;%d;"),strLotID, gOPCParam.nToolType);
		nIndex = 67; //N_000_000016_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
		
		strOPCTag.Format(_T("%s;%d;"),strLotID, gOPCParam.nBeamPath);
		nIndex = 68; //N_000_000017_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		strOPCTag.Format(_T("%s;%d;"),strLotID, gOPCParam.nDrillMethord);
		nIndex = 69; //N_000_000018_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		strOPCTag.Format(_T("%s;%d;"),strLotID, gOPCParam.nFreq);
		nIndex = 70; //N_000_000019_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		strOPCTag.Format(_T("%s;%d;"),strLotID, gOPCParam.nOnDelay);
		nIndex = 71; //N_000_000020_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		strOPCTag.Format(_T("%s;%d;"),strLotID, gOPCParam.nOffDelay);
		nIndex = 72; //N_000_000021_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		strOPCTag.Format(_T("%s;%d;"),strLotID, gOPCParam.nDrawSpeed);
		nIndex = 73; //N_000_000022_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		strOPCTag.Format(_T("%s;%d;"),strLotID, gOPCParam.nJumpSpeed);
		nIndex = 74; //N_000_000023_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		strOPCTag.Format(_T("%s;%d;"),strLotID, gOPCParam.nConnerDelay);
		nIndex = 75; //N_000_000024_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		strOPCTag.Format(_T("%s;%d;"),strLotID, gOPCParam.nJumpDelay);
		nIndex = 76; //N_000_000025_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		strOPCTag.Format(_T("%s;%d;"),strLotID, gOPCParam.LineDelay);
		nIndex = 77; //N_000_000026_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		strOPCTag.Format(_T("%s;%s;"),strLotID, gOPCParam.szAperture);
		nIndex = 78; //N_000_000027_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		strOPCTag.Format(_T("%s;%d;"),strLotID, gOPCParam.nDummyType);
		nIndex = 89; //N_000_000038_00
		((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		for(int i =0; i<gOPCParam.nSubToolCount; i++)
		{
			strOPCTag.Format(_T("%s;%.1f,%d;"),strLotID, gOPCParam.dShotDuty[i], gOPCParam.nShotFreq[i]);
			nIndex = 90; //N_000_000039_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
		}
	}
	else if(nType == N_HEAD)
	{
		if(gDProject.m_nSeparation != USE_2ND)
		{
			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dHeadOffset[0][0][0]);
			nIndex = 81; //N_001_000030_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dHeadOffset[0][0][1]);
			nIndex = 82; //N_001_000031_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dHeadOffset[0][1][0]);
			nIndex = 83; //N_001_000032_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dHeadOffset[0][1][1]);
			nIndex = 84; //N_001_000033_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End
		}
		if((gDProject.m_nSeparation == USE_DUAL && !m_bOdd) || gDProject.m_nSeparation == USE_2ND)
		{
			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dHeadOffset[1][0][0]);
			nIndex = 85; //N_001_000034_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dHeadOffset[1][0][1]);
			nIndex = 86; //N_001_000035_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dHeadOffset[1][1][0]);
			nIndex = 87; //N_001_000036_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

			strOPCTag.Format(_T("%s;%.1f;"),strLotID, gOPCParam.dHeadOffset[1][1][1]);
			nIndex = 88; //N_001_000037_00
			((CEasyDrillerDlg*)::AfxGetMainWnd())->SendMessage(UM_UPDATE_TAG, nIndex, reinterpret_cast<LPARAM>(&strOPCTag));  //817 Lot End

		}

	}

#endif
}
void CPaneAutoRun::GetSubToolParam(SUBTOOLDATA subTool, int nToolNo, int nSubToolNo)
{
	gOPCParam.nMainTool = nToolNo;
	gOPCParam.nSubTool = nSubToolNo;
	gOPCParam.nSubToolCount = subTool.nTotalShot;
	gOPCParam.nToolType = subTool.nToolType;
	gOPCParam.nBeamPath = subTool.nMask;
	gOPCParam.nDrillMethord = subTool.nShotMode;
	gOPCParam.nFreq = subTool.nFrequency;
	gOPCParam.nOnDelay = subTool.nLaserOnDelay;
	gOPCParam.nOffDelay = subTool.nLaserOffDelay;
	gOPCParam.nDrawSpeed = subTool.nDrawStepPeriod;
	gOPCParam.nJumpSpeed = subTool.nJumpStepPeriod;
	gOPCParam.nConnerDelay = subTool.nCornerDelay;
	gOPCParam.nJumpDelay = subTool.nJumpDelay;
	gOPCParam.LineDelay = subTool.nLineDelay;
	CString strTemp;
	strTemp.Format(_T("%s"), subTool.cFilePath);
//	gOPCParam.strAperture = strTemp;
	gOPCParam.nDummyType = gDProject.m_nDummyFreeType;
	for(int i = 0; i < 15; i++)
	{
		gOPCParam.nShotFreq[i] = (int)subTool.dShotMaxFreq[i];
		gOPCParam.dShotDuty[i] = subTool.dShotDuty[i];
	}
	OPCUpdateParameter(N_TOOL);
}
void CPaneAutoRun::CheckBasketInOut()
{

	char szResult[256];
	memset(szResult, 0, sizeof(szResult));
	BOOL bResult;
	m_bBasketLDIn = gDeviceFactory.GetMotor()->GetLoadBasketSignal(TRUE);
	m_bBasketUDIn = gDeviceFactory.GetMotor()->GetUnloadBasketSignal(TRUE); 
	m_bBasketLDOut = gDeviceFactory.GetMotor()->GetLoadBasketSignal(FALSE);
	m_bBasketUDOut = gDeviceFactory.GetMotor()->GetUnloadBasketSignal(FALSE);
	
	if(m_bBasketLDIn && !m_bOldBasketLDIn) //basket in
	{
		if(IsDrilling())
		{
			ErrMsgDlg(STDGNALM202);
			gDeviceFactory.GetMotor()->SetOutputBasket(TRUE);
			return;
		}
		//read 2d barcode  
//		gDeviceFactory.GetMotor()->Set2DBarcodeTrigger();
//		Sleep(500);
		gDeviceFactory.GetVision()->Get2DBarcode(szResult, TRUE);

		for(int i = 0; i < gLotInfo.nLastIndex; i++)
		{
			if(strcmp(szResult, gLotInfo.szBasketID[i]) == 0)
			{
				ErrMessage(_T("Same Basket ID is already in schedule"));
				gDeviceFactory.GetMotor()->SetOutputBasket(TRUE);
				m_bOldBasketLDIn = m_bBasketLDIn;
				return;
			}
		}

		m_pOPC->m_stcBasketID.SetWindowText(szResult);
		
		bResult = OPCBasket(TRUE, TRUE, szResult);
		int nIndex = gLotInfo.nLastIndex + 1;
		if(bResult)
		{
#ifndef __NO_USE_OPC__
			CDlgScheduleInfo dlg;
			if(dlg.MesDataCheck(szResult, nIndex, TRUE))
			{
				UpdateOPCDisplay();
				gDeviceFactory.GetMotor()->ResetBasketInfo(TRUE);
			}
#endif
		}
		else
		{

			bResult = OPCBasket(FALSE, TRUE, szResult);
			if(bResult)
				gDeviceFactory.GetMotor()->SetOutputBasket(TRUE);
		}
	}
	else if(!m_bBasketLDIn && m_bOldBasketLDIn)
	{
		OPCBasket(FALSE, TRUE, szResult);
	}

	if(m_bBasketUDIn && !m_bOldBasketUDIn) //basket in
	{
		if(IsDrilling())
		{
			ErrMsgDlg(STDGNALM202);
			gDeviceFactory.GetMotor()->SetOutputBasket(FALSE);
			return;
		}
		//read 2d barcode 
		
		gDeviceFactory.GetVision()->Get2DBarcode(szResult, FALSE);

//		m_pOPC->m_stcBasketID.SetWindowText(szResult);
		
//		for(int i =0 ; i< 10; i++)
//		strcpy(gLotInfo.szBasketID[i], szResult);

		if(gLotInfo.nLastIndex + 1 < MAX_LOTID_CNT)
			strcpy(gLotInfo.szBasketID[gLotInfo.nLastIndex], szResult);

		
		bResult = OPCBasket(TRUE, FALSE, szResult);
		
		if(bResult)
			gDeviceFactory.GetMotor()->ResetBasketInfo(FALSE);
		else
		{
			bResult = OPCBasket(FALSE, FALSE, szResult);
			if(bResult)
				gDeviceFactory.GetMotor()->SetOutputBasket(FALSE);
		}
	}
	else if(!m_bBasketUDIn && m_bOldBasketUDIn)
	{
		OPCBasket(FALSE, FALSE, szResult);
	}

	m_bOldBasketLDIn = m_bBasketLDIn;
	m_bOldBasketUDIn = m_bBasketUDIn;

}

BOOL CPaneAutoRun::SetAutoTemperature(BOOL bStartT)
{
	double d1stTemper, d2ndTemper; // auto Start T set
	gDeviceFactory.GetMotor()->GetTCTemperature(d1stTemper, d2ndTemper);

	if(d1stTemper <= -999 || d2ndTemper <= -999)
	{
		m_nErrMsgID = STDGNALM1032;
		return FALSE;
	}

	CString strFile, strLog;
	strFile.Format(_T("SCal_Time_Log"));
	if(bStartT)
	{
		gDeviceFactory.Get1stTemperCompen()->SetAutoRunStartTemperature(d1stTemper);
		gDeviceFactory.Get2ndTemperCompen()->SetAutoRunStartTemperature(d2ndTemper);
		strLog.Format(_T("Auto %d Board Start T\t %.3f \t %.3f"), m_nCurrentLotCount, d1stTemper, d2ndTemper);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
	else
	{
		BOOL b1st, b2nd;
		GetFirePanelInfo(b1st, b2nd);
		if(b1st)
			gDeviceFactory.Get1stTemperCompen()->SetAutoRunLastTemperature(d1stTemper);
		if(b2nd)
			gDeviceFactory.Get2ndTemperCompen()->SetAutoRunLastTemperature(d2ndTemper);

		strLog.Format(_T("Auto %d Board Last T\t %.3f \t %.3f, use 1st = %d, use 2nd = %d"), m_nCurrentLotCount, d1stTemper, d2ndTemper, b1st, b2nd);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
	return TRUE;
}

BOOL CPaneAutoRun::WaitTargetTToDown()
{
	double d1stTemper, d2ndTemper;
	int nCount = gProcessINI.m_sProcessOption.nSBTemperLongWaitTime * 10;
	int nTimeCnt = 0;
	while(TRUE)
	{
		gDeviceFactory.GetMotor()->GetTCTemperature(d1stTemper, d2ndTemper);
		if(gDProject.m_nSeparation == USE_1ST)
		{
			if(m_dTargetTemper >= d1stTemper)
				break;
		}
		else
		{
			if(m_dTargetTemper >= d2ndTemper )
				break;
		}

		nTimeCnt++;
		if(nTimeCnt > nCount)
			return TRUE;

		if(!CheckStatus()) // Stop확인
			return FALSE;
		::Sleep(100);
	}
	return TRUE;
}

double  CPaneAutoRun::GetAvgPower()
{
	int nBeamPath[MAX_TOOL_NO];
	int nHoleCount[MAX_TOOL_NO];
	double dAvgPower[MAX_TOOL_NO];
	double dShotCountPer[MAX_TOOL_NO];
	double dAvgPower2[MAX_TOOL_NO];
	double dResultPower = 0;
	memset(nBeamPath, -1, sizeof(nBeamPath));
	memset(nHoleCount, 0, sizeof(nHoleCount));
	memset(dShotCountPer, 0, sizeof(dShotCountPer));
	memset(dAvgPower, 0, sizeof(dAvgPower));
	memset(dAvgPower2, 0, sizeof(dAvgPower2));
	
	POSITION posSub;
	SUBTOOLDATA subTool;
	
	for(int i = ADDED_FID_TOOL; i < MAX_TOOL_NO; i++)
	{
		if(!gDProject.m_pToolCode[i]->m_bUseTool)
			continue;

		nBeamPath[i] = i;
		dAvgPower[i] = (gBeamPathINI.m_sBeampath.dPowCompensationTargetMax[nBeamPath[i]] +  gBeamPathINI.m_sBeampath.dPowCompensationTargetMin[nBeamPath[i]])/2.;

		posSub = gDProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		while(posSub)
		{
			subTool = gDProject.m_pToolCode[i]->m_SubToolData.GetNext(posSub);
			nHoleCount[i] += subTool.nTotalShot;
		}
	}
	int nTotalShot = gDProject.m_nTotalHole;
	for(int k =ADDED_FID_TOOL; k<MAX_TOOL_NO; k++)
	{
			if(!gDProject.m_pToolCode[k]->m_bUseTool)
				continue;

			dShotCountPer[k] = (double)nHoleCount[k] / (double)nTotalShot;
			dAvgPower2[k] = dAvgPower[k] * dShotCountPer[k];
			dResultPower += dAvgPower2[k];
	}
	return dResultPower;
}
BOOL CPaneAutoRun::SubDoLoading(BOOL b1st, BOOL b2nd)
{

#ifndef __KUNSAN_SAMSUNG_LARGE__
	ChangeBMPtoJPG();
	::Sleep(1000);
	return TRUE;
#endif

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	CString strFile, strLog;
	strFile.Format(_T("AutorunTrace"));

	if(!pMotor->SetLoadPickerDownOK(FALSE, FALSE))
	{
		m_nErrMsgID = STDGNALM719;
		return FALSE;
	}

	strLog.Format(_T("Picker down info down : 0, 0"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));


	int nWaitTime = gProcessINI.m_sProcessOption.nLoadTime * 1000; //sec
	int nCount = 0;
	while(!pMotor->IsHandlerOperation(HANDLER_LOADER_LOAD, FALSE, FALSE))
	{
		if(nCount >= nWaitTime)
		{
			strLog.Format(_T("Load start signal time out"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			m_nErrMsgID = STDGNALM719;

		
			return FALSE;
		}
		if(!CheckStatus())
		{
			return FALSE;
		}
		Sleep(100);
		nCount += 100;
	}
	

	if(!pMotor->GetReverseDirection())
	{
		if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX, gProcessINI.m_sProcessAutoSetting.dLoadPosY, TRUE))
		{
			m_nErrMsgID = STDGNALM438;
			return FALSE;
		}
	}
	else
	{
		if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dLoadPosX2, gProcessINI.m_sProcessAutoSetting.dLoadPosY2, TRUE))
		{
			m_nErrMsgID = STDGNALM438;
			return FALSE;
		}
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		return FALSE;
	}
	strLog.Format(_T("Table Move to Load Position"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	if(!pMotor->SetLoadPickerDownOK(b1st, b2nd))
	{
		m_nErrMsgID = STDGNALM719;
		return FALSE;
	}
	strLog.Format(_T("Picker down info down : %d, %d"), b1st, b2nd);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	ChangeBMPtoJPG();
	
	if(!WaitHandler(HANDLER_LOAD_PICKER_DOWN, b1st, b2nd))
	{
		m_nErrMsgID = STDGNALM719;

		strLog.Format(_T("Load picker down signal time out"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		return FALSE;
	}
	strLog.Format(_T("Load picker down signal in"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
	{
		pMotor->SetOutPort(PORT_TABLE_SUCTION1, b1st);
		pMotor->SetOutPort(PORT_TABLE_SUCTION2, b2nd);

		strLog.Format(_T("Set table suction on/off: %d, %d"), b1st, b2nd);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
//	Sleep(500);
	if(!pMotor->SetTablePCBExist(b1st, b2nd))
	{
		strLog.Format(_T("Current table info down fail: %d, %d"), b1st, b2nd);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		m_nErrMsgID = STDGNALM719;
		return FALSE;
	}
	strLog.Format(_T("Current table info down : %d, %d"), b1st, b2nd);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));


	return TRUE;
}
BOOL CPaneAutoRun::SubDoUnloading(BOOL b1st, BOOL b2nd)
{
#ifndef __KUNSAN_SAMSUNG_LARGE__
	::Sleep(1000);
	return TRUE;
#endif

#ifndef __MP920_MOTOR__
	DeviceMotor* pMotor = gDeviceFactory.GetMotor();
#else
	HMotor* pMotor = gDeviceFactory.GetMotor();
#endif
	CString strFile, strLog;
	strFile.Format(_T("AutorunTrace"));

	int nWaitTime = gProcessINI.m_sProcessOption.nUnloadTime * 1000; //sec
	int nCount = 0;
	while(!pMotor->IsHandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE, FALSE))
	{
		if(nCount >= nWaitTime)
		{
			strLog.Format(_T("Unload start signal time out"));
			::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
			m_nErrMsgID = STDGNALM726;
			return FALSE;
		}
		if(!CheckStatus())
		{
			return FALSE;
		}
		Sleep(100);
		nCount += 100;
	}
	
	if(!pMotor->SetUnloadPickerDownOK(FALSE, FALSE))
	{
		m_nErrMsgID = STDGNALM726;
		return FALSE;
	}
	strLog.Format(_T("Picker down info down : 0, 0"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	if(!pMotor->GetReverseDirection())
	{
		if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dUnloadPosX, gProcessINI.m_sProcessAutoSetting.dUnloadPosY, TRUE))
		{
			m_nErrMsgID = STDGNALM438;
			return FALSE;
		}
	}
	else
	{
		if(!pMotor->MotorMoveXY(gProcessINI.m_sProcessAutoSetting.dUnloadPosX2, gProcessINI.m_sProcessAutoSetting.dUnloadPosY2, TRUE))
		{
			m_nErrMsgID = STDGNALM438;
			return FALSE;
		}
	}
	if(!pMotor->InPositionIO(IND_X + IND_Y))
	{
		int nErrorAxis = gDeviceFactory.GetMotor()->GetInpositionError();
		CheckInpositionError(nErrorAxis);
		return FALSE;
	}
	strLog.Format(_T("Table move to unload position"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	if(!pMotor->SetUnloadPickerDownOK(b1st, b2nd))
	{
		m_nErrMsgID = STDGNALM726;
		return FALSE;
	}
	strLog.Format(_T("Picker down info down : %d, %d"), b1st, b2nd);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	if(!WaitHandler(HANDLER_UNLOAD_PICKER_DOWN, b1st, b2nd))
	{
		strLog.Format(_T("Unload picker down signal time out"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		m_nErrMsgID = STDGNALM726;
		return FALSE;
	}
		strLog.Format(_T("Unload picker down signal in"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	if(!gProcessINI.m_sProcessSystem.bNoUseSuction)
	{
		pMotor->SetOutPort(PORT_TABLE_SUCTION1, FALSE);
		pMotor->SetOutPort(PORT_TABLE_SUCTION2, FALSE);
			strLog.Format(_T("Set table suction on/off: 0, 0"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
	}
//	::Sleep(500);
	if(!pMotor->SetTablePCBExist(FALSE, FALSE))
	{
		
		strLog.Format(_T("Current table info down fail: 0, 0"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

		m_nErrMsgID = STDGNALM719;
		return FALSE;
	}
	strLog.Format(_T("Current table info down : 0, 0"));
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

	return TRUE;
}
BOOL CPaneAutoRun::WaitOPCRecvMessage()
{
#ifdef __TEST__
	return TRUE;
#endif
#ifdef __NO_USE_OPC__
	return TRUE;
#endif
	if( ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc == NULL)
		return TRUE;
	
	int nWaitTime = gProcessINI.m_sProcessOption.nOPCTimeOut * 100; // sec 
	
	m_dlgOPCWait.ShowWindow(SW_SHOW);
	m_dlgOPCWait.StartMeasurement(nWaitTime);
	BOOL bRecv = FALSE;
	int nCount = 0;
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->ResetRecvSignal();
	do
	{
		if(nCount > nWaitTime) //임의로 5초
		{
			m_dlgOPCWait.ShowWindow(SW_HIDE);
			return FALSE;
		}
		bRecv =  ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_bRecv;
		Sleep(10);
		nCount++;
		m_dlgOPCWait.UpdateMeasurement(nCount);
	}while(!bRecv);
	if(bRecv)
	{
		((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->m_bRecv = FALSE;
	}
	m_dlgOPCWait.ShowWindow(SW_HIDE);
	return TRUE;
}
void CPaneAutoRun::ResetOPCRecvMessage()
{
#ifndef __NO_USE_OPC__
	 ((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pOpc->ResetRecvSignal();
#endif
}

BOOL CPaneAutoRun::GetRepeatCompenTransResult(int nX, int nY, BOOL b1st, int& nResultX, int& nResultY)
{
	double dResultX, dResultY;
	if(b1st)
	{
		m_2DTrans1stForTempCompen.TransformPoint((double)nX, (double)nY, dResultX, dResultY);
	}
	else
	{
		m_2DTrans2ndForTempCompen.TransformPoint((double)nX, (double)nY, dResultX, dResultY);
	}
	nResultX = (int)dResultX;
	nResultY = (int)dResultY;
	if(nResultX < 0 || nResultX > 65535 ||
		nResultY < 0 || nResultY > 65535)
	{
		CString strFile, strLog;
		strFile.Format(_T("SCal_Time_Log"));
		strLog.Format(_T("Repeat Compensation Field over Error\t %d \t d"), nResultX, nResultY);
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));
		return FALSE;
	}

	return TRUE;
}

void CPaneAutoRun::CheckVaccumMotor()
{
	int nSuction = gDeviceFactory.GetMotor()->GetCurrentSuction();
	BOOL bMotor = gDeviceFactory.GetMotor()->GetCurrentSuctionMotor();
	BOOL bMasterSuction = FALSE;
	BOOL bSlaveSuction = FALSE;
		
	bMasterSuction = nSuction & 0x01;
	bSlaveSuction = nSuction & 0x02;

	if(nSuction & 0x01)
		bMasterSuction = TRUE;
	else
		bMasterSuction = FALSE;
		
	if(nSuction & 0x02)
		bSlaveSuction = TRUE;
	else
		bSlaveSuction = FALSE;

	if(m_bAutoRun == TRUE || bMotor == FALSE || bMasterSuction == TRUE || bSlaveSuction == TRUE)
	{
		m_VaccumTime.StartTime();
		m_bStartVacuumTime = FALSE;
	}
	else
	{
		if(m_bStartVacuumTime == FALSE)
			m_VaccumTime.StartTime();
		m_bStartVacuumTime = TRUE;

		double dVaccumMotorOnTime = m_VaccumTime.PresentTime();

		if(dVaccumMotorOnTime > (60 * 30))
		{
			gDeviceFactory.GetMotor()->Table1VacuumMotor(FALSE);
			m_VaccumTime.Finish();
		}
	}
}

void CPaneAutoRun::CheckAbsoluteScale(BOOL& bScaleOK)
{
	if(gDProject.m_nSeparation != USE_2ND)
	{
		if( m_dCurrentScaleX[0] < gProcessINI.m_sProcessFidFind.dScaleMinusLimit ||
			m_dCurrentScaleX[0] > gProcessINI.m_sProcessFidFind.dScalePlusLimit  ||
			m_dCurrentScaleY[0]	< gProcessINI.m_sProcessFidFind.dScaleMinusLimit ||
			m_dCurrentScaleY[0]	> gProcessINI.m_sProcessFidFind.dScalePlusLimit )
			bScaleOK = FALSE;
		else
			bScaleOK = TRUE;
	}
	else 
	{
		if( m_dCurrentScaleX[1] < gProcessINI.m_sProcessFidFind.dScaleMinusLimit ||
			m_dCurrentScaleX[1] > gProcessINI.m_sProcessFidFind.dScalePlusLimit  ||
			m_dCurrentScaleY[1]	< gProcessINI.m_sProcessFidFind.dScaleMinusLimit ||
			m_dCurrentScaleY[1]	> gProcessINI.m_sProcessFidFind.dScalePlusLimit )
			bScaleOK = FALSE;
		else
			bScaleOK = TRUE;	
	}
}

BOOL CPaneAutoRun::GetCurrentLotIndex()
{
	// 20131001
	gLotInfo.nTotalFireCount = m_nTotalCurrentLotCount;
	int nTotalLotCount = 0;
	m_nCurrentLotIndex = -1;
	m_bHaveToChangeProject = FALSE;
	for(int i = 0; i < gLotInfo.nLastIndex; i++)
	{
		nTotalLotCount += gLotInfo.nLotCount[i];
		if(m_nTotalCurrentLotCount < nTotalLotCount)
		{
			m_nCurrentLotIndex = i;
			if(m_nTotalCurrentLotCount == nTotalLotCount - gLotInfo.nLotCount[i]) // auto project change 조건임
			{
				m_bHaveToChangeProject = TRUE;
				m_nCurrentLotCount = 0;
				m_nNGLotCount = 0;
				if(i % 2 == 1) // 스캐줄일때 역방향으로 돌아올때는 이전 NG를 바로 더해줘야 lot 가공이 밀리지 않는다.
				{
					m_nTotalCurrentLotCount +=  gLotInfo.nNGLotCount[i - 1];
					m_nNGLotCount += gLotInfo.nNGLotCount[i - 1];
				
					CString strFile, strLog;
					strFile.Format(_T("AutorunTrace"));
					strLog.Format(_T("Lot Index(%d), m_nTotalCurrentLotCount(%d), nTotalLotCount(%d), gLotInfo.nLotCount(%d), gLotInfo.nNGLotCount[LotIndex-1](%d)"),i, m_nTotalCurrentLotCount, nTotalLotCount, gLotInfo.nLotCount[i],gLotInfo.nNGLotCount[i - 1]  );
					::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strLog));

				}
			}
			m_nInputLot = gLotInfo.nLotCount[i];
			break;
		}
		if(m_nTotalCurrentLotCount == nTotalLotCount && i == gLotInfo.nLastIndex - 1)
		{
			m_nCurrentLotIndex = i + 1;
			m_nInputLot = 0;
			return TRUE;
		}
	}
	if(m_nCurrentLotIndex == -1)
		return FALSE;

	return TRUE;
}
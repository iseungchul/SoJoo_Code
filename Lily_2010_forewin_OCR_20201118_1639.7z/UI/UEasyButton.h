#if !defined(AFX_UEASYBUTTON_H__AC521E74_9A67_482A_B72C_2EC9B0BC22A5__INCLUDED_)
#define AFX_UEASYBUTTON_H__AC521E74_9A67_482A_B72C_2EC9B0BC22A5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UEasyButton.h : header file
//

#define	TTS_BALLOON						0x40

/////////////////////////////////////////////////////////////////////////////
// UEasyButton window

// yhchung 2011.08.05 ��ư �ܰ��� �κ� �߰�

class UEasyButton : public CButton
{
// Construction
public:
	UEasyButton();

// Attributes
public:
	enum {
			RECT_NONE = 0,
			RECT_LEFT,
			RECT_RIGHT,
			RECT_BOTH
		};
	
	int		m_nColorType; // 2011.08.05
	
// Operations
public:
	void	SetRectAlign(int nRectAlign)	{ m_nRectAlign = nRectAlign; }
	void	SetClick(BOOL bClick);//	{ m_bClick = bClick; }
	BOOL	GetClick()				{ return m_bClick; }
	void	TimerControl(BOOL bStart);
	void	SetBtnCursor(int nCursorID);

	void	InitToolTip();
	void	SetToolTipText(LPCTSTR lpszText, BOOL bActivate=TRUE);
	void	ActivateToolTip(BOOL bEnable=TRUE);
	void	SetColorType(int nType) {m_nColorType = nType; } // 2011.08.05

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(UEasyButton)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~UEasyButton();

	// Generated message map functions
protected:
	void DrawText(LPDRAWITEMSTRUCT lpDrawItemStruct);
	void DrawBtn(LPDRAWITEMSTRUCT lpDrawItemStruct);

	//{{AFX_MSG(UEasyButton)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
	afx_msg LRESULT OnMouseLeave(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
private:
	BOOL			m_bCursorInBtn;
	BOOL			m_bClick;
	int				m_nTimerID;
	int				m_nRectAlign;
	HCURSOR			m_hCursor;
	CToolTipCtrl	m_ttcToolTip;
	CRect			m_rtLeft;
	CRect			m_rtRight;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UEASYBUTTON_H__AC521E74_9A67_482A_B72C_2EC9B0BC22A5__INCLUDED_)

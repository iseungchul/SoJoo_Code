// CPaneLogManagerOffset.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneLogManagerOffset.h"
#include <cfloat>
#include "..\Model\DEasyDrillerIni.h"
#include "..\model\dsystemini.h"
#include "..\Model\DProject.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerJobTime
IMPLEMENT_DYNCREATE(CPaneLogManagerOffset, CFormView)

CPaneLogManagerOffset::CPaneLogManagerOffset()
	: CFormView(CPaneLogManagerOffset::IDD)
{
	//{{AFX_DATA_INIT(CPaneLogManagerOffset)
	m_ctEnd = CTime::GetCurrentTime();
	m_ctStart = CTime::GetCurrentTime();

	m_nTimerID = 0;
	m_bShow = FALSE;
	m_bOnTimer = FALSE;
	m_nSelectHead = -1;
	m_strFilePath = "";


	//}}AFX_DATA_INIT
	
	memset(&m_lpszColumnHead2, 0, sizeof(m_lpszColumnHead2));

}

CPaneLogManagerOffset::~CPaneLogManagerOffset()
{
}

void CPaneLogManagerOffset::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneLogManagerOffset)
	DDX_Control(pDX, IDC_LIST_FIDUCIAL_SCALE, m_listFiducialScale);
	DDX_Control(pDX, IDC_DATETIMEPICKER_START, m_dtcStart);
	DDX_Control(pDX, IDC_DATETIMEPICKER_END, m_dtcEnd);
	DDX_Control(pDX, IDC_BUTTON_VIEW, m_btnView);
	DDX_Control(pDX, IDC_BUTTON_FIDSAVE, m_btnSave);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER_END, m_ctEnd);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER_START, m_ctStart);
	DDX_Control(pDX, IDC_DATETIMEPICKER_START, m_dtcStart);
	DDX_Control(pDX, IDC_DATETIMEPICKER_END, m_dtcEnd);
	DDX_Control(pDX, IDC_COMBO_CHOICE, m_cmbHead);

	DDX_Control(pDX, IDC_EDIT_FIDUCIALLOG_HOUR_START, m_edtHourStart);
	DDX_Control(pDX, IDC_EDIT_FIDUCIALLOG_HOUR_END, m_edtHourEnd);
	DDX_Control(pDX, IDC_EDIT_LOTID, m_edtLotID);
	//DDX_CBIndex(pDX, IDC_COMBO_HEAD, m_nSelectHead);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneLogManagerOffset, CFormView)
	//{{AFX_MSG_MAP(CPaneLogManagerOffset)
	ON_WM_TIMER()
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BUTTON_VIEW, OnButtonView)
	ON_BN_CLICKED(IDC_BUTTON_FIDSAVE,OnButtonSave)
	ON_WM_DESTROY()
	ON_NOTIFY(NM_CLICK, IDC_LIST_FIDUCIAL_SCALE, OnClickListLog)
	ON_CBN_SELCHANGE(IDC_COMBO_CHOICE, OnSelchangeCombo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerOffset diagnostics

#ifdef _DEBUG
void CPaneLogManagerOffset::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneLogManagerOffset::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneLogManagerJobTime message handlers






void CPaneLogManagerOffset::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
	InitStaticControl();
	InitEtcControl();
	InitEditControl();
	InitListControl();
	

	m_cmbHead.SetCurSel(0);
	m_nSelectHead = 0;

}

BOOL CPaneLogManagerOffset::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}


void CPaneLogManagerOffset::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	
	// View
	m_btnView.SetFont( &m_fntBtn );
	m_btnView.SetFlat( FALSE );
	m_btnView.EnableBallonToolTip();
	m_btnView.SetToolTipText( _T("View") );
	m_btnView.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnView.SetBtnCursor(IDC_HAND_1);

	// save
	m_btnSave.SetFont( &m_fntBtn );
	m_btnSave.SetFlat( FALSE );
	m_btnSave.EnableBallonToolTip();
	m_btnSave.SetToolTipText( _T("Save") );
	m_btnSave.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnSave.SetBtnCursor(IDC_HAND_1);

}

void CPaneLogManagerOffset::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");
	
// 	m_edtHourStart.SetFont( &m_fntEdit );
// 	m_edtHourStart.SetReceivedFlag( 5 ); 
// 
// 	m_edtHourEnd.SetFont( &m_fntEdit );
// 	m_edtHourEnd.SetReceivedFlag( 5 ); 



	m_edtHourStart.SetFont( &m_fntEdit );
	m_edtHourStart.SetForeColor( BLACK_COLOR );
	m_edtHourStart.SetBackColor( WHITE_COLOR );
	m_edtHourStart.SetReceivedFlag( 1 ); 
	m_edtHourStart.SetWindowText( _T("0") );


	m_edtHourEnd.SetFont( &m_fntEdit );
	m_edtHourEnd.SetForeColor( BLACK_COLOR );
	m_edtHourEnd.SetBackColor( WHITE_COLOR );
	m_edtHourEnd.SetReceivedFlag( 1 ); // Floating-Point
	m_edtHourEnd.SetWindowText( _T("24") );

	m_edtLotID.SetFont( &m_fntEdit );
	m_edtLotID.SetForeColor( BLACK_COLOR );
	m_edtLotID.SetBackColor( WHITE_COLOR );
	m_edtLotID.SetWindowText( _T("") );


}


void CPaneLogManagerOffset::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");
	
	GetDlgItem(IDC_STATIC_1)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_LOTID)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_TIME)->SetFont( &m_fntStatic );
	
	GetDlgItem(IDC_STATIC_DATE)->SetFont( &m_fntStatic );
}

void CPaneLogManagerOffset::InitListControl()
{
	// Set List Font
	if(&m_fntList == NULL)
		m_fntList.CreatePointFont(100, "Arial Bold");
	m_listFiducialScale.SetFont(&m_fntList);
	
	m_listFiducialScale.SetExtendedStyle(m_listFiducialScale.GetExtendedStyle() | LVM_SETCOLUMNORDERARRAY);
	
	m_ImageList.DeleteImageList();
	m_ImageList.Create(IDB_SMALL_TYPE, 16, 1, RGB(0, 0, 0));
	
	m_listFiducialScale.DeleteAllItems();
	m_listFiducialScale.SetImageList(&m_ImageList, LVSIL_SMALL);

	for(int i = 12; i >= 0; i--)
		m_listFiducialScale.DeleteColumn(i);

	if(m_nSelectHead == 0) // scal 
	{
		lstrcpy(m_lpszColumnHead[0], " Date ");
		lstrcpy(m_lpszColumnHead[1], " Time " );
		lstrcpy(m_lpszColumnHead[2], " Panel ");
		lstrcpy(m_lpszColumnHead[3], " Operation ");
		lstrcpy(m_lpszColumnHead[4], " Cam ");
		lstrcpy(m_lpszColumnHead[5], " Division "); 
		lstrcpy(m_lpszColumnHead[6], " BeamPath ");
		lstrcpy(m_lpszColumnHead[7], " Offset X ");
		lstrcpy(m_lpszColumnHead[8], " Offset Y ");
		lstrcpy(m_lpszColumnHead[9], " Offset R ");
		lstrcpy(m_lpszColumnHead[10], " Accept Score ");
		lstrcpy(m_lpszColumnHead[11], " Edge Score ");
		
		m_listFiducialScale.InsertColumn(0, _T(" "), LVCFMT_CENTER, 1);
		m_listFiducialScale.InsertColumn(1, m_lpszColumnHead[0], LVCFMT_CENTER, 80);
		m_listFiducialScale.InsertColumn(2, m_lpszColumnHead[1], LVCFMT_CENTER, 70);
		m_listFiducialScale.InsertColumn(3, m_lpszColumnHead[2], LVCFMT_CENTER, 60);
		m_listFiducialScale.InsertColumn(4, m_lpszColumnHead[3], LVCFMT_CENTER, 90);
		m_listFiducialScale.InsertColumn(5, m_lpszColumnHead[4], LVCFMT_CENTER, 60);
		m_listFiducialScale.InsertColumn(6, m_lpszColumnHead[5], LVCFMT_CENTER, 70);
		m_listFiducialScale.InsertColumn(7, m_lpszColumnHead[6], LVCFMT_CENTER, 90);
		m_listFiducialScale.InsertColumn(8, m_lpszColumnHead[7], LVCFMT_CENTER, 80);
		m_listFiducialScale.InsertColumn(9, m_lpszColumnHead[8], LVCFMT_CENTER, 80);
		m_listFiducialScale.InsertColumn(10, m_lpszColumnHead[9], LVCFMT_CENTER, 80);
		m_listFiducialScale.InsertColumn(11, m_lpszColumnHead[10], LVCFMT_CENTER, 105);
		m_listFiducialScale.InsertColumn(12, m_lpszColumnHead[11], LVCFMT_CENTER, 95);
	}
	else //head offset 
	{
		lstrcpy(m_lpszColumnHead[0], " Date ");
		lstrcpy(m_lpszColumnHead[1], " Time " );
		lstrcpy(m_lpszColumnHead[2], " Cam ");
		lstrcpy(m_lpszColumnHead[3], " Old X ");
		lstrcpy(m_lpszColumnHead[4], " New X "); 
		lstrcpy(m_lpszColumnHead[5], " Old Y ");
		lstrcpy(m_lpszColumnHead[6], " New Y ");
		lstrcpy(m_lpszColumnHead[7], " Old Z ");
		lstrcpy(m_lpszColumnHead[8], " New Z ");

		m_listFiducialScale.InsertColumn(0, _T(" "), LVCFMT_CENTER, 1);
		m_listFiducialScale.InsertColumn(1, m_lpszColumnHead[0], LVCFMT_CENTER, 100);
		m_listFiducialScale.InsertColumn(2, m_lpszColumnHead[1], LVCFMT_CENTER, 100);
		m_listFiducialScale.InsertColumn(3, m_lpszColumnHead[2], LVCFMT_CENTER, 120);
		m_listFiducialScale.InsertColumn(4, m_lpszColumnHead[3], LVCFMT_CENTER, 105);
		m_listFiducialScale.InsertColumn(5, m_lpszColumnHead[4], LVCFMT_CENTER, 105);
		m_listFiducialScale.InsertColumn(6, m_lpszColumnHead[5], LVCFMT_CENTER, 105);
		m_listFiducialScale.InsertColumn(7, m_lpszColumnHead[6], LVCFMT_CENTER, 105);
		m_listFiducialScale.InsertColumn(8, m_lpszColumnHead[7], LVCFMT_CENTER, 105);
		m_listFiducialScale.InsertColumn(9, m_lpszColumnHead[8], LVCFMT_CENTER, 105);
	}

}

void CPaneLogManagerOffset::InitEtcControl()
{
	// Set Etc Font
	m_fntEtc.CreatePointFont(150, "Arial Bold");	
	m_dtcStart.SetFont( &m_fntEtc );
	m_dtcEnd.SetFont( &m_fntEtc );

	m_cmbHead.SetFont( &m_fntEtc );
	m_nSelectHead = 0;
	m_cmbHead.ResetContent();
	m_cmbHead.AddString(_T("S.Cal"));
	m_cmbHead.AddString(_T("Head Offset"));
	m_cmbHead.SetCurSel(m_nSelectHead);
}



void CPaneLogManagerOffset::OnTimer(UINT nIDEvent) 
{	
	CFormView::OnTimer(nIDEvent);
}



void CPaneLogManagerOffset::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntEtc.DeleteObject();
	m_fntList.DeleteObject();
	m_fntStatic.DeleteObject();
	m_fntEdit.DeleteObject();
	
	CFormView::OnDestroy();
}

void CPaneLogManagerOffset::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

}


void CPaneLogManagerOffset::OnButtonView()
{
	UpdateData(TRUE);
	if(!CheckHour())
		return ;

	UpdateTime();
	m_bDataAdd = FALSE;

	m_strDate.Format(_T(""));

	m_nTotalTime[0] = m_nTotalTime[1] = m_nTotalTime[2] = m_nTotalTime[3] = m_nTotalTime[4] = 0;
	m_nSumTime[0] = m_nSumTime[1] = m_nSumTime[2] = m_nSumTime[3] = m_nSumTime[4] = 0;
	
	m_nOldYear = -1;
	m_listFiducialScale.DeleteAllItems();
	m_strLogDetailArray.RemoveAll();
	
	int i,j;
	
	if( (m_ctStart.GetYear() != m_ctEnd.GetYear() ) && (m_ctStart.GetMonth() != m_ctEnd.GetMonth()))
	{
		for(i = m_ctStart.GetYear() ; i <= m_ctEnd.GetYear(); i++)
		{
			if(i == m_ctStart.GetYear() )
			{
				for( j =  m_ctStart.GetMonth(); j <= 12; j++)
				{
					MakeFileString(i ,j);			
					FillList();
				}
			}
			else if( i == m_ctEnd.GetYear() )
			{
				for( j =  m_ctStart.GetMonth(); j <= m_ctEnd.GetMonth(); j++)
				{
					MakeFileString(i ,j);			
					FillList();
				}
			}
			else
			{
				for( j =  1; j <= 12; j++)
				{
					MakeFileString(i ,j);			
					FillList();
				}
			}
		}
	}
	else if( (m_ctStart.GetMonth() != m_ctEnd.GetMonth() ) )
	{
		for(int i = m_ctStart.GetMonth(); i <= m_ctEnd.GetMonth(); i++)
		{
			MakeFileString(m_ctEnd.GetYear() ,i);		
			FillList();
		}
	}
	else
	{
		MakeFileString(m_ctEnd.GetYear(),m_ctEnd.GetMonth());
		FillList();
	}
}

void CPaneLogManagerOffset::UpdateTime()
{
	if (m_ctStart > m_ctEnd)
	{
		m_ctStart = m_ctEnd;
		UpdateData(FALSE);
	}

	int nStartHour, nEndHour;
	CString strData;
	
	m_edtHourStart.GetWindowText( strData );
	nStartHour = atoi((LPSTR)(LPCTSTR) strData);
	
	m_edtHourEnd.GetWindowText( strData );
	nEndHour = atoi((LPSTR)(LPCTSTR) strData);

	int nYear = m_ctStart.GetYear();
	int nMon = m_ctStart.GetMonth();
	int nDay = m_ctStart.GetDay();

	m_ctStart = CTime(nYear, nMon, nDay, nStartHour, 0, 0);
	
	nYear = m_ctEnd.GetYear();
	nMon = m_ctEnd.GetMonth();
	nDay = m_ctEnd.GetDay();
	
	if(nEndHour == 24)
		m_ctEnd = CTime(nYear, nMon, nDay, nEndHour-1, 59, 59);
	else
		m_ctEnd = CTime(nYear, nMon, nDay, nEndHour, 0, 0);
}

void CPaneLogManagerOffset::MakeFileString(int nYear, int nMonth)
{
	CString strProcessLog;
	strProcessLog.Format(_T("%s"), gEasyDrillerINI.m_clsDirPath.GetProcessLogDir());	
	CString strFiducialScaleFile(strProcessLog);
	if(m_cmbHead.GetCurSel() == 0)
		strFiducialScaleFile += _T("SCalLog");
	else
		strFiducialScaleFile += _T("ChangeHeadOffset");

	CString strTime;
	strTime.Format(_T("%02d%02d"),nYear,nMonth);
	m_strFilePath = strFiducialScaleFile + strTime;	
}

void CPaneLogManagerOffset::FillList()
{
	CString strFiducialScaleFile = m_strFilePath;
	BOOL bCamOffset = m_cmbHead.GetCurSel();

	int nStartYear = m_ctStart.GetYear();
	int nStartMon = m_ctStart.GetMonth();
	int nStartDay = m_ctStart.GetDay();
	int nEndYear = m_ctEnd.GetYear();
	int nEndMon = m_ctEnd.GetMonth();
	int nEndDay = m_ctEnd.GetDay();

	FILE *fp;

	if(NULL != fopen_s(&fp, (LPCTSTR) strFiducialScaleFile,"r"))
		return ;

	TCHAR szBuf[8192];
	TCHAR *token, seps[] = _T("|\r\n");
	TCHAR *szNext;

	CString strTime, strDate, strPanel, strOP, strCam, strDivision, strOffsetX, strOffsetY, strTemp, strOffsetR, strBeamPath, strScore1, strScore2;
	CString strOldX, strOldY, strOldZ, strNewX, strNewY, strNewZ;
	int nYear, nMon, nDay;
	for(int nStart = m_listFiducialScale.GetItemCount(); fgets(szBuf, 8192, fp); nStart++)
	{
		if (NULL == (token = strtok_s(szBuf, seps, &szNext)))		// ��¥
		{
			if (feof(fp))
				break;
			else
				continue;
		}
		
		strDate = token;
		strDate.TrimLeft();
		strDate.TrimRight();
		
		int nPos = strDate.Find(_T('/'));
		int nLen = strDate.GetLength();
		nYear = atoi(strDate.Left(nPos));
		strTemp = strDate.Right(nLen - nPos - 1);
		nPos = strTemp.Find(_T('/'));
		nLen = strTemp.GetLength();
		nMon = atoi(strTemp.Left(nPos));
		nDay = atoi(strTemp.Right(nLen - nPos - 1));
		
		if (NULL == (token = strtok_s(NULL, seps, &szNext)))		// �ð�
			continue;
		
		strTime = token;
		strTime.TrimLeft();
		strTime.TrimRight();

		// �ð� �̱�	
		nPos = strTime.Find(_T(':'));
		nLen = strTime.GetLength();
		int nHour = atoi(strTime.Left(nPos));
		
		CTime cTime2(nYear, nMon, nDay, nHour, 1, 1);
		if (cTime2 < m_ctStart || cTime2 > m_ctEnd)
		{
			m_strDate.Format(_T(""));
			continue;
		}

		if(!bCamOffset)
		{
			//Panel
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;

			strPanel = token; 
			strPanel.TrimLeft(); 
			strPanel.TrimRight();

			//Operation
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strOP = token; 
			strOP.TrimLeft(); 
			strOP.TrimRight();

			// Cam
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strCam = token; 
			strCam.TrimLeft(); 
			strCam.TrimRight();

			// Division
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strDivision = token; 
			strDivision.TrimLeft(); 
			strDivision.TrimRight();

			// Offset X
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strOffsetX = token; 
			strOffsetX.TrimLeft(); 
			strOffsetX.TrimRight();

			// Offset Y
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strOffsetY = token; 
			strOffsetY.TrimLeft(); 
			strOffsetY.TrimRight();

			// Offset R
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;

			strOffsetR = token; 
			strOffsetR.TrimLeft(); 
			strOffsetR.TrimRight();

			// BeamPath
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;

			strBeamPath = token; 
			strBeamPath.TrimLeft(); 
			strBeamPath.TrimRight();

			// Accept Score
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;

			strScore1 = token; 
			strScore1.TrimLeft(); 
			strScore1.TrimRight();

			// Edge Score
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;

			strScore2 = token; 
			strScore2.TrimLeft(); 
			strScore2.TrimRight();

			int nInsert = m_listFiducialScale.InsertItem(nStart,_T(""));
			m_listFiducialScale.SetItemText(nInsert,1,strDate);
			m_listFiducialScale.SetItemText(nInsert,2,strTime);
			m_listFiducialScale.SetItemText(nInsert,3,strPanel);
			m_listFiducialScale.SetItemText(nInsert,4,strOP);
			m_listFiducialScale.SetItemText(nInsert,5,strCam);
			m_listFiducialScale.SetItemText(nInsert,6,strDivision);
			m_listFiducialScale.SetItemText(nInsert,7, strBeamPath);
			m_listFiducialScale.SetItemText(nInsert,8,strOffsetX);
			m_listFiducialScale.SetItemText(nInsert,9,strOffsetY);	
			m_listFiducialScale.SetItemText(nInsert,10,strOffsetR);
			m_listFiducialScale.SetItemText(nInsert,11,strScore1);
			m_listFiducialScale.SetItemText(nInsert,12,strScore2);
		}
		else
		{
			//Cam
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strCam = token; 
			strCam.TrimLeft(); 
			strCam.TrimRight();

			//Old X
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strOldX = token; 
			strOldX.TrimLeft(); 
			strOldX.TrimRight();

			//New X
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strNewX = token; 
			strNewX.TrimLeft(); 
			strNewX.TrimRight();

			//Old Y
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strOldY = token; 
			strOldY.TrimLeft(); 
			strOldY.TrimRight();
			
			//New Y
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strNewY = token; 
			strNewY.TrimLeft(); 
			strNewY.TrimRight();

			//Old Z
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strOldZ = token; 
			strOldZ.TrimLeft(); 
			strOldZ.TrimRight();
			
			//New Z
			if(NULL == (token = strtok_s(NULL, seps, &szNext)))
				continue;
			
			strNewZ = token; 
			strNewZ.TrimLeft(); 
			strNewZ.TrimRight();

			int nInsert = m_listFiducialScale.InsertItem(nStart,_T(""));
			m_listFiducialScale.SetItemText(nInsert,1,strDate);
			m_listFiducialScale.SetItemText(nInsert,2,strTime);
			m_listFiducialScale.SetItemText(nInsert,3,strCam);
			m_listFiducialScale.SetItemText(nInsert,4,strOldX);
			m_listFiducialScale.SetItemText(nInsert,5,strNewX);
			m_listFiducialScale.SetItemText(nInsert,6,strOldY);
			m_listFiducialScale.SetItemText(nInsert,7,strNewY);
			m_listFiducialScale.SetItemText(nInsert,8,strOldZ);
			m_listFiducialScale.SetItemText(nInsert,9,strNewZ);
		}
	}
	fclose(fp);
}

void CPaneLogManagerOffset::OnClickListLog(NMHDR* pNMHDR, LRESULT* pResult) 
{
	ShowDetailInformation();
	*pResult = 0;
}

void CPaneLogManagerOffset::ShowDetailInformation()
{
	int nSel = m_listFiducialScale.GetSelectionMark();
	if(-1 == nSel)
		return;
}

void CPaneLogManagerOffset::OnButtonSave()
{
	UpdateData(TRUE);

	
	if (0 == m_listFiducialScale.GetItemCount())
		return;
	
	TCHAR szFilter[] = _T("JobTime File(*.txt)|*.txt||");
	CFileDialog filedlg(FALSE, _T("txt"), _T(""), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);
	
	//	filedlg.m_ofn.lpstrInitialDir = _T("C:\\");
	
	if(IDOK == filedlg.DoModal())
	{
		CString strSaveAsProjectFileName = filedlg.GetPathName();
		WriteLogFile(strSaveAsProjectFileName);
	}
	else
		return;	
}

void CPaneLogManagerOffset::WriteLogFile(CString& strSaveFileName)
{
	CStdioFile cFile;
	TCHAR seps[] = _T(":\n");
	const CString strSeps = _T(":\n");
	TCHAR szBuf[2048] ={0,};
	CString strDetail, strLine;
	CString str1, str2, str3, str4, str5, str6;
	int nMax = m_listFiducialScale.GetItemCount();

	if (FALSE == cFile.Open(strSaveFileName, CFile::modeCreate | CFile::modeWrite))
	{
		ErrMessage(IDS_CREATE_FILE_ERR, MB_ICONERROR);
		return;
	}
	
	TRY
	{
		if(m_nSelectHead == 0)
		{
			strLine.Format(_T("Date\t PreHeat\t S Cal.\t Power\t Drill\t TotalTime\t \n"));
			strDetail += strLine;
			
			for (int i = 0; i < nMax; i++)
			{	
				str1 = m_listFiducialScale.GetItemText(i, 1);
				str2 = m_listFiducialScale.GetItemText(i, 2);
				str3 = m_listFiducialScale.GetItemText(i, 3);
				str4 = m_listFiducialScale.GetItemText(i, 4);
				str5 = m_listFiducialScale.GetItemText(i, 5);
				str6 = m_listFiducialScale.GetItemText(i, 6);

				strLine.Format(_T("%s\t %s\t %s\t %s\t %s\t %s\t \n"),
					str1, str2, str3, str4, str5, str6);
				strDetail += strLine;
				cFile.WriteString(strDetail);
				strDetail ="";		
			}
		}
		else
		{
			strLine.Format(_T("Date\t Name\t Start Time\t End Time\t Time\t \n"));
			strDetail += strLine;
			
			for (int i = 0; i < nMax; i++)
			{	
				str1 = m_listFiducialScale.GetItemText(i, 1);
				str2 = m_listFiducialScale.GetItemText(i, 2);
				str3 = m_listFiducialScale.GetItemText(i, 3);
				str4 = m_listFiducialScale.GetItemText(i, 4);
				str5 = m_listFiducialScale.GetItemText(i, 5);
				
				strLine.Format(_T("%s\t %s\t %s\t %s\t %s\t \n"),
					str1, str2, str3, str4, str5);
				strDetail += strLine;
				cFile.WriteString(strDetail);
				strDetail ="";		
			}
		}
	}
	CATCH (CFileException, e)
	{
		e->ReportError();
		e->Delete();
	}
	END_CATCH
		
	cFile.Close();
}

BOOL CPaneLogManagerOffset::CheckHour()
{
	UpdateData(TRUE);

	CString strData;
	
	m_edtHourStart.GetWindowText( strData );
	m_nStartHour = atoi((LPSTR)(LPCTSTR) strData);
	
	m_edtHourEnd.GetWindowText( strData );
	m_nEndHour = atoi((LPSTR)(LPCTSTR) strData);


	if( (m_nStartHour >  m_nEndHour)  || ( m_nStartHour > 24 || 0 > m_nStartHour) || ( m_nEndHour > 24 || 0 > m_nEndHour) )
	{	
		ErrMessage(_T("Please change Time Value "));
		return FALSE;
	}

	return TRUE;


}

void CPaneLogManagerOffset::OnSelchangeCombo() 
{
	m_nSelectHead = m_cmbHead.GetCurSel();
	InitListControl();
}

#if !defined(AFX_PANERECIPEGENDRILLMETHOD_H__C28B1E8B_E58C_4D99_9D35_A37996563B80__INCLUDED_)
#define AFX_PANERECIPEGENDRILLMETHOD_H__C28B1E8B_E58C_4D99_9D35_A37996563B80__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneRecipeGenDrillMethod.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenDrillMethod form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "ColorEdit.h"
#include "UEasyButtonEx.h"

class DProject;
class CPaneRecipeGenDrillMethod : public CFormView
{
protected:
	CPaneRecipeGenDrillMethod();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneRecipeGenDrillMethod)

// Form Data
public:
	//{{AFX_DATA(CPaneRecipeGenDrillMethod)
	enum { IDD = IDD_DLG_RECIPE_GEN_DRILLMETHOD };
	UEasyButtonEx	m_chkToolOrder;
	CColorEdit	m_edtPCBThickness;
	UEasyButtonEx	m_btnMeasuringThickness;
	int		m_nUsePanel;
	int		m_nFieldRotation;
	int		m_nMirro;
	int		m_nStageMovingDir;
//	int		m_nScannerMovingDir;
	int		m_nDrillMethod;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:
	BOOL SetData();
	BOOL		GetData(DProject& tempDProject);
	void		InitBtnControl();
	void		InitStaticControl();
	void		InitEditControl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneRecipeGenDrillMethod)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneRecipeGenDrillMethod();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CFont		m_fntBtn;
	CFont		m_fntBtn2;
	CFont		m_fntStatic;
	CFont		m_fntEdit;

	// Generated message map functions
	//{{AFX_MSG(CPaneRecipeGenDrillMethod)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnButtonMeasuringThickness();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANERECIPEGENDRILLMETHOD_H__C28B1E8B_E58C_4D99_9D35_A37996563B80__INCLUDED_)

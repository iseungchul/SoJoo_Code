#if !defined(AFX_CDLGOPCLOSSINPUT_H__5B5B4EF4_2599_4868_88E2_C4F4883CD219__INCLUDED_)
#define AFX_CDLGOPCLOSSINPUT_H__5B5B4EF4_2599_4868_88E2_C4F4883CD219__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CDlgOpcLossInput.h : header file
//
#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "DlgLaserMeasurement.h"
/////////////////////////////////////////////////////////////////////////////
// CDlgOpcLossInput dialog

class CDlgOpcLossInput : public CDialog
{
// Construction
public:

	CDlgOpcLossInput(CWnd* pParent = NULL);   // standard constructor
	BOOL WaitOPCRecvMessage();
	void InitListControl();
	void InitBtnControl();
	void InitEditControl();
	BOOL SetListItemFromOPCLossINI();
	void MessageLoop();
	static 	int CALLBACK CompareFunc(LPARAM lParam1 , LPARAM lParam2 , LPARAM lParamSort);
	BOOL SaveOPCINI();


	BOOL m_bModifyLossList;

// Dialog Data
	//{{AFX_DATA(CDlgOpcLossInput)
	enum { IDD = IDD_DLG_OPC_LOSS };
	UEasyButtonEx	m_btnOK;
	UEasyButtonEx	m_btnCancle;
	UEasyButtonEx	m_btnOPCInput;
	UEasyButtonEx	m_btnOPCModify;

	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	CListCtrl m_listBoardParam;
	CDlgLaserMeasurement m_dlgOPCWait;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgOpcLossInput)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CFont		m_fntBtn;
	CFont		m_fntStatic;
	CFont		m_fntStaticBig;
	CFont		m_fntList;
	CFont		m_fntEdit;

	// Generated message map functions
	//{{AFX_MSG(CDlgOpcLossInput)
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkListOpcLoss(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickListOpcLoss(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBtnOpcInput();
	afx_msg void OnBtnOpcModify();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:

	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CDLGOPCLOSSINPUT_H__5B5B4EF4_2599_4868_88E2_C4F4883CD219__INCLUDED_)

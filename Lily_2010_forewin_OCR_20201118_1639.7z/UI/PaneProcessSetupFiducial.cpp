// PaneProcessSetupFiducial.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneProcessSetupFiducial.h"
#include "..\model\DProcessINI.h"
#include "..\model\deasydrillerini.h"
#include "..\model\DProject.h"
#include "..\EasyDrillerDlg.h"
#include "..\Model\DSystemINI.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupFiducial

IMPLEMENT_DYNCREATE(CPaneProcessSetupFiducial, CFormView)

CPaneProcessSetupFiducial::CPaneProcessSetupFiducial()
	: CFormView(CPaneProcessSetupFiducial::IDD)
{
	//{{AFX_DATA_INIT(CPaneProcessSetupFiducial)
	//}}AFX_DATA_INIT
//	memset( m_nFidFindMethod, 0, sizeof(m_nFidFindMethod) );
	m_nUserLevel = 0;
	for(int i = 0; i< 9; i++)
	{
		m_bHoleFindAreaPos[i] = FALSE;
		m_bHoleFindHolePos[i] = FALSE;
	}
}

CPaneProcessSetupFiducial::~CPaneProcessSetupFiducial()
{
}

void CPaneProcessSetupFiducial::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneProcessSetupFiducial)
	DDX_Control(pDX, IDC_EDIT_MOVE_LENGTH_Y_HIGH, m_edtMoveLenHighY);
	DDX_Control(pDX, IDC_EDIT_MOVE_LENGTH_X_HIGH, m_edtMoveLenHighX);
	DDX_Control(pDX, IDC_CHECK_AUTO_PROCESS_FIDUCIAL_RECHECK, m_chkAutoProcessFidRecheck);
	DDX_Control(pDX, IDC_EDIT_TOTAL_RETRIAL, m_edtTotalRetrial);
	DDX_Control(pDX, IDC_EDIT_FIDUCIAL_ANGLE_LIMIT, m_edtFidAngle);
	DDX_Control(pDX, IDC_EDIT_PCB_LENGTH_TOLERANCE, m_edtPCBLenTolerance);
	DDX_Control(pDX, IDC_EDIT_PCB_LENGTH_TOLERANCE2, m_edtPCBLenTolerance2);
	DDX_Control(pDX, IDC_EDIT_PCB_POS_TOLERANCE, m_edtRecheckTolerance);
	DDX_Control(pDX, IDC_EDIT_MOVE_LENGTH_Y, m_edtMoveLenY);
	DDX_Control(pDX, IDC_EDIT_MOVE_LENGTH_X, m_edtMoveLenX);
	DDX_Control(pDX, IDC_EDIT_MOVE_REF_X, m_edtRefPosX);
	DDX_Control(pDX, IDC_EDIT_MOVE_REF_Y, m_edtRefPosY);
	DDX_Control(pDX, IDC_EDIT_MOVE_NEAR_X, m_edtNearPosX);
	DDX_Control(pDX, IDC_EDIT_MOVE_NEAR_X2, m_edtNearPosX2);
	DDX_Control(pDX, IDC_EDIT_MOVE_NEAR_Y, m_edtNearPosY);
	DDX_Control(pDX, IDC_EDIT_MOVE_NEAR_Y2, m_edtNearPosY2);
	DDX_Control(pDX, IDC_CHECK_ALL_PARAM, m_chkAllFidParam);
	DDX_Control(pDX, IDC_EDIT_HOLE_FIND_PRE_LIMIT, m_edtPreLimit );
	DDX_Control(pDX, IDC_EDIT_HOLE_FIND_POST_LIMIT, m_edtPostLimit);
	DDX_Control(pDX, IDC_CHECK_USE_COMPENSATION, m_chkUseCompensation);
	DDX_Control(pDX, IDC_EDIT_PCB_OPER_RUN_LIMIT, m_edtOperRunLimit);
	DDX_Control(pDX, IDC_EDIT_PCB_SCALE_TOLERANCE, m_edtScaleMinusLimit);
	DDX_Control(pDX, IDC_EDIT_PCB_SCALE_TOLERANCE2, m_edtScalePlusLimit);
	DDX_Control(pDX, IDC_CHECK_USE_OPER_RUN, m_chkUseOperRun);
	DDX_Control(pDX, IDC_EDIT_SIZE, m_edtSize);
	DDX_Control(pDX, IDC_EDIT_ASPECTRATIO, m_edtRatio);
	DDX_Control(pDX, IDC_EDIT_ROTATION, m_edtRotation);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneProcessSetupFiducial, CFormView)
	//{{AFX_MSG_MAP(CPaneProcessSetupFiducial)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHECK_AUTO_PROCESS_FIDUCIAL_RECHECK, OnCheckAutoProcessFidRecheck)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_STATIC_ACCEPT_SCORE, &CPaneProcessSetupFiducial::OnBnClickedStaticAcceptScore)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupFiducial diagnostics

#ifdef _DEBUG
void CPaneProcessSetupFiducial::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneProcessSetupFiducial::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneProcessSetupFiducial message handlers

void CPaneProcessSetupFiducial::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitStaticControl();
	InitEditControl();
	InitComboControl();
	InitBtnControl();

	if(gEasyDrillerINI.m_clsHwOption.GetCameraNum() == 1)
	{
		UpdateData(FALSE);
		GetDlgItem(IDC_STATIC_HIGH)->SetWindowText("Vision");

		GetDlgItem(IDC_STATIC_LOW)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_LOW_X_MM)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_LOW_Y_MM)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_MOVE_LENGTH_X)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_MOVE_LENGTH_Y)->ShowWindow(SW_HIDE);
	}
}

BOOL CPaneProcessSetupFiducial::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);

	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;

	return TRUE;
}

void CPaneProcessSetupFiducial::InitStaticControl()
{
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// Move length when fiducial finding
	GetDlgItem(IDC_STATIC_MOVE_LENGTH)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LOW)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HIGH)->SetFont( &m_fntStatic );

	// The total of retrial
	GetDlgItem(IDC_STATIC_TOTAL_RETRIAL)->SetFont( &m_fntStatic );
	
	// fiducial angle
	GetDlgItem(IDC_STATIC_FIDUCIAL_ANGLE)->SetFont( &m_fntStatic );

	// Check Fiducial Tolerance
	GetDlgItem(IDC_STATIC_FIDUCIAL_TOLERANCE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PCB_POS_TOLERANCE)->SetFont( &m_fntStatic );

	// Check Scale Tolerance
	GetDlgItem(IDC_STATIC_FIDUCIAL_SCALE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PCB_SCALE_TOLERANCE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PCB_SCALE_TOLERANCE2)->SetFont( &m_fntStatic );
	
	// Recheck Fiducial
	GetDlgItem(IDC_STATIC_FIDUCIAL_RECHECK)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_NEAR_POS)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_PCB_LENGTH_TOLERANCE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_PCB_LENGTH_TOLERANCE2)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_RETRIAL_COUNT)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_PCB_OPER_RUN)->SetFont( &m_fntStatic );

	GetDlgItem(IDC_STATIC_FIDUCIAL_ANGLE_LIMIT)->SetFont( &m_fntStatic );
	
	// Fiducial ref pos setting
	GetDlgItem(IDC_STATIC_MOVE_REF_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_REF_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_REF)->SetFont( &m_fntStatic );

	// Fiducial near pos setting
	GetDlgItem(IDC_STATIC_MOVE_NEAR_X)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_NEAR_Y)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_NEAR_POS)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_NEAR_POS1)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_MOVE_NEAR_POS2)->SetFont( &m_fntStatic );

	//accept score
	GetDlgItem(IDC_STATIC_ACCEPT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ROTATION)->SetFont( &m_fntStatic );
	// hole find
	GetDlgItem(IDC_STATIC_HOLE_FIND_LIMIT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HOLE_FIND_PRE_LIMIT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_HOLE_FIND_POST_LIMIT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_ACCEPT_SCORE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SIZE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_RATIO)->SetFont( &m_fntStatic );
}

void CPaneProcessSetupFiducial::InitEditControl()
{
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");

	// Move length when fiducial finding
	m_edtMoveLenX.SetFont( &m_fntEdit );
	m_edtMoveLenX.SetForeColor( BLACK_COLOR );
	m_edtMoveLenX.SetBackColor( WHITE_COLOR );
	m_edtMoveLenX.SetReceivedFlag( 3 );
	m_edtMoveLenX.SetWindowText( _T("1.1") );

	m_edtMoveLenY.SetFont( &m_fntEdit );
	m_edtMoveLenY.SetForeColor( BLACK_COLOR );
	m_edtMoveLenY.SetBackColor( WHITE_COLOR );
	m_edtMoveLenY.SetReceivedFlag( 3 );
	m_edtMoveLenY.SetWindowText( _T("0.8") );

	m_edtMoveLenHighX.SetFont( &m_fntEdit );
	m_edtMoveLenHighX.SetForeColor( BLACK_COLOR );
	m_edtMoveLenHighX.SetBackColor( WHITE_COLOR );
	m_edtMoveLenHighX.SetReceivedFlag( 3 );
	m_edtMoveLenHighX.SetWindowText( _T("1.1") );

	m_edtMoveLenHighY.SetFont( &m_fntEdit );
	m_edtMoveLenHighY.SetForeColor( BLACK_COLOR );
	m_edtMoveLenHighY.SetBackColor( WHITE_COLOR );
	m_edtMoveLenHighY.SetReceivedFlag( 3 );
	m_edtMoveLenHighY.SetWindowText( _T("0.8") );

	// Fiducial Angle Limit
	m_edtFidAngle.SetFont( &m_fntEdit );
	m_edtFidAngle.SetForeColor( BLACK_COLOR );
	m_edtFidAngle.SetBackColor( WHITE_COLOR );
	m_edtFidAngle.SetReceivedFlag( 3 );
	m_edtFidAngle.SetWindowText( _T("0.5") );

	// Number fiducial finding
	m_edtTotalRetrial.SetFont( &m_fntEdit );
	m_edtTotalRetrial.SetForeColor( BLACK_COLOR );
	m_edtTotalRetrial.SetBackColor( WHITE_COLOR );
	m_edtTotalRetrial.SetReceivedFlag( 1 );
	m_edtTotalRetrial.SetWindowText( _T("25") );

	m_edtPCBLenTolerance.SetFont( &m_fntEdit );
	m_edtPCBLenTolerance.SetForeColor( BLACK_COLOR );
	m_edtPCBLenTolerance.SetBackColor( WHITE_COLOR );
	m_edtPCBLenTolerance.SetReceivedFlag( 3 );
	m_edtPCBLenTolerance.SetWindowText( _T("0.5") );

	m_edtPCBLenTolerance2.SetFont( &m_fntEdit );
	m_edtPCBLenTolerance2.SetForeColor( BLACK_COLOR );
	m_edtPCBLenTolerance2.SetBackColor( WHITE_COLOR );
	m_edtPCBLenTolerance2.SetReceivedFlag( 3 );
	m_edtPCBLenTolerance2.SetWindowText( _T("0.5") );

	m_edtRecheckTolerance.SetFont( &m_fntEdit );
	m_edtRecheckTolerance.SetForeColor( BLACK_COLOR );
	m_edtRecheckTolerance.SetBackColor( WHITE_COLOR );
	m_edtRecheckTolerance.SetReceivedFlag( 3 );
	m_edtRecheckTolerance.SetWindowText( _T("0.5") );

	m_edtOperRunLimit.SetFont( &m_fntEdit );
	m_edtOperRunLimit.SetForeColor( BLACK_COLOR );
	m_edtOperRunLimit.SetBackColor( WHITE_COLOR );
	m_edtOperRunLimit.SetReceivedFlag( 3 );
	m_edtOperRunLimit.SetWindowText( _T("0.1") );

	// Fiducial ref pos 
	m_edtRefPosX.SetFont( &m_fntEdit );
	m_edtRefPosX.SetForeColor( BLACK_COLOR );
	m_edtRefPosX.SetBackColor( WHITE_COLOR );
	m_edtRefPosX.SetReceivedFlag( 3 );
	m_edtRefPosX.SetWindowText( _T("600") );
	
	m_edtRefPosY.SetFont( &m_fntEdit );
	m_edtRefPosY.SetForeColor( BLACK_COLOR );
	m_edtRefPosY.SetBackColor( WHITE_COLOR );
	m_edtRefPosY.SetReceivedFlag( 3 );
	m_edtRefPosY.SetWindowText( _T("700") );

	//Fiducial Near Pos

	m_edtNearPosX.SetFont( &m_fntEdit );
	m_edtNearPosX.SetForeColor( BLACK_COLOR );
	m_edtNearPosX.SetBackColor( WHITE_COLOR );
	m_edtNearPosX.SetReceivedFlag( 3 );
	m_edtNearPosX.SetWindowText( _T("600") );

	m_edtNearPosX2.SetFont( &m_fntEdit );
	m_edtNearPosX2.SetForeColor( BLACK_COLOR );
	m_edtNearPosX2.SetBackColor( WHITE_COLOR );
	m_edtNearPosX2.SetReceivedFlag( 3 );
	m_edtNearPosX2.SetWindowText( _T("700") );

	m_edtNearPosY.SetFont( &m_fntEdit );
	m_edtNearPosY.SetForeColor( BLACK_COLOR );
	m_edtNearPosY.SetBackColor( WHITE_COLOR );
	m_edtNearPosY.SetReceivedFlag( 3 );
	m_edtNearPosY.SetWindowText( _T("600") );

	m_edtNearPosY2.SetFont( &m_fntEdit );
	m_edtNearPosY2.SetForeColor( BLACK_COLOR );
	m_edtNearPosY2.SetBackColor( WHITE_COLOR );
	m_edtNearPosY2.SetReceivedFlag( 3 );
	m_edtNearPosY2.SetWindowText( _T("700") );

	// hole find
	m_edtPreLimit.SetFont( &m_fntEdit );
	m_edtPreLimit.SetForeColor( BLACK_COLOR );
	m_edtPreLimit.SetBackColor( WHITE_COLOR );
	m_edtPreLimit.SetReceivedFlag( 1 );
	m_edtPreLimit.SetWindowText( _T("10") );
	
	m_edtPostLimit.SetFont( &m_fntEdit );
	m_edtPostLimit.SetForeColor( BLACK_COLOR );
	m_edtPostLimit.SetBackColor( WHITE_COLOR );
	m_edtPostLimit.SetReceivedFlag( 1 );
	m_edtPostLimit.SetWindowText( _T("10") );

	// Scale Limit
	m_edtScaleMinusLimit.SetFont( &m_fntEdit );
	m_edtScaleMinusLimit.SetForeColor( BLACK_COLOR );
	m_edtScaleMinusLimit.SetBackColor( WHITE_COLOR );
	m_edtScaleMinusLimit.SetReceivedFlag( 1 );
	m_edtScaleMinusLimit.SetWindowText( _T("99") );
	
	m_edtScalePlusLimit.SetFont( &m_fntEdit );
	m_edtScalePlusLimit.SetForeColor( BLACK_COLOR );
	m_edtScalePlusLimit.SetBackColor( WHITE_COLOR );
	m_edtScalePlusLimit.SetReceivedFlag( 1 );
	m_edtScalePlusLimit.SetWindowText( _T("101") );

	//accept size
	m_edtSize.SetFont( &m_fntEdit );
	m_edtSize.SetForeColor( BLACK_COLOR );
	m_edtSize.SetBackColor( WHITE_COLOR );
	m_edtSize.SetReceivedFlag( 3 );
	m_edtSize.SetWindowText( _T("20") );

	m_edtRatio.SetFont( &m_fntEdit );
	m_edtRatio.SetForeColor( BLACK_COLOR );
	m_edtRatio.SetBackColor( WHITE_COLOR );
	m_edtRatio.SetReceivedFlag( 3 );
	m_edtRatio.SetWindowText( _T("20") );

	m_edtRotation.SetFont( &m_fntEdit );
	m_edtRotation.SetForeColor( BLACK_COLOR );
	m_edtRotation.SetBackColor( WHITE_COLOR );
	m_edtRotation.SetReceivedFlag( 1 );
	m_edtRotation.SetWindowText( _T("127") );
}

void CPaneProcessSetupFiducial::InitComboControl()
{
	// Set Combo Font
	m_fntCombo.CreatePointFont(130, "Arial Bold");

}

void CPaneProcessSetupFiducial::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	m_chkAutoProcessFidRecheck.SetFont( &m_fntBtn );
	m_chkAutoProcessFidRecheck.SetImageOrg( 10, 3 );
	m_chkAutoProcessFidRecheck.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkAutoProcessFidRecheck.EnableBallonToolTip();
	m_chkAutoProcessFidRecheck.SetToolTipText( _T("During auto processing, Recheck fiducial") );
	m_chkAutoProcessFidRecheck.SetBtnCursor(IDC_HAND_1);

	m_chkAllFidParam.SetFont( &m_fntBtn );
	m_chkAllFidParam.SetImageOrg( 10, 3 );
	m_chkAllFidParam.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkAllFidParam.EnableBallonToolTip();
	m_chkAllFidParam.SetToolTipText( _T("Use All Fiducial Setting Control") );
	m_chkAllFidParam.SetBtnCursor(IDC_HAND_1);

	m_chkUseCompensation.SetFont( &m_fntBtn );
	m_chkUseCompensation.SetImageOrg( 10, 3 );
	m_chkUseCompensation.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseCompensation.EnableBallonToolTip();
	m_chkUseCompensation.SetToolTipText( _T("Use Compensation Mode") );
	m_chkUseCompensation.SetBtnCursor(IDC_HAND_1);

	m_chkUseOperRun.SetFont( &m_fntBtn );
	m_chkUseOperRun.SetImageOrg( 10, 3 );
	m_chkUseOperRun.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkUseOperRun.EnableBallonToolTip();
	m_chkUseOperRun.SetToolTipText( _T("User can select (run or stop) when Fiducial scale limit is over") );
	m_chkUseOperRun.SetBtnCursor(IDC_HAND_1);
}

HBRUSH CPaneProcessSetupFiducial::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if( GetDlgItem(IDC_STATIC_MOVE_LENGTH)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_TOTAL_RETRIAL)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_FIDUCIAL_ANGLE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_FIDUCIAL_TOLERANCE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_FIDUCIAL_SCALE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_FIDUCIAL_RECHECK)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MOVE_REF)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_ACCEPT)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_MOVE_NEAR_POS)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_ACCEPT_SCORE)->GetSafeHwnd() == pWnd->m_hWnd ||
		GetDlgItem(IDC_STATIC_HOLE_FIND_LIMIT)->GetSafeHwnd() == pWnd->m_hWnd )
		pDC->SetTextColor( RGB(0, 0, 255) );
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CPaneProcessSetupFiducial::OnDestroy() 
{
	m_fntBtn.DeleteObject();
	m_fntCombo.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();

	CFormView::OnDestroy();
}

void CPaneProcessSetupFiducial::DispProcessFidFind()
{
	CString strData;

	// Total Retrial
	strData.Format(_T("%d"), m_sProcessFidFind.nFidTotalRetrial);
	m_edtTotalRetrial.SetWindowText( (LPCTSTR)strData );

	// Fiducial Angle Limit
	strData.Format(_T("%.1f"), m_sProcessFidFind.dFidAngleLimit);
	m_edtFidAngle.SetWindowText( (LPCTSTR)strData );

	// PCB Length Tolerance
	strData.Format(_T("%.3f"), m_sProcessFidFind.dPCBLenTolerance);
	m_edtPCBLenTolerance.SetWindowText( (LPCTSTR)strData );

	// PCB Length Tolerance
	strData.Format(_T("%.3f"), m_sProcessFidFind.dPCBLenTolerance2);
	m_edtPCBLenTolerance2.SetWindowText( (LPCTSTR)strData );

	// user run/stop limit
	strData.Format(_T("%.3f"), m_sProcessFidFind.dPCBLenTolOperatorRunLimit);
	m_edtOperRunLimit.SetWindowText( (LPCTSTR)strData );

	// Recheck Fiducial
	m_chkAutoProcessFidRecheck.SetCheck( m_sProcessFidFind.bAutoFidRecheck );

	// Recheck Tolerance
	strData.Format(_T("%.3f"), m_sProcessFidFind.dRecheckTolerance);
	m_edtRecheckTolerance.SetWindowText( (LPCTSTR)strData );

	// Move length when fiducial finding
	strData.Format(_T("%.3f"), m_sProcessFidFind.dMoveLowVision.x);
	m_edtMoveLenX.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.3f"), m_sProcessFidFind.dMoveLowVision.y);
	m_edtMoveLenY.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessFidFind.dMoveHighVision.x);
	m_edtMoveLenHighX.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessFidFind.dMoveHighVision.y);
	m_edtMoveLenHighY.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessFidFind.dRefPosX );
	m_edtRefPosX.SetWindowText( (LPCTSTR)strData );
	
	strData.Format(_T("%.3f"), m_sProcessFidFind.dRefPosY );
	m_edtRefPosY.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessFidFind.dNearPosX );
	m_edtNearPosX.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessFidFind.dNearPosY );
	m_edtNearPosY.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessFidFind.dNearPosX2 );
	m_edtNearPosX2.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessFidFind.dNearPosY2 );
	m_edtNearPosY2.SetWindowText( (LPCTSTR)strData );

	m_chkAllFidParam.SetCheck(m_sProcessFidFind.bUseAllControl );

	strData.Format(_T("%d"), m_sProcessFidFind.nHolePostLimit);
	m_edtPostLimit.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%d"), m_sProcessFidFind.nHolePreLimit);
	m_edtPreLimit.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessFidFind.dScaleMinusLimit);
	m_edtScaleMinusLimit.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.3f"), m_sProcessFidFind.dScalePlusLimit);
	m_edtScalePlusLimit.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sProcessFidFind.dAcceptScore);
	m_edtSize.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sProcessFidFind.dAcceptEdgeScore);
	m_edtRatio.SetWindowText( (LPCTSTR)strData );

	strData.Format(_T("%.2f"), m_sProcessFidFind.dRotateHoleAcceptScore);
	m_edtRotation.SetWindowText( (LPCTSTR)strData );

	int nID;
	for(int i = 0; i< 9; i++)
	{
		
		m_bHoleFindAreaPos[i] = m_sProcessFidFind.bHoleFindAreaPos[i];
		nID = IDC_CHECK_AREA_0 + i;
		((CButton*)GetDlgItem( nID ))->SetCheck( m_bHoleFindAreaPos[i] );

		m_bHoleFindHolePos[i] = m_sProcessFidFind.bHoleFindHolePos[i];
		nID = IDC_CHECK_HOLE_0 + i;
		((CButton*)GetDlgItem( nID ))->SetCheck( m_bHoleFindHolePos[i] );
	}
	m_chkUseCompensation.SetCheck(m_sProcessFidFind.bUseProportionCompensation);

	m_chkUseOperRun.SetCheck(m_sProcessFidFind.bOperatorCanRunForScaleOver);
	OnCheckAutoProcessFidRecheck();
	UpdateData(FALSE);
}

void CPaneProcessSetupFiducial::SetProcessFidFind(SPROCESSFIDFIND sProcessFidFind)
{
	memcpy( &m_sProcessFidFind, &sProcessFidFind, sizeof(m_sProcessFidFind) );
//	memcpy( m_nFidFindMethod, m_sProcessFidFind.nFidFindMethod, sizeof(m_nFidFindMethod) );

	DispProcessFidFind();
}

void CPaneProcessSetupFiducial::GetProcessFidFind(SPROCESSFIDFIND* pProcessFidFind)
{
	memcpy( pProcessFidFind, &m_sProcessFidFind, sizeof(m_sProcessFidFind) );
}

BOOL CPaneProcessSetupFiducial::OnApply()
{
	UpdateData(TRUE);

	CString strData;

	// Fiducial Find Setting
//	memcpy( m_sProcessFidFind.nFidFindMethod, m_nFidFindMethod, sizeof(m_nFidFindMethod) );

	// Total Retrial
	m_edtTotalRetrial.GetWindowText( strData );
	m_sProcessFidFind.nFidTotalRetrial = atoi( (LPSTR)(LPCTSTR)strData );

	// Fiducial Angle Limit
	m_edtFidAngle.GetWindowText( strData );
	m_sProcessFidFind.dFidAngleLimit = atof( (LPSTR)(LPCTSTR)strData );

	// PCB Length Tolerance
	m_edtPCBLenTolerance.GetWindowText( strData );
	m_sProcessFidFind.dPCBLenTolerance = atof( (LPSTR)(LPCTSTR)strData );

	// PCB Length Tolerance2
	m_edtPCBLenTolerance2.GetWindowText( strData );
	m_sProcessFidFind.dPCBLenTolerance2 = atof( (LPSTR)(LPCTSTR)strData );

	// user run/stop limit
	m_edtOperRunLimit.GetWindowText( strData );
	m_sProcessFidFind.dPCBLenTolOperatorRunLimit = atof( (LPSTR)(LPCTSTR)strData );

	// Recheck Fiducial
	m_sProcessFidFind.bAutoFidRecheck = m_chkAutoProcessFidRecheck.GetCheck();

	// Recheck Tolerance
	m_edtRecheckTolerance.GetWindowText( strData );
	m_sProcessFidFind.dRecheckTolerance = atof( (LPSTR)(LPCTSTR)strData );

	// Move length when fiducial finding
	m_edtMoveLenX.GetWindowText( strData );
	m_sProcessFidFind.dMoveLowVision.x = atof( (LPSTR)(LPCTSTR)strData );
		
	m_edtMoveLenY.GetWindowText( strData );
	m_sProcessFidFind.dMoveLowVision.y = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMoveLenHighX.GetWindowText( strData );
	m_sProcessFidFind.dMoveHighVision.x = atof( (LPSTR)(LPCTSTR)strData );

	m_edtMoveLenHighY.GetWindowText( strData );
	m_sProcessFidFind.dMoveHighVision.y = atof( (LPSTR)(LPCTSTR)strData );

	m_edtRefPosX.GetWindowText( strData );
	m_sProcessFidFind.dRefPosX = atof( (LPSTR)(LPCTSTR)strData );
	
	m_edtRefPosY.GetWindowText( strData );
	m_sProcessFidFind.dRefPosY = atof( (LPSTR)(LPCTSTR)strData );

	m_edtNearPosX.GetWindowText( strData );
	m_sProcessFidFind.dNearPosX = atof( (LPSTR)(LPCTSTR)strData );

	m_edtNearPosY.GetWindowText( strData );
	m_sProcessFidFind.dNearPosY = atof( (LPSTR)(LPCTSTR)strData );

	m_edtNearPosX2.GetWindowText( strData );
	m_sProcessFidFind.dNearPosX2 = atof( (LPSTR)(LPCTSTR)strData );

	m_edtNearPosY2.GetWindowText( strData );
	m_sProcessFidFind.dNearPosY2 = atof( (LPSTR)(LPCTSTR)strData );

	m_edtPreLimit.GetWindowText( strData );
	m_sProcessFidFind.nHolePreLimit = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtPostLimit.GetWindowText( strData );
	m_sProcessFidFind.nHolePostLimit = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtScaleMinusLimit.GetWindowText( strData );
	m_sProcessFidFind.dScaleMinusLimit = atoi( (LPSTR)(LPCTSTR)strData );

	m_edtScalePlusLimit.GetWindowText( strData );
	m_sProcessFidFind.dScalePlusLimit = atoi( (LPSTR)(LPCTSTR)strData );


	m_edtSize.GetWindowText( strData );
	if(atof(strData) < 0.7)
	{
		CString strM;
		strM.Format(_T(" 0.7 <= Defualt Score <= 1.0"));
		ErrMessage(strM);
		return FALSE;
	}
	m_sProcessFidFind.dAcceptScore = atof( (LPSTR)(LPCTSTR)strData );

	m_edtRatio.GetWindowText( strData );
	m_sProcessFidFind.dAcceptEdgeScore = atof( (LPSTR)(LPCTSTR)strData );

	m_edtRotation.GetWindowText( strData );
	m_sProcessFidFind.dRotateHoleAcceptScore = atof( (LPSTR)(LPCTSTR)strData );

	m_sProcessFidFind.bUseProportionCompensation = m_chkUseCompensation.GetCheck();

	m_sProcessFidFind.bOperatorCanRunForScaleOver = m_chkUseOperRun.GetCheck();

	m_sProcessFidFind.bUseAllControl = m_chkAllFidParam.GetCheck();

	int nID;
	for(int i = 0; i< 9; i++)
	{
		nID = IDC_CHECK_AREA_0 + i;
		m_bHoleFindAreaPos[i] = ((CButton*)GetDlgItem( nID ))->GetCheck();
		m_sProcessFidFind.bHoleFindAreaPos[i] = m_bHoleFindAreaPos[i];
				
		nID = IDC_CHECK_HOLE_0 + i;
		m_bHoleFindHolePos[i] = ((CButton*)GetDlgItem( nID ))->GetCheck();
		m_sProcessFidFind.bHoleFindHolePos[i] = m_bHoleFindHolePos[i];
	}
	return TRUE;
}
void CPaneProcessSetupFiducial::OnCheckAutoProcessFidRecheck()
{
	BOOL bCheck = m_chkAutoProcessFidRecheck.GetCheck();
	if(bCheck)
		m_edtRecheckTolerance.EnableWindow(TRUE);
	else
		m_edtRecheckTolerance.EnableWindow(FALSE);
}

CString CPaneProcessSetupFiducial::GetChangeValueStr()
{
	CString strMessage, strTemp;
	strMessage.Format(_T(""));
	/*
	if(m_sProcessFidFind.nFidFindMethod[0] != gProcessINI.m_sProcessFidFind.nFidFindMethod[0])
	{
		if(m_sProcessFidFind.nFidFindMethod[0] == LOW_CAM_FIND_FID)
			strTemp.Format(_T("| Standard Fid : Low Cam use "));
		else if(m_sProcessFidFind.nFidFindMethod[0] == HIGH_CAM_FIND_FID)
			strTemp.Format(_T("| Standard Fid : High Cam use "));
		else if(m_sProcessFidFind.nFidFindMethod[0] == LOW_TO_HIGH_FIND_FID)
			strTemp.Format(_T("| Standard Fid : Low to High Cam use "));
		else
			strTemp.Format(_T("| Standard Fid : Use Cam by Project "));
		strMessage += strTemp;
	}

	if(m_sProcessFidFind.nFidFindMethod[1] != gProcessINI.m_sProcessFidFind.nFidFindMethod[1])
	{
		if(m_sProcessFidFind.nFidFindMethod[1] == LOW_CAM_FIND_FID)
			strTemp.Format(_T("| Skiving Fid : Low Cam use "));
		else if(m_sProcessFidFind.nFidFindMethod[1] == HIGH_CAM_FIND_FID)
			strTemp.Format(_T("| Skiving Fid : High Cam use "));
		else if(m_sProcessFidFind.nFidFindMethod[1] == LOW_TO_HIGH_FIND_FID)
			strTemp.Format(_T("| Skiving Fid : Low to High Cam use "));
		else
			strTemp.Format(_T("| Skiving Fid : Use Cam by Project "));
		strMessage += strTemp;
	}
	*/
	
	if(m_sProcessFidFind.nFidTotalRetrial != gProcessINI.m_sProcessFidFind.nFidTotalRetrial)
	{
		strTemp.Format(_T("| No. of retry : %d "), m_sProcessFidFind.nFidTotalRetrial);
		strMessage += strTemp;
	}
	
	if(m_sProcessFidFind.bUseProportionCompensation != gProcessINI.m_sProcessFidFind.bUseProportionCompensation )
	{
		strTemp.Format(_T("| Use Proportion Compensation : %d "), 
			m_sProcessFidFind.bUseProportionCompensation);
		strMessage += strTemp;
	}

	if(m_sProcessFidFind.dPCBLenTolerance != gProcessINI.m_sProcessFidFind.dPCBLenTolerance)
	{
		strTemp.Format(_T("| Tolerance : %.3f "), m_sProcessFidFind.dPCBLenTolerance);
		strMessage += strTemp;
	}
	if(m_sProcessFidFind.dPCBLenTolerance2 != gProcessINI.m_sProcessFidFind.dPCBLenTolerance2)
	{
		strTemp.Format(_T("| Tolerance2 : %.3f "), m_sProcessFidFind.dPCBLenTolerance2);
		strMessage += strTemp;
	}
	if(m_sProcessFidFind.dMoveLowVision.x != gProcessINI.m_sProcessFidFind.dMoveLowVision.x ||
		m_sProcessFidFind.dMoveLowVision.y != gProcessINI.m_sProcessFidFind.dMoveLowVision.y)
	{
		strTemp.Format(_T("| Low Cam. move step : ( %.3f, %.3f)mm "), 
						m_sProcessFidFind.dMoveLowVision.x,
						m_sProcessFidFind.dMoveLowVision.y);
		strMessage += strTemp;
	}

	if(m_sProcessFidFind.dMoveHighVision.x != gProcessINI.m_sProcessFidFind.dMoveHighVision.x ||
		m_sProcessFidFind.dMoveHighVision.y != gProcessINI.m_sProcessFidFind.dMoveHighVision.y)
	{
		strTemp.Format(_T("| High Cam. move step : ( %.3f, %.3f)mm "), 
			m_sProcessFidFind.dMoveHighVision.x,
			m_sProcessFidFind.dMoveHighVision.y);
		strMessage += strTemp;
	}

	if(m_sProcessFidFind.dRefPosX != gProcessINI.m_sProcessFidFind.dRefPosX ||
		m_sProcessFidFind.dRefPosY != gProcessINI.m_sProcessFidFind.dRefPosY)
	{
		strTemp.Format(_T("| Ref. Fid Pos : ( %.3f, %.3f)mm "), 
			m_sProcessFidFind.dRefPosX,
			m_sProcessFidFind.dRefPosY);
		strMessage += strTemp;
	}

	if(m_sProcessFidFind.nAcceptSize != gProcessINI.m_sProcessFidFind.nAcceptSize )
	{
		strTemp.Format(_T("| Accept Size : %d "), 
			m_sProcessFidFind.nAcceptSize);
		strMessage += strTemp;
	}
	if(m_sProcessFidFind.nAcceptRatio != gProcessINI.m_sProcessFidFind.nAcceptRatio )
	{
		strTemp.Format(_T("| Accept Ratio : %d "), 
			m_sProcessFidFind.nAcceptRatio);
		strMessage += strTemp;
	}
	if(m_sProcessFidFind.bUseAllControl != gProcessINI.m_sProcessFidFind.bUseAllControl )
	{
		strTemp.Format(_T("| Use All Fid Control : %d "), 
			m_sProcessFidFind.bUseAllControl);
		strMessage += strTemp;
	}

	if(m_sProcessFidFind.nHolePreLimit != gProcessINI.m_sProcessFidFind.nHolePreLimit )
	{
		strTemp.Format(_T("| Hole Pre Limit : %d "), 
			m_sProcessFidFind.nHolePreLimit);
		strMessage += strTemp;
	}
	if(m_sProcessFidFind.nHolePostLimit != gProcessINI.m_sProcessFidFind.nHolePostLimit )
	{
		strTemp.Format(_T("| Hole Post Limit : %d "), 
			m_sProcessFidFind.nHolePostLimit);
		strMessage += strTemp;
	}

	if(m_sProcessFidFind.dScaleMinusLimit != gProcessINI.m_sProcessFidFind.dScaleMinusLimit )
	{
		strTemp.Format(_T("| Scale Minus Limit : %d "), 
			m_sProcessFidFind.dScaleMinusLimit);
		strMessage += strTemp;
	}
	if(m_sProcessFidFind.dScalePlusLimit != gProcessINI.m_sProcessFidFind.dScalePlusLimit )
	{
		strTemp.Format(_T("| Scale Plus Limit : %d "), 
			m_sProcessFidFind.dScalePlusLimit);
		strMessage += strTemp;
	}

	if(m_sProcessFidFind.dPCBLenTolOperatorRunLimit != gProcessINI.m_sProcessFidFind.dPCBLenTolOperatorRunLimit)
	{
		strTemp.Format(_T("| Operator Run Limit : %.3f "), m_sProcessFidFind.dPCBLenTolOperatorRunLimit);
		strMessage += strTemp;
	}

	if(m_sProcessFidFind.bOperatorCanRunForScaleOver != gProcessINI.m_sProcessFidFind.bOperatorCanRunForScaleOver )
	{
		strTemp.Format(_T("| Operator Can Run For Scale Over : %d "), 
			m_sProcessFidFind.bOperatorCanRunForScaleOver);
		strMessage += strTemp;
	}

	if(m_sProcessFidFind.dAcceptScore != gProcessINI.m_sProcessFidFind.dAcceptScore )
	{
		strTemp.Format(_T("| Accept Score : %.2f "), 
			m_sProcessFidFind.dAcceptScore);
		strMessage += strTemp;
	}

	if(m_sProcessFidFind.dAcceptEdgeScore != gProcessINI.m_sProcessFidFind.dAcceptEdgeScore )
	{
		strTemp.Format(_T("| Edge Score : %.2f "), 
			m_sProcessFidFind.dAcceptEdgeScore);
		strMessage += strTemp;
	}
	if(m_sProcessFidFind.dRotateHoleAcceptScore != gProcessINI.m_sProcessFidFind.dRotateHoleAcceptScore )
	{
		strTemp.Format(_T("| Rotation Score : %.2f "), 
			m_sProcessFidFind.dRotateHoleAcceptScore);
		strMessage += strTemp;
	}

	return strMessage;
}

void CPaneProcessSetupFiducial::EnableControl(BOOL bUse)
{
	
	if(gEasyDrillerINI.m_clsHwOption.GetCameraNum() > 1)
	{
		m_edtMoveLenHighX.EnableWindow(bUse);
		m_edtMoveLenHighY.EnableWindow(bUse);
	}
	
	m_edtMoveLenX.EnableWindow(bUse);
	m_edtMoveLenY.EnableWindow(bUse);
	m_edtTotalRetrial.EnableWindow(bUse);
	m_edtPCBLenTolerance.EnableWindow(bUse);
	m_edtPCBLenTolerance2.EnableWindow(bUse);
	m_chkUseCompensation.EnableWindow(bUse);
	m_chkAutoProcessFidRecheck.EnableWindow(bUse);
	m_edtFidAngle.EnableWindow(bUse);
	m_edtRefPosX.EnableWindow(bUse);
	m_edtRefPosY.EnableWindow(bUse);
	m_chkAllFidParam.EnableWindow(bUse);
	m_edtPreLimit.EnableWindow(bUse);	
	m_edtPostLimit.EnableWindow(bUse);
	m_edtScaleMinusLimit.EnableWindow(bUse);
	m_edtScalePlusLimit.EnableWindow(bUse);
	m_edtNearPosX.EnableWindow(bUse);
	m_edtNearPosY.EnableWindow(bUse);
	m_edtNearPosX2.EnableWindow(bUse);
	m_edtNearPosY2.EnableWindow(bUse);

	m_edtOperRunLimit.EnableWindow(bUse);
	m_chkUseOperRun.EnableWindow(bUse);
	if(m_nUserLevel > 0)
	{
		m_edtSize.EnableWindow(bUse);
		m_edtRatio.EnableWindow(bUse);
		m_edtRotation.EnableWindow(bUse);
	}
	else
	{
		m_edtSize.EnableWindow(FALSE);
		m_edtRatio.EnableWindow(FALSE);
		m_edtRotation.EnableWindow(FALSE);
		int nID;
		for(int i = 0; i< 9; i++)
		{
		
			nID = IDC_CHECK_AREA_0 + i;
			((CButton*)GetDlgItem( nID ))->EnableWindow(FALSE);
			nID = IDC_CHECK_HOLE_0 + i;
			((CButton*)GetDlgItem( nID ))->EnableWindow(FALSE);
		}
	}
}

void CPaneProcessSetupFiducial::SetAuthorityByLevel(int nLevel)
{
	m_nUserLevel = nLevel;
	switch(nLevel)
	{
	case 0:
		EnableControl(FALSE);
		break;
	case 1:
	case 2:
	case 3:
		EnableControl(TRUE);
		break;
	}
}

BOOL CPaneProcessSetupFiducial::SetAcceptScore()
{
	if(m_sProcessFidFind.nAcceptRatio < 0 || m_sProcessFidFind.nAcceptRatio > 100)
	{	
		ErrMessage(_T("0 <= Accept Ratio <= 100"));
		return FALSE;
	}
	if(m_sProcessFidFind.nAcceptSize < 0 || m_sProcessFidFind.nAcceptSize > 100)
	{
		ErrMessage(_T("0 <= Accept Size <= 100"));
		return FALSE;
	}

	int nCount = gDProject.m_Glyphs.GetFidCount(DEFAULT_FID_INDEX);
	for(int i =0; i< nCount; i++)
	{
		LPFIDDATA pFidData = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);

		pFidData->sVisInfo.dScoreSize = m_sProcessFidFind.nAcceptSize;
		pFidData->sVisInfo.dAspectRatio = m_sProcessFidFind.nAcceptRatio;
	}

	return TRUE;
}


BOOL CPaneProcessSetupFiducial::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{	
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CFormView::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CFormView::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Process_Fiducial) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
		
	}
	return CFormView::PreTranslateMessage(pMsg);
}


void CPaneProcessSetupFiducial::OnBnClickedStaticAcceptScore()
{
	// TODO: Add your control notification handler code here
}

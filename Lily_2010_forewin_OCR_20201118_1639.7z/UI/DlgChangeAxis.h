#if !defined(AFX_DLGCHANGEAXIS_H__BEFDFC78_3F38_46DE_A073_94A08C5F63F1__INCLUDED_)
#define AFX_DLGCHANGEAXIS_H__BEFDFC78_3F38_46DE_A073_94A08C5F63F1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgChangeAxis.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgChangeAxis dialog

class CDlgChangeAxis : public CDialog
{
// Construction
public:
	int m_nAxis;
	CDlgChangeAxis(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgChangeAxis)
	enum { IDD = IDD_CHANGE_AXIS };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgChangeAxis)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgChangeAxis)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnAxis0();
	afx_msg void OnBtnAxis90();
	afx_msg void OnBtnAxis180();
	afx_msg void OnBtnAxis270();
	afx_msg void OnBtnAxisLeft0();
	afx_msg void OnBtnAxisLeft90();
	afx_msg void OnBtnAxisLeft180();
	afx_msg void OnBtnAxisLeft270();
	afx_msg void OnBtnCurrentAxis();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void setButtonFont();
	CFont m_fontBtn;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCHANGEAXIS_H__BEFDFC78_3F38_46DE_A073_94A08C5F63F1__INCLUDED_)

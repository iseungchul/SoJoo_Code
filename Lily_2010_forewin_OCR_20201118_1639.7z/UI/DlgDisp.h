#if !defined(AFX_DLGDISP_H__EAD7A1D8_C2AB_4E01_B6F1_A814B065112C__INCLUDED_)
#define AFX_DLGDISP_H__EAD7A1D8_C2AB_4E01_B6F1_A814B065112C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgDisp.h : header file
//

#include "ColorStatic.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgDisp dialog

class CDlgDisp : public CDialog
{
// Construction
public:
	CDlgDisp(CWnd* pParent = NULL);   // standard constructor

	// Member Function List
	void	Init_Control();
	void	ShowDlg(BOOL bFlag, CString strMsg);
	void	DispMsg(BOOL bFlag);
	CString GetDispMsg();
	void	SetDispMsg(CString strMsg);

// Dialog Data
	//{{AFX_DATA(CDlgDisp)
	enum { IDD = IDD_DLG_DISP };
	CColorStatic	m_stcDisp;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgDisp)
	public:
	virtual BOOL Create(CWnd* pParentWnd);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	UINT	m_nTimerID;
	BOOL	m_bFlag;
	CFont	m_fntStatic;
	// Generated message map functions
	//{{AFX_MSG(CDlgDisp)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg LRESULT OnNcHitTest(CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGDISP_H__EAD7A1D8_C2AB_4E01_B6F1_A814B065112C__INCLUDED_)

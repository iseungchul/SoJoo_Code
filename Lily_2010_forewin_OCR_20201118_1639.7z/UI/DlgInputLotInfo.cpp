// DlgInputLotInfo.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "DlgInputLotInfo.h"
#include "..\EasyDrillerDlg.h"
#include "..\Model\DSystemINI.h"
#include "..\Model\DBeampathINI.h"
#include "PaneManualControl.h"
#include "PaneManualControlScannerCalibration.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInputLotInfo dialog


CDlgInputLotInfo::CDlgInputLotInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgInputLotInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgInputLotInfo)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nInputLot		= 0;
	m_nStartNo		= 0;
}


void CDlgInputLotInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInputLotInfo)
	DDX_Control(pDX, IDOK, m_btnOk);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_EDIT_INPUT_LOT, m_edtInputLot);
	DDX_Control(pDX, IDC_CHECK_DNC, m_chkData);
	DDX_Control(pDX, IDC_CHECK_SELECT, m_chkSelect);
	DDX_Control(pDX, IDC_CHECK_BEAMPATH_NO, m_chkBeampath);
	DDX_Control(pDX, IDC_CHECK_FIELD, m_chkField);
	DDX_Control(pDX, IDC_CHECK_LOT_COUNT, m_chkLotCount);
	DDX_Control(pDX, IDC_EDIT_INPUT_START_NO, m_edtStartNo);
	DDX_Control(pDX, IDC_LIST_BOARD_PARAM, m_listBoardParam);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInputLotInfo, CDialog)
	//{{AFX_MSG_MAP(CDlgInputLotInfo)
	ON_BN_CLICKED(IDC_CHECK_DNC, OnCheckData)
	ON_BN_CLICKED(IDC_CHECK_SELECT, OnCheckSelect)
	ON_BN_CLICKED(IDC_CHECK_BEAMPATH_NO, OnCheckBeampath)
	ON_BN_CLICKED(IDC_CHECK_FIELD, OnCheckField)
	ON_BN_CLICKED(IDC_CHECK_LOT_COUNT, OnCheckLotCount)

	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInputLotInfo message handlers

BOOL CDlgInputLotInfo::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitControl();
	SetData();
	InitListControl();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgInputLotInfo::InitControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(130, "Arial Bold");
	// Set Edit Font
	m_fntEdit.CreatePointFont(150, "Arial Bold");
	// Set Static Font
	m_fntStatic.CreatePointFont(130, "Arial Bold");

	// Cancel
	m_btnCancel.SetFont( &m_fntBtn );
	m_btnCancel.SetFlat( FALSE );
	m_btnCancel.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnCancel.EnableBallonToolTip();
	m_btnCancel.SetToolTipText( _T("Cancel") );
	m_btnCancel.SetBtnCursor(IDC_HAND_1);

	// Ok
	m_btnOk.SetFont( &m_fntBtn );
	m_btnOk.SetFlat( FALSE );
	m_btnOk.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_btnOk.EnableBallonToolTip();
	m_btnOk.SetToolTipText( _T("Ok") );
	m_btnOk.SetBtnCursor(IDC_HAND_1);
	m_btnOk.EnableWindow(FALSE);

//	GetDlgItem(IDC_STATIC_MSG)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AMOUNT_LOT)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_START_NUM)->SetFont( &m_fntStatic );
	m_listBoardParam.SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DNC)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_EDIT_DNC)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SELECT_FIRE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_EDIT_SELECT_FIRE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_FIELD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_EDIT_FIELD)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DIVIDE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCALE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LENGTH)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AUTOCAL)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_DIVIDE_VALUE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_SCALE_VALUE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_LENGTH_VALUE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_AUTOCAL_VALUE)->SetFont( &m_fntStatic );
	GetDlgItem(IDC_STATIC_POWER_VALUE)->SetFont( &m_fntStatic );

	m_chkData.SetFont( &m_fntBtn );
	m_chkData.SetImageOrg( 10, 3 );
	m_chkData.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkData.EnableBallonToolTip();
	m_chkData.SetToolTipText( _T("Apply the Parameter") );
	m_chkData.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_chkData.SetBtnCursor(IDC_HAND_1);

	m_chkBeampath.SetFont( &m_fntBtn );
	m_chkBeampath.SetImageOrg( 10, 3 );
	m_chkBeampath.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkBeampath.EnableBallonToolTip();
	m_chkBeampath.SetToolTipText( _T("Apply the Parameter") );
	m_chkBeampath.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_chkBeampath.SetBtnCursor(IDC_HAND_1);

	m_chkLotCount.SetFont( &m_fntBtn );
	m_chkLotCount.SetImageOrg( 10, 3 );
	m_chkLotCount.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkLotCount.EnableBallonToolTip();
	m_chkLotCount.SetToolTipText( _T("Apply the Parameter") );
	m_chkLotCount.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_chkLotCount.SetBtnCursor(IDC_HAND_1);

	m_chkSelect.SetFont( &m_fntBtn );
	m_chkSelect.SetImageOrg( 10, 3 );
	m_chkSelect.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkSelect.EnableBallonToolTip();
	m_chkSelect.SetToolTipText( _T("Apply the Parameter") );
	m_chkSelect.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_chkSelect.SetBtnCursor(IDC_HAND_1);

	m_chkField.SetFont( &m_fntBtn );
	m_chkField.SetImageOrg( 10, 3 );
	m_chkField.SetIcon( IDI_LEDON, IDI_LEDOFF );
	m_chkField.EnableBallonToolTip();
	m_chkField.SetToolTipText( _T("Apply the Parameter") );
	m_chkField.SetColor( UEasyButtonEx::COLOR_FG_IN, RGB(0, 128, 0) );
	m_chkField.SetBtnCursor(IDC_HAND_1);

	if(m_bAutoRun)
	{
		m_chkData.ShowWindow(SW_SHOW);
		m_chkBeampath.ShowWindow(SW_SHOW);
		m_chkLotCount.ShowWindow(SW_SHOW);
		m_chkSelect.ShowWindow(SW_HIDE);
		m_chkField.ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_DNC)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_DNC)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_SELECT_FIRE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SELECT_FIRE)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_FIELD)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_FIELD)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_AMOUNT_LOT)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_START_NUM)->ShowWindow(SW_SHOW);
		m_edtInputLot.ShowWindow(SW_SHOW);
		m_edtStartNo.ShowWindow(SW_SHOW);
	}
	else
	{
		m_chkData.ShowWindow(SW_SHOW);
		m_chkBeampath.ShowWindow(SW_SHOW);
		m_chkLotCount.ShowWindow(SW_HIDE);
		m_chkSelect.ShowWindow(SW_SHOW);
		
		GetDlgItem(IDC_STATIC_DNC)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_DNC)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC_SELECT_FIRE)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_SELECT_FIRE)->ShowWindow(SW_SHOW);
		if(m_bSelectFire)
		{
			GetDlgItem(IDC_STATIC_FIELD)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_EDIT_FIELD)->ShowWindow(SW_SHOW);
			m_chkField.ShowWindow(SW_SHOW);
		}
		else
		{
			GetDlgItem(IDC_STATIC_FIELD)->ShowWindow(SW_HIDE);
			GetDlgItem(IDC_EDIT_FIELD)->ShowWindow(SW_HIDE);
			m_chkField.ShowWindow(SW_HIDE);
		}
		GetDlgItem(IDC_STATIC_AMOUNT_LOT)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_START_NUM)->ShowWindow(SW_HIDE);
		m_edtInputLot.ShowWindow(SW_HIDE);
		m_edtStartNo.ShowWindow(SW_HIDE);
	}
	m_edtInputLot.SetFont( &m_fntEdit );
	m_edtInputLot.SetReceivedFlag( 1 );

	m_edtStartNo.SetFont( &m_fntEdit );
	m_edtStartNo.SetReceivedFlag( 1 );
	CString strData;
	strData.Format(_T("%d"), m_nInputLot);
	m_edtInputLot.SetWindowText( (LPCTSTR)strData );
	strData.Format(_T("%d"), m_nStartNo);
	m_edtStartNo.SetWindowText( (LPCTSTR)strData );
}

void CDlgInputLotInfo::OnOK() 
{
	CString strData;

	m_edtInputLot.GetWindowText( strData );

	int nLot = atoi( (LPSTR)(LPCTSTR)strData );

	if( nLot <= 0 )
	{
		ErrMessage(IDS_LOT_VALUE_ERR, MB_ICONERROR);
		m_edtInputLot.SetFocus();
		m_edtInputLot.SetSel( 0, -1 );
		return;
	}

	m_nInputLot = nLot;
	
	m_edtStartNo.GetWindowText( strData );
	
	int nStartNo = atoi((LPSTR)(LPCTSTR)strData );
	//if(nStartNo <= 0 || nLot < nStartNo)
	//{
	//	ErrMessage(IDS_START_LOTID_ERR, MB_ICONERROR);
	//	m_edtStartNo.SetFocus();
	//	m_edtStartNo.SetSel( 0, -1 );
	//	return;
	//}
	m_nStartNo = nStartNo;

	CDialog::OnOK();
}

BOOL CDlgInputLotInfo::DestroyWindow() 
{
	m_fntBtn.DeleteObject();
	m_fntEdit.DeleteObject();
	m_fntStatic.DeleteObject();
	
	return CDialog::DestroyWindow();
}


BOOL CDlgInputLotInfo::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
		if(pMsg->message == WM_LBUTTONDOWN || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_SPACE)
	{
		if(gSystemINI.m_sHardWare.bSaveButtonLog)
		{
			int nID = ::GetDlgCtrlID(pMsg->hwnd);

			if(nID == ::GetDlgCtrlID(this->m_hWnd))  // Dialog�� Form �� ID�� ��� ���� (���ϸ� ���α׷� ����)
				return CDialog::PreTranslateMessage(pMsg);
			HWND hItem = ::GetDlgItem(m_hWnd, nID);  // ���� ���̾�α��� �ڵ����� �˻�
			if(!::IsWindow(hItem))
				return CDialog::PreTranslateMessage(pMsg);

			DWORD dStyle = GetDlgItem(nID)->GetStyle();
			if(	dStyle & BS_PUSHBUTTON||
				dStyle & BS_CHECKBOX ||
				dStyle & BS_RADIOBUTTON ||
				dStyle & BS_AUTORADIOBUTTON)
			{
				CString strLog, strButtonText;
				strLog.GetBuffer(256);
				strButtonText.GetBuffer(256);
				GetDlgItem(nID)->GetWindowText(strButtonText);

				strLog.Format("USER_CLICK(Lot_Input) : %s", strButtonText);
				strLog.ReleaseBuffer();
				strButtonText.ReleaseBuffer();
				((CEasyDrillerDlg*)::AfxGetMainWnd())->SetButtonInfo(strLog);
				::AfxGetMainWnd()->SendMessage(UM_BUTTOM_MESSAGE);
			}
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}

void CDlgInputLotInfo::OnCheckData()
{
	BOOL bCheck;
	if(m_bAutoRun)
	{
		if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkLotCount.GetCheck())
			bCheck = TRUE;
		else
			bCheck = FALSE;

		if(bCheck)
			m_btnOk.EnableWindow(TRUE);
		else
			m_btnOk.EnableWindow(FALSE);
	}
	else
	{
		if(m_bSelectFire)
		{
			if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkSelect.GetCheck() && m_chkField.GetCheck())
				bCheck = TRUE;
			else
				bCheck = FALSE;
		}
		else
		{
			if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkSelect.GetCheck())
				bCheck = TRUE;
			else
				bCheck = FALSE;
		}

		if(bCheck)
			m_btnOk.EnableWindow(TRUE);
		else
			m_btnOk.EnableWindow(FALSE);
	}
}
void CDlgInputLotInfo::OnCheckSelect()
{
	BOOL bCheck;
	if(m_bAutoRun)
	{
		if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkLotCount.GetCheck())
			bCheck = TRUE;
		else
			bCheck = FALSE;

		if(bCheck)
			m_btnOk.EnableWindow(TRUE);
		else
			m_btnOk.EnableWindow(FALSE);
	}
	else
	{
		if(m_bSelectFire)
		{
			if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkSelect.GetCheck() && m_chkField.GetCheck())
				bCheck = TRUE;
			else
				bCheck = FALSE;
		}
		else
		{
			if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkSelect.GetCheck())
				bCheck = TRUE;
			else
				bCheck = FALSE;
		}

		if(bCheck)
			m_btnOk.EnableWindow(TRUE);
		else
			m_btnOk.EnableWindow(FALSE);
	}

}
void CDlgInputLotInfo::OnCheckBeampath()
{
	BOOL bCheck;
	if(m_bAutoRun)
	{
		if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkLotCount.GetCheck())
			bCheck = TRUE;
		else
			bCheck = FALSE;

		if(bCheck)
			m_btnOk.EnableWindow(TRUE);
		else
			m_btnOk.EnableWindow(FALSE);
	}
	else
	{
		if(m_bSelectFire)
		{
			if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkSelect.GetCheck() && m_chkField.GetCheck())
				bCheck = TRUE;
			else
				bCheck = FALSE;
		}
		else
		{
			if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkSelect.GetCheck())
				bCheck = TRUE;
			else
				bCheck = FALSE;
		}

		if(bCheck)
			m_btnOk.EnableWindow(TRUE);
		else
			m_btnOk.EnableWindow(FALSE);
	}

}
void CDlgInputLotInfo::OnCheckField()
{
	BOOL bCheck;
	if(m_bAutoRun)
	{
		if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkLotCount.GetCheck())
			bCheck = TRUE;
		else
			bCheck = FALSE;

		if(bCheck)
			m_btnOk.EnableWindow(TRUE);
		else
			m_btnOk.EnableWindow(FALSE);
	}
	else
	{
		if(m_bSelectFire)
		{
			if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkSelect.GetCheck() && m_chkField.GetCheck())
				bCheck = TRUE;
			else
				bCheck = FALSE;
		}
		else
		{
			if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkSelect.GetCheck())
				bCheck = TRUE;
			else
				bCheck = FALSE;
		}

		if(bCheck)
			m_btnOk.EnableWindow(TRUE);
		else
			m_btnOk.EnableWindow(FALSE);
	}

}
void CDlgInputLotInfo::OnCheckLotCount()
{
	BOOL bCheck;
	if(m_bAutoRun)
	{
		if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkLotCount.GetCheck())
			bCheck = TRUE;
		else
			bCheck = FALSE;

		if(bCheck)
			m_btnOk.EnableWindow(TRUE);
		else
			m_btnOk.EnableWindow(FALSE);
	}
	else
	{
		if(m_bSelectFire)
		{
			if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkSelect.GetCheck() && m_chkField.GetCheck())
				bCheck = TRUE;
			else
				bCheck = FALSE;
		}
		else
		{
			if(m_chkBeampath.GetCheck() && m_chkData.GetCheck() && m_chkSelect.GetCheck())
				bCheck = TRUE;
			else
				bCheck = FALSE;
		}

		if(bCheck)
			m_btnOk.EnableWindow(TRUE);
		else
			m_btnOk.EnableWindow(FALSE);
	}

}

void CDlgInputLotInfo::SetData()
{
	CString strValue,strFile;
	strFile.Format(_T("InputLotinfo"));
	CString strTemp;
	
	strTemp = gDProject.m_szFileName;

	for(int i =0; i < 4; i++)
	{
		int nIndex = strTemp.Find(_T("\\"));
		int nLength = strTemp.GetLength();
		strTemp = strTemp.Mid(nIndex+1, nLength);
	}

	GetDlgItem(IDC_EDIT_DNC)->SetWindowText(strTemp);

	
	if(m_bSelectFire)
	{
		strValue.Format(_T("ON"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strValue));
	}
	else
	{
		strValue.Format(_T("OFF"));
		::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strValue));
	}
	GetDlgItem(IDC_EDIT_SELECT_FIRE)->SetWindowText(strValue);

	strValue = SelectField();
	GetDlgItem(IDC_EDIT_FIELD)->SetWindowText(strValue);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strValue));

	strValue.Format(_T("%d X %d"), gDProject.m_nDivRangeXDisp, gDProject.m_nDivRangeYDisp);
	GetDlgItem(IDC_STATIC_DIVIDE_VALUE)->SetWindowText(strValue);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strValue));

	strValue.Format(_T("%.2f"), gDProject.m_dScaleTolerance2);
	GetDlgItem(IDC_STATIC_SCALE_VALUE)->SetWindowText(strValue);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strValue));

	strValue.Format(_T("%.2f , %.2f"), gDProject.m_dLengthTolerance1, gDProject.m_dLengthTolerance2);
	GetDlgItem(IDC_STATIC_LENGTH_VALUE)->SetWindowText(strValue);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strValue));

	strValue.Format(_T("(%.3f , %.3f) , (%.3f , %.3f)"),
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pScannerCalibration->m_dMaxOffsetMasterX*1000,
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pScannerCalibration->m_dMaxOffsetMasterY*1000,
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pScannerCalibration->m_dMaxOffsetSlaveX*1000,
	((CEasyDrillerDlg*)::AfxGetMainWnd())->m_pManualControl->m_pScannerCalibration->m_dMaxOffsetSlaveY*1000);
	GetDlgItem(IDC_STATIC_AUTOCAL_VALUE)->SetWindowText(strValue);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strValue));

	strValue.Format(_T("%.2f , %.2f"), gOPCParam.dPowerMeasure[0], gOPCParam.dPowerMeasure[1]);
	GetDlgItem(IDC_STATIC_POWER_VALUE)->SetWindowText(strValue);
	::AfxGetMainWnd()->SendMessage(UM_WRITE_LOG, reinterpret_cast<WPARAM>(&strFile), reinterpret_cast<LPARAM>(&strValue));
}

void CDlgInputLotInfo::InitListControl()
{
	// Set List Font
	m_fntList.CreatePointFont(130, "Arial Bold");

	m_listBoardParam.SetFont( &m_fntList );

	int nMaxColumnNum = 5;
	LV_COLUMN lvcolumn;
	CString strText;
	TCHAR szText[256] = {0,};

	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_CENTER;

	for(int i = 0 ; i < nMaxColumnNum ; i++ )
	{
		switch( i )
		{
		case 0 :
			strText.Format(_T("T"));
			lvcolumn.cx = 45;
			break;
		case 1 :
			strText.Format(_T("Beam Path"));
			lvcolumn.cx = 170;
			break;
		case 2 :
			strText.Format(_T("Shot"));
			lvcolumn.cx = 80;
			break;
		case 3 :
			strText.Format(_T("Duty"));
			lvcolumn.cx = 80;
			break;
		case 4 :
			strText.Format(_T("Frequency"));
			lvcolumn.cx = 100;
			break;
		}
		_stprintf_s( szText, _T("%s"), strText );
		lvcolumn.pszText = szText;
		lvcolumn.iSubItem = i;

		m_listBoardParam.InsertColumn(i, &lvcolumn);
	}

	DWORD dwStyle = m_listBoardParam.GetStyle();
	dwStyle |= LVS_EX_FULLROWSELECT;
	dwStyle |= LVS_EX_GRIDLINES;

	m_listBoardParam.SetExtendedStyle( dwStyle );

 	m_listBoardParam.DeleteAllItems();
 
 	CString strTotal;
 	SUBTOOLDATA toolData;
 	LVITEM lvItem;
 	lvItem.mask = LVIF_TEXT|LVIF_PARAM;
 	lvItem.lParam = 1;
 	lvItem.state = 0;
 	//	lvItem.stateMask = LVIS_SELECTED;
 	int nCount = 0;
 
 	for(int i = 0; i<MAX_TOOL_NO; i++)
 	{
 		if(!gDProject.m_pToolCode[i]->m_bUseTool)
 			continue;
 		//Tool No
		POSITION pos = gDProject.m_pToolCode[i]->m_SubToolData.GetHeadPosition();
		if(pos)
		{
			toolData = gDProject.m_pToolCode[i]->m_SubToolData.GetNext(pos);
			for(int j=0; j< toolData.nTotalShot; j++)
			{
 				lvItem.iItem = nCount;
 				lvItem.iSubItem = 0;
 				strTotal.Format(_T("%d"), i);
 				lvItem.pszText = (LPSTR)(LPCSTR)strTotal;
 				m_listBoardParam.InsertItem(&lvItem);
 
 				// 110311 Mask�� ����
 				lvItem.iItem = nCount;
 				lvItem.iSubItem = 1;
 				strTotal.Format(_T("%d-%s"), gBeamPathINI.m_sBeampath.nInfoId[toolData.nMask], gBeamPathINI.m_sBeampath.strInfoName[toolData.nMask] );
 				m_listBoardParam.SetItemText(nCount, 1, (LPSTR)(LPCSTR)strTotal);
			
				m_listBoardParam.InsertItem(&lvItem);
				lvItem.iItem = nCount;
				lvItem.iSubItem = 2;
				strTotal.Format(_T("%d"), j+1 );
				m_listBoardParam.SetItemText(nCount, 2, (LPSTR)(LPCSTR)strTotal);

 				// 110311 Duty�� ����
 				lvItem.iItem = nCount;
 				lvItem.iSubItem = 3;
 				strTotal.Format(_T("%.2f"), toolData.dShotDuty[j]);
 				m_listBoardParam.SetItemText(nCount, 3, (LPSTR)(LPCSTR)strTotal);
 		
				lvItem.iItem = nCount;
				lvItem.iSubItem = 4;
				strTotal.Format(_T("%.0f"), toolData.dShotMaxFreq[j]);
				m_listBoardParam.SetItemText(nCount, 4, (LPSTR)(LPCSTR)strTotal);
				nCount++;
			}
		}
 		else
 		{
 			strTotal.Format(_T("-"));
 			m_listBoardParam.SetItemText(nCount, 1, (LPSTR)(LPCSTR)strTotal);
 
 			m_listBoardParam.SetItemText(nCount, 2, (LPSTR)(LPCSTR)strTotal);
 
 			m_listBoardParam.SetItemText(nCount, 3, (LPSTR)(LPCSTR)strTotal);
 		}
// 		nCount++;
 	}
}
BOOL CDlgInputLotInfo::IsAvailableArea(DAreaInfo *pAreaInfo, int nToolNo, int nFidBlock)
{
	if(nToolNo == ADDED_FID_TOOL) // skiving ó��
	{
		int nIndex;
		int nCount = gDProject.m_Glyphs.GetUseFidCount(DEFAULT_FID_INDEX);
		LPFIDDATA pFidData;
		for(int i = 0; i < nCount; i++)
		{
			pFidData = gDProject.m_Glyphs.GetFiducialData(DEFAULT_FID_INDEX, i);
			if( (pFidData->nFidType & FID_SECONDARY) && (pFidData->nFidType & FID_DRILL))
			{
				nIndex = gDProject.m_Glyphs.GetUseFidRealIndex(DEFAULT_FID_INDEX, i);
				nIndex = pFidData->nFindIndex; //gDProject.m_Glyphs.GetUseFidRealIndex(ADDED_FID_INDEX, i);
				if(m_bAutoRun) // auto run������ select, tool visible�� ������� ��� �����Ѵ�.
					return TRUE;
				if(!m_bSelectFire || gDProject.m_Glyphs.GetUseFidSelect(DEFAULT_FID_INDEX, i)) //ADDED_FID_INDEX, nIndex))
				{
					if(pAreaInfo->IsThereSkivingData(nIndex, m_bSelectFire))
						return TRUE;
				}
			}
		}
		return FALSE;
	}

	if(pAreaInfo->IsThereSameBlockData(nFidBlock)) // data�� �־�� ��.
	{
		if(gDProject.m_ToolSumInfo[gDProject.m_ToolSumInfo[nToolNo].nRealToolNo].nToolAtri == emFlying)
			return FALSE;

		if(pAreaInfo->IsThereSameBlockData(nFidBlock) && m_bAutoRun)
			return TRUE;// auto run������ select, tool visible�� ������� ��� �����Ѵ�.


		if(gDProject.m_ToolSumInfo[gDProject.m_ToolSumInfo[nToolNo].nRealToolNo].nToolAtri == emOneBoardTool)
		{
			if(!gDProject.m_pToolCode[nToolNo]->IsVisable() || (!pAreaInfo->IsThereSelectData() && m_bSelectFire))
				return FALSE;
			else
				return TRUE;
		}
		else
		{
			for(int i = nToolNo; i < MAX_TOOL_NO; i++)
			{
				if(pAreaInfo->IsThereSelectData() && m_bSelectFire) // IsThereSelectData : visible tool�� ���ϴ� select �����Ͱ� ������
					return TRUE;
				if(pAreaInfo->IsThereData() && !m_bSelectFire)
					return TRUE;
			}
			return FALSE;
		}
		return TRUE;
	}
	else
		return FALSE;
}


CString CDlgInputLotInfo::SelectField()
{
	CString strField;
	int nStartTool = 1, nEndTool = MAX_TOOL_NO; // 0�� tool �����ϰ� ��� 
	// ������ ���� �ִ� tool �� areaTempList�� ����
	AreaList AreaTempList;
	POSITION posArea;
	DAreaInfo *pAreaInfo, *pAreaInfoOld;
	int nHoleLogIndex[5], nRefVal[5], nLogIndex = 0;
	for(int i = 0; i < 5; i++)
	{
		nHoleLogIndex[i] = -1; nRefVal[i] = INT_MAX;
	}
	int nFidBlock = -1;
	int nCount;

	for(int i = nStartTool; i < nEndTool; i++)
	{
		posArea = gDProject.m_Areas[i].GetHeadPosition();
		while (posArea) 
		{
			pAreaInfo = gDProject.m_Areas[i].GetNext(posArea);
			if(IsAvailableArea(pAreaInfo, i, nFidBlock))
			{
				AreaTempList.AddTail(pAreaInfo);
				if(abs(pAreaInfo->m_nCenterX - gDProject.m_nMinX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMinY) < nRefVal[0])
				{
					nRefVal[0] = abs(pAreaInfo->m_nCenterX - gDProject.m_nMinX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMinY);
					nHoleLogIndex[0] = nLogIndex;
				}
				if(abs(pAreaInfo->m_nCenterX - gDProject.m_nMaxX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMinY) < nRefVal[1])
				{
					nRefVal[1] = abs(pAreaInfo->m_nCenterX - gDProject.m_nMaxX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMinY);
					nHoleLogIndex[1] = nLogIndex;
				}
				if(abs(pAreaInfo->m_nCenterX - gDProject.m_nMinX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMaxY) < nRefVal[2])
				{
					nRefVal[2] = abs(pAreaInfo->m_nCenterX - gDProject.m_nMinX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMaxY);
					nHoleLogIndex[2] = nLogIndex;
				}
				if(abs(pAreaInfo->m_nCenterX - gDProject.m_nMaxX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMaxY) < nRefVal[3])
				{
					nRefVal[3] = abs(pAreaInfo->m_nCenterX - gDProject.m_nMaxX) + abs(pAreaInfo->m_nCenterY - gDProject.m_nMaxY);
					nHoleLogIndex[3] = nLogIndex;
				}
				if(abs(pAreaInfo->m_nCenterX - (gDProject.m_nMinX + gDProject.m_nMaxX)/2) 
					+ abs(pAreaInfo->m_nCenterY - (gDProject.m_nMinY +  gDProject.m_nMaxY)/2) < nRefVal[4])
				{
					nRefVal[4] = abs(pAreaInfo->m_nCenterX - (gDProject.m_nMinX + gDProject.m_nMaxX)/2) 
						+ abs(pAreaInfo->m_nCenterY - (gDProject.m_nMinY +  gDProject.m_nMaxY)/2);
					nHoleLogIndex[4] = nLogIndex;
				}
				nLogIndex++;
			}
		}
	}

	nCount = AreaTempList.GetCount();
	int i=0;
	posArea = AreaTempList.GetHeadPosition();
	while (i < nCount) 
	{
		pAreaInfo = AreaTempList.GetNext(posArea);
		int nfield = pAreaInfo->m_nSortIndex;
		CString str;
		str.Format(_T("%d ,"),nfield);
		strField += str;
		i++;
	}

	return strField;
}
#if !defined(AFX_PANERECIPEGENPARAMETERNEWNEXT_H__26F5ED10_4D05_48CC_915B_6AF5FD30DABB__INCLUDED_)
#define AFX_PANERECIPEGENPARAMETERNEWNEXT_H__26F5ED10_4D05_48CC_915B_6AF5FD30DABB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneRecipeGenParameterNewNext.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneRecipeGenParameterNewNext form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif


#include "ColorEdit.h"
#include "UEasyButtonEx.h"
#include "ColorComboEx.h"
#include "..\model\DProject.h"
#include "..\model\ToolCodeList.h"
#include "..\model\globalvariable.h"


#define TABLE_COUNT			24
#define COPYDATA_COUNT		24


class CPaneRecipeGenParameterNewNext : public CFormView
{
protected:
	CPaneRecipeGenParameterNewNext();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneRecipeGenParameterNewNext)

// Form Data
public:
	//{{AFX_DATA(CPaneRecipeGenParameterNewNext)
	enum { IDD = IDD_DLG_RECIPE_GEN_PARAMETER_NEW_NEXT };
	CListCtrl	m_ParamList;
	//}}AFX_DATA

// Attributes
public:
	CFont		m_fntList;
	CFont		m_fntCombo;
	CFont		m_fntStatic;
	CFont		m_fntEdit;
	CFont		m_fntBtn;

	UEasyButtonEx	m_btnOpen;
	UEasyButtonEx	m_btnSave;
	UEasyButtonEx	m_chkToolOrder;

	BOOL			m_bUseTool;
	BOOL			m_bToolOrder;
	BOOL			m_bUseAperture;
	BOOL			m_bUseFlipX;
	BOOL			m_bUseFlipY;

	double			m_dDuty[MAX_BEAM_HOLE];
	double			m_dAOMDelay[MAX_BEAM_HOLE];
	double			m_dAOMDuty[MAX_BEAM_HOLE];
	TCHAR			m_cAOMFilePath[MAX_BEAM_HOLE][255];

	CToolCodeList* m_pToolCode[MAX_TOOL_NO];
	CString		    m_strCopyData[COPYDATA_COUNT];

	BOOL			m_bGlobalParam;

	BOOL			m_bClickListofLeftMouse;
	BOOL			m_bClickListofRightMouse;

	// control on the list
	CPoint			m_posClicked;		// ����Ʈ �� Ŭ���� �� ��� 
	CEdit			m_editwnd;
	CComboBox		m_comToolType;
	CColorComboEx	m_comColor;
	CComboBox		m_comUseToolOrder;
	CComboBox		m_comPreheat;
	CComboBox		m_comPower;	
	CComboBox		m_comScanner;
	CComboBox		m_comBeamPath;
	CComboBox		m_comDrillMethod;
	CComboBox		m_comAddDel;
	CButton			m_btnAom;

	CPoint		m_posAddDelClicked;	// add,del �� �������� ���� �߰�, add,del �Ҷ� �޺��ڽ� Ŭ���� �� ��ġ���� ����� add del ���� �ȵ� 
	

	int m_nListRowCount;		// ����Ʈ�� ���� ũ�� ����// Ŭ���� ������ ���� tool, subtool ��ȣ�� �˱����� ��� 

	//control ����
	BOOL m_bSelectToolType;
	BOOL m_bSelectColor;
	BOOL m_bSelectUseToolOrder;
	BOOL m_bSelectPreheat;
	BOOL m_bSelectPreworkPower;
	BOOL m_bSelectPreworkScanner;
	BOOL m_bSelectBeampath;
	BOOL m_bSelectDrillMethod;
	BOOL m_bSelectAddDel;

// Operations
public:
	void CheckAnyDoPrework();
	int LimitClickforMarkShot(CPoint Position);
	int GetSelectDrillMethod();
	void SetSelectDrillMethod(int nSelect);
	int GetSelectBeampath();
	void SetSelectBeampath(int nSelect);
	int GetSelectPreScanner();
	void SetSelectPreScanner(int nSelect);
	int GetSelectPrePower();
	void SetSelectPrePower(int nSelect);
	int GetSelectPreheat();
	void SetSelectPreheat(int nSelect);
	int GetSelectUseToolOrder();
	void SetSelectUseToolorder(int nSelect);
	int GetSelectColor();
	void SetSelectColor(int nSelect);
	int GetSelectToolType();
	void SetSelectToolType(int nSelect);
	void UpdateListData(CPoint Pos, CString strData);
	BOOL GetData(DProject &tempDProject);
	void SetEditBoxActive(int i);
	BOOL CheckSubTool(SUBTOOLDATA subData, int nToolNum);
	BOOL GetAddDel();
	void SetAddDel(BOOL nSelect);
	void DelSubTool();
	void AddSubTool();
	void GetToolSubtoolNo(int ClickedPos, int &nToolNo, int &nSubToolNo);

	void SelectControl(int nXpos, int nYpos);
	BOOL MoveFocus(int nXpos, int nYpos, int nMoveType);
	void SetCurrentScrollPos(int xPos, int yPos);
	void SetCloseControl();
	void OnKillfocusEditGrid();
	void GetSubToolData(int nToolNo,int nSubNo);
	int GetSubToolNumber(int nToolNo);
	void DeleteList();
	void ChangeDisplay();
	BOOL SetData(GlobalVariable &mGlobal, int nMainTool);
	BOOL SetData(DProject& mDproject);

	void InitListControl();
	void InitStaticControl();
	void InitBtnControl();
	void InitComboControl();
	void InitEditControl();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneRecipeGenParameterNewNext)
	public:
	virtual void OnInitialUpdate();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneRecipeGenParameterNewNext();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneRecipeGenParameterNewNext)
	afx_msg void OnClickListParam(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRclickListParam(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangeComboAddDel();
	afx_msg void OnKillFocusComboAddDel();
	afx_msg void OnSelchangeComboToolType();
	afx_msg void OnKillFocusComboToolType();
	afx_msg void OnSelchangeComboColor();
	afx_msg void OnKillFocusComboColor();
	afx_msg void OnSelchangeComboUseToolOrder();
	afx_msg void OnKillFocusComboUseToolOrder();
	afx_msg void OnSelchangeComboPreheat();
	afx_msg void OnKillFocusComboPreheat();
	afx_msg void OnSelchangeComboPrePower();
	afx_msg void OnKillFocusComboPrePower();
	afx_msg void OnSelchangeComboPreScanner();
	afx_msg void OnKillFocusComboPreScanner();
	afx_msg void OnSelchangeComboBeampath();
	afx_msg void OnKillFocusComboBeampath();
	afx_msg void OnSelchangeComboDrillMethod();
	afx_msg void OnKillFocusComboDrillMethod();
	afx_msg void OnButtonParamOpenNext();
	afx_msg void OnButtonParamSaveNext();
	afx_msg void OnButtonAom();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANERECIPEGENPARAMETERNEWNEXT_H__26F5ED10_4D05_48CC_915B_6AF5FD30DABB__INCLUDED_)

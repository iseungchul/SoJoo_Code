#if !defined(AFX_PANEMANUALCONTROLIOMONITORNULLSUB_H__16D13F32_C5A0_4FCF_AF8A_1811701F6F07__INCLUDED_)
#define AFX_PANEMANUALCONTROLIOMONITORNULLSUB_H__16D13F32_C5A0_4FCF_AF8A_1811701F6F07__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PaneManualControlIOMonitorNullSub.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorNullSub form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CPaneManualControlIOMonitorNullSub : public CFormView
{
protected:
	CPaneManualControlIOMonitorNullSub();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CPaneManualControlIOMonitorNullSub)

// Form Data
public:
	//{{AFX_DATA(CPaneManualControlIOMonitorNullSub)
	enum { IDD = IDD_DLG_MANUAL_CONTROL_IO_MONITOR_NULL_SUB };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaneManualControlIOMonitorNullSub)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CPaneManualControlIOMonitorNullSub();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CPaneManualControlIOMonitorNullSub)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PANEMANUALCONTROLIOMONITORNULLSUB_H__16D13F32_C5A0_4FCF_AF8A_1811701F6F07__INCLUDED_)

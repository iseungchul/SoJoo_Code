// PaneAutoRunView.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneAutoRunView.h"
#include "PaneAutoRunViewData.h"
#include "PaneAutoRunViewFiducial.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunView

IMPLEMENT_DYNCREATE(CPaneAutoRunView, CFormView)

CPaneAutoRunView::CPaneAutoRunView()
	: CFormView(CPaneAutoRunView::IDD)
{
	//{{AFX_DATA_INIT(CPaneAutoRunView)
		// NOTE: the ClassWizard will add member initialization here
	m_pData = NULL;
	//}}AFX_DATA_INIT
}

CPaneAutoRunView::~CPaneAutoRunView()
{
}

void CPaneAutoRunView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneAutoRunView)
	DDX_Control(pDX, IDC_TAB_AUTORUN_VIEW, m_tabAutoRunView);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneAutoRunView, CFormView)
	//{{AFX_MSG_MAP(CPaneAutoRunView)
	ON_WM_MOUSEWHEEL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunView diagnostics

#ifdef _DEBUG
void CPaneAutoRunView::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneAutoRunView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneAutoRunView message handlers

void CPaneAutoRunView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitTabControl();
}

void CPaneAutoRunView::InitTabControl()
{

	// Set Button Font
	m_fntTab.CreatePointFont(110, "Arial Bold");
	
	BOOL bRet = 0;
	
	m_tabAutoRunView.SetFont( &m_fntTab );
	
	// Data
	bRet = m_tabAutoRunView.AddPane( _T(" Data "), RUNTIME_CLASS(CPaneAutoRunViewData) );
	if( FALSE != bRet )
	{
		m_pData = static_cast<CPaneAutoRunViewData*>(m_tabAutoRunView.GetPane(0));
		m_pData->OnInitialUpdate();
	}
	
	//Fiducial
	bRet = m_tabAutoRunView.AddPane( _T(" Fiducial "), RUNTIME_CLASS(CPaneAutoRunViewFiducial) );
	if( FALSE != bRet )
	{
		m_pFiducial = static_cast<CPaneAutoRunViewFiducial*>(m_tabAutoRunView.GetPane(1));
		m_pFiducial->OnInitialUpdate();
	}
	
}

BOOL CPaneAutoRunView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	// TODO: Add your message handler code here and/or call default
	ErrMessage(_T("runview"));
	return CFormView::OnMouseWheel(nFlags, zDelta, pt);
}

// PaneManualControlIOMonitorInputSub2Osan.cpp : implementation file
//

#include "stdafx.h"
#include "..\easydriller.h"
#include "PaneManualControlIOMonitorInputSub2Osan.h"
#include "..\device\HDeviceFactory.h"
#include "..\Model\DSystemINI.h"
#include "..\Model\DEasyDrillerINI.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub2Osan

IMPLEMENT_DYNCREATE(CPaneManualControlIOMonitorInputSub2Osan, CFormView)

CPaneManualControlIOMonitorInputSub2Osan::CPaneManualControlIOMonitorInputSub2Osan()
	: CFormView(CPaneManualControlIOMonitorInputSub2Osan::IDD)
{
	//{{AFX_DATA_INIT(CPaneManualControlIOMonitorInputSub2Osan)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nTimerID = 0;
}

CPaneManualControlIOMonitorInputSub2Osan::~CPaneManualControlIOMonitorInputSub2Osan()
{
}

void CPaneManualControlIOMonitorInputSub2Osan::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaneManualControlIOMonitorInputSub2Osan)
	DDX_Control(pDX, IDC_CHECK_ALIGN_RUN, m_ledAlignRun);
	DDX_Control(pDX, IDC_CHECK_ALIGN_END, m_ledAlignEnd);
	DDX_Control(pDX, IDC_CHECK_LOAD_RUN, m_ledLoadRun);
	DDX_Control(pDX, IDC_CHECK_LOAD_END, m_ledLoadEnd);
	DDX_Control(pDX, IDC_CHECK_UNLOAD_RUN, m_ledUnloadRun);
	DDX_Control(pDX, IDC_CHECK_UNLOAD_END, m_ledUnloadEnd);
	DDX_Control(pDX, IDC_CHECK_LOAD_REQUEST_READY, m_ledLoadRequestReady);

	DDX_Control(pDX, IDC_CHECK_LOAD_PART_ERROR, m_ledLoadPartError);
	DDX_Control(pDX, IDC_CHECK_UNLOAD_PART_ERROR, m_ledUnloadPartError);

	DDX_Control(pDX, IDC_CHECK_LP1_PCB_EXIST, m_ledLP1PCBExist);
	DDX_Control(pDX, IDC_CHECK_LP2_PCB_EXIST, m_ledLP2PCBExist);
	DDX_Control(pDX, IDC_CHECK_UP1_PCB_EXIST, m_ledUP1PCBExist);
	DDX_Control(pDX, IDC_CHECK_UP2_PCB_EXIST, m_ledUP2PCBExist);
	DDX_Control(pDX, IDC_CHECK_LD_ELV_PCB_EXIST, m_ledLdElvPCBExist);
	DDX_Control(pDX, IDC_CHECK_RESET_SWITCH, m_ledResetSwitch);
	DDX_Control(pDX, IDC_CHECK_LOADER_INTERLOCK_BYPASS, m_ledLoaderBypass);
	DDX_Control(pDX, IDC_CHECK_UNLOADER_INTERLOCK_BYPASS, m_ledUnloaderBypass);

	DDX_Control(pDX, IDC_CHECK_LD_PCB_TRANS_PCB_EXIST, m_ledLdPcbTransExist);
	DDX_Control(pDX, IDC_CHECK_LD_PAPER_TRANS_PCB_EXIST, m_ledLdPaperTransExist);
	DDX_Control(pDX, IDC_CHECK_UD_PCB_TRANS_PCB_EXIST, m_ledUdPcbTransExist);
	DDX_Control(pDX, IDC_CHECK_UD_PAPER_TRANS_PCB_EXIST, m_ledUdPaperTransExist);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPaneManualControlIOMonitorInputSub2Osan, CFormView)
	//{{AFX_MSG_MAP(CPaneManualControlIOMonitorInputSub2Osan)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub2Osan diagnostics

#ifdef _DEBUG
void CPaneManualControlIOMonitorInputSub2Osan::AssertValid() const
{
	CFormView::AssertValid();
}

void CPaneManualControlIOMonitorInputSub2Osan::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPaneManualControlIOMonitorInputSub2Osan message handlers

void CPaneManualControlIOMonitorInputSub2Osan::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitBtnControl();
}

void CPaneManualControlIOMonitorInputSub2Osan::InitBtnControl()
{
	// Set Button Font
	m_fntBtn.CreatePointFont(100, "Arial Bold");

	m_ledAlignRun.SetFont( &m_fntBtn );
	m_ledAlignRun.SetImage( IDB_LEDCOLOR, 15 );
	m_ledAlignRun.Depress( TRUE );

	m_ledAlignEnd.SetFont( &m_fntBtn );
	m_ledAlignEnd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledAlignEnd.Depress( TRUE );

	m_ledLoadRun.SetFont( &m_fntBtn );
	m_ledLoadRun.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLoadRun.Depress( TRUE );

	m_ledLoadEnd.SetFont( &m_fntBtn );
	m_ledLoadEnd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLoadEnd.Depress( TRUE );

	m_ledUnloadRun.SetFont( &m_fntBtn );
	m_ledUnloadRun.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUnloadRun.Depress( TRUE );

	m_ledUnloadEnd.SetFont( &m_fntBtn );
	m_ledUnloadEnd.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUnloadEnd.Depress( TRUE );

	m_ledLoadRequestReady.SetFont( &m_fntBtn );
	m_ledLoadRequestReady.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLoadRequestReady.Depress( TRUE );
	
	m_ledLoadPartError.SetFont( &m_fntBtn );
	m_ledLoadPartError.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLoadPartError.Depress( TRUE );

	m_ledUnloadPartError.SetFont( &m_fntBtn );
	m_ledUnloadPartError.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUnloadPartError.Depress( TRUE );

	m_ledLP1PCBExist.SetFont( &m_fntBtn );
	m_ledLP1PCBExist.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP1PCBExist.Depress( TRUE );

	m_ledLP2PCBExist.SetFont( &m_fntBtn );
	m_ledLP2PCBExist.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLP2PCBExist.Depress( TRUE );

	m_ledUP1PCBExist.SetFont( &m_fntBtn );
	m_ledUP1PCBExist.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP1PCBExist.Depress( TRUE );

	m_ledUP2PCBExist.SetFont( &m_fntBtn );
	m_ledUP2PCBExist.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUP2PCBExist.Depress( TRUE );

	m_ledLdElvPCBExist.SetFont( &m_fntBtn );
	m_ledLdElvPCBExist.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLdElvPCBExist.Depress( TRUE );

	m_ledLdPcbTransExist.SetFont( &m_fntBtn );
	m_ledLdPcbTransExist.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLdPcbTransExist.Depress( TRUE );

	m_ledLdPaperTransExist.SetFont( &m_fntBtn );
	m_ledLdPaperTransExist.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLdPaperTransExist.Depress( TRUE );

	m_ledUdPcbTransExist.SetFont( &m_fntBtn );
	m_ledUdPcbTransExist.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUdPcbTransExist.Depress( TRUE );
	
	m_ledUdPaperTransExist.SetFont( &m_fntBtn );
	m_ledUdPaperTransExist.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUdPaperTransExist.Depress( TRUE );

	m_ledResetSwitch.SetFont( &m_fntBtn );
	m_ledResetSwitch.SetImage( IDB_LEDCOLOR, 15 );
	m_ledResetSwitch.Depress( TRUE );

	m_ledLoaderBypass.SetFont( &m_fntBtn );
	m_ledLoaderBypass.SetImage( IDB_LEDCOLOR, 15 );
	m_ledLoaderBypass.Depress( TRUE );
	
	m_ledUnloaderBypass.SetFont( &m_fntBtn );
	m_ledUnloaderBypass.SetImage( IDB_LEDCOLOR, 15 );
	m_ledUnloaderBypass.Depress( TRUE );
}

void CPaneManualControlIOMonitorInputSub2Osan::UpdateStatus()
{
	// Align Run
	if(m_pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, FALSE, FALSE))
		m_ledAlignRun.Depress(FALSE);
	else
		m_ledAlignRun.Depress(TRUE);

	// Align End
	if(m_pMotor->IsHandlerOperation(HANDLER_LOADER_ALIGN, TRUE, FALSE))
		m_ledAlignEnd.Depress(FALSE);
	else
		m_ledAlignEnd.Depress(TRUE);

	// Load Run
	if(m_pMotor->IsHandlerOperation(HANDLER_LOADER_LOAD, FALSE, FALSE))
		m_ledLoadRun.Depress(FALSE);
	else
		m_ledLoadRun.Depress(TRUE);
	
	// Load End
	if(m_pMotor->IsHandlerOperation(HANDLER_LOADER_LOAD, TRUE, FALSE))
		m_ledLoadEnd.Depress(FALSE);
	else
		m_ledLoadEnd.Depress(TRUE);

	// Unload Run
	if(m_pMotor->IsHandlerOperation(HANDLER_UNLOADER_UNLOAD, FALSE, FALSE))
		m_ledUnloadRun.Depress(FALSE);
	else
		m_ledUnloadRun.Depress(TRUE);
	
	// Unload End
	if(m_pMotor->IsHandlerOperation(HANDLER_UNLOADER_UNLOAD, TRUE, FALSE))
		m_ledUnloadEnd.Depress(FALSE);
	else
		m_ledUnloadEnd.Depress(TRUE);

	// Load Request Ready
	if(m_pMotor->IsHandlerOperation(HANDLER_UNLOADER_TO_LOAD_START, TRUE, FALSE))
		m_ledLoadRequestReady.Depress(FALSE);
	else
		m_ledLoadRequestReady.Depress(TRUE);

	// LP1 PCB Exist
	if(m_pMotor->IsLoaderPicker1PCBExist())
		m_ledLP1PCBExist.Depress(FALSE);
	else
		m_ledLP1PCBExist.Depress(TRUE);

	// LP2 PCB Exist
	if(m_pMotor->IsLoaderPicker2PCBExist())
		m_ledLP2PCBExist.Depress(FALSE);
	else
		m_ledLP2PCBExist.Depress(TRUE);

	// UP1 PCB Exist
	if(m_pMotor->IsUnloaderPicker1PCBExist())
		m_ledUP1PCBExist.Depress(FALSE);
	else
		m_ledUP1PCBExist.Depress(TRUE);
	
	// UP2 PCB Exist
	if(m_pMotor->IsUnloaderPicker2PCBExist())
		m_ledUP2PCBExist.Depress(FALSE);
	else
		m_ledUP2PCBExist.Depress(TRUE);

	// Loader Elevator PCB Exist
	if(!m_pMotor->IsLoadCartNoPCB())
		m_ledLdElvPCBExist.Depress(FALSE);
	else
		m_ledLdElvPCBExist.Depress(TRUE);

	// Reset Switch
	if(m_pMotor->IsResetSwitch())
		m_ledResetSwitch.Depress(FALSE);
	else
		m_ledResetSwitch.Depress(TRUE);

	// Loader Interlock bypass
	if(m_pMotor->IsHandlerDoorBypass(TRUE))
		m_ledLoaderBypass.Depress(FALSE);
	else
		m_ledLoaderBypass.Depress(TRUE);

	// Unloader Interlock bypass
//	if(m_pMotor->IsHandlerDoorBypass(FALSE))
//		m_ledUnloaderBypass.Depress(FALSE);
//	else
//		m_ledUnloaderBypass.Depress(TRUE);

	// LoadPart Error
	if(m_pMotor->IsHandlerPartError(TRUE))
		m_ledLoadPartError.Depress(FALSE);
	else
		m_ledLoadPartError.Depress(TRUE);

	// UnloadPart Error
	if(m_pMotor->IsHandlerPartError(FALSE))
		m_ledUnloadPartError.Depress(FALSE);
	else
		m_ledUnloadPartError.Depress(TRUE);

	// Ld PCB Trans Exist
	if(m_pMotor->IsHandlerTablePCBExist(TRUE))
		m_ledLdPcbTransExist.Depress(FALSE);
	else
		m_ledLdPcbTransExist.Depress(TRUE);

	// Ld Paper Trans Exist
/*	if(m_pMotor->IsHandlerPaperTransPCBExist(TRUE))
		m_ledLdPaperTransExist.Depress(FALSE);
	else
		m_ledLdPaperTransExist.Depress(TRUE);
*/
	// Ud PCB Trans Exist
	if(m_pMotor->IsHandlerTablePCBExist(FALSE))
		m_ledUdPcbTransExist.Depress(FALSE);
	else
		m_ledUdPcbTransExist.Depress(TRUE);

	// Ud Paper Trans Exist
/*	if(m_pMotor->IsHandlerPaperTransPCBExist(FALSE))
		m_ledUdPaperTransExist.Depress(FALSE);
	else
		m_ledUdPaperTransExist.Depress(TRUE);
		*/
}

void CPaneManualControlIOMonitorInputSub2Osan::OnTimer(UINT nIDEvent) 
{
	UpdateStatus();
	
	CFormView::OnTimer(nIDEvent);
}

void CPaneManualControlIOMonitorInputSub2Osan::InitTimer()
{
	if(m_nTimerID == 0)
	{
		m_nTimerID = SetTimer(9972, 1000, NULL);
		m_pMotor = gDeviceFactory.GetMotor();
	}
}

void CPaneManualControlIOMonitorInputSub2Osan::DestroyTimer()
{
	if(m_nTimerID)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
}

BOOL CPaneManualControlIOMonitorInputSub2Osan::PreCreateWindow(CREATESTRUCT& cs) 
{
	CFormView::PreCreateWindow(cs);
	
	cs.dwExStyle	&= ~WS_EX_CLIENTEDGE;
	
	return TRUE;
}
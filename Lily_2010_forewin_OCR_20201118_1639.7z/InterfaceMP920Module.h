#ifndef __INC_MP920_MODULE_HDR__
#define __INC_MP920_MODULE_HDR__

#define DLLAPI	extern "C" __declspec( dllexport )

namespace MP920SETUP
{
	// Motor Setup
	DLLAPI HWND CreateMP920Setup(HWND hParent);
	DLLAPI void ShowMP920Setup(int nCmdShow);

	// IO Monitor
	DLLAPI HWND CreateIOMonitor(HWND hParent);
	DLLAPI void DestroyIOMonitor();
	DLLAPI void ShowIOMonitor(int nCmdShow);

	// MP920 Initialize & Destory
	DLLAPI BOOL InitializeMP920(int nPeriod=50);
	DLLAPI void	DestroyMP920();

	// Write Array Data
	DLLAPI BOOL WriteArrayData(WORD wAddr, WORD wAddrLen, BYTE* pData);
	// bAbs������ wOffset�� ���, Ȥ�� ���� Address�� ��� �� �������� �˷��ش�.
	// false�̸� base output address���� offset����ŭ �̵��Ͽ� Write �ϰڴٴ� ��.
	// true�̸� wOffset�� �ּҿ� Write �ϰڴٴ� ��....
	DLLAPI BOOL WriteWordData(WORD wOffset, WORD wOnOff, BOOL bAbs=FALSE);

	// Get Input Array Data (WORD ARRAY TYPE)
	DLLAPI void GetInputArrayData(WORD* pRegData);

	// LONG(4bytes) Data Conversion
	DLLAPI long ReadLong(WORD* pRegData, int& nPos);
	DLLAPI void WriteLong(BYTE* pData, long nData, int& nPos);

	// WORD(2bytes) Data Conversion
	DLLAPI void WriteWord(BYTE* pData, WORD wData, int& nPos);

	// BYTE(1byte) Data Conversion
	DLLAPI void WriteByte(BYTE* pData, WORD wData, int& nPos, BOOL bIsLow=TRUE);

	// HEX TO DEC
	DLLAPI DWORD HextoNum(char *hex);

	// AXIS SIZE
	DLLAPI int GetAxisSize();
	
	// AXIS INFO
	DLLAPI BOOL GetAxisInfo(int nAxis, SAXISINFO* pAxisInfo);
	DLLAPI BOOL ChangeAxisInfo(SAXISINFO sAxisInfo);
}

using namespace MP920SETUP;

#endif	// __INC_MP920_MODULE_HDR__
